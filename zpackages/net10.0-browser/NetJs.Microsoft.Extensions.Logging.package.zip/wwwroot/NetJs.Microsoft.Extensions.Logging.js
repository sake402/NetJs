
//--TRIMMABLE-BOUNDARY-START(89)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $sttp, $sdd, $mela, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Logging", 
    {
  "h": 89,
  "f": "Microsoft.Extensions.Logging",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 1179736,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 2555992,
          "t": 187629569
        }
      ]
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Logging",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Logging",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(983129)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions", ($self) => class LoggerFactoryOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295950425)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295950425);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950425)
            
            //--TRIMMABLE-BOUNDARY-START(12885885017)
            /*ActivityTrackingOptions*/ ActivityTrackingOptions = 0;
            //--TRIMMABLE-BOUNDARY-END(12885885017)
            
            static $h = 983129;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885885017),
    {
      "p": 196697,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475819609,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065754201,
        "f": 83886081
      },
      "n": "ActivityTrackingOptions",
      "d": 983129,
      "h": 12885885017,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885885017)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950425),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983129,
      "h": 4295950425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950425)
  ],
  "h": 983129,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "ActivityTrackingOptions = {ActivityTrackingOptions}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983129)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162777)
        $asm.$cls("$mel.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(115966279769)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(115966279769)
            
            //--TRIMMABLE-BOUNDARY-START(107376345177)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(107376345177)
            
            //--TRIMMABLE-BOUNDARY-START(111671312473)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606541401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mel.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Logging", $.$mel.System.SR.$type.Assembly);
                    $.$mel.System.SR.s_resourceManager = temp;
                }
                return $.$mel.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(111671312473)
            
            //--TRIMMABLE-BOUNDARY-START(8592097369)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836737625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mel.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851181657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8592097369)
            
            //--TRIMMABLE-BOUNDARY-START(98786410585)
            static /*string */ get InvalidActivityTrackingOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426672217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} is invalid ActivityTrackingOptions value.";
            }
            //--TRIMMABLE-BOUNDARY-END(98786410585)
            
            //--TRIMMABLE-BOUNDARY-START(47246803033)
            static /*string */ FormatInvalidActivityTrackingOptions(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246803033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("{0} is invalid ActivityTrackingOptions value.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(47246803033)
            
            //--TRIMMABLE-BOUNDARY-START(103081377881)
            static /*string */ get MoreThanOneWildcard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016606809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only one wildcard character is allowed in category name.";
            }
            //--TRIMMABLE-BOUNDARY-END(103081377881)
            
            //--TRIMMABLE-BOUNDARY-START(120261247065)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(120261247065)
            
            //--TRIMMABLE-BOUNDARY-START(94491443289)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94491443289);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491443289)
            
            //--TRIMMABLE-BOUNDARY-START(133146148953)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146148953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146148953)
            
            //--TRIMMABLE-BOUNDARY-START(85901508697)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901508697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mel.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(85901508697)
            
            //--TRIMMABLE-BOUNDARY-START(90196475993)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196475993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mel.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(90196475993)
            
            //--TRIMMABLE-BOUNDARY-START(12887064665)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887064665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(12887064665)
            
            //--TRIMMABLE-BOUNDARY-START(17182031961)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182031961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17182031961)
            
            //--TRIMMABLE-BOUNDARY-START(21476999257)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476999257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(21476999257)
            
            //--TRIMMABLE-BOUNDARY-START(25771966553)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771966553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mel.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25771966553)
            
            //--TRIMMABLE-BOUNDARY-START(30066933849)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(30066933849)
            
            //--TRIMMABLE-BOUNDARY-START(34361901145)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34361901145)
            
            //--TRIMMABLE-BOUNDARY-START(38656868441)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656868441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(38656868441)
            
            //--TRIMMABLE-BOUNDARY-START(42951835737)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951835737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mel.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42951835737)
            
            //--TRIMMABLE-BOUNDARY-START(4297130073)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(120261247065)
                    this.s_usingResourceKeys = $.$mel.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(120261247065)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297130073)
            
            static $h = 2162777;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 2162777
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162777)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572953)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerRuleSelector", ($self) => class LoggerRuleSelector
        {
            //--TRIMMABLE-BOUNDARY-START(8591507545)
            static /*void */ Select(/*LoggerFilterOptions*/ options, /*Type*/ providerType, /*string*/ category, /*out LogLevel?*/ minLevel, /*out Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                filter.$v = null;
                minLevel.$v = options.MinLevel;
                /*string?*/ let providerAlias = $.$mel.Microsoft.Extensions.Logging.ProviderAliasUtilities.GetAlias(providerType);
                /*LoggerFilterRule?*/ let current = null;
                var $en2 = options.RulesInternal.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var rule = $en2.Current;
                    {
                        if ($.$mel.Microsoft.Extensions.Logging.LoggerRuleSelector.IsBetter(rule, current, providerType.FullName, category) || (!$.$$.System.String.IsNullOrEmpty(providerAlias) && $.$mel.Microsoft.Extensions.Logging.LoggerRuleSelector.IsBetter(rule, current, providerAlias, category)))
                        {
                            current = rule;
                        }
                    }
                }
                if (current !== null)
                {
                    filter.$v = current.Filter;
                    minLevel.$v = current.LogLevel;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591507545)
            
            //--TRIMMABLE-BOUNDARY-START(4296540249)
            static /*bool */ IsBetter(/*LoggerFilterRule*/ rule, /*LoggerFilterRule?*/ current, /*string?*/ logger, /*string*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(rule.ProviderName, null) && $.$$.System.String.op_Inequality(rule.ProviderName, logger))
                {
                    return false;
                }
                /*string?*/ let categoryName = rule.CategoryName;
                if ($.$$.System.String.op_Inequality(categoryName, null))
                {
                    /*char*/ let WildcardChar = /***/ 42;
                    /*int*/ let wildcardIndex = $.$$.System.String.IndexOf$3.call(categoryName, WildcardChar);
                    if (wildcardIndex !== -1 && $.$$.System.String.IndexOf$1.call(categoryName, WildcardChar, ((wildcardIndex + 1) | 0)) !== -1)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mel.System.SR.MoreThanOneWildcard);
                    }
                    /*ReadOnlySpan<char>*/ let prefix, suffix;
                    if (wildcardIndex === -1)
                    {
                        prefix = $.$$.System.MemoryExtensions.AsSpan$4(categoryName);
                        suffix = new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))();
                    }
                    else 
                    {
                        prefix = $.$$.System.MemoryExtensions.AsSpan$1(categoryName, 0, wildcardIndex);
                        suffix = $.$$.System.MemoryExtensions.AsSpan$2(categoryName, ((wildcardIndex + 1) | 0));
                    }
                    if (!$.$$.System.MemoryExtensions.StartsWith($.$$.System.MemoryExtensions.AsSpan$4(category), prefix, 5/*StringComparison.OrdinalIgnoreCase*/) || !$.$$.System.MemoryExtensions.EndsWith($.$$.System.MemoryExtensions.AsSpan$4(category), suffix, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return false;
                    }
                }
                if ($.$$.System.String.op_Inequality((current?.ProviderName ?? null), null))
                {
                    if ($.$$.System.String.op_Equality(rule.ProviderName, null))
                    {
                        return false;
                    }
                }
                else 
                {
                    if ($.$$.System.String.op_Inequality(rule.ProviderName, null))
                    {
                        return true;
                    }
                }
                if ($.$$.System.String.op_Inequality((current?.CategoryName ?? null), null))
                {
                    if ($.$$.System.String.op_Equality(rule.CategoryName, null))
                    {
                        return false;
                    }
                    if (current.CategoryName.length > rule.CategoryName.length)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540249)
            
            static $h = 1572953;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591507545),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": 1376345
        },
        {
          "n": "providerType",
          "p": 187629569
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "minLevel",
          "p": $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,
          "f": 2
        },
        {
          "n": "filter",
          "p": $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h,
          "f": 2
        }
      ],
      "n": "Select",
      "d": 1572953,
      "h": 8591507545,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591507545),
//--TRIMMABLE-BOUNDARY-START(4296540249),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": 1441881
        },
        {
          "n": "current",
          "p": 1441881
        },
        {
          "n": "logger",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "IsBetter",
      "d": 1572953,
      "h": 4296540249,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4296540249)
  ],
  "h": 1572953
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerRuleSelector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572953)
        
        
        //--TRIMMABLE-BOUNDARY-START(262233)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.DebuggerDisplayFormatting", ($self) => class DebuggerDisplayFormatting
        {
            //--TRIMMABLE-BOUNDARY-START(8590196825)
            static /*string */ DebuggerToString(/*string*/ name, /*ILogger*/ logger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogLevel?*/ let minimumLevel = $.$mel.Microsoft.Extensions.Logging.DebuggerDisplayFormatting.CalculateEnabledLogLevel(logger);
                /*var*/ let debugText = `Name = \"${name}\"`;
                if (minimumLevel !== null)
                {
                    debugText += `, MinLevel = ${minimumLevel}`;
                }
                else 
                {
                    debugText += `, Enabled = false`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196825)
            
            //--TRIMMABLE-BOUNDARY-START(4295229529)
            static /*LogLevel? */ CalculateEnabledLogLevel(/*ILogger*/ logger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<LogLevel>*/ let logLevels = new ($.$$.System.ReadOnlySpan$$($.$mela.Microsoft.Extensions.Logging.LogLevel))().$ctor$4([ 5/*LogLevel.Critical*/, 4/*LogLevel.Error*/, 3/*LogLevel.Warning*/, 2/*LogLevel.Information*/, 1/*LogLevel.Debug*/, 0/*LogLevel.Trace*/ ]);
                /*LogLevel?*/ let minimumLevel = null;
                var $en2 = logLevels.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var logLevel = $en2.Current.$v;
                    {
                        if (!logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                        {
                            break;
                        }
                        minimumLevel = logLevel;
                    }
                }
                return minimumLevel;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229529)
            
            static $h = 262233;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590196825),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": "DebuggerToString",
      "d": 262233,
      "h": 8590196825,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590196825),
//--TRIMMABLE-BOUNDARY-START(4295229529),
    {
      "r": $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,
      "p": [
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": "CalculateEnabledLogLevel",
      "d": 262233,
      "h": 4295229529,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295229529)
  ],
  "h": 262233
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.DebuggerDisplayFormatting`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262233)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441881)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFilterRule", ($self) => class LoggerFilterRule extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296409177)
            $ctor$1(/*string?*/ providerName, /*string?*/ categoryName, /*LogLevel?*/ logLevel, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296409177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ProviderName = providerName;
                    this.CategoryName = categoryName;
                    this.LogLevel = logLevel;
                    this.Filter = filter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409177)
            
            //--TRIMMABLE-BOUNDARY-START(73015885913)
            /*string?*/ ProviderName = null;
            //--TRIMMABLE-BOUNDARY-END(73015885913)
            
            //--TRIMMABLE-BOUNDARY-START(25771245657)
            /*string?*/ CategoryName = null;
            //--TRIMMABLE-BOUNDARY-END(25771245657)
            
            //--TRIMMABLE-BOUNDARY-START(68720918617)
            /*LogLevel?*/ LogLevel = null;
            //--TRIMMABLE-BOUNDARY-END(68720918617)
            
            //--TRIMMABLE-BOUNDARY-START(30066212953)
            /*Func<string?, string?, LogLevel, bool>?*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(30066212953)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 77310853209, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${"ProviderName"}: '${this.ProviderName}', ${"CategoryName"}: '${this.CategoryName}', ${"LogLevel"}: '${this.LogLevel}', ${"Filter"}: '${$.$$.System.Object.ToString.call(this.Filter)}'`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mel.Microsoft.Extensions.Logging.LoggerFilterRule.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 77310853209, 330712612865)
            
            static $h = 1441881;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015885913),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425951321,
        "f": 50331649
      },
      "n": "ProviderName",
      "d": 1441881,
      "h": 73015885913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015885913),
//--TRIMMABLE-BOUNDARY-START(25771245657),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656147545,
        "f": 50331649
      },
      "n": "CategoryName",
      "d": 1441881,
      "h": 25771245657,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771245657),
//--TRIMMABLE-BOUNDARY-START(68720918617),
    {
      "p": $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836016729,
        "f": 50331649
      },
      "n": "LogLevel",
      "d": 1441881,
      "h": 68720918617,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720918617),
//--TRIMMABLE-BOUNDARY-START(30066212953),
    {
      "p": $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246082137,
        "f": 50331649
      },
      "n": "Filter",
      "d": 1441881,
      "h": 30066212953,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066212953)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 77310853209, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1441881,
      "h": 77310853209,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 77310853209, 330712612865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409177),
    {
      "p": [
        {
          "n": "providerName",
          "p": 1310721
        },
        {
          "n": "categoryName",
          "p": 1310721
        },
        {
          "n": "logLevel",
          "p": $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h
        },
        {
          "n": "filter",
          "p": $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441881,
      "h": 4296409177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409177)
  ],
  "h": 1441881
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFilterRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441881)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376345)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFilterOptions", ($self) => class LoggerFilterOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296343641)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296343641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343641)
            
            //--TRIMMABLE-BOUNDARY-START(21476212825)
            /*bool*/ CaptureScopes = false;
            //--TRIMMABLE-BOUNDARY-END(21476212825)
            
            //--TRIMMABLE-BOUNDARY-START(64425885785)
            /*LogLevel*/ MinLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(64425885785)
            
            //--TRIMMABLE-BOUNDARY-START(68720853081)
            /*IList<LoggerFilterRule> */ get Rules()
            {
                return this.RulesInternal;
            }
            //--TRIMMABLE-BOUNDARY-END(68720853081)
            
            //--TRIMMABLE-BOUNDARY-START(73015820377)
            /*List<LoggerFilterRule>*/ RulesInternal = null;
            //--TRIMMABLE-BOUNDARY-END(73015820377)
            
            //--TRIMMABLE-BOUNDARY-START(25771180121)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let debugText;
                if (this.MinLevel !== 6/*LogLevel.None*/)
                {
                    debugText = `MinLevel = ${this.MinLevel}`;
                }
                else 
                {
                    debugText = `Enabled = false`;
                }
                if (this.Rules.System$Collections$Generic$ICollection$$$Count > 0)
                {
                    debugText += `, Rules = ${this.Rules.System$Collections$Generic$ICollection$$$Count}`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(25771180121)
            
            //default member initializer
            constructor()
            {
                super();
                this.CaptureScopes = true;
                this.RulesInternal = new ($.$$.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterRule))().$ctor$1();
            }
            static $h = 1376345;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476212825),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361114713,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605754969,
        "f": 83886081
      },
      "n": "CaptureScopes",
      "d": 1376345,
      "h": 21476212825,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476212825),
//--TRIMMABLE-BOUNDARY-START(64425885785),
    {
      "p": 2293848,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951049305,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195689561,
        "f": 83886081
      },
      "n": "MinLevel",
      "d": 1376345,
      "h": 64425885785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425885785),
//--TRIMMABLE-BOUNDARY-START(68720853081),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterRule).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540983897,
        "f": 50331649
      },
      "n": "Rules",
      "d": 1376345,
      "h": 68720853081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720853081),
//--TRIMMABLE-BOUNDARY-START(73015820377),
    {
      "p": $.$$.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterRule).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130918489,
        "f": 50331656
      },
      "n": "RulesInternal",
      "d": 1376345,
      "h": 73015820377,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(73015820377)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771180121),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 1376345,
      "h": 25771180121,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25771180121)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343641),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376345,
      "h": 4296343641,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343641)
  ],
  "h": 1376345,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFilterOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376345)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704025)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggingBuilderExtensions", ($self) => class LoggingBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(17181573209)
            static /*ILoggingBuilder */ SetMinimumLevel(/*this ILoggingBuilder*/ builder, /*LogLevel*/ level)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181573209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services.System$Collections$Generic$ICollection$$$Add($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$6($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions), new $.$mel.Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions().$ctor$2(level)), [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(17181573209)
            
            //--TRIMMABLE-BOUNDARY-START(4296671321)
            static /*ILoggingBuilder */ AddProvider(/*this ILoggingBuilder*/ builder, /*ILoggerProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296671321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$mela.Microsoft.Extensions.Logging.ILoggerProvider, builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services, provider);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671321)
            
            //--TRIMMABLE-BOUNDARY-START(8591638617)
            static /*ILoggingBuilder */ ClearProviders(/*this ILoggingBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591638617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.RemoveAll$1($.$mela.Microsoft.Extensions.Logging.ILoggerProvider, builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(8591638617)
            
            //--TRIMMABLE-BOUNDARY-START(12886605913)
            static /*ILoggingBuilder */ Configure(/*this ILoggingBuilder*/ builder, /*Action<LoggerFactoryOptions>*/ action)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886605913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions, builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services, action);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(12886605913)
            
            static $h = 1704025;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181573209),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": "SetMinimumLevel",
      "d": 1704025,
      "h": 17181573209,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181573209),
//--TRIMMABLE-BOUNDARY-START(4296671321),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "provider",
          "p": 1114200
        }
      ],
      "n": "AddProvider",
      "d": 1704025,
      "h": 4296671321,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296671321),
//--TRIMMABLE-BOUNDARY-START(8591638617),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        }
      ],
      "n": "ClearProviders",
      "d": 1704025,
      "h": 8591638617,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591638617),
//--TRIMMABLE-BOUNDARY-START(12886605913),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions).$h
        }
      ],
      "n": "Configure",
      "d": 1704025,
      "h": 12886605913,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886605913)
  ],
  "h": 1704025
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggingBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704025)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966169)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.ProviderAliasUtilities", ($self) => class ProviderAliasUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(4296933465)
            /*string*/ static AliasAttributeTypeFullName = null;
            //--TRIMMABLE-BOUNDARY-END(4296933465)
            
            //--TRIMMABLE-BOUNDARY-START(8591900761)
            static /*string? */ GetAlias(/*Type*/ providerType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IList<CustomAttributeData>*/ let attributes = $.$$.System.Reflection.CustomAttributeData.GetCustomAttributes$1(providerType);
                for(/*int*/ let i = 0; i < attributes.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*CustomAttributeData*/ let attributeData = attributes.System$Collections$Generic$IList$$$get_Item(i, [$.$$.System.Reflection.CustomAttributeData]);
                    if ($.$$.System.String.op_Equality(attributeData.AttributeType.FullName, "Microsoft.Extensions.Logging.ProviderAliasAttribute"/*AliasAttributeTypeFullName*/) && attributeData.ConstructorArguments.System$Collections$Generic$ICollection$$$Count > 0)
                    {
                        /*CustomAttributeTypedArgument*/ let arg = attributeData.ConstructorArguments.System$Collections$Generic$IList$$$get_Item(0, [$.$$.System.Reflection.CustomAttributeTypedArgument]);
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(arg.ArgumentType, $.$$.System.String.$type), "arg.ArgumentType == typeof(string)");
                        const $t1 = () => arg.Value;
                        return $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t));
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8591900761)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4296933465)
                    this.AliasAttributeTypeFullName = "Microsoft.Extensions.Logging.ProviderAliasAttribute";
                    //--TRIMMABLE-BOUNDARY-END(4296933465)
                    
                }
            }
            static $h = 1966169;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591900761),
    {
      "r": 1310721,
      "p": [
        {
          "n": "providerType",
          "p": 187629569
        }
      ],
      "n": "GetAlias",
      "d": 1966169,
      "h": 8591900761,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591900761)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296933465),
    {
      "t": 1310721,
      "n": "AliasAttributeTypeFullName",
      "d": 1966169,
      "h": 4296933465,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296933465)
  ],
  "h": 1966169
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ProviderAliasUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966169)
        
        
        //--TRIMMABLE-BOUNDARY-START(65625)
        $asm.$cls("$mel.Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions", ($self) => class LoggingServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295032921)
            static /*IServiceCollection */ AddLogging$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mel.Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions.AddLogging(services, new ($.$$.System.Action$$($.$mela.Microsoft.Extensions.Logging.ILoggingBuilder))().$ctor(this,  (/*builder*/ builder) =>
                {
                }, {
  "r": 65537,
  "p": [
    {
      "n": "builder",
      "p": 1179736
    }
  ],
  "n": "",
  "d": 65625,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295032921)
            
            //--TRIMMABLE-BOUNDARY-START(8590000217)
            static /*IServiceCollection */ AddLogging(/*this IServiceCollection*/ services, /*Action<ILoggingBuilder>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$3($.$mela.Microsoft.Extensions.Logging.ILoggerFactory, $.$mel.Microsoft.Extensions.Logging.LoggerFactory));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2($.$mela.Microsoft.Extensions.Logging.ILogger$$().$type, $.$mela.Microsoft.Extensions.Logging.Logger$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$6($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions), new $.$mel.Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions().$ctor$2(2/*LogLevel.Information*/)));
                configure.Invoke(new $.$mel.Microsoft.Extensions.Logging.LoggingBuilder().$ctor$1(services));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000217)
            
            static $h = 65625;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032921),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddLogging",
      "o": "@$1",
      "d": 65625,
      "h": 4295032921,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032921),
//--TRIMMABLE-BOUNDARY-START(8590000217),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configure",
          "p": $.$$.System.Action$$($.$mela.Microsoft.Extensions.Logging.ILoggingBuilder).$h
        }
      ],
      "n": "AddLogging",
      "d": 65625,
      "h": 8590000217,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000217)
  ],
  "h": 65625
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65625)
        
        
        //--TRIMMABLE-BOUNDARY-START(393305)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions", ($self) => class FilterLoggingBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295360601)
            static /*ILoggingBuilder */ AddFilter$5(/*this ILoggingBuilder*/ builder, /*Func<string?, string?, LogLevel, bool>*/ filter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/**/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter(options, filter);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360601)
            
            //--TRIMMABLE-BOUNDARY-START(8590327897)
            static /*ILoggingBuilder */ AddFilter$6(/*this ILoggingBuilder*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/**/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$1(options, categoryLevelFilter);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590327897)
            
            //--TRIMMABLE-BOUNDARY-START(12885295193)
            static /*ILoggingBuilder */ AddFilter$14(T, /*this ILoggingBuilder*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/**/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$10(T, options, categoryLevelFilter);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885295193)
            
            //--TRIMMABLE-BOUNDARY-START(17180262489)
            static /*ILoggingBuilder */ AddFilter$7(/*this ILoggingBuilder*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$2(options, levelFilter);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262489)
            
            //--TRIMMABLE-BOUNDARY-START(21475229785)
            static /*ILoggingBuilder */ AddFilter$15(T, /*this ILoggingBuilder*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$11(T, options, levelFilter);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475229785)
            
            //--TRIMMABLE-BOUNDARY-START(25770197081)
            static /*ILoggingBuilder */ AddFilter$9(/*this ILoggingBuilder*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$4(options, category, level);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770197081)
            
            //--TRIMMABLE-BOUNDARY-START(30065164377)
            static /*ILoggingBuilder */ AddFilter$17(T, /*this ILoggingBuilder*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065164377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$13(T, options, category, level);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164377)
            
            //--TRIMMABLE-BOUNDARY-START(34360131673)
            static /*ILoggingBuilder */ AddFilter$8(/*this ILoggingBuilder*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360131673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$3(options, category, levelFilter);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360131673)
            
            //--TRIMMABLE-BOUNDARY-START(38655098969)
            static /*ILoggingBuilder */ AddFilter$16(T, /*this ILoggingBuilder*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655098969);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$12(T, options, category, levelFilter);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655098969)
            
            //--TRIMMABLE-BOUNDARY-START(42950066265)
            static /*LoggerFilterOptions */ AddFilter(/*this LoggerFilterOptions*/ builder, /*Func<string?, string?, LogLevel, bool>*/ filter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950066265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, filter);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950066265)
            
            //--TRIMMABLE-BOUNDARY-START(47245033561)
            static /*LoggerFilterOptions */ AddFilter$1(/*this LoggerFilterOptions*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245033561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, new ($.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return categoryLevelFilter.Invoke(name, level);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "type",
      "p": 1310721
    },
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "level",
      "p": 2293848
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245033561)
            
            //--TRIMMABLE-BOUNDARY-START(51540000857)
            static /*LoggerFilterOptions */ AddFilter$10(T, /*this LoggerFilterOptions*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540000857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, null, null, new ($.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return categoryLevelFilter.Invoke(name, level);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "type",
      "p": 1310721
    },
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "level",
      "p": 2293848
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540000857)
            
            //--TRIMMABLE-BOUNDARY-START(55834968153)
            static /*LoggerFilterOptions */ AddFilter$2(/*this LoggerFilterOptions*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834968153);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, new ($.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return levelFilter.Invoke(level);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "type",
      "p": 1310721
    },
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "level",
      "p": 2293848
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834968153)
            
            //--TRIMMABLE-BOUNDARY-START(60129935449)
            static /*LoggerFilterOptions */ AddFilter$11(T, /*this LoggerFilterOptions*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129935449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, null, null, new ($.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return levelFilter.Invoke(level);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "type",
      "p": 1310721
    },
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "level",
      "p": 2293848
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129935449)
            
            //--TRIMMABLE-BOUNDARY-START(64424902745)
            static /*LoggerFilterOptions */ AddFilter$4(/*this LoggerFilterOptions*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424902745);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, category, level, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424902745)
            
            //--TRIMMABLE-BOUNDARY-START(68719870041)
            static /*LoggerFilterOptions */ AddFilter$13(T, /*this LoggerFilterOptions*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719870041);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, category, level, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719870041)
            
            //--TRIMMABLE-BOUNDARY-START(73014837337)
            static /*LoggerFilterOptions */ AddFilter$3(/*this LoggerFilterOptions*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014837337);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, category, null, new ($.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return levelFilter.Invoke(level);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "type",
      "p": 1310721
    },
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "level",
      "p": 2293848
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014837337)
            
            //--TRIMMABLE-BOUNDARY-START(77309804633)
            static /*LoggerFilterOptions */ AddFilter$12(T, /*this LoggerFilterOptions*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309804633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, category, null, new ($.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return levelFilter.Invoke(level);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "type",
      "p": 1310721
    },
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "level",
      "p": 2293848
    }
  ],
  "n": "",
  "d": 393305,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309804633)
            
            //--TRIMMABLE-BOUNDARY-START(85899739225)
            static /*ILoggingBuilder */ ConfigureFilter(/*this ILoggingBuilder*/ builder, /*Action<LoggerFilterOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899739225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions, builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services, configureOptions);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(85899739225)
            
            //--TRIMMABLE-BOUNDARY-START(81604771929)
            static /*LoggerFilterOptions */ AddRule(/*LoggerFilterOptions*/ options, /*string?*/ type, /*string?*/ category, /*LogLevel?*/ level, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.Rules.System$Collections$Generic$ICollection$$$Add(new $.$mel.Microsoft.Extensions.Logging.LoggerFilterRule().$ctor$1(type, category, level, filter), [$.$mel.Microsoft.Extensions.Logging.LoggerFilterRule]);
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(81604771929)
            
            static $h = 393305;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360601),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "filter",
          "p": $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$5",
      "d": 393305,
      "h": 4295360601,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295360601),
//--TRIMMABLE-BOUNDARY-START(8590327897),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "categoryLevelFilter",
          "p": $.$$.System.Func$$$$($.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$6",
      "d": 393305,
      "h": 8590327897,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327897),
//--TRIMMABLE-BOUNDARY-START(12885295193),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "categoryLevelFilter",
          "p": $.$$.System.Func$$$$($.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$14",
      "d": 393305,
      "h": 12885295193,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885295193),
//--TRIMMABLE-BOUNDARY-START(17180262489),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "levelFilter",
          "p": $.$$.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$7",
      "d": 393305,
      "h": 17180262489,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180262489),
//--TRIMMABLE-BOUNDARY-START(21475229785),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "levelFilter",
          "p": $.$$.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$15",
      "d": 393305,
      "h": 21475229785,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21475229785),
//--TRIMMABLE-BOUNDARY-START(25770197081),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": "AddFilter",
      "o": "@$9",
      "d": 393305,
      "h": 25770197081,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770197081),
//--TRIMMABLE-BOUNDARY-START(30065164377),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$17",
      "d": 393305,
      "h": 30065164377,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30065164377),
//--TRIMMABLE-BOUNDARY-START(34360131673),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "levelFilter",
          "p": $.$$.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$8",
      "d": 393305,
      "h": 34360131673,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360131673),
//--TRIMMABLE-BOUNDARY-START(38655098969),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "levelFilter",
          "p": $.$$.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$16",
      "d": 393305,
      "h": 38655098969,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38655098969),
//--TRIMMABLE-BOUNDARY-START(42950066265),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "filter",
          "p": $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "d": 393305,
      "h": 42950066265,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950066265),
//--TRIMMABLE-BOUNDARY-START(47245033561),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "categoryLevelFilter",
          "p": $.$$.System.Func$$$$($.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$1",
      "d": 393305,
      "h": 47245033561,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245033561),
//--TRIMMABLE-BOUNDARY-START(51540000857),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "categoryLevelFilter",
          "p": $.$$.System.Func$$$$($.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$10",
      "d": 393305,
      "h": 51540000857,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(51540000857),
//--TRIMMABLE-BOUNDARY-START(55834968153),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "levelFilter",
          "p": $.$$.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$2",
      "d": 393305,
      "h": 55834968153,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834968153),
//--TRIMMABLE-BOUNDARY-START(60129935449),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "levelFilter",
          "p": $.$$.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$11",
      "d": 393305,
      "h": 60129935449,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60129935449),
//--TRIMMABLE-BOUNDARY-START(64424902745),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": "AddFilter",
      "o": "@$4",
      "d": 393305,
      "h": 64424902745,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424902745),
//--TRIMMABLE-BOUNDARY-START(68719870041),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$13",
      "d": 393305,
      "h": 68719870041,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(68719870041),
//--TRIMMABLE-BOUNDARY-START(73014837337),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "levelFilter",
          "p": $.$$.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$3",
      "d": 393305,
      "h": 73014837337,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014837337),
//--TRIMMABLE-BOUNDARY-START(77309804633),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "levelFilter",
          "p": $.$$.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$12",
      "d": 393305,
      "h": 77309804633,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77309804633),
//--TRIMMABLE-BOUNDARY-START(85899739225),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "configureOptions",
          "p": $.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h
        }
      ],
      "n": "ConfigureFilter",
      "d": 393305,
      "h": 85899739225,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899739225),
//--TRIMMABLE-BOUNDARY-START(81604771929),
    {
      "r": 1376345,
      "p": [
        {
          "n": "options",
          "p": 1376345
        },
        {
          "n": "type",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "category",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "level",
          "p": $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,
          "f": 65
        },
        {
          "n": "filter",
          "p": $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h,
          "f": 65
        }
      ],
      "n": "AddRule",
      "d": 393305,
      "h": 81604771929,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604771929)
  ],
  "h": 393305
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393305)
        
        
        //--TRIMMABLE-BOUNDARY-START(131161)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.ActivityExtensions", ($self) => class ActivityExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590065753)
            static /*string */ GetSpanId(/*this Activity*/ activity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    let $switch1 = activity.IdFormat;
                    if ($switch1 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.Id;
                    }
                    if ($switch1 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.SpanId.ToHexString();
                    }
                    return null;
                })() ?? $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065753)
            
            //--TRIMMABLE-BOUNDARY-START(12885033049)
            static /*string */ GetTraceId(/*this Activity*/ activity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    let $switch1 = activity.IdFormat;
                    if ($switch1 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.RootId;
                    }
                    if ($switch1 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.TraceId.ToHexString();
                    }
                    return null;
                })() ?? $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033049)
            
            //--TRIMMABLE-BOUNDARY-START(4295098457)
            static /*string */ GetParentId(/*this Activity*/ activity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    let $switch1 = activity.IdFormat;
                    if ($switch1 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.ParentId;
                    }
                    if ($switch1 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.ParentSpanId.ToHexString();
                    }
                    return null;
                })() ?? $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098457)
            
            static $h = 131161;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590065753),
    {
      "r": 1310721,
      "p": [
        {
          "n": "activity",
          "p": 196654
        }
      ],
      "n": "GetSpanId",
      "d": 131161,
      "h": 8590065753,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065753),
//--TRIMMABLE-BOUNDARY-START(12885033049),
    {
      "r": 1310721,
      "p": [
        {
          "n": "activity",
          "p": 196654
        }
      ],
      "n": "GetTraceId",
      "d": 131161,
      "h": 12885033049,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885033049),
//--TRIMMABLE-BOUNDARY-START(4295098457),
    {
      "r": 1310721,
      "p": [
        {
          "n": "activity",
          "p": 196654
        }
      ],
      "n": "GetParentId",
      "d": 131161,
      "h": 4295098457,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098457)
  ],
  "h": 131161
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ActivityExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131161)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835097)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.NullExternalScopeProvider", ($self) => class NullExternalScopeProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591769689)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591769689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591769689)
            
            //--TRIMMABLE-BOUNDARY-START(25771638873)
            /*IExternalScopeProvider*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(25771638873)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30066606169, 4295819352)
            /*void */ Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066606169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30066606169, 4295819352)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34361573465, 8590786648)
            /*IDisposable */ Microsoft$Extensions$Logging$IExternalScopeProvider$Push(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361573465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mel.Microsoft.Extensions.Logging.NullScope.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34361573465, 8590786648)
            
            //--TRIMMABLE-BOUNDARY-START(4296802393)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mel.Microsoft.Extensions.Logging.NullExternalScopeProvider().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296802393)
            
            static $h = 1835097;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771638873),
    {
      "p": 852056,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476671577,
        "f": 50331681
      },
      "n": "Instance",
      "d": 1835097,
      "h": 25771638873,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25771638873)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591769689),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1835097,
      "h": 8591769689,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8591769689)
  ],
  "i": [852056
  ],
  "h": 1835097
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.IExternalScopeProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.NullExternalScopeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835097)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638489)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggingBuilder", ($self) => class LoggingBuilder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296605785)
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296605785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Services = services;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605785)
            
            //--TRIMMABLE-BOUNDARY-START(21476474969)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(21476474969)
            
            //--TRIMMABLE-BOUNDARY-START(8591114328)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggingBuilder.Services.get
            get Microsoft$Extensions$Logging$ILoggingBuilder$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114328)
            
            static $h = 1638489;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476474969),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181507673,
        "f": 50331649
      },
      "n": "Services",
      "d": 1638489,
      "h": 21476474969,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476474969)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605785),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1638489,
      "h": 4296605785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605785)
  ],
  "i": [1179736
  ],
  "h": 1638489
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggingBuilder ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggingBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638489)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900633)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.NullScope", ($self) => class NullScope extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066671705)
            /*NullScope*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30066671705)
            
            //--TRIMMABLE-BOUNDARY-START(8591835225)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591835225);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591835225)
            
            //--TRIMMABLE-BOUNDARY-START(17181769817)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17181769817)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //--TRIMMABLE-BOUNDARY-START(4296867929)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mel.Microsoft.Extensions.Logging.NullScope().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296867929)
            
            static $h = 1900633;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066671705),
    {
      "p": 1900633,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771704409,
        "f": 50331681
      },
      "n": "Instance",
      "d": 1900633,
      "h": 30066671705,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30066671705)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181769817),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1900633,
      "h": 17181769817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591835225),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900633,
      "h": 8591835225,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8591835225)
  ],
  "i": [90177537
  ],
  "h": 1900633
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.NullScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900633)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048665)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider", ($self) => class LoggerFactoryScopeProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590983257)
            /*AsyncLocal<Scope?>*/ _currentScope = null;
            //--TRIMMABLE-BOUNDARY-END(8590983257)
            
            //--TRIMMABLE-BOUNDARY-START(4296015961)
            /*ActivityTrackingOptions*/ _activityTrackingOption = 0;
            //--TRIMMABLE-BOUNDARY-END(4296015961)
            
            //--TRIMMABLE-BOUNDARY-START(12885950553)
            $ctor$1(/*ActivityTrackingOptions*/ activityTrackingOption)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885950553);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._activityTrackingOption = activityTrackingOption;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885950553)
            
            //--TRIMMABLE-BOUNDARY-START(25770852441)
            /*void */ ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770852441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*void*/  function Report(/*Scope?*/ current)
                {
                    if (current === null)
                    {
                        return;
                    }
                    Report.call(this, current.Parent);
                    callback.Invoke(current.State, state);
                }
                if (this._activityTrackingOption !== 0/*ActivityTrackingOptions.None*/)
                {
                    /*Activity?*/ let activity = $.$sdd.System.Diagnostics.Activity.Current;
                    if (activity !== null)
                    {
                        /*string*/ let propertyKey = "__ActivityLogScope__";
                        /*ActivityLogScope?*/ let activityLogScope = $.$as(activity.GetCustomProperty(propertyKey), $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope);
                        if (activityLogScope === null)
                        {
                            activityLogScope = new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope().$ctor$1(activity, this._activityTrackingOption);
                            activity.SetCustomProperty(propertyKey, activityLogScope);
                        }
                        callback.Invoke(activityLogScope, state);
                        if ((this._activityTrackingOption & 32/*ActivityTrackingOptions.Tags*/) !== 0 && activity.TagObjects.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)]).System$Collections$IEnumerator$MoveNext())
                        {
                            callback.Invoke(activity.TagObjects, state);
                        }
                        if ((this._activityTrackingOption & 64/*ActivityTrackingOptions.Baggage*/) !== 0)
                        {
                            /*IEnumerable<KeyValuePair<string, string?>>*/ let baggage = activity.Baggage;
                            if (baggage.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)]).System$Collections$IEnumerator$MoveNext())
                            {
                                /*ActivityBaggageLogScopeWrapper*/ let scope = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.GetOrCreateActivityBaggageLogScopeWrapper(activity, baggage);
                                callback.Invoke(scope, state);
                            }
                        }
                    }
                }
                Report.call(this, this._currentScope.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(25770852441)
            
            //--TRIMMABLE-BOUNDARY-START(30065819737)
            static /*ActivityBaggageLogScopeWrapper */ GetOrCreateActivityBaggageLogScopeWrapper(/*Activity*/ activity, /*IEnumerable<KeyValuePair<string, string?>>*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065819737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let additionalItemsBaggagePropertyKey = "__ActivityBaggageItemsLogScope__";
                /*var*/ let activityBaggageLogScopeWrapper = $.$as(activity.GetCustomProperty(additionalItemsBaggagePropertyKey), $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper);
                if (activityBaggageLogScopeWrapper === null)
                {
                    activityBaggageLogScopeWrapper = new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper().$ctor$1(items);
                    activity.SetCustomProperty(additionalItemsBaggagePropertyKey, activityBaggageLogScopeWrapper);
                }
                return activityBaggageLogScopeWrapper;
            }
            //--TRIMMABLE-BOUNDARY-END(30065819737)
            
            //--TRIMMABLE-BOUNDARY-START(34360787033)
            /*IDisposable */ Push(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360787033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Scope?*/ let parent = this._currentScope.Value;
                /*var*/ let newScope = new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope().$ctor$1(this, state, parent);
                this._currentScope.Value = newScope;
                return newScope;
            }
            //--TRIMMABLE-BOUNDARY-END(34360787033)
            
            //--TRIMMABLE-BOUNDARY-START(1310809)
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider;
                return $cls.$_Scope ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope", ($self) => class Scope extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591245401)
                    /*LoggerFactoryScopeProvider*/ _provider = null;
                    //--TRIMMABLE-BOUNDARY-END(8591245401)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278105)
                    /*bool*/ _isDisposed = false;
                    //--TRIMMABLE-BOUNDARY-END(4296278105)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886212697)
                    $ctor$1(/*LoggerFactoryScopeProvider*/ provider, /*object?*/ state, /*Scope?*/ parent)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886212697);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._provider = provider;
                            this.State = state;
                            this.Parent = parent;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886212697)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245951065)
                    /*Scope?*/ Parent = null;
                    //--TRIMMABLE-BOUNDARY-END(47245951065)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540918361)
                    /*object?*/ State = null;
                    //--TRIMMABLE-BOUNDARY-END(51540918361)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 55835885657, 330712612865)
                    static/*conventional*/ /*string? */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835885657);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        const $t1 = this.State;
                        return $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t));
                    }
                    //Static convention instance redirect
                    /*string? */ ToString() { return $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 55835885657, 330712612865)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771114585)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771114585);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._isDisposed)
                        {
                            this._provider._currentScope.Value = this.Parent;
                            this._isDisposed = true;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771114585)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    static $h = 1310809;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245951065),
    {
      "p": 1310809,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361049177,
        "f": 50331649
      },
      "n": "Parent",
      "d": 1310809,
      "h": 47245951065,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245951065),
//--TRIMMABLE-BOUNDARY-START(51540918361),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950983769,
        "f": 50331649
      },
      "n": "State",
      "d": 1310809,
      "h": 51540918361,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540918361)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 55835885657, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1310809,
      "h": 55835885657,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55835885657, 330712612865),
//--TRIMMABLE-BOUNDARY-START(25771114585),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1310809,
      "h": 25771114585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771114585)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591245401),
    {
      "t": 1048665,
      "n": "_provider",
      "d": 1310809,
      "h": 8591245401,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245401),
//--TRIMMABLE-BOUNDARY-START(4296278105),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 1310809,
      "h": 4296278105,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278105)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886212697),
    {
      "p": [
        {
          "n": "provider",
          "p": 1048665
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "parent",
          "p": 1310809
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310809,
      "h": 12886212697,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886212697)
  ],
  "i": [90177537
  ],
  "d": 1048665,
  "h": 1310809
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1310809)
            
            //--TRIMMABLE-BOUNDARY-START(1245273)
            static $_ActivityLogScope;
            static get ActivityLogScope()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider;
                return $cls.$_ActivityLogScope ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope", ($self) => class ActivityLogScope extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296212569)
                    /*string?*/ _cachedToString = null;
                    //--TRIMMABLE-BOUNDARY-END(4296212569)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245885529)
                    /*int*/ static MaxItems = 5;
                    //--TRIMMABLE-BOUNDARY-END(47245885529)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591179865)
                    /*KeyValuePair<string, object?>[]*/ _items = null;
                    //--TRIMMABLE-BOUNDARY-END(8591179865)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886147161)
                    $ctor$1(/*Activity*/ activity, /*ActivityTrackingOptions*/ activityTrackingOption)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886147161);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2(activity !== null, "activity != null");
                            $.$$.System.Diagnostics.Debug.Assert$2(activityTrackingOption !== 0/*ActivityTrackingOptions.None*/, "activityTrackingOption != ActivityTrackingOptions.None");
                            /*int*/ let count = 0;
                            if ((activityTrackingOption & 1/*ActivityTrackingOptions.SpanId*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("SpanId", $.$mel.Microsoft.Extensions.Logging.ActivityExtensions.GetSpanId(activity)), count++);
                            }
                            if ((activityTrackingOption & 2/*ActivityTrackingOptions.TraceId*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("TraceId", $.$mel.Microsoft.Extensions.Logging.ActivityExtensions.GetTraceId(activity)), count++);
                            }
                            if ((activityTrackingOption & 4/*ActivityTrackingOptions.ParentId*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("ParentId", $.$mel.Microsoft.Extensions.Logging.ActivityExtensions.GetParentId(activity)), count++);
                            }
                            if ((activityTrackingOption & 8/*ActivityTrackingOptions.TraceState*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("TraceState", activity.TraceStateString), count++);
                            }
                            if ((activityTrackingOption & 16/*ActivityTrackingOptions.TraceFlags*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("TraceFlags", $.$box(activity.ActivityTraceFlags, $.$sdd.System.Diagnostics.ActivityTraceFlags)), count++);
                            }
                            this.Count = count;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886147161)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476081753)
                    /*int*/ Count = 0;
                    //--TRIMMABLE-BOUNDARY-END(21476081753)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835820121)
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        if (index >= this.Count)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
                        }
                        return $.$$.System.Array.$ReadT1.call(this._items, index);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835820121)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 60130787417, 330712612865)
                    static/*conventional*/ /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130787417);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if ($.$$.System.String.op_Equality(this._cachedToString, null))
                        {
                            /*StringBuilder*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                            sb.Append$19($.$$.System.Array.$ReadT1.call(this._items, 0).Key);
                            sb.Append$3(/*:*/ 58);
                            sb.Append$13($.$$.System.Array.$ReadT1.call(this._items, 0).Value);
                            for(/*int*/ let i = 1; i < this.Count; i++)
                            {
                                sb.Append$19(", ");
                                sb.Append$19($.$$.System.Array.$ReadT1.call(this._items, i).Key);
                                sb.Append$3(/*:*/ 58);
                                sb.Append$13($.$$.System.Array.$ReadT1.call(this._items, i).Value);
                            }
                            this._cachedToString = $.$$.System.Text.StringBuilder.ToString.call(sb);
                        }
                        return this._cachedToString;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 60130787417, 330712612865)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950918233)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950918233)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 51540852825, 4357488641)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540852825);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 51540852825, 4357488641)
                    
                    //--TRIMMABLE-BOUNDARY-START(8649965569)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8649965569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8649965569)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944801793)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354867201);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944801793)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354473985)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354473985);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354473985)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8591179865)
                        this._items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), null, [5/*MaxItems*/], null);
                        //--TRIMMABLE-BOUNDARY-END(8591179865)
                        
                    }
                    static $h = 1245273;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476081753),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066016345,
        "f": 50331649
      },
      "n": "Count",
      "d": 1245273,
      "h": 21476081753,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476081753),
//--TRIMMABLE-BOUNDARY-START(55835820121),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655950937,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 1245273,
      "h": 55835820121,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835820121)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 60130787417, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1245273,
      "h": 60130787417,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60130787417, 330712612865),
//--TRIMMABLE-BOUNDARY-START(42950918233),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": 1245273,
      "h": 42950918233,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950918233)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212569),
    {
      "t": 1310721,
      "n": "_cachedToString",
      "d": 1245273,
      "h": 4296212569,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212569),
//--TRIMMABLE-BOUNDARY-START(47245885529),
    {
      "t": 655361,
      "n": "MaxItems",
      "d": 1245273,
      "h": 47245885529,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245885529),
//--TRIMMABLE-BOUNDARY-START(8591179865),
    {
      "t": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "_items",
      "d": 1245273,
      "h": 8591179865,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886147161),
    {
      "p": [
        {
          "n": "activity",
          "p": 196654
        },
        {
          "n": "activityTrackingOption",
          "p": 196697
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245273,
      "h": 12886147161,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886147161)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62521345
  ],
  "d": 1048665,
  "h": 1245273
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope`; }
                }, $cls, ($v) => $cls.$_ActivityLogScope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245273)
            
            //--TRIMMABLE-BOUNDARY-START(1114201)
            static $_ActivityBaggageLogScopeWrapper;
            static get ActivityBaggageLogScopeWrapper()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider;
                return $cls.$_ActivityBaggageLogScopeWrapper ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper", ($self) => class ActivityBaggageLogScopeWrapper extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296081497)
                    /*IEnumerable<KeyValuePair<string, string?>>*/ _items = null;
                    //--TRIMMABLE-BOUNDARY-END(4296081497)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591048793)
                    /*StringBuilder?*/ _stringBuilder = null;
                    //--TRIMMABLE-BOUNDARY-END(8591048793)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886016089)
                    $ctor$1(/*IEnumerable<KeyValuePair<string, string?>>*/ items)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886016089);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._items = items;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886016089)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475950681)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475950681);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator().$ctor$3(this._items.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)]));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475950681)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 25770917977, 4357488641)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770917977);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator().$ctor$3(this._items.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)]));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 25770917977, 4357488641)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 30065885273, 330712612865)
                    static/*conventional*/ /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065885273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this)
                            {
                                /*IEnumerator<KeyValuePair<string, string?>>*/ let enumerator = this._items.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)]);
                                if (!enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    return $.$$.System.String.Empty;
                                }
                                this._stringBuilder ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                                this._stringBuilder.Append$19(enumerator.System$Collections$Generic$IEnumerator$$$Current.Key);
                                this._stringBuilder.Append$3(/*:*/ 58);
                                this._stringBuilder.Append$19(enumerator.System$Collections$Generic$IEnumerator$$$Current.Value);
                                while(enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this._stringBuilder.Append$19(", ");
                                    this._stringBuilder.Append$19(enumerator.System$Collections$Generic$IEnumerator$$$Current.Key);
                                    this._stringBuilder.Append$3(/*:*/ 58);
                                    this._stringBuilder.Append$19(enumerator.System$Collections$Generic$IEnumerator$$$Current.Value);
                                }
                                /*string*/ let result = $.$$.System.Text.StringBuilder.ToString.call(this._stringBuilder);
                                this._stringBuilder.Clear();
                                return result;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this)
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 30065885273, 330712612865)
                    
                    //--TRIMMABLE-BOUNDARY-START(1179737)
                    static $_BaggageEnumerator;
                    static get BaggageEnumerator()
                    {
                        let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper;
                        return $cls.$_BaggageEnumerator ??= $asm.$nstr("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator", ($self) => class BaggageEnumerator extends $.$$.System.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296147033)
                            /*IEnumerator<KeyValuePair<string, string?>>*/  get _enumerator() { return this.$getField(0, 4); }
                            /*IEnumerator<KeyValuePair<string, string?>>*/  set _enumerator(value) { this.$setField(0, 4, value); }
                            //--TRIMMABLE-BOUNDARY-END(4296147033)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591114329)
                            $ctor$3(/*IEnumerator<KeyValuePair<string, string?>>*/ enumerator)
                            {
                                super.$ctor$1();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(8591114329);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._enumerator = enumerator;
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591114329)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181048921)
                            /*KeyValuePair<string, object?> */ get Current()
                            {
                                return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Key, this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Value);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181048921)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 42950852697, 4357619713)
                            /*object? */ get System$Collections$IEnumerator$Current()
                            {
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 42950852697, 4357619713)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476016217)
                            /*void */ Dispose()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(21476016217);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return this._enumerator.System$IDisposable$Dispose();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476016217)
                            
                            //--TRIMMABLE-BOUNDARY-START(34360918105)
                            /*bool */ MoveNext()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(34360918105);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return this._enumerator.System$Collections$IEnumerator$MoveNext();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(34360918105)
                            
                            //--TRIMMABLE-BOUNDARY-START(38655885401)
                            /*void */ Reset()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(38655885401);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return this._enumerator.System$Collections$IEnumerator$Reset();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(38655885401)
                            
                            //--TRIMMABLE-BOUNDARY-START(12944474113)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<string, object?>>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354539521);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12944474113)
                            
                            //--TRIMMABLE-BOUNDARY-START(4385144833)
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4385144833);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Dispose(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4385144833)
                            
                            //--TRIMMABLE-BOUNDARY-START(17242521601)
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17242521601);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.MoveNext(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17242521601)
                            
                            //--TRIMMABLE-BOUNDARY-START(21537488897)
                            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                            System$Collections$IEnumerator$Reset()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21537488897);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Reset(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(21537488897)
                            
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._enumerator = this._enumerator;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(4296147033)
                                this._enumerator = null;
                                //--TRIMMABLE-BOUNDARY-END(4296147033)
                                
                            }
                            static $h = 1179737;
                            static $z = 4;
                            static $f = 0b10000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181048921),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065950809,
        "f": 50331649
      },
      "n": "Current",
      "d": 1179737,
      "h": 17181048921,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181048921),
//--TRIMMABLE-BOUNDARY-START(ALL, 42950852697, 4357619713),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540787289,
        "f": 50331650
      },
      "n": "{62652417}.Current",
      "o": "System$Collections$IEnumerator$Current",
      "d": 1179737,
      "h": 42950852697,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42950852697, 4357619713)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476016217),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1179737,
      "h": 21476016217,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016217),
//--TRIMMABLE-BOUNDARY-START(34360918105),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1179737,
      "h": 34360918105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360918105),
//--TRIMMABLE-BOUNDARY-START(38655885401),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1179737,
      "h": 38655885401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655885401)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147033),
    {
      "t": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,
      "n": "_enumerator",
      "d": 1179737,
      "h": 4296147033,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147033)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114329),
    {
      "p": [
        {
          "n": "enumerator",
          "p": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179737,
      "h": 8591114329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591114329),
//--TRIMMABLE-BOUNDARY-START(12886081625),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179737,
      "h": 12886081625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081625)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,90177537,62652417
  ],
  "d": 1114201,
  "h": 1179737
}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator`; }
                        }, $cls, ($v) => $cls.$_BaggageEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1179737)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354473985)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354473985);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354473985)
                    
                    static $h = 1114201;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475950681),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": 1114201,
      "h": 21475950681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475950681),
//--TRIMMABLE-BOUNDARY-START(ALL, 30065885273, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1114201,
      "h": 30065885273,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30065885273, 330712612865)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081497),
    {
      "t": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,
      "n": "_items",
      "d": 1114201,
      "h": 4296081497,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081497),
//--TRIMMABLE-BOUNDARY-START(8591048793),
    {
      "t": 166920193,
      "n": "_stringBuilder",
      "d": 1114201,
      "h": 8591048793,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048793)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886016089),
    {
      "p": [
        {
          "n": "items",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114201,
      "h": 12886016089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016089)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62521345
  ],
  "j": [1179737
  ],
  "d": 1048665,
  "h": 1114201
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper`; }
                }, $cls, ($v) => $cls.$_ActivityBaggageLogScopeWrapper = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114201)
            
            //--TRIMMABLE-BOUNDARY-START(4295819352)
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.ForEachScope<TState>(System.Action<object?, TState>, TState)
            Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ForEachScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819352)
            
            //--TRIMMABLE-BOUNDARY-START(8590786648)
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.Push(object?)
            Microsoft$Extensions$Logging$IExternalScopeProvider$Push()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Push(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786648)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590983257)
                this._currentScope = new ($.$$.System.Threading.AsyncLocal$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590983257)
                
            }
            static $h = 1048665;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770852441),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": (TState) => $.$$.System.Action$$$($.$$.System.Object, TState).$h
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "ForEachScope",
      "d": 1048665,
      "h": 25770852441,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(25770852441),
//--TRIMMABLE-BOUNDARY-START(30065819737),
    {
      "r": 1114201,
      "p": [
        {
          "n": "activity",
          "p": 196654
        },
        {
          "n": "items",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h
        }
      ],
      "n": "GetOrCreateActivityBaggageLogScopeWrapper",
      "d": 1048665,
      "h": 30065819737,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065819737),
//--TRIMMABLE-BOUNDARY-START(34360787033),
    {
      "r": 90177537,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "Push",
      "d": 1048665,
      "h": 34360787033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360787033)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590983257),
    {
      "t": $.$$.System.Threading.AsyncLocal$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope).$h,
      "n": "_currentScope",
      "d": 1048665,
      "h": 8590983257,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983257),
//--TRIMMABLE-BOUNDARY-START(4296015961),
    {
      "t": 196697,
      "n": "_activityTrackingOption",
      "d": 1048665,
      "h": 4296015961,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885950553),
    {
      "p": [
        {
          "n": "activityTrackingOption",
          "p": 196697
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048665,
      "h": 12885950553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885950553)
  ],
  "i": [852056
  ],
  "j": [1310809,1245273,1114201
  ],
  "h": 1048665
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.IExternalScopeProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048665)
        
        
        //--TRIMMABLE-BOUNDARY-START(458841)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.Logger", ($self) => class Logger extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295426137)
            /*string*/ _categoryName = null;
            //--TRIMMABLE-BOUNDARY-END(4295426137)
            
            //--TRIMMABLE-BOUNDARY-START(8590393433)
            $ctor$1(/*string*/ categoryName, /*LoggerInformation[]*/ loggers)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393433);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._categoryName = categoryName;
                    this.Loggers = loggers;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393433)
            
            //--TRIMMABLE-BOUNDARY-START(77309870169)
            /*LoggerInformation[]*/ Loggers = null;
            //--TRIMMABLE-BOUNDARY-END(77309870169)
            
            //--TRIMMABLE-BOUNDARY-START(81604837465)
            /*MessageLogger[]?*/ MessageLoggers = null;
            //--TRIMMABLE-BOUNDARY-END(81604837465)
            
            //--TRIMMABLE-BOUNDARY-START(90194772057)
            /*ScopeLogger[]?*/ ScopeLoggers = null;
            //--TRIMMABLE-BOUNDARY-END(90194772057)
            
            //--TRIMMABLE-BOUNDARY-START(64424968281)
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MessageLogger[]?*/ let loggers = this.MessageLoggers;
                if (loggers === null)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < loggers.length; i++)
                {
                    /*ref readonly MessageLogger*/ let loggerInfo = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mel.Microsoft.Extensions.Logging.MessageLogger, loggers, i, false, true);
                    if (!loggerInfo.$v.IsEnabled(logLevel))
                    {
                        continue;
                    }
                    LoggerLog(logLevel, eventId, loggerInfo.$v.Logger, exception, formatter, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$$.System.Collections.Generic.List$$($.$$.System.Exception)), $.$ref(() => state, ));
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mel.Microsoft.Extensions.Logging.Logger.ThrowLoggingError(exceptions);
                }
                /*static void*/  function LoggerLog(/*LogLevel*/ logLevel, /*EventId*/ eventId, /*ILogger*/ logger, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter, /*ref List<Exception>?*/ exceptions, /*in TState*/ state)
                {
                    try
                    {
                        logger.Microsoft$Extensions$Logging$ILogger$Log(TState, logLevel, eventId, state.$v, exception, formatter);
                    }
                    catch(ex)
                    {
                        exceptions.$v ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Exception))().$ctor$1();
                        exceptions.$v.Add(ex);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424968281)
            
            //--TRIMMABLE-BOUNDARY-START(60130000985)
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MessageLogger[]?*/ let loggers = this.MessageLoggers;
                if (loggers === null)
                {
                    return false;
                }
                /*List<Exception>?*/ let exceptions = null;
                /*int*/ let i = 0;
                for(; i < loggers.length; i++)
                {
                    /*ref readonly MessageLogger*/ let loggerInfo = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mel.Microsoft.Extensions.Logging.MessageLogger, loggers, i, false, true);
                    if (!loggerInfo.$v.IsEnabled(logLevel))
                    {
                        continue;
                    }
                    if (LoggerIsEnabled(logLevel, loggerInfo.$v.Logger, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$$.System.Collections.Generic.List$$($.$$.System.Exception))))
                    {
                        break;
                    }
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mel.Microsoft.Extensions.Logging.Logger.ThrowLoggingError(exceptions);
                }
                return i < loggers.length ? true : false;
                /*static bool*/  function LoggerIsEnabled(/*LogLevel*/ logLevel, /*ILogger*/ logger, /*ref List<Exception>?*/ exceptions)
                {
                    try
                    {
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                        {
                            return true;
                        }
                    }
                    catch(ex)
                    {
                        exceptions.$v ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Exception))().$ctor$1();
                        exceptions.$v.Add(ex);
                    }
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130000985)
            
            //--TRIMMABLE-BOUNDARY-START(25770262617)
            /*IDisposable? */ BeginScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ScopeLogger[]?*/ let loggers = this.ScopeLoggers;
                if (loggers === null)
                {
                    return $.$mel.Microsoft.Extensions.Logging.NullScope.Instance;
                }
                if (loggers.length === 1)
                {
                    return $.$$.System.Array.$ReadT1.call(loggers, 0).CreateScope(TState, state);
                }
                /*var*/ let scope = new $.$mel.Microsoft.Extensions.Logging.Logger.Scope().$ctor$1(loggers.length);
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < loggers.length; i++)
                {
                    /*ref readonly ScopeLogger*/ let scopeLogger = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mel.Microsoft.Extensions.Logging.ScopeLogger, loggers, i, false, true);
                    try
                    {
                        scope.SetDisposable(i, scopeLogger.$v.CreateScope(TState, state));
                    }
                    catch(ex)
                    {
                        exceptions ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Exception))().$ctor$1();
                        exceptions.Add(ex);
                    }
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mel.Microsoft.Extensions.Logging.Logger.ThrowLoggingError(exceptions);
                }
                return scope;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262617)
            
            //--TRIMMABLE-BOUNDARY-START(120259543129)
            static /*void */ ThrowLoggingError(/*List<Exception>*/ exceptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.AggregateException().$ctor$10("An error occurred while writing to logger(s).", exceptions);
            }
            //--TRIMMABLE-BOUNDARY-END(120259543129)
            
            //--TRIMMABLE-BOUNDARY-START(30065229913)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mel.Microsoft.Extensions.Logging.DebuggerDisplayFormatting.DebuggerToString(this._categoryName, this);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229913)
            
            //--TRIMMABLE-BOUNDARY-START(655449)
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.Logger;
                return $cls.$_Scope ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.Logger.Scope", ($self) => class Scope extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524633)
                    /*bool*/ _isDisposed = false;
                    //--TRIMMABLE-BOUNDARY-END(17180524633)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590590041)
                    /*IDisposable?*/ _disposable0 = null;
                    //--TRIMMABLE-BOUNDARY-END(8590590041)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557337)
                    /*IDisposable?*/ _disposable1 = null;
                    //--TRIMMABLE-BOUNDARY-END(12885557337)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622745)
                    /*IDisposable?[]?*/ _disposable = null;
                    //--TRIMMABLE-BOUNDARY-END(4295622745)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491929)
                    $ctor$1(/*int*/ count)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475491929);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            if (count > 2)
                            {
                                this._disposable = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.IDisposable), null, [((count - 2) | 0)], null);
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475491929)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426521)
                    /*void */ SetDisposable(/*int*/ index, /*IDisposable?*/ disposable)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065426521);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        switch(index)
                        {
                            case 0:
                            this._disposable0 = disposable;
                            break;
                            case 1:
                            this._disposable1 = disposable;
                            break;
                            default:
                            $.$$.System.Array.$WriteT1.call(this._disposable, disposable, ((index - 2) | 0));
                            break;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065426521)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770459225)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770459225);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._isDisposed)
                        {
                            this._disposable0?.System$IDisposable$Dispose();
                            this._disposable1?.System$IDisposable$Dispose();
                            if (this._disposable !== null)
                            {
                                /*int*/ let count = this._disposable.length;
                                for(/*int*/ let index = 0; index !== count; ++index)
                                {
                                    $.$$.System.Array.$ReadT1.call(this._disposable, index)?.System$IDisposable$Dispose();
                                }
                            }
                            this._isDisposed = true;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770459225)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    static $h = 655449;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065426521),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "disposable",
          "p": 90177537
        }
      ],
      "n": "SetDisposable",
      "d": 655449,
      "h": 30065426521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065426521),
//--TRIMMABLE-BOUNDARY-START(25770459225),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 655449,
      "h": 25770459225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459225)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524633),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 655449,
      "h": 17180524633,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180524633),
//--TRIMMABLE-BOUNDARY-START(8590590041),
    {
      "t": 90177537,
      "n": "_disposable0",
      "d": 655449,
      "h": 8590590041,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590590041),
//--TRIMMABLE-BOUNDARY-START(12885557337),
    {
      "t": 90177537,
      "n": "_disposable1",
      "d": 655449,
      "h": 12885557337,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885557337),
//--TRIMMABLE-BOUNDARY-START(4295622745),
    {
      "t": $.$typeArray($.$$.System.IDisposable).$h,
      "n": "_disposable",
      "d": 655449,
      "h": 4295622745,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622745)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475491929),
    {
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655449,
      "h": 21475491929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491929)
  ],
  "i": [90177537
  ],
  "d": 458841,
  "h": 655449
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.Logger.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655449)
            
            //--TRIMMABLE-BOUNDARY-START(12885819480)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            Microsoft$Extensions$Logging$ILogger$Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819480)
            
            //--TRIMMABLE-BOUNDARY-START(8590852184)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            Microsoft$Extensions$Logging$ILogger$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590852184)
            
            //--TRIMMABLE-BOUNDARY-START(4295884888)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            Microsoft$Extensions$Logging$ILogger$BeginScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884888)
            
            static $h = 458841;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77309870169),
    {
      "p": $.$typeArray($.$mel.Microsoft.Extensions.Logging.LoggerInformation).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655164505,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784706649,
        "f": 83886081
      },
      "n": "Loggers",
      "d": 458841,
      "h": 77309870169,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309870169),
//--TRIMMABLE-BOUNDARY-START(81604837465),
    {
      "p": $.$typeArray($.$mel.Microsoft.Extensions.Logging.MessageLogger).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245099097,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374641241,
        "f": 83886081
      },
      "n": "MessageLoggers",
      "d": 458841,
      "h": 81604837465,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604837465),
//--TRIMMABLE-BOUNDARY-START(90194772057),
    {
      "p": $.$typeArray($.$mel.Microsoft.Extensions.Logging.ScopeLogger).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033689,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964575833,
        "f": 83886081
      },
      "n": "ScopeLoggers",
      "d": 458841,
      "h": 90194772057,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194772057)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64424968281),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "exception",
          "p": 79888385
        },
        {
          "n": "formatter",
          "p": (TState) => $.$$.System.Func$$$$(TState, $.$$.System.Exception, $.$$.System.String).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Log",
      "d": 458841,
      "h": 64424968281,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(64424968281),
//--TRIMMABLE-BOUNDARY-START(60130000985),
    {
      "r": 262145,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "d": 458841,
      "h": 60130000985,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130000985),
//--TRIMMABLE-BOUNDARY-START(25770262617),
    {
      "r": 90177537,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "BeginScope",
      "d": 458841,
      "h": 25770262617,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(25770262617),
//--TRIMMABLE-BOUNDARY-START(120259543129),
    {
      "r": 65537,
      "p": [
        {
          "n": "exceptions",
          "p": $.$$.System.Collections.Generic.List$$($.$$.System.Exception).$h
        }
      ],
      "n": "ThrowLoggingError",
      "d": 458841,
      "h": 120259543129,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259543129),
//--TRIMMABLE-BOUNDARY-START(30065229913),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 458841,
      "h": 30065229913,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30065229913)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426137),
    {
      "t": 1310721,
      "n": "_categoryName",
      "d": 458841,
      "h": 4295426137,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426137)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393433),
    {
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        },
        {
          "n": "loggers",
          "p": $.$typeArray($.$mel.Microsoft.Extensions.Logging.LoggerInformation).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458841,
      "h": 8590393433,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393433)
  ],
  "i": [917592
  ],
  "j": [655449
  ],
  "h": 458841,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70582273,
      "c": 8660516865,
      "a": [
        {
          "v": null,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Logger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458841)
        
        
        //--TRIMMABLE-BOUNDARY-START(720985)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFactory", ($self) => class LoggerFactory extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475557465)
            /*ConcurrentDictionary<string, Logger>*/ _loggers = null;
            //--TRIMMABLE-BOUNDARY-END(21475557465)
            
            //--TRIMMABLE-BOUNDARY-START(25770524761)
            /*List<ProviderRegistration>*/ _providerRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(25770524761)
            
            //--TRIMMABLE-BOUNDARY-START(34360459353)
            /*object*/ _sync = null;
            //--TRIMMABLE-BOUNDARY-END(34360459353)
            
            //--TRIMMABLE-BOUNDARY-START(8590655577)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590655577)
            
            //--TRIMMABLE-BOUNDARY-START(4295688281)
            /*IDisposable?*/ _changeTokenRegistration = null;
            //--TRIMMABLE-BOUNDARY-END(4295688281)
            
            //--TRIMMABLE-BOUNDARY-START(17180590169)
            /*LoggerFilterOptions*/ _filterOptions = null;
            //--TRIMMABLE-BOUNDARY-END(17180590169)
            
            //--TRIMMABLE-BOUNDARY-START(30065492057)
            /*IExternalScopeProvider?*/ _scopeProvider = null;
            //--TRIMMABLE-BOUNDARY-END(30065492057)
            
            //--TRIMMABLE-BOUNDARY-START(12885622873)
            /*LoggerFactoryOptions*/ _factoryOptions = null;
            //--TRIMMABLE-BOUNDARY-END(12885622873)
            
            //--TRIMMABLE-BOUNDARY-START(38655426649)
            $ctor$1()
            {
                this.$ctor$6($.$$.System.Array.Empty($.$mela.Microsoft.Extensions.Logging.ILoggerProvider));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426649)
            
            //--TRIMMABLE-BOUNDARY-START(42950393945)
            $ctor$6(/*IEnumerable<ILoggerProvider>*/ providers)
            {
                this.$ctor$5(providers, new $.$mel.Microsoft.Extensions.Logging.StaticFilterOptionsMonitor().$ctor$1(new $.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions().$ctor$1()));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950393945);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393945)
            
            //--TRIMMABLE-BOUNDARY-START(47245361241)
            $ctor$2(/*IEnumerable<ILoggerProvider>*/ providers, /*LoggerFilterOptions*/ filterOptions)
            {
                this.$ctor$5(providers, new $.$mel.Microsoft.Extensions.Logging.StaticFilterOptionsMonitor().$ctor$1(filterOptions));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245361241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245361241)
            
            //--TRIMMABLE-BOUNDARY-START(51540328537)
            $ctor$5(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption)
            {
                this.$ctor$4(providers, filterOption, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540328537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540328537)
            
            //--TRIMMABLE-BOUNDARY-START(55835295833)
            $ctor$4(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption, /*IOptions<LoggerFactoryOptions>?*/ options)
            {
                this.$ctor$3(providers, filterOption, options, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835295833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835295833)
            
            //--TRIMMABLE-BOUNDARY-START(60130263129)
            $ctor$3(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption, /*IOptions<LoggerFactoryOptions>?*/ options, /*IExternalScopeProvider?*/ scopeProvider)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130263129);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._scopeProvider = scopeProvider;
                    this._factoryOptions = options === null || options.Microsoft$Extensions$Options$IOptions$$$Value === null ? new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions().$ctor$1() : options.Microsoft$Extensions$Options$IOptions$$$Value;
                    /*ActivityTrackingOptions*/ let ActivityTrackingOptionsMask = ~(1/*ActivityTrackingOptions.SpanId*/ | 2/*ActivityTrackingOptions.TraceId*/ | 4/*ActivityTrackingOptions.ParentId*/ | 16/*ActivityTrackingOptions.TraceFlags*/ | 8/*ActivityTrackingOptions.TraceState*/ | 32/*ActivityTrackingOptions.Tags*/ | 64/*ActivityTrackingOptions.Baggage*/);
                    if ((this._factoryOptions.ActivityTrackingOptions & ActivityTrackingOptionsMask) !== 0)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$mel.System.SR.Format$6($.$mel.System.SR.InvalidActivityTrackingOptions, $.$box(this._factoryOptions.ActivityTrackingOptions, $.$mel.Microsoft.Extensions.Logging.ActivityTrackingOptions)), "options");
                    }
                    var $en3 = providers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var provider = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddProviderRegistration(provider, false);
                        }
                    }
                    this._changeTokenRegistration = $.$meo.Microsoft.Extensions.Options.OptionsMonitorExtensions.OnChange($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions, filterOption, new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this, this.RefreshFilters));
                    this.RefreshFilters(filterOption.Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263129)
            
            //--TRIMMABLE-BOUNDARY-START(81605099609)
            static /*ILoggerFactory */ Create(/*Action<ILoggingBuilder>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let serviceCollection = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollection().$ctor$1();
                $.$mel.Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions.AddLogging(serviceCollection, configure);
                /*ServiceProvider*/ let serviceProvider = $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$2(serviceCollection);
                /*ILoggerFactory*/ let loggerFactory = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mela.Microsoft.Extensions.Logging.ILoggerFactory, serviceProvider);
                return new $.$mel.Microsoft.Extensions.Logging.LoggerFactory.DisposingLoggerFactory().$ctor$1(loggerFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(81605099609)
            
            //--TRIMMABLE-BOUNDARY-START(115964837977)
            /*void */ RefreshFilters(/*LoggerFilterOptions*/ filterOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._sync)
                    {
                        this._filterOptions = filterOptions;
                        var $en4 = this._loggers.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var registeredLogger = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*Logger*/ let logger = registeredLogger.Value;
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._sync)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964837977)
            
            //--TRIMMABLE-BOUNDARY-START(85900066905)
            /*ILogger */ CreateLogger(/*string*/ categoryName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CheckDisposed())
                {
                    throw new $.$$.System.ObjectDisposedException().$ctor$17("LoggerFactory");
                }
                /*Logger?*/ let logger;
                if (!this._loggers.TryGetValue(categoryName, $.$ref(() => logger, ($v) => logger = $v, $.$mel.Microsoft.Extensions.Logging.Logger)))
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._sync)
                        {
                            if (!this._loggers.TryGetValue(categoryName, $.$ref(() => logger, ($v) => logger = $v, $.$mel.Microsoft.Extensions.Logging.Logger)))
                            {
                                logger = new $.$mel.Microsoft.Extensions.Logging.Logger().$ctor$1(categoryName, this.CreateLoggers(categoryName));
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                                this._loggers.set_Item(categoryName, logger);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._sync)
                    }
                }
                return logger;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066905)
            
            //--TRIMMABLE-BOUNDARY-START(64425230425)
            /*void */ AddProvider(/*ILoggerProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CheckDisposed())
                {
                    throw new $.$$.System.ObjectDisposedException().$ctor$17("LoggerFactory");
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._sync)
                    {
                        this.AddProviderRegistration(provider, true);
                        var $en4 = this._loggers.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var existingLogger = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*Logger*/ let logger = existingLogger.Value;
                                /*LoggerInformation[]*/ let loggerInformation = logger.Loggers;
                                /*int*/ let newLoggerIndex = loggerInformation.length;
                                $.$$.System.Array.Resize($.$mel.Microsoft.Extensions.Logging.LoggerInformation, $.$ref(() => loggerInformation, ($v) => loggerInformation = $v, $.$typeArray($.$mel.Microsoft.Extensions.Logging.LoggerInformation)), ((loggerInformation.length + 1) | 0));
                                $.$$.System.Array.$WriteT1.call(loggerInformation, new $.$mel.Microsoft.Extensions.Logging.LoggerInformation().$ctor$3(provider, existingLogger.Key), newLoggerIndex);
                                logger.Loggers = loggerInformation;
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._sync)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425230425)
            
            //--TRIMMABLE-BOUNDARY-START(68720197721)
            /*void */ AddProviderRegistration(/*ILoggerProvider*/ provider, /*bool*/ dispose)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._providerRegistrations.Add((() =>
                {
                    //new $.$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration()
                    const $t1 = $.$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration;
                    const $i1 = new $t1();
                    $i1.Provider = provider;
                    $i1.ShouldDispose = dispose;
                    return $i1;
                })());
                let supportsExternalScope;
                if ($.$is(provider, $.$mela.Microsoft.Extensions.Logging.ISupportExternalScope, { set $v(v){ supportsExternalScope = v; } }))
                {
                    this._scopeProvider ??= new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider().$ctor$1(this._factoryOptions.ActivityTrackingOptions);
                    supportsExternalScope.Microsoft$Extensions$Logging$ISupportExternalScope$SetScopeProvider(this._scopeProvider);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720197721)
            
            //--TRIMMABLE-BOUNDARY-START(90195034201)
            /*LoggerInformation[] */ CreateLoggers(/*string*/ categoryName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let loggers = new ($.$$.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerInformation))().$ctor$3(this._providerRegistrations.Count);
                for(/*int*/ let i = 0; i < this._providerRegistrations.Count; i++)
                {
                    /*var*/ let loggerInformation = new $.$mel.Microsoft.Extensions.Logging.LoggerInformation().$ctor$3(this._providerRegistrations.get_Item(i).Provider, categoryName);
                    if (loggerInformation.Logger !== $.$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger.Instance)
                    {
                        loggers.Add(loggerInformation);
                    }
                }
                return loggers.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(90195034201)
            
            //--TRIMMABLE-BOUNDARY-START(73015165017)
            /*(MessageLogger[] MessageLoggers, ScopeLogger[]? ScopeLoggers) */ ApplyFilters(/*LoggerInformation[]*/ loggers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let messageLoggers = new ($.$$.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.MessageLogger))().$ctor$1();
                /*List<ScopeLogger>?*/ let scopeLoggers = this._filterOptions.CaptureScopes ? new ($.$$.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.ScopeLogger))().$ctor$1() : null;
                let $i1 = 0;
                let $arr1 = loggers;
                while ($i1 < $arr1.length)
                {
                    let loggerInformation = $arr1[$i1++];
                    /*LogLevel?*/ let minLevel;
                    /*Func<string?, string?, LogLevel, bool>?*/ let filter;
                    $.$mel.Microsoft.Extensions.Logging.LoggerRuleSelector.Select(this._filterOptions, loggerInformation.ProviderType, loggerInformation.Category, $.$ref(() => minLevel, ($v) => minLevel = $v, $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel)), $.$ref(() => filter, ($v) => filter = $v, $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean)));
                    if ((minLevel !== null) && (minLevel > 5/*LogLevel.Critical*/))
                    {
                        continue;
                    }
                    messageLoggers.Add(new $.$mel.Microsoft.Extensions.Logging.MessageLogger().$ctor$3(loggerInformation.Logger, loggerInformation.Category, loggerInformation.ProviderType.FullName, minLevel, filter));
                    if (!loggerInformation.ExternalScope)
                    {
                        scopeLoggers?.Add(new $.$mel.Microsoft.Extensions.Logging.ScopeLogger().$ctor$3(loggerInformation.Logger, null));
                    }
                }
                if (this._scopeProvider !== null)
                {
                    scopeLoggers?.Add(new $.$mel.Microsoft.Extensions.Logging.ScopeLogger().$ctor$3(null, this._scopeProvider));
                }
                return new ($.$$.System.ValueTuple$$$($.$typeArray($.$mel.Microsoft.Extensions.Logging.MessageLogger), $.$typeArray($.$mel.Microsoft.Extensions.Logging.ScopeLogger)))().$ctor$3(messageLoggers.ToArray(), (scopeLoggers?.ToArray() ?? null));
            }
            //--TRIMMABLE-BOUNDARY-END(73015165017)
            
            //--TRIMMABLE-BOUNDARY-START(77310132313)
            /*bool */ CheckDisposed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310132313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._disposed;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310132313)
            
            //--TRIMMABLE-BOUNDARY-START(98784968793)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._changeTokenRegistration?.System$IDisposable$Dispose();
                    var $en3 = this._providerRegistrations.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var registration = $en3.Current;
                        {
                            try
                            {
                                if (registration.ShouldDispose)
                                {
                                    registration.Provider.System$IDisposable$Dispose();
                                }
                            }
                            catch($e)
                            {
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784968793)
            
            //--TRIMMABLE-BOUNDARY-START(917593)
            static $_ProviderRegistration;
            static get ProviderRegistration()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactory;
                return $cls.$_ProviderRegistration ??= $asm.$nstr("$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration", ($self) => class ProviderRegistration extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852185)
                    /*ILoggerProvider*/  get Provider() { return this.$getField(0, 4); }
                    /*ILoggerProvider*/  set Provider(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590852185)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819481)
                    /*bool*/  get ShouldDispose() { return this.$getField(4, 1); }
                    /*bool*/  set ShouldDispose(value) { this.$setField(4, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885819481)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Provider = this.Provider;
                        copy.ShouldDispose = this.ShouldDispose;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590852185)
                        this.Provider = null;
                        //--TRIMMABLE-BOUNDARY-END(8590852185)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885819481)
                        this.ShouldDispose = false;
                        //--TRIMMABLE-BOUNDARY-END(12885819481)
                        
                    }
                    static $h = 917593;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852185),
    {
      "t": 1114200,
      "n": "Provider",
      "d": 917593,
      "h": 8590852185,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8590852185),
//--TRIMMABLE-BOUNDARY-START(12885819481),
    {
      "t": 262145,
      "n": "ShouldDispose",
      "d": 917593,
      "h": 12885819481,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885819481)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884889),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917593,
      "h": 4295884889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884889)
  ],
  "d": 720985,
  "h": 917593
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration`; }
                }, $cls, ($v) => $cls.$_ProviderRegistration = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917593)
            
            //--TRIMMABLE-BOUNDARY-START(786521)
            static $_DisposingLoggerFactory;
            static get DisposingLoggerFactory()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactory;
                return $cls.$_DisposingLoggerFactory ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.LoggerFactory.DisposingLoggerFactory", ($self) => class DisposingLoggerFactory extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753817)
                    /*ILoggerFactory*/ _loggerFactory = null;
                    //--TRIMMABLE-BOUNDARY-END(4295753817)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721113)
                    /*ServiceProvider*/ _serviceProvider = null;
                    //--TRIMMABLE-BOUNDARY-END(8590721113)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688409)
                    $ctor$1(/*ILoggerFactory*/ loggerFactory, /*ServiceProvider*/ serviceProvider)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885688409);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._loggerFactory = loggerFactory;
                            this._serviceProvider = serviceProvider;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885688409)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770590297)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770590297);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._serviceProvider.Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770590297)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475623001)
                    /*ILogger */ CreateLogger(/*string*/ categoryName)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475623001);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._loggerFactory.Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger(categoryName);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475623001)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655705)
                    /*void */ AddProvider(/*ILoggerProvider*/ provider)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180655705);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._loggerFactory.Microsoft$Extensions$Logging$ILoggerFactory$AddProvider(provider);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180655705)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590983256)
                    //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.CreateLogger(string)
                    Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590983256);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateLogger(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590983256)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015960)
                    //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.AddProvider(Microsoft.Extensions.Logging.ILoggerProvider)
                    Microsoft$Extensions$Logging$ILoggerFactory$AddProvider()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296015960);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.AddProvider(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296015960)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    static $h = 786521;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770590297),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 786521,
      "h": 25770590297,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590297),
//--TRIMMABLE-BOUNDARY-START(21475623001),
    {
      "r": 917592,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "d": 786521,
      "h": 21475623001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623001),
//--TRIMMABLE-BOUNDARY-START(17180655705),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 1114200
        }
      ],
      "n": "AddProvider",
      "d": 786521,
      "h": 17180655705,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655705)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753817),
    {
      "t": 1048664,
      "n": "_loggerFactory",
      "d": 786521,
      "h": 4295753817,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753817),
//--TRIMMABLE-BOUNDARY-START(8590721113),
    {
      "t": 3080285,
      "n": "_serviceProvider",
      "d": 786521,
      "h": 8590721113,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885688409),
    {
      "p": [
        {
          "n": "loggerFactory",
          "p": 1048664
        },
        {
          "n": "serviceProvider",
          "p": 3080285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786521,
      "h": 12885688409,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688409)
  ],
  "i": [1048664,90177537
  ],
  "d": 720985,
  "h": 786521
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggerFactory, $.$$.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactory.DisposingLoggerFactory`; }
                }, $cls, ($v) => $cls.$_DisposingLoggerFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786521)
            
            //--TRIMMABLE-BOUNDARY-START(94490001497)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `Providers = ${this._providerRegistrations.Count}, ${this._filterOptions.DebuggerToString()}`;
            }
            //--TRIMMABLE-BOUNDARY-END(94490001497)
            
            //--TRIMMABLE-BOUNDARY-START(8590983256)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.CreateLogger(string)
            Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLogger(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983256)
            
            //--TRIMMABLE-BOUNDARY-START(4296015960)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.AddProvider(Microsoft.Extensions.Logging.ILoggerProvider)
            Microsoft$Extensions$Logging$ILoggerFactory$AddProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddProvider(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296015960)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475557465)
                this._loggers = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mel.Microsoft.Extensions.Logging.Logger))().$ctor$4($.$$.System.StringComparer.Ordinal);
                //--TRIMMABLE-BOUNDARY-END(21475557465)
                
                //--TRIMMABLE-BOUNDARY-START(25770524761)
                this._providerRegistrations = new ($.$$.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(25770524761)
                
                //--TRIMMABLE-BOUNDARY-START(34360459353)
                this._sync = new $.$$.System.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(34360459353)
                
            }
            static $h = 720985;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605099609),
    {
      "r": 1048664,
      "p": [
        {
          "n": "configure",
          "p": $.$$.System.Action$$($.$mela.Microsoft.Extensions.Logging.ILoggingBuilder).$h
        }
      ],
      "n": "Create",
      "d": 720985,
      "h": 81605099609,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605099609),
//--TRIMMABLE-BOUNDARY-START(115964837977),
    {
      "r": 65537,
      "p": [
        {
          "n": "filterOptions",
          "p": 1376345
        }
      ],
      "n": "RefreshFilters",
      "d": 720985,
      "h": 115964837977,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964837977),
//--TRIMMABLE-BOUNDARY-START(85900066905),
    {
      "r": 917592,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "d": 720985,
      "h": 85900066905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900066905),
//--TRIMMABLE-BOUNDARY-START(64425230425),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 1114200
        }
      ],
      "n": "AddProvider",
      "d": 720985,
      "h": 64425230425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425230425),
//--TRIMMABLE-BOUNDARY-START(68720197721),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 1114200
        },
        {
          "n": "dispose",
          "p": 262145
        }
      ],
      "n": "AddProviderRegistration",
      "d": 720985,
      "h": 68720197721,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720197721),
//--TRIMMABLE-BOUNDARY-START(90195034201),
    {
      "r": $.$typeArray($.$mel.Microsoft.Extensions.Logging.LoggerInformation).$h,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLoggers",
      "d": 720985,
      "h": 90195034201,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195034201),
//--TRIMMABLE-BOUNDARY-START(73015165017),
    {
      "r": $.$$.System.ValueTuple$$$($.$typeArray($.$mel.Microsoft.Extensions.Logging.MessageLogger), $.$typeArray($.$mel.Microsoft.Extensions.Logging.ScopeLogger)).$h,
      "p": [
        {
          "n": "loggers",
          "p": $.$typeArray($.$mel.Microsoft.Extensions.Logging.LoggerInformation).$h
        }
      ],
      "n": "ApplyFilters",
      "d": 720985,
      "h": 73015165017,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015165017),
//--TRIMMABLE-BOUNDARY-START(77310132313),
    {
      "r": 262145,
      "n": "CheckDisposed",
      "d": 720985,
      "h": 77310132313,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(77310132313),
//--TRIMMABLE-BOUNDARY-START(98784968793),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 720985,
      "h": 98784968793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784968793),
//--TRIMMABLE-BOUNDARY-START(94490001497),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 720985,
      "h": 94490001497,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94490001497)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475557465),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mel.Microsoft.Extensions.Logging.Logger).$h,
      "n": "_loggers",
      "d": 720985,
      "h": 21475557465,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475557465),
//--TRIMMABLE-BOUNDARY-START(25770524761),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration).$h,
      "n": "_providerRegistrations",
      "d": 720985,
      "h": 25770524761,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770524761),
//--TRIMMABLE-BOUNDARY-START(34360459353),
    {
      "t": 131073,
      "n": "_sync",
      "d": 720985,
      "h": 34360459353,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360459353),
//--TRIMMABLE-BOUNDARY-START(8590655577),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 720985,
      "h": 8590655577,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655577),
//--TRIMMABLE-BOUNDARY-START(4295688281),
    {
      "t": 90177537,
      "n": "_changeTokenRegistration",
      "d": 720985,
      "h": 4295688281,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688281),
//--TRIMMABLE-BOUNDARY-START(17180590169),
    {
      "t": 1376345,
      "n": "_filterOptions",
      "d": 720985,
      "h": 17180590169,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590169),
//--TRIMMABLE-BOUNDARY-START(30065492057),
    {
      "t": 852056,
      "n": "_scopeProvider",
      "d": 720985,
      "h": 30065492057,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065492057),
//--TRIMMABLE-BOUNDARY-START(12885622873),
    {
      "t": 983129,
      "n": "_factoryOptions",
      "d": 720985,
      "h": 12885622873,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622873)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655426649),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720985,
      "h": 38655426649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426649),
//--TRIMMABLE-BOUNDARY-START(42950393945),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 720985,
      "h": 42950393945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393945),
//--TRIMMABLE-BOUNDARY-START(47245361241),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h
        },
        {
          "n": "filterOptions",
          "p": 1376345
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720985,
      "h": 47245361241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245361241),
//--TRIMMABLE-BOUNDARY-START(51540328537),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h
        },
        {
          "n": "filterOption",
          "p": $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 720985,
      "h": 51540328537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540328537),
//--TRIMMABLE-BOUNDARY-START(55835295833),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h
        },
        {
          "n": "filterOption",
          "p": $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h
        },
        {
          "n": "options",
          "p": $.$meo.Microsoft.Extensions.Options.IOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 720985,
      "h": 55835295833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835295833),
//--TRIMMABLE-BOUNDARY-START(60130263129),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h
        },
        {
          "n": "filterOption",
          "p": $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h
        },
        {
          "n": "options",
          "p": $.$meo.Microsoft.Extensions.Options.IOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions).$h,
          "f": 65
        },
        {
          "n": "scopeProvider",
          "p": 852056,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720985,
      "h": 60130263129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130263129)
  ],
  "i": [1048664,90177537
  ],
  "j": [917593,786521
  ],
  "h": 720985,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70582273,
      "c": 8660516865,
      "a": [
        {
          "v": null,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggerFactory, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720985)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769561)
        $asm.$str("$mel.Microsoft.Extensions.Logging.MessageLogger", ($self) => class MessageLogger extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296736857)
            $ctor$3(/*ILogger*/ logger, /*string*/ category, /*string?*/ providerTypeFullName, /*LogLevel?*/ minLevel, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296736857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Logger = logger;
                    this.Category = category;
                    this.ProviderTypeFullName = providerTypeFullName;
                    this.MinLevel = minLevel;
                    this.Filter = filter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736857)
            
            //--TRIMMABLE-BOUNDARY-START(90196082777)
            /*ILogger*/ Logger = null;
            //--TRIMMABLE-BOUNDARY-END(90196082777)
            
            //--TRIMMABLE-BOUNDARY-START(34361507929)
            /*string*/ Category = null;
            //--TRIMMABLE-BOUNDARY-END(34361507929)
            
            //--TRIMMABLE-BOUNDARY-START(98786017369)
            /*string?*/ ProviderTypeFullName = null;
            //--TRIMMABLE-BOUNDARY-END(98786017369)
            
            //--TRIMMABLE-BOUNDARY-START(94491050073)
            /*LogLevel?*/ MinLevel = null;
            //--TRIMMABLE-BOUNDARY-END(94491050073)
            
            //--TRIMMABLE-BOUNDARY-START(38656475225)
            /*Func<string?, string?, LogLevel, bool>?*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(38656475225)
            
            //--TRIMMABLE-BOUNDARY-START(85901115481)
            /*bool */ IsEnabled(/*LogLevel*/ level)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901115481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.MinLevel !== null && level < this.MinLevel)
                {
                    return false;
                }
                if (this.Filter !== null)
                {
                    return this.Filter.Invoke(this.ProviderTypeFullName, this.Category, level);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(85901115481)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.Category = this.Category;
                copy.ProviderTypeFullName = this.ProviderTypeFullName;
                copy.MinLevel = this.MinLevel;
                copy.Filter = this.Filter;
                return copy;
            }
            static $h = 1769561;
            static $z = 21;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(90196082777),
    {
      "p": 917592,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426279001,
        "f": 50331649
      },
      "n": "Logger",
      "d": 1769561,
      "h": 90196082777,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196082777),
//--TRIMMABLE-BOUNDARY-START(34361507929),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246409817,
        "f": 50331649
      },
      "n": "Category",
      "d": 1769561,
      "h": 34361507929,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361507929),
//--TRIMMABLE-BOUNDARY-START(98786017369),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606148185,
        "f": 50331650
      },
      "n": "ProviderTypeFullName",
      "d": 1769561,
      "h": 98786017369,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98786017369),
//--TRIMMABLE-BOUNDARY-START(94491050073),
    {
      "p": $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016213593,
        "f": 50331649
      },
      "n": "MinLevel",
      "d": 1769561,
      "h": 94491050073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491050073),
//--TRIMMABLE-BOUNDARY-START(38656475225),
    {
      "p": $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836344409,
        "f": 50331649
      },
      "n": "Filter",
      "d": 1769561,
      "h": 38656475225,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656475225)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901115481),
    {
      "r": 262145,
      "p": [
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "d": 1769561,
      "h": 85901115481,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901115481)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736857),
    {
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "providerTypeFullName",
          "p": 1310721
        },
        {
          "n": "minLevel",
          "p": $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h
        },
        {
          "n": "filter",
          "p": $.$$.System.Func$$$$$($.$$.System.String, $.$$.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$$.System.Boolean).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769561,
      "h": 4296736857,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736857),
//--TRIMMABLE-BOUNDARY-START(8591704153),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769561,
      "h": 8591704153,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591704153)
  ],
  "h": 1769561
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Logging.MessageLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769561)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031705)
        $asm.$str("$mel.Microsoft.Extensions.Logging.ScopeLogger", ($self) => class ScopeLogger extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296999001)
            $ctor$3(/*ILogger?*/ logger, /*IExternalScopeProvider?*/ externalScopeProvider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296999001);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(logger !== null || externalScopeProvider !== null, "Logger can't be null when there isn't an ExternalScopeProvider");
                    this.Logger = logger;
                    this.ExternalScopeProvider = externalScopeProvider;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296999001)
            
            //--TRIMMABLE-BOUNDARY-START(47246671961)
            /*ILogger?*/ Logger = null;
            //--TRIMMABLE-BOUNDARY-END(47246671961)
            
            //--TRIMMABLE-BOUNDARY-START(25771835481)
            /*IExternalScopeProvider?*/ ExternalScopeProvider = null;
            //--TRIMMABLE-BOUNDARY-END(25771835481)
            
            //--TRIMMABLE-BOUNDARY-START(21476868185)
            /*IDisposable? */ CreateScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476868185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ExternalScopeProvider !== null)
                {
                    return this.ExternalScopeProvider.Microsoft$Extensions$Logging$IExternalScopeProvider$Push($.$box(state, TState));
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this.Logger !== null, "Logger != null");
                return this.Logger.Microsoft$Extensions$Logging$ILogger$BeginScope(TState, state);
            }
            //--TRIMMABLE-BOUNDARY-END(21476868185)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.ExternalScopeProvider = this.ExternalScopeProvider;
                return copy;
            }
            static $h = 2031705;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246671961),
    {
      "p": 917592,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951704665,
        "f": 50331649
      },
      "n": "Logger",
      "d": 2031705,
      "h": 47246671961,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246671961),
//--TRIMMABLE-BOUNDARY-START(25771835481),
    {
      "p": 852056,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361770073,
        "f": 50331649
      },
      "n": "ExternalScopeProvider",
      "d": 2031705,
      "h": 25771835481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771835481)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476868185),
    {
      "r": 90177537,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "CreateScope",
      "d": 2031705,
      "h": 21476868185,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(21476868185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296999001),
    {
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "externalScopeProvider",
          "p": 852056
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2031705,
      "h": 4296999001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296999001),
//--TRIMMABLE-BOUNDARY-START(8591966297),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031705,
      "h": 8591966297,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591966297)
  ],
  "h": 2031705
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ScopeLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031705)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507417)
        $asm.$str("$mel.Microsoft.Extensions.Logging.LoggerInformation", ($self) => class LoggerInformation extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296474713)
            $ctor$3(/*ILoggerProvider*/ provider, /*string*/ category)
            {
                this.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296474713);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ProviderType = $.$$.System.Object.GetType.call(provider);
                    this.Logger = provider.Microsoft$Extensions$Logging$ILoggerProvider$CreateLogger(category);
                    this.Category = category;
                    this.ExternalScope = $.$is(provider, $.$mela.Microsoft.Extensions.Logging.ISupportExternalScope);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296474713)
            
            //--TRIMMABLE-BOUNDARY-START(73015951449)
            /*ILogger*/ Logger = null;
            //--TRIMMABLE-BOUNDARY-END(73015951449)
            
            //--TRIMMABLE-BOUNDARY-START(30066278489)
            /*string*/ Category = null;
            //--TRIMMABLE-BOUNDARY-END(30066278489)
            
            //--TRIMMABLE-BOUNDARY-START(77310918745)
            /*Type*/ ProviderType = null;
            //--TRIMMABLE-BOUNDARY-END(77310918745)
            
            //--TRIMMABLE-BOUNDARY-START(34361245785)
            /*bool*/ ExternalScope = false;
            //--TRIMMABLE-BOUNDARY-END(34361245785)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.Category = this.Category;
                copy.ProviderType = this.ProviderType;
                copy.ExternalScope = this.ExternalScope;
                return copy;
            }
            static $h = 1507417;
            static $z = 13;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015951449),
    {
      "p": 917592,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131049561,
        "f": 50331649
      },
      "n": "Logger",
      "d": 1507417,
      "h": 73015951449,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015951449),
//--TRIMMABLE-BOUNDARY-START(30066278489),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951180377,
        "f": 50331649
      },
      "n": "Category",
      "d": 1507417,
      "h": 30066278489,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066278489),
//--TRIMMABLE-BOUNDARY-START(77310918745),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720984153,
        "f": 50331649
      },
      "n": "ProviderType",
      "d": 1507417,
      "h": 77310918745,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310918745),
//--TRIMMABLE-BOUNDARY-START(34361245785),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541114969,
        "f": 50331649
      },
      "n": "ExternalScope",
      "d": 1507417,
      "h": 34361245785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361245785)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474713),
    {
      "p": [
        {
          "n": "provider",
          "p": 1114200
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507417,
      "h": 4296474713,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474713),
//--TRIMMABLE-BOUNDARY-START(8591442009),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507417,
      "h": 8591442009,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591442009)
  ],
  "h": 1507417
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507417)
        
        
        //--TRIMMABLE-BOUNDARY-START(196697)
        $asm.$str("$mel.Microsoft.Extensions.Logging.ActivityTrackingOptions", ($self) => class ActivityTrackingOptions extends $.$$.System.Enum
        {
            static None = 0;
            static SpanId = 1;
            static TraceId = 2;
            static ParentId = 4;
            static TraceState = 8;
            static TraceFlags = 16;
            static Tags = 32;
            static Baggage = 64;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SpanId": 1n,
                    "TraceId": 2n,
                    "ParentId": 4n,
                    "TraceState": 8n,
                    "TraceFlags": 16n,
                    "Tags": 32n,
                    "Baggage": 64n
                };
            }
            static $h = 196697;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885098585),
    {
      "t": 196697,
      "n": "None",
      "d": 196697,
      "h": 12885098585,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098585),
//--TRIMMABLE-BOUNDARY-START(21475033177),
    {
      "t": 196697,
      "n": "SpanId",
      "d": 196697,
      "h": 21475033177,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475033177),
//--TRIMMABLE-BOUNDARY-START(34359935065),
    {
      "t": 196697,
      "n": "TraceId",
      "d": 196697,
      "h": 34359935065,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359935065),
//--TRIMMABLE-BOUNDARY-START(17180065881),
    {
      "t": 196697,
      "n": "ParentId",
      "d": 196697,
      "h": 17180065881,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065881),
//--TRIMMABLE-BOUNDARY-START(38654902361),
    {
      "t": 196697,
      "n": "TraceState",
      "d": 196697,
      "h": 38654902361,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654902361),
//--TRIMMABLE-BOUNDARY-START(30064967769),
    {
      "t": 196697,
      "n": "TraceFlags",
      "d": 196697,
      "h": 30064967769,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064967769),
//--TRIMMABLE-BOUNDARY-START(25770000473),
    {
      "t": 196697,
      "n": "Tags",
      "d": 196697,
      "h": 25770000473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770000473),
//--TRIMMABLE-BOUNDARY-START(8590131289),
    {
      "t": 196697,
      "n": "Baggage",
      "d": 196697,
      "h": 8590131289,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131289)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163993),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196697,
      "h": 4295163993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163993)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 196697,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ActivityTrackingOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196697)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097241)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.StaticFilterOptionsMonitor", ($self) => class StaticFilterOptionsMonitor extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297064537)
            $ctor$1(/*LoggerFilterOptions*/ currentValue)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297064537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CurrentValue = $.$firstOf(currentValue, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("currentValue") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064537)
            
            //--TRIMMABLE-BOUNDARY-START(30066868313)
            /*IDisposable? */ OnChange(/*Action<LoggerFilterOptions, string>*/ listener)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066868313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066868313)
            
            //--TRIMMABLE-BOUNDARY-START(17181966425)
            /*LoggerFilterOptions */ Get(/*string?*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181966425);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CurrentValue;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181966425)
            
            //--TRIMMABLE-BOUNDARY-START(12886999129)
            /*LoggerFilterOptions*/ CurrentValue = null;
            //--TRIMMABLE-BOUNDARY-END(12886999129)
            
            //--TRIMMABLE-BOUNDARY-START(17180852311)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.CurrentValue.get
            get Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentValue;
            }
            //--TRIMMABLE-BOUNDARY-END(17180852311)
            
            //--TRIMMABLE-BOUNDARY-START(8590917719)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.Get(string?)
            Microsoft$Extensions$Options$IOptionsMonitor$$$Get()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590917719)
            
            //--TRIMMABLE-BOUNDARY-START(21475819607)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.OnChange(System.Action<Microsoft.Extensions.Logging.LoggerFilterOptions, string?>)
            Microsoft$Extensions$Options$IOptionsMonitor$$$OnChange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnChange(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819607)
            
            static $h = 2097241;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886999129),
    {
      "p": 1376345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771901017,
        "f": 50331649
      },
      "n": "CurrentValue",
      "d": 2097241,
      "h": 12886999129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886999129)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066868313),
    {
      "r": 90177537,
      "p": [
        {
          "n": "listener",
          "p": $.$$.System.Action$$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions, $.$$.System.String).$h
        }
      ],
      "n": "OnChange",
      "d": 2097241,
      "h": 30066868313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066868313),
//--TRIMMABLE-BOUNDARY-START(17181966425),
    {
      "r": 1376345,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": 2097241,
      "h": 17181966425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181966425)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064537),
    {
      "p": [
        {
          "n": "currentValue",
          "p": 1376345
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2097241,
      "h": 4297064537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297064537)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h
  ],
  "h": 2097241
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.StaticFilterOptionsMonitor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097241)
        
        
        //--TRIMMABLE-BOUNDARY-START(327769)
        $asm.$cls("$mel.Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions", ($self) => class DefaultLoggerLevelConfigureOptions extends $.$meo.Microsoft.Extensions.Options.ConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions)
        {
            //--TRIMMABLE-BOUNDARY-START(4295295065)
            $ctor$2(/*LogLevel*/ level)
            {
                super.$ctor$1(new ($.$$.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return options.MinLevel = level;
                }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 1376345
    }
  ],
  "n": "",
  "d": 327769,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295065);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295065)
            
            static $h = 327769;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295065),
    {
      "p": [
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327769,
      "h": 4295295065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295065)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h
  ],
  "h": 327769
}; }
            static get $b() { return $.$meo.Microsoft.Extensions.Options.ConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327769)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"))
//--TRIMMABLE-BOUNDARY-END(89)
