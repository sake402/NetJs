
(function ($global, $, $spc, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $sttp, $sdd, $mela, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Logging", 
    {"h":20,"f":"Microsoft.Extensions.Logging","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":1179669,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":2555925,"t":142606337}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Logging","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Logging","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions", ($self) => class LoggerFactoryOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*ActivityTrackingOptions*/ ActivityTrackingOptions = 0;
            //default member initializer
            constructor()
            {
                super();
                this.ActivityTrackingOptions = 0;
            }
            static $h = 786452;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":196628,"g":{"r":0,"d":0,"h":17180655636,"f":1},"s":{"r":0,"d":0,"h":21475622932,"f":1},"n":"ActivityTrackingOptions","d":786452,"h":12885688340,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":786452,"h":4295753748,"f":1}],"h":786452,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"ActivityTrackingOptions = {ActivityTrackingOptions}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryOptions`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFilterOptions", ($self) => class LoggerFilterOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool*/ CaptureScopes = false;
            /*LogLevel*/ MinLevel = 0;
            /*IList<LoggerFilterRule> */ get Rules()
            {
                return this.RulesInternal;
            }
            /*List<LoggerFilterRule>*/ RulesInternal = null;
            /*string */ DebuggerToString()
            {
                /*string*/ let debugText;
                if (this.MinLevel !== 6/*LogLevel.None*/)
                {
                    debugText = `MinLevel = ${this.MinLevel}`;
                }
                else 
                {
                    debugText = `Enabled = false`;
                }
                if (this.Rules.System$Collections$Generic$ICollection$$$Count > 0)
                {
                    debugText += `, Rules = ${this.Rules.System$Collections$Generic$ICollection$$$Count}`;
                }
                return debugText;
            }
            //default member initializer
            constructor()
            {
                super();
                this.CaptureScopes = true;
                this.MinLevel = 0;
                this.RulesInternal = new ($.$spc.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterRule))().$ctor$1();
            }
            static $h = 1179668;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17181048852,"f":1},"s":{"r":0,"d":0,"h":21476016148,"f":1},"n":"CaptureScopes","d":1179668,"h":12886081556,"f":1},{"p":2293781,"g":{"r":0,"d":0,"h":34360918036,"f":1},"s":{"r":0,"d":0,"h":38655885332,"f":1},"n":"MinLevel","d":1179668,"h":30065950740,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterRule).$h,"g":{"r":0,"d":0,"h":47245819924,"f":1},"n":"Rules","d":1179668,"h":42950852628,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterRule).$h,"g":{"r":0,"d":0,"h":60130721812,"f":8},"n":"RulesInternal","d":1179668,"h":55835754516,"f":8}],"m":[{"r":1310721,"n":"DebuggerToString","d":1179668,"h":64425689108,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":1179668,"h":4296146964,"f":1}],"h":1179668,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFilterOptions`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFilterRule", ($self) => class LoggerFilterRule extends $.$spc.System.Object
        {
            $ctor$1(/*string?*/ providerName, /*string?*/ categoryName, /*LogLevel?*/ logLevel, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                super.$ctor();
                {
                    this.ProviderName = providerName;
                    this.CategoryName = categoryName;
                    this.LogLevel = logLevel;
                    this.Filter = filter;
                }
                return this;
            }
            /*string?*/ ProviderName = null;
            /*string?*/ CategoryName = null;
            /*LogLevel?*/ LogLevel = null;
            /*Func<string?, string?, LogLevel, bool>?*/ Filter = null;
            static/*conventional*/ /*string */ ToString()
            {
                return `${"ProviderName"}: '${this.ProviderName}', ${"CategoryName"}: '${this.CategoryName}', ${"LogLevel"}: '${this.LogLevel}', ${"Filter"}: '${$.$spc.System.Object.ToString.call(this.Filter)}'`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mel.Microsoft.Extensions.Logging.LoggerFilterRule.ToString.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this.LogLevel = null;
            }
            static $h = 1245204;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181114388,"f":1},"n":"ProviderName","d":1245204,"h":12886147092,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066016276,"f":1},"n":"CategoryName","d":1245204,"h":25771048980,"f":1},{"p":$.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,"g":{"r":0,"d":0,"h":42950918164,"f":1},"n":"LogLevel","d":1245204,"h":38655950868,"f":1},{"p":$.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h,"g":{"r":0,"d":0,"h":55835820052,"f":1},"n":"Filter","d":1245204,"h":51540852756,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1245204,"h":60130787348,"f":32769}],"c":[{"p":[{"n":"providerName","p":1310721},{"n":"categoryName","p":1310721},{"n":"logLevel","p":$.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h},{"n":"filter","p":$.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":".ctor","o":"$ctor$1","d":1245204,"h":4296212500,"f":1}],"h":1245204}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFilterRule`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggingBuilderExtensions", ($self) => class LoggingBuilderExtensions
        {
            static /*ILoggingBuilder */ SetMinimumLevel(/*this ILoggingBuilder*/ builder, /*LogLevel*/ level)
            {
                builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services.System$Collections$Generic$ICollection$$$Add($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions), new $.$mel.Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions().$ctor$2(level)), [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return builder;
            }
            static /*ILoggingBuilder */ AddProvider(/*this ILoggingBuilder*/ builder, /*ILoggerProvider*/ provider)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$mela.Microsoft.Extensions.Logging.ILoggerProvider, builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services, provider);
                return builder;
            }
            static /*ILoggingBuilder */ ClearProviders(/*this ILoggingBuilder*/ builder)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.RemoveAll($.$mela.Microsoft.Extensions.Logging.ILoggerProvider, builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services);
                return builder;
            }
            static /*ILoggingBuilder */ Configure(/*this ILoggingBuilder*/ builder, /*Action<LoggerFactoryOptions>*/ action)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions, builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services, action);
                return builder;
            }
            static $h = 1507348;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"level","p":2293781}],"n":"SetMinimumLevel","d":1507348,"h":4296474644,"f":33},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"provider","p":1114133}],"n":"AddProvider","d":1507348,"h":8591441940,"f":33},{"r":1179669,"p":[{"n":"builder","p":1179669}],"n":"ClearProviders","d":1507348,"h":12886409236,"f":33},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"action","p":$.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions).$h}],"n":"Configure","d":1507348,"h":17181376532,"f":33}],"h":1507348}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggingBuilderExtensions`; }
        });
        
        $asm.$cls("$mel.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mel.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Logging", $.$mel.System.SR.$type.Assembly);
                    $.$mel.System.SR.s_resourceManager = temp;
                }
                return $.$mel.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mel.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mel.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidActivityTrackingOptions()
            {
                return "{0} is invalid ActivityTrackingOptions value.";
            }
            static /*string */ FormatInvalidActivityTrackingOptions(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("{0} is invalid ActivityTrackingOptions value.", arg1);
            }
            static /*string */ get MoreThanOneWildcard()
            {
                return "Only one wildcard character is allowed in category name.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mel.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mel.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mel.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mel.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mel.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mel.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mel.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1966100;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1966100}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.DebuggerDisplayFormatting", ($self) => class DebuggerDisplayFormatting
        {
            static /*string */ DebuggerToString(/*string*/ name, /*ILogger*/ logger)
            {
                /*LogLevel?*/ let minimumLevel = $.$mel.Microsoft.Extensions.Logging.DebuggerDisplayFormatting.CalculateEnabledLogLevel(logger);
                /*var*/ let debugText = `Name = \"${name}\"`;
                if (minimumLevel !== null)
                {
                    debugText += `, MinLevel = ${minimumLevel}`;
                }
                else 
                {
                    debugText += `, Enabled = false`;
                }
                return debugText;
            }
            static /*LogLevel? */ CalculateEnabledLogLevel(/*ILogger*/ logger)
            {
                /*ReadOnlySpan<LogLevel>*/ let logLevels = new ($.$spc.System.ReadOnlySpan$$($.$mela.Microsoft.Extensions.Logging.LogLevel))().$ctor$2([ 5/*LogLevel.Critical*/, 4/*LogLevel.Error*/, 3/*LogLevel.Warning*/, 2/*LogLevel.Information*/, 1/*LogLevel.Debug*/, 0/*LogLevel.Trace*/ ]);
                /*LogLevel?*/ let minimumLevel = null;
                var $en2 = logLevels.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var logLevel = $en2.Current.$v;
                    {
                        if (!logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                        {
                            break;
                        }
                        minimumLevel = logLevel;
                    }
                }
                return minimumLevel;
            }
            static $h = 262164;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"logger","p":917525}],"n":"DebuggerToString","d":262164,"h":4295229460,"f":40},{"r":$.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,"p":[{"n":"logger","p":917525}],"n":"CalculateEnabledLogLevel","d":262164,"h":8590196756,"f":40}],"h":262164}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.DebuggerDisplayFormatting`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerRuleSelector", ($self) => class LoggerRuleSelector
        {
            static /*void */ Select(/*LoggerFilterOptions*/ options, /*Type*/ providerType, /*string*/ category, /*out LogLevel?*/ minLevel, /*out Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                filter.$v = null;
                minLevel.$v = options.MinLevel;
                /*string?*/ let providerAlias = $.$mel.Microsoft.Extensions.Logging.ProviderAliasUtilities.GetAlias(providerType);
                /*LoggerFilterRule?*/ let current = null;
                var $en2 = options.RulesInternal.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var rule = $en2.Current;
                    {
                        if ($.$mel.Microsoft.Extensions.Logging.LoggerRuleSelector.IsBetter(rule, current, providerType.FullName, category) || (!$.$spc.System.String.IsNullOrEmpty(providerAlias) && $.$mel.Microsoft.Extensions.Logging.LoggerRuleSelector.IsBetter(rule, current, providerAlias, category)))
                        {
                            current = rule;
                        }
                    }
                }
                if (current !== null)
                {
                    filter.$v = current.Filter;
                    minLevel.$v = current.LogLevel;
                }
            }
            static /*bool */ IsBetter(/*LoggerFilterRule*/ rule, /*LoggerFilterRule?*/ current, /*string?*/ logger, /*string*/ category)
            {
                if ($.$spc.System.String.op_Inequality(rule.ProviderName, null) && $.$spc.System.String.op_Inequality(rule.ProviderName, logger))
                {
                    return false;
                }
                /*string?*/ let categoryName = rule.CategoryName;
                if ($.$spc.System.String.op_Inequality(categoryName, null))
                {
                    /*char*/ let WildcardChar = /***/ 42;
                    /*int*/ let wildcardIndex = $.$spc.System.String.IndexOf.call(categoryName, WildcardChar);
                    if (wildcardIndex !== -1 && $.$spc.System.String.IndexOf$1.call(categoryName, WildcardChar, ((wildcardIndex + 1) | 0)) !== -1)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mel.System.SR.MoreThanOneWildcard);
                    }
                    /*ReadOnlySpan<char>*/ let prefix, suffix;
                    if (wildcardIndex === -1)
                    {
                        prefix = $.$spc.System.MemoryExtensions.AsSpan$3(categoryName);
                        suffix = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))();
                    }
                    else 
                    {
                        prefix = $.$spc.System.MemoryExtensions.AsSpan$7(categoryName, 0, wildcardIndex);
                        suffix = $.$spc.System.MemoryExtensions.AsSpan$4(categoryName, ((wildcardIndex + 1) | 0));
                    }
                    if (!$.$spc.System.MemoryExtensions.StartsWith$5($.$spc.System.MemoryExtensions.AsSpan$3(category), prefix, 5/*StringComparison.OrdinalIgnoreCase*/) || !$.$spc.System.MemoryExtensions.EndsWith$5($.$spc.System.MemoryExtensions.AsSpan$3(category), suffix, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return false;
                    }
                }
                if ($.$spc.System.String.op_Inequality((current?.ProviderName ?? null), null))
                {
                    if ($.$spc.System.String.op_Equality(rule.ProviderName, null))
                    {
                        return false;
                    }
                }
                else 
                {
                    if ($.$spc.System.String.op_Inequality(rule.ProviderName, null))
                    {
                        return true;
                    }
                }
                if ($.$spc.System.String.op_Inequality((current?.CategoryName ?? null), null))
                {
                    if ($.$spc.System.String.op_Equality(rule.CategoryName, null))
                    {
                        return false;
                    }
                    if (current.CategoryName.length > rule.CategoryName.length)
                    {
                        return false;
                    }
                }
                return true;
            }
            static $h = 1376276;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"options","p":1179668},{"n":"providerType","p":142606337},{"n":"category","p":1310721},{"n":"minLevel","p":$.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,"f":2},{"n":"filter","p":$.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h,"f":2}],"n":"Select","d":1376276,"h":4296343572,"f":33},{"r":262145,"p":[{"n":"rule","p":1245204},{"n":"current","p":1245204},{"n":"logger","p":1310721},{"n":"category","p":1310721}],"n":"IsBetter","d":1376276,"h":8591310868,"f":34}],"h":1376276}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerRuleSelector`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions", ($self) => class LoggingServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddLogging(/*this IServiceCollection*/ services)
            {
                return $.$mel.Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions.AddLogging$1(services, new ($.$spc.System.Action$$($.$mela.Microsoft.Extensions.Logging.ILoggingBuilder))().$ctor(this,  (/*builder*/ builder) =>
                {
                }, {"r":65537,"p":[{"n":"builder","p":1179669}],"n":"","d":65556,"h":0,"f":1048578}));
            }
            static /*IServiceCollection */ AddLogging$1(/*this IServiceCollection*/ services, /*Action<ILoggingBuilder>*/ configure)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton($.$mela.Microsoft.Extensions.Logging.ILoggerFactory, $.$mel.Microsoft.Extensions.Logging.LoggerFactory));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$1($.$mela.Microsoft.Extensions.Logging.ILogger$$().$type, $.$mela.Microsoft.Extensions.Logging.Logger$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions), new $.$mel.Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions().$ctor$2(2/*LogLevel.Information*/)));
                configure.Invoke(new $.$mel.Microsoft.Extensions.Logging.LoggingBuilder().$ctor$1(services));
                return services;
            }
            static $h = 65556;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435}],"n":"AddLogging","d":65556,"h":4295032852,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configure","p":$.$spc.System.Action$$($.$mela.Microsoft.Extensions.Logging.ILoggingBuilder).$h}],"n":"AddLogging","o":"@$1","d":65556,"h":8590000148,"f":33}],"h":65556}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.ProviderAliasUtilities", ($self) => class ProviderAliasUtilities
        {
            /*string*/ static AliasAttributeTypeFullName = null;
            static /*string? */ GetAlias(/*Type*/ providerType)
            {
                /*IList<CustomAttributeData>*/ let attributes = $.$spc.System.Reflection.CustomAttributeData.GetCustomAttributes(providerType);
                for(/*int*/ let i = 0; i < attributes.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*CustomAttributeData*/ let attributeData = attributes.System$Collections$Generic$IList$$$get_Item(i, [$.$spc.System.Reflection.CustomAttributeData]);
                    if ($.$spc.System.String.op_Equality(attributeData.AttributeType.FullName, "Microsoft.Extensions.Logging.ProviderAliasAttribute"/*AliasAttributeTypeFullName*/) && attributeData.ConstructorArguments.System$Collections$Generic$ICollection$$$Count > 0)
                    {
                        /*CustomAttributeTypedArgument*/ let arg = attributeData.ConstructorArguments.System$Collections$Generic$IList$$$get_Item(0, [$.$spc.System.Reflection.CustomAttributeTypedArgument]);
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(arg.ArgumentType, $.$spc.System.String.$type), "arg.ArgumentType == typeof(string)");
                        const $t1 = () => arg.Value;
                        return $.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t));
                    }
                }
                return null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.AliasAttributeTypeFullName = "Microsoft.Extensions.Logging.ProviderAliasAttribute";
                }
            }
            static $h = 1769492;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"providerType","p":142606337}],"n":"GetAlias","d":1769492,"h":8591704084,"f":40}],"l":[{"t":1310721,"n":"AliasAttributeTypeFullName","d":1769492,"h":4296736788,"f":34}],"h":1769492}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ProviderAliasUtilities`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions", ($self) => class FilterLoggingBuilderExtensions
        {
            static /*ILoggingBuilder */ AddFilter(/*this ILoggingBuilder*/ builder, /*Func<string?, string?, LogLevel, bool>*/ filter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$9(options, filter);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ AddFilter$1(/*this ILoggingBuilder*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/**/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$10(options, categoryLevelFilter);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ AddFilter$2(T, /*this ILoggingBuilder*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/**/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$11(T, options, categoryLevelFilter);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ AddFilter$3(/*this ILoggingBuilder*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$12(options, levelFilter);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ AddFilter$4(T, /*this ILoggingBuilder*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$13(T, options, levelFilter);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ AddFilter$5(/*this ILoggingBuilder*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$14(options, category, level);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ AddFilter$6(T, /*this ILoggingBuilder*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$15(T, options, category, level);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ AddFilter$7(/*this ILoggingBuilder*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$16(options, category, levelFilter);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ AddFilter$8(T, /*this ILoggingBuilder*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddFilter$17(T, options, category, levelFilter);
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*LoggerFilterOptions */ AddFilter$9(/*this LoggerFilterOptions*/ builder, /*Func<string?, string?, LogLevel, bool>*/ filter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, filter);
            }
            static /*LoggerFilterOptions */ AddFilter$10(/*this LoggerFilterOptions*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, new ($.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                {
                    return categoryLevelFilter.Invoke(name, level);
                }, {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293781}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*LoggerFilterOptions */ AddFilter$11(T, /*this LoggerFilterOptions*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, null, null, new ($.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                {
                    return categoryLevelFilter.Invoke(name, level);
                }, {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293781}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*LoggerFilterOptions */ AddFilter$12(/*this LoggerFilterOptions*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, new ($.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                {
                    return levelFilter.Invoke(level);
                }, {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293781}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*LoggerFilterOptions */ AddFilter$13(T, /*this LoggerFilterOptions*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, null, null, new ($.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                {
                    return levelFilter.Invoke(level);
                }, {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293781}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*LoggerFilterOptions */ AddFilter$14(/*this LoggerFilterOptions*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, category, level, null);
            }
            static /*LoggerFilterOptions */ AddFilter$15(T, /*this LoggerFilterOptions*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, category, level, null);
            }
            static /*LoggerFilterOptions */ AddFilter$16(/*this LoggerFilterOptions*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, null, category, null, new ($.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                {
                    return levelFilter.Invoke(level);
                }, {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293781}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*LoggerFilterOptions */ AddFilter$17(T, /*this LoggerFilterOptions*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                return $.$mel.Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, category, null, new ($.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                {
                    return levelFilter.Invoke(level);
                }, {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293781}],"n":"","d":393236,"h":0,"f":1048578}));
            }
            static /*ILoggingBuilder */ ConfigureFilter(/*this ILoggingBuilder*/ builder, /*Action<LoggerFilterOptions>*/ configureOptions)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions, builder.Microsoft$Extensions$Logging$ILoggingBuilder$Services, configureOptions);
                return builder;
            }
            static /*LoggerFilterOptions */ AddRule(/*LoggerFilterOptions*/ options, /*string?*/ type, /*string?*/ category, /*LogLevel?*/ level, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                options.Rules.System$Collections$Generic$ICollection$$$Add(new $.$mel.Microsoft.Extensions.Logging.LoggerFilterRule().$ctor$1(type, category, level, filter), [$.$mel.Microsoft.Extensions.Logging.LoggerFilterRule]);
                return options;
            }
            static $h = 393236;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"filter","p":$.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":"AddFilter","d":393236,"h":4295360532,"f":33},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"categoryLevelFilter","p":$.$spc.System.Func$$$$($.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":"AddFilter","o":"@$1","d":393236,"h":8590327828,"f":33},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"categoryLevelFilter","p":$.$spc.System.Func$$$$($.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"g":["T"],"n":"AddFilter","o":"@$2","d":393236,"h":12885295124,"f":131105},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"levelFilter","p":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":"AddFilter","o":"@$3","d":393236,"h":17180262420,"f":33},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"levelFilter","p":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"g":["T"],"n":"AddFilter","o":"@$4","d":393236,"h":21475229716,"f":131105},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"category","p":1310721},{"n":"level","p":2293781}],"n":"AddFilter","o":"@$5","d":393236,"h":25770197012,"f":33},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"category","p":1310721},{"n":"level","p":2293781}],"g":["T"],"n":"AddFilter","o":"@$6","d":393236,"h":30065164308,"f":131105},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"category","p":1310721},{"n":"levelFilter","p":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":"AddFilter","o":"@$7","d":393236,"h":34360131604,"f":33},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"category","p":1310721},{"n":"levelFilter","p":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"g":["T"],"n":"AddFilter","o":"@$8","d":393236,"h":38655098900,"f":131105},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"filter","p":$.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":"AddFilter","o":"@$9","d":393236,"h":42950066196,"f":33},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"categoryLevelFilter","p":$.$spc.System.Func$$$$($.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":"AddFilter","o":"@$10","d":393236,"h":47245033492,"f":33},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"categoryLevelFilter","p":$.$spc.System.Func$$$$($.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"g":["T"],"n":"AddFilter","o":"@$11","d":393236,"h":51540000788,"f":131105},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"levelFilter","p":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":"AddFilter","o":"@$12","d":393236,"h":55834968084,"f":33},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"levelFilter","p":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"g":["T"],"n":"AddFilter","o":"@$13","d":393236,"h":60129935380,"f":131105},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"category","p":1310721},{"n":"level","p":2293781}],"n":"AddFilter","o":"@$14","d":393236,"h":64424902676,"f":33},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"category","p":1310721},{"n":"level","p":2293781}],"g":["T"],"n":"AddFilter","o":"@$15","d":393236,"h":68719869972,"f":131105},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"category","p":1310721},{"n":"levelFilter","p":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":"AddFilter","o":"@$16","d":393236,"h":73014837268,"f":33},{"r":1179668,"p":[{"n":"builder","p":1179668},{"n":"category","p":1310721},{"n":"levelFilter","p":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"g":["T"],"n":"AddFilter","o":"@$17","d":393236,"h":77309804564,"f":131105},{"r":1179669,"p":[{"n":"builder","p":1179669},{"n":"configureOptions","p":$.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h}],"n":"ConfigureFilter","d":393236,"h":81604771860,"f":34},{"r":1179668,"p":[{"n":"options","p":1179668},{"n":"type","p":1310721,"f":65},{"n":"category","p":1310721,"f":65},{"n":"level","p":$.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,"f":65},{"n":"filter","p":$.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h,"f":65}],"n":"AddRule","d":393236,"h":85899739156,"f":34}],"h":393236}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.ActivityExtensions", ($self) => class ActivityExtensions
        {
            static /*string */ GetSpanId(/*this Activity*/ activity)
            {
                return (() =>
                {
                    let $switch1 = activity.IdFormat;
                    if ($switch1 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.Id;
                    }
                    if ($switch1 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.SpanId.ToHexString();
                    }
                    return null;
                })() ?? $.$spc.System.String.Empty;
            }
            static /*string */ GetTraceId(/*this Activity*/ activity)
            {
                return (() =>
                {
                    let $switch1 = activity.IdFormat;
                    if ($switch1 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.RootId;
                    }
                    if ($switch1 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.TraceId.ToHexString();
                    }
                    return null;
                })() ?? $.$spc.System.String.Empty;
            }
            static /*string */ GetParentId(/*this Activity*/ activity)
            {
                return (() =>
                {
                    let $switch1 = activity.IdFormat;
                    if ($switch1 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.ParentId;
                    }
                    if ($switch1 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.ParentSpanId.ToHexString();
                    }
                    return null;
                })() ?? $.$spc.System.String.Empty;
            }
            static $h = 131092;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"activity","p":196652}],"n":"GetSpanId","d":131092,"h":4295098388,"f":33},{"r":1310721,"p":[{"n":"activity","p":196652}],"n":"GetTraceId","d":131092,"h":8590065684,"f":33},{"r":1310721,"p":[{"n":"activity","p":196652}],"n":"GetParentId","d":131092,"h":12885032980,"f":33}],"h":131092}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ActivityExtensions`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.NullScope", ($self) => class NullScope extends $.$spc.System.Object
        {
            /*NullScope*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mel.Microsoft.Extensions.Logging.NullScope().$ctor$1();
                }
            }
            static $h = 1703956;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1703956,"g":{"r":0,"d":0,"h":12886605844,"f":33},"n":"Instance","d":1703956,"h":8591638548,"f":33}],"m":[{"r":65537,"n":"Dispose","d":1703956,"h":21476540436,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1703956,"h":17181573140,"f":2}],"i":[57540609],"h":1703956}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.NullScope`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.NullExternalScopeProvider", ($self) => class NullExternalScopeProvider extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IExternalScopeProvider*/ static Instance = null;
            /*void */ Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
            }
            /*IDisposable */ Microsoft$Extensions$Logging$IExternalScopeProvider$Push(/*object?*/ state)
            {
                return $.$mel.Microsoft.Extensions.Logging.NullScope.Instance;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mel.Microsoft.Extensions.Logging.NullExternalScopeProvider().$ctor$1();
                }
            }
            static $h = 1638420;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851989,"g":{"r":0,"d":0,"h":17181507604,"f":33},"n":"Instance","d":1638420,"h":12886540308,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1638420,"h":4296605716,"f":2}],"i":[851989],"h":1638420}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.IExternalScopeProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.NullExternalScopeProvider`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggingBuilder", ($self) => class LoggingBuilder extends $.$spc.System.Object
        {
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    this.Services = services;
                }
                return this;
            }
            /*IServiceCollection*/ Services = null;
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggingBuilder.Services.get
            get Microsoft$Extensions$Logging$ILoggingBuilder$Services()
            {
                return this.Services;
            }
            static $h = 1441812;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":786435,"g":{"r":0,"d":0,"h":17181310996,"f":1},"n":"Services","d":1441812,"h":12886343700,"f":1}],"c":[{"p":[{"n":"services","p":786435}],"n":".ctor","o":"$ctor$1","d":1441812,"h":4296409108,"f":1}],"i":[1179669],"h":1441812}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggingBuilder ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggingBuilder`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider", ($self) => class LoggerFactoryScopeProvider extends $.$spc.System.Object
        {
            /*AsyncLocal<Scope?>*/ _currentScope = null;
            /*ActivityTrackingOptions*/ _activityTrackingOption = 0;
            $ctor$1(/*ActivityTrackingOptions*/ activityTrackingOption)
            {
                super.$ctor();
                this._activityTrackingOption = activityTrackingOption;
                return this;
            }
            /*void */ ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
                /*void*/  function Report(/*Scope?*/ current)
                {
                    if (current === null)
                    {
                        return;
                    }
                    Report.call(this, current.Parent);
                    callback.Invoke(current.State, state);
                }
                if (this._activityTrackingOption !== 0/*ActivityTrackingOptions.None*/)
                {
                    /*Activity?*/ let activity = $.$sdd.System.Diagnostics.Activity.Current;
                    if (activity !== null)
                    {
                        /*string*/ let propertyKey = "__ActivityLogScope__";
                        /*ActivityLogScope?*/ let activityLogScope = $.$as(activity.GetCustomProperty(propertyKey), $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope);
                        if (activityLogScope === null)
                        {
                            activityLogScope = new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope().$ctor$1(activity, this._activityTrackingOption);
                            activity.SetCustomProperty(propertyKey, activityLogScope);
                        }
                        callback.Invoke(activityLogScope, state);
                        if ((this._activityTrackingOption & 32/*ActivityTrackingOptions.Tags*/) !== 0 && activity.TagObjects.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]).System$Collections$IEnumerator$MoveNext())
                        {
                            callback.Invoke(activity.TagObjects, state);
                        }
                        if ((this._activityTrackingOption & 64/*ActivityTrackingOptions.Baggage*/) !== 0)
                        {
                            /*IEnumerable<KeyValuePair<string, string?>>*/ let baggage = activity.Baggage;
                            if (baggage.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)]).System$Collections$IEnumerator$MoveNext())
                            {
                                /*ActivityBaggageLogScopeWrapper*/ let scope = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.GetOrCreateActivityBaggageLogScopeWrapper(activity, baggage);
                                callback.Invoke(scope, state);
                            }
                        }
                    }
                }
                Report.call(this, this._currentScope.Value);
            }
            static /*ActivityBaggageLogScopeWrapper */ GetOrCreateActivityBaggageLogScopeWrapper(/*Activity*/ activity, /*IEnumerable<KeyValuePair<string, string?>>*/ items)
            {
                /*string*/ let additionalItemsBaggagePropertyKey = "__ActivityBaggageItemsLogScope__";
                /*var*/ let activityBaggageLogScopeWrapper = $.$as(activity.GetCustomProperty(additionalItemsBaggagePropertyKey), $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper);
                if (activityBaggageLogScopeWrapper === null)
                {
                    activityBaggageLogScopeWrapper = new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper().$ctor$1(items);
                    activity.SetCustomProperty(additionalItemsBaggagePropertyKey, activityBaggageLogScopeWrapper);
                }
                return activityBaggageLogScopeWrapper;
            }
            /*IDisposable */ Push(/*object?*/ state)
            {
                /*Scope?*/ let parent = this._currentScope.Value;
                /*var*/ let newScope = new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope().$ctor$1(this, state, parent);
                this._currentScope.Value = newScope;
                return newScope;
            }
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider;
                return $cls.$_Scope ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope", ($self) => class Scope extends $.$spc.System.Object
                {
                    /*LoggerFactoryScopeProvider*/ _provider = null;
                    /*bool*/ _isDisposed = false;
                    $ctor$1(/*LoggerFactoryScopeProvider*/ provider, /*object?*/ state, /*Scope?*/ parent)
                    {
                        super.$ctor();
                        {
                            this._provider = provider;
                            this.State = state;
                            this.Parent = parent;
                        }
                        return this;
                    }
                    /*Scope?*/ Parent = null;
                    /*object?*/ State = null;
                    static/*conventional*/ /*string? */ ToString()
                    {
                        const $t1 = this.State;
                        return $.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t));
                    }
                    //Static convention instance redirect
                    /*string? */ ToString() { return $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope.ToString.apply(this, arguments); }
                    /*void */ Dispose()
                    {
                        if (!this._isDisposed)
                        {
                            this._provider._currentScope.Value = this.Parent;
                            this._isDisposed = true;
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 1114132;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1114132,"g":{"r":0,"d":0,"h":25770917908,"f":1},"n":"Parent","d":1114132,"h":21475950612,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":38655819796,"f":1},"n":"State","d":1114132,"h":34360852500,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1114132,"h":42950787092,"f":32769},{"r":65537,"n":"Dispose","d":1114132,"h":47245754388,"f":1}],"l":[{"t":851988,"n":"_provider","d":1114132,"h":4296081428,"f":2},{"t":262145,"n":"_isDisposed","d":1114132,"h":8591048724,"f":2}],"c":[{"p":[{"n":"provider","p":851988},{"n":"state","p":131073},{"n":"parent","p":1114132}],"n":".ctor","o":"$ctor$1","d":1114132,"h":12886016020,"f":8}],"i":[57540609],"d":851988,"h":1114132}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            static $_ActivityLogScope;
            static get ActivityLogScope()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider;
                return $cls.$_ActivityLogScope ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope", ($self) => class ActivityLogScope extends $.$spc.System.Object
                {
                    /*string?*/ _cachedToString = null;
                    /*int*/ static MaxItems = 5;
                    /*KeyValuePair<string, object?>[]*/ _items = null;
                    $ctor$1(/*Activity*/ activity, /*ActivityTrackingOptions*/ activityTrackingOption)
                    {
                        super.$ctor();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(activity !== null, "activity != null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(activityTrackingOption !== 0/*ActivityTrackingOptions.None*/, "activityTrackingOption != ActivityTrackingOptions.None");
                            /*int*/ let count = 0;
                            if ((activityTrackingOption & 1/*ActivityTrackingOptions.SpanId*/) !== 0)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._items, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("SpanId", $.$mel.Microsoft.Extensions.Logging.ActivityExtensions.GetSpanId(activity)), count++);
                            }
                            if ((activityTrackingOption & 2/*ActivityTrackingOptions.TraceId*/) !== 0)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._items, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("TraceId", $.$mel.Microsoft.Extensions.Logging.ActivityExtensions.GetTraceId(activity)), count++);
                            }
                            if ((activityTrackingOption & 4/*ActivityTrackingOptions.ParentId*/) !== 0)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._items, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("ParentId", $.$mel.Microsoft.Extensions.Logging.ActivityExtensions.GetParentId(activity)), count++);
                            }
                            if ((activityTrackingOption & 8/*ActivityTrackingOptions.TraceState*/) !== 0)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._items, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("TraceState", activity.TraceStateString), count++);
                            }
                            if ((activityTrackingOption & 16/*ActivityTrackingOptions.TraceFlags*/) !== 0)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._items, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("TraceFlags", $.$box(activity.ActivityTraceFlags, $.$sdd.System.Diagnostics.ActivityTraceFlags)), count++);
                            }
                            this.Count = count;
                        }
                        return this;
                    }
                    /*int*/ Count = 0;
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        if (index >= this.Count)
                        {
                            throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("index");
                        }
                        return $.$spc.System.Array.$ReadT1.call(this._items, index);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        if ($.$spc.System.String.op_Equality(this._cachedToString, null))
                        {
                            /*StringBuilder*/ let sb = new $.$spc.System.Text.StringBuilder().$ctor$1();
                            sb.Append$2($.$spc.System.Array.$ReadT1.call(this._items, 0).Key);
                            sb.Append$7(/*:*/ 58);
                            sb.Append$19($.$spc.System.Array.$ReadT1.call(this._items, 0).Value);
                            for(/*int*/ let i = 1; i < this.Count; i++)
                            {
                                sb.Append$2(", ");
                                sb.Append$2($.$spc.System.Array.$ReadT1.call(this._items, i).Key);
                                sb.Append$7(/*:*/ 58);
                                sb.Append$19($.$spc.System.Array.$ReadT1.call(this._items, i).Value);
                            }
                            this._cachedToString = $.$spc.System.Text.StringBuilder.ToString.call(sb);
                        }
                        return this._cachedToString;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope.ToString.apply(this, arguments); }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._items = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, [5/*MaxItems*/], null);
                    }
                    static $h = 1048596;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065819668,"f":1},"n":"Count","d":1048596,"h":25770852372,"f":1},{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":38655754260,"f":1},"n":"Item","o":"@$2","d":1048596,"h":34360786964,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1048596,"h":42950721556,"f":32769},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":1048596,"h":47245688852,"f":1}],"l":[{"t":1310721,"n":"_cachedToString","d":1048596,"h":4296015892,"f":2},{"t":655361,"n":"MaxItems","d":1048596,"h":8590983188,"f":34},{"t":0,"n":"_items","d":1048596,"h":12885950484,"f":2}],"c":[{"p":[{"n":"activity","p":196652},{"n":"activityTrackingOption","p":196628}],"n":".ctor","o":"$ctor$1","d":1048596,"h":17180917780,"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31653889],"d":851988,"h":1048596}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityLogScope`; }
                }, $cls, ($v) => $cls.$_ActivityLogScope = $v);
            }
            static $_ActivityBaggageLogScopeWrapper;
            static get ActivityBaggageLogScopeWrapper()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider;
                return $cls.$_ActivityBaggageLogScopeWrapper ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper", ($self) => class ActivityBaggageLogScopeWrapper extends $.$spc.System.Object
                {
                    /*IEnumerable<KeyValuePair<string, string?>>*/ _items = null;
                    /*StringBuilder?*/ _stringBuilder = null;
                    $ctor$1(/*IEnumerable<KeyValuePair<string, string?>>*/ items)
                    {
                        super.$ctor();
                        {
                            this._items = items;
                        }
                        return this;
                    }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator().$ctor$2(this._items.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)]));
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator().$ctor$2(this._items.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)]));
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                /*IEnumerator<KeyValuePair<string, string?>>*/ let enumerator = this._items.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)]);
                                if (!enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    return $.$spc.System.String.Empty;
                                }
                                this._stringBuilder ??= new $.$spc.System.Text.StringBuilder().$ctor$1();
                                this._stringBuilder.Append$2(enumerator.System$Collections$Generic$IEnumerator$$$Current.Key);
                                this._stringBuilder.Append$7(/*:*/ 58);
                                this._stringBuilder.Append$2(enumerator.System$Collections$Generic$IEnumerator$$$Current.Value);
                                while(enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this._stringBuilder.Append$2(", ");
                                    this._stringBuilder.Append$2(enumerator.System$Collections$Generic$IEnumerator$$$Current.Key);
                                    this._stringBuilder.Append$7(/*:*/ 58);
                                    this._stringBuilder.Append$2(enumerator.System$Collections$Generic$IEnumerator$$$Current.Value);
                                }
                                /*string*/ let result = $.$spc.System.Text.StringBuilder.ToString.call(this._stringBuilder);
                                this._stringBuilder.Clear();
                                return result;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.ToString.apply(this, arguments); }
                    static $_BaggageEnumerator;
                    static get BaggageEnumerator()
                    {
                        let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper;
                        return $cls.$_BaggageEnumerator ??= $asm.$nstr("$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator", ($self) => class BaggageEnumerator extends $.$spc.System.ValueType
                        {
                            /*IEnumerator<KeyValuePair<string, string?>>*/  get _enumerator() { return this.$getField(0, 4); }
                            /*IEnumerator<KeyValuePair<string, string?>>*/  set _enumerator(value) { this.$setField(0, 4, value); }
                            $ctor$2(/*IEnumerator<KeyValuePair<string, string?>>*/ enumerator)
                            {
                                super.$ctor$1();
                                {
                                    this._enumerator = enumerator;
                                }
                                return this;
                            }
                            /*KeyValuePair<string, object?> */ get Current()
                            {
                                return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Key, this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Value);
                            }
                            /*object? */ get System$Collections$IEnumerator$Current()
                            {
                                return this.Current;
                            }
                            /*void */ Dispose()
                            {
                                return this._enumerator.System$IDisposable$Dispose();
                            }
                            /*bool */ MoveNext()
                            {
                                return this._enumerator.System$Collections$IEnumerator$MoveNext();
                            }
                            /*void */ Reset()
                            {
                                return this._enumerator.System$Collections$IEnumerator$Reset();
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<string, object?>>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                return this.Current;
                            }
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                return this.Dispose(...arguments);
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                return this.MoveNext(...arguments);
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                            System$Collections$IEnumerator$Reset()
                            {
                                return this.Reset(...arguments);
                            }
                            //default value type constructor
                            $ctor$3()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._enumerator = this._enumerator;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._enumerator = null;
                            }
                            static $h = 983060;
                            static $z = 4;
                            static $f = 0b10000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":17180852244,"f":1},"n":"Current","d":983060,"h":12885884948,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":25770786836,"f":2},"n":"{31784961}.Current","o":"System$Collections$IEnumerator$Current","d":983060,"h":21475819540,"f":2}],"m":[{"r":65537,"n":"Dispose","d":983060,"h":30065754132,"f":1},{"r":262145,"n":"MoveNext","d":983060,"h":34360721428,"f":1},{"r":65537,"n":"Reset","d":983060,"h":38655688724,"f":1}],"l":[{"t":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)).$h,"n":"_enumerator","d":983060,"h":4295950356,"f":2}],"c":[{"p":[{"n":"enumerator","p":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)).$h}],"n":".ctor","o":"$ctor$2","d":983060,"h":8590917652,"f":1},{"n":".ctor","o":"$ctor$3","d":983060,"h":42950656020,"f":1}],"i":[$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,57540609,31784961],"d":917524,"h":983060}; }
                            static get $b() { return $.$spc.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator`; }
                        }, $cls, ($v) => $cls.$_BaggageEnumerator = $v);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    static $h = 917524;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":917524,"h":17180786708,"f":1},{"r":1310721,"n":"ToString","d":917524,"h":25770721300,"f":32769}],"l":[{"t":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)).$h,"n":"_items","d":917524,"h":4295884820,"f":2},{"t":122945537,"n":"_stringBuilder","d":917524,"h":8590852116,"f":2}],"c":[{"p":[{"n":"items","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)).$h}],"n":".ctor","o":"$ctor$1","d":917524,"h":12885819412,"f":1}],"i":[$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31653889],"j":[983060],"d":851988,"h":917524}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper`; }
                }, $cls, ($v) => $cls.$_ActivityBaggageLogScopeWrapper = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.ForEachScope<TState>(System.Action<object?, TState>, TState)
            Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope()
            {
                return this.ForEachScope(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.Push(object?)
            Microsoft$Extensions$Logging$IExternalScopeProvider$Push()
            {
                return this.Push(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._currentScope = new ($.$spc.System.Threading.AsyncLocal$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope))().$ctor$1();
            }
            static $h = 851988;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"callback","p":(TState) => $.$spc.System.Action$$$($.$spc.System.Object, TState).$h},{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"ForEachScope","d":851988,"h":17180721172,"f":131073},{"r":917524,"p":[{"n":"activity","p":196652},{"n":"items","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)).$h}],"n":"GetOrCreateActivityBaggageLogScopeWrapper","d":851988,"h":21475688468,"f":34},{"r":57540609,"p":[{"n":"state","p":131073}],"n":"Push","d":851988,"h":25770655764,"f":1}],"l":[{"t":$.$spc.System.Threading.AsyncLocal$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider.Scope).$h,"n":"_currentScope","d":851988,"h":4295819284,"f":2},{"t":196628,"n":"_activityTrackingOption","d":851988,"h":8590786580,"f":2}],"c":[{"p":[{"n":"activityTrackingOption","p":196628}],"n":".ctor","o":"$ctor$1","d":851988,"h":12885753876,"f":1}],"i":[851989],"j":[1114132,1048596,917524],"h":851988}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.IExternalScopeProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.Logger", ($self) => class Logger extends $.$spc.System.Object
        {
            /*string*/ _categoryName = null;
            $ctor$1(/*string*/ categoryName, /*LoggerInformation[]*/ loggers)
            {
                super.$ctor();
                {
                    this._categoryName = categoryName;
                    this.Loggers = loggers;
                }
                return this;
            }
            /*LoggerInformation[]*/ Loggers = null;
            /*MessageLogger[]?*/ MessageLoggers = null;
            /*ScopeLogger[]?*/ ScopeLoggers = null;
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                /*MessageLogger[]?*/ let loggers = this.MessageLoggers;
                if (loggers === null)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < loggers.length; i++)
                {
                    /*ref readonly MessageLogger*/ let loggerInfo = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mel.Microsoft.Extensions.Logging.MessageLogger, loggers, i, false, true);
                    if (!loggerInfo.$v.IsEnabled(logLevel))
                    {
                        continue;
                    }
                    LoggerLog(logLevel, eventId, loggerInfo.$v.Logger, exception, formatter, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.Exception)), $.$ref(() => state, ));
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mel.Microsoft.Extensions.Logging.Logger.ThrowLoggingError(exceptions);
                }
                /*static void*/  function LoggerLog(/*LogLevel*/ logLevel, /*EventId*/ eventId, /*ILogger*/ logger, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter, /*ref List<Exception>?*/ exceptions, /*in TState*/ state)
                {
                    try
                    {
                        logger.Microsoft$Extensions$Logging$ILogger$Log(TState, logLevel, eventId, state.$v, exception, formatter);
                    }
                    catch(ex)
                    {
                        exceptions.$v ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                        exceptions.$v.Add(ex);
                    }
                }
            }
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                /*MessageLogger[]?*/ let loggers = this.MessageLoggers;
                if (loggers === null)
                {
                    return false;
                }
                /*List<Exception>?*/ let exceptions = null;
                /*int*/ let i = 0;
                for(; i < loggers.length; i++)
                {
                    /*ref readonly MessageLogger*/ let loggerInfo = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mel.Microsoft.Extensions.Logging.MessageLogger, loggers, i, false, true);
                    if (!loggerInfo.$v.IsEnabled(logLevel))
                    {
                        continue;
                    }
                    if (LoggerIsEnabled(logLevel, loggerInfo.$v.Logger, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))))
                    {
                        break;
                    }
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mel.Microsoft.Extensions.Logging.Logger.ThrowLoggingError(exceptions);
                }
                return i < loggers.length ? true : false;
                /*static bool*/  function LoggerIsEnabled(/*LogLevel*/ logLevel, /*ILogger*/ logger, /*ref List<Exception>?*/ exceptions)
                {
                    try
                    {
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                        {
                            return true;
                        }
                    }
                    catch(ex)
                    {
                        exceptions.$v ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                        exceptions.$v.Add(ex);
                    }
                    return false;
                }
            }
            /*IDisposable? */ BeginScope(TState, /*TState*/ state)
            {
                /*ScopeLogger[]?*/ let loggers = this.ScopeLoggers;
                if (loggers === null)
                {
                    return $.$mel.Microsoft.Extensions.Logging.NullScope.Instance;
                }
                if (loggers.length === 1)
                {
                    return $.$spc.System.Array.$ReadT1.call(loggers, 0).CreateScope(TState, state);
                }
                /*var*/ let scope = new $.$mel.Microsoft.Extensions.Logging.Logger.Scope().$ctor$1(loggers.length);
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < loggers.length; i++)
                {
                    /*ref readonly ScopeLogger*/ let scopeLogger = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mel.Microsoft.Extensions.Logging.ScopeLogger, loggers, i, false, true);
                    try
                    {
                        scope.SetDisposable(i, scopeLogger.$v.CreateScope(TState, state));
                    }
                    catch(ex)
                    {
                        exceptions ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                        exceptions.Add(ex);
                    }
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mel.Microsoft.Extensions.Logging.Logger.ThrowLoggingError(exceptions);
                }
                return scope;
            }
            static /*void */ ThrowLoggingError(/*List<Exception>*/ exceptions)
            {
                throw new $.$spc.System.AggregateException().$ctor$10("An error occurred while writing to logger(s).", exceptions);
            }
            /*string */ DebuggerToString()
            {
                return $.$mel.Microsoft.Extensions.Logging.DebuggerDisplayFormatting.DebuggerToString(this._categoryName, this);
            }
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.Logger;
                return $cls.$_Scope ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.Logger.Scope", ($self) => class Scope extends $.$spc.System.Object
                {
                    /*bool*/ _isDisposed = false;
                    /*IDisposable?*/ _disposable0 = null;
                    /*IDisposable?*/ _disposable1 = null;
                    /*IDisposable?[]?*/ _disposable = null;
                    $ctor$1(/*int*/ count)
                    {
                        super.$ctor();
                        {
                            if (count > 2)
                            {
                                this._disposable = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.IDisposable), null, [((count - 2) | 0)], null);
                            }
                        }
                        return this;
                    }
                    /*void */ SetDisposable(/*int*/ index, /*IDisposable?*/ disposable)
                    {
                        switch(index)
                        {
                            case 0:
                            this._disposable0 = disposable;
                            break;
                            case 1:
                            this._disposable1 = disposable;
                            break;
                            default:
                            $.$spc.System.Array.$WriteT1.call(this._disposable, disposable, ((index - 2) | 0));
                            break;
                        }
                    }
                    /*void */ Dispose()
                    {
                        if (!this._isDisposed)
                        {
                            this._disposable0?.System$IDisposable$Dispose();
                            this._disposable1?.System$IDisposable$Dispose();
                            if (this._disposable !== null)
                            {
                                /*int*/ let count = this._disposable.length;
                                for(/*int*/ let index = 0; index !== count; ++index)
                                {
                                    $.$spc.System.Array.$ReadT1.call(this._disposable, index)?.System$IDisposable$Dispose();
                                }
                            }
                            this._isDisposed = true;
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 524308;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"index","p":655361},{"n":"disposable","p":57540609}],"n":"SetDisposable","d":524308,"h":25770328084,"f":1},{"r":65537,"n":"Dispose","d":524308,"h":30065295380,"f":1}],"l":[{"t":262145,"n":"_isDisposed","d":524308,"h":4295491604,"f":2},{"t":57540609,"n":"_disposable0","d":524308,"h":8590458900,"f":2},{"t":57540609,"n":"_disposable1","d":524308,"h":12885426196,"f":2},{"t":0,"n":"_disposable","d":524308,"h":17180393492,"f":2}],"c":[{"p":[{"n":"count","p":655361}],"n":".ctor","o":"$ctor$1","d":524308,"h":21475360788,"f":1}],"i":[57540609],"d":458772,"h":524308}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.Logger.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            Microsoft$Extensions$Logging$ILogger$Log()
            {
                return this.Log(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            Microsoft$Extensions$Logging$ILogger$IsEnabled()
            {
                return this.IsEnabled(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            Microsoft$Extensions$Logging$ILogger$BeginScope()
            {
                return this.BeginScope(...arguments);
            }
            static $h = 458772;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":21475295252,"f":1},"s":{"r":0,"d":0,"h":25770262548,"f":1},"n":"Loggers","d":458772,"h":17180327956,"f":1},{"p":0,"g":{"r":0,"d":0,"h":38655164436,"f":1},"s":{"r":0,"d":0,"h":42950131732,"f":1},"n":"MessageLoggers","d":458772,"h":34360197140,"f":1},{"p":0,"g":{"r":0,"d":0,"h":55835033620,"f":1},"s":{"r":0,"d":0,"h":60130000916,"f":1},"n":"ScopeLoggers","d":458772,"h":51540066324,"f":1}],"m":[{"r":65537,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"state","p":(TState) => TState.$h},{"n":"exception","p":47251457},{"n":"formatter","p":(TState) => $.$spc.System.Func$$$$(TState, $.$spc.System.Exception, $.$spc.System.String).$h}],"g":["TState"],"n":"Log","d":458772,"h":64424968212,"f":131073},{"r":262145,"p":[{"n":"logLevel","p":2293781}],"n":"IsEnabled","d":458772,"h":68719935508,"f":1},{"r":57540609,"p":[{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"BeginScope","d":458772,"h":73014902804,"f":131073},{"r":65537,"p":[{"n":"exceptions","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Exception).$h}],"n":"ThrowLoggingError","d":458772,"h":77309870100,"f":34},{"r":1310721,"n":"DebuggerToString","d":458772,"h":81604837396,"f":8}],"l":[{"t":1310721,"n":"_categoryName","d":458772,"h":4295426068,"f":2}],"c":[{"p":[{"n":"categoryName","p":1310721},{"n":"loggers","p":0}],"n":".ctor","o":"$ctor$1","d":458772,"h":8590393364,"f":1}],"i":[917525],"j":[524308],"h":458772,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":null,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Logger`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.LoggerFactory", ($self) => class LoggerFactory extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<string, Logger>*/ _loggers = null;
            /*List<ProviderRegistration>*/ _providerRegistrations = null;
            /*object*/ _sync = null;
            /*bool*/ _disposed = false;
            /*IDisposable?*/ _changeTokenRegistration = null;
            /*LoggerFilterOptions*/ _filterOptions = null;
            /*IExternalScopeProvider?*/ _scopeProvider = null;
            /*LoggerFactoryOptions*/ _factoryOptions = null;
            $ctor$1()
            {
                this.$ctor$2($.$spc.System.Array.Empty($.$mela.Microsoft.Extensions.Logging.ILoggerProvider));
                {
                }
                return this;
            }
            $ctor$2(/*IEnumerable<ILoggerProvider>*/ providers)
            {
                this.$ctor$4(providers, new $.$mel.Microsoft.Extensions.Logging.StaticFilterOptionsMonitor().$ctor$1(new $.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions().$ctor$1()));
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<ILoggerProvider>*/ providers, /*LoggerFilterOptions*/ filterOptions)
            {
                this.$ctor$4(providers, new $.$mel.Microsoft.Extensions.Logging.StaticFilterOptionsMonitor().$ctor$1(filterOptions));
                {
                }
                return this;
            }
            $ctor$4(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption)
            {
                this.$ctor$5(providers, filterOption, null);
                {
                }
                return this;
            }
            $ctor$5(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption, /*IOptions<LoggerFactoryOptions>?*/ options)
            {
                this.$ctor$6(providers, filterOption, options, null);
                {
                }
                return this;
            }
            $ctor$6(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption, /*IOptions<LoggerFactoryOptions>?*/ options, /*IExternalScopeProvider?*/ scopeProvider)
            {
                super.$ctor();
                {
                    this._scopeProvider = scopeProvider;
                    this._factoryOptions = options === null || options.Microsoft$Extensions$Options$IOptions$$$Value === null ? new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions().$ctor$1() : options.Microsoft$Extensions$Options$IOptions$$$Value;
                    /*ActivityTrackingOptions*/ let ActivityTrackingOptionsMask = ~(1/*ActivityTrackingOptions.SpanId*/ | 2/*ActivityTrackingOptions.TraceId*/ | 4/*ActivityTrackingOptions.ParentId*/ | 16/*ActivityTrackingOptions.TraceFlags*/ | 8/*ActivityTrackingOptions.TraceState*/ | 32/*ActivityTrackingOptions.Tags*/ | 64/*ActivityTrackingOptions.Baggage*/);
                    if ((this._factoryOptions.ActivityTrackingOptions & ActivityTrackingOptionsMask) !== 0)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$mel.System.SR.Format($.$mel.System.SR.InvalidActivityTrackingOptions, $.$box(this._factoryOptions.ActivityTrackingOptions, $.$mel.Microsoft.Extensions.Logging.ActivityTrackingOptions)), "options");
                    }
                    var $en3 = providers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var provider = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddProviderRegistration(provider, false);
                        }
                    }
                    this._changeTokenRegistration = $.$meo.Microsoft.Extensions.Options.OptionsMonitorExtensions.OnChange($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions, filterOption, new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this, this.RefreshFilters));
                    this.RefreshFilters(filterOption.Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue);
                }
                return this;
            }
            static /*ILoggerFactory */ Create(/*Action<ILoggingBuilder>*/ configure)
            {
                /*var*/ let serviceCollection = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollection().$ctor$1();
                $.$mel.Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions.AddLogging$1(serviceCollection, configure);
                /*ServiceProvider*/ let serviceProvider = $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider(serviceCollection);
                /*ILoggerFactory*/ let loggerFactory = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mela.Microsoft.Extensions.Logging.ILoggerFactory, serviceProvider);
                return new $.$mel.Microsoft.Extensions.Logging.LoggerFactory.DisposingLoggerFactory().$ctor$1(loggerFactory, serviceProvider);
            }
            /*void */ RefreshFilters(/*LoggerFilterOptions*/ filterOptions)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._sync)
                    {
                        this._filterOptions = filterOptions;
                        var $en4 = this._loggers.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var registeredLogger = $en4.Current;
                            {
                                /*Logger*/ let logger = registeredLogger.Value;
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._sync)
                }
            }
            /*ILogger */ CreateLogger(/*string*/ categoryName)
            {
                if (this.CheckDisposed())
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$14("LoggerFactory");
                }
                /*Logger?*/ let logger;
                if (!this._loggers.TryGetValue(categoryName, $.$ref(() => logger, ($v) => logger = $v, $.$mel.Microsoft.Extensions.Logging.Logger)))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._sync)
                        {
                            if (!this._loggers.TryGetValue(categoryName, $.$ref(() => logger, ($v) => logger = $v, $.$mel.Microsoft.Extensions.Logging.Logger)))
                            {
                                logger = new $.$mel.Microsoft.Extensions.Logging.Logger().$ctor$1(categoryName, this.CreateLoggers(categoryName));
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                                this._loggers.set_Item(categoryName, logger);
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._sync)
                    }
                }
                return logger;
            }
            /*void */ AddProvider(/*ILoggerProvider*/ provider)
            {
                if (this.CheckDisposed())
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$14("LoggerFactory");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._sync)
                    {
                        this.AddProviderRegistration(provider, true);
                        var $en4 = this._loggers.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var existingLogger = $en4.Current;
                            {
                                /*Logger*/ let logger = existingLogger.Value;
                                /*LoggerInformation[]*/ let loggerInformation = logger.Loggers;
                                /*int*/ let newLoggerIndex = loggerInformation.length;
                                $.$spc.System.Array.Resize($.$mel.Microsoft.Extensions.Logging.LoggerInformation, $.$ref(() => loggerInformation, ($v) => loggerInformation = $v, $.$typeArray($.$mel.Microsoft.Extensions.Logging.LoggerInformation)), ((loggerInformation.length + 1) | 0));
                                $.$spc.System.Array.$WriteT1.call(loggerInformation, new $.$mel.Microsoft.Extensions.Logging.LoggerInformation().$ctor$2(provider, existingLogger.Key), newLoggerIndex);
                                logger.Loggers = loggerInformation;
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._sync)
                }
            }
            /*void */ AddProviderRegistration(/*ILoggerProvider*/ provider, /*bool*/ dispose)
            {
                this._providerRegistrations.Add((() =>
                {
                    //new $.$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration()
                    const $t1 = $.$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration;
                    const $i1 = new $t1();
                    $i1.Provider = provider;
                    $i1.ShouldDispose = dispose;
                    return $i1;
                })());
                let supportsExternalScope;
                if ($.$is(provider, $.$mela.Microsoft.Extensions.Logging.ISupportExternalScope, { set $v(v){ supportsExternalScope = v; } }))
                {
                    this._scopeProvider ??= new $.$mel.Microsoft.Extensions.Logging.LoggerFactoryScopeProvider().$ctor$1(this._factoryOptions.ActivityTrackingOptions);
                    supportsExternalScope.Microsoft$Extensions$Logging$ISupportExternalScope$SetScopeProvider(this._scopeProvider);
                }
            }
            /*LoggerInformation[] */ CreateLoggers(/*string*/ categoryName)
            {
                /*var*/ let loggers = new ($.$spc.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerInformation))().$ctor$2(this._providerRegistrations.Count);
                for(/*int*/ let i = 0; i < this._providerRegistrations.Count; i++)
                {
                    /*var*/ let loggerInformation = new $.$mel.Microsoft.Extensions.Logging.LoggerInformation().$ctor$2(this._providerRegistrations.get_Item(i).Provider, categoryName);
                    if (loggerInformation.Logger !== $.$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger.Instance)
                    {
                        loggers.Add(loggerInformation);
                    }
                }
                return loggers.ToArray();
            }
            /*(MessageLogger[] MessageLoggers, ScopeLogger[]? ScopeLoggers) */ ApplyFilters(/*LoggerInformation[]*/ loggers)
            {
                /*var*/ let messageLoggers = new ($.$spc.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.MessageLogger))().$ctor$1();
                /*List<ScopeLogger>?*/ let scopeLoggers = this._filterOptions.CaptureScopes ? new ($.$spc.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.ScopeLogger))().$ctor$1() : null;
                let $i1 = 0;
                let $arr1 = loggers;
                while ($i1 < $arr1.length)
                {
                    let loggerInformation = $arr1[$i1++];
                    /*LogLevel?*/ let minLevel;
                    /*Func<string?, string?, LogLevel, bool>?*/ let filter;
                    $.$mel.Microsoft.Extensions.Logging.LoggerRuleSelector.Select(this._filterOptions, loggerInformation.ProviderType, loggerInformation.Category, $.$ref(() => minLevel, ($v) => minLevel = $v, $.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel)), $.$ref(() => filter, ($v) => filter = $v, $.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean)));
                    if ((minLevel !== null) && (minLevel > 5/*LogLevel.Critical*/))
                    {
                        continue;
                    }
                    messageLoggers.Add(new $.$mel.Microsoft.Extensions.Logging.MessageLogger().$ctor$2(loggerInformation.Logger, loggerInformation.Category, loggerInformation.ProviderType.FullName, minLevel, filter));
                    if (!loggerInformation.ExternalScope)
                    {
                        scopeLoggers?.Add(new $.$mel.Microsoft.Extensions.Logging.ScopeLogger().$ctor$2(loggerInformation.Logger, null));
                    }
                }
                if (this._scopeProvider !== null)
                {
                    scopeLoggers?.Add(new $.$mel.Microsoft.Extensions.Logging.ScopeLogger().$ctor$2(null, this._scopeProvider));
                }
                return new ($.$spc.System.ValueTuple$$$($.$typeArray($.$mel.Microsoft.Extensions.Logging.MessageLogger), $.$typeArray($.$mel.Microsoft.Extensions.Logging.ScopeLogger)))().$ctor$2(messageLoggers.ToArray(), (scopeLoggers?.ToArray() ?? null));
            }
            /*bool */ CheckDisposed()
            {
                return this._disposed;
            }
            /*void */ Dispose()
            {
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._changeTokenRegistration?.System$IDisposable$Dispose();
                    var $en3 = this._providerRegistrations.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var registration = $en3.Current;
                        {
                            try
                            {
                                if (registration.ShouldDispose)
                                {
                                    registration.Provider.System$IDisposable$Dispose();
                                }
                            }
                            catch($e)
                            {
                            }
                        }
                    }
                }
            }
            static $_ProviderRegistration;
            static get ProviderRegistration()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactory;
                return $cls.$_ProviderRegistration ??= $asm.$nstr("$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration", ($self) => class ProviderRegistration extends $.$spc.System.ValueType
                {
                    /*ILoggerProvider*/  get Provider() { return this.$getField(0, 4); }
                    /*ILoggerProvider*/  set Provider(value) { this.$setField(0, 4, value); }
                    /*bool*/  get ShouldDispose() { return this.$getField(4, 1); }
                    /*bool*/  set ShouldDispose(value) { this.$setField(4, 1, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Provider = this.Provider;
                        copy.ShouldDispose = this.ShouldDispose;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Provider = null;
                        this.ShouldDispose = false;
                    }
                    static $h = 720916;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1114133,"n":"Provider","d":720916,"h":4295688212,"f":1},{"t":262145,"n":"ShouldDispose","d":720916,"h":8590655508,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":720916,"h":12885622804,"f":1}],"d":589844,"h":720916}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration`; }
                }, $cls, ($v) => $cls.$_ProviderRegistration = $v);
            }
            static $_DisposingLoggerFactory;
            static get DisposingLoggerFactory()
            {
                let $cls = $.$mel.Microsoft.Extensions.Logging.LoggerFactory;
                return $cls.$_DisposingLoggerFactory ??= $asm.$ncls("$mel.Microsoft.Extensions.Logging.LoggerFactory.DisposingLoggerFactory", ($self) => class DisposingLoggerFactory extends $.$spc.System.Object
                {
                    /*ILoggerFactory*/ _loggerFactory = null;
                    /*ServiceProvider*/ _serviceProvider = null;
                    $ctor$1(/*ILoggerFactory*/ loggerFactory, /*ServiceProvider*/ serviceProvider)
                    {
                        super.$ctor();
                        {
                            this._loggerFactory = loggerFactory;
                            this._serviceProvider = serviceProvider;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        this._serviceProvider.Dispose();
                    }
                    /*ILogger */ CreateLogger(/*string*/ categoryName)
                    {
                        return this._loggerFactory.Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger(categoryName);
                    }
                    /*void */ AddProvider(/*ILoggerProvider*/ provider)
                    {
                        this._loggerFactory.Microsoft$Extensions$Logging$ILoggerFactory$AddProvider(provider);
                    }
                    //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.CreateLogger(string)
                    Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger()
                    {
                        return this.CreateLogger(...arguments);
                    }
                    //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.AddProvider(Microsoft.Extensions.Logging.ILoggerProvider)
                    Microsoft$Extensions$Logging$ILoggerFactory$AddProvider()
                    {
                        return this.AddProvider(...arguments);
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 655380;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Dispose","d":655380,"h":17180524564,"f":1},{"r":917525,"p":[{"n":"categoryName","p":1310721}],"n":"CreateLogger","d":655380,"h":21475491860,"f":1},{"r":65537,"p":[{"n":"provider","p":1114133}],"n":"AddProvider","d":655380,"h":25770459156,"f":1}],"l":[{"t":1048597,"n":"_loggerFactory","d":655380,"h":4295622676,"f":2},{"t":3014660,"n":"_serviceProvider","d":655380,"h":8590589972,"f":2}],"c":[{"p":[{"n":"loggerFactory","p":1048597},{"n":"serviceProvider","p":3014660}],"n":".ctor","o":"$ctor$1","d":655380,"h":12885557268,"f":1}],"i":[1048597,57540609],"d":589844,"h":655380}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggerFactory, $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactory.DisposingLoggerFactory`; }
                }, $cls, ($v) => $cls.$_DisposingLoggerFactory = $v);
            }
            /*string */ DebuggerToString()
            {
                return `Providers = ${this._providerRegistrations.Count}, ${this._filterOptions.DebuggerToString()}`;
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.CreateLogger(string)
            Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger()
            {
                return this.CreateLogger(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.AddProvider(Microsoft.Extensions.Logging.ILoggerProvider)
            Microsoft$Extensions$Logging$ILoggerFactory$AddProvider()
            {
                return this.AddProvider(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._loggers = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mel.Microsoft.Extensions.Logging.Logger))().$ctor$4($.$spc.System.StringComparer.Ordinal);
                this._providerRegistrations = new ($.$spc.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration))().$ctor$1();
                this._sync = new $.$spc.System.Object().$ctor();
            }
            static $h = 589844;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1048597,"p":[{"n":"configure","p":$.$spc.System.Action$$($.$mela.Microsoft.Extensions.Logging.ILoggingBuilder).$h}],"n":"Create","d":589844,"h":64425099284,"f":33},{"r":65537,"p":[{"n":"filterOptions","p":1179668}],"n":"RefreshFilters","d":589844,"h":68720066580,"f":2},{"r":917525,"p":[{"n":"categoryName","p":1310721}],"n":"CreateLogger","d":589844,"h":73015033876,"f":1},{"r":65537,"p":[{"n":"provider","p":1114133}],"n":"AddProvider","d":589844,"h":77310001172,"f":1},{"r":65537,"p":[{"n":"provider","p":1114133},{"n":"dispose","p":262145}],"n":"AddProviderRegistration","d":589844,"h":81604968468,"f":2},{"r":0,"p":[{"n":"categoryName","p":1310721}],"n":"CreateLoggers","d":589844,"h":85899935764,"f":2},{"r":$.$spc.System.ValueTuple$$$($.$typeArray($.$mel.Microsoft.Extensions.Logging.MessageLogger), $.$typeArray($.$mel.Microsoft.Extensions.Logging.ScopeLogger)).$h,"p":[{"n":"loggers","p":0}],"n":"ApplyFilters","d":589844,"h":90194903060,"f":2},{"r":262145,"n":"CheckDisposed","d":589844,"h":94489870356,"f":132},{"r":65537,"n":"Dispose","d":589844,"h":98784837652,"f":1},{"r":1310721,"n":"DebuggerToString","d":589844,"h":111669739540,"f":2}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mel.Microsoft.Extensions.Logging.Logger).$h,"n":"_loggers","d":589844,"h":4295557140,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$mel.Microsoft.Extensions.Logging.LoggerFactory.ProviderRegistration).$h,"n":"_providerRegistrations","d":589844,"h":8590524436,"f":2},{"t":131073,"n":"_sync","d":589844,"h":12885491732,"f":2},{"t":262145,"n":"_disposed","d":589844,"h":17180459028,"f":2},{"t":57540609,"n":"_changeTokenRegistration","d":589844,"h":21475426324,"f":2},{"t":1179668,"n":"_filterOptions","d":589844,"h":25770393620,"f":2},{"t":851989,"n":"_scopeProvider","d":589844,"h":30065360916,"f":2},{"t":786452,"n":"_factoryOptions","d":589844,"h":34360328212,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":589844,"h":38655295508,"f":1},{"p":[{"n":"providers","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h}],"n":".ctor","o":"$ctor$2","d":589844,"h":42950262804,"f":1},{"p":[{"n":"providers","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h},{"n":"filterOptions","p":1179668}],"n":".ctor","o":"$ctor$3","d":589844,"h":47245230100,"f":1},{"p":[{"n":"providers","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h},{"n":"filterOption","p":$.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h}],"n":".ctor","o":"$ctor$4","d":589844,"h":51540197396,"f":1},{"p":[{"n":"providers","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h},{"n":"filterOption","p":$.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h},{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions).$h}],"n":".ctor","o":"$ctor$5","d":589844,"h":55835164692,"f":1},{"p":[{"n":"providers","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.ILoggerProvider).$h},{"n":"filterOption","p":$.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h},{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFactoryOptions).$h,"f":65},{"n":"scopeProvider","p":851989,"f":65}],"n":".ctor","o":"$ctor$6","d":589844,"h":60130131988,"f":1}],"i":[1048597,57540609],"j":[720916,655380],"h":589844,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":null,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggerFactory, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactory`; }
        });
        
        $asm.$str("$mel.Microsoft.Extensions.Logging.MessageLogger", ($self) => class MessageLogger extends $.$spc.System.ValueType
        {
            $ctor$2(/*ILogger*/ logger, /*string*/ category, /*string?*/ providerTypeFullName, /*LogLevel?*/ minLevel, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                super.$ctor$1();
                {
                    this.Logger = logger;
                    this.Category = category;
                    this.ProviderTypeFullName = providerTypeFullName;
                    this.MinLevel = minLevel;
                    this.Filter = filter;
                }
                return this;
            }
            /*ILogger*/ Logger = null;
            /*string*/ Category = null;
            /*string?*/ ProviderTypeFullName = null;
            /*LogLevel?*/ MinLevel = null;
            /*Func<string?, string?, LogLevel, bool>?*/ Filter = null;
            /*bool */ IsEnabled(/*LogLevel*/ level)
            {
                if (this.MinLevel !== null && level < this.MinLevel)
                {
                    return false;
                }
                if (this.Filter !== null)
                {
                    return this.Filter.Invoke(this.ProviderTypeFullName, this.Category, level);
                }
                return true;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.Category = this.Category;
                copy.ProviderTypeFullName = this.ProviderTypeFullName;
                copy.MinLevel = this.MinLevel;
                copy.Filter = this.Filter;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MinLevel = null;
            }
            static $h = 1572884;
            static $z = 21;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":917525,"g":{"r":0,"d":0,"h":17181442068,"f":1},"n":"Logger","d":1572884,"h":12886474772,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066343956,"f":1},"n":"Category","d":1572884,"h":25771376660,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42951245844,"f":2},"n":"ProviderTypeFullName","d":1572884,"h":38656278548,"f":2},{"p":$.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,"g":{"r":0,"d":0,"h":55836147732,"f":1},"n":"MinLevel","d":1572884,"h":51541180436,"f":1},{"p":$.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h,"g":{"r":0,"d":0,"h":68721049620,"f":1},"n":"Filter","d":1572884,"h":64426082324,"f":1}],"m":[{"r":262145,"p":[{"n":"level","p":2293781}],"n":"IsEnabled","d":1572884,"h":73016016916,"f":1}],"c":[{"p":[{"n":"logger","p":917525},{"n":"category","p":1310721},{"n":"providerTypeFullName","p":1310721},{"n":"minLevel","p":$.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h},{"n":"filter","p":$.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogLevel, $.$spc.System.Boolean).$h}],"n":".ctor","o":"$ctor$2","d":1572884,"h":4296540180,"f":1},{"n":".ctor","o":"$ctor$3","d":1572884,"h":77310984212,"f":1}],"h":1572884}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Logging.MessageLogger`; }
        });
        
        $asm.$str("$mel.Microsoft.Extensions.Logging.ScopeLogger", ($self) => class ScopeLogger extends $.$spc.System.ValueType
        {
            $ctor$2(/*ILogger?*/ logger, /*IExternalScopeProvider?*/ externalScopeProvider)
            {
                super.$ctor$1();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(logger !== null || externalScopeProvider !== null, "Logger can't be null when there isn't an ExternalScopeProvider");
                    this.Logger = logger;
                    this.ExternalScopeProvider = externalScopeProvider;
                }
                return this;
            }
            /*ILogger?*/ Logger = null;
            /*IExternalScopeProvider?*/ ExternalScopeProvider = null;
            /*IDisposable? */ CreateScope(TState, /*TState*/ state)
            {
                if (this.ExternalScopeProvider !== null)
                {
                    return this.ExternalScopeProvider.Microsoft$Extensions$Logging$IExternalScopeProvider$Push($.$box(state, TState));
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this.Logger !== null, "Logger != null");
                return this.Logger.Microsoft$Extensions$Logging$ILogger$BeginScope(TState, state);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.ExternalScopeProvider = this.ExternalScopeProvider;
                return copy;
            }
            static $h = 1835028;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":917525,"g":{"r":0,"d":0,"h":17181704212,"f":1},"n":"Logger","d":1835028,"h":12886736916,"f":1},{"p":851989,"g":{"r":0,"d":0,"h":30066606100,"f":1},"n":"ExternalScopeProvider","d":1835028,"h":25771638804,"f":1}],"m":[{"r":57540609,"p":[{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"CreateScope","d":1835028,"h":34361573396,"f":131073}],"c":[{"p":[{"n":"logger","p":917525},{"n":"externalScopeProvider","p":851989}],"n":".ctor","o":"$ctor$2","d":1835028,"h":4296802324,"f":1},{"n":".ctor","o":"$ctor$3","d":1835028,"h":38656540692,"f":1}],"h":1835028}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ScopeLogger`; }
        });
        
        $asm.$str("$mel.Microsoft.Extensions.Logging.LoggerInformation", ($self) => class LoggerInformation extends $.$spc.System.ValueType
        {
            $ctor$2(/*ILoggerProvider*/ provider, /*string*/ category)
            {
                this.$ctor$3();
                {
                    this.ProviderType = $.$spc.System.Object.GetType.call(provider);
                    this.Logger = provider.Microsoft$Extensions$Logging$ILoggerProvider$CreateLogger(category);
                    this.Category = category;
                    this.ExternalScope = $.$is(provider, $.$mela.Microsoft.Extensions.Logging.ISupportExternalScope);
                }
                return this;
            }
            /*ILogger*/ Logger = null;
            /*string*/ Category = null;
            /*Type*/ ProviderType = null;
            /*bool*/ ExternalScope = false;
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.Category = this.Category;
                copy.ProviderType = this.ProviderType;
                copy.ExternalScope = this.ExternalScope;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ExternalScope = false;
            }
            static $h = 1310740;
            static $z = 13;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":917525,"g":{"r":0,"d":0,"h":17181179924,"f":1},"n":"Logger","d":1310740,"h":12886212628,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066081812,"f":1},"n":"Category","d":1310740,"h":25771114516,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":42950983700,"f":1},"n":"ProviderType","d":1310740,"h":38656016404,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835885588,"f":1},"n":"ExternalScope","d":1310740,"h":51540918292,"f":1}],"c":[{"p":[{"n":"provider","p":1114133},{"n":"category","p":1310721}],"n":".ctor","o":"$ctor$2","d":1310740,"h":4296278036,"f":1},{"n":".ctor","o":"$ctor$3","d":1310740,"h":60130852884,"f":1}],"h":1310740}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerInformation`; }
        });
        
        $asm.$str("$mel.Microsoft.Extensions.Logging.ActivityTrackingOptions", ($self) => class ActivityTrackingOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static SpanId = 1;
            static TraceId = 2;
            static ParentId = 4;
            static TraceState = 8;
            static TraceFlags = 16;
            static Tags = 32;
            static Baggage = 64;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "SpanId": 1n,
                    "TraceId": 2n,
                    "ParentId": 4n,
                    "TraceState": 8n,
                    "TraceFlags": 16n,
                    "Tags": 32n,
                    "Baggage": 64n
                };
            }
            static $h = 196628;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":196628,"n":"None","d":196628,"h":4295163924,"f":33},{"t":196628,"n":"SpanId","d":196628,"h":8590131220,"f":33},{"t":196628,"n":"TraceId","d":196628,"h":12885098516,"f":33},{"t":196628,"n":"ParentId","d":196628,"h":17180065812,"f":33},{"t":196628,"n":"TraceState","d":196628,"h":21475033108,"f":33},{"t":196628,"n":"TraceFlags","d":196628,"h":25770000404,"f":33},{"t":196628,"n":"Tags","d":196628,"h":30064967700,"f":33},{"t":196628,"n":"Baggage","d":196628,"h":34359934996,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":196628,"h":38654902292,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":196628,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ActivityTrackingOptions`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.StaticFilterOptionsMonitor", ($self) => class StaticFilterOptionsMonitor extends $.$spc.System.Object
        {
            $ctor$1(/*LoggerFilterOptions*/ currentValue)
            {
                super.$ctor();
                {
                    this.CurrentValue = $.$firstOf(currentValue, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("currentValue") });
                }
                return this;
            }
            /*IDisposable? */ OnChange(/*Action<LoggerFilterOptions, string>*/ listener)
            {
                return null;
            }
            /*LoggerFilterOptions */ Get(/*string?*/ name)
            {
                return this.CurrentValue;
            }
            /*LoggerFilterOptions*/ CurrentValue = null;
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.CurrentValue.get
            get Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue()
            {
                return this.CurrentValue;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.Get(string?)
            Microsoft$Extensions$Options$IOptionsMonitor$$$Get()
            {
                return this.Get(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.OnChange(System.Action<Microsoft.Extensions.Logging.LoggerFilterOptions, string?>)
            Microsoft$Extensions$Options$IOptionsMonitor$$$OnChange()
            {
                return this.OnChange(...arguments);
            }
            static $h = 1900564;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1179668,"g":{"r":0,"d":0,"h":25771704340,"f":1},"n":"CurrentValue","d":1900564,"h":21476737044,"f":1}],"m":[{"r":57540609,"p":[{"n":"listener","p":$.$spc.System.Action$$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions, $.$spc.System.String).$h}],"n":"OnChange","d":1900564,"h":8591835156,"f":1},{"r":1179668,"p":[{"n":"name","p":1310721}],"n":"Get","d":1900564,"h":12886802452,"f":1}],"c":[{"p":[{"n":"currentValue","p":1179668}],"n":".ctor","o":"$ctor$1","d":1900564,"h":4296867860,"f":1}],"i":[$.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h],"h":1900564}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.StaticFilterOptionsMonitor`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions", ($self) => class DefaultLoggerLevelConfigureOptions extends $.$meo.Microsoft.Extensions.Options.ConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions)
        {
            $ctor$2(/*LogLevel*/ level)
            {
                super.$ctor$1(new ($.$spc.System.Action$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return options.MinLevel = level;
                }, {"r":65537,"p":[{"n":"options","p":1179668}],"n":"","d":327700,"h":0,"f":1048578}));
                {
                }
                return this;
            }
            static $h = 327700;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"c":[{"p":[{"n":"level","p":2293781}],"n":".ctor","o":"$ctor$2","d":327700,"h":4295294996,"f":1}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions).$h],"h":327700}; }
            static get $b() { return $.$meo.Microsoft.Extensions.Options.ConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mel.Microsoft.Extensions.Logging.LoggerFilterOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"))