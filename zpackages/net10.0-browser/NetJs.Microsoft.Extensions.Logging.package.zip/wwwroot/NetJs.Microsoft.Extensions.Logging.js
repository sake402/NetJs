
//--TRIMMABLE-BOUNDARY-START(89)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $sttp, $sdd, $mexla, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    let $uyGNgd;
    let $CZSKHd;
    let $CtFRgd;
    let $HbhcXe;
    let $RozTrh;
    let $GtOazk;
    let $sFpWWh;
    let $AhYWke;
    let $XGlHWc;
    let $WGxzDb;
    let $ypcVjl;
    let $JrsNHj;
    let $zJxeTj;
    let $fVgYba;
    let $ySmcqh;
    let $nZZDIe;
    let $TYgBcd;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Logging", 
    {
  "h": 89,
  "f": "Microsoft.Extensions.Logging",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 1179736,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 2555992,
          "t": 188547073
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Logging",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Logging",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(983129)
        $asm.$cls(`$mexl.MEL.LoggerFactoryOptions`, ($self) => class LoggerFactoryOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590917721)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917721);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917721)
            
            //--TRIMMABLE-BOUNDARY-START(12885885017)
            /*ActivityTrackingOptions*/ ActivityTrackingOptions = 0;
            //--TRIMMABLE-BOUNDARY-END(12885885017)
            
            //--TRIMMABLE-BOUNDARY-START(8590917721)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590917721)
            
            static $h = 983129;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885885017),
    {
      "p": 196697,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475819609,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065754201,
        "f": 83886081
      },
      "n": "ActivityTrackingOptions",
      "d": 983129,
      "h": 12885885017,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885885017)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917721),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983129,
      "h": 8590917721,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917721)
  ],
  "h": 983129,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "ActivityTrackingOptions = {ActivityTrackingOptions}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactoryOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactoryOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983129)
        
        

        //--TRIMMABLE-BOUNDARY-START(262233)
        $asm.$cls(`$mexl.MEL.DebuggerDisplayFormatting`, ($self) => class DebuggerDisplayFormatting
        {
            //--TRIMMABLE-BOUNDARY-START(8590196825)
            static /*string */ DebuggerToString(/*string*/ name, /*ILogger*/ logger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogLevel?*/ let minimumLevel = $.$mexl.MEL.DebuggerDisplayFormatting.CalculateEnabledLogLevel(logger);
                /*var*/ let debugText = `Name = \"${$.$strNN(name)}\"`;
                if (minimumLevel !== null)
                {
                    debugText += `, MinLevel = ${$.$strNN(minimumLevel)}`;
                }
                else 
                {
                    debugText += `, Enabled = false`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196825)
            
            //--TRIMMABLE-BOUNDARY-START(4295229529)
            static /*LogLevel? */ CalculateEnabledLogLevel(/*ILogger*/ logger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<LogLevel>*/ let logLevels = new ($.$$.S.ReadOnlySpan$$($.$mexla.MEL.LogLevel))().$ctor$7([ 5/*LogLevel.Critical*/, 4/*LogLevel.Error*/, 3/*LogLevel.Warning*/, 2/*LogLevel.Information*/, 1/*LogLevel.Debug*/, 0/*LogLevel.Trace*/ ]);
                /*LogLevel?*/ let minimumLevel = null;
                let $en1 = logLevels.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let logLevel = $en1.Current.$v;
                    {
                        if (!logger.MEL$ILogger$IsEnabled(logLevel))
                        {
                            break;
                        }
                        minimumLevel = logLevel;
                    }
                }
                return minimumLevel;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229529)
            
            static $h = 262233;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590196825),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": "DebuggerToString",
      "d": 262233,
      "h": 8590196825,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590196825),
//--TRIMMABLE-BOUNDARY-START(4295229529),
    {
      "r": $.$typeNullable($.$mexla.MEL.LogLevel).$h,
      "p": [
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": "CalculateEnabledLogLevel",
      "d": 262233,
      "h": 4295229529,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295229529)
  ],
  "h": 262233
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.DebuggerDisplayFormatting`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}DebuggerDisplayFormatting`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262233)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376345)
        $asm.$cls(`$mexl.MEL.LoggerFilterOptions`, ($self) => class LoggerFilterOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181245529)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181245529);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181245529)
            
            //--TRIMMABLE-BOUNDARY-START(21476212825)
            /*bool*/ CaptureScopes = false;
            //--TRIMMABLE-BOUNDARY-END(21476212825)
            
            //--TRIMMABLE-BOUNDARY-START(64425885785)
            /*LogLevel*/ MinLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(64425885785)
            
            //--TRIMMABLE-BOUNDARY-START(68720853081)
            /*IList<LoggerFilterRule> */ get Rules()
            {
                return this.RulesInternal;
            }
            //--TRIMMABLE-BOUNDARY-END(68720853081)
            
            //--TRIMMABLE-BOUNDARY-START(73015820377)
            /*List<LoggerFilterRule>*/ RulesInternal = null;
            //--TRIMMABLE-BOUNDARY-END(73015820377)
            
            //--TRIMMABLE-BOUNDARY-START(25771180121)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let debugText;
                if (this.MinLevel !== 6/*LogLevel.None*/)
                {
                    debugText = `MinLevel = ${$.$strNN($.$$.S.Enum.ToStringT($.$mexla.MEL.LogLevel, $.$$.S.UInt32, this.MinLevel))}`;
                }
                else 
                {
                    debugText = `Enabled = false`;
                }
                if (this.Rules.SCG$ICollection$$$Count > 0)
                {
                    debugText += `, Rules = ${$.$strNN(this.Rules.SCG$ICollection$$$Count)}`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(25771180121)
            
            //--TRIMMABLE-BOUNDARY-START(17181245529)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181245529)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21476212825)
                this.CaptureScopes = true;
                //--TRIMMABLE-BOUNDARY-END(21476212825)
                
                //--TRIMMABLE-BOUNDARY-START(73015820377)
                this.RulesInternal = new ($.$$.SCG.List$$($.$mexl.MEL.LoggerFilterRule))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(73015820377)
                
            }
            static $h = 1376345;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476212825),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361114713,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605754969,
        "f": 83886081
      },
      "n": "CaptureScopes",
      "d": 1376345,
      "h": 21476212825,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476212825),
//--TRIMMABLE-BOUNDARY-START(64425885785),
    {
      "p": 2293848,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951049305,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195689561,
        "f": 83886081
      },
      "n": "MinLevel",
      "d": 1376345,
      "h": 64425885785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425885785),
//--TRIMMABLE-BOUNDARY-START(68720853081),
    {
      "p": $.$$.SCG.IList$$($.$mexl.MEL.LoggerFilterRule).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540983897,
        "f": 50331649
      },
      "n": "Rules",
      "d": 1376345,
      "h": 68720853081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720853081),
//--TRIMMABLE-BOUNDARY-START(73015820377),
    {
      "p": $.$$.SCG.List$$($.$mexl.MEL.LoggerFilterRule).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130918489,
        "f": 50331656
      },
      "n": "RulesInternal",
      "d": 1376345,
      "h": 73015820377,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(73015820377)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771180121),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 1376345,
      "h": 25771180121,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25771180121)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181245529),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376345,
      "h": 17181245529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181245529)
  ],
  "h": 1376345,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFilterOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFilterOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376345)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441881)
        $asm.$cls(`$mexl.MEL.LoggerFilterRule`, ($self) => class LoggerFilterRule extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476278361)
            $ctor$1(/*string?*/ providerName, /*string?*/ categoryName, /*LogLevel?*/ logLevel, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476278361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ProviderName = providerName;
                    this.CategoryName = categoryName;
                    this.LogLevel = logLevel;
                    this.Filter = filter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278361)
            
            //--TRIMMABLE-BOUNDARY-START(73015885913)
            /*string?*/ ProviderName = null;
            //--TRIMMABLE-BOUNDARY-END(73015885913)
            
            //--TRIMMABLE-BOUNDARY-START(25771245657)
            /*string?*/ CategoryName = null;
            //--TRIMMABLE-BOUNDARY-END(25771245657)
            
            //--TRIMMABLE-BOUNDARY-START(68720918617)
            /*LogLevel?*/ LogLevel = null;
            //--TRIMMABLE-BOUNDARY-END(68720918617)
            
            //--TRIMMABLE-BOUNDARY-START(30066212953)
            /*Func<string?, string?, LogLevel, bool>?*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(30066212953)
            
            //--TRIMMABLE-BOUNDARY-START(77310853209)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("ProviderName")}: '${$.$strNN(this.ProviderName)}', ${$.$strNN("CategoryName")}: '${$.$strNN(this.CategoryName)}', ${$.$strNN("LogLevel")}: '${$.$strNN(this.LogLevel)}', ${$.$strNN("Filter")}: '${$.$strNN($.$dspc(this.Filter, $.$$.S.Object, ($t) => $t.ToString))}'`;
            }
            //--TRIMMABLE-BOUNDARY-END(77310853209)
            
            static $h = 1441881;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015885913),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425951321,
        "f": 50331649
      },
      "n": "ProviderName",
      "d": 1441881,
      "h": 73015885913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015885913),
//--TRIMMABLE-BOUNDARY-START(25771245657),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656147545,
        "f": 50331649
      },
      "n": "CategoryName",
      "d": 1441881,
      "h": 25771245657,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771245657),
//--TRIMMABLE-BOUNDARY-START(68720918617),
    {
      "p": $.$typeNullable($.$mexla.MEL.LogLevel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836016729,
        "f": 50331649
      },
      "n": "LogLevel",
      "d": 1441881,
      "h": 68720918617,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720918617),
//--TRIMMABLE-BOUNDARY-START(30066212953),
    {
      "p": $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246082137,
        "f": 50331649
      },
      "n": "Filter",
      "d": 1441881,
      "h": 30066212953,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066212953)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310853209),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1441881,
      "h": 77310853209,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310853209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476278361),
    {
      "p": [
        {
          "n": "providerName",
          "p": 1310721
        },
        {
          "n": "categoryName",
          "p": 1310721
        },
        {
          "n": "logLevel",
          "p": $.$typeNullable($.$mexla.MEL.LogLevel).$h
        },
        {
          "n": "filter",
          "p": $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441881,
      "h": 21476278361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476278361)
  ],
  "h": 1441881
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFilterRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFilterRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441881)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162777)
        $asm.$cls(`$mexl.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(115966279769)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(115966279769)
            
            //--TRIMMABLE-BOUNDARY-START(107376345177)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(107376345177)
            
            //--TRIMMABLE-BOUNDARY-START(111671312473)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606541401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mexl.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Logging", $.$mexl.S.SR.$type.Assembly);
                    $.$mexl.S.SR.s_resourceManager = temp;
                }
                return $.$mexl.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(111671312473)
            
            //--TRIMMABLE-BOUNDARY-START(8592097369)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836737625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexl.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851181657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexl.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8592097369)
            
            //--TRIMMABLE-BOUNDARY-START(98786410585)
            static /*string */ get InvalidActivityTrackingOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426672217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} is invalid ActivityTrackingOptions value.";
            }
            //--TRIMMABLE-BOUNDARY-END(98786410585)
            
            //--TRIMMABLE-BOUNDARY-START(47246803033)
            static /*string */ FormatInvalidActivityTrackingOptions(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246803033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("{0} is invalid ActivityTrackingOptions value.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(47246803033)
            
            //--TRIMMABLE-BOUNDARY-START(103081377881)
            static /*string */ get MoreThanOneWildcard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016606809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only one wildcard character is allowed in category name.";
            }
            //--TRIMMABLE-BOUNDARY-END(103081377881)
            
            //--TRIMMABLE-BOUNDARY-START(120261247065)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(120261247065)
            
            //--TRIMMABLE-BOUNDARY-START(94491443289)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94491443289);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491443289)
            
            //--TRIMMABLE-BOUNDARY-START(133146148953)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146148953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146148953)
            
            //--TRIMMABLE-BOUNDARY-START(90196475993)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196475993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexl.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mexl.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(90196475993)
            
            //--TRIMMABLE-BOUNDARY-START(85901508697)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901508697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mexl.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(85901508697)
            
            //--TRIMMABLE-BOUNDARY-START(38656868441)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656868441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38656868441)
            
            //--TRIMMABLE-BOUNDARY-START(34361901145)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34361901145)
            
            //--TRIMMABLE-BOUNDARY-START(30066933849)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30066933849)
            
            //--TRIMMABLE-BOUNDARY-START(42951835737)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951835737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mexl.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN($.$strNN(resourceFormat) + ", ") + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42951835737)
            
            //--TRIMMABLE-BOUNDARY-START(21476999257)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476999257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21476999257)
            
            //--TRIMMABLE-BOUNDARY-START(17182031961)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182031961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17182031961)
            
            //--TRIMMABLE-BOUNDARY-START(12887064665)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887064665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12887064665)
            
            //--TRIMMABLE-BOUNDARY-START(25771966553)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771966553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mexl.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN($.$strNN(resourceFormat) + ", ") + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25771966553)
            
            //--TRIMMABLE-BOUNDARY-START(4297130073)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297130073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(120261247065)
                    this.s_usingResourceKeys = $.$mexl.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(120261247065)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297130073)
            
            static $h = 2162777;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2162777
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162777)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966169)
        $asm.$cls(`$mexl.MEL.ProviderAliasUtilities`, ($self) => class ProviderAliasUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(4296933465)
            /*string*/ static AliasAttributeTypeFullName = null;
            //--TRIMMABLE-BOUNDARY-END(4296933465)
            
            //--TRIMMABLE-BOUNDARY-START(8591900761)
            static /*string? */ GetAlias(/*Type*/ providerType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IList<CustomAttributeData>*/ let attributes = $.$$.SR.CustomAttributeData.GetCustomAttributes$1(providerType);
                for(/*int*/ let i = 0; i < attributes.SCG$ICollection$$$Count; i++)
                {
                    /*CustomAttributeData*/ let attributeData = attributes.SCG$IList$$$get_Item(i);
                    if (attributeData.AttributeType.FullName === "Microsoft.Extensions.Logging.ProviderAliasAttribute"/*AliasAttributeTypeFullName*/ && attributeData.ConstructorArguments.SCG$ICollection$$$Count > 0)
                    {
                        /*CustomAttributeTypedArgument*/ let arg = attributeData.ConstructorArguments.SCG$IList$$$get_Item(0);
                        $.$$.SD.Debug.Assert$4(arg.ArgumentType === $.$$.S.String.$type, "arg.ArgumentType == typeof(string)");
                        /*object?*/ let __ca1__;
                        return _ = ((__ca1__ = arg.Value) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8591900761)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4296933465)
                    this.AliasAttributeTypeFullName = "Microsoft.Extensions.Logging.ProviderAliasAttribute";
                    //--TRIMMABLE-BOUNDARY-END(4296933465)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1966169;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591900761),
    {
      "r": 1310721,
      "p": [
        {
          "n": "providerType",
          "p": 188547073
        }
      ],
      "n": "GetAlias",
      "d": 1966169,
      "h": 8591900761,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591900761)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296933465),
    {
      "t": 1310721,
      "n": "AliasAttributeTypeFullName",
      "d": 1966169,
      "h": 4296933465,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296933465)
  ],
  "h": 1966169
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.ProviderAliasUtilities`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}ProviderAliasUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966169)
        
        

        //--TRIMMABLE-BOUNDARY-START(65625)
        $asm.$cls(`$mexl.MED.LoggingServiceCollectionExtensions`, ($self) => class LoggingServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590000217)
            static /*IServiceCollection */ AddLogging$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexl.MED.LoggingServiceCollectionExtensions.AddLogging(services, new ($.$$.S.Action$$($.$mexla.MEL.ILoggingBuilder))().$ctor(this,  (/*builder*/ builder) =>
                {
                }, $CZSKHd ??= {"r":65537,"p":[{"n":"builder","p":1179736}],"n":"","d":65625,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590000217)
            
            //--TRIMMABLE-BOUNDARY-START(4295032921)
            static /*IServiceCollection */ AddLogging(/*this IServiceCollection*/ services, /*Action<ILoggingBuilder>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$3($.$mexla.MEL.ILoggerFactory, $.$mexl.MEL.LoggerFactory));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$2($.$mexla.MEL.ILogger$$().$type, $.$mexla.MEL.Logger$$().$type));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddEnumerable(services, $.$mxdi.MED.ServiceDescriptor.Singleton$6($.$meo.MEO.IConfigureOptions$$($.$mexl.MEL.LoggerFilterOptions), new $.$mexl.MEL.DefaultLoggerLevelConfigureOptions().$ctor$2(2/*LogLevel.Information*/)));
                configure.Invoke(new $.$mexl.MEL.LoggingBuilder().$ctor$1(services));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032921)
            
            static $h = 65625;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000217),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddLogging",
      "o": "@$1",
      "d": 65625,
      "h": 8590000217,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000217),
//--TRIMMABLE-BOUNDARY-START(4295032921),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configure",
          "p": $.$$.S.Action$$($.$mexla.MEL.ILoggingBuilder).$h
        }
      ],
      "n": "AddLogging",
      "d": 65625,
      "h": 4295032921,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032921)
  ],
  "h": 65625
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}LoggingServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65625)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704025)
        $asm.$cls(`$mexl.MEL.LoggingBuilderExtensions`, ($self) => class LoggingBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(17181573209)
            static /*ILoggingBuilder */ SetMinimumLevel(/*this ILoggingBuilder*/ builder, /*LogLevel*/ level)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181573209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.MEL$ILoggingBuilder$Services.SCG$ICollection$$$Add($.$mxdi.MED.ServiceDescriptor.Singleton$6($.$meo.MEO.IConfigureOptions$$($.$mexl.MEL.LoggerFilterOptions), new $.$mexl.MEL.DefaultLoggerLevelConfigureOptions().$ctor$2(level)));
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(17181573209)
            
            //--TRIMMABLE-BOUNDARY-START(4296671321)
            static /*ILoggingBuilder */ AddProvider(/*this ILoggingBuilder*/ builder, /*ILoggerProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296671321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$mexla.MEL.ILoggerProvider, builder.MEL$ILoggingBuilder$Services, provider);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671321)
            
            //--TRIMMABLE-BOUNDARY-START(8591638617)
            static /*ILoggingBuilder */ ClearProviders(/*this ILoggingBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591638617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.RemoveAll$1($.$mexla.MEL.ILoggerProvider, builder.MEL$ILoggingBuilder$Services);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(8591638617)
            
            //--TRIMMABLE-BOUNDARY-START(12886605913)
            static /*ILoggingBuilder */ Configure(/*this ILoggingBuilder*/ builder, /*Action<LoggerFactoryOptions>*/ action)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886605913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$mexl.MEL.LoggerFactoryOptions, builder.MEL$ILoggingBuilder$Services, action);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(12886605913)
            
            static $h = 1704025;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181573209),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": "SetMinimumLevel",
      "d": 1704025,
      "h": 17181573209,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181573209),
//--TRIMMABLE-BOUNDARY-START(4296671321),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "provider",
          "p": 1114200
        }
      ],
      "n": "AddProvider",
      "d": 1704025,
      "h": 4296671321,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296671321),
//--TRIMMABLE-BOUNDARY-START(8591638617),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        }
      ],
      "n": "ClearProviders",
      "d": 1704025,
      "h": 8591638617,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591638617),
//--TRIMMABLE-BOUNDARY-START(12886605913),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$($.$mexl.MEL.LoggerFactoryOptions).$h
        }
      ],
      "n": "Configure",
      "d": 1704025,
      "h": 12886605913,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886605913)
  ],
  "h": 1704025
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggingBuilderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggingBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704025)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572953)
        $asm.$cls(`$mexl.MEL.LoggerRuleSelector`, ($self) => class LoggerRuleSelector
        {
            //--TRIMMABLE-BOUNDARY-START(8591507545)
            static /*void */ Select(/*LoggerFilterOptions*/ options, /*Type*/ providerType, /*string*/ category, /*out LogLevel?*/ minLevel, /*out Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                filter.$v = null;
                minLevel.$v = options.MinLevel;
                /*string?*/ let providerAlias = $.$mexl.MEL.ProviderAliasUtilities.GetAlias(providerType);
                /*LoggerFilterRule?*/ let current = null;
                let $en1 = options.RulesInternal.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let rule = $en1.Current;
                    {
                        if ($.$mexl.MEL.LoggerRuleSelector.IsBetter(rule, current, providerType.FullName, category) || (!$.$$.S.String.IsNullOrEmpty(providerAlias) && $.$mexl.MEL.LoggerRuleSelector.IsBetter(rule, current, providerAlias, category)))
                        {
                            current = rule;
                        }
                    }
                }
                if (current !== null)
                {
                    filter.$v = current.Filter;
                    minLevel.$v = current.LogLevel;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591507545)
            
            //--TRIMMABLE-BOUNDARY-START(4296540249)
            static /*bool */ IsBetter(/*LoggerFilterRule*/ rule, /*LoggerFilterRule?*/ current, /*string?*/ logger, /*string*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (rule.ProviderName !== null && rule.ProviderName !== logger)
                {
                    return false;
                }
                /*string?*/ let categoryName = rule.CategoryName;
                if (categoryName !== null)
                {
                    /*char*/ let WildcardChar = /***/ 42;
                    /*int*/ let wildcardIndex = $.$$.S.String.IndexOf$3.call(categoryName, WildcardChar);
                    if (wildcardIndex !== -1 && $.$$.S.String.IndexOf$1.call(categoryName, WildcardChar, ((wildcardIndex + 1) | 0)) !== -1)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$mexl.S.SR.MoreThanOneWildcard);
                    }
                    /*ReadOnlySpan<char>*/ let prefix, suffix;
                    if (wildcardIndex === -1)
                    {
                        prefix = $.$$.S.MemoryExtensions.AsSpan$4(categoryName);
                        suffix = new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))();
                    }
                    else 
                    {
                        prefix = $.$$.S.MemoryExtensions.AsSpan$1(categoryName, 0, wildcardIndex);
                        suffix = $.$$.S.MemoryExtensions.AsSpan$2(categoryName, ((wildcardIndex + 1) | 0));
                    }
                    if (!$.$$.S.MemoryExtensions.StartsWith($.$$.S.MemoryExtensions.AsSpan$4(category), prefix, 5/*StringComparison.OrdinalIgnoreCase*/) || !$.$$.S.MemoryExtensions.EndsWith($.$$.S.MemoryExtensions.AsSpan$4(category), suffix, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return false;
                    }
                }
                if ((current?.ProviderName ?? null) !== null)
                {
                    if (rule.ProviderName === null)
                    {
                        return false;
                    }
                }
                else 
                {
                    if (rule.ProviderName !== null)
                    {
                        return true;
                    }
                }
                if ((current?.CategoryName ?? null) !== null)
                {
                    if (rule.CategoryName === null)
                    {
                        return false;
                    }
                    if (current.CategoryName.length > rule.CategoryName.length)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540249)
            
            static $h = 1572953;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591507545),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": 1376345
        },
        {
          "n": "providerType",
          "p": 188547073
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "minLevel",
          "p": $.$typeNullable($.$mexla.MEL.LogLevel).$h,
          "f": 2
        },
        {
          "n": "filter",
          "p": $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h,
          "f": 2
        }
      ],
      "n": "Select",
      "d": 1572953,
      "h": 8591507545,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591507545),
//--TRIMMABLE-BOUNDARY-START(4296540249),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": 1441881
        },
        {
          "n": "current",
          "p": 1441881
        },
        {
          "n": "logger",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "IsBetter",
      "d": 1572953,
      "h": 4296540249,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4296540249)
  ],
  "h": 1572953
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerRuleSelector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerRuleSelector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572953)
        
        

        //--TRIMMABLE-BOUNDARY-START(393305)
        $asm.$cls(`$mexl.MEL.FilterLoggingBuilderExtensions`, ($self) => class FilterLoggingBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885295193)
            static /*ILoggingBuilder */ AddFilter$2(/*this ILoggingBuilder*/ builder, /*Func<string?, string?, LogLevel, bool>*/ filter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$7(options, filter);
                    }, $CtFRgd ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885295193)
            
            //--TRIMMABLE-BOUNDARY-START(8590327897)
            static /*ILoggingBuilder */ AddFilter$1(/*this ILoggingBuilder*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$6(options, categoryLevelFilter);
                    }, $HbhcXe ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590327897)
            
            //--TRIMMABLE-BOUNDARY-START(51540000857)
            static /*ILoggingBuilder */ AddFilter$11(T, /*this ILoggingBuilder*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540000857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$15(T, options, categoryLevelFilter);
                    }, $RozTrh ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540000857)
            
            //--TRIMMABLE-BOUNDARY-START(4295360601)
            static /*ILoggingBuilder */ AddFilter(/*this ILoggingBuilder*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$5(options, levelFilter);
                    }, $GtOazk ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360601)
            
            //--TRIMMABLE-BOUNDARY-START(47245033561)
            static /*ILoggingBuilder */ AddFilter$10(T, /*this ILoggingBuilder*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245033561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$14(T, options, levelFilter);
                    }, $sFpWWh ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245033561)
            
            //--TRIMMABLE-BOUNDARY-START(17180262489)
            static /*ILoggingBuilder */ AddFilter$3(/*this ILoggingBuilder*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$8(options, category, level);
                    }, $AhYWke ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262489)
            
            //--TRIMMABLE-BOUNDARY-START(55834968153)
            static /*ILoggingBuilder */ AddFilter$12(T, /*this ILoggingBuilder*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834968153);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$16(T, options, category, level);
                    }, $XGlHWc ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834968153)
            
            //--TRIMMABLE-BOUNDARY-START(21475229785)
            static /*ILoggingBuilder */ AddFilter$4(/*this ILoggingBuilder*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$9(options, category, levelFilter);
                    }, $WGxzDb ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475229785)
            
            //--TRIMMABLE-BOUNDARY-START(60129935449)
            static /*ILoggingBuilder */ AddFilter$13(T, /*this ILoggingBuilder*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129935449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.ConfigureFilter(builder, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/**/ options) =>
                    {
                        return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddFilter$17(T, options, category, levelFilter);
                    }, $ypcVjl ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129935449)
            
            //--TRIMMABLE-BOUNDARY-START(34360131673)
            static /*LoggerFilterOptions */ AddFilter$7(/*this LoggerFilterOptions*/ builder, /*Func<string?, string?, LogLevel, bool>*/ filter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360131673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, filter);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360131673)
            
            //--TRIMMABLE-BOUNDARY-START(30065164377)
            static /*LoggerFilterOptions */ AddFilter$6(/*this LoggerFilterOptions*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065164377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, new ($.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return categoryLevelFilter.Invoke(name, level);
                    }, $JrsNHj ??= {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293848}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164377)
            
            //--TRIMMABLE-BOUNDARY-START(68719870041)
            static /*LoggerFilterOptions */ AddFilter$15(T, /*this LoggerFilterOptions*/ builder, /*Func<string?, LogLevel, bool>*/ categoryLevelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719870041);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, null, null, new ($.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return categoryLevelFilter.Invoke(name, level);
                    }, $zJxeTj ??= {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293848}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719870041)
            
            //--TRIMMABLE-BOUNDARY-START(25770197081)
            static /*LoggerFilterOptions */ AddFilter$5(/*this LoggerFilterOptions*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, null, null, null, new ($.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return levelFilter.Invoke(level);
                    }, $fVgYba ??= {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293848}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770197081)
            
            //--TRIMMABLE-BOUNDARY-START(64424902745)
            static /*LoggerFilterOptions */ AddFilter$14(T, /*this LoggerFilterOptions*/ builder, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424902745);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, null, null, new ($.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean))().$ctor(this,  (/*type*/ type, /**/ name, /*level*/ level) =>
                    {
                        return levelFilter.Invoke(level);
                    }, $ySmcqh ??= {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293848}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424902745)
            
            //--TRIMMABLE-BOUNDARY-START(38655098969)
            static /*LoggerFilterOptions */ AddFilter$8(/*this LoggerFilterOptions*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655098969);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, null, category, level, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655098969)
            
            //--TRIMMABLE-BOUNDARY-START(73014837337)
            static /*LoggerFilterOptions */ AddFilter$16(T, /*this LoggerFilterOptions*/ builder, /*string?*/ category, /*LogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014837337);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, category, level, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014837337)
            
            //--TRIMMABLE-BOUNDARY-START(42950066265)
            static /*LoggerFilterOptions */ AddFilter$9(/*this LoggerFilterOptions*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950066265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, null, category, null, new ($.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /*level*/ level) =>
                    {
                        return levelFilter.Invoke(level);
                    }, $nZZDIe ??= {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293848}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950066265)
            
            //--TRIMMABLE-BOUNDARY-START(77309804633)
            static /*LoggerFilterOptions */ AddFilter$17(T, /*this LoggerFilterOptions*/ builder, /*string?*/ category, /*Func<LogLevel, bool>*/ levelFilter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309804633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexl.MEL.FilterLoggingBuilderExtensions.AddRule(builder, T.$type.FullName, category, null, new ($.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean))().$ctor(this,  (/*type*/ type, /*name*/ name, /**/ level) =>
                    {
                        return levelFilter.Invoke(level);
                    }, $TYgBcd ??= {"r":262145,"p":[{"n":"type","p":1310721},{"n":"name","p":1310721},{"n":"level","p":2293848}],"n":"","d":393305,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309804633)
            
            //--TRIMMABLE-BOUNDARY-START(85899739225)
            static /*ILoggingBuilder */ ConfigureFilter(/*this ILoggingBuilder*/ builder, /*Action<LoggerFilterOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899739225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$mexl.MEL.LoggerFilterOptions, builder.MEL$ILoggingBuilder$Services, configureOptions);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(85899739225)
            
            //--TRIMMABLE-BOUNDARY-START(81604771929)
            static /*LoggerFilterOptions */ AddRule(/*LoggerFilterOptions*/ options, /*string?*/ type, /*string?*/ category, /*LogLevel?*/ level, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.Rules.SCG$ICollection$$$Add(new $.$mexl.MEL.LoggerFilterRule().$ctor$1(type, category, level, filter));
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(81604771929)
            
            static $h = 393305;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295193),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "filter",
          "p": $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$2",
      "d": 393305,
      "h": 12885295193,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885295193),
//--TRIMMABLE-BOUNDARY-START(8590327897),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "categoryLevelFilter",
          "p": $.$$.S.Func$$$$($.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$1",
      "d": 393305,
      "h": 8590327897,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327897),
//--TRIMMABLE-BOUNDARY-START(51540000857),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "categoryLevelFilter",
          "p": $.$$.S.Func$$$$($.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$11",
      "d": 393305,
      "h": 51540000857,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(51540000857),
//--TRIMMABLE-BOUNDARY-START(4295360601),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "levelFilter",
          "p": $.$$.S.Func$$$($.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "d": 393305,
      "h": 4295360601,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295360601),
//--TRIMMABLE-BOUNDARY-START(47245033561),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "levelFilter",
          "p": $.$$.S.Func$$$($.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$10",
      "d": 393305,
      "h": 47245033561,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47245033561),
//--TRIMMABLE-BOUNDARY-START(17180262489),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": "AddFilter",
      "o": "@$3",
      "d": 393305,
      "h": 17180262489,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180262489),
//--TRIMMABLE-BOUNDARY-START(55834968153),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$12",
      "d": 393305,
      "h": 55834968153,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(55834968153),
//--TRIMMABLE-BOUNDARY-START(21475229785),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "levelFilter",
          "p": $.$$.S.Func$$$($.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$4",
      "d": 393305,
      "h": 21475229785,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475229785),
//--TRIMMABLE-BOUNDARY-START(60129935449),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "levelFilter",
          "p": $.$$.S.Func$$$($.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$13",
      "d": 393305,
      "h": 60129935449,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60129935449),
//--TRIMMABLE-BOUNDARY-START(34360131673),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "filter",
          "p": $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$7",
      "d": 393305,
      "h": 34360131673,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360131673),
//--TRIMMABLE-BOUNDARY-START(30065164377),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "categoryLevelFilter",
          "p": $.$$.S.Func$$$$($.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$6",
      "d": 393305,
      "h": 30065164377,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065164377),
//--TRIMMABLE-BOUNDARY-START(68719870041),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "categoryLevelFilter",
          "p": $.$$.S.Func$$$$($.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$15",
      "d": 393305,
      "h": 68719870041,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(68719870041),
//--TRIMMABLE-BOUNDARY-START(25770197081),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "levelFilter",
          "p": $.$$.S.Func$$$($.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$5",
      "d": 393305,
      "h": 25770197081,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770197081),
//--TRIMMABLE-BOUNDARY-START(64424902745),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "levelFilter",
          "p": $.$$.S.Func$$$($.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$14",
      "d": 393305,
      "h": 64424902745,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(64424902745),
//--TRIMMABLE-BOUNDARY-START(38655098969),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": "AddFilter",
      "o": "@$8",
      "d": 393305,
      "h": 38655098969,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655098969),
//--TRIMMABLE-BOUNDARY-START(73014837337),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$16",
      "d": 393305,
      "h": 73014837337,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73014837337),
//--TRIMMABLE-BOUNDARY-START(42950066265),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "levelFilter",
          "p": $.$$.S.Func$$$($.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": "AddFilter",
      "o": "@$9",
      "d": 393305,
      "h": 42950066265,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950066265),
//--TRIMMABLE-BOUNDARY-START(77309804633),
    {
      "r": 1376345,
      "p": [
        {
          "n": "builder",
          "p": 1376345
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "levelFilter",
          "p": $.$$.S.Func$$$($.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddFilter",
      "o": "@$17",
      "d": 393305,
      "h": 77309804633,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77309804633),
//--TRIMMABLE-BOUNDARY-START(85899739225),
    {
      "r": 1179736,
      "p": [
        {
          "n": "builder",
          "p": 1179736
        },
        {
          "n": "configureOptions",
          "p": $.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions).$h
        }
      ],
      "n": "ConfigureFilter",
      "d": 393305,
      "h": 85899739225,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899739225),
//--TRIMMABLE-BOUNDARY-START(81604771929),
    {
      "r": 1376345,
      "p": [
        {
          "n": "options",
          "p": 1376345
        },
        {
          "n": "type",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "category",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "level",
          "p": $.$typeNullable($.$mexla.MEL.LogLevel).$h,
          "f": 65
        },
        {
          "n": "filter",
          "p": $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "AddRule",
      "d": 393305,
      "h": 81604771929,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604771929)
  ],
  "h": 393305
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.FilterLoggingBuilderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}FilterLoggingBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393305)
        
        

        //--TRIMMABLE-BOUNDARY-START(131161)
        $asm.$cls(`$mexl.MEL.ActivityExtensions`, ($self) => class ActivityExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590065753)
            static /*string */ GetSpanId(/*this Activity*/ activity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    let $switch1 = activity.IdFormat;
                    if ($switch1 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.Id;
                    }
                    if ($switch1 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.SpanId.ToHexString();
                    }
                    return null;
                })() ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065753)
            
            //--TRIMMABLE-BOUNDARY-START(12885033049)
            static /*string */ GetTraceId(/*this Activity*/ activity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    let $switch2 = activity.IdFormat;
                    if ($switch2 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.RootId;
                    }
                    if ($switch2 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.TraceId.ToHexString();
                    }
                    return null;
                })() ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033049)
            
            //--TRIMMABLE-BOUNDARY-START(4295098457)
            static /*string */ GetParentId(/*this Activity*/ activity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    let $switch3 = activity.IdFormat;
                    if ($switch3 === 1/*ActivityIdFormat.Hierarchical*/)
                    {
                        return activity.ParentId;
                    }
                    if ($switch3 === 2/*ActivityIdFormat.W3C*/)
                    {
                        return activity.ParentSpanId.ToHexString();
                    }
                    return null;
                })() ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098457)
            
            static $h = 131161;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590065753),
    {
      "r": 1310721,
      "p": [
        {
          "n": "activity",
          "p": 196654
        }
      ],
      "n": "GetSpanId",
      "d": 131161,
      "h": 8590065753,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065753),
//--TRIMMABLE-BOUNDARY-START(12885033049),
    {
      "r": 1310721,
      "p": [
        {
          "n": "activity",
          "p": 196654
        }
      ],
      "n": "GetTraceId",
      "d": 131161,
      "h": 12885033049,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885033049),
//--TRIMMABLE-BOUNDARY-START(4295098457),
    {
      "r": 1310721,
      "p": [
        {
          "n": "activity",
          "p": 196654
        }
      ],
      "n": "GetParentId",
      "d": 131161,
      "h": 4295098457,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098457)
  ],
  "h": 131161
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.ActivityExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}ActivityExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131161)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835097)
        $asm.$cls(`$mexl.MEL.NullExternalScopeProvider`, ($self) => class NullExternalScopeProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886736985)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886736985);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886736985)
            
            //--TRIMMABLE-BOUNDARY-START(25771638873)
            /*IExternalScopeProvider*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(25771638873)
            
            //--TRIMMABLE-BOUNDARY-START(30066606169)
            /*void */ MEL$IExternalScopeProvider$ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066606169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30066606169)
            
            //--TRIMMABLE-BOUNDARY-START(34361573465)
            /*IDisposable */ MEL$IExternalScopeProvider$Push(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361573465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexl.MEL.NullScope.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(34361573465)
            
            //--TRIMMABLE-BOUNDARY-START(12886736985)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886736985)
            
            //--TRIMMABLE-BOUNDARY-START(8591769689)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591769689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25771638873)
                    this.Instance = new $.$mexl.MEL.NullExternalScopeProvider().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25771638873)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591769689)
            
            static $h = 1835097;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771638873),
    {
      "p": 852056,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476671577,
        "f": 50331681
      },
      "n": "Instance",
      "d": 1835097,
      "h": 25771638873,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25771638873)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886736985),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1835097,
      "h": 12886736985,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886736985)
  ],
  "h": 1835097
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.MEL.IExternalScopeProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.NullExternalScopeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}NullExternalScopeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835097)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638489)
        $asm.$cls(`$mexl.MEL.LoggingBuilder`, ($self) => class LoggingBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591573081)
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591573081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Services = services;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573081)
            
            //--TRIMMABLE-BOUNDARY-START(21476474969)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(21476474969)
            
            //--TRIMMABLE-BOUNDARY-START(8591114328)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggingBuilder.Services.get
            get MEL$ILoggingBuilder$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114328)
            
            static $h = 1638489;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476474969),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181507673,
        "f": 50331649
      },
      "n": "Services",
      "d": 1638489,
      "h": 21476474969,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476474969)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591573081),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1638489,
      "h": 8591573081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591573081)
  ],
  "h": 1638489
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.MEL.ILoggingBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggingBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggingBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638489)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900633)
        $asm.$cls(`$mexl.MEL.NullScope`, ($self) => class NullScope extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066671705)
            /*NullScope*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30066671705)
            
            //--TRIMMABLE-BOUNDARY-START(12886802521)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886802521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886802521)
            
            //--TRIMMABLE-BOUNDARY-START(17181769817)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17181769817)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12886802521)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886802521)
            
            //--TRIMMABLE-BOUNDARY-START(8591835225)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591835225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30066671705)
                    this.Instance = new $.$mexl.MEL.NullScope().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(30066671705)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591835225)
            
            static $h = 1900633;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066671705),
    {
      "p": 1900633,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771704409,
        "f": 50331681
      },
      "n": "Instance",
      "d": 1900633,
      "h": 30066671705,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30066671705)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181769817),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1900633,
      "h": 17181769817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886802521),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900633,
      "h": 12886802521,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886802521)
  ],
  "h": 1900633
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.NullScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}NullScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900633)
        
        

        //--TRIMMABLE-BOUNDARY-START(458841)
        $asm.$cls(`$mexl.MEL.Logger`, ($self) => class Logger extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295426137)
            /*string*/ _categoryName = null;
            //--TRIMMABLE-BOUNDARY-END(4295426137)
            
            //--TRIMMABLE-BOUNDARY-START(21475295321)
            $ctor$1(/*string*/ categoryName, /*LoggerInformation[]*/ loggers)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475295321);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._categoryName = categoryName;
                    this.Loggers = loggers;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295321)
            
            //--TRIMMABLE-BOUNDARY-START(68719935577)
            /*LoggerInformation[]*/ Loggers = null;
            //--TRIMMABLE-BOUNDARY-END(68719935577)
            
            //--TRIMMABLE-BOUNDARY-START(73014902873)
            /*MessageLogger[]?*/ MessageLoggers = null;
            //--TRIMMABLE-BOUNDARY-END(73014902873)
            
            //--TRIMMABLE-BOUNDARY-START(77309870169)
            /*ScopeLogger[]?*/ ScopeLoggers = null;
            //--TRIMMABLE-BOUNDARY-END(77309870169)
            
            //--TRIMMABLE-BOUNDARY-START(64424968281)
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MessageLogger[]?*/ let loggers = this.MessageLoggers;
                if (loggers === null)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < loggers.length; i++)
                {
                    /*ref readonly MessageLogger*/ let loggerInfo = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mexl.MEL.MessageLogger, loggers, i, false, true);
                    if (!loggerInfo.$v.IsEnabled(logLevel))
                    {
                        continue;
                    }
                    LoggerLog(logLevel, eventId, loggerInfo.$v.Logger, exception, formatter, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$$.SCG.List$$($.$$.S.Exception)), $.$ref(() => state, ));
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mexl.MEL.Logger.ThrowLoggingError(exceptions);
                }
                /*static void*/  function LoggerLog(/*LogLevel*/ logLevel, /*EventId*/ eventId, /*ILogger*/ logger, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter, /*ref List<Exception>?*/ exceptions, /*in TState*/ state)
                {
                    try
                    {
                        logger.MEL$ILogger$Log(TState, logLevel, eventId, state.$v, exception, formatter);
                    }
                    catch(ex)
                    {
                        exceptions.$v ??= new ($.$$.SCG.List$$($.$$.S.Exception))().$ctor$1();
                        exceptions.$v.Add(ex);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424968281)
            
            //--TRIMMABLE-BOUNDARY-START(60130000985)
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MessageLogger[]?*/ let loggers = this.MessageLoggers;
                if (loggers === null)
                {
                    return false;
                }
                /*List<Exception>?*/ let exceptions = null;
                /*int*/ let i = 0;
                for(; i < loggers.length; i++)
                {
                    /*ref readonly MessageLogger*/ let loggerInfo = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mexl.MEL.MessageLogger, loggers, i, false, true);
                    if (!loggerInfo.$v.IsEnabled(logLevel))
                    {
                        continue;
                    }
                    if (LoggerIsEnabled(logLevel, loggerInfo.$v.Logger, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$$.SCG.List$$($.$$.S.Exception))))
                    {
                        break;
                    }
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mexl.MEL.Logger.ThrowLoggingError(exceptions);
                }
                return i < loggers.length ? true : false;
                /*static bool*/  function LoggerIsEnabled(/*LogLevel*/ logLevel, /*ILogger*/ logger, /*ref List<Exception>?*/ exceptions)
                {
                    try
                    {
                        if (logger.MEL$ILogger$IsEnabled(logLevel))
                        {
                            return true;
                        }
                    }
                    catch(ex)
                    {
                        exceptions.$v ??= new ($.$$.SCG.List$$($.$$.S.Exception))().$ctor$1();
                        exceptions.$v.Add(ex);
                    }
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130000985)
            
            //--TRIMMABLE-BOUNDARY-START(25770262617)
            /*IDisposable? */ BeginScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ScopeLogger[]?*/ let loggers = this.ScopeLoggers;
                if (loggers === null)
                {
                    return $.$mexl.MEL.NullScope.Instance;
                }
                if (loggers.length === 1)
                {
                    return $.$$.System.Array.$ReadT1.call(loggers, 0).CreateScope(TState, state);
                }
                /*var*/ let scope = new $.$mexl.MEL.Logger.Scope().$ctor$1(loggers.length);
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < loggers.length; i++)
                {
                    /*ref readonly ScopeLogger*/ let scopeLogger = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mexl.MEL.ScopeLogger, loggers, i, false, true);
                    try
                    {
                        scope.SetDisposable(i, scopeLogger.$v.CreateScope(TState, state));
                    }
                    catch(ex)
                    {
                        exceptions ??= new ($.$$.SCG.List$$($.$$.S.Exception))().$ctor$1();
                        exceptions.Add(ex);
                    }
                }
                if (exceptions !== null && exceptions.Count > 0)
                {
                    $.$mexl.MEL.Logger.ThrowLoggingError(exceptions);
                }
                return scope;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262617)
            
            //--TRIMMABLE-BOUNDARY-START(107374641241)
            static /*void */ ThrowLoggingError(/*List<Exception>*/ exceptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.AggregateException().$ctor$10("An error occurred while writing to logger(s).", exceptions);
            }
            //--TRIMMABLE-BOUNDARY-END(107374641241)
            
            //--TRIMMABLE-BOUNDARY-START(30065229913)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexl.MEL.DebuggerDisplayFormatting.DebuggerToString(this._categoryName, this);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229913)
            
            //--TRIMMABLE-BOUNDARY-START(655449)
            static $_Scope;
            static get Scope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mexl.MEL.Logger;
                return $cls.$_Scope ??= $asm.$ncls(`$mexl.MEL.Logger.Scope`, ($self) => class Scope extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524633)
                    /*bool*/ _isDisposed = false;
                    //--TRIMMABLE-BOUNDARY-END(17180524633)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590590041)
                    /*IDisposable?*/ _disposable0 = null;
                    //--TRIMMABLE-BOUNDARY-END(8590590041)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557337)
                    /*IDisposable?*/ _disposable1 = null;
                    //--TRIMMABLE-BOUNDARY-END(12885557337)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622745)
                    /*IDisposable?[]?*/ _disposable = null;
                    //--TRIMMABLE-BOUNDARY-END(4295622745)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491929)
                    $ctor$1(/*int*/ count)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475491929);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            if (count > 2)
                            {
                                this._disposable = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.IDisposable), null, [((count - 2) | 0)], null);
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475491929)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426521)
                    /*void */ SetDisposable(/*int*/ index, /*IDisposable?*/ disposable)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065426521);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        switch(index)
                        {
                            case 0:
                            this._disposable0 = disposable;
                            break;
                            case 1:
                            this._disposable1 = disposable;
                            break;
                            default:
                            $.$$.System.Array.$WriteT1.call(this._disposable, disposable, ((index - 2) | 0));
                            break;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065426521)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770459225)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770459225);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._isDisposed)
                        {
                            this._disposable0?.S$IDisposable$Dispose();
                            this._disposable1?.S$IDisposable$Dispose();
                            if (this._disposable !== null)
                            {
                                /*int*/ let count = this._disposable.length;
                                for(/*int*/ let index = 0; index !== count; ++index)
                                {
                                    $.$$.System.Array.$ReadT1.call(this._disposable, index)?.S$IDisposable$Dispose();
                                }
                            }
                            this._isDisposed = true;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770459225)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $h = 655449;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065426521),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "disposable",
          "p": 91095041
        }
      ],
      "n": "SetDisposable",
      "d": 655449,
      "h": 30065426521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065426521),
//--TRIMMABLE-BOUNDARY-START(25770459225),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 655449,
      "h": 25770459225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459225)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524633),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 655449,
      "h": 17180524633,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180524633),
//--TRIMMABLE-BOUNDARY-START(8590590041),
    {
      "t": 91095041,
      "n": "_disposable0",
      "d": 655449,
      "h": 8590590041,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590590041),
//--TRIMMABLE-BOUNDARY-START(12885557337),
    {
      "t": 91095041,
      "n": "_disposable1",
      "d": 655449,
      "h": 12885557337,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885557337),
//--TRIMMABLE-BOUNDARY-START(4295622745),
    {
      "t": $.$typeArray($.$$.S.IDisposable).$h,
      "n": "_disposable",
      "d": 655449,
      "h": 4295622745,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622745)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475491929),
    {
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655449,
      "h": 21475491929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491929)
  ],
  "d": 458841,
  "h": 655449
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.Logger+Scope`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}Logger${separator}Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655449)
            
            //--TRIMMABLE-BOUNDARY-START(12885819480)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            MEL$ILogger$Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819480)
            
            //--TRIMMABLE-BOUNDARY-START(8590852184)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            MEL$ILogger$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590852184)
            
            //--TRIMMABLE-BOUNDARY-START(4295884888)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            MEL$ILogger$BeginScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884888)
            
            static $h = 458841;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719935577),
    {
      "p": $.$typeArray($.$mexl.MEL.LoggerInformation).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655164505,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899804761,
        "f": 83886081
      },
      "n": "Loggers",
      "d": 458841,
      "h": 68719935577,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719935577),
//--TRIMMABLE-BOUNDARY-START(73014902873),
    {
      "p": $.$typeArray($.$mexl.MEL.MessageLogger).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245099097,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489739353,
        "f": 83886081
      },
      "n": "MessageLoggers",
      "d": 458841,
      "h": 73014902873,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014902873),
//--TRIMMABLE-BOUNDARY-START(77309870169),
    {
      "p": $.$typeArray($.$mexl.MEL.ScopeLogger).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033689,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079673945,
        "f": 83886081
      },
      "n": "ScopeLoggers",
      "d": 458841,
      "h": 77309870169,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309870169)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64424968281),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "exception",
          "p": 80805889
        },
        {
          "n": "formatter",
          "p": (TState) => $.$$.S.Func$$$$(TState, $.$$.S.Exception, $.$$.S.String).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Log",
      "d": 458841,
      "h": 64424968281,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(64424968281),
//--TRIMMABLE-BOUNDARY-START(60130000985),
    {
      "r": 262145,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "d": 458841,
      "h": 60130000985,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130000985),
//--TRIMMABLE-BOUNDARY-START(25770262617),
    {
      "r": 91095041,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "BeginScope",
      "d": 458841,
      "h": 25770262617,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(25770262617),
//--TRIMMABLE-BOUNDARY-START(107374641241),
    {
      "r": 65537,
      "p": [
        {
          "n": "exceptions",
          "p": $.$$.SCG.List$$($.$$.S.Exception).$h
        }
      ],
      "n": "ThrowLoggingError",
      "d": 458841,
      "h": 107374641241,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374641241),
//--TRIMMABLE-BOUNDARY-START(30065229913),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 458841,
      "h": 30065229913,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30065229913)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426137),
    {
      "t": 1310721,
      "n": "_categoryName",
      "d": 458841,
      "h": 4295426137,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426137)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475295321),
    {
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        },
        {
          "n": "loggers",
          "p": $.$typeArray($.$mexl.MEL.LoggerInformation).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458841,
      "h": 21475295321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295321)
  ],
  "h": 458841,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": null,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.MEL.ILogger ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ /*$.$mexl.MEL.Logger.LoggerDebugView*/$.$$.DeletedObject, /*$.$mexl.MEL.Logger.LoggerProviderDebugView*/$.$$.DeletedObject, $.$mexl.MEL.Logger.Scope ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.Logger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}Logger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458841)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048665)
        $asm.$cls(`$mexl.MEL.LoggerFactoryScopeProvider`, ($self) => class LoggerFactoryScopeProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590983257)
            /*AsyncLocal<Scope?>*/ _currentScope = null;
            //--TRIMMABLE-BOUNDARY-END(8590983257)
            
            //--TRIMMABLE-BOUNDARY-START(4296015961)
            /*ActivityTrackingOptions*/ _activityTrackingOption = 0;
            //--TRIMMABLE-BOUNDARY-END(4296015961)
            
            //--TRIMMABLE-BOUNDARY-START(12885950553)
            $ctor$1(/*ActivityTrackingOptions*/ activityTrackingOption)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885950553);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._activityTrackingOption = activityTrackingOption;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885950553)
            
            //--TRIMMABLE-BOUNDARY-START(17180917849)
            /*void */ ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180917849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*void*/  function Report(/*Scope?*/ current)
                {
                    if (current === null)
                    {
                        return;
                    }
                    Report.call(this, current.Parent);
                    callback.Invoke(current.State, state);
                }
                if (this._activityTrackingOption !== 0/*ActivityTrackingOptions.None*/)
                {
                    /*Activity?*/ let activity = $.$sdd.SD.Activity.Current;
                    if (activity !== null)
                    {
                        /*string*/ let propertyKey = "__ActivityLogScope__";
                        /*ActivityLogScope?*/ let activityLogScope = $.$as(activity.GetCustomProperty(propertyKey), $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityLogScope);
                        if (activityLogScope === null)
                        {
                            activityLogScope = new $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityLogScope().$ctor$1(activity, this._activityTrackingOption);
                            activity.SetCustomProperty(propertyKey, activityLogScope);
                        }
                        callback.Invoke(activityLogScope, state);
                        if ((this._activityTrackingOption & 32/*ActivityTrackingOptions.Tags*/) !== 0 && activity.TagObjects.SCG$IEnumerable$$$GetEnumerator().SC$1$IEnumerator$MoveNext())
                        {
                            callback.Invoke(activity.TagObjects, state);
                        }
                        if ((this._activityTrackingOption & 64/*ActivityTrackingOptions.Baggage*/) !== 0)
                        {
                            /*IEnumerable<KeyValuePair<string, string?>>*/ let baggage = activity.Baggage;
                            if (baggage.SCG$IEnumerable$$$GetEnumerator().SC$1$IEnumerator$MoveNext())
                            {
                                /*ActivityBaggageLogScopeWrapper*/ let scope = $.$mexl.MEL.LoggerFactoryScopeProvider.GetOrCreateActivityBaggageLogScopeWrapper(activity, baggage);
                                callback.Invoke(scope, state);
                            }
                        }
                    }
                }
                Report.call(this, this._currentScope.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(17180917849)
            
            //--TRIMMABLE-BOUNDARY-START(21475885145)
            static /*ActivityBaggageLogScopeWrapper */ GetOrCreateActivityBaggageLogScopeWrapper(/*Activity*/ activity, /*IEnumerable<KeyValuePair<string, string?>>*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let additionalItemsBaggagePropertyKey = "__ActivityBaggageItemsLogScope__";
                /*var*/ let activityBaggageLogScopeWrapper = $.$as(activity.GetCustomProperty(additionalItemsBaggagePropertyKey), $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper);
                if (activityBaggageLogScopeWrapper === null)
                {
                    activityBaggageLogScopeWrapper = new $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper().$ctor$1(items);
                    activity.SetCustomProperty(additionalItemsBaggagePropertyKey, activityBaggageLogScopeWrapper);
                }
                return activityBaggageLogScopeWrapper;
            }
            //--TRIMMABLE-BOUNDARY-END(21475885145)
            
            //--TRIMMABLE-BOUNDARY-START(25770852441)
            /*IDisposable */ Push(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770852441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Scope?*/ let parent = this._currentScope.Value;
                /*var*/ let newScope = new $.$mexl.MEL.LoggerFactoryScopeProvider.Scope().$ctor$1(this, state, parent);
                this._currentScope.Value = newScope;
                return newScope;
            }
            //--TRIMMABLE-BOUNDARY-END(25770852441)
            
            //--TRIMMABLE-BOUNDARY-START(1310809)
            static $_Scope;
            static get Scope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1310809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mexl.MEL.LoggerFactoryScopeProvider;
                return $cls.$_Scope ??= $asm.$ncls(`$mexl.MEL.LoggerFactoryScopeProvider.Scope`, ($self) => class Scope extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591245401)
                    /*LoggerFactoryScopeProvider*/ _provider = null;
                    //--TRIMMABLE-BOUNDARY-END(8591245401)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278105)
                    /*bool*/ _isDisposed = false;
                    //--TRIMMABLE-BOUNDARY-END(4296278105)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476147289)
                    $ctor$1(/*LoggerFactoryScopeProvider*/ provider, /*object?*/ state, /*Scope?*/ parent)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476147289);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._provider = provider;
                            this.State = state;
                            this.Parent = parent;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476147289)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245951065)
                    /*Scope?*/ Parent = null;
                    //--TRIMMABLE-BOUNDARY-END(47245951065)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540918361)
                    /*object?*/ State = null;
                    //--TRIMMABLE-BOUNDARY-END(51540918361)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835885657)
                    /*string? */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835885657);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*object?*/ let __ca1__;
                        return _ = ((__ca1__ = this.State) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835885657)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771114585)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771114585);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._isDisposed)
                        {
                            this._provider._currentScope.Value = this.Parent;
                            this._isDisposed = true;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771114585)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $h = 1310809;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245951065),
    {
      "p": 1310809,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361049177,
        "f": 50331649
      },
      "n": "Parent",
      "d": 1310809,
      "h": 47245951065,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245951065),
//--TRIMMABLE-BOUNDARY-START(51540918361),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950983769,
        "f": 50331649
      },
      "n": "State",
      "d": 1310809,
      "h": 51540918361,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540918361)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835885657),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1310809,
      "h": 55835885657,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835885657),
//--TRIMMABLE-BOUNDARY-START(25771114585),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1310809,
      "h": 25771114585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771114585)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591245401),
    {
      "t": 1048665,
      "n": "_provider",
      "d": 1310809,
      "h": 8591245401,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245401),
//--TRIMMABLE-BOUNDARY-START(4296278105),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 1310809,
      "h": 4296278105,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278105)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476147289),
    {
      "p": [
        {
          "n": "provider",
          "p": 1048665
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "parent",
          "p": 1310809
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310809,
      "h": 21476147289,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476147289)
  ],
  "d": 1048665,
  "h": 1310809
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider+Scope`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactoryScopeProvider${separator}Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1310809)
            
            //--TRIMMABLE-BOUNDARY-START(1245273)
            static $_ActivityLogScope;
            static get ActivityLogScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1245273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mexl.MEL.LoggerFactoryScopeProvider;
                return $cls.$_ActivityLogScope ??= $asm.$ncls(`$mexl.MEL.LoggerFactoryScopeProvider.ActivityLogScope`, ($self) => class ActivityLogScope extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296212569)
                    /*string?*/ _cachedToString = null;
                    //--TRIMMABLE-BOUNDARY-END(4296212569)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245885529)
                    /*int*/ static MaxItems = 5;
                    //--TRIMMABLE-BOUNDARY-END(47245885529)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591179865)
                    /*KeyValuePair<string, object?>[]*/ _items = null;
                    //--TRIMMABLE-BOUNDARY-END(8591179865)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181114457)
                    $ctor$1(/*Activity*/ activity, /*ActivityTrackingOptions*/ activityTrackingOption)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181114457);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(activity !== null, "activity != null");
                            $.$$.SD.Debug.Assert$4(activityTrackingOption !== 0/*ActivityTrackingOptions.None*/, "activityTrackingOption != ActivityTrackingOptions.None");
                            /*int*/ let count = 0;
                            if ((activityTrackingOption & 1/*ActivityTrackingOptions.SpanId*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("SpanId", $.$mexl.MEL.ActivityExtensions.GetSpanId(activity)), count++);
                            }
                            if ((activityTrackingOption & 2/*ActivityTrackingOptions.TraceId*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("TraceId", $.$mexl.MEL.ActivityExtensions.GetTraceId(activity)), count++);
                            }
                            if ((activityTrackingOption & 4/*ActivityTrackingOptions.ParentId*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("ParentId", $.$mexl.MEL.ActivityExtensions.GetParentId(activity)), count++);
                            }
                            if ((activityTrackingOption & 8/*ActivityTrackingOptions.TraceState*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("TraceState", activity.TraceStateString), count++);
                            }
                            if ((activityTrackingOption & 16/*ActivityTrackingOptions.TraceFlags*/) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(this._items, new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("TraceFlags", $.$box(activity.ActivityTraceFlags, $.$sdd.SD.ActivityTraceFlags)), count++);
                            }
                            this.Count = count;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181114457)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476081753)
                    /*int*/ Count = 0;
                    //--TRIMMABLE-BOUNDARY-END(21476081753)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835820121)
                    /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
                    {
                        if (index >= this.Count)
                        {
                            throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("index");
                        }
                        return $.$$.System.Array.$ReadT1.call(this._items, index);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835820121)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130787417)
                    /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130787417);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._cachedToString === null)
                        {
                            /*StringBuilder*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                            sb.Append$21($.$$.System.Array.$ReadT1.call(this._items, 0).Key);
                            sb.Append$5(/*:*/ 58);
                            sb.Append$15($.$$.System.Array.$ReadT1.call(this._items, 0).Value);
                            for(/*int*/ let i = 1; i < this.Count; i++)
                            {
                                sb.Append$21(", ");
                                sb.Append$21($.$$.System.Array.$ReadT1.call(this._items, i).Key);
                                sb.Append$5(/*:*/ 58);
                                sb.Append$15($.$$.System.Array.$ReadT1.call(this._items, i).Value);
                            }
                            this._cachedToString = sb.ToString();
                        }
                        return this._cachedToString;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130787417)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950918233)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item$1(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950918233)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540852825)
                    /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540852825);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540852825)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650817537)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    SCG$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650817537);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650817537)
                    
                    //--TRIMMABLE-BOUNDARY-START(12945653761)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get SCG$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355719169);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945653761)
                    
                    //--TRIMMABLE-BOUNDARY-START(4355325953)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    SCG$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355325953);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4355325953)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8591179865)
                        this._items = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), null, [5/*MaxItems*/], null);
                        //--TRIMMABLE-BOUNDARY-END(8591179865)
                        
                    }
                    static $h = 1245273;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476081753),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066016345,
        "f": 50331649
      },
      "n": "Count",
      "d": 1245273,
      "h": 21476081753,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476081753),
//--TRIMMABLE-BOUNDARY-START(55835820121),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655950937,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 1245273,
      "h": 55835820121,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(55835820121)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130787417),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1245273,
      "h": 60130787417,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130787417),
//--TRIMMABLE-BOUNDARY-START(42950918233),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,
      "n": "GetEnumerator",
      "d": 1245273,
      "h": 42950918233,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950918233)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212569),
    {
      "t": 1310721,
      "n": "_cachedToString",
      "d": 1245273,
      "h": 4296212569,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212569),
//--TRIMMABLE-BOUNDARY-START(47245885529),
    {
      "t": 655361,
      "n": "MaxItems",
      "d": 1245273,
      "h": 47245885529,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245885529),
//--TRIMMABLE-BOUNDARY-START(8591179865),
    {
      "t": $.$typeArray($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,
      "n": "_items",
      "d": 1245273,
      "h": 8591179865,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181114457),
    {
      "p": [
        {
          "n": "activity",
          "p": 196654
        },
        {
          "n": "activityTrackingOption",
          "p": 196697
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245273,
      "h": 17181114457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181114457)
  ],
  "d": 1048665,
  "h": 1245273
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IReadOnlyList$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SCG.IReadOnlyCollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SC$1.IEnumerable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider+ActivityLogScope`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactoryScopeProvider${separator}ActivityLogScope`; }
                }, $cls, ($v) => $cls.$_ActivityLogScope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245273)
            
            //--TRIMMABLE-BOUNDARY-START(1114201)
            static $_ActivityBaggageLogScopeWrapper;
            static get ActivityBaggageLogScopeWrapper()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mexl.MEL.LoggerFactoryScopeProvider;
                return $cls.$_ActivityBaggageLogScopeWrapper ??= $asm.$ncls(`$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper`, ($self) => class ActivityBaggageLogScopeWrapper extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296081497)
                    /*IEnumerable<KeyValuePair<string, string?>>*/ _items = null;
                    //--TRIMMABLE-BOUNDARY-END(4296081497)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591048793)
                    /*StringBuilder?*/ _stringBuilder = null;
                    //--TRIMMABLE-BOUNDARY-END(8591048793)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886016089)
                    $ctor$1(/*IEnumerable<KeyValuePair<string, string?>>*/ items)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886016089);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._items = items;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886016089)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180983385)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180983385);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator().$ctor$3(this._items.SCG$IEnumerable$$$GetEnumerator());
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180983385)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475950681)
                    /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475950681);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator().$ctor$3(this._items.SCG$IEnumerable$$$GetEnumerator());
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475950681)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770917977)
                    /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770917977);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock(this)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this)
                            {
                                /*IEnumerator<KeyValuePair<string, string?>>*/ let enumerator = this._items.SCG$IEnumerable$$$GetEnumerator();
                                if (!enumerator.SC$1$IEnumerator$MoveNext())
                                {
                                    return $.$$.S.String.Empty;
                                }
                                this._stringBuilder ??= new $.$$.ST.StringBuilder().$ctor$1();
                                this._stringBuilder.Append$21(enumerator.SCG$IEnumerator$$$Current.Key);
                                this._stringBuilder.Append$5(/*:*/ 58);
                                this._stringBuilder.Append$21(enumerator.SCG$IEnumerator$$$Current.Value);
                                while(enumerator.SC$1$IEnumerator$MoveNext())
                                {
                                    this._stringBuilder.Append$21(", ");
                                    this._stringBuilder.Append$21(enumerator.SCG$IEnumerator$$$Current.Key);
                                    this._stringBuilder.Append$5(/*:*/ 58);
                                    this._stringBuilder.Append$21(enumerator.SCG$IEnumerator$$$Current.Value);
                                }
                                /*string*/ let result = this._stringBuilder.ToString();
                                this._stringBuilder.Clear();
                                return result;
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770917977)
                    
                    //--TRIMMABLE-BOUNDARY-START(1179737)
                    static $_BaggageEnumerator;
                    static get BaggageEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1179737);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper;
                        return $cls.$_BaggageEnumerator ??= $asm.$nstr(`$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator`, ($self) => class BaggageEnumerator extends $.$$.S.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296147033)
                            /*IEnumerator<KeyValuePair<string, string?>>*/ _enumerator = null;
                            //--TRIMMABLE-BOUNDARY-END(4296147033)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886081625)
                            $ctor$3(/*IEnumerator<KeyValuePair<string, string?>>*/ enumerator)
                            {
                                super.$ctor$1();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12886081625);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._enumerator = enumerator;
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886081625)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181048921)
                            /*KeyValuePair<string, object?> */ get Current()
                            {
                                return new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3(this._enumerator.SCG$IEnumerator$$$Current.Key, this._enumerator.SCG$IEnumerator$$$Current.Value);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181048921)
                            
                            //--TRIMMABLE-BOUNDARY-START(42950852697)
                            /*object? */ get SC$1$IEnumerator$Current()
                            {
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(42950852697)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476016217)
                            /*void */ Dispose()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(21476016217);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return this._enumerator.S$IDisposable$Dispose();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476016217)
                            
                            //--TRIMMABLE-BOUNDARY-START(34360918105)
                            /*bool */ MoveNext()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(34360918105);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return this._enumerator.SC$1$IEnumerator$MoveNext();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(34360918105)
                            
                            //--TRIMMABLE-BOUNDARY-START(38655885401)
                            /*void */ Reset()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(38655885401);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return this._enumerator.SC$1$IEnumerator$Reset();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(38655885401)
                            
                            //--TRIMMABLE-BOUNDARY-START(12945326081)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<string, object?>>.Current.get
                            get SCG$IEnumerator$$$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4355391489);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12945326081)
                            
                            //--TRIMMABLE-BOUNDARY-START(4386062337)
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            S$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4386062337);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Dispose(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4386062337)
                            
                            //--TRIMMABLE-BOUNDARY-START(17243373569)
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            SC$1$IEnumerator$MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17243373569);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.MoveNext(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17243373569)
                            
                            //--TRIMMABLE-BOUNDARY-START(21538340865)
                            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                            SC$1$IEnumerator$Reset()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21538340865);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Reset(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(21538340865)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591114329)
                            //default constructor overload
                            $ctor$2()
                            {
                                super.$ctor$1();
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(8591114329);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591114329)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591114329)
                            //generic new constructor
                            $gctor()
                            {
                                return this.$ctor$2();
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591114329)
                            
                            $clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._enumerator = this._enumerator;
                                return copy;
                            }
                            static $h = 1179737;
                            static $z = 4;
                            static $f = 0b10000001010000000;
                            static $k = 2;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181048921),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065950809,
        "f": 50331649
      },
      "n": "Current",
      "d": 1179737,
      "h": 17181048921,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181048921),
//--TRIMMABLE-BOUNDARY-START(42950852697),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540787289,
        "f": 50331650
      },
      "n": "{63504385}.Current",
      "o": "SC$1$IEnumerator$Current",
      "d": 1179737,
      "h": 42950852697,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950852697)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476016217),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1179737,
      "h": 21476016217,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016217),
//--TRIMMABLE-BOUNDARY-START(34360918105),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1179737,
      "h": 34360918105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360918105),
//--TRIMMABLE-BOUNDARY-START(38655885401),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1179737,
      "h": 38655885401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655885401)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147033),
    {
      "t": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "n": "_enumerator",
      "d": 1179737,
      "h": 4296147033,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147033)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886081625),
    {
      "p": [
        {
          "n": "enumerator",
          "p": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179737,
      "h": 12886081625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081625),
//--TRIMMABLE-BOUNDARY-START(8591114329),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179737,
      "h": 8591114329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591114329)
  ],
  "d": 1114201,
  "h": 1179737
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider+ActivityBaggageLogScopeWrapper+BaggageEnumerator`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactoryScopeProvider${separator}ActivityBaggageLogScopeWrapper${separator}BaggageEnumerator`; }
                        }, $cls, ($v) => $cls.$_BaggageEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1179737)
                    
                    //--TRIMMABLE-BOUNDARY-START(4355325953)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    SCG$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355325953);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4355325953)
                    
                    static $h = 1114201;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180983385),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,
      "n": "GetEnumerator",
      "d": 1114201,
      "h": 17180983385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983385),
//--TRIMMABLE-BOUNDARY-START(25770917977),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1114201,
      "h": 25770917977,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770917977)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081497),
    {
      "t": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "n": "_items",
      "d": 1114201,
      "h": 4296081497,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081497),
//--TRIMMABLE-BOUNDARY-START(8591048793),
    {
      "t": 167837697,
      "n": "_stringBuilder",
      "d": 1114201,
      "h": 8591048793,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048793)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886016089),
    {
      "p": [
        {
          "n": "items",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114201,
      "h": 12886016089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016089)
  ],
  "d": 1048665,
  "h": 1114201
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SC$1.IEnumerable ]; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper.BaggageEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider+ActivityBaggageLogScopeWrapper`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactoryScopeProvider${separator}ActivityBaggageLogScopeWrapper`; }
                }, $cls, ($v) => $cls.$_ActivityBaggageLogScopeWrapper = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114201)
            
            //--TRIMMABLE-BOUNDARY-START(4295819352)
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.ForEachScope<TState>(System.Action<object?, TState>, TState)
            MEL$IExternalScopeProvider$ForEachScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ForEachScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819352)
            
            //--TRIMMABLE-BOUNDARY-START(8590786648)
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.Push(object?)
            MEL$IExternalScopeProvider$Push()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Push(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786648)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590983257)
                this._currentScope = new ($.$$.ST$1.AsyncLocal$$($.$mexl.MEL.LoggerFactoryScopeProvider.Scope))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590983257)
                
            }
            static $h = 1048665;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180917849),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": (TState) => $.$$.S.Action$$$($.$$.S.Object, TState).$h
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "ForEachScope",
      "d": 1048665,
      "h": 17180917849,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(17180917849),
//--TRIMMABLE-BOUNDARY-START(21475885145),
    {
      "r": 1114201,
      "p": [
        {
          "n": "activity",
          "p": 196654
        },
        {
          "n": "items",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h
        }
      ],
      "n": "GetOrCreateActivityBaggageLogScopeWrapper",
      "d": 1048665,
      "h": 21475885145,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475885145),
//--TRIMMABLE-BOUNDARY-START(25770852441),
    {
      "r": 91095041,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "Push",
      "d": 1048665,
      "h": 25770852441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770852441)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590983257),
    {
      "t": $.$$.ST$1.AsyncLocal$$($.$mexl.MEL.LoggerFactoryScopeProvider.Scope).$h,
      "n": "_currentScope",
      "d": 1048665,
      "h": 8590983257,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983257),
//--TRIMMABLE-BOUNDARY-START(4296015961),
    {
      "t": 196697,
      "n": "_activityTrackingOption",
      "d": 1048665,
      "h": 4296015961,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885950553),
    {
      "p": [
        {
          "n": "activityTrackingOption",
          "p": 196697
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048665,
      "h": 12885950553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885950553)
  ],
  "h": 1048665
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.MEL.IExternalScopeProvider ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mexl.MEL.LoggerFactoryScopeProvider.Scope, $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityLogScope, $.$mexl.MEL.LoggerFactoryScopeProvider.ActivityBaggageLogScopeWrapper ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactoryScopeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactoryScopeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048665)
        
        

        //--TRIMMABLE-BOUNDARY-START(720985)
        $asm.$cls(`$mexl.MEL.LoggerFactory`, ($self) => class LoggerFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475557465)
            /*ConcurrentDictionary<string, Logger>*/ _loggers = null;
            //--TRIMMABLE-BOUNDARY-END(21475557465)
            
            //--TRIMMABLE-BOUNDARY-START(25770524761)
            /*List<ProviderRegistration>*/ _providerRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(25770524761)
            
            //--TRIMMABLE-BOUNDARY-START(34360459353)
            /*object*/ _sync = null;
            //--TRIMMABLE-BOUNDARY-END(34360459353)
            
            //--TRIMMABLE-BOUNDARY-START(8590655577)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590655577)
            
            //--TRIMMABLE-BOUNDARY-START(4295688281)
            /*IDisposable?*/ _changeTokenRegistration = null;
            //--TRIMMABLE-BOUNDARY-END(4295688281)
            
            //--TRIMMABLE-BOUNDARY-START(17180590169)
            /*LoggerFilterOptions*/ _filterOptions = null;
            //--TRIMMABLE-BOUNDARY-END(17180590169)
            
            //--TRIMMABLE-BOUNDARY-START(30065492057)
            /*IExternalScopeProvider?*/ _scopeProvider = null;
            //--TRIMMABLE-BOUNDARY-END(30065492057)
            
            //--TRIMMABLE-BOUNDARY-START(12885622873)
            /*LoggerFactoryOptions*/ _factoryOptions = null;
            //--TRIMMABLE-BOUNDARY-END(12885622873)
            
            //--TRIMMABLE-BOUNDARY-START(38655426649)
            $ctor$1()
            {
                this.$ctor$6($.$$.S.Array.Empty($.$mexla.MEL.ILoggerProvider));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426649)
            
            //--TRIMMABLE-BOUNDARY-START(60130263129)
            $ctor$6(/*IEnumerable<ILoggerProvider>*/ providers)
            {
                this.$ctor$5(providers, new $.$mexl.MEL.StaticFilterOptionsMonitor().$ctor$1(new $.$mexl.MEL.LoggerFilterOptions().$ctor$1()));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130263129);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263129)
            
            //--TRIMMABLE-BOUNDARY-START(42950393945)
            $ctor$2(/*IEnumerable<ILoggerProvider>*/ providers, /*LoggerFilterOptions*/ filterOptions)
            {
                this.$ctor$5(providers, new $.$mexl.MEL.StaticFilterOptionsMonitor().$ctor$1(filterOptions));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950393945);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393945)
            
            //--TRIMMABLE-BOUNDARY-START(55835295833)
            $ctor$5(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption)
            {
                this.$ctor$4(providers, filterOption, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835295833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835295833)
            
            //--TRIMMABLE-BOUNDARY-START(51540328537)
            $ctor$4(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption, /*IOptions<LoggerFactoryOptions>?*/ options)
            {
                this.$ctor$3(providers, filterOption, options, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540328537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540328537)
            
            //--TRIMMABLE-BOUNDARY-START(47245361241)
            $ctor$3(/*IEnumerable<ILoggerProvider>*/ providers, /*IOptionsMonitor<LoggerFilterOptions>*/ filterOption, /*IOptions<LoggerFactoryOptions>?*/ options, /*IExternalScopeProvider?*/ scopeProvider)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245361241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._scopeProvider = scopeProvider;
                    this._factoryOptions = options === null || options.MEO$IOptions$Microsoft$Extensions$Logging$LoggerFactoryOptions$Value === null ? new $.$mexl.MEL.LoggerFactoryOptions().$ctor$1() : options.MEO$IOptions$Microsoft$Extensions$Logging$LoggerFactoryOptions$Value;
                    /*ActivityTrackingOptions*/ let ActivityTrackingOptionsMask = ~(1/*ActivityTrackingOptions.SpanId*/ | 2/*ActivityTrackingOptions.TraceId*/ | 4/*ActivityTrackingOptions.ParentId*/ | 16/*ActivityTrackingOptions.TraceFlags*/ | 8/*ActivityTrackingOptions.TraceState*/ | 32/*ActivityTrackingOptions.Tags*/ | 64/*ActivityTrackingOptions.Baggage*/);
                    if ((this._factoryOptions.ActivityTrackingOptions & ActivityTrackingOptionsMask) !== 0)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$mexl.S.SR.Format$6($.$mexl.S.SR.InvalidActivityTrackingOptions, $.$box(this._factoryOptions.ActivityTrackingOptions, $.$mexl.MEL.ActivityTrackingOptions)), "options");
                    }
                    let $en1 = providers.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let provider = $en1.SCG$IEnumerator$$$Current;
                        {
                            this.AddProviderRegistration(provider, false);
                        }
                    }
                    this._changeTokenRegistration = $.$meo.MEO.OptionsMonitorExtensions.OnChange($.$mexl.MEL.LoggerFilterOptions, filterOption, new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this, this.RefreshFilters));
                    this.RefreshFilters(filterOption.MEO$IOptionsMonitor$Microsoft$Extensions$Logging$LoggerFilterOptions$CurrentValue);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245361241)
            
            //--TRIMMABLE-BOUNDARY-START(81605099609)
            static /*ILoggerFactory */ Create(/*Action<ILoggingBuilder>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let serviceCollection = new $.$mxdi.MED.ServiceCollection().$ctor$1();
                $.$mexl.MED.LoggingServiceCollectionExtensions.AddLogging(serviceCollection, configure);
                /*ServiceProvider*/ let serviceProvider = $.$med.MED.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$2(serviceCollection);
                /*ILoggerFactory*/ let loggerFactory = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mexla.MEL.ILoggerFactory, serviceProvider);
                return new $.$mexl.MEL.LoggerFactory.DisposingLoggerFactory().$ctor$1(loggerFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(81605099609)
            
            //--TRIMMABLE-BOUNDARY-START(103079936089)
            /*void */ RefreshFilters(/*LoggerFilterOptions*/ filterOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079936089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_sync)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._sync)
                    {
                        this._filterOptions = filterOptions;
                        let $en2 = this._loggers.GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let registeredLogger = $en2.SCG$IEnumerator$$$Current;
                            {
                                /*Logger*/ let logger = registeredLogger.Value;
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._sync)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079936089)
            
            //--TRIMMABLE-BOUNDARY-START(85900066905)
            /*ILogger */ CreateLogger(/*string*/ categoryName)
            {
                /*Logger?*/ let logger;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CheckDisposed())
                {
                    throw new $.$$.S.ObjectDisposedException().$ctor$17("LoggerFactory");
                }
                if (!this._loggers.TryGetValue(categoryName, $.$ref(() => logger, ($v) => logger = $v, $.$mexl.MEL.Logger)))
                {
                    //lock(_sync)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this._sync)
                        {
                            if (!this._loggers.TryGetValue(categoryName, $.$ref(() => logger, ($v) => logger = $v, $.$mexl.MEL.Logger)))
                            {
                                logger = new $.$mexl.MEL.Logger().$ctor$1(categoryName, this.CreateLoggers(categoryName));
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                                this._loggers.set_Item$1(categoryName, logger);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this._sync)
                    }
                }
                return logger;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066905)
            
            //--TRIMMABLE-BOUNDARY-START(64425230425)
            /*void */ AddProvider(/*ILoggerProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CheckDisposed())
                {
                    throw new $.$$.S.ObjectDisposedException().$ctor$17("LoggerFactory");
                }
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                //lock(_sync)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._sync)
                    {
                        this.AddProviderRegistration(provider, true);
                        let $en5 = this._loggers.GetEnumerator();
                        while ($en5.SC$1$IEnumerator$MoveNext())
                        {
                            let existingLogger = $en5.SCG$IEnumerator$$$Current;
                            {
                                /*Logger*/ let logger = existingLogger.Value;
                                /*LoggerInformation[]*/ let loggerInformation = logger.Loggers;
                                /*int*/ let newLoggerIndex = loggerInformation.length;
                                $.$$.S.Array.Resize($.$mexl.MEL.LoggerInformation, $.$ref(() => loggerInformation, ($v) => loggerInformation = $v, $.$typeArray($.$mexl.MEL.LoggerInformation)), ((loggerInformation.length + 1) | 0));
                                $.$$.System.Array.$WriteT1.call(loggerInformation, new $.$mexl.MEL.LoggerInformation().$ctor$3(provider, existingLogger.Key), newLoggerIndex);
                                logger.Loggers = loggerInformation;
                                $.$tupleUnpack(($tp) =>
                                {
                                    logger.MessageLoggers = $tp.Item1;
                                    logger.ScopeLoggers = $tp.Item2;
                                }).$v = this.ApplyFilters(logger.Loggers);
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._sync)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425230425)
            
            //--TRIMMABLE-BOUNDARY-START(68720197721)
            /*void */ AddProviderRegistration(/*ILoggerProvider*/ provider, /*bool*/ dispose)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._providerRegistrations.Add((() =>
                {
                    //new $.$mexl.MEL.LoggerFactory.ProviderRegistration()
                    const $t7 = $.$mexl.MEL.LoggerFactory.ProviderRegistration;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Provider = provider;
                    $i7.ShouldDispose = dispose;
                    return $i7;
                })());
                let supportsExternalScope;
                if ($.$is(provider, $.$mexla.MEL.ISupportExternalScope, { set $v($v){ supportsExternalScope = $v; } }))
                {
                    this._scopeProvider ??= new $.$mexl.MEL.LoggerFactoryScopeProvider().$ctor$1(this._factoryOptions.ActivityTrackingOptions);
                    supportsExternalScope.MEL$ISupportExternalScope$SetScopeProvider(this._scopeProvider);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720197721)
            
            //--TRIMMABLE-BOUNDARY-START(90195034201)
            /*LoggerInformation[] */ CreateLoggers(/*string*/ categoryName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let loggers = new ($.$$.SCG.List$$($.$mexl.MEL.LoggerInformation))().$ctor$3(this._providerRegistrations.Count);
                for(/*int*/ let i = 0; i < this._providerRegistrations.Count; i++)
                {
                    /*var*/ let loggerInformation = new $.$mexl.MEL.LoggerInformation().$ctor$3(this._providerRegistrations.get_Item(i).Provider, categoryName);
                    if (loggerInformation.Logger !== $.$mexla.MELA.NullLogger.Instance)
                    {
                        loggers.Add(loggerInformation);
                    }
                }
                return loggers.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(90195034201)
            
            //--TRIMMABLE-BOUNDARY-START(73015165017)
            /*(MessageLogger[] MessageLoggers, ScopeLogger[]? ScopeLoggers) */ ApplyFilters(/*LoggerInformation[]*/ loggers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let messageLoggers = new ($.$$.SCG.List$$($.$mexl.MEL.MessageLogger))().$ctor$1();
                /*List<ScopeLogger>?*/ let scopeLoggers = this._filterOptions.CaptureScopes ? new ($.$$.SCG.List$$($.$mexl.MEL.ScopeLogger))().$ctor$1() : null;
                let $i8 = 0;
                let $arr8 = loggers;
                while ($i8 < $arr8.length)
                {
                    /*LogLevel?*/ let minLevel;
                    /*Func<string?, string?, LogLevel, bool>?*/ let filter;
                    let loggerInformation = $arr8[$i8++];
                    $.$mexl.MEL.LoggerRuleSelector.Select(this._filterOptions, loggerInformation.ProviderType, loggerInformation.Category, $.$ref(() => minLevel, ($v) => minLevel = $v, $.$typeNullable($.$mexla.MEL.LogLevel)), $.$ref(() => filter, ($v) => filter = $v, $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean)));
                    if ((minLevel !== null) && (minLevel > 5/*LogLevel.Critical*/))
                    {
                        continue;
                    }
                    messageLoggers.Add(new $.$mexl.MEL.MessageLogger().$ctor$3(loggerInformation.Logger, loggerInformation.Category, loggerInformation.ProviderType.FullName, minLevel, filter));
                    if (!loggerInformation.ExternalScope)
                    {
                        scopeLoggers?.Add(new $.$mexl.MEL.ScopeLogger().$ctor$3(loggerInformation.Logger, null));
                    }
                }
                if (this._scopeProvider !== null)
                {
                    scopeLoggers?.Add(new $.$mexl.MEL.ScopeLogger().$ctor$3(null, this._scopeProvider));
                }
                return new ($.$$.S.ValueTuple$$$($.$typeArray($.$mexl.MEL.MessageLogger), $.$typeArray($.$mexl.MEL.ScopeLogger)))().$ctor$3(messageLoggers.ToArray(), (scopeLoggers?.ToArray() ?? null));
            }
            //--TRIMMABLE-BOUNDARY-END(73015165017)
            
            //--TRIMMABLE-BOUNDARY-START(77310132313)
            /*bool */ CheckDisposed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310132313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._disposed;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310132313)
            
            //--TRIMMABLE-BOUNDARY-START(98784968793)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._changeTokenRegistration?.S$IDisposable$Dispose();
                    let $en11 = this._providerRegistrations.GetEnumerator();
                    while ($en11.MoveNext())
                    {
                        let registration = $en11.Current;
                        {
                            try
                            {
                                if (registration.ShouldDispose)
                                {
                                    registration.Provider.S$IDisposable$Dispose();
                                }
                            }
                            catch($e)
                            {
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784968793)
            
            //--TRIMMABLE-BOUNDARY-START(917593)
            static $_ProviderRegistration;
            static get ProviderRegistration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mexl.MEL.LoggerFactory;
                return $cls.$_ProviderRegistration ??= $asm.$nstr(`$mexl.MEL.LoggerFactory.ProviderRegistration`, ($self) => class ProviderRegistration extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852185)
                    /*ILoggerProvider*/ Provider = null;
                    //--TRIMMABLE-BOUNDARY-END(8590852185)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819481)
                    /*bool*/ ShouldDispose = false;
                    //--TRIMMABLE-BOUNDARY-END(12885819481)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884889)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295884889);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295884889)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884889)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295884889)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Provider = this.Provider;
                        copy.ShouldDispose = this.ShouldDispose;
                        return copy;
                    }
                    static $h = 917593;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852185),
    {
      "t": 1114200,
      "n": "Provider",
      "d": 917593,
      "h": 8590852185,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8590852185),
//--TRIMMABLE-BOUNDARY-START(12885819481),
    {
      "t": 262145,
      "n": "ShouldDispose",
      "d": 917593,
      "h": 12885819481,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885819481)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884889),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917593,
      "h": 4295884889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884889)
  ],
  "d": 720985,
  "h": 917593
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactory+ProviderRegistration`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactory${separator}ProviderRegistration`; }
                }, $cls, ($v) => $cls.$_ProviderRegistration = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917593)
            
            //--TRIMMABLE-BOUNDARY-START(786521)
            static $_DisposingLoggerFactory;
            static get DisposingLoggerFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mexl.MEL.LoggerFactory;
                return $cls.$_DisposingLoggerFactory ??= $asm.$ncls(`$mexl.MEL.LoggerFactory.DisposingLoggerFactory`, ($self) => class DisposingLoggerFactory extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753817)
                    /*ILoggerFactory*/ _loggerFactory = null;
                    //--TRIMMABLE-BOUNDARY-END(4295753817)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721113)
                    /*ServiceProvider*/ _serviceProvider = null;
                    //--TRIMMABLE-BOUNDARY-END(8590721113)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688409)
                    $ctor$1(/*ILoggerFactory*/ loggerFactory, /*ServiceProvider*/ serviceProvider)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885688409);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._loggerFactory = loggerFactory;
                            this._serviceProvider = serviceProvider;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885688409)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770590297)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770590297);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._serviceProvider.Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770590297)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475623001)
                    /*ILogger */ CreateLogger(/*string*/ categoryName)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475623001);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._loggerFactory.MEL$ILoggerFactory$CreateLogger(categoryName);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475623001)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655705)
                    /*void */ AddProvider(/*ILoggerProvider*/ provider)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180655705);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._loggerFactory.MEL$ILoggerFactory$AddProvider(provider);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180655705)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590983256)
                    //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.CreateLogger(string)
                    MEL$ILoggerFactory$CreateLogger()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590983256);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateLogger(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590983256)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015960)
                    //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.AddProvider(Microsoft.Extensions.Logging.ILoggerProvider)
                    MEL$ILoggerFactory$AddProvider()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296015960);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.AddProvider(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296015960)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $h = 786521;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770590297),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 786521,
      "h": 25770590297,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590297),
//--TRIMMABLE-BOUNDARY-START(21475623001),
    {
      "r": 917592,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "d": 786521,
      "h": 21475623001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623001),
//--TRIMMABLE-BOUNDARY-START(17180655705),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 1114200
        }
      ],
      "n": "AddProvider",
      "d": 786521,
      "h": 17180655705,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655705)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753817),
    {
      "t": 1048664,
      "n": "_loggerFactory",
      "d": 786521,
      "h": 4295753817,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753817),
//--TRIMMABLE-BOUNDARY-START(8590721113),
    {
      "t": 3080285,
      "n": "_serviceProvider",
      "d": 786521,
      "h": 8590721113,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885688409),
    {
      "p": [
        {
          "n": "loggerFactory",
          "p": 1048664
        },
        {
          "n": "serviceProvider",
          "p": 3080285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786521,
      "h": 12885688409,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688409)
  ],
  "d": 720985,
  "h": 786521
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mexla.MEL.ILoggerFactory, $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactory+DisposingLoggerFactory`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactory${separator}DisposingLoggerFactory`; }
                }, $cls, ($v) => $cls.$_DisposingLoggerFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786521)
            
            //--TRIMMABLE-BOUNDARY-START(94490001497)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `Providers = ${$.$strNN(this._providerRegistrations.Count)}, ${$.$strNN(this._filterOptions.DebuggerToString())}`;
            }
            //--TRIMMABLE-BOUNDARY-END(94490001497)
            
            //--TRIMMABLE-BOUNDARY-START(8590983256)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.CreateLogger(string)
            MEL$ILoggerFactory$CreateLogger()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLogger(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983256)
            
            //--TRIMMABLE-BOUNDARY-START(4296015960)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.AddProvider(Microsoft.Extensions.Logging.ILoggerProvider)
            MEL$ILoggerFactory$AddProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddProvider(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296015960)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(38655426649)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(38655426649)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475557465)
                this._loggers = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mexl.MEL.Logger))().$ctor$4($.$$.S.StringComparer.Ordinal);
                //--TRIMMABLE-BOUNDARY-END(21475557465)
                
                //--TRIMMABLE-BOUNDARY-START(25770524761)
                this._providerRegistrations = new ($.$$.SCG.List$$($.$mexl.MEL.LoggerFactory.ProviderRegistration))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(25770524761)
                
                //--TRIMMABLE-BOUNDARY-START(34360459353)
                this._sync = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(34360459353)
                
            }
            static $h = 720985;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605099609),
    {
      "r": 1048664,
      "p": [
        {
          "n": "configure",
          "p": $.$$.S.Action$$($.$mexla.MEL.ILoggingBuilder).$h
        }
      ],
      "n": "Create",
      "d": 720985,
      "h": 81605099609,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605099609),
//--TRIMMABLE-BOUNDARY-START(103079936089),
    {
      "r": 65537,
      "p": [
        {
          "n": "filterOptions",
          "p": 1376345
        }
      ],
      "n": "RefreshFilters",
      "d": 720985,
      "h": 103079936089,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079936089),
//--TRIMMABLE-BOUNDARY-START(85900066905),
    {
      "r": 917592,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "d": 720985,
      "h": 85900066905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900066905),
//--TRIMMABLE-BOUNDARY-START(64425230425),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 1114200
        }
      ],
      "n": "AddProvider",
      "d": 720985,
      "h": 64425230425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425230425),
//--TRIMMABLE-BOUNDARY-START(68720197721),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 1114200
        },
        {
          "n": "dispose",
          "p": 262145
        }
      ],
      "n": "AddProviderRegistration",
      "d": 720985,
      "h": 68720197721,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720197721),
//--TRIMMABLE-BOUNDARY-START(90195034201),
    {
      "r": $.$typeArray($.$mexl.MEL.LoggerInformation).$h,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLoggers",
      "d": 720985,
      "h": 90195034201,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195034201),
//--TRIMMABLE-BOUNDARY-START(73015165017),
    {
      "r": $.$$.S.ValueTuple$$$($.$typeArray($.$mexl.MEL.MessageLogger), $.$typeArray($.$mexl.MEL.ScopeLogger)).$h,
      "p": [
        {
          "n": "loggers",
          "p": $.$typeArray($.$mexl.MEL.LoggerInformation).$h
        }
      ],
      "n": "ApplyFilters",
      "d": 720985,
      "h": 73015165017,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015165017),
//--TRIMMABLE-BOUNDARY-START(77310132313),
    {
      "r": 262145,
      "n": "CheckDisposed",
      "d": 720985,
      "h": 77310132313,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(77310132313),
//--TRIMMABLE-BOUNDARY-START(98784968793),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 720985,
      "h": 98784968793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784968793),
//--TRIMMABLE-BOUNDARY-START(94490001497),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 720985,
      "h": 94490001497,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94490001497)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475557465),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mexl.MEL.Logger).$h,
      "n": "_loggers",
      "d": 720985,
      "h": 21475557465,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475557465),
//--TRIMMABLE-BOUNDARY-START(25770524761),
    {
      "t": $.$$.SCG.List$$($.$mexl.MEL.LoggerFactory.ProviderRegistration).$h,
      "n": "_providerRegistrations",
      "d": 720985,
      "h": 25770524761,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770524761),
//--TRIMMABLE-BOUNDARY-START(34360459353),
    {
      "t": 131073,
      "n": "_sync",
      "d": 720985,
      "h": 34360459353,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360459353),
//--TRIMMABLE-BOUNDARY-START(8590655577),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 720985,
      "h": 8590655577,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655577),
//--TRIMMABLE-BOUNDARY-START(4295688281),
    {
      "t": 91095041,
      "n": "_changeTokenRegistration",
      "d": 720985,
      "h": 4295688281,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688281),
//--TRIMMABLE-BOUNDARY-START(17180590169),
    {
      "t": 1376345,
      "n": "_filterOptions",
      "d": 720985,
      "h": 17180590169,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590169),
//--TRIMMABLE-BOUNDARY-START(30065492057),
    {
      "t": 852056,
      "n": "_scopeProvider",
      "d": 720985,
      "h": 30065492057,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065492057),
//--TRIMMABLE-BOUNDARY-START(12885622873),
    {
      "t": 983129,
      "n": "_factoryOptions",
      "d": 720985,
      "h": 12885622873,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622873)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655426649),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720985,
      "h": 38655426649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426649),
//--TRIMMABLE-BOUNDARY-START(60130263129),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.IEnumerable$$($.$mexla.MEL.ILoggerProvider).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 720985,
      "h": 60130263129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130263129),
//--TRIMMABLE-BOUNDARY-START(42950393945),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.IEnumerable$$($.$mexla.MEL.ILoggerProvider).$h
        },
        {
          "n": "filterOptions",
          "p": 1376345
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720985,
      "h": 42950393945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393945),
//--TRIMMABLE-BOUNDARY-START(55835295833),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.IEnumerable$$($.$mexla.MEL.ILoggerProvider).$h
        },
        {
          "n": "filterOption",
          "p": $.$meo.MEO.IOptionsMonitor$$($.$mexl.MEL.LoggerFilterOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 720985,
      "h": 55835295833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835295833),
//--TRIMMABLE-BOUNDARY-START(51540328537),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.IEnumerable$$($.$mexla.MEL.ILoggerProvider).$h
        },
        {
          "n": "filterOption",
          "p": $.$meo.MEO.IOptionsMonitor$$($.$mexl.MEL.LoggerFilterOptions).$h
        },
        {
          "n": "options",
          "p": $.$meo.MEO.IOptions$$($.$mexl.MEL.LoggerFactoryOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 720985,
      "h": 51540328537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540328537),
//--TRIMMABLE-BOUNDARY-START(47245361241),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.IEnumerable$$($.$mexla.MEL.ILoggerProvider).$h
        },
        {
          "n": "filterOption",
          "p": $.$meo.MEO.IOptionsMonitor$$($.$mexl.MEL.LoggerFilterOptions).$h
        },
        {
          "n": "options",
          "p": $.$meo.MEO.IOptions$$($.$mexl.MEL.LoggerFactoryOptions).$h,
          "f": 65
        },
        {
          "n": "scopeProvider",
          "p": 852056,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720985,
      "h": 47245361241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245361241)
  ],
  "h": 720985,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": null,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.MEL.ILoggerFactory, $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mexl.MEL.LoggerFactory.ProviderRegistration, $.$mexl.MEL.LoggerFactory.DisposingLoggerFactory, /*$.$mexl.MEL.LoggerFactory.LoggerFactoryDebugView*/$.$$.DeletedObject ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720985)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769561)
        $asm.$str(`$mexl.MEL.MessageLogger`, ($self) => class MessageLogger extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(30066540633)
            $ctor$3(/*ILogger*/ logger, /*string*/ category, /*string?*/ providerTypeFullName, /*LogLevel?*/ minLevel, /*Func<string?, string?, LogLevel, bool>?*/ filter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066540633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Logger = logger;
                    this.Category = category;
                    this.ProviderTypeFullName = providerTypeFullName;
                    this.MinLevel = minLevel;
                    this.Filter = filter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066540633)
            
            //--TRIMMABLE-BOUNDARY-START(90196082777)
            /*ILogger*/ Logger = null;
            //--TRIMMABLE-BOUNDARY-END(90196082777)
            
            //--TRIMMABLE-BOUNDARY-START(34361507929)
            /*string*/ Category = null;
            //--TRIMMABLE-BOUNDARY-END(34361507929)
            
            //--TRIMMABLE-BOUNDARY-START(98786017369)
            /*string?*/ ProviderTypeFullName = null;
            //--TRIMMABLE-BOUNDARY-END(98786017369)
            
            //--TRIMMABLE-BOUNDARY-START(94491050073)
            /*LogLevel?*/ MinLevel = null;
            //--TRIMMABLE-BOUNDARY-END(94491050073)
            
            //--TRIMMABLE-BOUNDARY-START(38656475225)
            /*Func<string?, string?, LogLevel, bool>?*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(38656475225)
            
            //--TRIMMABLE-BOUNDARY-START(85901115481)
            /*bool */ IsEnabled(/*LogLevel*/ level)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901115481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.MinLevel !== null && level < this.MinLevel)
                {
                    return false;
                }
                if (this.Filter !== null)
                {
                    return this.Filter.Invoke(this.ProviderTypeFullName, this.Category, level);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(85901115481)
            
            //--TRIMMABLE-BOUNDARY-START(25771573337)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771573337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771573337)
            
            //--TRIMMABLE-BOUNDARY-START(25771573337)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25771573337)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.Category = this.Category;
                copy.ProviderTypeFullName = this.ProviderTypeFullName;
                copy.MinLevel = this.MinLevel;
                copy.Filter = this.Filter;
                return copy;
            }
            static $h = 1769561;
            static $z = 21;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90196082777),
    {
      "p": 917592,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426279001,
        "f": 50331649
      },
      "n": "Logger",
      "d": 1769561,
      "h": 90196082777,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196082777),
//--TRIMMABLE-BOUNDARY-START(34361507929),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246409817,
        "f": 50331649
      },
      "n": "Category",
      "d": 1769561,
      "h": 34361507929,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361507929),
//--TRIMMABLE-BOUNDARY-START(98786017369),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606148185,
        "f": 50331650
      },
      "n": "ProviderTypeFullName",
      "d": 1769561,
      "h": 98786017369,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98786017369),
//--TRIMMABLE-BOUNDARY-START(94491050073),
    {
      "p": $.$typeNullable($.$mexla.MEL.LogLevel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016213593,
        "f": 50331649
      },
      "n": "MinLevel",
      "d": 1769561,
      "h": 94491050073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491050073),
//--TRIMMABLE-BOUNDARY-START(38656475225),
    {
      "p": $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836344409,
        "f": 50331649
      },
      "n": "Filter",
      "d": 1769561,
      "h": 38656475225,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656475225)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901115481),
    {
      "r": 262145,
      "p": [
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "d": 1769561,
      "h": 85901115481,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901115481)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066540633),
    {
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "providerTypeFullName",
          "p": 1310721
        },
        {
          "n": "minLevel",
          "p": $.$typeNullable($.$mexla.MEL.LogLevel).$h
        },
        {
          "n": "filter",
          "p": $.$$.S.Func$$$$$($.$$.S.String, $.$$.S.String, $.$mexla.MEL.LogLevel, $.$$.S.Boolean).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769561,
      "h": 30066540633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066540633),
//--TRIMMABLE-BOUNDARY-START(25771573337),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769561,
      "h": 25771573337,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771573337)
  ],
  "h": 1769561
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.MessageLogger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}MessageLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769561)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031705)
        $asm.$str(`$mexl.MEL.ScopeLogger`, ($self) => class ScopeLogger extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17181900889)
            $ctor$3(/*ILogger?*/ logger, /*IExternalScopeProvider?*/ externalScopeProvider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181900889);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(logger !== null || externalScopeProvider !== null, "Logger can't be null when there isn't an ExternalScopeProvider");
                    this.Logger = logger;
                    this.ExternalScopeProvider = externalScopeProvider;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181900889)
            
            //--TRIMMABLE-BOUNDARY-START(47246671961)
            /*ILogger?*/ Logger = null;
            //--TRIMMABLE-BOUNDARY-END(47246671961)
            
            //--TRIMMABLE-BOUNDARY-START(25771835481)
            /*IExternalScopeProvider?*/ ExternalScopeProvider = null;
            //--TRIMMABLE-BOUNDARY-END(25771835481)
            
            //--TRIMMABLE-BOUNDARY-START(21476868185)
            /*IDisposable? */ CreateScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476868185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ExternalScopeProvider !== null)
                {
                    return this.ExternalScopeProvider.MEL$IExternalScopeProvider$Push($.$box(state, TState));
                }
                $.$$.SD.Debug.Assert$4(this.Logger !== null, "Logger != null");
                return this.Logger.MEL$ILogger$BeginScope(TState, state);
            }
            //--TRIMMABLE-BOUNDARY-END(21476868185)
            
            //--TRIMMABLE-BOUNDARY-START(12886933593)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886933593)
            
            //--TRIMMABLE-BOUNDARY-START(12886933593)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886933593)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.ExternalScopeProvider = this.ExternalScopeProvider;
                return copy;
            }
            static $h = 2031705;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246671961),
    {
      "p": 917592,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951704665,
        "f": 50331649
      },
      "n": "Logger",
      "d": 2031705,
      "h": 47246671961,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246671961),
//--TRIMMABLE-BOUNDARY-START(25771835481),
    {
      "p": 852056,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361770073,
        "f": 50331649
      },
      "n": "ExternalScopeProvider",
      "d": 2031705,
      "h": 25771835481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771835481)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476868185),
    {
      "r": 91095041,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "CreateScope",
      "d": 2031705,
      "h": 21476868185,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(21476868185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181900889),
    {
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "externalScopeProvider",
          "p": 852056
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2031705,
      "h": 17181900889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181900889),
//--TRIMMABLE-BOUNDARY-START(12886933593),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031705,
      "h": 12886933593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886933593)
  ],
  "h": 2031705
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.ScopeLogger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}ScopeLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031705)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507417)
        $asm.$str(`$mexl.MEL.LoggerInformation`, ($self) => class LoggerInformation extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25771311193)
            $ctor$3(/*ILoggerProvider*/ provider, /*string*/ category)
            {
                this.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771311193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ProviderType = $.$$.S.Object.GetType.call(provider);
                    this.Logger = provider.MEL$ILoggerProvider$CreateLogger(category);
                    this.Category = category;
                    this.ExternalScope = $.$is(provider, $.$mexla.MEL.ISupportExternalScope);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771311193)
            
            //--TRIMMABLE-BOUNDARY-START(73015951449)
            /*ILogger*/ Logger = null;
            //--TRIMMABLE-BOUNDARY-END(73015951449)
            
            //--TRIMMABLE-BOUNDARY-START(30066278489)
            /*string*/ Category = null;
            //--TRIMMABLE-BOUNDARY-END(30066278489)
            
            //--TRIMMABLE-BOUNDARY-START(77310918745)
            /*Type*/ ProviderType = null;
            //--TRIMMABLE-BOUNDARY-END(77310918745)
            
            //--TRIMMABLE-BOUNDARY-START(34361245785)
            /*bool*/ ExternalScope = false;
            //--TRIMMABLE-BOUNDARY-END(34361245785)
            
            //--TRIMMABLE-BOUNDARY-START(21476343897)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343897)
            
            //--TRIMMABLE-BOUNDARY-START(21476343897)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21476343897)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Logger = this.Logger;
                copy.Category = this.Category;
                copy.ProviderType = this.ProviderType;
                copy.ExternalScope = this.ExternalScope;
                return copy;
            }
            static $h = 1507417;
            static $z = 13;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015951449),
    {
      "p": 917592,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131049561,
        "f": 50331649
      },
      "n": "Logger",
      "d": 1507417,
      "h": 73015951449,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015951449),
//--TRIMMABLE-BOUNDARY-START(30066278489),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951180377,
        "f": 50331649
      },
      "n": "Category",
      "d": 1507417,
      "h": 30066278489,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066278489),
//--TRIMMABLE-BOUNDARY-START(77310918745),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720984153,
        "f": 50331649
      },
      "n": "ProviderType",
      "d": 1507417,
      "h": 77310918745,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310918745),
//--TRIMMABLE-BOUNDARY-START(34361245785),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541114969,
        "f": 50331649
      },
      "n": "ExternalScope",
      "d": 1507417,
      "h": 34361245785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361245785)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771311193),
    {
      "p": [
        {
          "n": "provider",
          "p": 1114200
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507417,
      "h": 25771311193,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771311193),
//--TRIMMABLE-BOUNDARY-START(21476343897),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507417,
      "h": 21476343897,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343897)
  ],
  "h": 1507417
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggerInformation`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggerInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507417)
        
        

        //--TRIMMABLE-BOUNDARY-START(196697)
        $asm.$str(`$mexl.MEL.ActivityTrackingOptions`, ($self) => class ActivityTrackingOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static SpanId = 1;
            static TraceId = 2;
            static ParentId = 4;
            static TraceState = 8;
            static TraceFlags = 16;
            static Tags = 32;
            static Baggage = 64;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SpanId": 1n,
                    "TraceId": 2n,
                    "ParentId": 4n,
                    "TraceState": 8n,
                    "TraceFlags": 16n,
                    "Tags": 32n,
                    "Baggage": 64n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295163993)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163993)
            
            //--TRIMMABLE-BOUNDARY-START(4295163993)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163993)
            
            static $h = 196697;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885098585),
    {
      "t": 196697,
      "n": "None",
      "d": 196697,
      "h": 12885098585,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098585),
//--TRIMMABLE-BOUNDARY-START(21475033177),
    {
      "t": 196697,
      "n": "SpanId",
      "d": 196697,
      "h": 21475033177,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475033177),
//--TRIMMABLE-BOUNDARY-START(34359935065),
    {
      "t": 196697,
      "n": "TraceId",
      "d": 196697,
      "h": 34359935065,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359935065),
//--TRIMMABLE-BOUNDARY-START(17180065881),
    {
      "t": 196697,
      "n": "ParentId",
      "d": 196697,
      "h": 17180065881,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065881),
//--TRIMMABLE-BOUNDARY-START(38654902361),
    {
      "t": 196697,
      "n": "TraceState",
      "d": 196697,
      "h": 38654902361,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654902361),
//--TRIMMABLE-BOUNDARY-START(30064967769),
    {
      "t": 196697,
      "n": "TraceFlags",
      "d": 196697,
      "h": 30064967769,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064967769),
//--TRIMMABLE-BOUNDARY-START(25770000473),
    {
      "t": 196697,
      "n": "Tags",
      "d": 196697,
      "h": 25770000473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770000473),
//--TRIMMABLE-BOUNDARY-START(8590131289),
    {
      "t": 196697,
      "n": "Baggage",
      "d": 196697,
      "h": 8590131289,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131289)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163993),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196697,
      "h": 4295163993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163993)
  ],
  "h": 196697,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.ActivityTrackingOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}ActivityTrackingOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196697)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097241)
        $asm.$cls(`$mexl.MEL.StaticFilterOptionsMonitor`, ($self) => class StaticFilterOptionsMonitor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592031833)
            $ctor$1(/*LoggerFilterOptions*/ currentValue)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592031833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CurrentValue = $.$firstOf(currentValue, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("currentValue") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592031833)
            
            //--TRIMMABLE-BOUNDARY-START(30066868313)
            /*IDisposable? */ OnChange(/*Action<LoggerFilterOptions, string>*/ listener)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066868313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066868313)
            
            //--TRIMMABLE-BOUNDARY-START(25771901017)
            /*LoggerFilterOptions */ Get(/*string?*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771901017);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CurrentValue;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771901017)
            
            //--TRIMMABLE-BOUNDARY-START(12886999129)
            /*LoggerFilterOptions*/ CurrentValue = null;
            //--TRIMMABLE-BOUNDARY-END(12886999129)
            
            //--TRIMMABLE-BOUNDARY-START(12885885015)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.CurrentValue.get
            get MEO$IOptionsMonitor$Microsoft$Extensions$Logging$LoggerFilterOptions$CurrentValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentValue;
            }
            //--TRIMMABLE-BOUNDARY-END(12885885015)
            
            //--TRIMMABLE-BOUNDARY-START(17180852311)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.Get(string?)
            MEO$IOptionsMonitor$Microsoft$Extensions$Logging$LoggerFilterOptions$Get()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180852311)
            
            //--TRIMMABLE-BOUNDARY-START(21475819607)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<Microsoft.Extensions.Logging.LoggerFilterOptions>.OnChange(System.Action<Microsoft.Extensions.Logging.LoggerFilterOptions, string?>)
            MEO$IOptionsMonitor$Microsoft$Extensions$Logging$LoggerFilterOptions$OnChange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnChange(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819607)
            
            static $h = 2097241;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886999129),
    {
      "p": 1376345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476933721,
        "f": 50331649
      },
      "n": "CurrentValue",
      "d": 2097241,
      "h": 12886999129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886999129)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066868313),
    {
      "r": 91095041,
      "p": [
        {
          "n": "listener",
          "p": $.$$.S.Action$$$($.$mexl.MEL.LoggerFilterOptions, $.$$.S.String).$h
        }
      ],
      "n": "OnChange",
      "d": 2097241,
      "h": 30066868313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066868313),
//--TRIMMABLE-BOUNDARY-START(25771901017),
    {
      "r": 1376345,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": 2097241,
      "h": 25771901017,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771901017)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592031833),
    {
      "p": [
        {
          "n": "currentValue",
          "p": 1376345
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2097241,
      "h": 8592031833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592031833)
  ],
  "h": 2097241
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptionsMonitor$$($.$mexl.MEL.LoggerFilterOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.StaticFilterOptionsMonitor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}StaticFilterOptionsMonitor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097241)
        
        

        //--TRIMMABLE-BOUNDARY-START(327769)
        $asm.$cls(`$mexl.MEL.DefaultLoggerLevelConfigureOptions`, ($self) => class DefaultLoggerLevelConfigureOptions extends $.$meo.MEO.ConfigureOptions$$($.$mexl.MEL.LoggerFilterOptions)
        {
            //--TRIMMABLE-BOUNDARY-START(4295295065)
            $ctor$2(/*LogLevel*/ level)
            {
                super.$ctor$1(new ($.$$.S.Action$$($.$mexl.MEL.LoggerFilterOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return options.MinLevel = level;
                }, $uyGNgd ??= {"r":65537,"p":[{"n":"options","p":1376345}],"n":"","d":327769,"h":0,"f":17825794}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295065);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295065)
            
            static $h = 327769;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$meo.MEO.ConfigureOptions$$($.$mexl.MEL.LoggerFilterOptions); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295065),
    {
      "p": [
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327769,
      "h": 4295295065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295065)
  ],
  "h": 327769
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureOptions$$($.$mexl.MEL.LoggerFilterOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.DefaultLoggerLevelConfigureOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}DefaultLoggerLevelConfigureOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327769)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"));
})();
//--TRIMMABLE-BOUNDARY-END(89)
