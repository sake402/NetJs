
(function ($global, $, $spc, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $scn, $scm, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $mxdi, $sca, $meo) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", 
    {"h":19,"f":"Microsoft.Extensions.Options.ConfigurationExtensions","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Options.ConfigurationExtensions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Options.ConfigurationExtensions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions", ($self) => class OptionsConfigurationServiceCollectionExtensions
        {
            static /*IServiceCollection */ Configure(TOptions, /*this IServiceCollection*/ services, /*IConfiguration*/ config)
            {
                return $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions.Configure$1(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName, config);
            }
            static /*IServiceCollection */ Configure$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*IConfiguration*/ config)
            {
                return $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions.Configure$3(TOptions, services, name, config, new ($.$spc.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions))().$ctor(this,  (/*_*/ _0) =>
                {
                }, {"r":65537,"p":[{"n":"_","p":65551}],"n":"","d":131091,"h":0,"f":1048578}));
            }
            static /*IServiceCollection */ Configure$2(TOptions, /*this IServiceCollection*/ services, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                return $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions.Configure$3(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName, config, configureBinder);
            }
            static /*IServiceCollection */ Configure$3(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(config, "config");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions), services, new ($.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions))().$ctor$2(name, config));
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), services, new ($.$meoc.Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions$$(TOptions))().$ctor$3(name, config, configureBinder));
            }
            static $h = 131091;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435},{"n":"config","p":262158}],"g":["TOptions"],"n":"Configure","d":131091,"h":4295098387,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"name","p":1310721},{"n":"config","p":262158}],"g":["TOptions"],"n":"Configure","o":"@$1","d":131091,"h":8590065683,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"config","p":262158},{"n":"configureBinder","p":$.$spc.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h}],"g":["TOptions"],"n":"Configure","o":"@$2","d":131091,"h":12885032979,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"name","p":1310721},{"n":"config","p":262158},{"n":"configureBinder","p":$.$spc.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h}],"g":["TOptions"],"n":"Configure","o":"@$3","d":131091,"h":17180000275,"f":131105}],"h":131091}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$meoc.Microsoft.Extensions.DependencyInjection.OptionsBuilderConfigurationExtensions", ($self) => class OptionsBuilderConfigurationExtensions
        {
            /*string*/ static RequiresDynamicCodeMessage = null;
            /*string*/ static TrimmingRequiredUnreferencedCodeMessage = null;
            static /*OptionsBuilder<TOptions> */ Bind(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*IConfiguration*/ config)
            {
                return $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsBuilderConfigurationExtensions.Bind$1(TOptions, optionsBuilder, config, new ($.$spc.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions))().$ctor(this,  (/*_*/ _0) =>
                {
                }, {"r":65537,"p":[{"n":"_","p":65551}],"n":"","d":65555,"h":0,"f":1048578}));
            }
            static /*OptionsBuilder<TOptions> */ Bind$1(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(optionsBuilder, "optionsBuilder");
                $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions.Configure$3(TOptions, optionsBuilder.Services, optionsBuilder.Name, config, configureBinder);
                return optionsBuilder;
            }
            static /*OptionsBuilder<TOptions> */ BindConfiguration(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*string*/ configSectionPath, /*Action<BinderOptions>?*/ configureBinder)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(optionsBuilder, "optionsBuilder");
                $.$spc.System.ArgumentNullException.ThrowIfNull(configSectionPath, "configSectionPath");
                optionsBuilder.Configure$1($.$meca.Microsoft.Extensions.Configuration.IConfiguration, new ($.$spc.System.Action$$$(TOptions, $.$meca.Microsoft.Extensions.Configuration.IConfiguration))().$ctor(this,  (/*opts*/ opts, /*config*/ config) =>
                {
                    /*IConfiguration*/ let section = $.$spc.System.String.Equals$5("", configSectionPath, 5/*StringComparison.OrdinalIgnoreCase*/) ? config : config.Microsoft$Extensions$Configuration$IConfiguration$GetSection(configSectionPath);
                    $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind$2(section, $.$box(opts, TOptions), configureBinder);
                }, {"r":65537,"p":[{"n":"opts","p":(TOptions) => TOptions.$h},{"n":"config","p":262158}],"n":"","d":65555,"h":0,"f":1048578}));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$6($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions), $.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions), optionsBuilder.Services, new ($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions))().$ctor$2(optionsBuilder.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$meca.Microsoft.Extensions.Configuration.IConfiguration, sp));
                }, {"r":(TOptions) => $.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":65555,"h":0,"f":1048578}));
                return optionsBuilder;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.RequiresDynamicCodeMessage = "Binding strongly typed objects to configuration values may require generating dynamic code at runtime.";
                }
                {
                    this.TrimmingRequiredUnreferencedCodeMessage = "TOptions's dependent types may have their members trimmed. Ensure all required members are preserved.";
                }
            }
            static $h = 65555;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,"p":[{"n":"optionsBuilder","p":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h},{"n":"config","p":262158}],"g":["TOptions"],"n":"Bind","d":65555,"h":12884967443,"f":131105},{"r":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,"p":[{"n":"optionsBuilder","p":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h},{"n":"config","p":262158},{"n":"configureBinder","p":$.$spc.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h}],"g":["TOptions"],"n":"Bind","o":"@$1","d":65555,"h":17179934739,"f":131105},{"r":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,"p":[{"n":"optionsBuilder","p":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h},{"n":"configSectionPath","p":1310721},{"n":"configureBinder","p":$.$spc.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h,"f":65}],"g":["TOptions"],"n":"BindConfiguration","d":65555,"h":21474902035,"f":131105}],"l":[{"t":1310721,"n":"RequiresDynamicCodeMessage","d":65555,"h":4295032851,"f":40},{"t":1310721,"n":"TrimmingRequiredUnreferencedCodeMessage","d":65555,"h":8590000147,"f":40}],"h":65555}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.OptionsBuilderConfigurationExtensions`; }
        });
        
        $asm.$cls("$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource<>", (TOptions) => $asm.$gt("$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource<>", [TOptions], ($self) => class ConfigurationChangeTokenSource$$ extends $.$spc.System.Object
        {
            /*IConfiguration*/ _config = null;
            $ctor$1(/*IConfiguration*/ config)
            {
                this.$ctor$2($.$meo.Microsoft.Extensions.Options.Options.DefaultName, config);
                {
                }
                return this;
            }
            $ctor$2(/*string?*/ name, /*IConfiguration*/ config)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(config, "config");
                    this._config = config;
                    this.Name = name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                }
                return this;
            }
            /*string*/ Name = null;
            /*IChangeToken */ GetChangeToken()
            {
                return this._config.Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken();
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsChangeTokenSource<TOptions>.GetChangeToken()
            Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$GetChangeToken()
            {
                return this.GetChangeToken(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsChangeTokenSource<TOptions>.Name.get
            get Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$Name()
            {
                return this.Name;
            }
            static $h = 196627;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"m":[{"r":720898,"n":"GetChangeToken","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"l":[{"t":262158,"n":"_config","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"config","p":262158}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"name","p":1310721},{"n":"config","p":262158}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"i":[$.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions).$h],"g":[TOptions?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigurationChangeTokenSource<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meoc.Microsoft.Extensions.Options.ConfigureFromConfigurationOptions<>", (TOptions) => $asm.$gt("$meoc.Microsoft.Extensions.Options.ConfigureFromConfigurationOptions<>", [TOptions], ($self) => class ConfigureFromConfigurationOptions$$ extends $.$meo.Microsoft.Extensions.Options.ConfigureOptions$$(TOptions)
        {
            $ctor$2(/*IConfiguration*/ config)
            {
                super.$ctor$1(new ($.$spc.System.Action$$(TOptions))().$ctor(this,  (/**/ options) =>
                {
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind$1(config, $.$box(options, TOptions));
                }, {"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"","d":this.$h,"h":0,"f":1048578}));
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(config, "config");
                }
                return this;
            }
            static $h = 262163;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"c":[{"p":[{"n":"config","p":262158}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$meo.Microsoft.Extensions.Options.ConfigureOptions$$(TOptions); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureFromConfigurationOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meoc.Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions<>", (TOptions) => $asm.$gt("$meoc.Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions<>", [TOptions], ($self) => class NamedConfigureFromConfigurationOptions$$ extends $.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$(TOptions)
        {
            $ctor$2(/*string?*/ name, /*IConfiguration*/ config)
            {
                this.$ctor$3(name, config, new ($.$spc.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions))().$ctor(this,  (/*_*/ _0) =>
                {
                }, {"r":65537,"p":[{"n":"_","p":65551}],"n":"","d":this.$h,"h":0,"f":1048578}));
                {
                }
                return this;
            }
            $ctor$3(/*string?*/ name, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                super.$ctor$1(name, new ($.$spc.System.Action$$(TOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind$2(config, $.$box(options, TOptions), configureBinder);
                }, {"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"","d":this.$h,"h":0,"f":1048578}));
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(config, "config");
                }
                return this;
            }
            static $h = 327699;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"c":[{"p":[{"n":"name","p":1310721},{"n":"config","p":262158}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"name","p":1310721},{"n":"config","p":262158},{"n":"configureBinder","p":$.$spc.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$(TOptions); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions<${TOptions?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"))