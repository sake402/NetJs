
//--TRIMMABLE-BOUNDARY-START(86)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mecga, $mec, $scn, $scm, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $mxdi, $sca, $meo) {
    "use strict";
    let _;
    let $uQjzEg;
    let $XhTcob;
    let $ibrUte;
    let $GQNTYk;
    let $KLVXDc;
    let $sZxjpj;
    let $JyxLtk;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", 
    {
  "h": 86,
  "f": "Microsoft.Extensions.Options.ConfigurationExtensions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65622)
        $asm.$cls(`$meoc.MED.OptionsBuilderConfigurationExtensions`, ($self) => class OptionsBuilderConfigurationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(17179934806)
            /*string*/ static RequiresDynamicCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17179934806)
            
            //--TRIMMABLE-BOUNDARY-START(21474902102)
            /*string*/ static TrimmingRequiredUnreferencedCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(21474902102)
            
            //--TRIMMABLE-BOUNDARY-START(8590000214)
            static /*OptionsBuilder<TOptions> */ Bind$1(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*IConfiguration*/ config)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000214);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meoc.MED.OptionsBuilderConfigurationExtensions.Bind(TOptions, optionsBuilder, config, new ($.$$.S.Action$$($.$mecb.MEC.BinderOptions))().$ctor(this,  (/*_*/ _0) =>
                    {
                    }, $KLVXDc ??= {"r":65537,"p":[{"n":"_","p":65632}],"n":"","d":65622,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000214)
            
            //--TRIMMABLE-BOUNDARY-START(4295032918)
            static /*OptionsBuilder<TOptions> */ Bind(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(optionsBuilder, "optionsBuilder");
                $.$meoc.MED.OptionsConfigurationServiceCollectionExtensions.Configure$2(TOptions, optionsBuilder.Services, optionsBuilder.Name, config, configureBinder);
                return optionsBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032918)
            
            //--TRIMMABLE-BOUNDARY-START(12884967510)
            static /*OptionsBuilder<TOptions> */ BindConfiguration(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*string*/ configSectionPath, /*Action<BinderOptions>?*/ configureBinder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(optionsBuilder, "optionsBuilder");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configSectionPath, "configSectionPath");
                optionsBuilder.Configure$1($.$mecga.MEC.IConfiguration, new ($.$$.S.Action$$$(TOptions, $.$mecga.MEC.IConfiguration))().$ctor(this,  (/*opts*/ opts, /**/ config) =>
                {
                    /*IConfiguration*/ let section = $.$$.S.String.Equals$3("", configSectionPath, 5/*StringComparison.OrdinalIgnoreCase*/) ? config : config.MEC$IConfiguration$GetSection(configSectionPath);
                    $.$mecb.MEC.ConfigurationBinder.Bind(section, $.$box(opts, TOptions), configureBinder);
                }, $sZxjpj ??= {"r":65537,"p":[{"n":"opts","p":(TOptions) => TOptions.$h},{"n":"config","p":393310}],"n":"","d":65622,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$4($.$meo.MEO.IOptionsChangeTokenSource$$(TOptions), $.$meoc.MEO.ConfigurationChangeTokenSource$$(TOptions), optionsBuilder.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meoc.MEO.ConfigurationChangeTokenSource$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meoc.MEO.ConfigurationChangeTokenSource$$(TOptions))().$ctor$2(optionsBuilder.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mecga.MEC.IConfiguration, sp));
                }, $JyxLtk ??= {"r":(TOptions) => $.$meoc.MEO.ConfigurationChangeTokenSource$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":65622,"h":0,"f":17825794}));
                return optionsBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967510)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934806)
                    this.RequiresDynamicCodeMessage = "Binding strongly typed objects to configuration values may require generating dynamic code at runtime.";
                    //--TRIMMABLE-BOUNDARY-END(17179934806)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902102)
                    this.TrimmingRequiredUnreferencedCodeMessage = "TOptions's dependent types may have their members trimmed. Ensure all required members are preserved.";
                    //--TRIMMABLE-BOUNDARY-END(21474902102)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65622;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000214),
    {
      "r": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "optionsBuilder",
          "p": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Bind",
      "o": "@$1",
      "d": 65622,
      "h": 8590000214,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590000214),
//--TRIMMABLE-BOUNDARY-START(4295032918),
    {
      "r": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "optionsBuilder",
          "p": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "configureBinder",
          "p": $.$$.S.Action$$($.$mecb.MEC.BinderOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Bind",
      "d": 65622,
      "h": 4295032918,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295032918),
//--TRIMMABLE-BOUNDARY-START(12884967510),
    {
      "r": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "optionsBuilder",
          "p": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h
        },
        {
          "n": "configSectionPath",
          "p": 1310721
        },
        {
          "n": "configureBinder",
          "p": $.$$.S.Action$$($.$mecb.MEC.BinderOptions).$h,
          "f": 65
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "BindConfiguration",
      "d": 65622,
      "h": 12884967510,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12884967510)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934806),
    {
      "t": 1310721,
      "n": "RequiresDynamicCodeMessage",
      "d": 65622,
      "h": 17179934806,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934806),
//--TRIMMABLE-BOUNDARY-START(21474902102),
    {
      "t": 1310721,
      "n": "TrimmingRequiredUnreferencedCodeMessage",
      "d": 65622,
      "h": 21474902102,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902102)
  ],
  "h": 65622
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.OptionsBuilderConfigurationExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}OptionsBuilderConfigurationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65622)
        
        

        //--TRIMMABLE-BOUNDARY-START(131158)
        $asm.$cls(`$meoc.MED.OptionsConfigurationServiceCollectionExtensions`, ($self) => class OptionsConfigurationServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590065750)
            static /*IServiceCollection */ Configure$1(TOptions, /*this IServiceCollection*/ services, /*IConfiguration*/ config)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065750);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meoc.MED.OptionsConfigurationServiceCollectionExtensions.Configure$3(TOptions, services, $.$meo.MEO.Options.DefaultName, config);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590065750)
            
            //--TRIMMABLE-BOUNDARY-START(17180000342)
            static /*IServiceCollection */ Configure$3(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*IConfiguration*/ config)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000342);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meoc.MED.OptionsConfigurationServiceCollectionExtensions.Configure$2(TOptions, services, name, config, new ($.$$.S.Action$$($.$mecb.MEC.BinderOptions))().$ctor(this,  (/*_*/ _0) =>
                    {
                    }, $uQjzEg ??= {"r":65537,"p":[{"n":"_","p":65632}],"n":"","d":131158,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180000342)
            
            //--TRIMMABLE-BOUNDARY-START(4295098454)
            static /*IServiceCollection */ Configure(TOptions, /*this IServiceCollection*/ services, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098454);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meoc.MED.OptionsConfigurationServiceCollectionExtensions.Configure$2(TOptions, services, $.$meo.MEO.Options.DefaultName, config, configureBinder);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098454)
            
            //--TRIMMABLE-BOUNDARY-START(12885033046)
            static /*IServiceCollection */ Configure$2(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(config, "config");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.MEO.IOptionsChangeTokenSource$$(TOptions), services, new ($.$meoc.MEO.ConfigurationChangeTokenSource$$(TOptions))().$ctor$2(name, config));
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.MEO.IConfigureOptions$$(TOptions), services, new ($.$meoc.MEO.NamedConfigureFromConfigurationOptions$$(TOptions))().$ctor$2(name, config, configureBinder));
            }
            //--TRIMMABLE-BOUNDARY-END(12885033046)
            
            static $h = 131158;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590065750),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "o": "@$1",
      "d": 131158,
      "h": 8590065750,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590065750),
//--TRIMMABLE-BOUNDARY-START(17180000342),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "o": "@$3",
      "d": 131158,
      "h": 17180000342,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180000342),
//--TRIMMABLE-BOUNDARY-START(4295098454),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "configureBinder",
          "p": $.$$.S.Action$$($.$mecb.MEC.BinderOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "d": 131158,
      "h": 4295098454,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295098454),
//--TRIMMABLE-BOUNDARY-START(12885033046),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "configureBinder",
          "p": $.$$.S.Action$$($.$mecb.MEC.BinderOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "o": "@$2",
      "d": 131158,
      "h": 12885033046,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885033046)
  ],
  "h": 131158
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}OptionsConfigurationServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131158)
        
        

        //--TRIMMABLE-BOUNDARY-START(196694)
        $asm.$cls(`$meoc.MEO.ConfigurationChangeTokenSource<>`, (TOptions) => $asm.$gt(`$meoc.MEO.ConfigurationChangeTokenSource<>`, [TOptions], ($self) => class ConfigurationChangeTokenSource$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163990)
            /*IConfiguration*/ _config = null;
            //--TRIMMABLE-BOUNDARY-END(4295163990)
            
            //--TRIMMABLE-BOUNDARY-START(12885098582)
            $ctor$1(/*IConfiguration*/ config)
            {
                this.$ctor$2($.$meo.MEO.Options.DefaultName, config);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098582);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098582)
            
            //--TRIMMABLE-BOUNDARY-START(17180065878)
            $ctor$2(/*string?*/ name, /*IConfiguration*/ config)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065878);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(config, "config");
                    this._config = config;
                    this.Name = name ?? $.$meo.MEO.Options.DefaultName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065878)
            
            //--TRIMMABLE-BOUNDARY-START(34359935062)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(34359935062)
            
            //--TRIMMABLE-BOUNDARY-START(30064967766)
            /*IChangeToken */ GetChangeToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._config.MEC$IConfiguration$GetReloadToken();
            }
            //--TRIMMABLE-BOUNDARY-END(30064967766)
            
            //--TRIMMABLE-BOUNDARY-START(12885753943)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsChangeTokenSource<TOptions>.GetChangeToken()
            MEO$IOptionsChangeTokenSource$$$GetChangeToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChangeToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753943)
            
            //--TRIMMABLE-BOUNDARY-START(8590786647)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsChangeTokenSource<TOptions>.Name.get
            get MEO$IOptionsChangeTokenSource$$$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786647)
            
            static $H = 196694;
            static $h = 196694;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359935062),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770000470,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 34359935062,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359935062)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064967766),
    {
      "r": 720981,
      "n": "GetChangeToken",
      "d": this.$h,
      "H": 30064967766,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064967766)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163990),
    {
      "t": 393310,
      "n": "_config",
      "d": this.$h,
      "H": 4295163990,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163990)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098582),
    {
      "p": [
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12885098582,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098582),
//--TRIMMABLE-BOUNDARY-START(17180065878),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 17180065878,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065878)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions"
    }
  ],
  "r": 1,
  "H": 196694,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptionsChangeTokenSource$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigurationChangeTokenSource<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigurationChangeTokenSource$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196694)
        
        

        //--TRIMMABLE-BOUNDARY-START(262230)
        $asm.$cls(`$meoc.MEO.ConfigureFromConfigurationOptions<>`, (TOptions) => $asm.$gt(`$meoc.MEO.ConfigureFromConfigurationOptions<>`, [TOptions], ($self) => class ConfigureFromConfigurationOptions$$ extends $.$meo.MEO.ConfigureOptions$$(TOptions)
        {
            //--TRIMMABLE-BOUNDARY-START(4295229526)
            $ctor$2(/*IConfiguration*/ config)
            {
                super.$ctor$1(new ($.$$.S.Action$$(TOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mecb.MEC.ConfigurationBinder.Bind$1(config, $.$box(options, TOptions));
                }, $XhTcob ??= {"r":65537,"p":[{"n":"options","p":TOptions?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229526);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(config, "config");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229526)
            
            static $H = 262230;
            static $h = 262230;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$meo.MEO.ConfigureOptions$$(TOptions); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229526),
    {
      "p": [
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295229526,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229526)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 262230,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigureFromConfigurationOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigureFromConfigurationOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262230)
        
        

        //--TRIMMABLE-BOUNDARY-START(327766)
        $asm.$cls(`$meoc.MEO.NamedConfigureFromConfigurationOptions<>`, (TOptions) => $asm.$gt(`$meoc.MEO.NamedConfigureFromConfigurationOptions<>`, [TOptions], ($self) => class NamedConfigureFromConfigurationOptions$$ extends $.$meo.MEO.ConfigureNamedOptions$$(TOptions)
        {
            //--TRIMMABLE-BOUNDARY-START(8590262358)
            $ctor$3(/*string?*/ name, /*IConfiguration*/ config)
            {
                this.$ctor$2(name, config, new ($.$$.S.Action$$($.$mecb.MEC.BinderOptions))().$ctor(this,  (/*_*/ _0) =>
                {
                }, $ibrUte ??= {"r":65537,"p":[{"n":"_","p":65632}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262358);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262358)
            
            //--TRIMMABLE-BOUNDARY-START(4295295062)
            $ctor$2(/*string?*/ name, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                super.$ctor$1(name, new ($.$$.S.Action$$(TOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mecb.MEC.ConfigurationBinder.Bind(config, $.$box(options, TOptions), configureBinder);
                }, $GQNTYk ??= {"r":65537,"p":[{"n":"options","p":TOptions?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295062);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(config, "config");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295062)
            
            static $H = 327766;
            static $h = 327766;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$meo.MEO.ConfigureNamedOptions$$(TOptions); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262358),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 8590262358,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262358),
//--TRIMMABLE-BOUNDARY-START(4295295062),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "configureBinder",
          "p": $.$$.S.Action$$($.$mecb.MEC.BinderOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295295062,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295062)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 327766,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureNamedOptions$$(TOptions), $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}NamedConfigureFromConfigurationOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327766)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"));
})();
//--TRIMMABLE-BOUNDARY-END(86)
