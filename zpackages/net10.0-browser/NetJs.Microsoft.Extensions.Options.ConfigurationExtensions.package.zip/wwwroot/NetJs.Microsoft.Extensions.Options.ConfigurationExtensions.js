
//--TRIMMABLE-BOUNDARY-START(86)
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $scn, $scm, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $mxdi, $sca, $meo) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", 
    {
  "h": 86,
  "f": "Microsoft.Extensions.Options.ConfigurationExtensions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65622)
        $asm.$cls("$meoc.Microsoft.Extensions.DependencyInjection.OptionsBuilderConfigurationExtensions", ($self) => class OptionsBuilderConfigurationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(17179934806)
            /*string*/ static RequiresDynamicCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17179934806)
            
            //--TRIMMABLE-BOUNDARY-START(21474902102)
            /*string*/ static TrimmingRequiredUnreferencedCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(21474902102)
            
            //--TRIMMABLE-BOUNDARY-START(4295032918)
            static /*OptionsBuilder<TOptions> */ Bind$1(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*IConfiguration*/ config)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032918);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsBuilderConfigurationExtensions.Bind(TOptions, optionsBuilder, config, new ($.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions))().$ctor(this,  (/**/ _0) =>
                    {
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "_",
      "p": 65632
    }
  ],
  "n": "",
  "d": 65622,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032918)
            
            //--TRIMMABLE-BOUNDARY-START(8590000214)
            static /*OptionsBuilder<TOptions> */ Bind(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(optionsBuilder, "optionsBuilder");
                $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions.Configure(TOptions, optionsBuilder.Services, optionsBuilder.Name, config, configureBinder);
                return optionsBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000214)
            
            //--TRIMMABLE-BOUNDARY-START(12884967510)
            static /*OptionsBuilder<TOptions> */ BindConfiguration(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder, /*string*/ configSectionPath, /*Action<BinderOptions>?*/ configureBinder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(optionsBuilder, "optionsBuilder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configSectionPath, "configSectionPath");
                optionsBuilder.Configure$1($.$meca.Microsoft.Extensions.Configuration.IConfiguration, new ($.$$.System.Action$$$(TOptions, $.$meca.Microsoft.Extensions.Configuration.IConfiguration))().$ctor(this,  (/*opts*/ opts, /*config*/ config) =>
                {
                    /*IConfiguration*/ let section = $.$$.System.String.Equals$2("", configSectionPath, 5/*StringComparison.OrdinalIgnoreCase*/) ? config : config.Microsoft$Extensions$Configuration$IConfiguration$GetSection(configSectionPath);
                    $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind(section, $.$box(opts, TOptions), configureBinder);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "opts",
      "p": (TOptions) => TOptions.$h
    },
    {
      "n": "config",
      "p": 393310
    }
  ],
  "n": "",
  "d": 65622,
  "h": 0,
  "f": 17825794
}));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$4($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions), $.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions), optionsBuilder.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions))().$ctor$1(optionsBuilder.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$meca.Microsoft.Extensions.Configuration.IConfiguration, sp));
                }, {
  "r": (TOptions) => $.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": 65622,
  "h": 0,
  "f": 17825794
}));
                return optionsBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967510)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934806)
                    this.RequiresDynamicCodeMessage = "Binding strongly typed objects to configuration values may require generating dynamic code at runtime.";
                    //--TRIMMABLE-BOUNDARY-END(17179934806)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902102)
                    this.TrimmingRequiredUnreferencedCodeMessage = "TOptions's dependent types may have their members trimmed. Ensure all required members are preserved.";
                    //--TRIMMABLE-BOUNDARY-END(21474902102)
                    
                }
            }
            static $h = 65622;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032918),
    {
      "r": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "optionsBuilder",
          "p": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Bind",
      "o": "@$1",
      "d": 65622,
      "h": 4295032918,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295032918),
//--TRIMMABLE-BOUNDARY-START(8590000214),
    {
      "r": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "optionsBuilder",
          "p": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "configureBinder",
          "p": $.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Bind",
      "d": 65622,
      "h": 8590000214,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590000214),
//--TRIMMABLE-BOUNDARY-START(12884967510),
    {
      "r": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "optionsBuilder",
          "p": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h
        },
        {
          "n": "configSectionPath",
          "p": 1310721
        },
        {
          "n": "configureBinder",
          "p": $.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h,
          "f": 65
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "BindConfiguration",
      "d": 65622,
      "h": 12884967510,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12884967510)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934806),
    {
      "t": 1310721,
      "n": "RequiresDynamicCodeMessage",
      "d": 65622,
      "h": 17179934806,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934806),
//--TRIMMABLE-BOUNDARY-START(21474902102),
    {
      "t": 1310721,
      "n": "TrimmingRequiredUnreferencedCodeMessage",
      "d": 65622,
      "h": 21474902102,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902102)
  ],
  "h": 65622
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.OptionsBuilderConfigurationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65622)
        
        
        //--TRIMMABLE-BOUNDARY-START(131158)
        $asm.$cls("$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions", ($self) => class OptionsConfigurationServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295098454)
            static /*IServiceCollection */ Configure$3(TOptions, /*this IServiceCollection*/ services, /*IConfiguration*/ config)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098454);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions.Configure$1(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName, config);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098454)
            
            //--TRIMMABLE-BOUNDARY-START(8590065750)
            static /*IServiceCollection */ Configure$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*IConfiguration*/ config)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065750);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions.Configure(TOptions, services, name, config, new ($.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions))().$ctor(this,  (/*_*/ _0) =>
                    {
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "_",
      "p": 65632
    }
  ],
  "n": "",
  "d": 131158,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590065750)
            
            //--TRIMMABLE-BOUNDARY-START(12885033046)
            static /*IServiceCollection */ Configure$2(TOptions, /*this IServiceCollection*/ services, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033046);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meoc.Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions.Configure(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName, config, configureBinder);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885033046)
            
            //--TRIMMABLE-BOUNDARY-START(17180000342)
            static /*IServiceCollection */ Configure(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(config, "config");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions), services, new ($.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$(TOptions))().$ctor$1(name, config));
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), services, new ($.$meoc.Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions$$(TOptions))().$ctor$2(name, config, configureBinder));
            }
            //--TRIMMABLE-BOUNDARY-END(17180000342)
            
            static $h = 131158;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098454),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "o": "@$3",
      "d": 131158,
      "h": 4295098454,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295098454),
//--TRIMMABLE-BOUNDARY-START(8590065750),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "o": "@$1",
      "d": 131158,
      "h": 8590065750,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590065750),
//--TRIMMABLE-BOUNDARY-START(12885033046),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "configureBinder",
          "p": $.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "o": "@$2",
      "d": 131158,
      "h": 12885033046,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885033046),
//--TRIMMABLE-BOUNDARY-START(17180000342),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "configureBinder",
          "p": $.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "d": 131158,
      "h": 17180000342,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180000342)
  ],
  "h": 131158
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.OptionsConfigurationServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131158)
        
        
        //--TRIMMABLE-BOUNDARY-START(196694)
        $asm.$cls("$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource<>", (TOptions) => $asm.$gt("$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource<>", [TOptions], ($self) => class ConfigurationChangeTokenSource$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163990)
            /*IConfiguration*/ _config = null;
            //--TRIMMABLE-BOUNDARY-END(4295163990)
            
            //--TRIMMABLE-BOUNDARY-START(8590131286)
            $ctor$2(/*IConfiguration*/ config)
            {
                this.$ctor$1($.$meo.Microsoft.Extensions.Options.Options.DefaultName, config);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131286);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131286)
            
            //--TRIMMABLE-BOUNDARY-START(12885098582)
            $ctor$1(/*string?*/ name, /*IConfiguration*/ config)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098582);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(config, "config");
                    this._config = config;
                    this.Name = name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098582)
            
            //--TRIMMABLE-BOUNDARY-START(34359935062)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(34359935062)
            
            //--TRIMMABLE-BOUNDARY-START(30064967766)
            /*IChangeToken */ GetChangeToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._config.Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken();
            }
            //--TRIMMABLE-BOUNDARY-END(30064967766)
            
            //--TRIMMABLE-BOUNDARY-START(12885753943)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsChangeTokenSource<TOptions>.GetChangeToken()
            Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$GetChangeToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChangeToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753943)
            
            //--TRIMMABLE-BOUNDARY-START(8590786647)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsChangeTokenSource<TOptions>.Name.get
            get Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786647)
            
            static $h = 196694;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359935062),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359935062)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064967766),
    {
      "r": 720981,
      "n": "GetChangeToken",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064967766)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163990),
    {
      "t": 393310,
      "n": "_config",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163990)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131286),
    {
      "p": [
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131286),
//--TRIMMABLE-BOUNDARY-START(12885098582),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098582)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigurationChangeTokenSource<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196694)
        
        
        //--TRIMMABLE-BOUNDARY-START(262230)
        $asm.$cls("$meoc.Microsoft.Extensions.Options.ConfigureFromConfigurationOptions<>", (TOptions) => $asm.$gt("$meoc.Microsoft.Extensions.Options.ConfigureFromConfigurationOptions<>", [TOptions], ($self) => class ConfigureFromConfigurationOptions$$ extends $.$meo.Microsoft.Extensions.Options.ConfigureOptions$$(TOptions)
        {
            //--TRIMMABLE-BOUNDARY-START(4295229526)
            $ctor$2(/*IConfiguration*/ config)
            {
                super.$ctor$1(new ($.$$.System.Action$$(TOptions))().$ctor(this,  (/**/ options) =>
                {
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind$1(config, $.$box(options, TOptions));
                }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": TOptions?.$h??1507328
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229526);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(config, "config");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229526)
            
            static $h = 262230;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229526),
    {
      "p": [
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229526)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$meo.Microsoft.Extensions.Options.ConfigureOptions$$(TOptions); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureFromConfigurationOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262230)
        
        
        //--TRIMMABLE-BOUNDARY-START(327766)
        $asm.$cls("$meoc.Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions<>", (TOptions) => $asm.$gt("$meoc.Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions<>", [TOptions], ($self) => class NamedConfigureFromConfigurationOptions$$ extends $.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$(TOptions)
        {
            //--TRIMMABLE-BOUNDARY-START(4295295062)
            $ctor$3(/*string?*/ name, /*IConfiguration*/ config)
            {
                this.$ctor$2(name, config, new ($.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions))().$ctor(this,  (/*_*/ _0) =>
                {
                }, {
  "r": 65537,
  "p": [
    {
      "n": "_",
      "p": 65632
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295062);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295062)
            
            //--TRIMMABLE-BOUNDARY-START(8590262358)
            $ctor$2(/*string?*/ name, /*IConfiguration*/ config, /*Action<BinderOptions>?*/ configureBinder)
            {
                super.$ctor$1(name, new ($.$$.System.Action$$(TOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind(config, $.$box(options, TOptions), configureBinder);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": TOptions?.$h??1507328
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262358);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(config, "config");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262358)
            
            static $h = 327766;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295062),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295062),
//--TRIMMABLE-BOUNDARY-START(8590262358),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "configureBinder",
          "p": $.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262358)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$(TOptions); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.NamedConfigureFromConfigurationOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327766)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"))
//--TRIMMABLE-BOUNDARY-END(86)
