
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $mwp, $scn, $scp, $scs, $sdp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Options", 
    {"h":18,"f":"Microsoft.Extensions.Options","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Options","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Options","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.Extensions.Options.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsMonitor<>", (/*out*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsMonitor<>", [/*out*/ TOptions], ($self) => class IOptionsMonitor$$
        {
            static $h = 983058;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":TOptions?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":50856193},"n":"CurrentValue","o":"Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2097409}],"m":[{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721}],"n":"Get","o":"Microsoft$Extensions$Options$IOptionsMonitor$$$Get","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":17301761},{"r":57540609,"p":[{"n":"listener","p":$.$$.System.Action$$$(TOptions, $.$$.System.String).$h}],"n":"OnChange","o":"Microsoft$Extensions$Options$IOptionsMonitor$$$OnChange","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777473}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":32}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsMonitor<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IStartupValidator", ($self) => class IStartupValidator
        {
            static $h = 1245202;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Validate","o":"Microsoft$Extensions$Options$IStartupValidator$Validate","d":1245202,"h":4296212498,"f":16777473}],"h":1245202}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IStartupValidator`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptions<>", (/*out*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptions<>", [/*out*/ TOptions], ($self) => class IOptions$$
        {
            static $h = 786450;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":TOptions?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":50856193},"n":"Value","o":"Microsoft$Extensions$Options$IOptions$$$Value","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2097409}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":33}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource<>", (/*out*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource<>", [/*out*/ TOptions], ($self) => class IOptionsChangeTokenSource$$
        {
            static $h = 851986;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331905},"n":"Name","o":"Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$Name","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097409}],"m":[{"r":720898,"n":"GetChangeToken","o":"Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$GetChangeToken","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":32}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsChangeTokenSource<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IValidateOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IValidateOptions<>", [TOptions], ($self) => class IValidateOptions$$
        {
            static $h = 1310738;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3211282,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Validate","o":"Microsoft$Extensions$Options$IValidateOptions$$$Validate","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IValidateOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsMonitorCache<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsMonitorCache<>", [TOptions], ($self) => class IOptionsMonitorCache$$
        {
            static $h = 1048594;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721},{"n":"createOptions","p":$.$$.System.Func$$(TOptions).$h}],"n":"GetOrAdd","o":"Microsoft$Extensions$Options$IOptionsMonitorCache$$$GetOrAdd","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473},{"r":262145,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"TryAdd","o":"Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryAdd","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777473},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"TryRemove","o":"Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryRemove","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777473},{"r":65537,"n":"Clear","o":"Microsoft$Extensions$Options$IOptionsMonitorCache$$$Clear","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777473}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsMonitorCache<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IConfigureOptions<>", (/*in*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IConfigureOptions<>", [/*in*/ TOptions], ($self) => class IConfigureOptions$$
        {
            static $h = 720914;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328,"f":32}],"n":"Configure","o":"Microsoft$Extensions$Options$IConfigureOptions$$$Configure","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":17}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IConfigureOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsFactory<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsFactory<>", [TOptions], ($self) => class IOptionsFactory$$
        {
            static $h = 917522;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721}],"n":"Create","o":"Microsoft$Extensions$Options$IOptionsFactory$$$Create","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsFactory<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IPostConfigureOptions<>", (/*in*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IPostConfigureOptions<>", [/*in*/ TOptions], ($self) => class IPostConfigureOptions$$
        {
            static $h = 1179666;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328,"f":32}],"n":"PostConfigure","o":"Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":17}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IPostConfigureOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsSnapshot<>", (/*out*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsSnapshot<>", [/*out*/ TOptions], ($self) => class IOptionsSnapshot$$
        {
            static $h = 1114130;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721}],"n":"Get","o":"Microsoft$Extensions$Options$IOptionsSnapshot$$$Get","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":17301761}],"i":[$.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":33}],"r":1,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsSnapshot<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.IConfigureNamedOptions<>", (/*in*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IConfigureNamedOptions<>", [/*in*/ TOptions], ($self) => class IConfigureNamedOptions$$
        {
            static $h = 655378;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328,"f":32}],"n":"Configure","o":"Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":17}],"r":1,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.IConfigureNamedOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.Options", ($self) => class Options
        {
            /*DynamicallyAccessedMemberTypes*/ static DynamicallyAccessedMembers = 1;
            /*string*/ static DefaultName = null;
            static /*IOptions<TOptions> */ Create(TOptions, /*TOptions*/ options)
            {
                return new ($.$meo.Microsoft.Extensions.Options.OptionsWrapper$$(TOptions))().$ctor$1(options);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultName = $.$$.System.String.Empty;
                }
            }
            static $h = 1376274;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TOptions) => $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h,"p":[{"n":"options","p":(TOptions) => TOptions.$h}],"g":["TOptions"],"n":"Create","d":1376274,"h":12886278162,"f":16908321}],"l":[{"n":"DynamicallyAccessedMembers","d":1376274,"h":4296343570,"f":4194344},{"t":1310721,"n":"DefaultName","d":1376274,"h":8591310866,"f":4194337}],"h":1376274}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.Options`; }
        });
        
        $asm.$cls("$meo.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$meo.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Options", $.$meo.System.SR.$type.Assembly);
                    $.$meo.System.SR.s_resourceManager = temp;
                }
                return $.$meo.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$meo.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$meo.System.SR.resourceCulture = value;
            }
            static /*string */ get Error_CannotActivateAbstractOrInterface()
            {
                return "Cannot create instance of type '{0}' because it is either abstract or an interface.";
            }
            static /*string */ FormatError_CannotActivateAbstractOrInterface(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it is either abstract or an interface.", arg1);
            }
            static /*string */ get Error_FailedBinding()
            {
                return "Failed to convert '{0}' to type '{1}'.";
            }
            static /*string */ FormatError_FailedBinding(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("Failed to convert '{0}' to type '{1}'.", arg1, arg2);
            }
            static /*string */ get Error_FailedToActivate()
            {
                return "Failed to create instance of type '{0}'.";
            }
            static /*string */ FormatError_FailedToActivate(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Failed to create instance of type '{0}'.", arg1);
            }
            static /*string */ get Error_MissingParameterlessConstructor()
            {
                return "Cannot create instance of type '{0}' because it is missing a public parameterless constructor.";
            }
            static /*string */ FormatError_MissingParameterlessConstructor(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it is missing a public parameterless constructor.", arg1);
            }
            static /*string */ get Error_NoConfigurationServices()
            {
                return "No IConfigureOptions<>, IPostConfigureOptions<>, or IValidateOptions<> implementations were found.";
            }
            static /*string */ get Error_NoConfigurationServicesAndAction()
            {
                return "No IConfigureOptions<>, IPostConfigureOptions<>, or IValidateOptions<> implementations were found, did you mean to call Configure<> or PostConfigure<>?";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$meo.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$meo.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$meo.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$meo.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$meo.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$meo.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3342354;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3342354}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptionsResult", ($self) => class ValidateOptionsResult extends $.$$.System.Object
        {
            /*ValidateOptionsResult*/ static Skip = null;
            /*ValidateOptionsResult*/ static Success = null;
            /*bool*/ Succeeded = false;
            /*bool*/ Skipped = false;
            /*bool*/ Failed = false;
            /*string?*/ FailureMessage = null;
            /*IEnumerable<string>?*/ Failures = null;
            static /*ValidateOptionsResult */ Fail$1(/*string*/ failureMessage)
            {
                return (() =>
                {
                    //new $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult()
                    const $t1 = $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult;
                    const $i1 = new $t1();
                    $i1.Failed = true;
                    $i1.FailureMessage = failureMessage;
                    $i1.Failures = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [failureMessage], [-1], null);
                    return $i1;
                })();
            }
            static /*ValidateOptionsResult */ Fail(/*IEnumerable<string>*/ failures)
            {
                return (() =>
                {
                    //new $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult()
                    const $t1 = $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult;
                    const $i1 = new $t1();
                    $i1.Failed = true;
                    $i1.FailureMessage = $.$$.System.String.Join$5("; ", failures);
                    $i1.Failures = failures;
                    return $i1;
                })();
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Succeeded = false;
                this.Skipped = false;
                this.Failed = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Skip = (() =>
                    {
                        //new $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult()
                        const $t1 = $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult;
                        const $i1 = new $t1();
                        $i1.Skipped = true;
                        return $i1;
                    })();
                }
                {
                    this.Success = (() =>
                    {
                        //new $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult()
                        const $t1 = $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult;
                        const $i1 = new $t1();
                        $i1.Succeeded = true;
                        return $i1;
                    })();
                }
            }
            static $h = 3211282;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21478047762,"f":50331649},"s":{"r":0,"d":0,"h":25773015058,"f":83886084},"n":"Succeeded","d":3211282,"h":17183080466,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38657916946,"f":50331649},"s":{"r":0,"d":0,"h":42952884242,"f":83886084},"n":"Skipped","d":3211282,"h":34362949650,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":55837786130,"f":50331649},"s":{"r":0,"d":0,"h":60132753426,"f":83886084},"n":"Failed","d":3211282,"h":51542818834,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":73017655314,"f":50331649},"s":{"r":0,"d":0,"h":77312622610,"f":83886084},"n":"FailureMessage","d":3211282,"h":68722688018,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":90197524498,"f":50331649},"s":{"r":0,"d":0,"h":94492491794,"f":83886084},"n":"Failures","d":3211282,"h":85902557202,"f":2097153}],"m":[{"r":3211282,"p":[{"n":"failureMessage","p":1310721}],"n":"Fail","o":"@$1","d":3211282,"h":98787459090,"f":16777249},{"r":3211282,"p":[{"n":"failures","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":"Fail","d":3211282,"h":103082426386,"f":16777249}],"l":[{"t":3211282,"n":"Skip","d":3211282,"h":4298178578,"f":4194337},{"t":3211282,"n":"Success","d":3211282,"h":8593145874,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":3211282,"h":107377393682,"f":16777217}],"h":3211282}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptionsResult`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptionsResultBuilder", ($self) => class ValidateOptionsResultBuilder extends $.$$.System.Object
        {
            /*string*/ static MemberSeparatorString = null;
            /*List<string>?*/ _errors = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ AddError(/*string*/ error, /*string?*/ propertyName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(error, "error");
                this.Errors.Add(propertyName === null ? error : `Property ${propertyName}: ${error}`);
            }
            /*void */ AddResult$1(/*ValidationResult?*/ result)
            {
                if (!((result?.ErrorMessage ?? null) === null))
                {
                    /*string*/ let joinedMembers = $.$$.System.String.Join$5(", "/*MemberSeparatorString*/, result.MemberNames);
                    this.Errors.Add(joinedMembers.length !== 0 ? `${joinedMembers}: ${result.ErrorMessage}` : result.ErrorMessage);
                }
            }
            /*void */ AddResults(/*IEnumerable<ValidationResult?>?*/ results)
            {
                if (results !== null)
                {
                    var $en3 = results.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var result = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddResult$1(result);
                        }
                    }
                }
            }
            /*void */ AddResult(/*ValidateOptionsResult*/ result)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(result, "result");
                if (result.Failed)
                {
                    if (result.Failures === null)
                    {
                        this.Errors.Add(result.FailureMessage);
                    }
                    else 
                    {
                        var $en4 = result.Failures.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var failure = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (!(failure === null))
                                {
                                    this.Errors.Add(failure);
                                }
                            }
                        }
                    }
                }
            }
            /*ValidateOptionsResult */ Build()
            {
                if ($.$$.System.Int32.op_GreaterThan$1((this._errors?.Count ?? null), 0))
                {
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail(this._errors);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
            }
            /*void */ Clear()
            {
                return (this._errors?.Clear() ?? null);
            }
            /*int */ get ErrorsCount()
            {
                return this._errors === null ? 0 : this._errors.Count;
            }
            /*List<string> */ get Errors()
            {
                return this._errors ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MemberSeparatorString = ", ";
                }
            }
            static $h = 3276818;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":47247917074,"f":50331650},"n":"ErrorsCount","d":3276818,"h":42952949778,"f":2097154},{"p":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":55837851666,"f":50331650},"n":"Errors","d":3276818,"h":51542884370,"f":2097154}],"m":[{"r":65537,"p":[{"n":"error","p":1310721},{"n":"propertyName","p":1310721,"f":65}],"n":"AddError","d":3276818,"h":17183146002,"f":16777217},{"r":65537,"p":[{"n":"result","p":3670054}],"n":"AddResult","o":"@$1","d":3276818,"h":21478113298,"f":16777217},{"r":65537,"p":[{"n":"results","p":$.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h}],"n":"AddResults","d":3276818,"h":25773080594,"f":16777217},{"r":65537,"p":[{"n":"result","p":3211282}],"n":"AddResult","d":3276818,"h":30068047890,"f":16777217},{"r":3211282,"n":"Build","d":3276818,"h":34363015186,"f":16777217},{"r":65537,"n":"Clear","d":3276818,"h":38657982482,"f":16777217}],"l":[{"t":1310721,"n":"MemberSeparatorString","d":3276818,"h":4298244114,"f":4194338},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h,"n":"_errors","d":3276818,"h":8593211410,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":3276818,"h":12888178706,"f":16777217}],"h":3276818,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{ErrorsCount} errors","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptionsResultBuilder`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsMonitorExtensions", ($self) => class OptionsMonitorExtensions
        {
            static /*IDisposable? */ OnChange(TOptions, /*this IOptionsMonitor<TOptions>*/ monitor, /*Action<TOptions>*/ listener)
            {
                return monitor.Microsoft$Extensions$Options$IOptionsMonitor$$$OnChange(new ($.$$.System.Action$$$(TOptions, $.$$.System.String))().$ctor(this,  (/*o*/ o, /*_*/ _1) =>
                {
                    return listener.Invoke(o);
                }, {"r":65537,"p":[{"n":"o","p":(TOptions) => TOptions.$h},{"n":"_","p":1310721}],"n":"","d":1835026,"h":0,"f":17825794}), [TOptions]);
            }
            static $h = 1835026;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":57540609,"p":[{"n":"monitor","p":(TOptions) => $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions).$h},{"n":"listener","p":(TOptions) => $.$$.System.Action$$(TOptions).$h}],"g":["TOptions"],"n":"OnChange","d":1835026,"h":4296802322,"f":16908321}],"h":1835026}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsMonitorExtensions`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.StartupValidatorOptions", ($self) => class StartupValidatorOptions extends $.$$.System.Object
        {
            /*Dictionary<(Type, string), Action>*/ _validators = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._validators = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String), $.$$.System.Action))().$ctor$1();
            }
            static $h = 2555922;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String), $.$$.System.Action).$h,"g":{"r":0,"d":0,"h":12887457810,"f":50331649},"n":"_validators","d":2555922,"h":8592490514,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":2555922,"h":17182425106,"f":16777217}],"h":2555922}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.StartupValidatorOptions`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsBuilder<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsBuilder<>", [TOptions], ($self) => class OptionsBuilder$$ extends $.$$.System.Object
        {
            /*string*/ static DefaultValidationFailureMessage = null;
            /*string*/ Name = null;
            /*IServiceCollection*/ Services = null;
            $ctor$1(/*IServiceCollection*/ services, /*string?*/ name)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                    this.Services = services;
                    this.Name = name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                }
                return this;
            }
            /*OptionsBuilder<TOptions> */ Configure(/*Action<TOptions>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$(TOptions))().$ctor$1(this.Name, configureOptions));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Configure$1(TDep, /*Action<TOptions, TDep>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Configure$5(TDep1, TDep2, /*Action<TOptions, TDep1, TDep2>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Configure$4(TDep1, TDep2, TDep3, /*Action<TOptions, TDep1, TDep2, TDep3>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Configure$3(TDep1, TDep2, TDep3, TDep4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Configure$2(TDep1, TDep2, TDep3, TDep4, TDep5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ PostConfigure(/*Action<TOptions>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$(TOptions))().$ctor$1(this.Name, configureOptions));
                return this;
            }
            /*OptionsBuilder<TOptions> */ PostConfigure$1(TDep, /*Action<TOptions, TDep>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ PostConfigure$5(TDep1, TDep2, /*Action<TOptions, TDep1, TDep2>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ PostConfigure$4(TDep1, TDep2, TDep3, /*Action<TOptions, TDep1, TDep2, TDep3>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ PostConfigure$3(TDep1, TDep2, TDep3, TDep4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/**/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ PostConfigure$2(TDep1, TDep2, TDep3, TDep4, TDep5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), configureOptions);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Validate$1(/*Func<TOptions, bool>*/ validation)
            {
                return this.Validate(validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
            }
            /*OptionsBuilder<TOptions> */ Validate(/*Func<TOptions, bool>*/ validation, /*string*/ failureMessage)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$(TOptions))().$ctor$1(this.Name, validation, failureMessage));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Validate$3(TDep, /*Func<TOptions, TDep, bool>*/ validation)
            {
                return this.Validate$2(TDep, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
            }
            /*OptionsBuilder<TOptions> */ Validate$2(TDep, /*Func<TOptions, TDep, bool>*/ validation, /*string*/ failureMessage)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), validation, failureMessage);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Validate$11(TDep1, TDep2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation)
            {
                return this.Validate$10(TDep1, TDep2, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
            }
            /*OptionsBuilder<TOptions> */ Validate$10(TDep1, TDep2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation, /*string*/ failureMessage)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), validation, failureMessage);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Validate$9(TDep1, TDep2, TDep3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation)
            {
                return this.Validate$8(TDep1, TDep2, TDep3, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
            }
            /*OptionsBuilder<TOptions> */ Validate$8(TDep1, TDep2, TDep3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation, /*string*/ failureMessage)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), validation, failureMessage);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Validate$7(TDep1, TDep2, TDep3, TDep4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation)
            {
                return this.Validate$6(TDep1, TDep2, TDep3, TDep4, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
            }
            /*OptionsBuilder<TOptions> */ Validate$6(TDep1, TDep2, TDep3, TDep4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation, /*string*/ failureMessage)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), validation, failureMessage);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            /*OptionsBuilder<TOptions> */ Validate$5(TDep1, TDep2, TDep3, TDep4, TDep5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation)
            {
                return this.Validate$4(TDep1, TDep2, TDep3, TDep4, TDep5, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
            }
            /*OptionsBuilder<TOptions> */ Validate$4(TDep1, TDep2, TDep3, TDep4, TDep5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation, /*string*/ failureMessage)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), validation, failureMessage);
                }, {"r":$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327717}],"n":"","d":this.$h,"h":0,"f":17825794}));
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultValidationFailureMessage = "A validation error has occurred.";
                }
            }
            static $h = 1441810;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":786435,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Services","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153}],"m":[{"r":this.$h,"p":[{"n":"configureOptions","p":$.$$.System.Action$$(TOptions).$h}],"n":"Configure","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777345},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep) => $.$$.System.Action$$$(TOptions, TDep).$h}],"g":["TDep"],"n":"Configure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep1, TDep2) => $.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h}],"g":["TDep1","TDep2"],"n":"Configure","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep1, TDep2, TDep3) => $.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h}],"g":["TDep1","TDep2","TDep3"],"n":"Configure","o":"@$4","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep1, TDep2, TDep3, TDep4) => $.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h}],"g":["TDep1","TDep2","TDep3","TDep4"],"n":"Configure","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h}],"g":["TDep1","TDep2","TDep3","TDep4","TDep5"],"n":"Configure","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":$.$$.System.Action$$(TOptions).$h}],"n":"PostConfigure","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777345},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep) => $.$$.System.Action$$$(TOptions, TDep).$h}],"g":["TDep"],"n":"PostConfigure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep1, TDep2) => $.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h}],"g":["TDep1","TDep2"],"n":"PostConfigure","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep1, TDep2, TDep3) => $.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h}],"g":["TDep1","TDep2","TDep3"],"n":"PostConfigure","o":"@$4","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep1, TDep2, TDep3, TDep4) => $.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h}],"g":["TDep1","TDep2","TDep3","TDep4"],"n":"PostConfigure","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16908417},{"r":this.$h,"p":[{"n":"configureOptions","p":(TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h}],"g":["TDep1","TDep2","TDep3","TDep4","TDep5"],"n":"PostConfigure","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":$.$$.System.Func$$$(TOptions, $.$$.System.Boolean).$h}],"n":"Validate","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777345},{"r":this.$h,"p":[{"n":"validation","p":$.$$.System.Func$$$(TOptions, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"n":"Validate","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777345},{"r":this.$h,"p":[{"n":"validation","p":(TDep) => $.$$.System.Func$$$$(TOptions, TDep, $.$$.System.Boolean).$h}],"g":["TDep"],"n":"Validate","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep) => $.$$.System.Func$$$$(TOptions, TDep, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"g":["TDep"],"n":"Validate","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep1, TDep2) => $.$$.System.Func$$$$$(TOptions, TDep1, TDep2, $.$$.System.Boolean).$h}],"g":["TDep1","TDep2"],"n":"Validate","o":"@$11","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep1, TDep2) => $.$$.System.Func$$$$$(TOptions, TDep1, TDep2, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"g":["TDep1","TDep2"],"n":"Validate","o":"@$10","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep1, TDep2, TDep3) => $.$$.System.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.System.Boolean).$h}],"g":["TDep1","TDep2","TDep3"],"n":"Validate","o":"@$9","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep1, TDep2, TDep3) => $.$$.System.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"g":["TDep1","TDep2","TDep3"],"n":"Validate","o":"@$8","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep1, TDep2, TDep3, TDep4) => $.$$.System.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.System.Boolean).$h}],"g":["TDep1","TDep2","TDep3","TDep4"],"n":"Validate","o":"@$7","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep1, TDep2, TDep3, TDep4) => $.$$.System.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"g":["TDep1","TDep2","TDep3","TDep4"],"n":"Validate","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.System.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.System.Boolean).$h}],"g":["TDep1","TDep2","TDep3","TDep4","TDep5"],"n":"Validate","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":16908417},{"r":this.$h,"p":[{"n":"validation","p":(TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.System.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"g":["TDep1","TDep2","TDep3","TDep4","TDep5"],"n":"Validate","o":"@$4","d":this.$h,"h":Number(BigInt(this.$h)|0x2000000000n),"f":16908417}],"l":[{"t":1310721,"n":"DefaultValidationFailureMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338}],"c":[{"p":[{"n":"services","p":786435},{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217}],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsBuilder<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions", ($self) => class OptionsBuilderExtensions
        {
            static /*OptionsBuilder<TOptions> */ ValidateOnStart(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(optionsBuilder, "optionsBuilder");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$3($.$meo.Microsoft.Extensions.Options.IStartupValidator, $.$meo.Microsoft.Extensions.Options.StartupValidator, optionsBuilder.Services);
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions$2($.$meo.Microsoft.Extensions.Options.StartupValidatorOptions, optionsBuilder.Services).Configure$1($.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions), new ($.$$.System.Action$$$($.$meo.Microsoft.Extensions.Options.StartupValidatorOptions, $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions)))().$ctor(this,  (/*vo*/ vo, /*options*/ options) =>
                {
                    vo._validators.set_Item(new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String))().$ctor$3(TOptions.$type, optionsBuilder.Name), new $.$$.System.Action().$ctor(this,  () =>
                    {
                        return options.Microsoft$Extensions$Options$IOptionsMonitor$$$Get(optionsBuilder.Name, [TOptions]);
                    }, {"r":65537,"n":"","d":65554,"h":0,"f":17825794}));
                }, {"r":65537,"p":[{"n":"vo","p":2555922},{"n":"options","p":(TOptions) => $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions).$h}],"n":"","d":65554,"h":0,"f":17825794}));
                return optionsBuilder;
            }
            static $h = 65554;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,"p":[{"n":"optionsBuilder","p":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h}],"g":["TOptions"],"n":"ValidateOnStart","d":65554,"h":4295032850,"f":16908321}],"h":65554}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions", ($self) => class OptionsServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddOptions(/*this IServiceCollection*/ services)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2($.$meo.Microsoft.Extensions.Options.IOptions$$().$type, $.$meo.Microsoft.Extensions.Options.UnnamedOptionsManager$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$1($.$meo.Microsoft.Extensions.Options.IOptionsSnapshot$$().$type, $.$meo.Microsoft.Extensions.Options.OptionsManager$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2($.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$().$type, $.$meo.Microsoft.Extensions.Options.OptionsMonitor$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$1($.$meo.Microsoft.Extensions.Options.IOptionsFactory$$().$type, $.$meo.Microsoft.Extensions.Options.OptionsFactory$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2($.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$().$type, $.$meo.Microsoft.Extensions.Options.OptionsCache$$().$type));
                return services;
            }
            static /*OptionsBuilder<TOptions> */ AddOptionsWithValidateOnStart$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions.ValidateOnStart(TOptions, new ($.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions))().$ctor$1(services, name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName));
            }
            static /*OptionsBuilder<TOptions> */ AddOptionsWithValidateOnStart(TOptions, TValidateOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable$1($.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$3($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), TValidateOptions));
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions.ValidateOnStart(TOptions, new ($.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions))().$ctor$1(services, name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName));
            }
            static /*IServiceCollection */ Configure(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure$1(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName, configureOptions);
            }
            static /*IServiceCollection */ Configure$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*Action<TOptions>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), services, new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$(TOptions))().$ctor$1(name, configureOptions));
                return services;
            }
            static /*IServiceCollection */ ConfigureAll(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure$1(TOptions, services, null, configureOptions);
            }
            static /*IServiceCollection */ PostConfigure(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.PostConfigure$1(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName, configureOptions);
            }
            static /*IServiceCollection */ PostConfigure$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*Action<TOptions>*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), services, new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$(TOptions))().$ctor$1(name, configureOptions));
                return services;
            }
            static /*IServiceCollection */ PostConfigureAll(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.PostConfigure$1(TOptions, services, null, configureOptions);
            }
            static /*IServiceCollection */ ConfigureOptions$2(TConfigureOptions, /*this IServiceCollection*/ services)
            {
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.ConfigureOptions$1(services, TConfigureOptions.$type);
            }
            static /*IEnumerable<Type> */ FindConfigurationServices(/*Type*/ type)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    let $i1 = 0;
                    let $arr1 = GetInterfacesOnType(type);
                    while ($i1 < $arr1.length)
                    {
                        let t = $arr1[$i1++];
                        if (t.IsGenericType)
                        {
                            /*Type*/ let gtd = t.GetGenericTypeDefinition();
                            if ($.$$.System.Type.op_Equality$1(gtd, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$().$type) || $.$$.System.Type.op_Equality$1(gtd, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$().$type) || $.$$.System.Type.op_Equality$1(gtd, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$().$type))
                            {
                                yield t;
                            }
                        }
                    }
                    /*static Type[]*/  function GetInterfacesOnType(/*Type*/ t)
                    {
                        return t.GetInterfaces();
                    }
                }.bind(this));
            }
            static /*void */ ThrowNoConfigServices(/*Type*/ type)
            {
                throw new $.$$.System.InvalidOperationException().$ctor$12(type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Action$$().$type) ? $.$meo.System.SR.Error_NoConfigurationServicesAndAction : $.$meo.System.SR.Error_NoConfigurationServices);
            }
            static /*IServiceCollection */ ConfigureOptions$1(/*this IServiceCollection*/ services, /*Type*/ configureType)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                /*bool*/ let added = false;
                var $en2 = $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.FindConfigurationServices(configureType).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var serviceType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$1(services, serviceType, configureType);
                        added = true;
                    }
                }
                if (!added)
                {
                    $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.ThrowNoConfigServices(configureType);
                }
                return services;
            }
            static /*IServiceCollection */ ConfigureOptions(/*this IServiceCollection*/ services, /*object*/ configureInstance)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                /*Type*/ let configureType = $.$$.System.Object.GetType.call(configureInstance);
                /*bool*/ let added = false;
                var $en2 = $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.FindConfigurationServices(configureType).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var serviceType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$1(services, serviceType, configureInstance);
                        added = true;
                    }
                }
                if (!added)
                {
                    $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.ThrowNoConfigServices(configureType);
                }
                return services;
            }
            static /*OptionsBuilder<TOptions> */ AddOptions$2(TOptions, /*this IServiceCollection*/ services)
            {
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions$1(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName);
            }
            static /*OptionsBuilder<TOptions> */ AddOptions$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                return new ($.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions))().$ctor$1(services, name);
            }
            static $h = 131090;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435}],"n":"AddOptions","d":131090,"h":4295098386,"f":16777249},{"r":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,"p":[{"n":"services","p":786435},{"n":"name","p":1310721,"f":65}],"g":["TOptions"],"n":"AddOptionsWithValidateOnStart","o":"@$1","d":131090,"h":8590065682,"f":16908321},{"r":(TOptions, TValidateOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,"p":[{"n":"services","p":786435},{"n":"name","p":1310721,"f":65}],"g":["TOptions","TValidateOptions"],"n":"AddOptionsWithValidateOnStart","d":131090,"h":12885032978,"f":16908321},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configureOptions","p":(TOptions) => $.$$.System.Action$$(TOptions).$h}],"g":["TOptions"],"n":"Configure","d":131090,"h":17180000274,"f":16908321},{"r":786435,"p":[{"n":"services","p":786435},{"n":"name","p":1310721},{"n":"configureOptions","p":(TOptions) => $.$$.System.Action$$(TOptions).$h}],"g":["TOptions"],"n":"Configure","o":"@$1","d":131090,"h":21474967570,"f":16908321},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configureOptions","p":(TOptions) => $.$$.System.Action$$(TOptions).$h}],"g":["TOptions"],"n":"ConfigureAll","d":131090,"h":25769934866,"f":16908321},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configureOptions","p":(TOptions) => $.$$.System.Action$$(TOptions).$h}],"g":["TOptions"],"n":"PostConfigure","d":131090,"h":30064902162,"f":16908321},{"r":786435,"p":[{"n":"services","p":786435},{"n":"name","p":1310721},{"n":"configureOptions","p":(TOptions) => $.$$.System.Action$$(TOptions).$h}],"g":["TOptions"],"n":"PostConfigure","o":"@$1","d":131090,"h":34359869458,"f":16908321},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configureOptions","p":(TOptions) => $.$$.System.Action$$(TOptions).$h}],"g":["TOptions"],"n":"PostConfigureAll","d":131090,"h":38654836754,"f":16908321},{"r":786435,"p":[{"n":"services","p":786435}],"g":["TConfigureOptions"],"n":"ConfigureOptions","o":"@$2","d":131090,"h":42949804050,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Type).$h,"p":[{"n":"type","p":142475265}],"n":"FindConfigurationServices","d":131090,"h":47244771346,"f":16777250},{"r":65537,"p":[{"n":"type","p":142475265}],"n":"ThrowNoConfigServices","d":131090,"h":51539738642,"f":16777250},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configureType","p":142475265}],"n":"ConfigureOptions","o":"@$1","d":131090,"h":55834705938,"f":16777249},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configureInstance","p":131073}],"n":"ConfigureOptions","d":131090,"h":60129673234,"f":16777249},{"r":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,"p":[{"n":"services","p":786435}],"g":["TOptions"],"n":"AddOptions","o":"@$2","d":131090,"h":64424640530,"f":16908321},{"r":(TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,"p":[{"n":"services","p":786435},{"n":"name","p":1310721}],"g":["TOptions"],"n":"AddOptions","o":"@$1","d":131090,"h":68719607826,"f":16908321}],"h":131090}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsWrapper<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsWrapper<>", [TOptions], ($self) => class OptionsWrapper$$ extends $.$$.System.Object
        {
            $ctor$1(/*TOptions*/ options)
            {
                super.$ctor();
                {
                    this.Value = options;
                }
                return this;
            }
            /*TOptions*/ Value = $.$default(TOptions);
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get Microsoft$Extensions$Options$IOptions$$$Value()
            {
                return this.Value;
            }
            static $h = 2031634;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":TOptions?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153}],"c":[{"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsWrapper<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.UnnamedOptionsManager<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.UnnamedOptionsManager<>", [TOptions], ($self) => class UnnamedOptionsManager$$ extends $.$$.System.Object
        {
            /*IOptionsFactory<TOptions>*/ _factory = null;
            /*object?*/ _syncObj = null;
            /*TOptions?*/ _value = null;
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory)
            {
                super.$ctor();
                this._factory = factory;
                return this;
            }
            /*TOptions */ get Value()
            {
                let value;
                if ($.$is(this._value, TOptions, { set $v(v){ value = v; } }))
                {
                    return value;
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._syncObj ?? $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this._syncObj, ($v) => this._syncObj = $v, $.$$.System.Object), new $.$$.System.Object().$ctor(), null) ?? this._syncObj)
                    {
                        return this._value ??= this._factory.Microsoft$Extensions$Options$IOptionsFactory$$$Create($.$meo.Microsoft.Extensions.Options.Options.DefaultName, [TOptions]);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._syncObj ?? $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this._syncObj, ($v) => this._syncObj = $v, $.$$.System.Object), new $.$$.System.Object().$ctor(), null) ?? this._syncObj)
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get Microsoft$Extensions$Options$IOptions$$$Value()
            {
                return this.Value;
            }
            static $h = 2621458;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":TOptions?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153}],"l":[{"t":$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h,"n":"_factory","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":131073,"n":"_syncObj","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":TOptions?.$h??1507328,"n":"_value","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"p":[{"n":"factory","p":$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.UnnamedOptionsManager<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.StartupValidator", ($self) => class StartupValidator extends $.$$.System.Object
        {
            /*StartupValidatorOptions*/ _validatorOptions = null;
            $ctor$1(/*IOptions<StartupValidatorOptions>*/ validators)
            {
                super.$ctor();
                {
                    this._validatorOptions = validators.Microsoft$Extensions$Options$IOptions$$$Value;
                }
                return this;
            }
            /*void */ Validate()
            {
                /*List<Exception>?*/ let exceptions = null;
                var $en2 = this._validatorOptions._validators.Values.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var validator = $en2.Current;
                    {
                        try
                        {
                            validator.Invoke();
                        }
                        catch(ex)
                        {
                            exceptions ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Exception))().$ctor$1();
                            exceptions.Add(ex);
                        }
                    }
                }
                if (exceptions !== null)
                {
                    if (exceptions.Count === 1)
                    {
                        $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exceptions.get_Item(0)).Throw();
                    }
                    if (exceptions.Count > 1)
                    {
                        throw new $.$$.System.AggregateException().$ctor$6(exceptions);
                    }
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IStartupValidator.Validate()
            Microsoft$Extensions$Options$IStartupValidator$Validate()
            {
                return this.Validate(...arguments);
            }
            static $h = 2490386;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Validate","d":2490386,"h":12887392274,"f":16777217}],"l":[{"t":2555922,"n":"_validatorOptions","d":2490386,"h":4297457682,"f":4194306}],"c":[{"p":[{"n":"validators","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$meo.Microsoft.Extensions.Options.StartupValidatorOptions).$h}],"n":".ctor","o":"$ctor$1","d":2490386,"h":8592424978,"f":16777217}],"i":[1245202],"h":2490386}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IStartupValidator ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.StartupValidator`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsFactory<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsFactory<>", [TOptions], ($self) => class OptionsFactory$$ extends $.$$.System.Object
        {
            /*IConfigureOptions<TOptions>[]*/ _setups = null;
            /*IPostConfigureOptions<TOptions>[]*/ _postConfigures = null;
            /*IValidateOptions<TOptions>[]*/ _validations = null;
            $ctor$2(/*IEnumerable<IConfigureOptions<TOptions>>*/ setups, /*IEnumerable<IPostConfigureOptions<TOptions>>*/ postConfigures)
            {
                this.$ctor$1(setups, postConfigures, $.$$.System.Array.Empty($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)));
                {
                }
                return this;
            }
            $ctor$1(/*IEnumerable<IConfigureOptions<TOptions>>*/ setups, /*IEnumerable<IPostConfigureOptions<TOptions>>*/ postConfigures, /*IEnumerable<IValidateOptions<TOptions>>*/ validations)
            {
                super.$ctor();
                {
                    this._setups = $.$as(setups, $.$typeArray($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions))) ?? new ($.$$.System.Collections.Generic.List$$($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor$2(setups).ToArray();
                    this._postConfigures = $.$as(postConfigures, $.$typeArray($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions))) ?? new ($.$$.System.Collections.Generic.List$$($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor$2(postConfigures).ToArray();
                    this._validations = $.$as(validations, $.$typeArray($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions))) ?? new ($.$$.System.Collections.Generic.List$$($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor$2(validations).ToArray();
                }
                return this;
            }
            /*TOptions */ Create(/*string*/ name)
            {
                /*TOptions*/ let options = this.CreateInstance(name);
                let $i1 = 0;
                let $arr1 = this._setups;
                while ($i1 < $arr1.length)
                {
                    let setup = $arr1[$i1++];
                    let namedSetup;
                    if ($.$is(setup, $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), { set $v(v){ namedSetup = v; } }))
                    {
                        namedSetup.Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure(name, options, [TOptions]);
                    }
                    else if ($.$$.System.String.op_Equality(name, $.$meo.Microsoft.Extensions.Options.Options.DefaultName))
                    {
                        setup.Microsoft$Extensions$Options$IConfigureOptions$$$Configure(options, [TOptions]);
                    }
                }
                let $i2 = 0;
                let $arr2 = this._postConfigures;
                while ($i2 < $arr2.length)
                {
                    let post = $arr2[$i2++];
                    post.Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure(name, options, [TOptions]);
                }
                if (this._validations.length > 0)
                {
                    /*var*/ let failures = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    let $i3 = 0;
                    let $arr3 = this._validations;
                    while ($i3 < $arr3.length)
                    {
                        let validate = $arr3[$i3++];
                        /*ValidateOptionsResult*/ let result = validate.Microsoft$Extensions$Options$IValidateOptions$$$Validate(name, options, [TOptions]);
                        if (!(result === null) && result.Failed)
                        {
                            failures.AddRange(result.Failures);
                        }
                    }
                    if (failures.Count > 0)
                    {
                        throw new $.$meo.Microsoft.Extensions.Options.OptionsValidationException().$ctor$5(name, TOptions.$type, failures);
                    }
                }
                return options;
            }
            /*TOptions */ CreateInstance(/*string*/ name)
            {
                return $.$$.System.Activator.CreateInstance$10(TOptions);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsFactory<TOptions>.Create(string)
            Microsoft$Extensions$Options$IOptionsFactory$$$Create()
            {
                return this.Create(...arguments);
            }
            static $h = 1572882;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721}],"n":"Create","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217},{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721}],"n":"CreateInstance","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777348}],"l":[{"t":$.$typeArray($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)).$h,"n":"_setups","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$typeArray($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)).$h,"n":"_postConfigures","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$typeArray($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)).$h,"n":"_validations","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"p":[{"n":"setups","p":$.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)).$h},{"n":"postConfigures","p":$.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"p":[{"n":"setups","p":$.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)).$h},{"n":"postConfigures","p":$.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)).$h},{"n":"validations","p":$.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsFactory<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureOptions<>", [TOptions], ($self) => class ConfigureOptions$$ extends $.$$.System.Object
        {
            $ctor$1(/*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    this.Action = action;
                }
                return this;
            }
            /*Action<TOptions>?*/ Action = null;
            /*void */ Configure(/*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                this.Action?.Invoke(options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                return this.Configure(...arguments);
            }
            static $h = 589842;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Action$$(TOptions).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777345}],"c":[{"p":[{"n":"action","p":$.$$.System.Action$$(TOptions).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<>", [TOptions], ($self) => class ValidateOptions$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*Func<TOptions, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Func<TOptions, bool>*/ Validation = null;
            /*string*/ FailureMessage = null;
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                return this.Validate(...arguments);
            }
            static $h = 3145746;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Func$$$(TOptions, $.$$.System.Boolean).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Validation","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"FailureMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153}],"m":[{"r":3211282,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Validate","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"validation","p":$.$$.System.Func$$$(TOptions, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<>", [TOptions], ($self) => class PostConfigureOptions$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions>?*/ Action = null;
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options);
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                return this.PostConfigure(...arguments);
            }
            static $h = 2424850;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$(TOptions).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777345}],"c":[{"p":[{"n":"name","p":1310721},{"n":"action","p":$.$$.System.Action$$(TOptions).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsCache<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsCache<>", [TOptions], ($self) => class OptionsCache$$ extends $.$$.System.Object
        {
            /*ConcurrentDictionary<string, Lazy<TOptions>>*/ _cache = null;
            /*void */ Clear()
            {
                return this._cache.Clear();
            }
            /*TOptions */ GetOrAdd(/*string?*/ name, /*Func<TOptions>*/ createOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(createOptions, "createOptions");
                name ??= $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                /*Lazy<TOptions>*/ let value;
                value = this._cache.GetOrAdd$2($.$$.System.Func$$(TOptions), name, new ($.$$.System.Func$$$$($.$$.System.String, $.$$.System.Func$$(TOptions), $.$$.System.Lazy$$(TOptions)))().$ctor($.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions), /*static*/ (/**/ name, /*createOptions*/ createOptions) =>
                {
                    return new ($.$$.System.Lazy$$(TOptions))().$ctor$6(createOptions);
                }, {"r":$.$$.System.Lazy$$(TOptions).$h,"p":[{"n":"name","p":1310721},{"n":"createOptions","p":$.$$.System.Func$$(TOptions).$h}],"n":"","d":this.$h,"h":0,"f":17825826}), createOptions);
                return value.Value;
            }
            /*TOptions */ GetOrAdd$1(TArg, /*string?*/ name, /*Func<string, TArg, TOptions>*/ createOptions, /*TArg*/ factoryArgument)
            {
                if ($.$$.System.Type.op_Inequality$1($.$$.System.Object.GetType.call(this), $.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions).$type))
                {
                    /*string?*/ let localName = name;
                    /*Func<string, TArg, TOptions>*/ let localCreateOptions = createOptions;
                    /*TArg*/ let localFactoryArgument = factoryArgument;
                    return this.GetOrAdd(name, new ($.$$.System.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localCreateOptions.Invoke(localName ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, localFactoryArgument);
                    }, {"r":TOptions?.$h??1507328,"n":"","d":this.$h,"h":0,"f":17825794}));
                }
                return this._cache.GetOrAdd$2($.$$.System.ValueTuple$$$($.$$.System.Func$$$$($.$$.System.String, TArg, TOptions), TArg), name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, new ($.$$.System.Func$$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Func$$$$($.$$.System.String, TArg, TOptions), TArg), $.$$.System.Lazy$$(TOptions)))().$ctor($.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions), /*static*/ (/*name*/ name, /*arg*/ arg) =>
                {
                    return new ($.$$.System.Lazy$$(TOptions))().$ctor$6(new ($.$$.System.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return arg.Item1.Invoke(name, arg.Item2);
                    }, {"r":TOptions?.$h??1507328,"n":"","d":this.$h,"h":0,"f":17825794}));
                }, {"r":$.$$.System.Lazy$$(TOptions).$h,"p":[{"n":"name","p":1310721},{"n":"arg","p":(TArg) => $.$$.System.ValueTuple$$$($.$$.System.Func$$$$($.$$.System.String, TArg, TOptions), TArg).$h}],"n":"","d":this.$h,"h":0,"f":17825826}), new ($.$$.System.ValueTuple$$$($.$$.System.Func$$$$($.$$.System.String, TArg, TOptions), TArg))().$ctor$3(createOptions, factoryArgument)).Value;
            }
            /*bool */ TryGetValue(/*string?*/ name, /*out TOptions*/ options)
            {
                /*Lazy<TOptions>?*/ let lazy;
                if (this._cache.TryGetValue(name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, $.$ref(() => lazy, ($v) => lazy = $v, $.$$.System.Lazy$$(TOptions))))
                {
                    options.$v = lazy.Value;
                    return true;
                }
                options.$v = $.$default(TOptions);
                return false;
            }
            /*bool */ TryAdd(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                return this._cache.TryAdd(name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, new ($.$$.System.Lazy$$(TOptions))().$ctor$8(options));
            }
            /*bool */ TryRemove(/*string?*/ name)
            {
                return this._cache.TryRemove$1(name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, $.$discardRef());
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.GetOrAdd(string?, System.Func<TOptions>)
            Microsoft$Extensions$Options$IOptionsMonitorCache$$$GetOrAdd()
            {
                return this.GetOrAdd(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.TryAdd(string?, TOptions)
            Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryAdd()
            {
                return this.TryAdd(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.TryRemove(string?)
            Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryRemove()
            {
                return this.TryRemove(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.Clear()
            Microsoft$Extensions$Options$IOptionsMonitorCache$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Lazy$$(TOptions)))().$ctor$7(1, 31, $.$$.System.StringComparer.Ordinal);
            }
            static $h = 1507346;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Clear","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217},{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721},{"n":"createOptions","p":$.$$.System.Func$$(TOptions).$h}],"n":"GetOrAdd","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777345},{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721},{"n":"createOptions","p":(TArg) => $.$$.System.Func$$$$($.$$.System.String, TArg, TOptions).$h},{"n":"factoryArgument","p":(TArg) => TArg.$h}],"g":["TArg"],"n":"GetOrAdd","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16908296},{"r":262145,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777224},{"r":262145,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"TryAdd","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777345},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"TryRemove","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777345}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Lazy$$(TOptions)).$h,"n":"_cache","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsCache<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,>", (TOptions, TDep) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,>", [TOptions, TDep], ($self) => class PostConfigureOptions$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Action<TOptions, TDep>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency = dependency;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep>?*/ Action = null;
            /*TDep*/ Dependency = $.$default(TDep);
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency);
                }
            }
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                return this.PostConfigure(...arguments);
            }
            static $h = 2359314;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$(TOptions, TDep).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency","p":TDep?.$h??1572864},{"n":"action","p":$.$$.System.Action$$$(TOptions, TDep).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep?.$h??1572864],"s":[{"n":"TOptions","f":1},{"n":"TDep","f":1}],"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,>", (TOptions, TDep) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,>", [TOptions, TDep], ($self) => class ValidateOptions$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Func<TOptions, TDep, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency = dependency;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Func<TOptions, TDep, bool>*/ Validation = null;
            /*string*/ FailureMessage = null;
            /*TDep*/ Dependency = $.$default(TDep);
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                return this.Validate(...arguments);
            }
            static $h = 3080210;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Func$$$$(TOptions, TDep, $.$$.System.Boolean).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Validation","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"FailureMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153}],"m":[{"r":3211282,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Validate","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency","p":TDep?.$h??1572864},{"n":"validation","p":$.$$.System.Func$$$$(TOptions, TDep, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep?.$h??1572864],"s":[{"n":"TOptions","f":1},null],"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,,>", (TOptions, TDep1, TDep2) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,,>", [TOptions, TDep1, TDep2], ($self) => class ValidateOptions$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Func<TOptions, TDep1, TDep2, bool>*/ Validation = null;
            /*string*/ FailureMessage = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                return this.Validate(...arguments);
            }
            static $h = 3014674;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Func$$$$$(TOptions, TDep1, TDep2, $.$$.System.Boolean).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Validation","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"FailureMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153}],"m":[{"r":3211282,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Validate","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency1","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"validation","p":$.$$.System.Func$$$$$(TOptions, TDep1, TDep2, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400],"s":[{"n":"TOptions","f":1},null,null],"r":3,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,>", (TOptions, TDep1, TDep2) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,>", [TOptions, TDep1, TDep2], ($self) => class PostConfigureOptions$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*Action<TOptions, TDep1, TDep2>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep1, TDep2>?*/ Action = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2);
                }
            }
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                return this.PostConfigure(...arguments);
            }
            static $h = 2293778;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"action","p":$.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400],"s":[{"n":"TOptions","f":1},{"n":"TDep1","f":1},{"n":"TDep2","f":1}],"r":3,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,>", (TOptions, TDep1, TDep2, TDep3) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,>", [TOptions, TDep1, TDep2, TDep3], ($self) => class ValidateOptions$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ Validation = null;
            /*string*/ FailureMessage = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                return this.Validate(...arguments);
            }
            static $h = 2949138;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.System.Boolean).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Validation","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"FailureMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153}],"m":[{"r":3211282,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Validate","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency1","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"validation","p":$.$$.System.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936],"s":[{"n":"TOptions","f":1},null,null,null],"r":4,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,>", (TOptions, TDep1, TDep2, TDep3) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,>", [TOptions, TDep1, TDep2, TDep3], ($self) => class PostConfigureOptions$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Action<TOptions, TDep1, TDep2, TDep3>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep1, TDep2, TDep3>?*/ Action = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3);
                }
            }
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                return this.PostConfigure(...arguments);
            }
            static $h = 2228242;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"action","p":$.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936],"s":[{"n":"TOptions","f":1},{"n":"TDep1","f":1},{"n":"TDep2","f":1},{"n":"TDep3","f":1}],"r":4,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class PostConfigureOptions$$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ Action = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4);
                }
            }
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                return this.PostConfigure(...arguments);
            }
            static $h = 2162706;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153},{"p":TDep4?.$h??1769472,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"n":"Dependency4","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency1","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"dependency4","p":TDep4?.$h??1769472},{"n":"action","p":$.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472],"s":[{"n":"TOptions","f":1},{"n":"TDep1","f":1},{"n":"TDep2","f":1},{"n":"TDep3","f":1},{"n":"TDep4","f":1}],"r":5,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class ValidateOptions$$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ Validation = null;
            /*string*/ FailureMessage = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                return this.Validate(...arguments);
            }
            static $h = 2883602;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.System.Boolean).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Validation","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"FailureMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153},{"p":TDep4?.$h??1769472,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1600000000n),"f":50331649},"n":"Dependency4","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2097153}],"m":[{"r":3211282,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Validate","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency1","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"dependency4","p":TDep4?.$h??1769472},{"n":"validation","p":$.$$.System.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472],"s":[{"n":"TOptions","f":1},null,null,null,null],"r":5,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class ValidateOptions$$$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ Validation = null;
            /*string*/ FailureMessage = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                return this.Validate(...arguments);
            }
            static $h = 2818066;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.System.Boolean).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Validation","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"FailureMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153},{"p":TDep4?.$h??1769472,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1600000000n),"f":50331649},"n":"Dependency4","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2097153},{"p":TDep5?.$h??1835008,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1900000000n),"f":50331649},"n":"Dependency5","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":2097153}],"m":[{"r":3211282,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Validate","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency1","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"dependency4","p":TDep4?.$h??1769472},{"n":"dependency5","p":TDep5?.$h??1835008},{"n":"validation","p":$.$$.System.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.System.Boolean).$h},{"n":"failureMessage","p":1310721}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472,TDep5?.$h??1835008],"s":[{"n":"TOptions","f":1},null,null,null,null,null],"r":6,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class PostConfigureOptions$$$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ Action = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5);
                }
            }
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                return this.PostConfigure(...arguments);
            }
            static $h = 2097170;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153},{"p":TDep4?.$h??1769472,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"n":"Dependency4","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153},{"p":TDep5?.$h??1835008,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1600000000n),"f":50331649},"n":"Dependency5","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"PostConfigure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency1","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"dependency4","p":TDep4?.$h??1769472},{"n":"dependency5","p":TDep5?.$h??1835008},{"n":"action","p":$.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472,TDep5?.$h??1835008],"s":[{"n":"TOptions","f":1},{"n":"TDep1","f":1},{"n":"TDep2","f":1},{"n":"TDep3","f":1},{"n":"TDep4","f":1},{"n":"TDep5","f":1}],"r":6,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsManager<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsManager<>", [TOptions], ($self) => class OptionsManager$$ extends $.$$.System.Object
        {
            /*IOptionsFactory<TOptions>*/ _factory = null;
            /*OptionsCache<TOptions>*/ _cache = null;
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory)
            {
                super.$ctor();
                {
                    this._factory = factory;
                }
                return this;
            }
            /*TOptions */ get Value()
            {
                return this.Get($.$meo.Microsoft.Extensions.Options.Options.DefaultName);
            }
            /*TOptions */ Get(/*string?*/ name)
            {
                name ??= $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                /*TOptions?*/ let options;
                if (!this._cache.TryGetValue(name, $.$ref(() => options, ($v) => options = $v, TOptions)))
                {
                    /*IOptionsFactory<TOptions>*/ let localFactory = this._factory;
                    /*string*/ let localName = name;
                    options = this._cache.GetOrAdd(name, new ($.$$.System.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localFactory.Microsoft$Extensions$Options$IOptionsFactory$$$Create(localName, [TOptions]);
                    }, {"r":TOptions?.$h??1507328,"n":"","d":this.$h,"h":0,"f":17825794}));
                }
                return options;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsSnapshot<TOptions>.Get(string?)
            Microsoft$Extensions$Options$IOptionsSnapshot$$$Get()
            {
                return this.Get(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get Microsoft$Extensions$Options$IOptions$$$Value()
            {
                return this.Value;
            }
            //default member initializer
            constructor()
            {
                super();
                this._cache = new ($.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions))().$ctor$1();
            }
            static $h = 1638418;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":TOptions?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2097153}],"m":[{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721}],"n":"Get","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777345}],"l":[{"t":$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h,"n":"_factory","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions).$h,"n":"_cache","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"factory","p":$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IOptionsSnapshot$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsSnapshot$$(TOptions), $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsManager<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<>", [TOptions], ($self) => class ConfigureNamedOptions$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions>?*/ Action = null;
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options);
                }
            }
            /*void */ Configure$1(/*TOptions*/ options)
            {
                return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                return this.Configure(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                return this.Configure$1(...arguments);
            }
            static $h = 524306;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$(TOptions).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"action","p":$.$$.System.Action$$(TOptions).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,>", (TOptions, TDep) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,>", [TOptions, TDep], ($self) => class ConfigureNamedOptions$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Action<TOptions, TDep>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency = dependency;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep>?*/ Action = null;
            /*TDep*/ Dependency = $.$default(TDep);
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency);
                }
            }
            /*void */ Configure$1(/*TOptions*/ options)
            {
                return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                return this.Configure(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                return this.Configure$1(...arguments);
            }
            static $h = 458770;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$(TOptions, TDep).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency","p":TDep?.$h??1572864},{"n":"action","p":$.$$.System.Action$$$(TOptions, TDep).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep?.$h??1572864],"s":[{"n":"TOptions","f":1},{"n":"TDep","f":1}],"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,>", (TOptions, TDep1, TDep2) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,>", [TOptions, TDep1, TDep2], ($self) => class ConfigureNamedOptions$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*Action<TOptions, TDep1, TDep2>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep1, TDep2>?*/ Action = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2);
                }
            }
            /*void */ Configure$1(/*TOptions*/ options)
            {
                return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                return this.Configure(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                return this.Configure$1(...arguments);
            }
            static $h = 393234;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"action","p":$.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400],"s":[{"n":"TOptions","f":1},{"n":"TDep1","f":1},{"n":"TDep2","f":1}],"r":3,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,>", (TOptions, TDep1, TDep2, TDep3) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,>", [TOptions, TDep1, TDep2, TDep3], ($self) => class ConfigureNamedOptions$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Action<TOptions, TDep1, TDep2, TDep3>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep1, TDep2, TDep3>?*/ Action = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3);
                }
            }
            /*void */ Configure$1(/*TOptions*/ options)
            {
                return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                return this.Configure(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                return this.Configure$1(...arguments);
            }
            static $h = 327698;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"action","p":$.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936],"s":[{"n":"TOptions","f":1},{"n":"TDep1","f":1},{"n":"TDep2","f":1},{"n":"TDep3","f":1}],"r":4,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class ConfigureNamedOptions$$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ Action = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4);
                }
            }
            /*void */ Configure$1(/*TOptions*/ options)
            {
                return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                return this.Configure(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                return this.Configure$1(...arguments);
            }
            static $h = 262162;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153},{"p":TDep4?.$h??1769472,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"n":"Dependency4","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency1","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"dependency4","p":TDep4?.$h??1769472},{"n":"action","p":$.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472],"s":[{"n":"TOptions","f":1},{"n":"TDep1","f":1},{"n":"TDep2","f":1},{"n":"TDep3","f":1},{"n":"TDep4","f":1}],"r":5,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class ConfigureNamedOptions$$$$$$$ extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ action)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ Action = null;
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5);
                }
            }
            /*void */ Configure$1(/*TOptions*/ options)
            {
                return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                return this.Configure(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                return this.Configure$1(...arguments);
            }
            static $h = 196626;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":$.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Action","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":TDep1?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Dependency1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":TDep2?.$h??1638400,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331649},"n":"Dependency2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097153},{"p":TDep3?.$h??1703936,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"Dependency3","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153},{"p":TDep4?.$h??1769472,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"n":"Dependency4","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153},{"p":TDep5?.$h??1835008,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1600000000n),"f":50331649},"n":"Dependency5","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777345},{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328}],"n":"Configure","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777217}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dependency1","p":TDep1?.$h??1572864},{"n":"dependency2","p":TDep2?.$h??1638400},{"n":"dependency3","p":TDep3?.$h??1703936},{"n":"dependency4","p":TDep4?.$h??1769472},{"n":"dependency5","p":TDep5?.$h??1835008},{"n":"action","p":$.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h],"g":[TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472,TDep5?.$h??1835008],"s":[{"n":"TOptions","f":1},{"n":"TDep1","f":1},{"n":"TDep2","f":1},{"n":"TDep3","f":1},{"n":"TDep4","f":1},{"n":"TDep5","f":1}],"r":6,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsMonitor<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsMonitor<>", [TOptions], ($self) => class OptionsMonitor$$ extends $.$$.System.Object
        {
            /*IOptionsMonitorCache<TOptions>*/ _cache = null;
            /*IOptionsFactory<TOptions>*/ _factory = null;
            /*List<IDisposable>*/ _registrations = null;
            /*Action<TOptions, string>?*/ _onChange = null;
            add__onChange(/*Action<TOptions, string>?*/ value)
            {
                this._onChange = $.$$.System.Delegate.Combine(this._onChange, value);
            }
            remove__onChange(/*Action<TOptions, string>?*/ value)
            {
                this._onChange = $.$$.System.Delegate.Remove(this._onChange, value);
            }
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory, /*IEnumerable<IOptionsChangeTokenSource<TOptions>>*/ sources, /*IOptionsMonitorCache<TOptions>*/ cache)
            {
                super.$ctor();
                {
                    this._factory = factory;
                    this._cache = cache;
                    /*void*/  function RegisterSource(/*IOptionsChangeTokenSource<TOptions>*/ source)
                    {
                        /*IDisposable*/ let registration = $.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange$1($.$$.System.String, new ($.$$.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(source, source.Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$GetChangeToken), new ($.$$.System.Action$$($.$$.System.String))().$ctor(this, this.InvokeChanged), source.Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$Name);
                        this._registrations.Add(registration);
                    }
                    let sourcesArray;
                    if ($.$is(sources, $.$typeArray($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions)), { set $v(v){ sourcesArray = v; } }))
                    {
                        let $i1 = 0;
                        let $arr1 = sourcesArray;
                        while ($i1 < $arr1.length)
                        {
                            let source = $arr1[$i1++];
                            RegisterSource.call(this, source);
                        }
                    }
                    else 
                    {
                        var $en4 = sources.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var source = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                RegisterSource.call(this, source);
                            }
                        }
                    }
                }
                return this;
            }
            /*void */ InvokeChanged(/*string?*/ name)
            {
                name ??= $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                this._cache.Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryRemove(name, [TOptions]);
                /*TOptions*/ let options = this.Get(name);
                this._onChange?.Invoke(options, name);
            }
            /*TOptions */ get CurrentValue()
            {
                return this.Get($.$meo.Microsoft.Extensions.Options.Options.DefaultName);
            }
            /*TOptions */ Get(/*string?*/ name)
            {
                let optionsCache;
                if (!$.$is(this._cache, $.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions), { set $v(v){ optionsCache = v; } }))
                {
                    /*string*/ let localName = name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                    /*IOptionsFactory<TOptions>*/ let localFactory = this._factory;
                    return this._cache.Microsoft$Extensions$Options$IOptionsMonitorCache$$$GetOrAdd(localName, new ($.$$.System.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localFactory.Microsoft$Extensions$Options$IOptionsFactory$$$Create(localName, [TOptions]);
                    }, {"r":TOptions?.$h??1507328,"n":"","d":this.$h,"h":0,"f":17825794}), [TOptions]);
                }
                return optionsCache.GetOrAdd$1($.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions), name, new ($.$$.System.Func$$$$($.$$.System.String, $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions), TOptions))().$ctor($.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions), /*static*/ (/*name*/ name, /*factory*/ factory) =>
                {
                    return factory.Microsoft$Extensions$Options$IOptionsFactory$$$Create(name, [TOptions]);
                }, {"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721},{"n":"factory","p":$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h}],"n":"","d":this.$h,"h":0,"f":17825826}), this._factory);
            }
            /*IDisposable */ OnChange(/*Action<TOptions, string>*/ listener)
            {
                /*var*/ let disposable = new ($.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).ChangeTrackerDisposable)().$ctor$1(this, listener);
                this.add__onChange(new ($.$$.System.Action$$$(TOptions, $.$$.System.String))().$ctor(disposable, disposable.OnChange));
                return disposable;
            }
            /*void */ Dispose()
            {
                var $en2 = this._registrations.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var registration = $en2.Current;
                    {
                        registration.System$IDisposable$Dispose();
                    }
                }
                this._registrations.Clear();
            }
            static $_ChangeTrackerDisposable;
            static get ChangeTrackerDisposable()
            {
                let $cls = $.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions);
                return $cls.$_ChangeTrackerDisposable ??= $asm.$ncls("$meo.Microsoft.Extensions.Options.OptionsMonitor$$.ChangeTrackerDisposable", ($self) => class ChangeTrackerDisposable extends $.$$.System.Object
                {
                    /*Action<TOptions, string>*/ _listener = null;
                    /*OptionsMonitor<TOptions>*/ _monitor = null;
                    $ctor$1(/*OptionsMonitor<TOptions>*/ monitor, /*Action<TOptions, string>*/ listener)
                    {
                        super.$ctor();
                        {
                            this._listener = listener;
                            this._monitor = monitor;
                        }
                        return this;
                    }
                    /*void */ OnChange(/*TOptions*/ options, /*string*/ name)
                    {
                        return this._listener.Invoke(options, name);
                    }
                    /*void */ Dispose()
                    {
                        return this._monitor.remove__onChange(new ($.$$.System.Action$$$(TOptions, $.$$.System.String))().$ctor(this, this.OnChange));
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 1769490;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"options","p":TOptions?.$h??1507328},{"n":"name","p":1310721}],"n":"OnChange","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"l":[{"t":$.$$.System.Action$$$(TOptions, $.$$.System.String).$h,"n":"_listener","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).$h,"n":"_monitor","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"monitor","p":$.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).$h},{"n":"listener","p":$.$$.System.Action$$$(TOptions, $.$$.System.String).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"i":[57540609],"d":$.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Options.OptionsMonitor<${TOptions?.$fullName}>.ChangeTrackerDisposable`; }
                }, $cls, ($v) => $cls.$_ChangeTrackerDisposable = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.CurrentValue.get
            get Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue()
            {
                return this.CurrentValue;
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.Get(string?)
            Microsoft$Extensions$Options$IOptionsMonitor$$$Get()
            {
                return this.Get(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.OnChange(System.Action<TOptions, string?>)
            Microsoft$Extensions$Options$IOptionsMonitor$$$OnChange()
            {
                return this.OnChange(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._registrations = new ($.$$.System.Collections.Generic.List$$($.$$.System.IDisposable))().$ctor$1();
            }
            static $h = 1703954;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":TOptions?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"CurrentValue","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721}],"n":"InvokeChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777218},{"r":TOptions?.$h??1507328,"p":[{"n":"name","p":1310721}],"n":"Get","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777345},{"r":57540609,"p":[{"n":"listener","p":$.$$.System.Action$$$(TOptions, $.$$.System.String).$h}],"n":"OnChange","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777217}],"l":[{"t":$.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$(TOptions).$h,"n":"_cache","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h,"n":"_factory","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.IDisposable).$h,"n":"_registrations","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"p":[{"n":"factory","p":$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h},{"n":"sources","p":$.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions)).$h},{"n":"cache","p":$.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$(TOptions).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217}],"e":[{"e":$.$$.System.Action$$$(TOptions, $.$$.System.String).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.Action$$$(TOptions, $.$$.System.String).$h}],"n":"add__onChange","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":150994952},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.Action$$$(TOptions, $.$$.System.String).$h}],"n":"remove__onChange","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":285212680},"n":"_onChange","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":8388616}],"i":[$.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions).$h,57540609],"g":[TOptions?.$h??1507328],"s":[{"n":"TOptions","f":1}],"j":[$.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).ChangeTrackerDisposable.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions), $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsMonitor<${TOptions?.$fullName}>`; }
        }));
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsValidatorAttribute", ($self) => class OptionsValidatorAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1966098;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":1966098,"h":4296933394,"f":16777217}],"h":1966098,"a":[{"t":14745601,"c":21489582081,"a":[{"v":12,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsValidatorAttribute`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateObjectMembersAttribute", ($self) => class ValidateObjectMembersAttribute extends $.$$.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*Type*/ validator)
            {
                super.$ctor$1();
                {
                    this.Validator = validator;
                }
                return this;
            }
            /*Type?*/ Validator = null;
            static $h = 2752530;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":21477589010,"f":50331649},"n":"Validator","d":2752530,"h":17182621714,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":2752530,"h":4297719826,"f":16777217},{"p":[{"n":"validator","p":142475265}],"n":".ctor","o":"$ctor$3","d":2752530,"h":8592687122,"f":16777217}],"h":2752530,"a":[{"t":14745601,"c":21489582081,"a":[{"v":384,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateObjectMembersAttribute`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateEnumeratedItemsAttribute", ($self) => class ValidateEnumeratedItemsAttribute extends $.$$.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*Type*/ validator)
            {
                super.$ctor$1();
                {
                    this.Validator = validator;
                }
                return this;
            }
            /*Type?*/ Validator = null;
            static $h = 2686994;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":21477523474,"f":50331649},"n":"Validator","d":2686994,"h":17182556178,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":2686994,"h":4297654290,"f":16777217},{"p":[{"n":"validator","p":142475265}],"n":".ctor","o":"$ctor$3","d":2686994,"h":8592621586,"f":16777217}],"h":2686994,"a":[{"t":14745601,"c":21489582081,"a":[{"v":384,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateEnumeratedItemsAttribute`; }
        });
        
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsValidationException", ($self) => class OptionsValidationException extends $.$$.System.Exception
        {
            $ctor$5(/*string*/ optionsName, /*Type*/ optionsType, /*IEnumerable<string>?*/ failureMessages)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(optionsName, "optionsName");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(optionsType, "optionsType");
                    this.Failures = failureMessages ?? new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    this.OptionsType = optionsType;
                    this.OptionsName = optionsName;
                }
                return this;
            }
            /*string*/ OptionsName = null;
            /*Type*/ OptionsType = null;
            /*IEnumerable<string>*/ Failures = null;
            /*string */ get Message()
            {
                return $.$$.System.String.Join$5("; ", this.Failures);
            }
            static $h = 1900562;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181769746,"f":50331649},"n":"OptionsName","d":1900562,"h":12886802450,"f":2097153},{"p":142475265,"g":{"r":0,"d":0,"h":30066671634,"f":50331649},"n":"OptionsType","d":1900562,"h":25771704338,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":42951573522,"f":50331649},"n":"Failures","d":1900562,"h":38656606226,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51541508114,"f":50364417},"n":"Message","d":1900562,"h":47246540818,"f":2129921}],"c":[{"p":[{"n":"optionsName","p":1310721},{"n":"optionsType","p":142475265},{"n":"failureMessages","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":".ctor","o":"$ctor$5","d":1900562,"h":4296867858,"f":16777217}],"i":[113246209],"h":1900562}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsValidationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations"))