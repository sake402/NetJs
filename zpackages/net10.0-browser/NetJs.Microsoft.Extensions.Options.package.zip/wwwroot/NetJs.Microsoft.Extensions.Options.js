
//--TRIMMABLE-BOUNDARY-START(87)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $mwp, $scn, $scp, $scs, $sdp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca) {
    "use strict";
    let _;
    let $EbCReg;
    let $gmToxc;
    let $UuKoyb;
    let $VlNtTc;
    let $KwEBDb;
    let $TOELoi;
    let $VnMkua;
    let $kJShPa;
    let $Uzrvlg;
    let $SRPfBc;
    let $MIuKgg;
    let $YYrhal;
    let $YESdaf;
    let $AHsOJc;
    let $DxAVuf;
    let $VYoVwa;
    let $HKJUah;
    let $QlAqza;
    let $sZUZQe;
    let $zDWOTj;
    let $BiNnol;
    let $uRceUb;
    let $kXEzXd;
    let $lOcJid;
    let $fKdkQf;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Options", 
    {
  "h": 87,
  "f": "Microsoft.Extensions.Options",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Extensions.Options.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Options",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Options",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(720983)
        $asm.$cls(`$meo.MEO.IConfigureOptions<>`, (/*in*/ TOptions) => $asm.$gt(`$meo.MEO.IConfigureOptions<>`, [/*in*/ TOptions], ($self) => class IConfigureOptions$$
        {
            static $H = 720983;
            static $h = 720983;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295688279),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864,
          "f": 32
        }
      ],
      "n": "Configure",
      "o": `MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`,
      "d": this.$h,
      "H": 4295688279,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295688279)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 17
    }
  ],
  "r": 1,
  "H": 720983,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IConfigureOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IConfigureOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(720983)
        
        

        //--TRIMMABLE-BOUNDARY-START(852055)
        $asm.$cls(`$meo.MEO.IOptionsChangeTokenSource<>`, (/*out*/ TOptions) => $asm.$gt(`$meo.MEO.IOptionsChangeTokenSource<>`, [/*out*/ TOptions], ($self) => class IOptionsChangeTokenSource$$
        {
            static $H = 852055;
            static $h = 852055;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180721239),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 8590786647,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50331905
      },
      "n": "Name",
      "o": "MEO$IOptionsChangeTokenSource$$$Name",
      "d": this.$h,
      "H": 17180721239,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180721239)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753943),
    {
      "r": 720981,
      "n": "GetChangeToken",
      "o": "MEO$IOptionsChangeTokenSource$$$GetChangeToken",
      "d": this.$h,
      "H": 12885753943,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885753943)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 32
    }
  ],
  "r": 1,
  "H": 852055,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IOptionsChangeTokenSource<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IOptionsChangeTokenSource$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(852055)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179735)
        $asm.$cls(`$meo.MEO.IPostConfigureOptions<>`, (/*in*/ TOptions) => $asm.$gt(`$meo.MEO.IPostConfigureOptions<>`, [/*in*/ TOptions], ($self) => class IPostConfigureOptions$$
        {
            static $H = 1179735;
            static $h = 1179735;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296147031),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864,
          "f": 32
        }
      ],
      "n": "PostConfigure",
      "o": `MEO$IPostConfigureOptions$${TOptions.$getFullName('$')}$PostConfigure`,
      "d": this.$h,
      "H": 4296147031,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296147031)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 17
    }
  ],
  "r": 1,
  "H": 1179735,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IPostConfigureOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IPostConfigureOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1179735)
        
        

        //--TRIMMABLE-BOUNDARY-START(786519)
        $asm.$cls(`$meo.MEO.IOptions<>`, (/*out*/ TOptions) => $asm.$gt(`$meo.MEO.IOptions<>`, [/*out*/ TOptions], ($self) => class IOptions$$
        {
            static $H = 786519;
            static $h = 786519;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885688407),
    {
      "p": TOptions?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 8590721111,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50856193
      },
      "n": "Value",
      "o": `MEO$IOptions$${TOptions.$getFullName('$')}$Value`,
      "d": this.$h,
      "H": 12885688407,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885688407)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 33
    }
  ],
  "r": 1,
  "H": 786519,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(786519)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310807)
        $asm.$cls(`$meo.MEO.IValidateOptions<>`, (TOptions) => $asm.$gt(`$meo.MEO.IValidateOptions<>`, [TOptions], ($self) => class IValidateOptions$$
        {
            static $H = 1310807;
            static $h = 1310807;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296278103),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Validate",
      "o": `MEO$IValidateOptions$${TOptions.$getFullName('$')}$Validate`,
      "d": this.$h,
      "H": 4296278103,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296278103)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 1310807,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IValidateOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IValidateOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1310807)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245271)
        $asm.$cls(`$meo.MEO.IStartupValidator`, ($self) => class IStartupValidator
        {
            static $h = 1245271;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296212567),
    {
      "r": 65537,
      "n": "Validate",
      "o": "MEO$IStartupValidator$Validate",
      "d": 1245271,
      "h": 4296212567,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296212567)
  ],
  "h": 1245271
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IStartupValidator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IStartupValidator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245271)
        
        

        //--TRIMMABLE-BOUNDARY-START(917591)
        $asm.$cls(`$meo.MEO.IOptionsFactory<>`, (TOptions) => $asm.$gt(`$meo.MEO.IOptionsFactory<>`, [TOptions], ($self) => class IOptionsFactory$$
        {
            static $H = 917591;
            static $h = 917591;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295884887),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Create",
      "o": `MEO$IOptionsFactory$${TOptions.$getFullName('$')}$Create`,
      "d": this.$h,
      "H": 4295884887,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295884887)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 917591,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IOptionsFactory<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IOptionsFactory$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917591)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048663)
        $asm.$cls(`$meo.MEO.IOptionsMonitorCache<>`, (TOptions) => $asm.$gt(`$meo.MEO.IOptionsMonitorCache<>`, [TOptions], ($self) => class IOptionsMonitorCache$$
        {
            static $H = 1048663;
            static $h = 1048663;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983255),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "createOptions",
          "p": $.$$.S.Func$$(TOptions).$h
        }
      ],
      "n": "GetOrAdd",
      "o": "MEO$IOptionsMonitorCache$$$GetOrAdd",
      "d": this.$h,
      "H": 8590983255,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590983255),
//--TRIMMABLE-BOUNDARY-START(12885950551),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "TryAdd",
      "o": "MEO$IOptionsMonitorCache$$$TryAdd",
      "d": this.$h,
      "H": 12885950551,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885950551),
//--TRIMMABLE-BOUNDARY-START(17180917847),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "TryRemove",
      "o": "MEO$IOptionsMonitorCache$$$TryRemove",
      "d": this.$h,
      "H": 17180917847,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180917847),
//--TRIMMABLE-BOUNDARY-START(4296015959),
    {
      "r": 65537,
      "n": "Clear",
      "o": "MEO$IOptionsMonitorCache$$$Clear",
      "d": this.$h,
      "H": 4296015959,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296015959)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 1048663,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IOptionsMonitorCache<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IOptionsMonitorCache$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1048663)
        
        

        //--TRIMMABLE-BOUNDARY-START(983127)
        $asm.$cls(`$meo.MEO.IOptionsMonitor<>`, (/*out*/ TOptions) => $asm.$gt(`$meo.MEO.IOptionsMonitor<>`, [/*out*/ TOptions], ($self) => class IOptionsMonitor$$
        {
            static $H = 983127;
            static $h = 983127;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295950423),
    {
      "p": TOptions?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12885885015,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50856193
      },
      "n": "CurrentValue",
      "o": `MEO$IOptionsMonitor$${TOptions.$getFullName('$')}$CurrentValue`,
      "d": this.$h,
      "H": 4295950423,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295950423)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180852311),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": `MEO$IOptionsMonitor$${TOptions.$getFullName('$')}$Get`,
      "d": this.$h,
      "H": 17180852311,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 17301761
    },
//--TRIMMABLE-BOUNDARY-END(17180852311),
//--TRIMMABLE-BOUNDARY-START(21475819607),
    {
      "r": 91095041,
      "p": [
        {
          "n": "listener",
          "p": $.$$.S.Action$$$(TOptions, $.$$.S.String).$h
        }
      ],
      "n": "OnChange",
      "o": `MEO$IOptionsMonitor$${TOptions.$getFullName('$')}$OnChange`,
      "d": this.$h,
      "H": 21475819607,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475819607)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 32
    }
  ],
  "r": 1,
  "H": 983127,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IOptionsMonitor<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IOptionsMonitor$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(983127)
        
        

        //--TRIMMABLE-BOUNDARY-START(655447)
        $asm.$cls(`$meo.MEO.IConfigureNamedOptions<>`, (/*in*/ TOptions) => $asm.$gt(`$meo.MEO.IConfigureNamedOptions<>`, [/*in*/ TOptions], ($self) => class IConfigureNamedOptions$$
        {
            static $H = 655447;
            static $h = 655447;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295622743),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864,
          "f": 32
        }
      ],
      "n": "Configure",
      "o": `MEO$IConfigureNamedOptions$${TOptions.$getFullName('$')}$Configure`,
      "d": this.$h,
      "H": 4295622743,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295622743)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 17
    }
  ],
  "r": 1,
  "H": 655447,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IConfigureNamedOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IConfigureNamedOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(655447)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114199)
        $asm.$cls(`$meo.MEO.IOptionsSnapshot<>`, (/*out*/ TOptions) => $asm.$gt(`$meo.MEO.IOptionsSnapshot<>`, [/*out*/ TOptions], ($self) => class IOptionsSnapshot$$
        {
            static $H = 1114199;
            static $h = 1114199;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296081495),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": `MEO$IOptionsSnapshot$${TOptions.$getFullName('$')}$Get`,
      "d": this.$h,
      "H": 4296081495,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 17301761
    },
//--TRIMMABLE-BOUNDARY-END(4296081495)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 33
    }
  ],
  "r": 1,
  "H": 1114199,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.IOptionsSnapshot<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}IOptionsSnapshot$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1114199)
        
        

        //--TRIMMABLE-BOUNDARY-START(2555991)
        $asm.$cls(`$meo.MEO.StartupValidatorOptions`, ($self) => class StartupValidatorOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297523287)
            /*Dictionary<(Type, string), Action>*/ _validators = null;
            //--TRIMMABLE-BOUNDARY-END(4297523287)
            
            //--TRIMMABLE-BOUNDARY-START(12887457879)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887457879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887457879)
            
            //--TRIMMABLE-BOUNDARY-START(12887457879)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12887457879)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4297523287)
                this._validators = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.String), $.$$.S.Action))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4297523287)
                
            }
            static $h = 2555991;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4297523287),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.String), $.$$.S.Action).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477392471,
        "f": 50331649
      },
      "n": "_validators",
      "d": 2555991,
      "h": 4297523287,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(4297523287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887457879),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2555991,
      "h": 12887457879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887457879)
  ],
  "h": 2555991
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.StartupValidatorOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}StartupValidatorOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2555991)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376343)
        $asm.$cls(`$meo.MEO.Options`, ($self) => class Options
        {
            //--TRIMMABLE-BOUNDARY-START(17181245527)
            /*DynamicallyAccessedMemberTypes*/ static DynamicallyAccessedMembers = 1;
            //--TRIMMABLE-BOUNDARY-END(17181245527)
            
            //--TRIMMABLE-BOUNDARY-START(12886278231)
            /*string*/ static DefaultName = null;
            //--TRIMMABLE-BOUNDARY-END(12886278231)
            
            //--TRIMMABLE-BOUNDARY-START(8591310935)
            static /*IOptions<TOptions> */ Create(TOptions, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$meo.MEO.OptionsWrapper$$(TOptions))().$ctor$1(options);
            }
            //--TRIMMABLE-BOUNDARY-END(8591310935)
            
            //--TRIMMABLE-BOUNDARY-START(4296343639)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12886278231)
                    this.DefaultName = $.$$.S.String.Empty;
                    //--TRIMMABLE-BOUNDARY-END(12886278231)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296343639)
            
            static $h = 1376343;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591310935),
    {
      "r": (TOptions) => $.$meo.MEO.IOptions$$(TOptions).$h,
      "p": [
        {
          "n": "options",
          "p": (TOptions) => TOptions.$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Create",
      "d": 1376343,
      "h": 8591310935,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591310935)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181245527),
    {
      "n": "DynamicallyAccessedMembers",
      "d": 1376343,
      "h": 17181245527,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181245527),
//--TRIMMABLE-BOUNDARY-START(12886278231),
    {
      "t": 1310721,
      "n": "DefaultName",
      "d": 1376343,
      "h": 12886278231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278231)
  ],
  "h": 1376343
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.Options`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}Options`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376343)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835095)
        $asm.$cls(`$meo.MEO.OptionsMonitorExtensions`, ($self) => class OptionsMonitorExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296802391)
            static /*IDisposable? */ OnChange(TOptions, /*this IOptionsMonitor<TOptions>*/ monitor, /*Action<TOptions>*/ listener)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296802391);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return monitor[`MEO$IOptionsMonitor$${TOptions.$getFullName('$')}$OnChange`](new ($.$$.S.Action$$$(TOptions, $.$$.S.String))().$ctor(this,  (/*o*/ o, /**/ _1) =>
                    {
                        return listener.Invoke(o);
                    }, $EbCReg ??= {"r":65537,"p":[{"n":"o","p":(TOptions) => TOptions.$h},{"n":"_","p":1310721}],"n":"","d":1835095,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296802391)
            
            static $h = 1835095;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296802391),
    {
      "r": 91095041,
      "p": [
        {
          "n": "monitor",
          "p": (TOptions) => $.$meo.MEO.IOptionsMonitor$$(TOptions).$h
        },
        {
          "n": "listener",
          "p": (TOptions) => $.$$.S.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "OnChange",
      "d": 1835095,
      "h": 4296802391,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4296802391)
  ],
  "h": 1835095
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsMonitorExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsMonitorExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835095)
        
        

        //--TRIMMABLE-BOUNDARY-START(3211351)
        $asm.$cls(`$meo.MEO.ValidateOptionsResult`, ($self) => class ValidateOptionsResult extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(141737132119)
            /*ValidateOptionsResult*/ static Skip = null;
            //--TRIMMABLE-BOUNDARY-END(141737132119)
            
            //--TRIMMABLE-BOUNDARY-START(154622034007)
            /*ValidateOptionsResult*/ static Success = null;
            //--TRIMMABLE-BOUNDARY-END(154622034007)
            
            //--TRIMMABLE-BOUNDARY-START(150327066711)
            /*bool*/ Succeeded = false;
            //--TRIMMABLE-BOUNDARY-END(150327066711)
            
            //--TRIMMABLE-BOUNDARY-START(146032099415)
            /*bool*/ Skipped = false;
            //--TRIMMABLE-BOUNDARY-END(146032099415)
            
            //--TRIMMABLE-BOUNDARY-START(42952884311)
            /*bool*/ Failed = false;
            //--TRIMMABLE-BOUNDARY-END(42952884311)
            
            //--TRIMMABLE-BOUNDARY-START(47247851607)
            /*string?*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(47247851607)
            
            //--TRIMMABLE-BOUNDARY-START(51542818903)
            /*IEnumerable<string>?*/ Failures = null;
            //--TRIMMABLE-BOUNDARY-END(51542818903)
            
            //--TRIMMABLE-BOUNDARY-START(38657917015)
            static /*ValidateOptionsResult */ Fail$1(/*string*/ failureMessage)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657917015);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$meo.MEO.ValidateOptionsResult()
                        const $t1 = $.$meo.MEO.ValidateOptionsResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Failed = true;
                        $i1.FailureMessage = failureMessage;
                        $i1.Failures = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [failureMessage], [-1], null);
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657917015)
            
            //--TRIMMABLE-BOUNDARY-START(34362949719)
            static /*ValidateOptionsResult */ Fail(/*IEnumerable<string>*/ failures)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362949719);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$meo.MEO.ValidateOptionsResult()
                        const $t2 = $.$meo.MEO.ValidateOptionsResult;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Failed = true;
                        $i2.FailureMessage = $.$$.S.String.Join$5("; ", failures);
                        $i2.Failures = failures;
                        return $i2;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362949719)
            
            //--TRIMMABLE-BOUNDARY-START(30067982423)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067982423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067982423)
            
            //--TRIMMABLE-BOUNDARY-START(30067982423)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30067982423)
            
            //--TRIMMABLE-BOUNDARY-START(25773015127)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773015127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(141737132119)
                    this.Skip = (() =>
                    {
                        //new $.$meo.MEO.ValidateOptionsResult()
                        const $t3 = $.$meo.MEO.ValidateOptionsResult;
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        $i3.Skipped = true;
                        return $i3;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(141737132119)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154622034007)
                    this.Success = (() =>
                    {
                        //new $.$meo.MEO.ValidateOptionsResult()
                        const $t4 = $.$meo.MEO.ValidateOptionsResult;
                        const $i4 = new $t4();
                        $i4.$ctor$1();
                        $i4.Succeeded = true;
                        return $i4;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(154622034007)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773015127)
            
            static $h = 3211351;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(150327066711),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492491863,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137442164823,
        "f": 83886084
      },
      "n": "Succeeded",
      "d": 3211351,
      "h": 150327066711,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150327066711),
//--TRIMMABLE-BOUNDARY-START(146032099415),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902557271,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128852230231,
        "f": 83886084
      },
      "n": "Skipped",
      "d": 3211351,
      "h": 146032099415,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146032099415),
//--TRIMMABLE-BOUNDARY-START(42952884311),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132753495,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103082426455,
        "f": 83886084
      },
      "n": "Failed",
      "d": 3211351,
      "h": 42952884311,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952884311),
//--TRIMMABLE-BOUNDARY-START(47247851607),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722688087,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111672361047,
        "f": 83886084
      },
      "n": "FailureMessage",
      "d": 3211351,
      "h": 47247851607,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247851607),
//--TRIMMABLE-BOUNDARY-START(51542818903),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312622679,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120262295639,
        "f": 83886084
      },
      "n": "Failures",
      "d": 3211351,
      "h": 51542818903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542818903)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38657917015),
    {
      "r": 3211351,
      "p": [
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "o": "@$1",
      "d": 3211351,
      "h": 38657917015,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657917015),
//--TRIMMABLE-BOUNDARY-START(34362949719),
    {
      "r": 3211351,
      "p": [
        {
          "n": "failures",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "Fail",
      "d": 3211351,
      "h": 34362949719,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362949719)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(141737132119),
    {
      "t": 3211351,
      "n": "Skip",
      "d": 3211351,
      "h": 141737132119,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141737132119),
//--TRIMMABLE-BOUNDARY-START(154622034007),
    {
      "t": 3211351,
      "n": "Success",
      "d": 3211351,
      "h": 154622034007,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154622034007)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067982423),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3211351,
      "h": 30067982423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067982423)
  ],
  "h": 3211351
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateOptionsResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateOptionsResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211351)
        
        

        //--TRIMMABLE-BOUNDARY-START(65623)
        $asm.$cls(`$meo.MED.OptionsBuilderExtensions`, ($self) => class OptionsBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295032919)
            static /*OptionsBuilder<TOptions> */ ValidateOnStart(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(optionsBuilder, "optionsBuilder");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddTransient$3($.$meo.MEO.IStartupValidator, $.$meo.MEO.StartupValidator, optionsBuilder.Services);
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions$2($.$meo.MEO.StartupValidatorOptions, optionsBuilder.Services).Configure$1($.$meo.MEO.IOptionsMonitor$$(TOptions), new ($.$$.S.Action$$$($.$meo.MEO.StartupValidatorOptions, $.$meo.MEO.IOptionsMonitor$$(TOptions)))().$ctor(this,  (/*vo*/ vo, /*options*/ options) =>
                {
                    vo._validators.set_Item(new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.String))().$ctor$3(TOptions.$type, optionsBuilder.Name), new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return options[`MEO$IOptionsMonitor$${TOptions.$getFullName('$')}$Get`](optionsBuilder.Name);
                    }, $gmToxc ??= {"r":65537,"n":"","d":65623,"h":0,"f":17825794}));
                }, $UuKoyb ??= {"r":65537,"p":[{"n":"vo","p":2555991},{"n":"options","p":(TOptions) => $.$meo.MEO.IOptionsMonitor$$(TOptions).$h}],"n":"","d":65623,"h":0,"f":17825794}));
                return optionsBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032919)
            
            static $h = 65623;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032919),
    {
      "r": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "optionsBuilder",
          "p": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "ValidateOnStart",
      "d": 65623,
      "h": 4295032919,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295032919)
  ],
  "h": 65623
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}OptionsBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65623)
        
        

        //--TRIMMABLE-BOUNDARY-START(3342423)
        $asm.$cls(`$meo.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(184686936151)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(184686936151)
            
            //--TRIMMABLE-BOUNDARY-START(167507066967)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167507066967);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167507066967)
            
            //--TRIMMABLE-BOUNDARY-START(197571838039)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197571838039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197571838039)
            
            //--TRIMMABLE-BOUNDARY-START(163212099671)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163212099671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$meo.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(163212099671)
            
            //--TRIMMABLE-BOUNDARY-START(158917132375)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158917132375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$meo.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(158917132375)
            
            //--TRIMMABLE-BOUNDARY-START(64427851863)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427851863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(64427851863)
            
            //--TRIMMABLE-BOUNDARY-START(60132884567)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132884567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(60132884567)
            
            //--TRIMMABLE-BOUNDARY-START(55837917271)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837917271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(55837917271)
            
            //--TRIMMABLE-BOUNDARY-START(68722819159)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722819159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$meo.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN($.$strNN(resourceFormat) + ", ") + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(68722819159)
            
            //--TRIMMABLE-BOUNDARY-START(47247982679)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247982679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(47247982679)
            
            //--TRIMMABLE-BOUNDARY-START(42953015383)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953015383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(42953015383)
            
            //--TRIMMABLE-BOUNDARY-START(38658048087)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658048087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(38658048087)
            
            //--TRIMMABLE-BOUNDARY-START(51542949975)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542949975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$meo.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN($.$strNN(resourceFormat) + ", ") + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(51542949975)
            
            //--TRIMMABLE-BOUNDARY-START(180391968855)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(180391968855)
            
            //--TRIMMABLE-BOUNDARY-START(171802034263)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(171802034263)
            
            //--TRIMMABLE-BOUNDARY-START(176097001559)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154622165079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$meo.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Options", $.$meo.S.SR.$type.Assembly);
                    $.$meo.S.SR.s_resourceManager = temp;
                }
                return $.$meo.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(176097001559)
            
            //--TRIMMABLE-BOUNDARY-START(8593277015)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492622935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meo.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276870743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8593277015)
            
            //--TRIMMABLE-BOUNDARY-START(12888244311)
            static /*string */ get Error_CannotActivateAbstractOrInterface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082557527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it is either abstract or an interface.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888244311)
            
            //--TRIMMABLE-BOUNDARY-START(73017786455)
            static /*string */ FormatError_CannotActivateAbstractOrInterface(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017786455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot create instance of type '{0}' because it is either abstract or an interface.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73017786455)
            
            //--TRIMMABLE-BOUNDARY-START(17183211607)
            static /*string */ get Error_FailedBinding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672492119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to convert '{0}' to type '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183211607)
            
            //--TRIMMABLE-BOUNDARY-START(77312753751)
            static /*string */ FormatError_FailedBinding(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312753751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Failed to convert '{0}' to type '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(77312753751)
            
            //--TRIMMABLE-BOUNDARY-START(21478178903)
            static /*string */ get Error_FailedToActivate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262426711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to create instance of type '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(21478178903)
            
            //--TRIMMABLE-BOUNDARY-START(81607721047)
            static /*string */ FormatError_FailedToActivate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607721047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Failed to create instance of type '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81607721047)
            
            //--TRIMMABLE-BOUNDARY-START(25773146199)
            static /*string */ get Error_MissingParameterlessConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852361303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it is missing a public parameterless constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(25773146199)
            
            //--TRIMMABLE-BOUNDARY-START(85902688343)
            static /*string */ FormatError_MissingParameterlessConstructor(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902688343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot create instance of type '{0}' because it is missing a public parameterless constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85902688343)
            
            //--TRIMMABLE-BOUNDARY-START(30068113495)
            static /*string */ get Error_NoConfigurationServices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442295895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No IConfigureOptions<>, IPostConfigureOptions<>, or IValidateOptions<> implementations were found.";
            }
            //--TRIMMABLE-BOUNDARY-END(30068113495)
            
            //--TRIMMABLE-BOUNDARY-START(34363080791)
            static /*string */ get Error_NoConfigurationServicesAndAction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032230487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No IConfigureOptions<>, IPostConfigureOptions<>, or IValidateOptions<> implementations were found, did you mean to call Configure<> or PostConfigure<>?";
            }
            //--TRIMMABLE-BOUNDARY-END(34363080791)
            
            //--TRIMMABLE-BOUNDARY-START(4298309719)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298309719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(184686936151)
                    this.s_usingResourceKeys = $.$meo.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(184686936151)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298309719)
            
            static $h = 3342423;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3342423
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342423)
        
        

        //--TRIMMABLE-BOUNDARY-START(3276887)
        $asm.$cls(`$meo.MEO.ValidateOptionsResultBuilder`, ($self) => class ValidateOptionsResultBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64427786327)
            /*string*/ static MemberSeparatorString = null;
            //--TRIMMABLE-BOUNDARY-END(64427786327)
            
            //--TRIMMABLE-BOUNDARY-START(4298244183)
            /*List<string>?*/ _errors = null;
            //--TRIMMABLE-BOUNDARY-END(4298244183)
            
            //--TRIMMABLE-BOUNDARY-START(8593211479)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593211479);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593211479)
            
            //--TRIMMABLE-BOUNDARY-START(12888178775)
            /*void */ AddError(/*string*/ error, /*string?*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888178775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(error, "error");
                this.Errors.Add(propertyName === null ? error : `Property ${$.$strNN(propertyName)}: ${$.$strNN(error)}`);
            }
            //--TRIMMABLE-BOUNDARY-END(12888178775)
            
            //--TRIMMABLE-BOUNDARY-START(21478113367)
            /*void */ AddResult$1(/*ValidationResult?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478113367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!((result?.ErrorMessage ?? null) === null))
                {
                    /*string*/ let joinedMembers = $.$$.S.String.Join$5(", "/*MemberSeparatorString*/, result.MemberNames);
                    this.Errors.Add(joinedMembers.length !== 0 ? `${$.$strNN(joinedMembers)}: ${$.$strNN(result.ErrorMessage)}` : result.ErrorMessage);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478113367)
            
            //--TRIMMABLE-BOUNDARY-START(25773080663)
            /*void */ AddResults(/*IEnumerable<ValidationResult?>?*/ results)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773080663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (results !== null)
                {
                    let $en1 = results.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let result = $en1.SCG$IEnumerator$$$Current;
                        {
                            this.AddResult$1(result);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773080663)
            
            //--TRIMMABLE-BOUNDARY-START(17183146071)
            /*void */ AddResult(/*ValidateOptionsResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183146071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(result, "result");
                if (result.Failed)
                {
                    if (result.Failures === null)
                    {
                        this.Errors.Add(result.FailureMessage);
                    }
                    else 
                    {
                        let $en2 = result.Failures.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let failure = $en2.SCG$IEnumerator$$$Current;
                            {
                                if (!(failure === null))
                                {
                                    this.Errors.Add(failure);
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183146071)
            
            //--TRIMMABLE-BOUNDARY-START(30068047959)
            /*ValidateOptionsResult */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068047959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Int32.op_GreaterThan((this._errors?.Count ?? null), 0))
                {
                    return $.$meo.MEO.ValidateOptionsResult.Fail(this._errors);
                }
                return $.$meo.MEO.ValidateOptionsResult.Success;
            }
            //--TRIMMABLE-BOUNDARY-END(30068047959)
            
            //--TRIMMABLE-BOUNDARY-START(34363015255)
            /*void */ Clear()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363015255);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._errors?.Clear() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34363015255)
            
            //--TRIMMABLE-BOUNDARY-START(42952949847)
            /*int */ get ErrorsCount()
            {
                return this._errors === null ? 0 : this._errors.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(42952949847)
            
            //--TRIMMABLE-BOUNDARY-START(38657982551)
            /*List<string> */ get Errors()
            {
                return this._errors ??= new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(38657982551)
            
            //--TRIMMABLE-BOUNDARY-START(8593211479)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8593211479)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(64427786327)
                    this.MemberSeparatorString = ", ";
                    //--TRIMMABLE-BOUNDARY-END(64427786327)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3276887;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952949847),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132819031,
        "f": 50331650
      },
      "n": "ErrorsCount",
      "d": 3276887,
      "h": 42952949847,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42952949847),
//--TRIMMABLE-BOUNDARY-START(38657982551),
    {
      "p": $.$$.SCG.List$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542884439,
        "f": 50331650
      },
      "n": "Errors",
      "d": 3276887,
      "h": 38657982551,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38657982551)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888178775),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 1310721
        },
        {
          "n": "propertyName",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "AddError",
      "d": 3276887,
      "h": 12888178775,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888178775),
//--TRIMMABLE-BOUNDARY-START(21478113367),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 3670055
        }
      ],
      "n": "AddResult",
      "o": "@$1",
      "d": 3276887,
      "h": 21478113367,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478113367),
//--TRIMMABLE-BOUNDARY-START(25773080663),
    {
      "r": 65537,
      "p": [
        {
          "n": "results",
          "p": $.$$.SCG.IEnumerable$$($.$sca.SCD.ValidationResult).$h
        }
      ],
      "n": "AddResults",
      "d": 3276887,
      "h": 25773080663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773080663),
//--TRIMMABLE-BOUNDARY-START(17183146071),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 3211351
        }
      ],
      "n": "AddResult",
      "d": 3276887,
      "h": 17183146071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183146071),
//--TRIMMABLE-BOUNDARY-START(30068047959),
    {
      "r": 3211351,
      "n": "Build",
      "d": 3276887,
      "h": 30068047959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068047959),
//--TRIMMABLE-BOUNDARY-START(34363015255),
    {
      "r": 65537,
      "n": "Clear",
      "d": 3276887,
      "h": 34363015255,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363015255)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64427786327),
    {
      "t": 1310721,
      "n": "MemberSeparatorString",
      "d": 3276887,
      "h": 64427786327,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64427786327),
//--TRIMMABLE-BOUNDARY-START(4298244183),
    {
      "t": $.$$.SCG.List$$($.$$.S.String).$h,
      "n": "_errors",
      "d": 3276887,
      "h": 4298244183,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298244183)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593211479),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3276887,
      "h": 8593211479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593211479)
  ],
  "h": 3276887,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{ErrorsCount} errors",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateOptionsResultBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateOptionsResultBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276887)
        
        

        //--TRIMMABLE-BOUNDARY-START(131159)
        $asm.$cls(`$meo.MED.OptionsServiceCollectionExtensions`, ($self) => class OptionsServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295098455)
            static /*IServiceCollection */ AddOptions(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$2($.$meo.MEO.IOptions$$().$type, $.$meo.MEO.UnnamedOptionsManager$$().$type));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Scoped$1($.$meo.MEO.IOptionsSnapshot$$().$type, $.$meo.MEO.OptionsManager$$().$type));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$2($.$meo.MEO.IOptionsMonitor$$().$type, $.$meo.MEO.OptionsMonitor$$().$type));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Transient$1($.$meo.MEO.IOptionsFactory$$().$type, $.$meo.MEO.OptionsFactory$$().$type));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$2($.$meo.MEO.IOptionsMonitorCache$$().$type, $.$meo.MEO.OptionsCache$$().$type));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098455)
            
            //--TRIMMABLE-BOUNDARY-START(21474967639)
            static /*OptionsBuilder<TOptions> */ AddOptionsWithValidateOnStart$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meo.MED.OptionsBuilderExtensions.ValidateOnStart(TOptions, new ($.$meo.MEO.OptionsBuilder$$(TOptions))().$ctor$1(services, name ?? $.$meo.MEO.Options.DefaultName));
            }
            //--TRIMMABLE-BOUNDARY-END(21474967639)
            
            //--TRIMMABLE-BOUNDARY-START(17180000343)
            static /*OptionsBuilder<TOptions> */ AddOptionsWithValidateOnStart(TOptions, TValidateOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddEnumerable($.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services), $.$mxdi.MED.ServiceDescriptor.Singleton$3($.$meo.MEO.IValidateOptions$$(TOptions), TValidateOptions));
                return $.$meo.MED.OptionsBuilderExtensions.ValidateOnStart(TOptions, new ($.$meo.MEO.OptionsBuilder$$(TOptions))().$ctor$1(services, name ?? $.$meo.MEO.Options.DefaultName));
            }
            //--TRIMMABLE-BOUNDARY-END(17180000343)
            
            //--TRIMMABLE-BOUNDARY-START(25769934935)
            static /*IServiceCollection */ Configure(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769934935);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.MED.OptionsServiceCollectionExtensions.Configure$1(TOptions, services, $.$meo.MEO.Options.DefaultName, configureOptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769934935)
            
            //--TRIMMABLE-BOUNDARY-START(30064902231)
            static /*IServiceCollection */ Configure$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*Action<TOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.MEO.IConfigureOptions$$(TOptions), services, new ($.$meo.MEO.ConfigureNamedOptions$$(TOptions))().$ctor$1(name, configureOptions));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902231)
            
            //--TRIMMABLE-BOUNDARY-START(34359869527)
            static /*IServiceCollection */ ConfigureAll(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359869527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.MED.OptionsServiceCollectionExtensions.Configure$1(TOptions, services, null, configureOptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359869527)
            
            //--TRIMMABLE-BOUNDARY-START(55834706007)
            static /*IServiceCollection */ PostConfigure(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834706007);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.MED.OptionsServiceCollectionExtensions.PostConfigure$1(TOptions, services, $.$meo.MEO.Options.DefaultName, configureOptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834706007)
            
            //--TRIMMABLE-BOUNDARY-START(60129673303)
            static /*IServiceCollection */ PostConfigure$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*Action<TOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.MEO.IPostConfigureOptions$$(TOptions), services, new ($.$meo.MEO.PostConfigureOptions$$(TOptions))().$ctor$1(name, configureOptions));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673303)
            
            //--TRIMMABLE-BOUNDARY-START(64424640599)
            static /*IServiceCollection */ PostConfigureAll(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424640599);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.MED.OptionsServiceCollectionExtensions.PostConfigure$1(TOptions, services, null, configureOptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424640599)
            
            //--TRIMMABLE-BOUNDARY-START(47244771415)
            static /*IServiceCollection */ ConfigureOptions$2(TConfigureOptions, /*this IServiceCollection*/ services)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244771415);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.MED.OptionsServiceCollectionExtensions.ConfigureOptions$1(services, TConfigureOptions.$type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244771415)
            
            //--TRIMMABLE-BOUNDARY-START(51539738711)
            static /*IEnumerable<Type> */ FindConfigurationServices(/*Type*/ type)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.Type))().$ctor$1(function*()
                {
                    let $i1 = 0;
                    let $arr1 = GetInterfacesOnType(type);
                    while ($i1 < $arr1.length)
                    {
                        let t = $arr1[$i1++];
                        if (t.IsGenericType)
                        {
                            /*Type*/ let gtd = t.GetGenericTypeDefinition();
                            if (gtd === $.$meo.MEO.IConfigureOptions$$().$type || gtd === $.$meo.MEO.IPostConfigureOptions$$().$type || gtd === $.$meo.MEO.IValidateOptions$$().$type)
                            {
                                yield t;
                            }
                        }
                    }
                    /*static Type[]*/  function GetInterfacesOnType(/*Type*/ t)
                    {
                        {
                            return t.GetInterfaces();
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(51539738711)
            
            //--TRIMMABLE-BOUNDARY-START(68719607895)
            static /*void */ ThrowNoConfigServices(/*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719607895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.InvalidOperationException().$ctor$12(type.IsGenericType && type.GetGenericTypeDefinition() === $.$$.S.Action$$().$type ? $.$meo.S.SR.Error_NoConfigurationServicesAndAction : $.$meo.S.SR.Error_NoConfigurationServices);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719607895)
            
            //--TRIMMABLE-BOUNDARY-START(42949804119)
            static /*IServiceCollection */ ConfigureOptions$1(/*this IServiceCollection*/ services, /*Type*/ configureType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                /*bool*/ let added = false;
                let $en2 = $.$meo.MED.OptionsServiceCollectionExtensions.FindConfigurationServices(configureType).SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let serviceType = $en2.SCG$IEnumerator$$$Current;
                    {
                        $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$1(services, serviceType, configureType);
                        added = true;
                    }
                }
                if (!added)
                {
                    $.$meo.MED.OptionsServiceCollectionExtensions.ThrowNoConfigServices(configureType);
                }
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804119)
            
            //--TRIMMABLE-BOUNDARY-START(38654836823)
            static /*IServiceCollection */ ConfigureOptions(/*this IServiceCollection*/ services, /*object*/ configureInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                /*Type*/ let configureType = $.$$.S.Object.GetType.call(configureInstance);
                /*bool*/ let added = false;
                let $en3 = $.$meo.MED.OptionsServiceCollectionExtensions.FindConfigurationServices(configureType).SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let serviceType = $en3.SCG$IEnumerator$$$Current;
                    {
                        $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$1(services, serviceType, configureInstance);
                        added = true;
                    }
                }
                if (!added)
                {
                    $.$meo.MED.OptionsServiceCollectionExtensions.ThrowNoConfigServices(configureType);
                }
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(38654836823)
            
            //--TRIMMABLE-BOUNDARY-START(12885033047)
            static /*OptionsBuilder<TOptions> */ AddOptions$2(TOptions, /*this IServiceCollection*/ services)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions$1(TOptions, services, $.$meo.MEO.Options.DefaultName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885033047)
            
            //--TRIMMABLE-BOUNDARY-START(8590065751)
            static /*OptionsBuilder<TOptions> */ AddOptions$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                return new ($.$meo.MEO.OptionsBuilder$$(TOptions))().$ctor$1(services, name);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065751)
            
            static $h = 131159;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098455),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddOptions",
      "d": 131159,
      "h": 4295098455,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098455),
//--TRIMMABLE-BOUNDARY-START(21474967639),
    {
      "r": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721,
          "f": 65
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "AddOptionsWithValidateOnStart",
      "o": "@$1",
      "d": 131159,
      "h": 21474967639,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21474967639),
//--TRIMMABLE-BOUNDARY-START(17180000343),
    {
      "r": (TOptions, TValidateOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721,
          "f": 65
        }
      ],
      "g": [
        "TOptions",
        "TValidateOptions"
      ],
      "n": "AddOptionsWithValidateOnStart",
      "d": 131159,
      "h": 17180000343,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180000343),
//--TRIMMABLE-BOUNDARY-START(25769934935),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.S.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "d": 131159,
      "h": 25769934935,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25769934935),
//--TRIMMABLE-BOUNDARY-START(30064902231),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.S.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "o": "@$1",
      "d": 131159,
      "h": 30064902231,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30064902231),
//--TRIMMABLE-BOUNDARY-START(34359869527),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.S.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "ConfigureAll",
      "d": 131159,
      "h": 34359869527,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34359869527),
//--TRIMMABLE-BOUNDARY-START(55834706007),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.S.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "PostConfigure",
      "d": 131159,
      "h": 55834706007,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(55834706007),
//--TRIMMABLE-BOUNDARY-START(60129673303),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.S.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": 131159,
      "h": 60129673303,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60129673303),
//--TRIMMABLE-BOUNDARY-START(64424640599),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.S.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "PostConfigureAll",
      "d": 131159,
      "h": 64424640599,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(64424640599),
//--TRIMMABLE-BOUNDARY-START(47244771415),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TConfigureOptions"
      ],
      "n": "ConfigureOptions",
      "o": "@$2",
      "d": 131159,
      "h": 47244771415,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47244771415),
//--TRIMMABLE-BOUNDARY-START(51539738711),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Type).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "FindConfigurationServices",
      "d": 131159,
      "h": 51539738711,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51539738711),
//--TRIMMABLE-BOUNDARY-START(68719607895),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "ThrowNoConfigServices",
      "d": 131159,
      "h": 68719607895,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719607895),
//--TRIMMABLE-BOUNDARY-START(42949804119),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureType",
          "p": 188547073
        }
      ],
      "n": "ConfigureOptions",
      "o": "@$1",
      "d": 131159,
      "h": 42949804119,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949804119),
//--TRIMMABLE-BOUNDARY-START(38654836823),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureInstance",
          "p": 131073
        }
      ],
      "n": "ConfigureOptions",
      "d": 131159,
      "h": 38654836823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654836823),
//--TRIMMABLE-BOUNDARY-START(12885033047),
    {
      "r": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "AddOptions",
      "o": "@$2",
      "d": 131159,
      "h": 12885033047,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885033047),
//--TRIMMABLE-BOUNDARY-START(8590065751),
    {
      "r": (TOptions) => $.$meo.MEO.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "AddOptions",
      "o": "@$1",
      "d": 131159,
      "h": 8590065751,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590065751)
  ],
  "h": 131159
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}OptionsServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131159)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441879)
        $asm.$cls(`$meo.MEO.OptionsBuilder<>`, (TOptions) => $asm.$gt(`$meo.MEO.OptionsBuilder<>`, [TOptions], ($self) => class OptionsBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42951114839)
            /*string*/ static DefaultValidationFailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42951114839)
            
            //--TRIMMABLE-BOUNDARY-START(64425951319)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(64425951319)
            
            //--TRIMMABLE-BOUNDARY-START(94490722391)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(94490722391)
            
            //--TRIMMABLE-BOUNDARY-START(12886343767)
            $ctor$1(/*IServiceCollection*/ services, /*string?*/ name)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343767);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                    this.Services = services;
                    this.Name = name ?? $.$meo.MEO.Options.DefaultName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343767)
            
            //--TRIMMABLE-BOUNDARY-START(17181311063)
            /*OptionsBuilder<TOptions> */ Configure(/*Action<TOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181311063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.MEO.IConfigureOptions$$(TOptions), this.Services, new ($.$meo.MEO.ConfigureNamedOptions$$(TOptions))().$ctor$1(this.Name, configureOptions));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311063)
            
            //--TRIMMABLE-BOUNDARY-START(21476278359)
            /*OptionsBuilder<TOptions> */ Configure$1(TDep, /*Action<TOptions, TDep>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476278359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ConfigureNamedOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), configureOptions);
                }, $MIuKgg ??= {"r":$.$meo.MEO.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278359)
            
            //--TRIMMABLE-BOUNDARY-START(38656147543)
            /*OptionsBuilder<TOptions> */ Configure$5(TDep1, TDep2, /*Action<TOptions, TDep1, TDep2>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ConfigureNamedOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), configureOptions);
                }, $YYrhal ??= {"r":$.$meo.MEO.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656147543)
            
            //--TRIMMABLE-BOUNDARY-START(34361180247)
            /*OptionsBuilder<TOptions> */ Configure$4(TDep1, TDep2, TDep3, /*Action<TOptions, TDep1, TDep2, TDep3>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ConfigureNamedOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), configureOptions);
                }, $YESdaf ??= {"r":$.$meo.MEO.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361180247)
            
            //--TRIMMABLE-BOUNDARY-START(30066212951)
            /*OptionsBuilder<TOptions> */ Configure$3(TDep1, TDep2, TDep3, TDep4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ConfigureNamedOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), configureOptions);
                }, $AHsOJc ??= {"r":$.$meo.MEO.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212951)
            
            //--TRIMMABLE-BOUNDARY-START(25771245655)
            /*OptionsBuilder<TOptions> */ Configure$2(TDep1, TDep2, TDep3, TDep4, TDep5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IConfigureOptions$$(TOptions)))().$ctor(this,  (/**/ sp) =>
                {
                    return new ($.$meo.MEO.ConfigureNamedOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), configureOptions);
                }, $DxAVuf ??= {"r":$.$meo.MEO.IConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245655)
            
            //--TRIMMABLE-BOUNDARY-START(68720918615)
            /*OptionsBuilder<TOptions> */ PostConfigure(/*Action<TOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720918615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.MEO.IPostConfigureOptions$$(TOptions), this.Services, new ($.$meo.MEO.PostConfigureOptions$$(TOptions))().$ctor$1(this.Name, configureOptions));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720918615)
            
            //--TRIMMABLE-BOUNDARY-START(73015885911)
            /*OptionsBuilder<TOptions> */ PostConfigure$1(TDep, /*Action<TOptions, TDep>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.PostConfigureOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), configureOptions);
                }, $VYoVwa ??= {"r":$.$meo.MEO.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015885911)
            
            //--TRIMMABLE-BOUNDARY-START(90195755095)
            /*OptionsBuilder<TOptions> */ PostConfigure$5(TDep1, TDep2, /*Action<TOptions, TDep1, TDep2>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195755095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.PostConfigureOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), configureOptions);
                }, $HKJUah ??= {"r":$.$meo.MEO.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90195755095)
            
            //--TRIMMABLE-BOUNDARY-START(85900787799)
            /*OptionsBuilder<TOptions> */ PostConfigure$4(TDep1, TDep2, TDep3, /*Action<TOptions, TDep1, TDep2, TDep3>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.PostConfigureOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), configureOptions);
                }, $QlAqza ??= {"r":$.$meo.MEO.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85900787799)
            
            //--TRIMMABLE-BOUNDARY-START(81605820503)
            /*OptionsBuilder<TOptions> */ PostConfigure$3(TDep1, TDep2, TDep3, TDep4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.PostConfigureOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), configureOptions);
                }, $sZUZQe ??= {"r":$.$meo.MEO.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605820503)
            
            //--TRIMMABLE-BOUNDARY-START(77310853207)
            /*OptionsBuilder<TOptions> */ PostConfigure$2(TDep1, TDep2, TDep3, TDep4, TDep5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.PostConfigureOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), configureOptions);
                }, $zDWOTj ??= {"r":$.$meo.MEO.IPostConfigureOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310853207)
            
            //--TRIMMABLE-BOUNDARY-START(103080656983)
            /*OptionsBuilder<TOptions> */ Validate$1(/*Func<TOptions, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080656983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate(validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080656983)
            
            //--TRIMMABLE-BOUNDARY-START(98785689687)
            /*OptionsBuilder<TOptions> */ Validate(/*Func<TOptions, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.MEO.IValidateOptions$$(TOptions), this.Services, new ($.$meo.MEO.ValidateOptions$$(TOptions))().$ctor$1(this.Name, validation, failureMessage));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(98785689687)
            
            //--TRIMMABLE-BOUNDARY-START(111670591575)
            /*OptionsBuilder<TOptions> */ Validate$3(TDep, /*Func<TOptions, TDep, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670591575);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$2(TDep, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670591575)
            
            //--TRIMMABLE-BOUNDARY-START(107375624279)
            /*OptionsBuilder<TOptions> */ Validate$2(TDep, /*Func<TOptions, TDep, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375624279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IValidateOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ValidateOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), validation, failureMessage);
                }, $BiNnol ??= {"r":$.$meo.MEO.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(107375624279)
            
            //--TRIMMABLE-BOUNDARY-START(146030329943)
            /*OptionsBuilder<TOptions> */ Validate$11(TDep1, TDep2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030329943);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$10(TDep1, TDep2, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030329943)
            
            //--TRIMMABLE-BOUNDARY-START(141735362647)
            /*OptionsBuilder<TOptions> */ Validate$10(TDep1, TDep2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735362647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IValidateOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ValidateOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), validation, failureMessage);
                }, $uRceUb ??= {"r":$.$meo.MEO.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(141735362647)
            
            //--TRIMMABLE-BOUNDARY-START(137440395351)
            /*OptionsBuilder<TOptions> */ Validate$9(TDep1, TDep2, TDep3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440395351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$8(TDep1, TDep2, TDep3, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137440395351)
            
            //--TRIMMABLE-BOUNDARY-START(133145428055)
            /*OptionsBuilder<TOptions> */ Validate$8(TDep1, TDep2, TDep3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145428055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IValidateOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ValidateOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), validation, failureMessage);
                }, $kXEzXd ??= {"r":$.$meo.MEO.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(133145428055)
            
            //--TRIMMABLE-BOUNDARY-START(128850460759)
            /*OptionsBuilder<TOptions> */ Validate$7(TDep1, TDep2, TDep3, TDep4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850460759);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$6(TDep1, TDep2, TDep3, TDep4, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850460759)
            
            //--TRIMMABLE-BOUNDARY-START(124555493463)
            /*OptionsBuilder<TOptions> */ Validate$6(TDep1, TDep2, TDep3, TDep4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555493463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IValidateOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ValidateOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), validation, failureMessage);
                }, $lOcJid ??= {"r":$.$meo.MEO.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(124555493463)
            
            //--TRIMMABLE-BOUNDARY-START(120260526167)
            /*OptionsBuilder<TOptions> */ Validate$5(TDep1, TDep2, TDep3, TDep4, TDep5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260526167);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$4(TDep1, TDep2, TDep3, TDep4, TDep5, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260526167)
            
            //--TRIMMABLE-BOUNDARY-START(115965558871)
            /*OptionsBuilder<TOptions> */ Validate$4(TDep1, TDep2, TDep3, TDep4, TDep5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965558871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.MEO.IValidateOptions$$(TOptions), this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$meo.MEO.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.MEO.ValidateOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), validation, failureMessage);
                }, $fKdkQf ??= {"r":$.$meo.MEO.IValidateOptions$$(TOptions).$h,"p":[{"n":"sp","p":327718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115965558871)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(42951114839)
                    this.DefaultValidationFailureMessage = "A validation error has occurred.";
                    //--TRIMMABLE-BOUNDARY-END(42951114839)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $H = 1441879;
            static $h = 1441879;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425951319),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541049431,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 64425951319,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425951319),
//--TRIMMABLE-BOUNDARY-START(94490722391),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60130984023,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Services",
      "d": this.$h,
      "H": 94490722391,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490722391)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181311063),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": $.$$.S.Action$$(TOptions).$h
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "H": 17181311063,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181311063),
//--TRIMMABLE-BOUNDARY-START(21476278359),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep) => $.$$.S.Action$$$(TOptions, TDep).$h
        }
      ],
      "g": [
        "TDep"
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "H": 21476278359,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(21476278359),
//--TRIMMABLE-BOUNDARY-START(38656147543),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2) => $.$$.S.Action$$$$(TOptions, TDep1, TDep2).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2"
      ],
      "n": "Configure",
      "o": "@$5",
      "d": this.$h,
      "H": 38656147543,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(38656147543),
//--TRIMMABLE-BOUNDARY-START(34361180247),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3) => $.$$.S.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3"
      ],
      "n": "Configure",
      "o": "@$4",
      "d": this.$h,
      "H": 34361180247,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(34361180247),
//--TRIMMABLE-BOUNDARY-START(30066212951),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3, TDep4) => $.$$.S.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4"
      ],
      "n": "Configure",
      "o": "@$3",
      "d": this.$h,
      "H": 30066212951,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(30066212951),
//--TRIMMABLE-BOUNDARY-START(25771245655),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.S.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4",
        "TDep5"
      ],
      "n": "Configure",
      "o": "@$2",
      "d": this.$h,
      "H": 25771245655,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(25771245655),
//--TRIMMABLE-BOUNDARY-START(68720918615),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": $.$$.S.Action$$(TOptions).$h
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "H": 68720918615,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720918615),
//--TRIMMABLE-BOUNDARY-START(73015885911),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep) => $.$$.S.Action$$$(TOptions, TDep).$h
        }
      ],
      "g": [
        "TDep"
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "H": 73015885911,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(73015885911),
//--TRIMMABLE-BOUNDARY-START(90195755095),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2) => $.$$.S.Action$$$$(TOptions, TDep1, TDep2).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2"
      ],
      "n": "PostConfigure",
      "o": "@$5",
      "d": this.$h,
      "H": 90195755095,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(90195755095),
//--TRIMMABLE-BOUNDARY-START(85900787799),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3) => $.$$.S.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3"
      ],
      "n": "PostConfigure",
      "o": "@$4",
      "d": this.$h,
      "H": 85900787799,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(85900787799),
//--TRIMMABLE-BOUNDARY-START(81605820503),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3, TDep4) => $.$$.S.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4"
      ],
      "n": "PostConfigure",
      "o": "@$3",
      "d": this.$h,
      "H": 81605820503,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(81605820503),
//--TRIMMABLE-BOUNDARY-START(77310853207),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.S.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4",
        "TDep5"
      ],
      "n": "PostConfigure",
      "o": "@$2",
      "d": this.$h,
      "H": 77310853207,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(77310853207),
//--TRIMMABLE-BOUNDARY-START(103080656983),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": $.$$.S.Func$$$(TOptions, $.$$.S.Boolean).$h
        }
      ],
      "n": "Validate",
      "o": "@$1",
      "d": this.$h,
      "H": 103080656983,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103080656983),
//--TRIMMABLE-BOUNDARY-START(98785689687),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": $.$$.S.Func$$$(TOptions, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "H": 98785689687,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98785689687),
//--TRIMMABLE-BOUNDARY-START(111670591575),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep) => $.$$.S.Func$$$$(TOptions, TDep, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "TDep"
      ],
      "n": "Validate",
      "o": "@$3",
      "d": this.$h,
      "H": 111670591575,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(111670591575),
//--TRIMMABLE-BOUNDARY-START(107375624279),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep) => $.$$.S.Func$$$$(TOptions, TDep, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep"
      ],
      "n": "Validate",
      "o": "@$2",
      "d": this.$h,
      "H": 107375624279,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(107375624279),
//--TRIMMABLE-BOUNDARY-START(146030329943),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2) => $.$$.S.Func$$$$$(TOptions, TDep1, TDep2, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2"
      ],
      "n": "Validate",
      "o": "@$11",
      "d": this.$h,
      "H": 146030329943,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(146030329943),
//--TRIMMABLE-BOUNDARY-START(141735362647),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2) => $.$$.S.Func$$$$$(TOptions, TDep1, TDep2, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep1",
        "TDep2"
      ],
      "n": "Validate",
      "o": "@$10",
      "d": this.$h,
      "H": 141735362647,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(141735362647),
//--TRIMMABLE-BOUNDARY-START(137440395351),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3) => $.$$.S.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3"
      ],
      "n": "Validate",
      "o": "@$9",
      "d": this.$h,
      "H": 137440395351,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(137440395351),
//--TRIMMABLE-BOUNDARY-START(133145428055),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3) => $.$$.S.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3"
      ],
      "n": "Validate",
      "o": "@$8",
      "d": this.$h,
      "H": 133145428055,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(133145428055),
//--TRIMMABLE-BOUNDARY-START(128850460759),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3, TDep4) => $.$$.S.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4"
      ],
      "n": "Validate",
      "o": "@$7",
      "d": this.$h,
      "H": 128850460759,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(128850460759),
//--TRIMMABLE-BOUNDARY-START(124555493463),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3, TDep4) => $.$$.S.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4"
      ],
      "n": "Validate",
      "o": "@$6",
      "d": this.$h,
      "H": 124555493463,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(124555493463),
//--TRIMMABLE-BOUNDARY-START(120260526167),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.S.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.S.Boolean).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4",
        "TDep5"
      ],
      "n": "Validate",
      "o": "@$5",
      "d": this.$h,
      "H": 120260526167,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(120260526167),
//--TRIMMABLE-BOUNDARY-START(115965558871),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.S.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4",
        "TDep5"
      ],
      "n": "Validate",
      "o": "@$4",
      "d": this.$h,
      "H": 115965558871,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(115965558871)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951114839),
    {
      "t": 1310721,
      "n": "DefaultValidationFailureMessage",
      "d": this.$h,
      "H": 42951114839,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951114839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886343767),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12886343767,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886343767)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 1441879,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsBuilder<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsBuilder$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1441879)
        
        

        //--TRIMMABLE-BOUNDARY-START(2621527)
        $asm.$cls(`$meo.MEO.UnnamedOptionsManager<>`, (TOptions) => $asm.$gt(`$meo.MEO.UnnamedOptionsManager<>`, [TOptions], ($self) => class UnnamedOptionsManager$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297588823)
            /*IOptionsFactory<TOptions>*/ _factory = null;
            //--TRIMMABLE-BOUNDARY-END(4297588823)
            
            //--TRIMMABLE-BOUNDARY-START(8592556119)
            /*object?*/ _syncObj = null;
            //--TRIMMABLE-BOUNDARY-END(8592556119)
            
            //--TRIMMABLE-BOUNDARY-START(12887523415)
            /*TOptions?*/ _value = null;
            //--TRIMMABLE-BOUNDARY-END(12887523415)
            
            //--TRIMMABLE-BOUNDARY-START(17182490711)
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182490711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._factory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182490711)
            
            //--TRIMMABLE-BOUNDARY-START(30067392599)
            /*TOptions */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772425303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let value;
                if ($.$is(this._value, TOptions, { set $v($v){ value = $v; } }))
                {
                    return value;
                }
                //lock(_syncObj ?? Interlocked.CompareExchange(ref _syncObj, new object(), null) ?? _syncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._syncObj ?? $.$$.ST$1.Interlocked.CompareExchange$7($.$ref(() => this._syncObj, ($v) => this._syncObj = $v, $.$$.S.Object), new $.$$.S.Object().$ctor(), null) ?? this._syncObj)
                    {
                        return this._value ??= this._factory[`MEO$IOptionsFactory$${TOptions.$getFullName('$')}$Create`]($.$meo.MEO.Options.DefaultName);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._syncObj ?? $.$$.ST$1.Interlocked.CompareExchange$7($.$ref(() => this._syncObj, ($v) => this._syncObj = $v, $.$$.S.Object), new $.$$.S.Object().$ctor(), null) ?? this._syncObj)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067392599)
            
            //--TRIMMABLE-BOUNDARY-START(8590721111)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get [`MEO$IOptions$${TOptions.$getFullName('$')}$Value`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721111)
            
            static $H = 2621527;
            static $h = 2621527;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067392599),
    {
      "p": TOptions?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25772425303,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "H": 30067392599,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067392599)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297588823),
    {
      "t": $.$meo.MEO.IOptionsFactory$$(TOptions).$h,
      "n": "_factory",
      "d": this.$h,
      "H": 4297588823,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297588823),
//--TRIMMABLE-BOUNDARY-START(8592556119),
    {
      "t": 131073,
      "n": "_syncObj",
      "d": this.$h,
      "H": 8592556119,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592556119),
//--TRIMMABLE-BOUNDARY-START(12887523415),
    {
      "t": TOptions?.$h??1572864,
      "n": "_value",
      "d": this.$h,
      "H": 12887523415,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887523415)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182490711),
    {
      "p": [
        {
          "n": "factory",
          "p": $.$meo.MEO.IOptionsFactory$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17182490711,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182490711)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 2621527,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.UnnamedOptionsManager<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}UnnamedOptionsManager$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2621527)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031703)
        $asm.$cls(`$meo.MEO.OptionsWrapper<>`, (TOptions) => $asm.$gt(`$meo.MEO.OptionsWrapper<>`, [TOptions], ($self) => class OptionsWrapper$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591966295)
            $ctor$1(/*TOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591966295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = options;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591966295)
            
            //--TRIMMABLE-BOUNDARY-START(21476868183)
            /*TOptions*/ Value = $.$default(TOptions);
            //--TRIMMABLE-BOUNDARY-END(21476868183)
            
            //--TRIMMABLE-BOUNDARY-START(8590721111)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get [`MEO$IOptions$${TOptions.$getFullName('$')}$Value`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721111)
            
            static $H = 2031703;
            static $h = 2031703;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476868183),
    {
      "p": TOptions?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17181900887,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "H": 21476868183,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476868183)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591966295),
    {
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8591966295,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591966295)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 2031703,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsWrapper<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsWrapper$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2031703)
        
        

        //--TRIMMABLE-BOUNDARY-START(2490455)
        $asm.$cls(`$meo.MEO.StartupValidator`, ($self) => class StartupValidator extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297457751)
            /*StartupValidatorOptions*/ _validatorOptions = null;
            //--TRIMMABLE-BOUNDARY-END(4297457751)
            
            //--TRIMMABLE-BOUNDARY-START(8592425047)
            $ctor$1(/*IOptions<StartupValidatorOptions>*/ validators)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592425047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._validatorOptions = validators.MEO$IOptions$Microsoft$Extensions$Options$StartupValidatorOptions$Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592425047)
            
            //--TRIMMABLE-BOUNDARY-START(12887392343)
            /*void */ Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887392343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<Exception>?*/ let exceptions = null;
                let $en1 = this._validatorOptions._validators.Values.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let validator = $en1.Current;
                    {
                        try
                        {
                            validator.Invoke();
                        }
                        catch(ex)
                        {
                            exceptions ??= new ($.$$.SCG.List$$($.$$.S.Exception))().$ctor$1();
                            exceptions.Add(ex);
                        }
                    }
                }
                if (exceptions !== null)
                {
                    if (exceptions.Count === 1)
                    {
                        $.$$.SRE$1.ExceptionDispatchInfo.Capture(exceptions.get_Item(0)).Throw();
                    }
                    if (exceptions.Count > 1)
                    {
                        throw new $.$$.S.AggregateException().$ctor$6(exceptions);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887392343)
            
            //--TRIMMABLE-BOUNDARY-START(4296212567)
            //Generated interface implemetation for Microsoft.Extensions.Options.IStartupValidator.Validate()
            MEO$IStartupValidator$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296212567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296212567)
            
            static $h = 2490455;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887392343),
    {
      "r": 65537,
      "n": "Validate",
      "d": 2490455,
      "h": 12887392343,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887392343)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297457751),
    {
      "t": 2555991,
      "n": "_validatorOptions",
      "d": 2490455,
      "h": 4297457751,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297457751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592425047),
    {
      "p": [
        {
          "n": "validators",
          "p": $.$meo.MEO.IOptions$$($.$meo.MEO.StartupValidatorOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2490455,
      "h": 8592425047,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592425047)
  ],
  "h": 2490455
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IStartupValidator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.StartupValidator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}StartupValidator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490455)
        
        

        //--TRIMMABLE-BOUNDARY-START(589911)
        $asm.$cls(`$meo.MEO.ConfigureOptions<>`, (TOptions) => $asm.$gt(`$meo.MEO.ConfigureOptions<>`, [TOptions], ($self) => class ConfigureOptions$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590524503)
            $ctor$1(/*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590524503);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524503)
            
            //--TRIMMABLE-BOUNDARY-START(12885491799)
            /*Action<TOptions>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(12885491799)
            
            //--TRIMMABLE-BOUNDARY-START(17180459095)
            /*void */ Configure(/*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                this.Action?.Invoke(options);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459095)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            [`MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $H = 589911;
            static $h = 589911;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885491799),
    {
      "p": $.$$.S.Action$$(TOptions).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770393687,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 12885491799,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885491799)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459095),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "H": 17180459095,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180459095)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590524503),
    {
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Action$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590524503,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590524503)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 589911,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigureOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigureOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(589911)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507415)
        $asm.$cls(`$meo.MEO.OptionsCache<>`, (TOptions) => $asm.$gt(`$meo.MEO.OptionsCache<>`, [TOptions], ($self) => class OptionsCache$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474711)
            /*ConcurrentDictionary<string, Lazy<TOptions>>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4296474711)
            
            //--TRIMMABLE-BOUNDARY-START(12886409303)
            /*void */ Clear()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409303);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._cache.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886409303)
            
            //--TRIMMABLE-BOUNDARY-START(17181376599)
            /*TOptions */ GetOrAdd(/*string?*/ name, /*Func<TOptions>*/ createOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(createOptions, "createOptions");
                name ??= $.$meo.MEO.Options.DefaultName;
                /*Lazy<TOptions>*/ let value;
                value = this._cache.GetOrAdd$2($.$$.S.Func$$(TOptions), name, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Func$$(TOptions), $.$$.S.Lazy$$(TOptions)))().$ctor($.$meo.MEO.OptionsCache$$(TOptions), /*static*/ (/*name*/ name, /*createOptions*/ createOptions) =>
                {
                    return new ($.$$.S.Lazy$$(TOptions))().$ctor$6(createOptions);
                }, $VlNtTc ??= {"r":$.$$.S.Lazy$$(TOptions).$h,"p":[{"n":"name","p":1310721},{"n":"createOptions","p":$.$$.S.Func$$(TOptions).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826}), createOptions);
                return value.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376599)
            
            //--TRIMMABLE-BOUNDARY-START(21476343895)
            /*TOptions */ GetOrAdd$1(TArg, /*string?*/ name, /*Func<string, TArg, TOptions>*/ createOptions, /*TArg*/ factoryArgument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.GetType.call(this) !== $.$meo.MEO.OptionsCache$$(TOptions).$type)
                {
                    /*string?*/ let localName = name;
                    /*Func<string, TArg, TOptions>*/ let localCreateOptions = createOptions;
                    /*TArg*/ let localFactoryArgument = factoryArgument;
                    return this.GetOrAdd(name, new ($.$$.S.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localCreateOptions.Invoke(localName ?? $.$meo.MEO.Options.DefaultName, localFactoryArgument);
                    }, $KwEBDb ??= {"r":TOptions?.$h??1572864,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                return this._cache.GetOrAdd$2($.$$.S.ValueTuple$$$($.$$.S.Func$$$$($.$$.S.String, TArg, TOptions), TArg), name ?? $.$meo.MEO.Options.DefaultName, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.S.Func$$$$($.$$.S.String, TArg, TOptions), TArg), $.$$.S.Lazy$$(TOptions)))().$ctor($.$meo.MEO.OptionsCache$$(TOptions), /*static*/ (/*name*/ name, /*arg*/ arg) =>
                {
                    return new ($.$$.S.Lazy$$(TOptions))().$ctor$6(new ($.$$.S.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return arg.Item1.Invoke(name, arg.Item2);
                    }, $TOELoi ??= {"r":TOptions?.$h??1572864,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }, $VnMkua ??= {"r":$.$$.S.Lazy$$(TOptions).$h,"p":[{"n":"name","p":1310721},{"n":"arg","p":(TArg) => $.$$.S.ValueTuple$$$($.$$.S.Func$$$$($.$$.S.String, TArg, TOptions), TArg).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826}), new ($.$$.S.ValueTuple$$$($.$$.S.Func$$$$($.$$.S.String, TArg, TOptions), TArg))().$ctor$3(createOptions, factoryArgument)).Value;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343895)
            
            //--TRIMMABLE-BOUNDARY-START(30066278487)
            /*bool */ TryGetValue(/*string?*/ name, /*out TOptions*/ options)
            {
                /*Lazy<TOptions>?*/ let lazy;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._cache.TryGetValue(name ?? $.$meo.MEO.Options.DefaultName, $.$ref(() => lazy, ($v) => lazy = $v, $.$$.S.Lazy$$(TOptions))))
                {
                    options.$v = lazy.Value;
                    return true;
                }
                options.$v = $.$default(TOptions);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30066278487)
            
            //--TRIMMABLE-BOUNDARY-START(25771311191)
            /*bool */ TryAdd(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                return this._cache.TryAdd(name ?? $.$meo.MEO.Options.DefaultName, new ($.$$.S.Lazy$$(TOptions))().$ctor$8(options));
            }
            //--TRIMMABLE-BOUNDARY-END(25771311191)
            
            //--TRIMMABLE-BOUNDARY-START(34361245783)
            /*bool */ TryRemove(/*string?*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361245783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._cache.TryRemove$1(name ?? $.$meo.MEO.Options.DefaultName, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245783)
            
            //--TRIMMABLE-BOUNDARY-START(8590983255)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.GetOrAdd(string?, System.Func<TOptions>)
            MEO$IOptionsMonitorCache$$$GetOrAdd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOrAdd(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983255)
            
            //--TRIMMABLE-BOUNDARY-START(12885950551)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.TryAdd(string?, TOptions)
            MEO$IOptionsMonitorCache$$$TryAdd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryAdd(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885950551)
            
            //--TRIMMABLE-BOUNDARY-START(17180917847)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.TryRemove(string?)
            MEO$IOptionsMonitorCache$$$TryRemove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180917847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryRemove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180917847)
            
            //--TRIMMABLE-BOUNDARY-START(4296015959)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.Clear()
            MEO$IOptionsMonitorCache$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296015959)
            
            //--TRIMMABLE-BOUNDARY-START(8591442007)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591442007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591442007)
            
            //--TRIMMABLE-BOUNDARY-START(8591442007)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591442007)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474711)
                this._cache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.Lazy$$(TOptions)))().$ctor$7(1, 31, $.$$.S.StringComparer.Ordinal);
                //--TRIMMABLE-BOUNDARY-END(4296474711)
                
            }
            static $H = 1507415;
            static $h = 1507415;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886409303),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "H": 12886409303,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409303),
//--TRIMMABLE-BOUNDARY-START(17181376599),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "createOptions",
          "p": $.$$.S.Func$$(TOptions).$h
        }
      ],
      "n": "GetOrAdd",
      "d": this.$h,
      "H": 17181376599,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181376599),
//--TRIMMABLE-BOUNDARY-START(21476343895),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "createOptions",
          "p": (TArg) => $.$$.S.Func$$$$($.$$.S.String, TArg, TOptions).$h
        },
        {
          "n": "factoryArgument",
          "p": (TArg) => TArg.$h
        }
      ],
      "g": [
        "TArg"
      ],
      "n": "GetOrAdd",
      "o": "@$1",
      "d": this.$h,
      "H": 21476343895,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(21476343895),
//--TRIMMABLE-BOUNDARY-START(30066278487),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": this.$h,
      "H": 30066278487,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30066278487),
//--TRIMMABLE-BOUNDARY-START(25771311191),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "TryAdd",
      "d": this.$h,
      "H": 25771311191,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771311191),
//--TRIMMABLE-BOUNDARY-START(34361245783),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "TryRemove",
      "d": this.$h,
      "H": 34361245783,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34361245783)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474711),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.Lazy$$(TOptions)).$h,
      "n": "_cache",
      "d": this.$h,
      "H": 4296474711,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474711)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591442007),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8591442007,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591442007)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 1507415,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptionsMonitorCache$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsCache<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsCache$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1507415)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572951)
        $asm.$cls(`$meo.MEO.OptionsFactory<>`, (TOptions) => $asm.$gt(`$meo.MEO.OptionsFactory<>`, [TOptions], ($self) => class OptionsFactory$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591507543)
            /*IConfigureOptions<TOptions>[]*/ _setups = null;
            //--TRIMMABLE-BOUNDARY-END(8591507543)
            
            //--TRIMMABLE-BOUNDARY-START(4296540247)
            /*IPostConfigureOptions<TOptions>[]*/ _postConfigures = null;
            //--TRIMMABLE-BOUNDARY-END(4296540247)
            
            //--TRIMMABLE-BOUNDARY-START(12886474839)
            /*IValidateOptions<TOptions>[]*/ _validations = null;
            //--TRIMMABLE-BOUNDARY-END(12886474839)
            
            //--TRIMMABLE-BOUNDARY-START(21476409431)
            $ctor$2(/*IEnumerable<IConfigureOptions<TOptions>>*/ setups, /*IEnumerable<IPostConfigureOptions<TOptions>>*/ postConfigures)
            {
                this.$ctor$1(setups, postConfigures, $.$$.S.Array.Empty($.$meo.MEO.IValidateOptions$$(TOptions)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476409431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409431)
            
            //--TRIMMABLE-BOUNDARY-START(17181442135)
            $ctor$1(/*IEnumerable<IConfigureOptions<TOptions>>*/ setups, /*IEnumerable<IPostConfigureOptions<TOptions>>*/ postConfigures, /*IEnumerable<IValidateOptions<TOptions>>*/ validations)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181442135);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._setups = $.$as(setups, $.$typeArray($.$meo.MEO.IConfigureOptions$$(TOptions))) ?? new ($.$$.SCG.List$$($.$meo.MEO.IConfigureOptions$$(TOptions)))().$ctor$2(setups).ToArray();
                    this._postConfigures = $.$as(postConfigures, $.$typeArray($.$meo.MEO.IPostConfigureOptions$$(TOptions))) ?? new ($.$$.SCG.List$$($.$meo.MEO.IPostConfigureOptions$$(TOptions)))().$ctor$2(postConfigures).ToArray();
                    this._validations = $.$as(validations, $.$typeArray($.$meo.MEO.IValidateOptions$$(TOptions))) ?? new ($.$$.SCG.List$$($.$meo.MEO.IValidateOptions$$(TOptions)))().$ctor$2(validations).ToArray();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181442135)
            
            //--TRIMMABLE-BOUNDARY-START(25771376727)
            /*TOptions */ Create(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771376727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TOptions*/ let options = this.CreateInstance(name);
                let $i1 = 0;
                let $arr1 = this._setups;
                while ($i1 < $arr1.length)
                {
                    let setup = $arr1[$i1++];
                    let namedSetup;
                    if ($.$is(setup, $.$meo.MEO.IConfigureNamedOptions$$(TOptions), { set $v($v){ namedSetup = $v; } }))
                    {
                        namedSetup[`MEO$IConfigureNamedOptions$${TOptions.$getFullName('$')}$Configure`](name, options);
                    }
                    else if (name === $.$meo.MEO.Options.DefaultName)
                    {
                        setup[`MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`](options);
                    }
                }
                let $i2 = 0;
                let $arr2 = this._postConfigures;
                while ($i2 < $arr2.length)
                {
                    let post = $arr2[$i2++];
                    post[`MEO$IPostConfigureOptions$${TOptions.$getFullName('$')}$PostConfigure`](name, options);
                }
                if (this._validations.length > 0)
                {
                    /*var*/ let failures = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                    let $i3 = 0;
                    let $arr3 = this._validations;
                    while ($i3 < $arr3.length)
                    {
                        let validate = $arr3[$i3++];
                        /*ValidateOptionsResult*/ let result = validate[`MEO$IValidateOptions$${TOptions.$getFullName('$')}$Validate`](name, options);
                        if (!(result === null) && result.Failed)
                        {
                            failures.AddRange(result.Failures);
                        }
                    }
                    if (failures.Count > 0)
                    {
                        throw new $.$meo.MEO.OptionsValidationException().$ctor$5(name, TOptions.$type, failures);
                    }
                }
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(25771376727)
            
            //--TRIMMABLE-BOUNDARY-START(30066344023)
            /*TOptions */ CreateInstance(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066344023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Activator.CreateInstance$10(TOptions);
            }
            //--TRIMMABLE-BOUNDARY-END(30066344023)
            
            //--TRIMMABLE-BOUNDARY-START(4295884887)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsFactory<TOptions>.Create(string)
            [`MEO$IOptionsFactory$${TOptions.$getFullName('$')}$Create`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884887)
            
            static $H = 1572951;
            static $h = 1572951;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771376727),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Create",
      "d": this.$h,
      "H": 25771376727,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771376727),
//--TRIMMABLE-BOUNDARY-START(30066344023),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "CreateInstance",
      "d": this.$h,
      "H": 30066344023,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30066344023)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591507543),
    {
      "t": $.$typeArray($.$meo.MEO.IConfigureOptions$$(TOptions)).$h,
      "n": "_setups",
      "d": this.$h,
      "H": 8591507543,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507543),
//--TRIMMABLE-BOUNDARY-START(4296540247),
    {
      "t": $.$typeArray($.$meo.MEO.IPostConfigureOptions$$(TOptions)).$h,
      "n": "_postConfigures",
      "d": this.$h,
      "H": 4296540247,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540247),
//--TRIMMABLE-BOUNDARY-START(12886474839),
    {
      "t": $.$typeArray($.$meo.MEO.IValidateOptions$$(TOptions)).$h,
      "n": "_validations",
      "d": this.$h,
      "H": 12886474839,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886474839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476409431),
    {
      "p": [
        {
          "n": "setups",
          "p": $.$$.SCG.IEnumerable$$($.$meo.MEO.IConfigureOptions$$(TOptions)).$h
        },
        {
          "n": "postConfigures",
          "p": $.$$.SCG.IEnumerable$$($.$meo.MEO.IPostConfigureOptions$$(TOptions)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 21476409431,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476409431),
//--TRIMMABLE-BOUNDARY-START(17181442135),
    {
      "p": [
        {
          "n": "setups",
          "p": $.$$.SCG.IEnumerable$$($.$meo.MEO.IConfigureOptions$$(TOptions)).$h
        },
        {
          "n": "postConfigures",
          "p": $.$$.SCG.IEnumerable$$($.$meo.MEO.IPostConfigureOptions$$(TOptions)).$h
        },
        {
          "n": "validations",
          "p": $.$$.SCG.IEnumerable$$($.$meo.MEO.IValidateOptions$$(TOptions)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17181442135,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181442135)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 1572951,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptionsFactory$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsFactory<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsFactory$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1572951)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424919)
        $asm.$cls(`$meo.MEO.PostConfigureOptions<>`, (TOptions) => $asm.$gt(`$meo.MEO.PostConfigureOptions<>`, [TOptions], ($self) => class PostConfigureOptions$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887326807)
            $ctor$1(/*string?*/ name, /*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887326807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326807)
            
            //--TRIMMABLE-BOUNDARY-START(38657130583)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(38657130583)
            
            //--TRIMMABLE-BOUNDARY-START(17182294103)
            /*Action<TOptions>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(17182294103)
            
            //--TRIMMABLE-BOUNDARY-START(42952097879)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952097879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952097879)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            [`MEO$IPostConfigureOptions$${TOptions.$getFullName('$')}$PostConfigure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $H = 2424919;
            static $h = 2424919;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657130583),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34362163287,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 38657130583,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657130583),
//--TRIMMABLE-BOUNDARY-START(17182294103),
    {
      "p": $.$$.S.Action$$(TOptions).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25772228695,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 17182294103,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182294103)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952097879),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "H": 42952097879,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42952097879)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887326807),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12887326807,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887326807)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 2424919,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IPostConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}PostConfigureOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2424919)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359383)
        $asm.$cls(`$meo.MEO.PostConfigureOptions<,>`, (TOptions, TDep) => $asm.$gt(`$meo.MEO.PostConfigureOptions<,>`, [TOptions, TDep], ($self) => class PostConfigureOptions$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182228567)
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Action<TOptions, TDep>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182228567);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency = dependency;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182228567)
            
            //--TRIMMABLE-BOUNDARY-START(55836934231)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(55836934231)
            
            //--TRIMMABLE-BOUNDARY-START(21477195863)
            /*Action<TOptions, TDep>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(21477195863)
            
            //--TRIMMABLE-BOUNDARY-START(25772163159)
            /*TDep*/ Dependency = $.$default(TDep);
            //--TRIMMABLE-BOUNDARY-END(25772163159)
            
            //--TRIMMABLE-BOUNDARY-START(60131901527)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131901527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131901527)
            
            //--TRIMMABLE-BOUNDARY-START(64426868823)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426868823);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426868823)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            [`MEO$IPostConfigureOptions$${TOptions.$getFullName('$')}$PostConfigure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $H = 2359383;
            static $h = 2359383;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836934231),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541966935,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 55836934231,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836934231),
//--TRIMMABLE-BOUNDARY-START(21477195863),
    {
      "p": $.$$.S.Action$$$(TOptions, TDep).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34362097751,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 21477195863,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477195863),
//--TRIMMABLE-BOUNDARY-START(25772163159),
    {
      "p": TDep?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42952032343,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Dependency",
      "d": this.$h,
      "H": 25772163159,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772163159)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131901527),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "H": 60131901527,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60131901527),
//--TRIMMABLE-BOUNDARY-START(64426868823),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "H": 64426868823,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426868823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182228567),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep?.$h??1638400
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$(TOptions, TDep).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17182228567,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182228567)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep?.$h??1638400,
      "n": "TDep",
      "f": 1
    }
  ],
  "r": 2,
  "H": 2359383,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IPostConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}PostConfigureOptions$${TOptions?.$getFullName(separator)}$${TDep?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2359383)
        
        

        //--TRIMMABLE-BOUNDARY-START(2293847)
        $asm.$cls(`$meo.MEO.PostConfigureOptions<,,>`, (TOptions, TDep1, TDep2) => $asm.$gt(`$meo.MEO.PostConfigureOptions<,,>`, [TOptions, TDep1, TDep2], ($self) => class PostConfigureOptions$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21477130327)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*Action<TOptions, TDep1, TDep2>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477130327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477130327)
            
            //--TRIMMABLE-BOUNDARY-START(73016737879)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(73016737879)
            
            //--TRIMMABLE-BOUNDARY-START(25772097623)
            /*Action<TOptions, TDep1, TDep2>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(25772097623)
            
            //--TRIMMABLE-BOUNDARY-START(30067064919)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(30067064919)
            
            //--TRIMMABLE-BOUNDARY-START(34362032215)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(34362032215)
            
            //--TRIMMABLE-BOUNDARY-START(77311705175)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311705175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311705175)
            
            //--TRIMMABLE-BOUNDARY-START(81606672471)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81606672471);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606672471)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            [`MEO$IPostConfigureOptions$${TOptions.$getFullName('$')}$PostConfigure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $H = 2293847;
            static $h = 2293847;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73016737879),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721770583,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 73016737879,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016737879),
//--TRIMMABLE-BOUNDARY-START(25772097623),
    {
      "p": $.$$.S.Action$$$$(TOptions, TDep1, TDep2).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42951966807,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 25772097623,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772097623),
//--TRIMMABLE-BOUNDARY-START(30067064919),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541901399,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 30067064919,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067064919),
//--TRIMMABLE-BOUNDARY-START(34362032215),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131835991,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 34362032215,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362032215)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77311705175),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "H": 77311705175,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77311705175),
//--TRIMMABLE-BOUNDARY-START(81606672471),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "H": 81606672471,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606672471)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477130327),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$$(TOptions, TDep1, TDep2).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 21477130327,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477130327)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1",
      "f": 1
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2",
      "f": 1
    }
  ],
  "r": 3,
  "H": 2293847,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IPostConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}PostConfigureOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2293847)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228311)
        $asm.$cls(`$meo.MEO.PostConfigureOptions<,,,>`, (TOptions, TDep1, TDep2, TDep3) => $asm.$gt(`$meo.MEO.PostConfigureOptions<,,,>`, [TOptions, TDep1, TDep2, TDep3], ($self) => class PostConfigureOptions$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25772032087)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Action<TOptions, TDep1, TDep2, TDep3>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772032087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772032087)
            
            //--TRIMMABLE-BOUNDARY-START(90196541527)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(90196541527)
            
            //--TRIMMABLE-BOUNDARY-START(30066999383)
            /*Action<TOptions, TDep1, TDep2, TDep3>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(30066999383)
            
            //--TRIMMABLE-BOUNDARY-START(34361966679)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(34361966679)
            
            //--TRIMMABLE-BOUNDARY-START(38656933975)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(38656933975)
            
            //--TRIMMABLE-BOUNDARY-START(42951901271)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(42951901271)
            
            //--TRIMMABLE-BOUNDARY-START(94491508823)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491508823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491508823)
            
            //--TRIMMABLE-BOUNDARY-START(98786476119)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98786476119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98786476119)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            [`MEO$IPostConfigureOptions$${TOptions.$getFullName('$')}$PostConfigure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $H = 2228311;
            static $h = 2228311;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90196541527),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85901574231,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 90196541527,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196541527),
//--TRIMMABLE-BOUNDARY-START(30066999383),
    {
      "p": $.$$.S.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541835863,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 30066999383,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066999383),
//--TRIMMABLE-BOUNDARY-START(34361966679),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131770455,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 34361966679,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361966679),
//--TRIMMABLE-BOUNDARY-START(38656933975),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721705047,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 38656933975,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656933975),
//--TRIMMABLE-BOUNDARY-START(42951901271),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77311639639,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 42951901271,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951901271)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94491508823),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "H": 94491508823,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94491508823),
//--TRIMMABLE-BOUNDARY-START(98786476119),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "H": 98786476119,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98786476119)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772032087),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 25772032087,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772032087)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1",
      "f": 1
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2",
      "f": 1
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3",
      "f": 1
    }
  ],
  "r": 4,
  "H": 2228311,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IPostConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}PostConfigureOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2228311)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162775)
        $asm.$cls(`$meo.MEO.PostConfigureOptions<,,,,>`, (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt(`$meo.MEO.PostConfigureOptions<,,,,>`, [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class PostConfigureOptions$$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066933847)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066933847);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066933847)
            
            //--TRIMMABLE-BOUNDARY-START(107376345175)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(107376345175)
            
            //--TRIMMABLE-BOUNDARY-START(34361901143)
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(34361901143)
            
            //--TRIMMABLE-BOUNDARY-START(38656868439)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(38656868439)
            
            //--TRIMMABLE-BOUNDARY-START(42951835735)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(42951835735)
            
            //--TRIMMABLE-BOUNDARY-START(47246803031)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(47246803031)
            
            //--TRIMMABLE-BOUNDARY-START(51541770327)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(51541770327)
            
            //--TRIMMABLE-BOUNDARY-START(111671312471)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671312471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111671312471)
            
            //--TRIMMABLE-BOUNDARY-START(115966279767)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115966279767);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115966279767)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            [`MEO$IPostConfigureOptions$${TOptions.$getFullName('$')}$PostConfigure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $H = 2162775;
            static $h = 2162775;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107376345175),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103081377879,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 107376345175,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376345175),
//--TRIMMABLE-BOUNDARY-START(34361901143),
    {
      "p": $.$$.S.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131704919,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 34361901143,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361901143),
//--TRIMMABLE-BOUNDARY-START(38656868439),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721639511,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 38656868439,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656868439),
//--TRIMMABLE-BOUNDARY-START(42951835735),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77311574103,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 42951835735,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951835735),
//--TRIMMABLE-BOUNDARY-START(47246803031),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85901508695,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 47246803031,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246803031),
//--TRIMMABLE-BOUNDARY-START(51541770327),
    {
      "p": TDep4?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94491443287,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "H": 51541770327,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541770327)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111671312471),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "H": 111671312471,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111671312471),
//--TRIMMABLE-BOUNDARY-START(115966279767),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "H": 115966279767,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115966279767)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066933847),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1835008
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 30066933847,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066933847)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1",
      "f": 1
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2",
      "f": 1
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3",
      "f": 1
    },
    {
      "h": TDep4?.$h??1835008,
      "n": "TDep4",
      "f": 1
    }
  ],
  "r": 5,
  "H": 2162775,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IPostConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}PostConfigureOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$${TDep4?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2162775)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097239)
        $asm.$cls(`$meo.MEO.PostConfigureOptions<,,,,,>`, (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt(`$meo.MEO.PostConfigureOptions<,,,,,>`, [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class PostConfigureOptions$$$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361835607)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361835607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361835607)
            
            //--TRIMMABLE-BOUNDARY-START(124556148823)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(124556148823)
            
            //--TRIMMABLE-BOUNDARY-START(38656802903)
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(38656802903)
            
            //--TRIMMABLE-BOUNDARY-START(42951770199)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(42951770199)
            
            //--TRIMMABLE-BOUNDARY-START(47246737495)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(47246737495)
            
            //--TRIMMABLE-BOUNDARY-START(51541704791)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(51541704791)
            
            //--TRIMMABLE-BOUNDARY-START(55836672087)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(55836672087)
            
            //--TRIMMABLE-BOUNDARY-START(60131639383)
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            //--TRIMMABLE-BOUNDARY-END(60131639383)
            
            //--TRIMMABLE-BOUNDARY-START(128851116119)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851116119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851116119)
            
            //--TRIMMABLE-BOUNDARY-START(133146083415)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146083415);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146083415)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            [`MEO$IPostConfigureOptions$${TOptions.$getFullName('$')}$PostConfigure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $H = 2097239;
            static $h = 2097239;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124556148823),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120261181527,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 124556148823,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124556148823),
//--TRIMMABLE-BOUNDARY-START(38656802903),
    {
      "p": $.$$.S.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721573975,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 38656802903,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656802903),
//--TRIMMABLE-BOUNDARY-START(42951770199),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77311508567,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 42951770199,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951770199),
//--TRIMMABLE-BOUNDARY-START(47246737495),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85901443159,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 47246737495,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246737495),
//--TRIMMABLE-BOUNDARY-START(51541704791),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94491377751,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 51541704791,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541704791),
//--TRIMMABLE-BOUNDARY-START(55836672087),
    {
      "p": TDep4?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103081312343,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "H": 55836672087,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836672087),
//--TRIMMABLE-BOUNDARY-START(60131639383),
    {
      "p": TDep5?.$h??1900544,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111671246935,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "n": "Dependency5",
      "d": this.$h,
      "H": 60131639383,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131639383)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128851116119),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "H": 128851116119,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(128851116119),
//--TRIMMABLE-BOUNDARY-START(133146083415),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "H": 133146083415,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133146083415)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361835607),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1835008
        },
        {
          "n": "dependency5",
          "p": TDep5?.$h??1900544
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 34361835607,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361835607)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1",
      "f": 1
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2",
      "f": 1
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3",
      "f": 1
    },
    {
      "h": TDep4?.$h??1835008,
      "n": "TDep4",
      "f": 1
    },
    {
      "h": TDep5?.$h??1900544,
      "n": "TDep5",
      "f": 1
    }
  ],
  "r": 6,
  "H": 2097239,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IPostConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}PostConfigureOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$${TDep4?.$getFullName(separator)}$${TDep5?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2097239)
        
        

        //--TRIMMABLE-BOUNDARY-START(3145815)
        $asm.$cls(`$meo.MEO.ValidateOptions<>`, (TOptions) => $asm.$gt(`$meo.MEO.ValidateOptions<>`, [TOptions], ($self) => class ValidateOptions$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183014999)
            $ctor$1(/*string?*/ name, /*Func<TOptions, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183014999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183014999)
            
            //--TRIMMABLE-BOUNDARY-START(51542753367)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(51542753367)
            
            //--TRIMMABLE-BOUNDARY-START(60132687959)
            /*Func<TOptions, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(60132687959)
            
            //--TRIMMABLE-BOUNDARY-START(21477982295)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(21477982295)
            
            //--TRIMMABLE-BOUNDARY-START(55837720663)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837720663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Name === null || name === this.Name)
                {
                    if (this.Validation.Invoke(options))
                    {
                        return $.$meo.MEO.ValidateOptionsResult.Success;
                    }
                    return $.$meo.MEO.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.MEO.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(55837720663)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            [`MEO$IValidateOptions$${TOptions.$getFullName('$')}$Validate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $H = 3145815;
            static $h = 3145815;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542753367),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38657851479,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 51542753367,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542753367),
//--TRIMMABLE-BOUNDARY-START(60132687959),
    {
      "p": $.$$.S.Func$$$(TOptions, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47247786071,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "H": 60132687959,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132687959),
//--TRIMMABLE-BOUNDARY-START(21477982295),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30067916887,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "H": 21477982295,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477982295)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55837720663),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "H": 55837720663,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55837720663)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183014999),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "validation",
          "p": $.$$.S.Func$$$(TOptions, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17183014999,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183014999)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 3145815,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IValidateOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3145815)
        
        

        //--TRIMMABLE-BOUNDARY-START(3080279)
        $asm.$cls(`$meo.MEO.ValidateOptions<,>`, (TOptions, TDep) => $asm.$gt(`$meo.MEO.ValidateOptions<,>`, [TOptions, TDep], ($self) => class ValidateOptions$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21477916759)
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Func<TOptions, TDep, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477916759);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency = dependency;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477916759)
            
            //--TRIMMABLE-BOUNDARY-START(68722557015)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(68722557015)
            
            //--TRIMMABLE-BOUNDARY-START(77312491607)
            /*Func<TOptions, TDep, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(77312491607)
            
            //--TRIMMABLE-BOUNDARY-START(30067851351)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(30067851351)
            
            //--TRIMMABLE-BOUNDARY-START(25772884055)
            /*TDep*/ Dependency = $.$default(TDep);
            //--TRIMMABLE-BOUNDARY-END(25772884055)
            
            //--TRIMMABLE-BOUNDARY-START(73017524311)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017524311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Name === null || name === this.Name)
                {
                    if (this.Validation.Invoke(options, this.Dependency))
                    {
                        return $.$meo.MEO.ValidateOptionsResult.Success;
                    }
                    return $.$meo.MEO.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.MEO.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(73017524311)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            [`MEO$IValidateOptions$${TOptions.$getFullName('$')}$Validate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $H = 3080279;
            static $h = 3080279;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68722557015),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55837655127,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 68722557015,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722557015),
//--TRIMMABLE-BOUNDARY-START(77312491607),
    {
      "p": $.$$.S.Func$$$$(TOptions, TDep, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64427589719,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "H": 77312491607,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312491607),
//--TRIMMABLE-BOUNDARY-START(30067851351),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47247720535,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "H": 30067851351,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067851351),
//--TRIMMABLE-BOUNDARY-START(25772884055),
    {
      "p": TDep?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38657785943,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "Dependency",
      "d": this.$h,
      "H": 25772884055,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772884055)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73017524311),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "H": 73017524311,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73017524311)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477916759),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep?.$h??1638400
        },
        {
          "n": "validation",
          "p": $.$$.S.Func$$$$(TOptions, TDep, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 21477916759,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477916759)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep?.$h??1638400,
      "n": "TDep"
    }
  ],
  "r": 2,
  "H": 3080279,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IValidateOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateOptions$${TOptions?.$getFullName(separator)}$${TDep?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3080279)
        
        

        //--TRIMMABLE-BOUNDARY-START(3014743)
        $asm.$cls(`$meo.MEO.ValidateOptions<,,>`, (TOptions, TDep1, TDep2) => $asm.$gt(`$meo.MEO.ValidateOptions<,,>`, [TOptions, TDep1, TDep2], ($self) => class ValidateOptions$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25772818519)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772818519);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772818519)
            
            //--TRIMMABLE-BOUNDARY-START(85902360663)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(85902360663)
            
            //--TRIMMABLE-BOUNDARY-START(94492295255)
            /*Func<TOptions, TDep1, TDep2, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(94492295255)
            
            //--TRIMMABLE-BOUNDARY-START(38657720407)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(38657720407)
            
            //--TRIMMABLE-BOUNDARY-START(30067785815)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(30067785815)
            
            //--TRIMMABLE-BOUNDARY-START(34362753111)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(34362753111)
            
            //--TRIMMABLE-BOUNDARY-START(90197327959)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197327959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Name === null || name === this.Name)
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2))
                    {
                        return $.$meo.MEO.ValidateOptionsResult.Success;
                    }
                    return $.$meo.MEO.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.MEO.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(90197327959)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            [`MEO$IValidateOptions$${TOptions.$getFullName('$')}$Validate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $H = 3014743;
            static $h = 3014743;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85902360663),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73017458775,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 85902360663,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85902360663),
//--TRIMMABLE-BOUNDARY-START(94492295255),
    {
      "p": $.$$.S.Func$$$$$(TOptions, TDep1, TDep2, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81607393367,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "H": 94492295255,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94492295255),
//--TRIMMABLE-BOUNDARY-START(38657720407),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64427524183,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "H": 38657720407,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657720407),
//--TRIMMABLE-BOUNDARY-START(30067785815),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47247654999,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 30067785815,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067785815),
//--TRIMMABLE-BOUNDARY-START(34362753111),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55837589591,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 34362753111,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362753111)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90197327959),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "H": 90197327959,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90197327959)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772818519),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "validation",
          "p": $.$$.S.Func$$$$$(TOptions, TDep1, TDep2, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 25772818519,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772818519)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1"
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2"
    }
  ],
  "r": 3,
  "H": 3014743,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IValidateOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3014743)
        
        

        //--TRIMMABLE-BOUNDARY-START(2949207)
        $asm.$cls(`$meo.MEO.ValidateOptions<,,,>`, (TOptions, TDep1, TDep2, TDep3) => $asm.$gt(`$meo.MEO.ValidateOptions<,,,>`, [TOptions, TDep1, TDep2, TDep3], ($self) => class ValidateOptions$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30067720279)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067720279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067720279)
            
            //--TRIMMABLE-BOUNDARY-START(103082164311)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(103082164311)
            
            //--TRIMMABLE-BOUNDARY-START(111672098903)
            /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(111672098903)
            
            //--TRIMMABLE-BOUNDARY-START(47247589463)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(47247589463)
            
            //--TRIMMABLE-BOUNDARY-START(34362687575)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(34362687575)
            
            //--TRIMMABLE-BOUNDARY-START(38657654871)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(38657654871)
            
            //--TRIMMABLE-BOUNDARY-START(42952622167)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(42952622167)
            
            //--TRIMMABLE-BOUNDARY-START(107377131607)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377131607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Name === null || name === this.Name)
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3))
                    {
                        return $.$meo.MEO.ValidateOptionsResult.Success;
                    }
                    return $.$meo.MEO.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.MEO.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(107377131607)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            [`MEO$IValidateOptions$${TOptions.$getFullName('$')}$Validate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $H = 2949207;
            static $h = 2949207;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103082164311),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90197262423,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 103082164311,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103082164311),
//--TRIMMABLE-BOUNDARY-START(111672098903),
    {
      "p": $.$$.S.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98787197015,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "H": 111672098903,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111672098903),
//--TRIMMABLE-BOUNDARY-START(47247589463),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81607327831,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "H": 47247589463,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247589463),
//--TRIMMABLE-BOUNDARY-START(34362687575),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55837524055,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 34362687575,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362687575),
//--TRIMMABLE-BOUNDARY-START(38657654871),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64427458647,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 38657654871,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657654871),
//--TRIMMABLE-BOUNDARY-START(42952622167),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73017393239,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 42952622167,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952622167)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107377131607),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "H": 107377131607,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107377131607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067720279),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "validation",
          "p": $.$$.S.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 30067720279,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067720279)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1"
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2"
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3"
    }
  ],
  "r": 4,
  "H": 2949207,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IValidateOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2949207)
        
        

        //--TRIMMABLE-BOUNDARY-START(2883671)
        $asm.$cls(`$meo.MEO.ValidateOptions<,,,,>`, (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt(`$meo.MEO.ValidateOptions<,,,,>`, [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class ValidateOptions$$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34362622039)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362622039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362622039)
            
            //--TRIMMABLE-BOUNDARY-START(120261967959)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(120261967959)
            
            //--TRIMMABLE-BOUNDARY-START(128851902551)
            /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(128851902551)
            
            //--TRIMMABLE-BOUNDARY-START(55837458519)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(55837458519)
            
            //--TRIMMABLE-BOUNDARY-START(38657589335)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(38657589335)
            
            //--TRIMMABLE-BOUNDARY-START(42952556631)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(42952556631)
            
            //--TRIMMABLE-BOUNDARY-START(47247523927)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(47247523927)
            
            //--TRIMMABLE-BOUNDARY-START(51542491223)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(51542491223)
            
            //--TRIMMABLE-BOUNDARY-START(124556935255)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556935255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Name === null || name === this.Name)
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4))
                    {
                        return $.$meo.MEO.ValidateOptionsResult.Success;
                    }
                    return $.$meo.MEO.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.MEO.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(124556935255)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            [`MEO$IValidateOptions$${TOptions.$getFullName('$')}$Validate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $H = 2883671;
            static $h = 2883671;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120261967959),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107377066071,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 120261967959,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261967959),
//--TRIMMABLE-BOUNDARY-START(128851902551),
    {
      "p": $.$$.S.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115967000663,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "H": 128851902551,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128851902551),
//--TRIMMABLE-BOUNDARY-START(55837458519),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98787131479,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "H": 55837458519,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837458519),
//--TRIMMABLE-BOUNDARY-START(38657589335),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64427393111,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 38657589335,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657589335),
//--TRIMMABLE-BOUNDARY-START(42952556631),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73017327703,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 42952556631,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952556631),
//--TRIMMABLE-BOUNDARY-START(47247523927),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81607262295,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 47247523927,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247523927),
//--TRIMMABLE-BOUNDARY-START(51542491223),
    {
      "p": TDep4?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90197196887,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "H": 51542491223,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542491223)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(124556935255),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "H": 124556935255,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124556935255)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34362622039),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1835008
        },
        {
          "n": "validation",
          "p": $.$$.S.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 34362622039,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362622039)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1"
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2"
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3"
    },
    {
      "h": TDep4?.$h??1835008,
      "n": "TDep4"
    }
  ],
  "r": 5,
  "H": 2883671,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IValidateOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$${TDep4?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2883671)
        
        

        //--TRIMMABLE-BOUNDARY-START(2818135)
        $asm.$cls(`$meo.MEO.ValidateOptions<,,,,,>`, (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt(`$meo.MEO.ValidateOptions<,,,,,>`, [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class ValidateOptions$$$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38657523799)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657523799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38657523799)
            
            //--TRIMMABLE-BOUNDARY-START(137441771607)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(137441771607)
            
            //--TRIMMABLE-BOUNDARY-START(146031706199)
            /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(146031706199)
            
            //--TRIMMABLE-BOUNDARY-START(64427327575)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(64427327575)
            
            //--TRIMMABLE-BOUNDARY-START(42952491095)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(42952491095)
            
            //--TRIMMABLE-BOUNDARY-START(47247458391)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(47247458391)
            
            //--TRIMMABLE-BOUNDARY-START(51542425687)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(51542425687)
            
            //--TRIMMABLE-BOUNDARY-START(55837392983)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(55837392983)
            
            //--TRIMMABLE-BOUNDARY-START(60132360279)
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            //--TRIMMABLE-BOUNDARY-END(60132360279)
            
            //--TRIMMABLE-BOUNDARY-START(141736738903)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736738903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Name === null || name === this.Name)
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5))
                    {
                        return $.$meo.MEO.ValidateOptionsResult.Success;
                    }
                    return $.$meo.MEO.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.MEO.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(141736738903)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            [`MEO$IValidateOptions$${TOptions.$getFullName('$')}$Validate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $H = 2818135;
            static $h = 2818135;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137441771607),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124556869719,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 137441771607,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441771607),
//--TRIMMABLE-BOUNDARY-START(146031706199),
    {
      "p": $.$$.S.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133146804311,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "H": 146031706199,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146031706199),
//--TRIMMABLE-BOUNDARY-START(64427327575),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115966935127,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "H": 64427327575,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427327575),
//--TRIMMABLE-BOUNDARY-START(42952491095),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73017262167,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 42952491095,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952491095),
//--TRIMMABLE-BOUNDARY-START(47247458391),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81607196759,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 47247458391,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247458391),
//--TRIMMABLE-BOUNDARY-START(51542425687),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90197131351,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 51542425687,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542425687),
//--TRIMMABLE-BOUNDARY-START(55837392983),
    {
      "p": TDep4?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98787065943,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "H": 55837392983,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837392983),
//--TRIMMABLE-BOUNDARY-START(60132360279),
    {
      "p": TDep5?.$h??1900544,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107377000535,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "n": "Dependency5",
      "d": this.$h,
      "H": 60132360279,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132360279)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141736738903),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "H": 141736738903,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141736738903)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38657523799),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1835008
        },
        {
          "n": "dependency5",
          "p": TDep5?.$h??1900544
        },
        {
          "n": "validation",
          "p": $.$$.S.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.S.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 38657523799,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657523799)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1"
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2"
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3"
    },
    {
      "h": TDep4?.$h??1835008,
      "n": "TDep4"
    },
    {
      "h": TDep5?.$h??1900544,
      "n": "TDep5"
    }
  ],
  "r": 6,
  "H": 2818135,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IValidateOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$${TDep4?.$getFullName(separator)}$${TDep5?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2818135)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704023)
        $asm.$cls(`$meo.MEO.OptionsMonitor<>`, (TOptions) => $asm.$gt(`$meo.MEO.OptionsMonitor<>`, [TOptions], ($self) => class OptionsMonitor$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296671319)
            /*IOptionsMonitorCache<TOptions>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4296671319)
            
            //--TRIMMABLE-BOUNDARY-START(8591638615)
            /*IOptionsFactory<TOptions>*/ _factory = null;
            //--TRIMMABLE-BOUNDARY-END(8591638615)
            
            //--TRIMMABLE-BOUNDARY-START(17181573207)
            /*List<IDisposable>*/ _registrations = null;
            //--TRIMMABLE-BOUNDARY-END(17181573207)
            
            //--TRIMMABLE-BOUNDARY-START(12886605911)
            /*Action<TOptions, string>?*/ _onChange = null;
            //--TRIMMABLE-BOUNDARY-END(12886605911)
            
            //--TRIMMABLE-BOUNDARY-START(12886605911)
            //--TRIMMABLE-BOUNDARY-START(30066475095)
            add__onChange(/*Action<TOptions, string>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066475095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._onChange = $.$$.S.Delegate.Combine$2(this._onChange, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30066475095)
            
            //--TRIMMABLE-BOUNDARY-START(68721180759)
            remove__onChange(/*Action<TOptions, string>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721180759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._onChange = $.$$.S.Delegate.Remove(this._onChange, value);
            }
            //--TRIMMABLE-BOUNDARY-END(68721180759)
            
            //--TRIMMABLE-BOUNDARY-END(12886605911)
            
            //--TRIMMABLE-BOUNDARY-START(21476540503)
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory, /*IEnumerable<IOptionsChangeTokenSource<TOptions>>*/ sources, /*IOptionsMonitorCache<TOptions>*/ cache)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476540503);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._factory = factory;
                    this._cache = cache;
                    /*void*/  function RegisterSource(/*IOptionsChangeTokenSource<TOptions>*/ source)
                    {
                        /*IDisposable*/ let registration = $.$mep.MEP.ChangeToken.OnChange$1($.$$.S.String, new ($.$$.S.Func$$($.$mep.MEP.IChangeToken))().$ctor(source, source.MEO$IOptionsChangeTokenSource$$$GetChangeToken), new ($.$$.S.Action$$($.$$.S.String))().$ctor(this, this.InvokeChanged), source.MEO$IOptionsChangeTokenSource$$$Name);
                        this._registrations.Add(registration);
                    }
                    let sourcesArray;
                    if ($.$is(sources, $.$typeArray($.$meo.MEO.IOptionsChangeTokenSource$$(TOptions)), { set $v($v){ sourcesArray = $v; } }))
                    {
                        let $i1 = 0;
                        let $arr1 = sourcesArray;
                        while ($i1 < $arr1.length)
                        {
                            let source = $arr1[$i1++];
                            RegisterSource.call(this, source);
                        }
                    }
                    else 
                    {
                        let $en2 = sources.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let source = $en2.SCG$IEnumerator$$$Current;
                            {
                                RegisterSource.call(this, source);
                            }
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476540503)
            
            //--TRIMMABLE-BOUNDARY-START(55836278871)
            /*void */ InvokeChanged(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836278871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                name ??= $.$meo.MEO.Options.DefaultName;
                this._cache.MEO$IOptionsMonitorCache$$$TryRemove(name);
                /*TOptions*/ let options = this.Get(name);
                this._onChange?.Invoke(options, name);
            }
            //--TRIMMABLE-BOUNDARY-END(55836278871)
            
            //--TRIMMABLE-BOUNDARY-START(34361442391)
            /*TOptions */ get CurrentValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246344279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get($.$meo.MEO.Options.DefaultName);
            }
            //--TRIMMABLE-BOUNDARY-END(34361442391)
            
            //--TRIMMABLE-BOUNDARY-START(51541311575)
            /*TOptions */ Get(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541311575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let optionsCache;
                if (!$.$is(this._cache, $.$meo.MEO.OptionsCache$$(TOptions), { set $v($v){ optionsCache = $v; } }))
                {
                    /*string*/ let localName = name ?? $.$meo.MEO.Options.DefaultName;
                    /*IOptionsFactory<TOptions>*/ let localFactory = this._factory;
                    return this._cache.MEO$IOptionsMonitorCache$$$GetOrAdd(localName, new ($.$$.S.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localFactory[`MEO$IOptionsFactory$${TOptions.$getFullName('$')}$Create`](localName);
                    }, $kJShPa ??= {"r":TOptions?.$h??1572864,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                return optionsCache.GetOrAdd$1($.$meo.MEO.IOptionsFactory$$(TOptions), name, new ($.$$.S.Func$$$$($.$$.S.String, $.$meo.MEO.IOptionsFactory$$(TOptions), TOptions))().$ctor($.$meo.MEO.OptionsMonitor$$(TOptions), /*static*/ (/*name*/ name, /*factory*/ factory) =>
                {
                    return factory[`MEO$IOptionsFactory$${TOptions.$getFullName('$')}$Create`](name);
                }, $Uzrvlg ??= {"r":TOptions?.$h??1572864,"p":[{"n":"name","p":1310721},{"n":"factory","p":$.$meo.MEO.IOptionsFactory$$(TOptions).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826}), this._factory);
            }
            //--TRIMMABLE-BOUNDARY-END(51541311575)
            
            //--TRIMMABLE-BOUNDARY-START(60131246167)
            /*IDisposable */ OnChange(/*Action<TOptions, string>*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131246167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let disposable = new ($.$meo.MEO.OptionsMonitor$$(TOptions).ChangeTrackerDisposable)().$ctor$1(this, listener);
                this.add__onChange(new ($.$$.S.Action$$$(TOptions, $.$$.S.String))().$ctor(disposable, disposable.OnChange));
                return disposable;
            }
            //--TRIMMABLE-BOUNDARY-END(60131246167)
            
            //--TRIMMABLE-BOUNDARY-START(38656409687)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656409687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en3 = this._registrations.GetEnumerator();
                while ($en3.MoveNext())
                {
                    let registration = $en3.Current;
                    {
                        registration.S$IDisposable$Dispose();
                    }
                }
                this._registrations.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(38656409687)
            
            //--TRIMMABLE-BOUNDARY-START(1769559)
            static $_ChangeTrackerDisposable;
            static get ChangeTrackerDisposable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1769559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$meo.MEO.OptionsMonitor$$(TOptions);
                return $cls.$_ChangeTrackerDisposable ??= $asm.$ncls(`$meo.MEO.OptionsMonitor<${TOptions?.$fullName}>.ChangeTrackerDisposable`, ($self) => class ChangeTrackerDisposable extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296736855)
                    /*Action<TOptions, string>*/ _listener = null;
                    //--TRIMMABLE-BOUNDARY-END(4296736855)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591704151)
                    /*OptionsMonitor<TOptions>*/ _monitor = null;
                    //--TRIMMABLE-BOUNDARY-END(8591704151)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886671447)
                    $ctor$1(/*OptionsMonitor<TOptions>*/ monitor, /*Action<TOptions, string>*/ listener)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886671447);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._listener = listener;
                            this._monitor = monitor;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886671447)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476606039)
                    /*void */ OnChange(/*TOptions*/ options, /*string*/ name)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476606039);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._listener.Invoke(options, name);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476606039)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181638743)
                    /*void */ Dispose()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181638743);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._monitor.remove__onChange(new ($.$$.S.Action$$$(TOptions, $.$$.S.String))().$ctor(this, this.OnChange));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181638743)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $H = 1769559;
                    static $h = 1769559;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476606039),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "OnChange",
      "d": 1769559,
      "H": 21476606039,
      "h": Number(BigInt(1769559)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476606039),
//--TRIMMABLE-BOUNDARY-START(17181638743),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1769559,
      "H": 17181638743,
      "h": Number(BigInt(1769559)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181638743)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736855),
    {
      "t": $.$$.S.Action$$$(TOptions, $.$$.S.String).$h,
      "n": "_listener",
      "d": 1769559,
      "H": 4296736855,
      "h": Number(BigInt(1769559)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736855),
//--TRIMMABLE-BOUNDARY-START(8591704151),
    {
      "t": 1704023,
      "n": "_monitor",
      "d": 1769559,
      "H": 8591704151,
      "h": Number(BigInt(1769559)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704151)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886671447),
    {
      "p": [
        {
          "n": "monitor",
          "p": 1704023
        },
        {
          "n": "listener",
          "p": $.$$.S.Action$$$(TOptions, $.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769559,
      "H": 12886671447,
      "h": Number(BigInt(1769559)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671447)
  ],
  "d": 1704023,
  "H": 1769559,
  "h": 1769559
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsMonitor<${TOptions?.$fullName}>+ChangeTrackerDisposable`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsMonitor$${TOptions?.$getFullName(separator)}$${separator}ChangeTrackerDisposable`; }
                }, $cls, ($v) => $cls.$_ChangeTrackerDisposable = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1769559)
            
            //--TRIMMABLE-BOUNDARY-START(12885885015)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.CurrentValue.get
            get [`MEO$IOptionsMonitor$${TOptions.$getFullName('$')}$CurrentValue`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentValue;
            }
            //--TRIMMABLE-BOUNDARY-END(12885885015)
            
            //--TRIMMABLE-BOUNDARY-START(17180852311)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.Get(string?)
            [`MEO$IOptionsMonitor$${TOptions.$getFullName('$')}$Get`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180852311)
            
            //--TRIMMABLE-BOUNDARY-START(21475819607)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.OnChange(System.Action<TOptions, string?>)
            [`MEO$IOptionsMonitor$${TOptions.$getFullName('$')}$OnChange`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnChange(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819607)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17181573207)
                this._registrations = new ($.$$.SCG.List$$($.$$.S.IDisposable))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17181573207)
                
            }
            static $H = 1704023;
            static $h = 1704023;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361442391),
    {
      "p": TOptions?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246344279,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "CurrentValue",
      "d": this.$h,
      "H": 34361442391,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361442391)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836278871),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "InvokeChanged",
      "d": this.$h,
      "H": 55836278871,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836278871),
//--TRIMMABLE-BOUNDARY-START(51541311575),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": this.$h,
      "H": 51541311575,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51541311575),
//--TRIMMABLE-BOUNDARY-START(60131246167),
    {
      "r": 91095041,
      "p": [
        {
          "n": "listener",
          "p": $.$$.S.Action$$$(TOptions, $.$$.S.String).$h
        }
      ],
      "n": "OnChange",
      "d": this.$h,
      "H": 60131246167,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131246167),
//--TRIMMABLE-BOUNDARY-START(38656409687),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 38656409687,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656409687)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296671319),
    {
      "t": $.$meo.MEO.IOptionsMonitorCache$$(TOptions).$h,
      "n": "_cache",
      "d": this.$h,
      "H": 4296671319,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671319),
//--TRIMMABLE-BOUNDARY-START(8591638615),
    {
      "t": $.$meo.MEO.IOptionsFactory$$(TOptions).$h,
      "n": "_factory",
      "d": this.$h,
      "H": 8591638615,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638615),
//--TRIMMABLE-BOUNDARY-START(17181573207),
    {
      "t": $.$$.SCG.List$$($.$$.S.IDisposable).$h,
      "n": "_registrations",
      "d": this.$h,
      "H": 17181573207,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181573207)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476540503),
    {
      "p": [
        {
          "n": "factory",
          "p": $.$meo.MEO.IOptionsFactory$$(TOptions).$h
        },
        {
          "n": "sources",
          "p": $.$$.SCG.IEnumerable$$($.$meo.MEO.IOptionsChangeTokenSource$$(TOptions)).$h
        },
        {
          "n": "cache",
          "p": $.$meo.MEO.IOptionsMonitorCache$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 21476540503,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476540503)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(12886605911),
    {
      "e": $.$$.S.Action$$$(TOptions, $.$$.S.String).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.Action$$$(TOptions, $.$$.S.String).$h
          }
        ],
        "n": "add__onChange",
        "d": this.$h,
        "H": 30066475095,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 150994952
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.Action$$$(TOptions, $.$$.S.String).$h
          }
        ],
        "n": "remove__onChange",
        "d": this.$h,
        "H": 68721180759,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 285212680
      },
      "n": "_onChange",
      "d": this.$h,
      "H": 12886605911,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 8388616
    },
//--TRIMMABLE-BOUNDARY-END(12886605911)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 1704023,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptionsMonitor$$(TOptions), $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$meo.MEO.OptionsMonitor$$(TOptions).ChangeTrackerDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsMonitor<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsMonitor$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1704023)
        
        

        //--TRIMMABLE-BOUNDARY-START(524375)
        $asm.$cls(`$meo.MEO.ConfigureNamedOptions<>`, (TOptions) => $asm.$gt(`$meo.MEO.ConfigureNamedOptions<>`, [TOptions], ($self) => class ConfigureNamedOptions$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885426263)
            $ctor$1(/*string?*/ name, /*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426263);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426263)
            
            //--TRIMMABLE-BOUNDARY-START(47245164631)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(47245164631)
            
            //--TRIMMABLE-BOUNDARY-START(17180393559)
            /*Action<TOptions>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(17180393559)
            
            //--TRIMMABLE-BOUNDARY-START(21475360855)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360855)
            
            //--TRIMMABLE-BOUNDARY-START(25770328151)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770328151)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            [`MEO$IConfigureNamedOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            [`MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $H = 524375;
            static $h = 524375;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245164631),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950197335,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 47245164631,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245164631),
//--TRIMMABLE-BOUNDARY-START(17180393559),
    {
      "p": $.$$.S.Action$$(TOptions).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360262743,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 17180393559,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180393559)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475360855),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "H": 21475360855,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475360855),
//--TRIMMABLE-BOUNDARY-START(25770328151),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "H": 25770328151,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328151)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426263),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12885426263,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426263)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 524375,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureNamedOptions$$(TOptions), $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigureNamedOptions$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(524375)
        
        

        //--TRIMMABLE-BOUNDARY-START(458839)
        $asm.$cls(`$meo.MEO.ConfigureNamedOptions<,>`, (TOptions, TDep) => $asm.$gt(`$meo.MEO.ConfigureNamedOptions<,>`, [TOptions, TDep], ($self) => class ConfigureNamedOptions$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180328023)
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Action<TOptions, TDep>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180328023);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency = dependency;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328023)
            
            //--TRIMMABLE-BOUNDARY-START(64424968279)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(64424968279)
            
            //--TRIMMABLE-BOUNDARY-START(21475295319)
            /*Action<TOptions, TDep>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(21475295319)
            
            //--TRIMMABLE-BOUNDARY-START(34360197207)
            /*TDep*/ Dependency = $.$default(TDep);
            //--TRIMMABLE-BOUNDARY-END(34360197207)
            
            //--TRIMMABLE-BOUNDARY-START(25770262615)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770262615)
            
            //--TRIMMABLE-BOUNDARY-START(30065229911)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065229911);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065229911)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            [`MEO$IConfigureNamedOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            [`MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $H = 458839;
            static $h = 458839;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424968279),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60130000983,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 64424968279,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424968279),
//--TRIMMABLE-BOUNDARY-START(21475295319),
    {
      "p": $.$$.S.Action$$$(TOptions, TDep).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950131799,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 21475295319,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475295319),
//--TRIMMABLE-BOUNDARY-START(34360197207),
    {
      "p": TDep?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540066391,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Dependency",
      "d": this.$h,
      "H": 34360197207,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360197207)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770262615),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "H": 25770262615,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770262615),
//--TRIMMABLE-BOUNDARY-START(30065229911),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "H": 30065229911,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229911)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180328023),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep?.$h??1638400
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$(TOptions, TDep).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17180328023,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180328023)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep?.$h??1638400,
      "n": "TDep",
      "f": 1
    }
  ],
  "r": 2,
  "H": 458839,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureNamedOptions$$(TOptions), $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigureNamedOptions$${TOptions?.$getFullName(separator)}$${TDep?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458839)
        
        

        //--TRIMMABLE-BOUNDARY-START(393303)
        $asm.$cls(`$meo.MEO.ConfigureNamedOptions<,,>`, (TOptions, TDep1, TDep2) => $asm.$gt(`$meo.MEO.ConfigureNamedOptions<,,>`, [TOptions, TDep1, TDep2], ($self) => class ConfigureNamedOptions$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475229783)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*Action<TOptions, TDep1, TDep2>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229783)
            
            //--TRIMMABLE-BOUNDARY-START(81604771927)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(81604771927)
            
            //--TRIMMABLE-BOUNDARY-START(25770197079)
            /*Action<TOptions, TDep1, TDep2>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(25770197079)
            
            //--TRIMMABLE-BOUNDARY-START(38655098967)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(38655098967)
            
            //--TRIMMABLE-BOUNDARY-START(42950066263)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(42950066263)
            
            //--TRIMMABLE-BOUNDARY-START(30065164375)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164375)
            
            //--TRIMMABLE-BOUNDARY-START(34360131671)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360131671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360131671)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            [`MEO$IConfigureNamedOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            [`MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $H = 393303;
            static $h = 393303;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604771927),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77309804631,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 81604771927,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604771927),
//--TRIMMABLE-BOUNDARY-START(25770197079),
    {
      "p": $.$$.S.Action$$$$(TOptions, TDep1, TDep2).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540000855,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 25770197079,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770197079),
//--TRIMMABLE-BOUNDARY-START(38655098967),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60129935447,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 38655098967,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655098967),
//--TRIMMABLE-BOUNDARY-START(42950066263),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68719870039,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 42950066263,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950066263)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065164375),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "H": 30065164375,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30065164375),
//--TRIMMABLE-BOUNDARY-START(34360131671),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "H": 34360131671,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360131671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475229783),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$$(TOptions, TDep1, TDep2).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 21475229783,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475229783)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1",
      "f": 1
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2",
      "f": 1
    }
  ],
  "r": 3,
  "H": 393303,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureNamedOptions$$(TOptions), $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigureNamedOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393303)
        
        

        //--TRIMMABLE-BOUNDARY-START(327767)
        $asm.$cls(`$meo.MEO.ConfigureNamedOptions<,,,>`, (TOptions, TDep1, TDep2, TDep3) => $asm.$gt(`$meo.MEO.ConfigureNamedOptions<,,,>`, [TOptions, TDep1, TDep2, TDep3], ($self) => class ConfigureNamedOptions$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770131543)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Action<TOptions, TDep1, TDep2, TDep3>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131543);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131543)
            
            //--TRIMMABLE-BOUNDARY-START(98784575575)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(98784575575)
            
            //--TRIMMABLE-BOUNDARY-START(30065098839)
            /*Action<TOptions, TDep1, TDep2, TDep3>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(30065098839)
            
            //--TRIMMABLE-BOUNDARY-START(42950000727)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(42950000727)
            
            //--TRIMMABLE-BOUNDARY-START(47244968023)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(47244968023)
            
            //--TRIMMABLE-BOUNDARY-START(51539935319)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(51539935319)
            
            //--TRIMMABLE-BOUNDARY-START(34360066135)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360066135)
            
            //--TRIMMABLE-BOUNDARY-START(38655033431)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655033431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655033431)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            [`MEO$IConfigureNamedOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            [`MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $H = 327767;
            static $h = 327767;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784575575),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94489608279,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 98784575575,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784575575),
//--TRIMMABLE-BOUNDARY-START(30065098839),
    {
      "p": $.$$.S.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60129869911,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 30065098839,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065098839),
//--TRIMMABLE-BOUNDARY-START(42950000727),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68719804503,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 42950000727,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950000727),
//--TRIMMABLE-BOUNDARY-START(47244968023),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77309739095,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 47244968023,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244968023),
//--TRIMMABLE-BOUNDARY-START(51539935319),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85899673687,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 51539935319,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539935319)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360066135),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "H": 34360066135,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34360066135),
//--TRIMMABLE-BOUNDARY-START(38655033431),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "H": 38655033431,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033431)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770131543),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 25770131543,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131543)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1",
      "f": 1
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2",
      "f": 1
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3",
      "f": 1
    }
  ],
  "r": 4,
  "H": 327767,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureNamedOptions$$(TOptions), $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigureNamedOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327767)
        
        

        //--TRIMMABLE-BOUNDARY-START(262231)
        $asm.$cls(`$meo.MEO.ConfigureNamedOptions<,,,,>`, (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt(`$meo.MEO.ConfigureNamedOptions<,,,,>`, [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class ConfigureNamedOptions$$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065033303)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065033303);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065033303)
            
            //--TRIMMABLE-BOUNDARY-START(115964379223)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(115964379223)
            
            //--TRIMMABLE-BOUNDARY-START(34360000599)
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(34360000599)
            
            //--TRIMMABLE-BOUNDARY-START(47244902487)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(47244902487)
            
            //--TRIMMABLE-BOUNDARY-START(51539869783)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(51539869783)
            
            //--TRIMMABLE-BOUNDARY-START(55834837079)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(55834837079)
            
            //--TRIMMABLE-BOUNDARY-START(60129804375)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(60129804375)
            
            //--TRIMMABLE-BOUNDARY-START(38654967895)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654967895)
            
            //--TRIMMABLE-BOUNDARY-START(42949935191)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949935191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949935191)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            [`MEO$IConfigureNamedOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            [`MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $H = 262231;
            static $h = 262231;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964379223),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111669411927,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 115964379223,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964379223),
//--TRIMMABLE-BOUNDARY-START(34360000599),
    {
      "p": $.$$.S.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68719738967,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 34360000599,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000599),
//--TRIMMABLE-BOUNDARY-START(47244902487),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77309673559,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 47244902487,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244902487),
//--TRIMMABLE-BOUNDARY-START(51539869783),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85899608151,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 51539869783,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539869783),
//--TRIMMABLE-BOUNDARY-START(55834837079),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94489542743,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 55834837079,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837079),
//--TRIMMABLE-BOUNDARY-START(60129804375),
    {
      "p": TDep4?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103079477335,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "H": 60129804375,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129804375)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654967895),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "H": 38654967895,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38654967895),
//--TRIMMABLE-BOUNDARY-START(42949935191),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "H": 42949935191,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935191)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065033303),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1835008
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 30065033303,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033303)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1",
      "f": 1
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2",
      "f": 1
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3",
      "f": 1
    },
    {
      "h": TDep4?.$h??1835008,
      "n": "TDep4",
      "f": 1
    }
  ],
  "r": 5,
  "H": 262231,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureNamedOptions$$(TOptions), $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigureNamedOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$${TDep4?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262231)
        
        

        //--TRIMMABLE-BOUNDARY-START(196695)
        $asm.$cls(`$meo.MEO.ConfigureNamedOptions<,,,,,>`, (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt(`$meo.MEO.ConfigureNamedOptions<,,,,,>`, [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class ConfigureNamedOptions$$$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34359935063)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359935063);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935063)
            
            //--TRIMMABLE-BOUNDARY-START(133144182871)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(133144182871)
            
            //--TRIMMABLE-BOUNDARY-START(38654902359)
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(38654902359)
            
            //--TRIMMABLE-BOUNDARY-START(51539804247)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(51539804247)
            
            //--TRIMMABLE-BOUNDARY-START(55834771543)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(55834771543)
            
            //--TRIMMABLE-BOUNDARY-START(60129738839)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(60129738839)
            
            //--TRIMMABLE-BOUNDARY-START(64424706135)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(64424706135)
            
            //--TRIMMABLE-BOUNDARY-START(68719673431)
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            //--TRIMMABLE-BOUNDARY-END(68719673431)
            
            //--TRIMMABLE-BOUNDARY-START(42949869655)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if (this.Name === null || name === this.Name)
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949869655)
            
            //--TRIMMABLE-BOUNDARY-START(47244836951)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244836951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.MEO.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244836951)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            [`MEO$IConfigureNamedOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            [`MEO$IConfigureOptions$${TOptions.$getFullName('$')}$Configure`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $H = 196695;
            static $h = 196695;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144182871),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128849215575,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "H": 133144182871,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144182871),
//--TRIMMABLE-BOUNDARY-START(38654902359),
    {
      "p": $.$$.S.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77309608023,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "H": 38654902359,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654902359),
//--TRIMMABLE-BOUNDARY-START(51539804247),
    {
      "p": TDep1?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85899542615,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "H": 51539804247,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539804247),
//--TRIMMABLE-BOUNDARY-START(55834771543),
    {
      "p": TDep2?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94489477207,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "H": 55834771543,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834771543),
//--TRIMMABLE-BOUNDARY-START(60129738839),
    {
      "p": TDep3?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103079411799,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "H": 60129738839,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129738839),
//--TRIMMABLE-BOUNDARY-START(64424706135),
    {
      "p": TDep4?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111669346391,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "H": 64424706135,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424706135),
//--TRIMMABLE-BOUNDARY-START(68719673431),
    {
      "p": TDep5?.$h??1900544,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120259280983,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "n": "Dependency5",
      "d": this.$h,
      "H": 68719673431,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719673431)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949869655),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "H": 42949869655,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42949869655),
//--TRIMMABLE-BOUNDARY-START(47244836951),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1572864
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "H": 47244836951,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244836951)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34359935063),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1638400
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1703936
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1769472
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1835008
        },
        {
          "n": "dependency5",
          "p": TDep5?.$h??1900544
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 34359935063,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359935063)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    },
    {
      "h": TDep1?.$h??1638400,
      "n": "TDep1",
      "f": 1
    },
    {
      "h": TDep2?.$h??1703936,
      "n": "TDep2",
      "f": 1
    },
    {
      "h": TDep3?.$h??1769472,
      "n": "TDep3",
      "f": 1
    },
    {
      "h": TDep4?.$h??1835008,
      "n": "TDep4",
      "f": 1
    },
    {
      "h": TDep5?.$h??1900544,
      "n": "TDep5",
      "f": 1
    }
  ],
  "r": 6,
  "H": 196695,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IConfigureNamedOptions$$(TOptions), $.$meo.MEO.IConfigureOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ConfigureNamedOptions$${TOptions?.$getFullName(separator)}$${TDep1?.$getFullName(separator)}$${TDep2?.$getFullName(separator)}$${TDep3?.$getFullName(separator)}$${TDep4?.$getFullName(separator)}$${TDep5?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196695)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638487)
        $asm.$cls(`$meo.MEO.OptionsManager<>`, (TOptions) => $asm.$gt(`$meo.MEO.OptionsManager<>`, [TOptions], ($self) => class OptionsManager$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591573079)
            /*IOptionsFactory<TOptions>*/ _factory = null;
            //--TRIMMABLE-BOUNDARY-END(8591573079)
            
            //--TRIMMABLE-BOUNDARY-START(4296605783)
            /*OptionsCache<TOptions>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4296605783)
            
            //--TRIMMABLE-BOUNDARY-START(12886540375)
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886540375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._factory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540375)
            
            //--TRIMMABLE-BOUNDARY-START(30066409559)
            /*TOptions */ get Value()
            {
                return this.Get($.$meo.MEO.Options.DefaultName);
            }
            //--TRIMMABLE-BOUNDARY-END(30066409559)
            
            //--TRIMMABLE-BOUNDARY-START(25771442263)
            /*TOptions */ Get(/*string?*/ name)
            {
                /*TOptions?*/ let options;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771442263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                name ??= $.$meo.MEO.Options.DefaultName;
                if (!this._cache.TryGetValue(name, $.$ref(() => options, ($v) => options = $v, TOptions)))
                {
                    /*IOptionsFactory<TOptions>*/ let localFactory = this._factory;
                    /*string*/ let localName = name;
                    options = this._cache.GetOrAdd(name, new ($.$$.S.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localFactory[`MEO$IOptionsFactory$${TOptions.$getFullName('$')}$Create`](localName);
                    }, $SRPfBc ??= {"r":TOptions?.$h??1572864,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(25771442263)
            
            //--TRIMMABLE-BOUNDARY-START(4296081495)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsSnapshot<TOptions>.Get(string?)
            [`MEO$IOptionsSnapshot$${TOptions.$getFullName('$')}$Get`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081495)
            
            //--TRIMMABLE-BOUNDARY-START(8590721111)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get [`MEO$IOptions$${TOptions.$getFullName('$')}$Value`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721111)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296605783)
                this._cache = new ($.$meo.MEO.OptionsCache$$(TOptions))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296605783)
                
            }
            static $H = 1638487;
            static $h = 1638487;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066409559),
    {
      "p": TOptions?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21476474967,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "H": 30066409559,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066409559)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771442263),
    {
      "r": TOptions?.$h??1572864,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": this.$h,
      "H": 25771442263,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771442263)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591573079),
    {
      "t": $.$meo.MEO.IOptionsFactory$$(TOptions).$h,
      "n": "_factory",
      "d": this.$h,
      "H": 8591573079,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591573079),
//--TRIMMABLE-BOUNDARY-START(4296605783),
    {
      "t": $.$meo.MEO.OptionsCache$$(TOptions).$h,
      "n": "_cache",
      "d": this.$h,
      "H": 4296605783,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605783)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886540375),
    {
      "p": [
        {
          "n": "factory",
          "p": $.$meo.MEO.IOptionsFactory$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12886540375,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540375)
  ],
  "s": [
    {
      "h": TOptions?.$h??1572864,
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "H": 1638487,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptionsSnapshot$$(TOptions), $.$meo.MEO.IOptions$$(TOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsManager<${TOptions?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsManager$${TOptions?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1638487)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966167)
        $asm.$cls(`$meo.MEO.OptionsValidatorAttribute`, ($self) => class OptionsValidatorAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296933463)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296933463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296933463)
            
            //--TRIMMABLE-BOUNDARY-START(4296933463)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296933463)
            
            static $h = 1966167;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933463),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966167,
      "h": 4296933463,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933463)
  ],
  "h": 1966167,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 12,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsValidatorAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsValidatorAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966167)
        
        

        //--TRIMMABLE-BOUNDARY-START(2752599)
        $asm.$cls(`$meo.MEO.ValidateObjectMembersAttribute`, ($self) => class ValidateObjectMembersAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592687191)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592687191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592687191)
            
            //--TRIMMABLE-BOUNDARY-START(12887654487)
            $ctor$3(/*Type*/ validator)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887654487);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Validator = validator;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887654487)
            
            //--TRIMMABLE-BOUNDARY-START(25772556375)
            /*Type?*/ Validator = null;
            //--TRIMMABLE-BOUNDARY-END(25772556375)
            
            //--TRIMMABLE-BOUNDARY-START(8592687191)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592687191)
            
            static $h = 2752599;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772556375),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477589079,
        "f": 50331649
      },
      "n": "Validator",
      "d": 2752599,
      "h": 25772556375,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772556375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592687191),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752599,
      "h": 8592687191,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592687191),
//--TRIMMABLE-BOUNDARY-START(12887654487),
    {
      "p": [
        {
          "n": "validator",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2752599,
      "h": 12887654487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887654487)
  ],
  "h": 2752599,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 384,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateObjectMembersAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateObjectMembersAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752599)
        
        

        //--TRIMMABLE-BOUNDARY-START(2687063)
        $asm.$cls(`$meo.MEO.ValidateEnumeratedItemsAttribute`, ($self) => class ValidateEnumeratedItemsAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592621655)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592621655);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592621655)
            
            //--TRIMMABLE-BOUNDARY-START(12887588951)
            $ctor$3(/*Type*/ validator)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887588951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Validator = validator;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887588951)
            
            //--TRIMMABLE-BOUNDARY-START(25772490839)
            /*Type?*/ Validator = null;
            //--TRIMMABLE-BOUNDARY-END(25772490839)
            
            //--TRIMMABLE-BOUNDARY-START(8592621655)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592621655)
            
            static $h = 2687063;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772490839),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477523543,
        "f": 50331649
      },
      "n": "Validator",
      "d": 2687063,
      "h": 25772490839,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772490839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592621655),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687063,
      "h": 8592621655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592621655),
//--TRIMMABLE-BOUNDARY-START(12887588951),
    {
      "p": [
        {
          "n": "validator",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2687063,
      "h": 12887588951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887588951)
  ],
  "h": 2687063,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 384,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.ValidateEnumeratedItemsAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}ValidateEnumeratedItemsAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687063)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900631)
        $asm.$cls(`$meo.MEO.OptionsValidationException`, ($self) => class OptionsValidationException extends $.$$.S.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(17181769815)
            $ctor$5(/*string*/ optionsName, /*Type*/ optionsType, /*IEnumerable<string>?*/ failureMessages)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181769815);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(optionsName, "optionsName");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(optionsType, "optionsType");
                    this.Failures = failureMessages ?? new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                    this.OptionsType = optionsType;
                    this.OptionsName = optionsName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181769815)
            
            //--TRIMMABLE-BOUNDARY-START(64426410071)
            /*string*/ OptionsName = null;
            //--TRIMMABLE-BOUNDARY-END(64426410071)
            
            //--TRIMMABLE-BOUNDARY-START(68721377367)
            /*Type*/ OptionsType = null;
            //--TRIMMABLE-BOUNDARY-END(68721377367)
            
            //--TRIMMABLE-BOUNDARY-START(21476737111)
            /*IEnumerable<string>*/ Failures = null;
            //--TRIMMABLE-BOUNDARY-END(21476737111)
            
            //--TRIMMABLE-BOUNDARY-START(60131442775)
            /*string */ get Message()
            {
                return $.$$.S.String.Join$5("; ", this.Failures);
            }
            //--TRIMMABLE-BOUNDARY-END(60131442775)
            
            static $h = 1900631;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Exception; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64426410071),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246540887,
        "f": 50331649
      },
      "n": "OptionsName",
      "d": 1900631,
      "h": 64426410071,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426410071),
//--TRIMMABLE-BOUNDARY-START(68721377367),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836475479,
        "f": 50331649
      },
      "n": "OptionsType",
      "d": 1900631,
      "h": 68721377367,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721377367),
//--TRIMMABLE-BOUNDARY-START(21476737111),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066671703,
        "f": 50331649
      },
      "n": "Failures",
      "d": 1900631,
      "h": 21476737111,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476737111),
//--TRIMMABLE-BOUNDARY-START(60131442775),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656606295,
        "f": 50364417
      },
      "n": "Message",
      "d": 1900631,
      "h": 60131442775,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60131442775)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181769815),
    {
      "p": [
        {
          "n": "optionsName",
          "p": 1310721
        },
        {
          "n": "optionsType",
          "p": 188547073
        },
        {
          "n": "failureMessages",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1900631,
      "h": 17181769815,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769815)
  ],
  "h": 1900631
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Options.OptionsValidationException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Options${separator}OptionsValidationException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900631)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations"));
})();
//--TRIMMABLE-BOUNDARY-END(87)
