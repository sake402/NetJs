
//--TRIMMABLE-BOUNDARY-START(87)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $mwp, $scn, $scp, $scs, $sdp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Options", 
    {
  "h": 87,
  "f": "Microsoft.Extensions.Options",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.Extensions.Options.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Options",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Options",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(720983)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IConfigureOptions<>", (/*in*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IConfigureOptions<>", [/*in*/ TOptions], ($self) => class IConfigureOptions$$
        {
            static $h = 720983;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295688279),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328,
          "f": 32
        }
      ],
      "n": "Configure",
      "o": "Microsoft$Extensions$Options$IConfigureOptions$$$Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295688279)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 17
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IConfigureOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(720983)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048663)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsMonitorCache<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsMonitorCache<>", [TOptions], ($self) => class IOptionsMonitorCache$$
        {
            static $h = 1048663;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983255),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "createOptions",
          "p": $.$$.System.Func$$(TOptions).$h
        }
      ],
      "n": "GetOrAdd",
      "o": "Microsoft$Extensions$Options$IOptionsMonitorCache$$$GetOrAdd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590983255),
//--TRIMMABLE-BOUNDARY-START(12885950551),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "TryAdd",
      "o": "Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryAdd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885950551),
//--TRIMMABLE-BOUNDARY-START(17180917847),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "TryRemove",
      "o": "Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryRemove",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180917847),
//--TRIMMABLE-BOUNDARY-START(4296015959),
    {
      "r": 65537,
      "n": "Clear",
      "o": "Microsoft$Extensions$Options$IOptionsMonitorCache$$$Clear",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296015959)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsMonitorCache<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1048663)
        
        
        //--TRIMMABLE-BOUNDARY-START(983127)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsMonitor<>", (/*out*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsMonitor<>", [/*out*/ TOptions], ($self) => class IOptionsMonitor$$
        {
            static $h = 983127;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295950423),
    {
      "p": TOptions?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50856193
      },
      "n": "CurrentValue",
      "o": "Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295950423)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180852311),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": "Microsoft$Extensions$Options$IOptionsMonitor$$$Get",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 17301761
    },
//--TRIMMABLE-BOUNDARY-END(17180852311),
//--TRIMMABLE-BOUNDARY-START(21475819607),
    {
      "r": 90308609,
      "p": [
        {
          "n": "listener",
          "p": $.$$.System.Action$$$(TOptions, $.$$.System.String).$h
        }
      ],
      "n": "OnChange",
      "o": "Microsoft$Extensions$Options$IOptionsMonitor$$$OnChange",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475819607)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 32
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsMonitor<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(983127)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245271)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IStartupValidator", ($self) => class IStartupValidator
        {
            static $h = 1245271;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296212567),
    {
      "r": 65537,
      "n": "Validate",
      "o": "Microsoft$Extensions$Options$IStartupValidator$Validate",
      "d": 1245271,
      "h": 4296212567,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296212567)
  ],
  "h": 1245271
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IStartupValidator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245271)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310807)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IValidateOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IValidateOptions<>", [TOptions], ($self) => class IValidateOptions$$
        {
            static $h = 1310807;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296278103),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Validate",
      "o": "Microsoft$Extensions$Options$IValidateOptions$$$Validate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296278103)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IValidateOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1310807)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179735)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IPostConfigureOptions<>", (/*in*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IPostConfigureOptions<>", [/*in*/ TOptions], ($self) => class IPostConfigureOptions$$
        {
            static $h = 1179735;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296147031),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328,
          "f": 32
        }
      ],
      "n": "PostConfigure",
      "o": "Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296147031)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 17
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IPostConfigureOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1179735)
        
        
        //--TRIMMABLE-BOUNDARY-START(852055)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource<>", (/*out*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource<>", [/*out*/ TOptions], ($self) => class IOptionsChangeTokenSource$$
        {
            static $h = 852055;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180721239),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50331905
      },
      "n": "Name",
      "o": "Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180721239)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753943),
    {
      "r": 720981,
      "n": "GetChangeToken",
      "o": "Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$GetChangeToken",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885753943)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 32
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsChangeTokenSource<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(852055)
        
        
        //--TRIMMABLE-BOUNDARY-START(917591)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsFactory<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsFactory<>", [TOptions], ($self) => class IOptionsFactory$$
        {
            static $h = 917591;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295884887),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Create",
      "o": "Microsoft$Extensions$Options$IOptionsFactory$$$Create",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295884887)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsFactory<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917591)
        
        
        //--TRIMMABLE-BOUNDARY-START(786519)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptions<>", (/*out*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptions<>", [/*out*/ TOptions], ($self) => class IOptions$$
        {
            static $h = 786519;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885688407),
    {
      "p": TOptions?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50856193
      },
      "n": "Value",
      "o": "Microsoft$Extensions$Options$IOptions$$$Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885688407)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 33
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(786519)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114199)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IOptionsSnapshot<>", (/*out*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IOptionsSnapshot<>", [/*out*/ TOptions], ($self) => class IOptionsSnapshot$$
        {
            static $h = 1114199;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296081495),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": "Microsoft$Extensions$Options$IOptionsSnapshot$$$Get",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 17301761
    },
//--TRIMMABLE-BOUNDARY-END(4296081495)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 33
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.IOptionsSnapshot<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1114199)
        
        
        //--TRIMMABLE-BOUNDARY-START(655447)
        $asm.$cls("$meo.Microsoft.Extensions.Options.IConfigureNamedOptions<>", (/*in*/ TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.IConfigureNamedOptions<>", [/*in*/ TOptions], ($self) => class IConfigureNamedOptions$$
        {
            static $h = 655447;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295622743),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328,
          "f": 32
        }
      ],
      "n": "Configure",
      "o": "Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295622743)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 17
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.IConfigureNamedOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(655447)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376343)
        $asm.$cls("$meo.Microsoft.Extensions.Options.Options", ($self) => class Options
        {
            //--TRIMMABLE-BOUNDARY-START(17181245527)
            /*DynamicallyAccessedMemberTypes*/ static DynamicallyAccessedMembers = 1;
            //--TRIMMABLE-BOUNDARY-END(17181245527)
            
            //--TRIMMABLE-BOUNDARY-START(12886278231)
            /*string*/ static DefaultName = null;
            //--TRIMMABLE-BOUNDARY-END(12886278231)
            
            //--TRIMMABLE-BOUNDARY-START(8591310935)
            static /*IOptions<TOptions> */ Create(TOptions, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$meo.Microsoft.Extensions.Options.OptionsWrapper$$(TOptions))().$ctor$1(options);
            }
            //--TRIMMABLE-BOUNDARY-END(8591310935)
            
            //--TRIMMABLE-BOUNDARY-START(4296343639)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12886278231)
                    this.DefaultName = $.$$.System.String.Empty;
                    //--TRIMMABLE-BOUNDARY-END(12886278231)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296343639)
            
            static $h = 1376343;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591310935),
    {
      "r": (TOptions) => $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h,
      "p": [
        {
          "n": "options",
          "p": (TOptions) => TOptions.$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Create",
      "d": 1376343,
      "h": 8591310935,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591310935)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181245527),
    {
      "n": "DynamicallyAccessedMembers",
      "d": 1376343,
      "h": 17181245527,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181245527),
//--TRIMMABLE-BOUNDARY-START(12886278231),
    {
      "t": 1310721,
      "n": "DefaultName",
      "d": 1376343,
      "h": 12886278231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278231)
  ],
  "h": 1376343
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.Options`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376343)
        
        
        //--TRIMMABLE-BOUNDARY-START(3342423)
        $asm.$cls("$meo.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(180391968855)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(180391968855)
            
            //--TRIMMABLE-BOUNDARY-START(171802034263)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(171802034263)
            
            //--TRIMMABLE-BOUNDARY-START(176097001559)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154622165079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$meo.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Options", $.$meo.System.SR.$type.Assembly);
                    $.$meo.System.SR.s_resourceManager = temp;
                }
                return $.$meo.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(176097001559)
            
            //--TRIMMABLE-BOUNDARY-START(8593277015)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492622935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meo.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276870743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8593277015)
            
            //--TRIMMABLE-BOUNDARY-START(12888244311)
            static /*string */ get Error_CannotActivateAbstractOrInterface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082557527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it is either abstract or an interface.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888244311)
            
            //--TRIMMABLE-BOUNDARY-START(73017786455)
            static /*string */ FormatError_CannotActivateAbstractOrInterface(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017786455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it is either abstract or an interface.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73017786455)
            
            //--TRIMMABLE-BOUNDARY-START(17183211607)
            static /*string */ get Error_FailedBinding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672492119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to convert '{0}' to type '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183211607)
            
            //--TRIMMABLE-BOUNDARY-START(77312753751)
            static /*string */ FormatError_FailedBinding(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312753751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Failed to convert '{0}' to type '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(77312753751)
            
            //--TRIMMABLE-BOUNDARY-START(21478178903)
            static /*string */ get Error_FailedToActivate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262426711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to create instance of type '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(21478178903)
            
            //--TRIMMABLE-BOUNDARY-START(81607721047)
            static /*string */ FormatError_FailedToActivate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607721047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Failed to create instance of type '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81607721047)
            
            //--TRIMMABLE-BOUNDARY-START(25773146199)
            static /*string */ get Error_MissingParameterlessConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852361303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it is missing a public parameterless constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(25773146199)
            
            //--TRIMMABLE-BOUNDARY-START(85902688343)
            static /*string */ FormatError_MissingParameterlessConstructor(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902688343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it is missing a public parameterless constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85902688343)
            
            //--TRIMMABLE-BOUNDARY-START(30068113495)
            static /*string */ get Error_NoConfigurationServices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442295895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No IConfigureOptions<>, IPostConfigureOptions<>, or IValidateOptions<> implementations were found.";
            }
            //--TRIMMABLE-BOUNDARY-END(30068113495)
            
            //--TRIMMABLE-BOUNDARY-START(34363080791)
            static /*string */ get Error_NoConfigurationServicesAndAction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032230487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No IConfigureOptions<>, IPostConfigureOptions<>, or IValidateOptions<> implementations were found, did you mean to call Configure<> or PostConfigure<>?";
            }
            //--TRIMMABLE-BOUNDARY-END(34363080791)
            
            //--TRIMMABLE-BOUNDARY-START(184686936151)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(184686936151)
            
            //--TRIMMABLE-BOUNDARY-START(167507066967)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167507066967);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167507066967)
            
            //--TRIMMABLE-BOUNDARY-START(197571838039)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197571838039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197571838039)
            
            //--TRIMMABLE-BOUNDARY-START(163212099671)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163212099671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$meo.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(163212099671)
            
            //--TRIMMABLE-BOUNDARY-START(158917132375)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158917132375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$meo.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(158917132375)
            
            //--TRIMMABLE-BOUNDARY-START(64427851863)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427851863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(64427851863)
            
            //--TRIMMABLE-BOUNDARY-START(60132884567)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132884567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(60132884567)
            
            //--TRIMMABLE-BOUNDARY-START(55837917271)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837917271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(55837917271)
            
            //--TRIMMABLE-BOUNDARY-START(68722819159)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722819159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$meo.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(68722819159)
            
            //--TRIMMABLE-BOUNDARY-START(47247982679)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247982679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(47247982679)
            
            //--TRIMMABLE-BOUNDARY-START(42953015383)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953015383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(42953015383)
            
            //--TRIMMABLE-BOUNDARY-START(38658048087)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658048087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meo.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(38658048087)
            
            //--TRIMMABLE-BOUNDARY-START(51542949975)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542949975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$meo.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(51542949975)
            
            //--TRIMMABLE-BOUNDARY-START(4298309719)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(184686936151)
                    this.s_usingResourceKeys = $.$meo.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(184686936151)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298309719)
            
            static $h = 3342423;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3342423
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342423)
        
        
        //--TRIMMABLE-BOUNDARY-START(131159)
        $asm.$cls("$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions", ($self) => class OptionsServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295098455)
            static /*IServiceCollection */ AddOptions(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2($.$meo.Microsoft.Extensions.Options.IOptions$$().$type, $.$meo.Microsoft.Extensions.Options.UnnamedOptionsManager$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$1($.$meo.Microsoft.Extensions.Options.IOptionsSnapshot$$().$type, $.$meo.Microsoft.Extensions.Options.OptionsManager$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2($.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$().$type, $.$meo.Microsoft.Extensions.Options.OptionsMonitor$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$1($.$meo.Microsoft.Extensions.Options.IOptionsFactory$$().$type, $.$meo.Microsoft.Extensions.Options.OptionsFactory$$().$type));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2($.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$().$type, $.$meo.Microsoft.Extensions.Options.OptionsCache$$().$type));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098455)
            
            //--TRIMMABLE-BOUNDARY-START(21474967639)
            static /*OptionsBuilder<TOptions> */ AddOptionsWithValidateOnStart$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions.ValidateOnStart(TOptions, new ($.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions))().$ctor$1(services, name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName));
            }
            //--TRIMMABLE-BOUNDARY-END(21474967639)
            
            //--TRIMMABLE-BOUNDARY-START(17180000343)
            static /*OptionsBuilder<TOptions> */ AddOptionsWithValidateOnStart(TOptions, TValidateOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable$1($.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$3($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), TValidateOptions));
                return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions.ValidateOnStart(TOptions, new ($.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions))().$ctor$1(services, name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName));
            }
            //--TRIMMABLE-BOUNDARY-END(17180000343)
            
            //--TRIMMABLE-BOUNDARY-START(25769934935)
            static /*IServiceCollection */ Configure(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769934935);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure$1(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName, configureOptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769934935)
            
            //--TRIMMABLE-BOUNDARY-START(30064902231)
            static /*IServiceCollection */ Configure$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*Action<TOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), services, new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$(TOptions))().$ctor$1(name, configureOptions));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902231)
            
            //--TRIMMABLE-BOUNDARY-START(34359869527)
            static /*IServiceCollection */ ConfigureAll(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359869527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure$1(TOptions, services, null, configureOptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359869527)
            
            //--TRIMMABLE-BOUNDARY-START(55834706007)
            static /*IServiceCollection */ PostConfigure(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834706007);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.PostConfigure$1(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName, configureOptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834706007)
            
            //--TRIMMABLE-BOUNDARY-START(60129673303)
            static /*IServiceCollection */ PostConfigure$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name, /*Action<TOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), services, new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$(TOptions))().$ctor$1(name, configureOptions));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673303)
            
            //--TRIMMABLE-BOUNDARY-START(64424640599)
            static /*IServiceCollection */ PostConfigureAll(TOptions, /*this IServiceCollection*/ services, /*Action<TOptions>*/ configureOptions)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424640599);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.PostConfigure$1(TOptions, services, null, configureOptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424640599)
            
            //--TRIMMABLE-BOUNDARY-START(47244771415)
            static /*IServiceCollection */ ConfigureOptions$2(TConfigureOptions, /*this IServiceCollection*/ services)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244771415);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.ConfigureOptions$1(services, TConfigureOptions.$type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244771415)
            
            //--TRIMMABLE-BOUNDARY-START(51539738711)
            static /*IEnumerable<Type> */ FindConfigurationServices(/*Type*/ type)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    let $i1 = 0;
                    let $arr1 = GetInterfacesOnType(type);
                    while ($i1 < $arr1.length)
                    {
                        let t = $arr1[$i1++];
                        if (t.IsGenericType)
                        {
                            /*Type*/ let gtd = t.GetGenericTypeDefinition();
                            if ($.$$.System.Type.op_Equality$1(gtd, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$().$type) || $.$$.System.Type.op_Equality$1(gtd, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$().$type) || $.$$.System.Type.op_Equality$1(gtd, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$().$type))
                            {
                                yield t;
                            }
                        }
                    }
                    /*static Type[]*/  function GetInterfacesOnType(/*Type*/ t)
                    {
                        {
                            return t.GetInterfaces();
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(51539738711)
            
            //--TRIMMABLE-BOUNDARY-START(68719607895)
            static /*void */ ThrowNoConfigServices(/*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719607895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12(type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Action$$().$type) ? $.$meo.System.SR.Error_NoConfigurationServicesAndAction : $.$meo.System.SR.Error_NoConfigurationServices);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719607895)
            
            //--TRIMMABLE-BOUNDARY-START(42949804119)
            static /*IServiceCollection */ ConfigureOptions$1(/*this IServiceCollection*/ services, /*Type*/ configureType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                /*bool*/ let added = false;
                var $en2 = $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.FindConfigurationServices(configureType).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var serviceType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$1(services, serviceType, configureType);
                        added = true;
                    }
                }
                if (!added)
                {
                    $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.ThrowNoConfigServices(configureType);
                }
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804119)
            
            //--TRIMMABLE-BOUNDARY-START(38654836823)
            static /*IServiceCollection */ ConfigureOptions(/*this IServiceCollection*/ services, /*object*/ configureInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                /*Type*/ let configureType = $.$$.System.Object.GetType.call(configureInstance);
                /*bool*/ let added = false;
                var $en2 = $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.FindConfigurationServices(configureType).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var serviceType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$1(services, serviceType, configureInstance);
                        added = true;
                    }
                }
                if (!added)
                {
                    $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.ThrowNoConfigServices(configureType);
                }
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(38654836823)
            
            //--TRIMMABLE-BOUNDARY-START(12885033047)
            static /*OptionsBuilder<TOptions> */ AddOptions$2(TOptions, /*this IServiceCollection*/ services)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions$1(TOptions, services, $.$meo.Microsoft.Extensions.Options.Options.DefaultName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885033047)
            
            //--TRIMMABLE-BOUNDARY-START(8590065751)
            static /*OptionsBuilder<TOptions> */ AddOptions$1(TOptions, /*this IServiceCollection*/ services, /*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                return new ($.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions))().$ctor$1(services, name);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065751)
            
            static $h = 131159;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098455),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddOptions",
      "d": 131159,
      "h": 4295098455,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098455),
//--TRIMMABLE-BOUNDARY-START(21474967639),
    {
      "r": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721,
          "f": 65
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "AddOptionsWithValidateOnStart",
      "o": "@$1",
      "d": 131159,
      "h": 21474967639,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21474967639),
//--TRIMMABLE-BOUNDARY-START(17180000343),
    {
      "r": (TOptions, TValidateOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721,
          "f": 65
        }
      ],
      "g": [
        "TOptions",
        "TValidateOptions"
      ],
      "n": "AddOptionsWithValidateOnStart",
      "d": 131159,
      "h": 17180000343,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180000343),
//--TRIMMABLE-BOUNDARY-START(25769934935),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.System.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "d": 131159,
      "h": 25769934935,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25769934935),
//--TRIMMABLE-BOUNDARY-START(30064902231),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.System.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "Configure",
      "o": "@$1",
      "d": 131159,
      "h": 30064902231,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30064902231),
//--TRIMMABLE-BOUNDARY-START(34359869527),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.System.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "ConfigureAll",
      "d": 131159,
      "h": 34359869527,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34359869527),
//--TRIMMABLE-BOUNDARY-START(55834706007),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.System.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "PostConfigure",
      "d": 131159,
      "h": 55834706007,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(55834706007),
//--TRIMMABLE-BOUNDARY-START(60129673303),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.System.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": 131159,
      "h": 60129673303,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60129673303),
//--TRIMMABLE-BOUNDARY-START(64424640599),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": (TOptions) => $.$$.System.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "PostConfigureAll",
      "d": 131159,
      "h": 64424640599,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(64424640599),
//--TRIMMABLE-BOUNDARY-START(47244771415),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TConfigureOptions"
      ],
      "n": "ConfigureOptions",
      "o": "@$2",
      "d": 131159,
      "h": 47244771415,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47244771415),
//--TRIMMABLE-BOUNDARY-START(51539738711),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Type).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "FindConfigurationServices",
      "d": 131159,
      "h": 51539738711,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51539738711),
//--TRIMMABLE-BOUNDARY-START(68719607895),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "ThrowNoConfigServices",
      "d": 131159,
      "h": 68719607895,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719607895),
//--TRIMMABLE-BOUNDARY-START(42949804119),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureType",
          "p": 187760641
        }
      ],
      "n": "ConfigureOptions",
      "o": "@$1",
      "d": 131159,
      "h": 42949804119,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949804119),
//--TRIMMABLE-BOUNDARY-START(38654836823),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureInstance",
          "p": 131073
        }
      ],
      "n": "ConfigureOptions",
      "d": 131159,
      "h": 38654836823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654836823),
//--TRIMMABLE-BOUNDARY-START(12885033047),
    {
      "r": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "AddOptions",
      "o": "@$2",
      "d": 131159,
      "h": 12885033047,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885033047),
//--TRIMMABLE-BOUNDARY-START(8590065751),
    {
      "r": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "AddOptions",
      "o": "@$1",
      "d": 131159,
      "h": 8590065751,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590065751)
  ],
  "h": 131159
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131159)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835095)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsMonitorExtensions", ($self) => class OptionsMonitorExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296802391)
            static /*IDisposable? */ OnChange(TOptions, /*this IOptionsMonitor<TOptions>*/ monitor, /*Action<TOptions>*/ listener)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296802391);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return monitor.Microsoft$Extensions$Options$IOptionsMonitor$$$OnChange(new ($.$$.System.Action$$$(TOptions, $.$$.System.String))().$ctor(this,  (/**/ o, /*_*/ _1) =>
                    {
                        return listener.Invoke(o);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": (TOptions) => TOptions.$h
    },
    {
      "n": "_",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 1835095,
  "h": 0,
  "f": 17825794
}), [TOptions]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296802391)
            
            static $h = 1835095;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296802391),
    {
      "r": 90308609,
      "p": [
        {
          "n": "monitor",
          "p": (TOptions) => $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions).$h
        },
        {
          "n": "listener",
          "p": (TOptions) => $.$$.System.Action$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "OnChange",
      "d": 1835095,
      "h": 4296802391,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4296802391)
  ],
  "h": 1835095
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsMonitorExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835095)
        
        
        //--TRIMMABLE-BOUNDARY-START(65623)
        $asm.$cls("$meo.Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions", ($self) => class OptionsBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295032919)
            static /*OptionsBuilder<TOptions> */ ValidateOnStart(TOptions, /*this OptionsBuilder<TOptions>*/ optionsBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(optionsBuilder, "optionsBuilder");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$3($.$meo.Microsoft.Extensions.Options.IStartupValidator, $.$meo.Microsoft.Extensions.Options.StartupValidator, optionsBuilder.Services);
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions$2($.$meo.Microsoft.Extensions.Options.StartupValidatorOptions, optionsBuilder.Services).Configure$1($.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions), new ($.$$.System.Action$$$($.$meo.Microsoft.Extensions.Options.StartupValidatorOptions, $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions)))().$ctor(this,  (/*vo*/ vo, /*options*/ options) =>
                {
                    vo._validators.set_Item(new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String))().$ctor$3(TOptions.$type, optionsBuilder.Name), new $.$$.System.Action().$ctor(this,  () =>
                    {
                        return options.Microsoft$Extensions$Options$IOptionsMonitor$$$Get(optionsBuilder.Name, [TOptions]);
                    }, {
  "r": 65537,
  "n": "",
  "d": 65623,
  "h": 0,
  "f": 17825794
}));
                }, {
  "r": 65537,
  "p": [
    {
      "n": "vo",
      "p": 2555991
    },
    {
      "n": "options",
      "p": (TOptions) => $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions).$h
    }
  ],
  "n": "",
  "d": 65623,
  "h": 0,
  "f": 17825794
}));
                return optionsBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032919)
            
            static $h = 65623;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032919),
    {
      "r": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h,
      "p": [
        {
          "n": "optionsBuilder",
          "p": (TOptions) => $.$meo.Microsoft.Extensions.Options.OptionsBuilder$$(TOptions).$h
        }
      ],
      "g": [
        "TOptions"
      ],
      "n": "ValidateOnStart",
      "d": 65623,
      "h": 4295032919,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295032919)
  ],
  "h": 65623
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65623)
        
        
        //--TRIMMABLE-BOUNDARY-START(2555991)
        $asm.$cls("$meo.Microsoft.Extensions.Options.StartupValidatorOptions", ($self) => class StartupValidatorOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297523287)
            /*Dictionary<(Type, string), Action>*/ _validators = null;
            //--TRIMMABLE-BOUNDARY-END(4297523287)
            
            //--TRIMMABLE-BOUNDARY-START(12887457879)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887457879)
            
            //default member initializer
            constructor()
            {
                super();
                this._validators = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String), $.$$.System.Action))().$ctor$1();
            }
            static $h = 2555991;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(4297523287),
    {
      "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String), $.$$.System.Action).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477392471,
        "f": 50331649
      },
      "n": "_validators",
      "d": 2555991,
      "h": 4297523287,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(4297523287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887457879),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2555991,
      "h": 12887457879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887457879)
  ],
  "h": 2555991
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.StartupValidatorOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2555991)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441879)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsBuilder<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsBuilder<>", [TOptions], ($self) => class OptionsBuilder$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42951114839)
            /*string*/ static DefaultValidationFailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42951114839)
            
            //--TRIMMABLE-BOUNDARY-START(64425951319)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(64425951319)
            
            //--TRIMMABLE-BOUNDARY-START(94490722391)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(94490722391)
            
            //--TRIMMABLE-BOUNDARY-START(12886343767)
            $ctor$1(/*IServiceCollection*/ services, /*string?*/ name)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343767);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                    this.Services = services;
                    this.Name = name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343767)
            
            //--TRIMMABLE-BOUNDARY-START(17181311063)
            /*OptionsBuilder<TOptions> */ Configure(/*Action<TOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181311063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$(TOptions))().$ctor$1(this.Name, configureOptions));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311063)
            
            //--TRIMMABLE-BOUNDARY-START(21476278359)
            /*OptionsBuilder<TOptions> */ Configure$1(TDep, /*Action<TOptions, TDep>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476278359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278359)
            
            //--TRIMMABLE-BOUNDARY-START(38656147543)
            /*OptionsBuilder<TOptions> */ Configure$5(TDep1, TDep2, /*Action<TOptions, TDep1, TDep2>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/**/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656147543)
            
            //--TRIMMABLE-BOUNDARY-START(34361180247)
            /*OptionsBuilder<TOptions> */ Configure$4(TDep1, TDep2, TDep3, /*Action<TOptions, TDep1, TDep2, TDep3>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/**/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361180247)
            
            //--TRIMMABLE-BOUNDARY-START(30066212951)
            /*OptionsBuilder<TOptions> */ Configure$3(TDep1, TDep2, TDep3, TDep4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212951)
            
            //--TRIMMABLE-BOUNDARY-START(25771245655)
            /*OptionsBuilder<TOptions> */ Configure$2(TDep1, TDep2, TDep3, TDep4, TDep5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ConfigureNamedOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245655)
            
            //--TRIMMABLE-BOUNDARY-START(68720918615)
            /*OptionsBuilder<TOptions> */ PostConfigure(/*Action<TOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720918615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$(TOptions))().$ctor$1(this.Name, configureOptions));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720918615)
            
            //--TRIMMABLE-BOUNDARY-START(73015885911)
            /*OptionsBuilder<TOptions> */ PostConfigure$1(TDep, /*Action<TOptions, TDep>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015885911)
            
            //--TRIMMABLE-BOUNDARY-START(90195755095)
            /*OptionsBuilder<TOptions> */ PostConfigure$5(TDep1, TDep2, /*Action<TOptions, TDep1, TDep2>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195755095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90195755095)
            
            //--TRIMMABLE-BOUNDARY-START(85900787799)
            /*OptionsBuilder<TOptions> */ PostConfigure$4(TDep1, TDep2, TDep3, /*Action<TOptions, TDep1, TDep2, TDep3>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85900787799)
            
            //--TRIMMABLE-BOUNDARY-START(81605820503)
            /*OptionsBuilder<TOptions> */ PostConfigure$3(TDep1, TDep2, TDep3, TDep4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605820503)
            
            //--TRIMMABLE-BOUNDARY-START(77310853207)
            /*OptionsBuilder<TOptions> */ PostConfigure$2(TDep1, TDep2, TDep3, TDep4, TDep5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configureOptions, "configureOptions");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.PostConfigureOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), configureOptions);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310853207)
            
            //--TRIMMABLE-BOUNDARY-START(103080656983)
            /*OptionsBuilder<TOptions> */ Validate$1(/*Func<TOptions, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080656983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate(validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080656983)
            
            //--TRIMMABLE-BOUNDARY-START(98785689687)
            /*OptionsBuilder<TOptions> */ Validate(/*Func<TOptions, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$(TOptions))().$ctor$1(this.Name, validation, failureMessage));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(98785689687)
            
            //--TRIMMABLE-BOUNDARY-START(111670591575)
            /*OptionsBuilder<TOptions> */ Validate$3(TDep, /*Func<TOptions, TDep, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670591575);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$2(TDep, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670591575)
            
            //--TRIMMABLE-BOUNDARY-START(107375624279)
            /*OptionsBuilder<TOptions> */ Validate$2(TDep, /*Func<TOptions, TDep, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375624279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$(TOptions, TDep))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep, sp), validation, failureMessage);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(107375624279)
            
            //--TRIMMABLE-BOUNDARY-START(146030329943)
            /*OptionsBuilder<TOptions> */ Validate$11(TDep1, TDep2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030329943);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$10(TDep1, TDep2, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030329943)
            
            //--TRIMMABLE-BOUNDARY-START(141735362647)
            /*OptionsBuilder<TOptions> */ Validate$10(TDep1, TDep2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735362647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$$(TOptions, TDep1, TDep2))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), validation, failureMessage);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(141735362647)
            
            //--TRIMMABLE-BOUNDARY-START(137440395351)
            /*OptionsBuilder<TOptions> */ Validate$9(TDep1, TDep2, TDep3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440395351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$8(TDep1, TDep2, TDep3, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137440395351)
            
            //--TRIMMABLE-BOUNDARY-START(133145428055)
            /*OptionsBuilder<TOptions> */ Validate$8(TDep1, TDep2, TDep3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145428055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$$$(TOptions, TDep1, TDep2, TDep3))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), validation, failureMessage);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(133145428055)
            
            //--TRIMMABLE-BOUNDARY-START(128850460759)
            /*OptionsBuilder<TOptions> */ Validate$7(TDep1, TDep2, TDep3, TDep4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850460759);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$6(TDep1, TDep2, TDep3, TDep4, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850460759)
            
            //--TRIMMABLE-BOUNDARY-START(124555493463)
            /*OptionsBuilder<TOptions> */ Validate$6(TDep1, TDep2, TDep3, TDep4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555493463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), validation, failureMessage);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(124555493463)
            
            //--TRIMMABLE-BOUNDARY-START(120260526167)
            /*OptionsBuilder<TOptions> */ Validate$5(TDep1, TDep2, TDep3, TDep4, TDep5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260526167);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Validate$4(TDep1, TDep2, TDep3, TDep4, TDep5, validation, "A validation error has occurred."/*DefaultValidationFailureMessage*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260526167)
            
            //--TRIMMABLE-BOUNDARY-START(115965558871)
            /*OptionsBuilder<TOptions> */ Validate$4(TDep1, TDep2, TDep3, TDep4, TDep5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation, /*string*/ failureMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965558871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$5($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions), this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return new ($.$meo.Microsoft.Extensions.Options.ValidateOptions$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5))().$ctor$1(this.Name, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep1, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep2, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep3, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep4, sp), $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1(TDep5, sp), validation, failureMessage);
                }, {
  "r": $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115965558871)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(42951114839)
                    this.DefaultValidationFailureMessage = "A validation error has occurred.";
                    //--TRIMMABLE-BOUNDARY-END(42951114839)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1441879;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425951319),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425951319),
//--TRIMMABLE-BOUNDARY-START(94490722391),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Services",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490722391)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181311063),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": $.$$.System.Action$$(TOptions).$h
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181311063),
//--TRIMMABLE-BOUNDARY-START(21476278359),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep) => $.$$.System.Action$$$(TOptions, TDep).$h
        }
      ],
      "g": [
        "TDep"
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(21476278359),
//--TRIMMABLE-BOUNDARY-START(38656147543),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2) => $.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2"
      ],
      "n": "Configure",
      "o": "@$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(38656147543),
//--TRIMMABLE-BOUNDARY-START(34361180247),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3) => $.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3"
      ],
      "n": "Configure",
      "o": "@$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(34361180247),
//--TRIMMABLE-BOUNDARY-START(30066212951),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3, TDep4) => $.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4"
      ],
      "n": "Configure",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(30066212951),
//--TRIMMABLE-BOUNDARY-START(25771245655),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4",
        "TDep5"
      ],
      "n": "Configure",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(25771245655),
//--TRIMMABLE-BOUNDARY-START(68720918615),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": $.$$.System.Action$$(TOptions).$h
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720918615),
//--TRIMMABLE-BOUNDARY-START(73015885911),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep) => $.$$.System.Action$$$(TOptions, TDep).$h
        }
      ],
      "g": [
        "TDep"
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(73015885911),
//--TRIMMABLE-BOUNDARY-START(90195755095),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2) => $.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2"
      ],
      "n": "PostConfigure",
      "o": "@$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(90195755095),
//--TRIMMABLE-BOUNDARY-START(85900787799),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3) => $.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3"
      ],
      "n": "PostConfigure",
      "o": "@$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(85900787799),
//--TRIMMABLE-BOUNDARY-START(81605820503),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3, TDep4) => $.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4"
      ],
      "n": "PostConfigure",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(81605820503),
//--TRIMMABLE-BOUNDARY-START(77310853207),
    {
      "r": this.$h,
      "p": [
        {
          "n": "configureOptions",
          "p": (TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4",
        "TDep5"
      ],
      "n": "PostConfigure",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(77310853207),
//--TRIMMABLE-BOUNDARY-START(103080656983),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": $.$$.System.Func$$$(TOptions, $.$$.System.Boolean).$h
        }
      ],
      "n": "Validate",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103080656983),
//--TRIMMABLE-BOUNDARY-START(98785689687),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": $.$$.System.Func$$$(TOptions, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98785689687),
//--TRIMMABLE-BOUNDARY-START(111670591575),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep) => $.$$.System.Func$$$$(TOptions, TDep, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "TDep"
      ],
      "n": "Validate",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(111670591575),
//--TRIMMABLE-BOUNDARY-START(107375624279),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep) => $.$$.System.Func$$$$(TOptions, TDep, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep"
      ],
      "n": "Validate",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(107375624279),
//--TRIMMABLE-BOUNDARY-START(146030329943),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2) => $.$$.System.Func$$$$$(TOptions, TDep1, TDep2, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2"
      ],
      "n": "Validate",
      "o": "@$11",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(146030329943),
//--TRIMMABLE-BOUNDARY-START(141735362647),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2) => $.$$.System.Func$$$$$(TOptions, TDep1, TDep2, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep1",
        "TDep2"
      ],
      "n": "Validate",
      "o": "@$10",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(141735362647),
//--TRIMMABLE-BOUNDARY-START(137440395351),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3) => $.$$.System.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3"
      ],
      "n": "Validate",
      "o": "@$9",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(137440395351),
//--TRIMMABLE-BOUNDARY-START(133145428055),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3) => $.$$.System.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3"
      ],
      "n": "Validate",
      "o": "@$8",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(133145428055),
//--TRIMMABLE-BOUNDARY-START(128850460759),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3, TDep4) => $.$$.System.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4"
      ],
      "n": "Validate",
      "o": "@$7",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(128850460759),
//--TRIMMABLE-BOUNDARY-START(124555493463),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3, TDep4) => $.$$.System.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4"
      ],
      "n": "Validate",
      "o": "@$6",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(124555493463),
//--TRIMMABLE-BOUNDARY-START(120260526167),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.System.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.System.Boolean).$h
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4",
        "TDep5"
      ],
      "n": "Validate",
      "o": "@$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(120260526167),
//--TRIMMABLE-BOUNDARY-START(115965558871),
    {
      "r": this.$h,
      "p": [
        {
          "n": "validation",
          "p": (TDep1, TDep2, TDep3, TDep4, TDep5) => $.$$.System.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "g": [
        "TDep1",
        "TDep2",
        "TDep3",
        "TDep4",
        "TDep5"
      ],
      "n": "Validate",
      "o": "@$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(115965558871)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951114839),
    {
      "t": 1310721,
      "n": "DefaultValidationFailureMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951114839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886343767),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886343767)
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsBuilder<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1441879)
        
        
        //--TRIMMABLE-BOUNDARY-START(3276887)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptionsResultBuilder", ($self) => class ValidateOptionsResultBuilder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64427786327)
            /*string*/ static MemberSeparatorString = null;
            //--TRIMMABLE-BOUNDARY-END(64427786327)
            
            //--TRIMMABLE-BOUNDARY-START(4298244183)
            /*List<string>?*/ _errors = null;
            //--TRIMMABLE-BOUNDARY-END(4298244183)
            
            //--TRIMMABLE-BOUNDARY-START(8593211479)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593211479);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593211479)
            
            //--TRIMMABLE-BOUNDARY-START(12888178775)
            /*void */ AddError(/*string*/ error, /*string?*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888178775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(error, "error");
                this.Errors.Add(propertyName === null ? error : `Property ${propertyName}: ${error}`);
            }
            //--TRIMMABLE-BOUNDARY-END(12888178775)
            
            //--TRIMMABLE-BOUNDARY-START(21478113367)
            /*void */ AddResult$1(/*ValidationResult?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478113367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!((result?.ErrorMessage ?? null) === null))
                {
                    /*string*/ let joinedMembers = $.$$.System.String.Join$5(", "/*MemberSeparatorString*/, result.MemberNames);
                    this.Errors.Add(joinedMembers.length !== 0 ? `${joinedMembers}: ${result.ErrorMessage}` : result.ErrorMessage);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478113367)
            
            //--TRIMMABLE-BOUNDARY-START(25773080663)
            /*void */ AddResults(/*IEnumerable<ValidationResult?>?*/ results)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773080663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (results !== null)
                {
                    var $en3 = results.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var result = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddResult$1(result);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773080663)
            
            //--TRIMMABLE-BOUNDARY-START(17183146071)
            /*void */ AddResult(/*ValidateOptionsResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183146071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(result, "result");
                if (result.Failed)
                {
                    if (result.Failures === null)
                    {
                        this.Errors.Add(result.FailureMessage);
                    }
                    else 
                    {
                        var $en4 = result.Failures.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var failure = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (!(failure === null))
                                {
                                    this.Errors.Add(failure);
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183146071)
            
            //--TRIMMABLE-BOUNDARY-START(30068047959)
            /*ValidateOptionsResult */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068047959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Int32.op_GreaterThan$1((this._errors?.Count ?? null), 0))
                {
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail(this._errors);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
            }
            //--TRIMMABLE-BOUNDARY-END(30068047959)
            
            //--TRIMMABLE-BOUNDARY-START(34363015255)
            /*void */ Clear()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363015255);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._errors?.Clear() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34363015255)
            
            //--TRIMMABLE-BOUNDARY-START(42952949847)
            /*int */ get ErrorsCount()
            {
                return this._errors === null ? 0 : this._errors.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(42952949847)
            
            //--TRIMMABLE-BOUNDARY-START(38657982551)
            /*List<string> */ get Errors()
            {
                return this._errors ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(38657982551)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(64427786327)
                    this.MemberSeparatorString = ", ";
                    //--TRIMMABLE-BOUNDARY-END(64427786327)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3276887;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952949847),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132819031,
        "f": 50331650
      },
      "n": "ErrorsCount",
      "d": 3276887,
      "h": 42952949847,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42952949847),
//--TRIMMABLE-BOUNDARY-START(38657982551),
    {
      "p": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542884439,
        "f": 50331650
      },
      "n": "Errors",
      "d": 3276887,
      "h": 38657982551,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38657982551)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888178775),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 1310721
        },
        {
          "n": "propertyName",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "AddError",
      "d": 3276887,
      "h": 12888178775,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888178775),
//--TRIMMABLE-BOUNDARY-START(21478113367),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 3670055
        }
      ],
      "n": "AddResult",
      "o": "@$1",
      "d": 3276887,
      "h": 21478113367,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478113367),
//--TRIMMABLE-BOUNDARY-START(25773080663),
    {
      "r": 65537,
      "p": [
        {
          "n": "results",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h
        }
      ],
      "n": "AddResults",
      "d": 3276887,
      "h": 25773080663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773080663),
//--TRIMMABLE-BOUNDARY-START(17183146071),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 3211351
        }
      ],
      "n": "AddResult",
      "d": 3276887,
      "h": 17183146071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183146071),
//--TRIMMABLE-BOUNDARY-START(30068047959),
    {
      "r": 3211351,
      "n": "Build",
      "d": 3276887,
      "h": 30068047959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068047959),
//--TRIMMABLE-BOUNDARY-START(34363015255),
    {
      "r": 65537,
      "n": "Clear",
      "d": 3276887,
      "h": 34363015255,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363015255)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64427786327),
    {
      "t": 1310721,
      "n": "MemberSeparatorString",
      "d": 3276887,
      "h": 64427786327,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64427786327),
//--TRIMMABLE-BOUNDARY-START(4298244183),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "n": "_errors",
      "d": 3276887,
      "h": 4298244183,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298244183)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593211479),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3276887,
      "h": 8593211479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593211479)
  ],
  "h": 3276887,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{ErrorsCount} errors",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptionsResultBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276887)
        
        
        //--TRIMMABLE-BOUNDARY-START(3211351)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptionsResult", ($self) => class ValidateOptionsResult extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(141737132119)
            /*ValidateOptionsResult*/ static Skip = null;
            //--TRIMMABLE-BOUNDARY-END(141737132119)
            
            //--TRIMMABLE-BOUNDARY-START(154622034007)
            /*ValidateOptionsResult*/ static Success = null;
            //--TRIMMABLE-BOUNDARY-END(154622034007)
            
            //--TRIMMABLE-BOUNDARY-START(150327066711)
            /*bool*/ Succeeded = false;
            //--TRIMMABLE-BOUNDARY-END(150327066711)
            
            //--TRIMMABLE-BOUNDARY-START(146032099415)
            /*bool*/ Skipped = false;
            //--TRIMMABLE-BOUNDARY-END(146032099415)
            
            //--TRIMMABLE-BOUNDARY-START(42952884311)
            /*bool*/ Failed = false;
            //--TRIMMABLE-BOUNDARY-END(42952884311)
            
            //--TRIMMABLE-BOUNDARY-START(47247851607)
            /*string?*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(47247851607)
            
            //--TRIMMABLE-BOUNDARY-START(51542818903)
            /*IEnumerable<string>?*/ Failures = null;
            //--TRIMMABLE-BOUNDARY-END(51542818903)
            
            //--TRIMMABLE-BOUNDARY-START(38657917015)
            static /*ValidateOptionsResult */ Fail$1(/*string*/ failureMessage)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657917015);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult()
                        const $t1 = $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult;
                        const $i1 = new $t1();
                        $i1.Failed = true;
                        $i1.FailureMessage = failureMessage;
                        $i1.Failures = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [failureMessage], [-1], null);
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657917015)
            
            //--TRIMMABLE-BOUNDARY-START(34362949719)
            static /*ValidateOptionsResult */ Fail(/*IEnumerable<string>*/ failures)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362949719);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult()
                        const $t1 = $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult;
                        const $i1 = new $t1();
                        $i1.Failed = true;
                        $i1.FailureMessage = $.$$.System.String.Join$5("; ", failures);
                        $i1.Failures = failures;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362949719)
            
            //--TRIMMABLE-BOUNDARY-START(30067982423)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067982423)
            
            //--TRIMMABLE-BOUNDARY-START(25773015127)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(141737132119)
                    this.Skip = (() =>
                    {
                        //new $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult()
                        const $t1 = $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult;
                        const $i1 = new $t1();
                        $i1.Skipped = true;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(141737132119)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154622034007)
                    this.Success = (() =>
                    {
                        //new $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult()
                        const $t1 = $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult;
                        const $i1 = new $t1();
                        $i1.Succeeded = true;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(154622034007)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773015127)
            
            static $h = 3211351;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(150327066711),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492491863,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137442164823,
        "f": 83886084
      },
      "n": "Succeeded",
      "d": 3211351,
      "h": 150327066711,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150327066711),
//--TRIMMABLE-BOUNDARY-START(146032099415),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902557271,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128852230231,
        "f": 83886084
      },
      "n": "Skipped",
      "d": 3211351,
      "h": 146032099415,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146032099415),
//--TRIMMABLE-BOUNDARY-START(42952884311),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132753495,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103082426455,
        "f": 83886084
      },
      "n": "Failed",
      "d": 3211351,
      "h": 42952884311,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952884311),
//--TRIMMABLE-BOUNDARY-START(47247851607),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722688087,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111672361047,
        "f": 83886084
      },
      "n": "FailureMessage",
      "d": 3211351,
      "h": 47247851607,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247851607),
//--TRIMMABLE-BOUNDARY-START(51542818903),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312622679,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120262295639,
        "f": 83886084
      },
      "n": "Failures",
      "d": 3211351,
      "h": 51542818903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542818903)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38657917015),
    {
      "r": 3211351,
      "p": [
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "o": "@$1",
      "d": 3211351,
      "h": 38657917015,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657917015),
//--TRIMMABLE-BOUNDARY-START(34362949719),
    {
      "r": 3211351,
      "p": [
        {
          "n": "failures",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "Fail",
      "d": 3211351,
      "h": 34362949719,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362949719)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(141737132119),
    {
      "t": 3211351,
      "n": "Skip",
      "d": 3211351,
      "h": 141737132119,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141737132119),
//--TRIMMABLE-BOUNDARY-START(154622034007),
    {
      "t": 3211351,
      "n": "Success",
      "d": 3211351,
      "h": 154622034007,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154622034007)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067982423),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3211351,
      "h": 30067982423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067982423)
  ],
  "h": 3211351
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptionsResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211351)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031703)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsWrapper<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsWrapper<>", [TOptions], ($self) => class OptionsWrapper$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591966295)
            $ctor$1(/*TOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591966295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = options;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591966295)
            
            //--TRIMMABLE-BOUNDARY-START(21476868183)
            /*TOptions*/ Value = $.$default(TOptions);
            //--TRIMMABLE-BOUNDARY-END(21476868183)
            
            //--TRIMMABLE-BOUNDARY-START(8590721111)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get Microsoft$Extensions$Options$IOptions$$$Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721111)
            
            static $h = 2031703;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476868183),
    {
      "p": TOptions?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476868183)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591966295),
    {
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591966295)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsWrapper<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2031703)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621527)
        $asm.$cls("$meo.Microsoft.Extensions.Options.UnnamedOptionsManager<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.UnnamedOptionsManager<>", [TOptions], ($self) => class UnnamedOptionsManager$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297588823)
            /*IOptionsFactory<TOptions>*/ _factory = null;
            //--TRIMMABLE-BOUNDARY-END(4297588823)
            
            //--TRIMMABLE-BOUNDARY-START(8592556119)
            /*object?*/ _syncObj = null;
            //--TRIMMABLE-BOUNDARY-END(8592556119)
            
            //--TRIMMABLE-BOUNDARY-START(12887523415)
            /*TOptions?*/ _value = null;
            //--TRIMMABLE-BOUNDARY-END(12887523415)
            
            //--TRIMMABLE-BOUNDARY-START(17182490711)
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182490711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._factory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182490711)
            
            //--TRIMMABLE-BOUNDARY-START(30067392599)
            /*TOptions */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772425303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let value;
                if ($.$is(this._value, TOptions, { set $v(v){ value = v; } }))
                {
                    return value;
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._syncObj ?? $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this._syncObj, ($v) => this._syncObj = $v, $.$$.System.Object), new $.$$.System.Object().$ctor(), null) ?? this._syncObj)
                    {
                        return this._value ??= this._factory.Microsoft$Extensions$Options$IOptionsFactory$$$Create($.$meo.Microsoft.Extensions.Options.Options.DefaultName, [TOptions]);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._syncObj ?? $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this._syncObj, ($v) => this._syncObj = $v, $.$$.System.Object), new $.$$.System.Object().$ctor(), null) ?? this._syncObj)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067392599)
            
            //--TRIMMABLE-BOUNDARY-START(8590721111)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get Microsoft$Extensions$Options$IOptions$$$Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721111)
            
            static $h = 2621527;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067392599),
    {
      "p": TOptions?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067392599)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297588823),
    {
      "t": $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h,
      "n": "_factory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297588823),
//--TRIMMABLE-BOUNDARY-START(8592556119),
    {
      "t": 131073,
      "n": "_syncObj",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592556119),
//--TRIMMABLE-BOUNDARY-START(12887523415),
    {
      "t": TOptions?.$h??1507328,
      "n": "_value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887523415)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182490711),
    {
      "p": [
        {
          "n": "factory",
          "p": $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182490711)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.UnnamedOptionsManager<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2621527)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490455)
        $asm.$cls("$meo.Microsoft.Extensions.Options.StartupValidator", ($self) => class StartupValidator extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297457751)
            /*StartupValidatorOptions*/ _validatorOptions = null;
            //--TRIMMABLE-BOUNDARY-END(4297457751)
            
            //--TRIMMABLE-BOUNDARY-START(8592425047)
            $ctor$1(/*IOptions<StartupValidatorOptions>*/ validators)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592425047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._validatorOptions = validators.Microsoft$Extensions$Options$IOptions$$$Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592425047)
            
            //--TRIMMABLE-BOUNDARY-START(12887392343)
            /*void */ Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887392343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<Exception>?*/ let exceptions = null;
                var $en2 = this._validatorOptions._validators.Values.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var validator = $en2.Current;
                    {
                        try
                        {
                            validator.Invoke();
                        }
                        catch(ex)
                        {
                            exceptions ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Exception))().$ctor$1();
                            exceptions.Add(ex);
                        }
                    }
                }
                if (exceptions !== null)
                {
                    if (exceptions.Count === 1)
                    {
                        $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exceptions.get_Item(0)).Throw();
                    }
                    if (exceptions.Count > 1)
                    {
                        throw new $.$$.System.AggregateException().$ctor$6(exceptions);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887392343)
            
            //--TRIMMABLE-BOUNDARY-START(4296212567)
            //Generated interface implemetation for Microsoft.Extensions.Options.IStartupValidator.Validate()
            Microsoft$Extensions$Options$IStartupValidator$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296212567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296212567)
            
            static $h = 2490455;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887392343),
    {
      "r": 65537,
      "n": "Validate",
      "d": 2490455,
      "h": 12887392343,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887392343)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297457751),
    {
      "t": 2555991,
      "n": "_validatorOptions",
      "d": 2490455,
      "h": 4297457751,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297457751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592425047),
    {
      "p": [
        {
          "n": "validators",
          "p": $.$meo.Microsoft.Extensions.Options.IOptions$$($.$meo.Microsoft.Extensions.Options.StartupValidatorOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2490455,
      "h": 8592425047,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592425047)
  ],
  "i": [1245271
  ],
  "h": 2490455
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IStartupValidator ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.StartupValidator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490455)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572951)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsFactory<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsFactory<>", [TOptions], ($self) => class OptionsFactory$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591507543)
            /*IConfigureOptions<TOptions>[]*/ _setups = null;
            //--TRIMMABLE-BOUNDARY-END(8591507543)
            
            //--TRIMMABLE-BOUNDARY-START(4296540247)
            /*IPostConfigureOptions<TOptions>[]*/ _postConfigures = null;
            //--TRIMMABLE-BOUNDARY-END(4296540247)
            
            //--TRIMMABLE-BOUNDARY-START(12886474839)
            /*IValidateOptions<TOptions>[]*/ _validations = null;
            //--TRIMMABLE-BOUNDARY-END(12886474839)
            
            //--TRIMMABLE-BOUNDARY-START(21476409431)
            $ctor$2(/*IEnumerable<IConfigureOptions<TOptions>>*/ setups, /*IEnumerable<IPostConfigureOptions<TOptions>>*/ postConfigures)
            {
                this.$ctor$1(setups, postConfigures, $.$$.System.Array.Empty($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476409431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409431)
            
            //--TRIMMABLE-BOUNDARY-START(17181442135)
            $ctor$1(/*IEnumerable<IConfigureOptions<TOptions>>*/ setups, /*IEnumerable<IPostConfigureOptions<TOptions>>*/ postConfigures, /*IEnumerable<IValidateOptions<TOptions>>*/ validations)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181442135);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._setups = $.$as(setups, $.$typeArray($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions))) ?? new ($.$$.System.Collections.Generic.List$$($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)))().$ctor$2(setups).ToArray();
                    this._postConfigures = $.$as(postConfigures, $.$typeArray($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions))) ?? new ($.$$.System.Collections.Generic.List$$($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)))().$ctor$2(postConfigures).ToArray();
                    this._validations = $.$as(validations, $.$typeArray($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions))) ?? new ($.$$.System.Collections.Generic.List$$($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)))().$ctor$2(validations).ToArray();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181442135)
            
            //--TRIMMABLE-BOUNDARY-START(25771376727)
            /*TOptions */ Create(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771376727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TOptions*/ let options = this.CreateInstance(name);
                let $i1 = 0;
                let $arr1 = this._setups;
                while ($i1 < $arr1.length)
                {
                    let setup = $arr1[$i1++];
                    let namedSetup;
                    if ($.$is(setup, $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), { set $v(v){ namedSetup = v; } }))
                    {
                        namedSetup.Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure(name, options, [TOptions]);
                    }
                    else if ($.$$.System.String.op_Equality(name, $.$meo.Microsoft.Extensions.Options.Options.DefaultName))
                    {
                        setup.Microsoft$Extensions$Options$IConfigureOptions$$$Configure(options, [TOptions]);
                    }
                }
                let $i2 = 0;
                let $arr2 = this._postConfigures;
                while ($i2 < $arr2.length)
                {
                    let post = $arr2[$i2++];
                    post.Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure(name, options, [TOptions]);
                }
                if (this._validations.length > 0)
                {
                    /*var*/ let failures = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    let $i3 = 0;
                    let $arr3 = this._validations;
                    while ($i3 < $arr3.length)
                    {
                        let validate = $arr3[$i3++];
                        /*ValidateOptionsResult*/ let result = validate.Microsoft$Extensions$Options$IValidateOptions$$$Validate(name, options, [TOptions]);
                        if (!(result === null) && result.Failed)
                        {
                            failures.AddRange(result.Failures);
                        }
                    }
                    if (failures.Count > 0)
                    {
                        throw new $.$meo.Microsoft.Extensions.Options.OptionsValidationException().$ctor$5(name, TOptions.$type, failures);
                    }
                }
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(25771376727)
            
            //--TRIMMABLE-BOUNDARY-START(30066344023)
            /*TOptions */ CreateInstance(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066344023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Activator.CreateInstance$10(TOptions);
            }
            //--TRIMMABLE-BOUNDARY-END(30066344023)
            
            //--TRIMMABLE-BOUNDARY-START(4295884887)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsFactory<TOptions>.Create(string)
            Microsoft$Extensions$Options$IOptionsFactory$$$Create()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884887)
            
            static $h = 1572951;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771376727),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Create",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771376727),
//--TRIMMABLE-BOUNDARY-START(30066344023),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "CreateInstance",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30066344023)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591507543),
    {
      "t": $.$typeArray($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)).$h,
      "n": "_setups",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507543),
//--TRIMMABLE-BOUNDARY-START(4296540247),
    {
      "t": $.$typeArray($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)).$h,
      "n": "_postConfigures",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540247),
//--TRIMMABLE-BOUNDARY-START(12886474839),
    {
      "t": $.$typeArray($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)).$h,
      "n": "_validations",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886474839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476409431),
    {
      "p": [
        {
          "n": "setups",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)).$h
        },
        {
          "n": "postConfigures",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476409431),
//--TRIMMABLE-BOUNDARY-START(17181442135),
    {
      "p": [
        {
          "n": "setups",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions)).$h
        },
        {
          "n": "postConfigures",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions)).$h
        },
        {
          "n": "validations",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181442135)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsFactory<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1572951)
        
        
        //--TRIMMABLE-BOUNDARY-START(589911)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureOptions<>", [TOptions], ($self) => class ConfigureOptions$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590524503)
            $ctor$1(/*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590524503);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524503)
            
            //--TRIMMABLE-BOUNDARY-START(12885491799)
            /*Action<TOptions>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(12885491799)
            
            //--TRIMMABLE-BOUNDARY-START(17180459095)
            /*void */ Configure(/*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                this.Action?.Invoke(options);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459095)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $h = 589911;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885491799),
    {
      "p": $.$$.System.Action$$(TOptions).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885491799)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459095),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180459095)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590524503),
    {
      "p": [
        {
          "n": "action",
          "p": $.$$.System.Action$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590524503)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(589911)
        
        
        //--TRIMMABLE-BOUNDARY-START(3145815)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<>", [TOptions], ($self) => class ValidateOptions$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183014999)
            $ctor$1(/*string?*/ name, /*Func<TOptions, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183014999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183014999)
            
            //--TRIMMABLE-BOUNDARY-START(51542753367)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(51542753367)
            
            //--TRIMMABLE-BOUNDARY-START(60132687959)
            /*Func<TOptions, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(60132687959)
            
            //--TRIMMABLE-BOUNDARY-START(21477982295)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(21477982295)
            
            //--TRIMMABLE-BOUNDARY-START(55837720663)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837720663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(55837720663)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $h = 3145815;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542753367),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542753367),
//--TRIMMABLE-BOUNDARY-START(60132687959),
    {
      "p": $.$$.System.Func$$$(TOptions, $.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132687959),
//--TRIMMABLE-BOUNDARY-START(21477982295),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477982295)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55837720663),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55837720663)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183014999),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "validation",
          "p": $.$$.System.Func$$$(TOptions, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183014999)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3145815)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507415)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsCache<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsCache<>", [TOptions], ($self) => class OptionsCache$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474711)
            /*ConcurrentDictionary<string, Lazy<TOptions>>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4296474711)
            
            //--TRIMMABLE-BOUNDARY-START(12886409303)
            /*void */ Clear()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409303);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._cache.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886409303)
            
            //--TRIMMABLE-BOUNDARY-START(17181376599)
            /*TOptions */ GetOrAdd(/*string?*/ name, /*Func<TOptions>*/ createOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(createOptions, "createOptions");
                name ??= $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                /*Lazy<TOptions>*/ let value;
                value = this._cache.GetOrAdd$2($.$$.System.Func$$(TOptions), name, new ($.$$.System.Func$$$$($.$$.System.String, $.$$.System.Func$$(TOptions), $.$$.System.Lazy$$(TOptions)))().$ctor($.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions), /*static*/ (/*name*/ name, /*createOptions*/ createOptions) =>
                {
                    return new ($.$$.System.Lazy$$(TOptions))().$ctor$6(createOptions);
                }, {
  "r": $.$$.System.Lazy$$(TOptions).$h,
  "p": [
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "createOptions",
      "p": $.$$.System.Func$$(TOptions).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825826
}), createOptions);
                return value.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376599)
            
            //--TRIMMABLE-BOUNDARY-START(21476343895)
            /*TOptions */ GetOrAdd$1(TArg, /*string?*/ name, /*Func<string, TArg, TOptions>*/ createOptions, /*TArg*/ factoryArgument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Inequality$1($.$$.System.Object.GetType.call(this), $.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions).$type))
                {
                    /*string?*/ let localName = name;
                    /*Func<string, TArg, TOptions>*/ let localCreateOptions = createOptions;
                    /*TArg*/ let localFactoryArgument = factoryArgument;
                    return this.GetOrAdd(name, new ($.$$.System.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localCreateOptions.Invoke(localName ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, localFactoryArgument);
                    }, {
  "r": TOptions?.$h??1507328,
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                }
                return this._cache.GetOrAdd$2($.$$.System.ValueTuple$$$($.$$.System.Func$$$$($.$$.System.String, TArg, TOptions), TArg), name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, new ($.$$.System.Func$$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Func$$$$($.$$.System.String, TArg, TOptions), TArg), $.$$.System.Lazy$$(TOptions)))().$ctor($.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions), /*static*/ (/*name*/ name, /*arg*/ arg) =>
                {
                    return new ($.$$.System.Lazy$$(TOptions))().$ctor$6(new ($.$$.System.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return arg.Item1.Invoke(name, arg.Item2);
                    }, {
  "r": TOptions?.$h??1507328,
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                }, {
  "r": $.$$.System.Lazy$$(TOptions).$h,
  "p": [
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "arg",
      "p": (TArg) => $.$$.System.ValueTuple$$$($.$$.System.Func$$$$($.$$.System.String, TArg, TOptions), TArg).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.ValueTuple$$$($.$$.System.Func$$$$($.$$.System.String, TArg, TOptions), TArg))().$ctor$3(createOptions, factoryArgument)).Value;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343895)
            
            //--TRIMMABLE-BOUNDARY-START(30066278487)
            /*bool */ TryGetValue(/*string?*/ name, /*out TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Lazy<TOptions>?*/ let lazy;
                if (this._cache.TryGetValue(name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, $.$ref(() => lazy, ($v) => lazy = $v, $.$$.System.Lazy$$(TOptions))))
                {
                    options.$v = lazy.Value;
                    return true;
                }
                options.$v = $.$default(TOptions);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30066278487)
            
            //--TRIMMABLE-BOUNDARY-START(25771311191)
            /*bool */ TryAdd(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                return this._cache.TryAdd(name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, new ($.$$.System.Lazy$$(TOptions))().$ctor$8(options));
            }
            //--TRIMMABLE-BOUNDARY-END(25771311191)
            
            //--TRIMMABLE-BOUNDARY-START(34361245783)
            /*bool */ TryRemove(/*string?*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361245783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._cache.TryRemove$1(name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245783)
            
            //--TRIMMABLE-BOUNDARY-START(8590983255)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.GetOrAdd(string?, System.Func<TOptions>)
            Microsoft$Extensions$Options$IOptionsMonitorCache$$$GetOrAdd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOrAdd(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983255)
            
            //--TRIMMABLE-BOUNDARY-START(12885950551)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.TryAdd(string?, TOptions)
            Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryAdd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryAdd(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885950551)
            
            //--TRIMMABLE-BOUNDARY-START(17180917847)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.TryRemove(string?)
            Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryRemove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180917847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryRemove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180917847)
            
            //--TRIMMABLE-BOUNDARY-START(4296015959)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitorCache<TOptions>.Clear()
            Microsoft$Extensions$Options$IOptionsMonitorCache$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296015959)
            
            //--TRIMMABLE-BOUNDARY-START(8591442007)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591442007)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474711)
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Lazy$$(TOptions)))().$ctor$7(1, 31, $.$$.System.StringComparer.Ordinal);
                //--TRIMMABLE-BOUNDARY-END(4296474711)
                
            }
            static $h = 1507415;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886409303),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409303),
//--TRIMMABLE-BOUNDARY-START(17181376599),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "createOptions",
          "p": $.$$.System.Func$$(TOptions).$h
        }
      ],
      "n": "GetOrAdd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181376599),
//--TRIMMABLE-BOUNDARY-START(21476343895),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "createOptions",
          "p": (TArg) => $.$$.System.Func$$$$($.$$.System.String, TArg, TOptions).$h
        },
        {
          "n": "factoryArgument",
          "p": (TArg) => TArg.$h
        }
      ],
      "g": [
        "TArg"
      ],
      "n": "GetOrAdd",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(21476343895),
//--TRIMMABLE-BOUNDARY-START(30066278487),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30066278487),
//--TRIMMABLE-BOUNDARY-START(25771311191),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "TryAdd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771311191),
//--TRIMMABLE-BOUNDARY-START(34361245783),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "TryRemove",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34361245783)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474711),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Lazy$$(TOptions)).$h,
      "n": "_cache",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474711)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591442007),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591442007)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsCache<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1507415)
        
        
        //--TRIMMABLE-BOUNDARY-START(3080279)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,>", (TOptions, TDep) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,>", [TOptions, TDep], ($self) => class ValidateOptions$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21477916759)
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Func<TOptions, TDep, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477916759);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency = dependency;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477916759)
            
            //--TRIMMABLE-BOUNDARY-START(68722557015)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(68722557015)
            
            //--TRIMMABLE-BOUNDARY-START(77312491607)
            /*Func<TOptions, TDep, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(77312491607)
            
            //--TRIMMABLE-BOUNDARY-START(30067851351)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(30067851351)
            
            //--TRIMMABLE-BOUNDARY-START(25772884055)
            /*TDep*/ Dependency = $.$default(TDep);
            //--TRIMMABLE-BOUNDARY-END(25772884055)
            
            //--TRIMMABLE-BOUNDARY-START(73017524311)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017524311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(73017524311)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $h = 3080279;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68722557015),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722557015),
//--TRIMMABLE-BOUNDARY-START(77312491607),
    {
      "p": $.$$.System.Func$$$$(TOptions, TDep, $.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312491607),
//--TRIMMABLE-BOUNDARY-START(30067851351),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067851351),
//--TRIMMABLE-BOUNDARY-START(25772884055),
    {
      "p": TDep?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "Dependency",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772884055)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73017524311),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73017524311)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477916759),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep?.$h??1572864
        },
        {
          "n": "validation",
          "p": $.$$.System.Func$$$$(TOptions, TDep, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477916759)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep?.$h??1572864
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    null
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3080279)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014743)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,,>", (TOptions, TDep1, TDep2) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,,>", [TOptions, TDep1, TDep2], ($self) => class ValidateOptions$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25772818519)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*Func<TOptions, TDep1, TDep2, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772818519);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772818519)
            
            //--TRIMMABLE-BOUNDARY-START(85902360663)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(85902360663)
            
            //--TRIMMABLE-BOUNDARY-START(94492295255)
            /*Func<TOptions, TDep1, TDep2, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(94492295255)
            
            //--TRIMMABLE-BOUNDARY-START(38657720407)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(38657720407)
            
            //--TRIMMABLE-BOUNDARY-START(30067785815)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(30067785815)
            
            //--TRIMMABLE-BOUNDARY-START(34362753111)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(34362753111)
            
            //--TRIMMABLE-BOUNDARY-START(90197327959)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197327959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(90197327959)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $h = 3014743;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85902360663),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85902360663),
//--TRIMMABLE-BOUNDARY-START(94492295255),
    {
      "p": $.$$.System.Func$$$$$(TOptions, TDep1, TDep2, $.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94492295255),
//--TRIMMABLE-BOUNDARY-START(38657720407),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657720407),
//--TRIMMABLE-BOUNDARY-START(30067785815),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067785815),
//--TRIMMABLE-BOUNDARY-START(34362753111),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362753111)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90197327959),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90197327959)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772818519),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "validation",
          "p": $.$$.System.Func$$$$$(TOptions, TDep1, TDep2, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772818519)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    null,
    null
  ],
  "r": 3,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3014743)
        
        
        //--TRIMMABLE-BOUNDARY-START(2949207)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,>", (TOptions, TDep1, TDep2, TDep3) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,>", [TOptions, TDep1, TDep2, TDep3], ($self) => class ValidateOptions$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30067720279)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067720279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067720279)
            
            //--TRIMMABLE-BOUNDARY-START(103082164311)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(103082164311)
            
            //--TRIMMABLE-BOUNDARY-START(111672098903)
            /*Func<TOptions, TDep1, TDep2, TDep3, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(111672098903)
            
            //--TRIMMABLE-BOUNDARY-START(47247589463)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(47247589463)
            
            //--TRIMMABLE-BOUNDARY-START(34362687575)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(34362687575)
            
            //--TRIMMABLE-BOUNDARY-START(38657654871)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(38657654871)
            
            //--TRIMMABLE-BOUNDARY-START(42952622167)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(42952622167)
            
            //--TRIMMABLE-BOUNDARY-START(107377131607)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377131607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(107377131607)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $h = 2949207;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103082164311),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103082164311),
//--TRIMMABLE-BOUNDARY-START(111672098903),
    {
      "p": $.$$.System.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111672098903),
//--TRIMMABLE-BOUNDARY-START(47247589463),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247589463),
//--TRIMMABLE-BOUNDARY-START(34362687575),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362687575),
//--TRIMMABLE-BOUNDARY-START(38657654871),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657654871),
//--TRIMMABLE-BOUNDARY-START(42952622167),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952622167)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107377131607),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107377131607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067720279),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "validation",
          "p": $.$$.System.Func$$$$$$(TOptions, TDep1, TDep2, TDep3, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067720279)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    null,
    null,
    null
  ],
  "r": 4,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2949207)
        
        
        //--TRIMMABLE-BOUNDARY-START(2883671)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class ValidateOptions$$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34362622039)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362622039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362622039)
            
            //--TRIMMABLE-BOUNDARY-START(120261967959)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(120261967959)
            
            //--TRIMMABLE-BOUNDARY-START(128851902551)
            /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(128851902551)
            
            //--TRIMMABLE-BOUNDARY-START(55837458519)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(55837458519)
            
            //--TRIMMABLE-BOUNDARY-START(38657589335)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(38657589335)
            
            //--TRIMMABLE-BOUNDARY-START(42952556631)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(42952556631)
            
            //--TRIMMABLE-BOUNDARY-START(47247523927)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(47247523927)
            
            //--TRIMMABLE-BOUNDARY-START(51542491223)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(51542491223)
            
            //--TRIMMABLE-BOUNDARY-START(124556935255)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556935255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(124556935255)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $h = 2883671;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(120261967959),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261967959),
//--TRIMMABLE-BOUNDARY-START(128851902551),
    {
      "p": $.$$.System.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128851902551),
//--TRIMMABLE-BOUNDARY-START(55837458519),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837458519),
//--TRIMMABLE-BOUNDARY-START(38657589335),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657589335),
//--TRIMMABLE-BOUNDARY-START(42952556631),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952556631),
//--TRIMMABLE-BOUNDARY-START(47247523927),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247523927),
//--TRIMMABLE-BOUNDARY-START(51542491223),
    {
      "p": TDep4?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542491223)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(124556935255),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124556935255)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34362622039),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1769472
        },
        {
          "n": "validation",
          "p": $.$$.System.Func$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362622039)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    null,
    null,
    null,
    null
  ],
  "r": 5,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2883671)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818135)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt("$meo.Microsoft.Extensions.Options.ValidateOptions<,,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class ValidateOptions$$$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38657523799)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ validation, /*string*/ failureMessage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657523799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validation, "validation");
                    this.Name = name;
                    this.Validation = validation;
                    this.FailureMessage = failureMessage;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38657523799)
            
            //--TRIMMABLE-BOUNDARY-START(137441771607)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(137441771607)
            
            //--TRIMMABLE-BOUNDARY-START(146031706199)
            /*Func<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, bool>*/ Validation = null;
            //--TRIMMABLE-BOUNDARY-END(146031706199)
            
            //--TRIMMABLE-BOUNDARY-START(64427327575)
            /*string*/ FailureMessage = null;
            //--TRIMMABLE-BOUNDARY-END(64427327575)
            
            //--TRIMMABLE-BOUNDARY-START(42952491095)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(42952491095)
            
            //--TRIMMABLE-BOUNDARY-START(47247458391)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(47247458391)
            
            //--TRIMMABLE-BOUNDARY-START(51542425687)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(51542425687)
            
            //--TRIMMABLE-BOUNDARY-START(55837392983)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(55837392983)
            
            //--TRIMMABLE-BOUNDARY-START(60132360279)
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            //--TRIMMABLE-BOUNDARY-END(60132360279)
            
            //--TRIMMABLE-BOUNDARY-START(141736738903)
            /*ValidateOptionsResult */ Validate(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736738903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    if (this.Validation.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5))
                    {
                        return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Success;
                    }
                    return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Fail$1(this.FailureMessage);
                }
                return $.$meo.Microsoft.Extensions.Options.ValidateOptionsResult.Skip;
            }
            //--TRIMMABLE-BOUNDARY-END(141736738903)
            
            //--TRIMMABLE-BOUNDARY-START(4296278103)
            //Generated interface implemetation for Microsoft.Extensions.Options.IValidateOptions<TOptions>.Validate(string?, TOptions)
            Microsoft$Extensions$Options$IValidateOptions$$$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296278103)
            
            static $h = 2818135;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(137441771607),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441771607),
//--TRIMMABLE-BOUNDARY-START(146031706199),
    {
      "p": $.$$.System.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331649
      },
      "n": "Validation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146031706199),
//--TRIMMABLE-BOUNDARY-START(64427327575),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331649
      },
      "n": "FailureMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427327575),
//--TRIMMABLE-BOUNDARY-START(42952491095),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952491095),
//--TRIMMABLE-BOUNDARY-START(47247458391),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247458391),
//--TRIMMABLE-BOUNDARY-START(51542425687),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542425687),
//--TRIMMABLE-BOUNDARY-START(55837392983),
    {
      "p": TDep4?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837392983),
//--TRIMMABLE-BOUNDARY-START(60132360279),
    {
      "p": TDep5?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "n": "Dependency5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132360279)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141736738903),
    {
      "r": 3211351,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Validate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141736738903)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38657523799),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1769472
        },
        {
          "n": "dependency5",
          "p": TDep5?.$h??1835008
        },
        {
          "n": "validation",
          "p": $.$$.System.Func$$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5, $.$$.System.Boolean).$h
        },
        {
          "n": "failureMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657523799)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472,TDep5?.$h??1835008
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    null,
    null,
    null,
    null,
    null
  ],
  "r": 6,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IValidateOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2818135)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424919)
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<>", [TOptions], ($self) => class PostConfigureOptions$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887326807)
            $ctor$1(/*string?*/ name, /*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887326807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326807)
            
            //--TRIMMABLE-BOUNDARY-START(38657130583)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(38657130583)
            
            //--TRIMMABLE-BOUNDARY-START(17182294103)
            /*Action<TOptions>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(17182294103)
            
            //--TRIMMABLE-BOUNDARY-START(42952097879)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952097879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952097879)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $h = 2424919;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657130583),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657130583),
//--TRIMMABLE-BOUNDARY-START(17182294103),
    {
      "p": $.$$.System.Action$$(TOptions).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182294103)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952097879),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42952097879)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887326807),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887326807)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2424919)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359383)
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,>", (TOptions, TDep) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,>", [TOptions, TDep], ($self) => class PostConfigureOptions$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182228567)
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Action<TOptions, TDep>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182228567);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency = dependency;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182228567)
            
            //--TRIMMABLE-BOUNDARY-START(55836934231)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(55836934231)
            
            //--TRIMMABLE-BOUNDARY-START(21477195863)
            /*Action<TOptions, TDep>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(21477195863)
            
            //--TRIMMABLE-BOUNDARY-START(25772163159)
            /*TDep*/ Dependency = $.$default(TDep);
            //--TRIMMABLE-BOUNDARY-END(25772163159)
            
            //--TRIMMABLE-BOUNDARY-START(60131901527)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131901527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131901527)
            
            //--TRIMMABLE-BOUNDARY-START(64426868823)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426868823);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426868823)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $h = 2359383;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836934231),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836934231),
//--TRIMMABLE-BOUNDARY-START(21477195863),
    {
      "p": $.$$.System.Action$$$(TOptions, TDep).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477195863),
//--TRIMMABLE-BOUNDARY-START(25772163159),
    {
      "p": TDep?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Dependency",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772163159)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131901527),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60131901527),
//--TRIMMABLE-BOUNDARY-START(64426868823),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426868823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182228567),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep?.$h??1572864
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$(TOptions, TDep).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182228567)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep?.$h??1572864
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep",
      "f": 1
    }
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2359383)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293847)
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,>", (TOptions, TDep1, TDep2) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,>", [TOptions, TDep1, TDep2], ($self) => class PostConfigureOptions$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21477130327)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*Action<TOptions, TDep1, TDep2>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477130327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477130327)
            
            //--TRIMMABLE-BOUNDARY-START(73016737879)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(73016737879)
            
            //--TRIMMABLE-BOUNDARY-START(25772097623)
            /*Action<TOptions, TDep1, TDep2>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(25772097623)
            
            //--TRIMMABLE-BOUNDARY-START(30067064919)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(30067064919)
            
            //--TRIMMABLE-BOUNDARY-START(34362032215)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(34362032215)
            
            //--TRIMMABLE-BOUNDARY-START(77311705175)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311705175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311705175)
            
            //--TRIMMABLE-BOUNDARY-START(81606672471)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81606672471);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606672471)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $h = 2293847;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73016737879),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016737879),
//--TRIMMABLE-BOUNDARY-START(25772097623),
    {
      "p": $.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772097623),
//--TRIMMABLE-BOUNDARY-START(30067064919),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067064919),
//--TRIMMABLE-BOUNDARY-START(34362032215),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362032215)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77311705175),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77311705175),
//--TRIMMABLE-BOUNDARY-START(81606672471),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606672471)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477130327),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477130327)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep1",
      "f": 1
    },
    {
      "n": "TDep2",
      "f": 1
    }
  ],
  "r": 3,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2293847)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228311)
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,>", (TOptions, TDep1, TDep2, TDep3) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,>", [TOptions, TDep1, TDep2, TDep3], ($self) => class PostConfigureOptions$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25772032087)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Action<TOptions, TDep1, TDep2, TDep3>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772032087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772032087)
            
            //--TRIMMABLE-BOUNDARY-START(90196541527)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(90196541527)
            
            //--TRIMMABLE-BOUNDARY-START(30066999383)
            /*Action<TOptions, TDep1, TDep2, TDep3>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(30066999383)
            
            //--TRIMMABLE-BOUNDARY-START(34361966679)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(34361966679)
            
            //--TRIMMABLE-BOUNDARY-START(38656933975)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(38656933975)
            
            //--TRIMMABLE-BOUNDARY-START(42951901271)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(42951901271)
            
            //--TRIMMABLE-BOUNDARY-START(94491508823)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491508823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491508823)
            
            //--TRIMMABLE-BOUNDARY-START(98786476119)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98786476119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98786476119)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $h = 2228311;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(90196541527),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196541527),
//--TRIMMABLE-BOUNDARY-START(30066999383),
    {
      "p": $.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066999383),
//--TRIMMABLE-BOUNDARY-START(34361966679),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361966679),
//--TRIMMABLE-BOUNDARY-START(38656933975),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656933975),
//--TRIMMABLE-BOUNDARY-START(42951901271),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951901271)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94491508823),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94491508823),
//--TRIMMABLE-BOUNDARY-START(98786476119),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98786476119)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772032087),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772032087)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep1",
      "f": 1
    },
    {
      "n": "TDep2",
      "f": 1
    },
    {
      "n": "TDep3",
      "f": 1
    }
  ],
  "r": 4,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2228311)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162775)
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class PostConfigureOptions$$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066933847)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066933847);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066933847)
            
            //--TRIMMABLE-BOUNDARY-START(107376345175)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(107376345175)
            
            //--TRIMMABLE-BOUNDARY-START(34361901143)
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(34361901143)
            
            //--TRIMMABLE-BOUNDARY-START(38656868439)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(38656868439)
            
            //--TRIMMABLE-BOUNDARY-START(42951835735)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(42951835735)
            
            //--TRIMMABLE-BOUNDARY-START(47246803031)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(47246803031)
            
            //--TRIMMABLE-BOUNDARY-START(51541770327)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(51541770327)
            
            //--TRIMMABLE-BOUNDARY-START(111671312471)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671312471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111671312471)
            
            //--TRIMMABLE-BOUNDARY-START(115966279767)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115966279767);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115966279767)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $h = 2162775;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(107376345175),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376345175),
//--TRIMMABLE-BOUNDARY-START(34361901143),
    {
      "p": $.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361901143),
//--TRIMMABLE-BOUNDARY-START(38656868439),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656868439),
//--TRIMMABLE-BOUNDARY-START(42951835735),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951835735),
//--TRIMMABLE-BOUNDARY-START(47246803031),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246803031),
//--TRIMMABLE-BOUNDARY-START(51541770327),
    {
      "p": TDep4?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541770327)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111671312471),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111671312471),
//--TRIMMABLE-BOUNDARY-START(115966279767),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115966279767)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066933847),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1769472
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066933847)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep1",
      "f": 1
    },
    {
      "n": "TDep2",
      "f": 1
    },
    {
      "n": "TDep3",
      "f": 1
    },
    {
      "n": "TDep4",
      "f": 1
    }
  ],
  "r": 5,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2162775)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097239)
        $asm.$cls("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt("$meo.Microsoft.Extensions.Options.PostConfigureOptions<,,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class PostConfigureOptions$$$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361835607)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361835607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361835607)
            
            //--TRIMMABLE-BOUNDARY-START(124556148823)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(124556148823)
            
            //--TRIMMABLE-BOUNDARY-START(38656802903)
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(38656802903)
            
            //--TRIMMABLE-BOUNDARY-START(42951770199)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(42951770199)
            
            //--TRIMMABLE-BOUNDARY-START(47246737495)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(47246737495)
            
            //--TRIMMABLE-BOUNDARY-START(51541704791)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(51541704791)
            
            //--TRIMMABLE-BOUNDARY-START(55836672087)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(55836672087)
            
            //--TRIMMABLE-BOUNDARY-START(60131639383)
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            //--TRIMMABLE-BOUNDARY-END(60131639383)
            
            //--TRIMMABLE-BOUNDARY-START(128851116119)
            /*void */ PostConfigure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851116119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851116119)
            
            //--TRIMMABLE-BOUNDARY-START(133146083415)
            /*void */ PostConfigure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146083415);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PostConfigure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146083415)
            
            //--TRIMMABLE-BOUNDARY-START(4296147031)
            //Generated interface implemetation for Microsoft.Extensions.Options.IPostConfigureOptions<TOptions>.PostConfigure(string?, TOptions)
            Microsoft$Extensions$Options$IPostConfigureOptions$$$PostConfigure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296147031)
            
            static $h = 2097239;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(124556148823),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124556148823),
//--TRIMMABLE-BOUNDARY-START(38656802903),
    {
      "p": $.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656802903),
//--TRIMMABLE-BOUNDARY-START(42951770199),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951770199),
//--TRIMMABLE-BOUNDARY-START(47246737495),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246737495),
//--TRIMMABLE-BOUNDARY-START(51541704791),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541704791),
//--TRIMMABLE-BOUNDARY-START(55836672087),
    {
      "p": TDep4?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836672087),
//--TRIMMABLE-BOUNDARY-START(60131639383),
    {
      "p": TDep5?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "n": "Dependency5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131639383)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128851116119),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(128851116119),
//--TRIMMABLE-BOUNDARY-START(133146083415),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "PostConfigure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133146083415)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361835607),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1769472
        },
        {
          "n": "dependency5",
          "p": TDep5?.$h??1835008
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361835607)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472,TDep5?.$h??1835008
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep1",
      "f": 1
    },
    {
      "n": "TDep2",
      "f": 1
    },
    {
      "n": "TDep3",
      "f": 1
    },
    {
      "n": "TDep4",
      "f": 1
    },
    {
      "n": "TDep5",
      "f": 1
    }
  ],
  "r": 6,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IPostConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.PostConfigureOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2097239)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638487)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsManager<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsManager<>", [TOptions], ($self) => class OptionsManager$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591573079)
            /*IOptionsFactory<TOptions>*/ _factory = null;
            //--TRIMMABLE-BOUNDARY-END(8591573079)
            
            //--TRIMMABLE-BOUNDARY-START(4296605783)
            /*OptionsCache<TOptions>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4296605783)
            
            //--TRIMMABLE-BOUNDARY-START(12886540375)
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886540375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._factory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540375)
            
            //--TRIMMABLE-BOUNDARY-START(30066409559)
            /*TOptions */ get Value()
            {
                return this.Get($.$meo.Microsoft.Extensions.Options.Options.DefaultName);
            }
            //--TRIMMABLE-BOUNDARY-END(30066409559)
            
            //--TRIMMABLE-BOUNDARY-START(25771442263)
            /*TOptions */ Get(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771442263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                name ??= $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                /*TOptions?*/ let options;
                if (!this._cache.TryGetValue(name, $.$ref(() => options, ($v) => options = $v, TOptions)))
                {
                    /*IOptionsFactory<TOptions>*/ let localFactory = this._factory;
                    /*string*/ let localName = name;
                    options = this._cache.GetOrAdd(name, new ($.$$.System.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localFactory.Microsoft$Extensions$Options$IOptionsFactory$$$Create(localName, [TOptions]);
                    }, {
  "r": TOptions?.$h??1507328,
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                }
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(25771442263)
            
            //--TRIMMABLE-BOUNDARY-START(4296081495)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsSnapshot<TOptions>.Get(string?)
            Microsoft$Extensions$Options$IOptionsSnapshot$$$Get()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081495)
            
            //--TRIMMABLE-BOUNDARY-START(8590721111)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptions<TOptions>.Value.get
            get Microsoft$Extensions$Options$IOptions$$$Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721111)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296605783)
                this._cache = new ($.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296605783)
                
            }
            static $h = 1638487;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066409559),
    {
      "p": TOptions?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066409559)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771442263),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771442263)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591573079),
    {
      "t": $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h,
      "n": "_factory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591573079),
//--TRIMMABLE-BOUNDARY-START(4296605783),
    {
      "t": $.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions).$h,
      "n": "_cache",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605783)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886540375),
    {
      "p": [
        {
          "n": "factory",
          "p": $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540375)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptionsSnapshot$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsSnapshot$$(TOptions), $.$meo.Microsoft.Extensions.Options.IOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsManager<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1638487)
        
        
        //--TRIMMABLE-BOUNDARY-START(524375)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<>", [TOptions], ($self) => class ConfigureNamedOptions$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885426263)
            $ctor$1(/*string?*/ name, /*Action<TOptions>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426263);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426263)
            
            //--TRIMMABLE-BOUNDARY-START(47245164631)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(47245164631)
            
            //--TRIMMABLE-BOUNDARY-START(17180393559)
            /*Action<TOptions>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(17180393559)
            
            //--TRIMMABLE-BOUNDARY-START(21475360855)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360855)
            
            //--TRIMMABLE-BOUNDARY-START(25770328151)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770328151)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $h = 524375;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245164631),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245164631),
//--TRIMMABLE-BOUNDARY-START(17180393559),
    {
      "p": $.$$.System.Action$$(TOptions).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180393559)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475360855),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475360855),
//--TRIMMABLE-BOUNDARY-START(25770328151),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328151)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426263),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426263)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(524375)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704023)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsMonitor<>", (TOptions) => $asm.$gt("$meo.Microsoft.Extensions.Options.OptionsMonitor<>", [TOptions], ($self) => class OptionsMonitor$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296671319)
            /*IOptionsMonitorCache<TOptions>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4296671319)
            
            //--TRIMMABLE-BOUNDARY-START(8591638615)
            /*IOptionsFactory<TOptions>*/ _factory = null;
            //--TRIMMABLE-BOUNDARY-END(8591638615)
            
            //--TRIMMABLE-BOUNDARY-START(17181573207)
            /*List<IDisposable>*/ _registrations = null;
            //--TRIMMABLE-BOUNDARY-END(17181573207)
            
            //--TRIMMABLE-BOUNDARY-START(12886605911)
            /*Action<TOptions, string>?*/ _onChange = null;
            //--TRIMMABLE-BOUNDARY-END(12886605911)
            
            //--TRIMMABLE-BOUNDARY-START(12886605911)
            //--TRIMMABLE-BOUNDARY-START(34361442391)
            add__onChange(/*Action<TOptions, string>?*/ value)
            {
                this._onChange = $.$$.System.Delegate.Combine(this._onChange, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34361442391)
            
            //--TRIMMABLE-BOUNDARY-START(73016148055)
            remove__onChange(/*Action<TOptions, string>?*/ value)
            {
                this._onChange = $.$$.System.Delegate.Remove(this._onChange, value);
            }
            //--TRIMMABLE-BOUNDARY-END(73016148055)
            
            //--TRIMMABLE-BOUNDARY-END(12886605911)
            
            //--TRIMMABLE-BOUNDARY-START(25771507799)
            $ctor$1(/*IOptionsFactory<TOptions>*/ factory, /*IEnumerable<IOptionsChangeTokenSource<TOptions>>*/ sources, /*IOptionsMonitorCache<TOptions>*/ cache)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771507799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._factory = factory;
                    this._cache = cache;
                    /*void*/  function RegisterSource(/*IOptionsChangeTokenSource<TOptions>*/ source)
                    {
                        /*IDisposable*/ let registration = $.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange$1($.$$.System.String, new ($.$$.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(source, source.Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$GetChangeToken), new ($.$$.System.Action$$($.$$.System.String))().$ctor(this, this.InvokeChanged), source.Microsoft$Extensions$Options$IOptionsChangeTokenSource$$$Name);
                        this._registrations.Add(registration);
                    }
                    let sourcesArray;
                    if ($.$is(sources, $.$typeArray($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions)), { set $v(v){ sourcesArray = v; } }))
                    {
                        let $i1 = 0;
                        let $arr1 = sourcesArray;
                        while ($i1 < $arr1.length)
                        {
                            let source = $arr1[$i1++];
                            RegisterSource.call(this, source);
                        }
                    }
                    else 
                    {
                        var $en4 = sources.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var source = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                RegisterSource.call(this, source);
                            }
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771507799)
            
            //--TRIMMABLE-BOUNDARY-START(60131246167)
            /*void */ InvokeChanged(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131246167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                name ??= $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                this._cache.Microsoft$Extensions$Options$IOptionsMonitorCache$$$TryRemove(name, [TOptions]);
                /*TOptions*/ let options = this.Get(name);
                this._onChange?.Invoke(options, name);
            }
            //--TRIMMABLE-BOUNDARY-END(60131246167)
            
            //--TRIMMABLE-BOUNDARY-START(38656409687)
            /*TOptions */ get CurrentValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541311575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get($.$meo.Microsoft.Extensions.Options.Options.DefaultName);
            }
            //--TRIMMABLE-BOUNDARY-END(38656409687)
            
            //--TRIMMABLE-BOUNDARY-START(55836278871)
            /*TOptions */ Get(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836278871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let optionsCache;
                if (!$.$is(this._cache, $.$meo.Microsoft.Extensions.Options.OptionsCache$$(TOptions), { set $v(v){ optionsCache = v; } }))
                {
                    /*string*/ let localName = name ?? $.$meo.Microsoft.Extensions.Options.Options.DefaultName;
                    /*IOptionsFactory<TOptions>*/ let localFactory = this._factory;
                    return this._cache.Microsoft$Extensions$Options$IOptionsMonitorCache$$$GetOrAdd(localName, new ($.$$.System.Func$$(TOptions))().$ctor(this,  () =>
                    {
                        return localFactory.Microsoft$Extensions$Options$IOptionsFactory$$$Create(localName, [TOptions]);
                    }, {
  "r": TOptions?.$h??1507328,
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}), [TOptions]);
                }
                return optionsCache.GetOrAdd$1($.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions), name, new ($.$$.System.Func$$$$($.$$.System.String, $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions), TOptions))().$ctor($.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions), /*static*/ (/**/ name, /*factory*/ factory) =>
                {
                    return factory.Microsoft$Extensions$Options$IOptionsFactory$$$Create(name, [TOptions]);
                }, {
  "r": TOptions?.$h??1507328,
  "p": [
    {
      "n": "name",
      "p": 1310721
    },
    {
      "n": "factory",
      "p": $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825826
}), this._factory);
            }
            //--TRIMMABLE-BOUNDARY-END(55836278871)
            
            //--TRIMMABLE-BOUNDARY-START(64426213463)
            /*IDisposable */ OnChange(/*Action<TOptions, string>*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426213463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let disposable = new ($.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).ChangeTrackerDisposable)().$ctor$1(this, listener);
                this.add__onChange(new ($.$$.System.Action$$$(TOptions, $.$$.System.String))().$ctor(disposable, disposable.OnChange));
                return disposable;
            }
            //--TRIMMABLE-BOUNDARY-END(64426213463)
            
            //--TRIMMABLE-BOUNDARY-START(42951376983)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951376983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._registrations.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var registration = $en2.Current;
                    {
                        registration.System$IDisposable$Dispose();
                    }
                }
                this._registrations.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(42951376983)
            
            //--TRIMMABLE-BOUNDARY-START(1769559)
            static $_ChangeTrackerDisposable;
            static get ChangeTrackerDisposable()
            {
                let $cls = $.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions);
                return $cls.$_ChangeTrackerDisposable ??= $asm.$ncls("$meo.Microsoft.Extensions.Options.OptionsMonitor$$.ChangeTrackerDisposable", ($self) => class ChangeTrackerDisposable extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296736855)
                    /*Action<TOptions, string>*/ _listener = null;
                    //--TRIMMABLE-BOUNDARY-END(4296736855)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591704151)
                    /*OptionsMonitor<TOptions>*/ _monitor = null;
                    //--TRIMMABLE-BOUNDARY-END(8591704151)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886671447)
                    $ctor$1(/*OptionsMonitor<TOptions>*/ monitor, /*Action<TOptions, string>*/ listener)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886671447);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._listener = listener;
                            this._monitor = monitor;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886671447)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476606039)
                    /*void */ OnChange(/*TOptions*/ options, /*string*/ name)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476606039);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._listener.Invoke(options, name);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476606039)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181638743)
                    /*void */ Dispose()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181638743);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._monitor.remove__onChange(new ($.$$.System.Action$$$(TOptions, $.$$.System.String))().$ctor(this, this.OnChange));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181638743)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    static $h = 1769559;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476606039),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "OnChange",
      "d": 1769559,
      "h": Number(BigInt(1769559)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476606039),
//--TRIMMABLE-BOUNDARY-START(17181638743),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1769559,
      "h": Number(BigInt(1769559)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181638743)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736855),
    {
      "t": $.$$.System.Action$$$(TOptions, $.$$.System.String).$h,
      "n": "_listener",
      "d": 1769559,
      "h": Number(BigInt(1769559)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736855),
//--TRIMMABLE-BOUNDARY-START(8591704151),
    {
      "t": $.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).$h,
      "n": "_monitor",
      "d": 1769559,
      "h": Number(BigInt(1769559)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704151)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886671447),
    {
      "p": [
        {
          "n": "monitor",
          "p": $.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).$h
        },
        {
          "n": "listener",
          "p": $.$$.System.Action$$$(TOptions, $.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769559,
      "h": Number(BigInt(1769559)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671447)
  ],
  "i": [90308609
  ],
  "d": $.$meo.Microsoft.Extensions.Options.OptionsMonitor$$(TOptions).$h,
  "h": 1769559
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Options.OptionsMonitor<${TOptions?.$fullName}>.ChangeTrackerDisposable`; }
                }, $cls, ($v) => $cls.$_ChangeTrackerDisposable = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1769559)
            
            //--TRIMMABLE-BOUNDARY-START(12885885015)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.CurrentValue.get
            get Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentValue;
            }
            //--TRIMMABLE-BOUNDARY-END(12885885015)
            
            //--TRIMMABLE-BOUNDARY-START(17180852311)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.Get(string?)
            Microsoft$Extensions$Options$IOptionsMonitor$$$Get()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180852311)
            
            //--TRIMMABLE-BOUNDARY-START(21475819607)
            //Generated interface implemetation for Microsoft.Extensions.Options.IOptionsMonitor<TOptions>.OnChange(System.Action<TOptions, string?>)
            Microsoft$Extensions$Options$IOptionsMonitor$$$OnChange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnChange(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819607)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17181573207)
                this._registrations = new ($.$$.System.Collections.Generic.List$$($.$$.System.IDisposable))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17181573207)
                
            }
            static $h = 1704023;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656409687),
    {
      "p": TOptions?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "CurrentValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656409687)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131246167),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "InvokeChanged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60131246167),
//--TRIMMABLE-BOUNDARY-START(55836278871),
    {
      "r": TOptions?.$h??1507328,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55836278871),
//--TRIMMABLE-BOUNDARY-START(64426213463),
    {
      "r": 90308609,
      "p": [
        {
          "n": "listener",
          "p": $.$$.System.Action$$$(TOptions, $.$$.System.String).$h
        }
      ],
      "n": "OnChange",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426213463),
//--TRIMMABLE-BOUNDARY-START(42951376983),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951376983)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296671319),
    {
      "t": $.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$(TOptions).$h,
      "n": "_cache",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671319),
//--TRIMMABLE-BOUNDARY-START(8591638615),
    {
      "t": $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h,
      "n": "_factory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638615),
//--TRIMMABLE-BOUNDARY-START(17181573207),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.IDisposable).$h,
      "n": "_registrations",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181573207)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771507799),
    {
      "p": [
        {
          "n": "factory",
          "p": $.$meo.Microsoft.Extensions.Options.IOptionsFactory$$(TOptions).$h
        },
        {
          "n": "sources",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$(TOptions)).$h
        },
        {
          "n": "cache",
          "p": $.$meo.Microsoft.Extensions.Options.IOptionsMonitorCache$$(TOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771507799)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(12886605911),
    {
      "e": $.$$.System.Action$$$(TOptions, $.$$.System.String).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.Action$$$(TOptions, $.$$.System.String).$h
          }
        ],
        "n": "add__onChange",
        "d": this.$h,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 150994952
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.Action$$$(TOptions, $.$$.System.String).$h
          }
        ],
        "n": "remove__onChange",
        "d": this.$h,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 285212680
      },
      "n": "_onChange",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 8388616
    },
//--TRIMMABLE-BOUNDARY-END(12886605911)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions).$h,90308609
  ],
  "g": [TOptions?.$h??1507328
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    }
  ],
  "j": [1769559
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$(TOptions), $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsMonitor<${TOptions?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1704023)
        
        
        //--TRIMMABLE-BOUNDARY-START(458839)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,>", (TOptions, TDep) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,>", [TOptions, TDep], ($self) => class ConfigureNamedOptions$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180328023)
            $ctor$1(/*string?*/ name, /*TDep*/ dependency, /*Action<TOptions, TDep>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180328023);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency = dependency;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328023)
            
            //--TRIMMABLE-BOUNDARY-START(64424968279)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(64424968279)
            
            //--TRIMMABLE-BOUNDARY-START(21475295319)
            /*Action<TOptions, TDep>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(21475295319)
            
            //--TRIMMABLE-BOUNDARY-START(34360197207)
            /*TDep*/ Dependency = $.$default(TDep);
            //--TRIMMABLE-BOUNDARY-END(34360197207)
            
            //--TRIMMABLE-BOUNDARY-START(25770262615)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770262615)
            
            //--TRIMMABLE-BOUNDARY-START(30065229911)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065229911);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065229911)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $h = 458839;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424968279),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424968279),
//--TRIMMABLE-BOUNDARY-START(21475295319),
    {
      "p": $.$$.System.Action$$$(TOptions, TDep).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475295319),
//--TRIMMABLE-BOUNDARY-START(34360197207),
    {
      "p": TDep?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Dependency",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360197207)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770262615),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770262615),
//--TRIMMABLE-BOUNDARY-START(30065229911),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229911)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180328023),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep?.$h??1572864
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$(TOptions, TDep).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180328023)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep?.$h??1572864
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep",
      "f": 1
    }
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458839)
        
        
        //--TRIMMABLE-BOUNDARY-START(393303)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,>", (TOptions, TDep1, TDep2) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,>", [TOptions, TDep1, TDep2], ($self) => class ConfigureNamedOptions$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475229783)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*Action<TOptions, TDep1, TDep2>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229783)
            
            //--TRIMMABLE-BOUNDARY-START(81604771927)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(81604771927)
            
            //--TRIMMABLE-BOUNDARY-START(25770197079)
            /*Action<TOptions, TDep1, TDep2>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(25770197079)
            
            //--TRIMMABLE-BOUNDARY-START(38655098967)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(38655098967)
            
            //--TRIMMABLE-BOUNDARY-START(42950066263)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(42950066263)
            
            //--TRIMMABLE-BOUNDARY-START(30065164375)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164375)
            
            //--TRIMMABLE-BOUNDARY-START(34360131671)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360131671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360131671)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $h = 393303;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604771927),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604771927),
//--TRIMMABLE-BOUNDARY-START(25770197079),
    {
      "p": $.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770197079),
//--TRIMMABLE-BOUNDARY-START(38655098967),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655098967),
//--TRIMMABLE-BOUNDARY-START(42950066263),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950066263)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065164375),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30065164375),
//--TRIMMABLE-BOUNDARY-START(34360131671),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360131671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475229783),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$$(TOptions, TDep1, TDep2).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475229783)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep1",
      "f": 1
    },
    {
      "n": "TDep2",
      "f": 1
    }
  ],
  "r": 3,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393303)
        
        
        //--TRIMMABLE-BOUNDARY-START(327767)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,>", (TOptions, TDep1, TDep2, TDep3) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,>", [TOptions, TDep1, TDep2, TDep3], ($self) => class ConfigureNamedOptions$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770131543)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*Action<TOptions, TDep1, TDep2, TDep3>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131543);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131543)
            
            //--TRIMMABLE-BOUNDARY-START(98784575575)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(98784575575)
            
            //--TRIMMABLE-BOUNDARY-START(30065098839)
            /*Action<TOptions, TDep1, TDep2, TDep3>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(30065098839)
            
            //--TRIMMABLE-BOUNDARY-START(42950000727)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(42950000727)
            
            //--TRIMMABLE-BOUNDARY-START(47244968023)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(47244968023)
            
            //--TRIMMABLE-BOUNDARY-START(51539935319)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(51539935319)
            
            //--TRIMMABLE-BOUNDARY-START(34360066135)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360066135)
            
            //--TRIMMABLE-BOUNDARY-START(38655033431)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655033431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655033431)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $h = 327767;
            static $g = 4;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784575575),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784575575),
//--TRIMMABLE-BOUNDARY-START(30065098839),
    {
      "p": $.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065098839),
//--TRIMMABLE-BOUNDARY-START(42950000727),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950000727),
//--TRIMMABLE-BOUNDARY-START(47244968023),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244968023),
//--TRIMMABLE-BOUNDARY-START(51539935319),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539935319)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360066135),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34360066135),
//--TRIMMABLE-BOUNDARY-START(38655033431),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033431)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770131543),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$$$(TOptions, TDep1, TDep2, TDep3).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131543)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep1",
      "f": 1
    },
    {
      "n": "TDep2",
      "f": 1
    },
    {
      "n": "TDep3",
      "f": 1
    }
  ],
  "r": 4,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327767)
        
        
        //--TRIMMABLE-BOUNDARY-START(262231)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4], ($self) => class ConfigureNamedOptions$$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065033303)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065033303);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065033303)
            
            //--TRIMMABLE-BOUNDARY-START(115964379223)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(115964379223)
            
            //--TRIMMABLE-BOUNDARY-START(34360000599)
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(34360000599)
            
            //--TRIMMABLE-BOUNDARY-START(47244902487)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(47244902487)
            
            //--TRIMMABLE-BOUNDARY-START(51539869783)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(51539869783)
            
            //--TRIMMABLE-BOUNDARY-START(55834837079)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(55834837079)
            
            //--TRIMMABLE-BOUNDARY-START(60129804375)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(60129804375)
            
            //--TRIMMABLE-BOUNDARY-START(38654967895)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654967895)
            
            //--TRIMMABLE-BOUNDARY-START(42949935191)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949935191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949935191)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $h = 262231;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964379223),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964379223),
//--TRIMMABLE-BOUNDARY-START(34360000599),
    {
      "p": $.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000599),
//--TRIMMABLE-BOUNDARY-START(47244902487),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244902487),
//--TRIMMABLE-BOUNDARY-START(51539869783),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539869783),
//--TRIMMABLE-BOUNDARY-START(55834837079),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837079),
//--TRIMMABLE-BOUNDARY-START(60129804375),
    {
      "p": TDep4?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129804375)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654967895),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38654967895),
//--TRIMMABLE-BOUNDARY-START(42949935191),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935191)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065033303),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1769472
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033303)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep1",
      "f": 1
    },
    {
      "n": "TDep2",
      "f": 1
    },
    {
      "n": "TDep3",
      "f": 1
    },
    {
      "n": "TDep4",
      "f": 1
    }
  ],
  "r": 5,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262231)
        
        
        //--TRIMMABLE-BOUNDARY-START(196695)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,,,>", (TOptions, TDep1, TDep2, TDep3, TDep4, TDep5) => $asm.$gt("$meo.Microsoft.Extensions.Options.ConfigureNamedOptions<,,,,,>", [TOptions, TDep1, TDep2, TDep3, TDep4, TDep5], ($self) => class ConfigureNamedOptions$$$$$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34359935063)
            $ctor$1(/*string?*/ name, /*TDep1*/ dependency1, /*TDep2*/ dependency2, /*TDep3*/ dependency3, /*TDep4*/ dependency4, /*TDep5*/ dependency5, /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ action)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359935063);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Action = action;
                    this.Dependency1 = dependency1;
                    this.Dependency2 = dependency2;
                    this.Dependency3 = dependency3;
                    this.Dependency4 = dependency4;
                    this.Dependency5 = dependency5;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935063)
            
            //--TRIMMABLE-BOUNDARY-START(133144182871)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(133144182871)
            
            //--TRIMMABLE-BOUNDARY-START(38654902359)
            /*Action<TOptions, TDep1, TDep2, TDep3, TDep4, TDep5>?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(38654902359)
            
            //--TRIMMABLE-BOUNDARY-START(51539804247)
            /*TDep1*/ Dependency1 = $.$default(TDep1);
            //--TRIMMABLE-BOUNDARY-END(51539804247)
            
            //--TRIMMABLE-BOUNDARY-START(55834771543)
            /*TDep2*/ Dependency2 = $.$default(TDep2);
            //--TRIMMABLE-BOUNDARY-END(55834771543)
            
            //--TRIMMABLE-BOUNDARY-START(60129738839)
            /*TDep3*/ Dependency3 = $.$default(TDep3);
            //--TRIMMABLE-BOUNDARY-END(60129738839)
            
            //--TRIMMABLE-BOUNDARY-START(64424706135)
            /*TDep4*/ Dependency4 = $.$default(TDep4);
            //--TRIMMABLE-BOUNDARY-END(64424706135)
            
            //--TRIMMABLE-BOUNDARY-START(68719673431)
            /*TDep5*/ Dependency5 = $.$default(TDep5);
            //--TRIMMABLE-BOUNDARY-END(68719673431)
            
            //--TRIMMABLE-BOUNDARY-START(42949869655)
            /*void */ Configure(/*string?*/ name, /*TOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(options, TOptions), "options");
                if ($.$$.System.String.op_Equality(this.Name, null) || $.$$.System.String.op_Equality(name, this.Name))
                {
                    this.Action?.Invoke(options, this.Dependency1, this.Dependency2, this.Dependency3, this.Dependency4, this.Dependency5);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949869655)
            
            //--TRIMMABLE-BOUNDARY-START(47244836951)
            /*void */ Configure$1(/*TOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244836951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Configure($.$meo.Microsoft.Extensions.Options.Options.DefaultName, options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244836951)
            
            //--TRIMMABLE-BOUNDARY-START(4295622743)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureNamedOptions<TOptions>.Configure(string?, TOptions)
            Microsoft$Extensions$Options$IConfigureNamedOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622743)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<TOptions>.Configure(TOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            static $h = 196695;
            static $g = 6;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144182871),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "n": "Name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144182871),
//--TRIMMABLE-BOUNDARY-START(38654902359),
    {
      "p": $.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Action",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654902359),
//--TRIMMABLE-BOUNDARY-START(51539804247),
    {
      "p": TDep1?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Dependency1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539804247),
//--TRIMMABLE-BOUNDARY-START(55834771543),
    {
      "p": TDep2?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "Dependency2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834771543),
//--TRIMMABLE-BOUNDARY-START(60129738839),
    {
      "p": TDep3?.$h??1703936,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "Dependency3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129738839),
//--TRIMMABLE-BOUNDARY-START(64424706135),
    {
      "p": TDep4?.$h??1769472,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "n": "Dependency4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424706135),
//--TRIMMABLE-BOUNDARY-START(68719673431),
    {
      "p": TDep5?.$h??1835008,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "n": "Dependency5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719673431)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949869655),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42949869655),
//--TRIMMABLE-BOUNDARY-START(47244836951),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": TOptions?.$h??1507328
        }
      ],
      "n": "Configure",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244836951)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34359935063),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "dependency1",
          "p": TDep1?.$h??1572864
        },
        {
          "n": "dependency2",
          "p": TDep2?.$h??1638400
        },
        {
          "n": "dependency3",
          "p": TDep3?.$h??1703936
        },
        {
          "n": "dependency4",
          "p": TDep4?.$h??1769472
        },
        {
          "n": "dependency5",
          "p": TDep5?.$h??1835008
        },
        {
          "n": "action",
          "p": $.$$.System.Action$$$$$$$(TOptions, TDep1, TDep2, TDep3, TDep4, TDep5).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359935063)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions).$h,$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions).$h
  ],
  "g": [TOptions?.$h??1507328,TDep1?.$h??1572864,TDep2?.$h??1638400,TDep3?.$h??1703936,TDep4?.$h??1769472,TDep5?.$h??1835008
  ],
  "s": [
    {
      "n": "TOptions",
      "f": 1
    },
    {
      "n": "TDep1",
      "f": 1
    },
    {
      "n": "TDep2",
      "f": 1
    },
    {
      "n": "TDep3",
      "f": 1
    },
    {
      "n": "TDep4",
      "f": 1
    },
    {
      "n": "TDep5",
      "f": 1
    }
  ],
  "r": 6,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureNamedOptions$$(TOptions), $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$(TOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.ConfigureNamedOptions<${TOptions?.$fullName},${TDep1?.$fullName},${TDep2?.$fullName},${TDep3?.$fullName},${TDep4?.$fullName},${TDep5?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196695)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966167)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsValidatorAttribute", ($self) => class OptionsValidatorAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296933463)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296933463)
            
            static $h = 1966167;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933463),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966167,
      "h": 4296933463,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933463)
  ],
  "h": 1966167,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 12,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsValidatorAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966167)
        
        
        //--TRIMMABLE-BOUNDARY-START(2687063)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateEnumeratedItemsAttribute", ($self) => class ValidateEnumeratedItemsAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592621655)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592621655);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592621655)
            
            //--TRIMMABLE-BOUNDARY-START(12887588951)
            $ctor$3(/*Type*/ validator)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887588951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Validator = validator;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887588951)
            
            //--TRIMMABLE-BOUNDARY-START(25772490839)
            /*Type?*/ Validator = null;
            //--TRIMMABLE-BOUNDARY-END(25772490839)
            
            static $h = 2687063;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772490839),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477523543,
        "f": 50331649
      },
      "n": "Validator",
      "d": 2687063,
      "h": 25772490839,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772490839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592621655),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687063,
      "h": 8592621655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592621655),
//--TRIMMABLE-BOUNDARY-START(12887588951),
    {
      "p": [
        {
          "n": "validator",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2687063,
      "h": 12887588951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887588951)
  ],
  "h": 2687063,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateEnumeratedItemsAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687063)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752599)
        $asm.$cls("$meo.Microsoft.Extensions.Options.ValidateObjectMembersAttribute", ($self) => class ValidateObjectMembersAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592687191)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592687191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592687191)
            
            //--TRIMMABLE-BOUNDARY-START(12887654487)
            $ctor$3(/*Type*/ validator)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887654487);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Validator = validator;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887654487)
            
            //--TRIMMABLE-BOUNDARY-START(25772556375)
            /*Type?*/ Validator = null;
            //--TRIMMABLE-BOUNDARY-END(25772556375)
            
            static $h = 2752599;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772556375),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477589079,
        "f": 50331649
      },
      "n": "Validator",
      "d": 2752599,
      "h": 25772556375,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772556375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592687191),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752599,
      "h": 8592687191,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592687191),
//--TRIMMABLE-BOUNDARY-START(12887654487),
    {
      "p": [
        {
          "n": "validator",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2752599,
      "h": 12887654487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887654487)
  ],
  "h": 2752599,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Options.ValidateObjectMembersAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752599)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900631)
        $asm.$cls("$meo.Microsoft.Extensions.Options.OptionsValidationException", ($self) => class OptionsValidationException extends $.$$.System.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(17181769815)
            $ctor$5(/*string*/ optionsName, /*Type*/ optionsType, /*IEnumerable<string>?*/ failureMessages)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181769815);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(optionsName, "optionsName");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(optionsType, "optionsType");
                    this.Failures = failureMessages ?? new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    this.OptionsType = optionsType;
                    this.OptionsName = optionsName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181769815)
            
            //--TRIMMABLE-BOUNDARY-START(64426410071)
            /*string*/ OptionsName = null;
            //--TRIMMABLE-BOUNDARY-END(64426410071)
            
            //--TRIMMABLE-BOUNDARY-START(68721377367)
            /*Type*/ OptionsType = null;
            //--TRIMMABLE-BOUNDARY-END(68721377367)
            
            //--TRIMMABLE-BOUNDARY-START(21476737111)
            /*IEnumerable<string>*/ Failures = null;
            //--TRIMMABLE-BOUNDARY-END(21476737111)
            
            //--TRIMMABLE-BOUNDARY-START(60131442775)
            /*string */ get Message()
            {
                return $.$$.System.String.Join$5("; ", this.Failures);
            }
            //--TRIMMABLE-BOUNDARY-END(60131442775)
            
            static $h = 1900631;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 80019457,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64426410071),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246540887,
        "f": 50331649
      },
      "n": "OptionsName",
      "d": 1900631,
      "h": 64426410071,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426410071),
//--TRIMMABLE-BOUNDARY-START(68721377367),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836475479,
        "f": 50331649
      },
      "n": "OptionsType",
      "d": 1900631,
      "h": 68721377367,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721377367),
//--TRIMMABLE-BOUNDARY-START(21476737111),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066671703,
        "f": 50331649
      },
      "n": "Failures",
      "d": 1900631,
      "h": 21476737111,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476737111),
//--TRIMMABLE-BOUNDARY-START(60131442775),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656606295,
        "f": 50364417
      },
      "n": "Message",
      "d": 1900631,
      "h": 60131442775,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60131442775)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181769815),
    {
      "p": [
        {
          "n": "optionsName",
          "p": 1310721
        },
        {
          "n": "optionsType",
          "p": 187760641
        },
        {
          "n": "failureMessages",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1900631,
      "h": 17181769815,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769815)
  ],
  "i": [157483009
  ],
  "h": 1900631
}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `Microsoft.Extensions.Options.OptionsValidationException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900631)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations"))
//--TRIMMABLE-BOUNDARY-END(87)
