
//--TRIMMABLE-BOUNDARY-START(85)
(async function () {
(function ($global, $, $$, $sm) {
    "use strict";
    let _;
    let $jrucrb;
    let $PudJoe;
    let $otcrZk;
    let $oLNQcb;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Primitives", 
    {
  "h": 85,
  "f": "Microsoft.Extensions.Primitives",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Primitives",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Primitives",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(720981)
        $asm.$cls(`$mep.MEP.IChangeToken`, ($self) => class IChangeToken
        {
            static $h = 720981;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770524757),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475557461,
        "f": 50331905
      },
      "n": "HasChanged",
      "o": "MEP$IChangeToken$HasChanged",
      "d": 720981,
      "h": 25770524757,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770524757),
//--TRIMMABLE-BOUNDARY-START(4295688277),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885622869,
        "f": 50331905
      },
      "n": "ActiveChangeCallbacks",
      "o": "MEP$IChangeToken$ActiveChangeCallbacks",
      "d": 720981,
      "h": 4295688277,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295688277)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065492053),
    {
      "r": 91095041,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterChangeCallback",
      "o": "MEP$IChangeToken$RegisterChangeCallback",
      "d": 720981,
      "h": 30065492053,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065492053)
  ],
  "h": 720981
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.IChangeToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}IChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720981)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441877)
        $asm.$cls(`$mep.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(158915231829)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(158915231829)
            
            //--TRIMMABLE-BOUNDARY-START(150325297237)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(150325297237)
            
            //--TRIMMABLE-BOUNDARY-START(154620264533)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145428053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mep.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Primitives", $.$mep.S.SR.$type.Assembly);
                    $.$mep.S.SR.s_resourceManager = temp;
                }
                return $.$mep.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(154620264533)
            
            //--TRIMMABLE-BOUNDARY-START(30066212949)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555493461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800133717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mep.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212949)
            
            //--TRIMMABLE-BOUNDARY-START(8591376469)
            static /*string */ get Argument_InvalidOffsetLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length are out of bounds for the string or length is greater than the number of characters from index to the end of the string.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591376469)
            
            //--TRIMMABLE-BOUNDARY-START(12886343765)
            static /*string */ get Argument_InvalidOffsetLengthStringSegment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195755093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length are out of bounds for this StringSegment or length is greater than the number of characters to the end of this StringSegment.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886343765)
            
            //--TRIMMABLE-BOUNDARY-START(17181311061)
            static /*string */ get Capacity_CannotChangeAfterWriteStarted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot change capacity after write started.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181311061)
            
            //--TRIMMABLE-BOUNDARY-START(21476278357)
            static /*string */ get Capacity_NotEnough()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375624277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Not enough capacity to write '{0}' characters, only '{1}' left.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476278357)
            
            //--TRIMMABLE-BOUNDARY-START(68720918613)
            static /*string */ FormatCapacity_NotEnough(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720918613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Not enough capacity to write '{0}' characters, only '{1}' left.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(68720918613)
            
            //--TRIMMABLE-BOUNDARY-START(25771245653)
            static /*string */ get Capacity_NotUsedEntirely()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965558869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Entire reserved capacity was not used. Capacity: '{0}', written '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771245653)
            
            //--TRIMMABLE-BOUNDARY-START(73015885909)
            static /*string */ FormatCapacity_NotUsedEntirely(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Entire reserved capacity was not used. Capacity: '{0}', written '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(73015885909)
            
            //--TRIMMABLE-BOUNDARY-START(163210199125)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(163210199125)
            
            //--TRIMMABLE-BOUNDARY-START(146030329941)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030329941);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030329941)
            
            //--TRIMMABLE-BOUNDARY-START(176095101013)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176095101013);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095101013)
            
            //--TRIMMABLE-BOUNDARY-START(141735362645)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735362645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mep.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(141735362645)
            
            //--TRIMMABLE-BOUNDARY-START(137440395349)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440395349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mep.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(137440395349)
            
            //--TRIMMABLE-BOUNDARY-START(60130984021)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130984021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(60130984021)
            
            //--TRIMMABLE-BOUNDARY-START(55836016725)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(55836016725)
            
            //--TRIMMABLE-BOUNDARY-START(51541049429)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(51541049429)
            
            //--TRIMMABLE-BOUNDARY-START(64425951317)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mep.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(64425951317)
            
            //--TRIMMABLE-BOUNDARY-START(42951114837)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42951114837)
            
            //--TRIMMABLE-BOUNDARY-START(38656147541)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38656147541)
            
            //--TRIMMABLE-BOUNDARY-START(34361180245)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34361180245)
            
            //--TRIMMABLE-BOUNDARY-START(47246082133)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mep.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47246082133)
            
            //--TRIMMABLE-BOUNDARY-START(4296409173)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(163210199125)
                    this.s_usingResourceKeys = $.$mep.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(163210199125)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296409173)
            
            static $h = 1441877;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1441877
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441877)
        
        

        //--TRIMMABLE-BOUNDARY-START(655445)
        $asm.$cls(`$mep.MEP.Extensions`, ($self) => class Extensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295622741)
            static /*StringBuilder */ Append(/*this StringBuilder*/ builder, /*StringSegment*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return builder.Append$20(segment.Buffer, segment.Offset, segment.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(4295622741)
            
            static $h = 655445;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295622741),
    {
      "r": 167837697,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        },
        {
          "n": "segment",
          "p": 852053
        }
      ],
      "n": "Append",
      "d": 655445,
      "h": 4295622741,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295622741)
  ],
  "h": 655445
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.Extensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}Extensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655445)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310805)
        $asm.$cls(`$mep.MEP.ThrowHelper`, ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(30066081877)
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentNullException().$ctor$19($.$mep.MEP.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(30066081877)
            
            //--TRIMMABLE-BOUNDARY-START(34361049173)
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$mep.MEP.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(34361049173)
            
            //--TRIMMABLE-BOUNDARY-START(25771114581)
            static /*void */ ThrowArgumentException(/*ExceptionResource*/ resource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771114581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentException().$ctor$14($.$mep.MEP.ThrowHelper.GetResourceText(resource));
            }
            //--TRIMMABLE-BOUNDARY-END(25771114581)
            
            //--TRIMMABLE-BOUNDARY-START(42950983765)
            static /*void */ ThrowInvalidOperationException$1(/*ExceptionResource*/ resource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mep.MEP.ThrowHelper.GetResourceText(resource));
            }
            //--TRIMMABLE-BOUNDARY-END(42950983765)
            
            //--TRIMMABLE-BOUNDARY-START(38656016469)
            static /*void */ ThrowInvalidOperationException(/*ExceptionResource*/ resource, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656016469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let message = $.$$.S.String.Format$10($.$mep.MEP.ThrowHelper.GetResourceText(resource), args);
                throw new $.$$.S.InvalidOperationException().$ctor$12(message);
            }
            //--TRIMMABLE-BOUNDARY-END(38656016469)
            
            //--TRIMMABLE-BOUNDARY-START(12886212693)
            static /*ArgumentNullException */ GetArgumentNullException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentNullException().$ctor$19($.$mep.MEP.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(12886212693)
            
            //--TRIMMABLE-BOUNDARY-START(17181179989)
            static /*ArgumentOutOfRangeException */ GetArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181179989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$mep.MEP.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(17181179989)
            
            //--TRIMMABLE-BOUNDARY-START(4296278101)
            static /*ArgumentException */ GetArgumentException(/*ExceptionResource*/ resource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentException().$ctor$14($.$mep.MEP.ThrowHelper.GetResourceText(resource));
            }
            //--TRIMMABLE-BOUNDARY-END(4296278101)
            
            //--TRIMMABLE-BOUNDARY-START(21476147285)
            static /*string */ GetResourceText(/*ExceptionResource*/ resource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.S.Enum.IsDefined($.$mep.MEP.ExceptionResource.$type, $.$box(resource, $.$mep.MEP.ExceptionResource)), "The enum value is not defined, please check the ExceptionResource Enum.");
                switch(resource)
                {
                    case 0/*ExceptionResource.Argument_InvalidOffsetLength*/:
                    return $.$mep.S.SR.Argument_InvalidOffsetLength;
                    case 1/*ExceptionResource.Argument_InvalidOffsetLengthStringSegment*/:
                    return $.$mep.S.SR.Argument_InvalidOffsetLengthStringSegment;
                    case 2/*ExceptionResource.Capacity_CannotChangeAfterWriteStarted*/:
                    return $.$mep.S.SR.Capacity_CannotChangeAfterWriteStarted;
                    case 3/*ExceptionResource.Capacity_NotEnough*/:
                    return $.$mep.S.SR.Capacity_NotEnough;
                    case 4/*ExceptionResource.Capacity_NotUsedEntirely*/:
                    return $.$mep.S.SR.Capacity_NotUsedEntirely;
                    default:
                    $.$$.SD.Debug.Fail$1(`Unexpected resource ${$.$strNN($.$$.S.Enum.ToStringT($.$mep.MEP.ExceptionResource, $.$$.S.UInt32, resource))}`);
                    return "";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476147285)
            
            //--TRIMMABLE-BOUNDARY-START(8591245397)
            static /*string */ GetArgumentName(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.S.Enum.IsDefined($.$mep.MEP.ExceptionArgument.$type, $.$box(argument, $.$mep.MEP.ExceptionArgument)), "The enum value is not defined, please check the ExceptionArgument Enum.");
                return $.$$.S.Enum.ToStringT($.$mep.MEP.ExceptionArgument, $.$$.S.UInt32, argument);
            }
            //--TRIMMABLE-BOUNDARY-END(8591245397)
            
            static $h = 1310805;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066081877),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 524373
        }
      ],
      "n": "ThrowArgumentNullException",
      "d": 1310805,
      "h": 30066081877,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30066081877),
//--TRIMMABLE-BOUNDARY-START(34361049173),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 524373
        }
      ],
      "n": "ThrowArgumentOutOfRangeException",
      "d": 1310805,
      "h": 34361049173,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34361049173),
//--TRIMMABLE-BOUNDARY-START(25771114581),
    {
      "r": 65537,
      "p": [
        {
          "n": "resource",
          "p": 589909
        }
      ],
      "n": "ThrowArgumentException",
      "d": 1310805,
      "h": 25771114581,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25771114581),
//--TRIMMABLE-BOUNDARY-START(42950983765),
    {
      "r": 65537,
      "p": [
        {
          "n": "resource",
          "p": 589909
        }
      ],
      "n": "ThrowInvalidOperationException",
      "o": "@$1",
      "d": 1310805,
      "h": 42950983765,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950983765),
//--TRIMMABLE-BOUNDARY-START(38656016469),
    {
      "r": 65537,
      "p": [
        {
          "n": "resource",
          "p": 589909
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "ThrowInvalidOperationException",
      "d": 1310805,
      "h": 38656016469,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38656016469),
//--TRIMMABLE-BOUNDARY-START(12886212693),
    {
      "r": 45023233,
      "p": [
        {
          "n": "argument",
          "p": 524373
        }
      ],
      "n": "GetArgumentNullException",
      "d": 1310805,
      "h": 12886212693,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886212693),
//--TRIMMABLE-BOUNDARY-START(17181179989),
    {
      "r": 45088769,
      "p": [
        {
          "n": "argument",
          "p": 524373
        }
      ],
      "n": "GetArgumentOutOfRangeException",
      "d": 1310805,
      "h": 17181179989,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17181179989),
//--TRIMMABLE-BOUNDARY-START(4296278101),
    {
      "r": 44957697,
      "p": [
        {
          "n": "resource",
          "p": 589909
        }
      ],
      "n": "GetArgumentException",
      "d": 1310805,
      "h": 4296278101,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296278101),
//--TRIMMABLE-BOUNDARY-START(21476147285),
    {
      "r": 1310721,
      "p": [
        {
          "n": "resource",
          "p": 589909
        }
      ],
      "n": "GetResourceText",
      "d": 1310805,
      "h": 21476147285,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476147285),
//--TRIMMABLE-BOUNDARY-START(8591245397),
    {
      "r": 1310721,
      "p": [
        {
          "n": "argument",
          "p": 524373
        }
      ],
      "n": "GetArgumentName",
      "d": 1310805,
      "h": 8591245397,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8591245397)
  ],
  "h": 1310805
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.ThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310805)
        
        

        //--TRIMMABLE-BOUNDARY-START(131157)
        $asm.$cls(`$mep.MEI.ChangeCallbackRegistrar`, ($self) => class ChangeCallbackRegistrar
        {
            //--TRIMMABLE-BOUNDARY-START(4295098453)
            static /*IDisposable */ UnsafeRegisterChangeCallback(T, /*Action<object?>*/ callback, /*object?*/ state, /*CancellationToken*/ token, /*Action<T>*/ onFailure, /*T*/ onFailureState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return token.UnsafeRegister$1(callback, state);
                }
                catch($e)
                {
                    onFailure.Invoke(onFailureState);
                }
                return $.$mep.MEF.EmptyDisposable.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098453)
            
            static $h = 131157;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098453),
    {
      "r": 91095041,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "token",
          "p": 170852353
        },
        {
          "n": "onFailure",
          "p": (T) => $.$$.S.Action$$(T).$h
        },
        {
          "n": "onFailureState",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "UnsafeRegisterChangeCallback",
      "d": 131157,
      "h": 4295098453,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295098453)
  ],
  "h": 131157
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.ChangeCallbackRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}ChangeCallbackRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131157)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376341)
        $asm.$cls(`$mep.SNH.HashHelpers`, ($self) => class HashHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(4296343637)
            static /*int */ Combine(/*int*/ h1, /*int*/ h2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let rol5 = (((h1 >>> 0) << 5) >>> 0) | ((h1 >>> 0) >>> 27);
                return ((((rol5 | 0) + h1) | 0)) ^ h2;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343637)
            
            static $h = 1376341;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296343637),
    {
      "r": 655361,
      "p": [
        {
          "n": "h1",
          "p": 655361
        },
        {
          "n": "h2",
          "p": 655361
        }
      ],
      "n": "Combine",
      "d": 1376341,
      "h": 4296343637,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296343637)
  ],
  "h": 1376341
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Numerics.Hashing.HashHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Numerics${separator}Hashing${separator}HashHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376341)
        
        

        //--TRIMMABLE-BOUNDARY-START(262229)
        $asm.$cls(`$mep.MEP.ChangeToken`, ($self) => class ChangeToken
        {
            //--TRIMMABLE-BOUNDARY-START(4295229525)
            static /*IDisposable */ OnChange(/*Func<IChangeToken?>*/ changeTokenProducer, /*Action*/ changeTokenConsumer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (changeTokenProducer === null)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.changeTokenProducer*/);
                }
                if (changeTokenConsumer === null)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.changeTokenConsumer*/);
                }
                return new ($.$mep.MEP.ChangeToken.ChangeTokenRegistration$$($.$$.S.Action))().$ctor$1(changeTokenProducer, new ($.$$.S.Action$$($.$$.S.Action))().$ctor(this,  (/*callback*/ callback) =>
                {
                    return callback.Invoke();
                }, $PudJoe ??= {"r":65537,"p":[{"n":"callback","p":43122689}],"n":"","d":262229,"h":0,"f":17825794}), changeTokenConsumer);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229525)
            
            //--TRIMMABLE-BOUNDARY-START(8590196821)
            static /*IDisposable */ OnChange$1(TState, /*Func<IChangeToken?>*/ changeTokenProducer, /*Action<TState>*/ changeTokenConsumer, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (changeTokenProducer === null)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.changeTokenProducer*/);
                }
                if (changeTokenConsumer === null)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.changeTokenConsumer*/);
                }
                return new ($.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState))().$ctor$1(changeTokenProducer, changeTokenConsumer, state);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196821)
            
            //--TRIMMABLE-BOUNDARY-START(327765)
            static $_ChangeTokenRegistration$$;
            static ChangeTokenRegistration$$(TState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mep.MEP.ChangeToken;
                return ($cls.$_ChangeTokenRegistration$$ ??= $asm.$ncls(`$mep.MEP.ChangeToken.ChangeTokenRegistration<>`, (TState) => $asm.$gt(`$mep.MEP.ChangeToken.ChangeTokenRegistration<>`, [TState], ($self) => class ChangeTokenRegistration$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590262357)
                    /*Func<IChangeToken?>*/ _changeTokenProducer = null;
                    //--TRIMMABLE-BOUNDARY-END(8590262357)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295295061)
                    /*Action<TState>*/ _changeTokenConsumer = null;
                    //--TRIMMABLE-BOUNDARY-END(4295295061)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475164245)
                    /*TState*/ _state = $.$default(TState);
                    //--TRIMMABLE-BOUNDARY-END(21475164245)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885229653)
                    /*IDisposable?*/ _disposable = null;
                    //--TRIMMABLE-BOUNDARY-END(12885229653)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180196949)
                    /*NoopDisposable*/ static _disposedSentinel = null;
                    //--TRIMMABLE-BOUNDARY-END(17180196949)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065098837)
                    $ctor$1(/*Func<IChangeToken?>*/ changeTokenProducer, /*Action<TState>*/ changeTokenConsumer, /*TState*/ state)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065098837);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._changeTokenProducer = changeTokenProducer;
                            this._changeTokenConsumer = changeTokenConsumer;
                            this._state = state;
                            /*IChangeToken?*/ let token = changeTokenProducer.Invoke();
                            this.RegisterChangeTokenCallback(token);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065098837)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655033429)
                    /*void */ OnChangeTokenFired()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655033429);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*IChangeToken?*/ let token = this._changeTokenProducer.Invoke();
                        try
                        {
                            this._changeTokenConsumer.Invoke(this._state);
                        }
                        finally
                        {
                            {
                                this.RegisterChangeTokenCallback(token);
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655033429)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950000725)
                    /*void */ RegisterChangeTokenCallback(/*IChangeToken?*/ token)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950000725);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (token === null)
                        {
                            return;
                        }
                        /*IDisposable*/ let registraton = token.MEP$IChangeToken$RegisterChangeCallback(new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/**/ s) =>
                        {
                            return ($.$cast(s, $.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState))).OnChangeTokenFired();
                        }, $otcrZk ??= {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), this);
                        if (token.MEP$IChangeToken$HasChanged && token.MEP$IChangeToken$ActiveChangeCallbacks)
                        {
                            registraton?.S$IDisposable$Dispose();
                            return;
                        }
                        this.SetDisposable(registraton);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950000725)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244968021)
                    /*void */ SetDisposable(/*IDisposable*/ disposable)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47244968021);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*IDisposable?*/ let current = $.$ref(() => this._disposable, ($v) => this._disposable = $v, $.$$.S.IDisposable).$v;
                        if (current === $.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState)._disposedSentinel)
                        {
                            disposable.S$IDisposable$Dispose();
                            return;
                        }
                        /*IDisposable?*/ let previous = $.$$.ST$1.Interlocked.CompareExchange$14($.$$.S.IDisposable, $.$ref(() => this._disposable, ($v) => this._disposable = $v, $.$$.S.IDisposable), disposable, current);
                        if (previous === $.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState)._disposedSentinel)
                        {
                            disposable.S$IDisposable$Dispose();
                        }
                        else if (previous === current)
                        {
                        }
                        else 
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("Somebody else set the _disposable field");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47244968021)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360066133)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360066133);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.ST$1.Interlocked.Exchange$14($.$$.S.IDisposable, $.$ref(() => this._disposable, ($v) => this._disposable = $v, $.$$.S.IDisposable), $.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState)._disposedSentinel)?.S$IDisposable$Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360066133)
                    
                    //--TRIMMABLE-BOUNDARY-START(393301)
                    static $_NoopDisposable;
                    static get NoopDisposable()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(393301);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState);
                        return $cls.$_NoopDisposable ??= $asm.$ncls(`$mep.MEP.ChangeToken.ChangeTokenRegistration<${TState?.$fullName}>.NoopDisposable`, ($self) => class NoopDisposable extends $.$$.S.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(8590327893)
                            /*void */ Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(8590327893);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                            }
                            //--TRIMMABLE-BOUNDARY-END(8590327893)
                            
                            //--TRIMMABLE-BOUNDARY-START(4386062337)
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            S$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4386062337);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Dispose(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4386062337)
                            
                            //--TRIMMABLE-BOUNDARY-START(4295360597)
                            //default constructor overload
                            $ctor$1()
                            {
                                super.$ctor();
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4295360597);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4295360597)
                            
                            //--TRIMMABLE-BOUNDARY-START(4295360597)
                            //generic new constructor
                            $gctor()
                            {
                                return this.$ctor$1();
                            }
                            //--TRIMMABLE-BOUNDARY-END(4295360597)
                            
                            static $H = 393301;
                            static $h = 393301;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$$.S.Object; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327893),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 393301,
      "H": 8590327893,
      "h": Number(BigInt(393301)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327893)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360597),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393301,
      "H": 4295360597,
      "h": Number(BigInt(393301)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360597)
  ],
  "d": 327765,
  "H": 393301,
  "h": 393301
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.ChangeToken+ChangeTokenRegistration<${TState?.$fullName}>+NoopDisposable`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}ChangeToken${separator}ChangeTokenRegistration$${TState?.$getFullName(separator)}$${separator}NoopDisposable`; }
                        }, $cls, ($v) => $cls.$_NoopDisposable = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(393301)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770131541)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770131541);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17180196949)
                            this._disposedSentinel = new ($.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState).NoopDisposable)().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(17180196949)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770131541)
                    
                    static $H = 327765;
                    static $h = 327765;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655033429),
    {
      "r": 65537,
      "n": "OnChangeTokenFired",
      "d": this.$h,
      "H": 38655033429,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655033429),
//--TRIMMABLE-BOUNDARY-START(42950000725),
    {
      "r": 65537,
      "p": [
        {
          "n": "token",
          "p": 720981
        }
      ],
      "n": "RegisterChangeTokenCallback",
      "d": this.$h,
      "H": 42950000725,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950000725),
//--TRIMMABLE-BOUNDARY-START(47244968021),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposable",
          "p": 91095041
        }
      ],
      "n": "SetDisposable",
      "d": this.$h,
      "H": 47244968021,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244968021),
//--TRIMMABLE-BOUNDARY-START(34360066133),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 34360066133,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066133)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590262357),
    {
      "t": $.$$.S.Func$$($.$mep.MEP.IChangeToken).$h,
      "n": "_changeTokenProducer",
      "d": this.$h,
      "H": 8590262357,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262357),
//--TRIMMABLE-BOUNDARY-START(4295295061),
    {
      "t": $.$$.S.Action$$(TState).$h,
      "n": "_changeTokenConsumer",
      "d": this.$h,
      "H": 4295295061,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295061),
//--TRIMMABLE-BOUNDARY-START(21475164245),
    {
      "t": TState?.$h??1572864,
      "n": "_state",
      "d": this.$h,
      "H": 21475164245,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475164245),
//--TRIMMABLE-BOUNDARY-START(12885229653),
    {
      "t": 91095041,
      "n": "_disposable",
      "d": this.$h,
      "H": 12885229653,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885229653),
//--TRIMMABLE-BOUNDARY-START(17180196949),
    {
      "t": 393301,
      "n": "_disposedSentinel",
      "d": this.$h,
      "H": 17180196949,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180196949)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065098837),
    {
      "p": [
        {
          "n": "changeTokenProducer",
          "p": $.$$.S.Func$$($.$mep.MEP.IChangeToken).$h
        },
        {
          "n": "changeTokenConsumer",
          "p": $.$$.S.Action$$(TState).$h
        },
        {
          "n": "state",
          "p": TState?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 30065098837,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098837)
  ],
  "s": [
    {
      "h": TState?.$h??1572864,
      "n": "TState"
    }
  ],
  "r": 1,
  "d": 262229,
  "H": 327765,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState).NoopDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.ChangeToken+ChangeTokenRegistration<${TState?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}ChangeToken${separator}ChangeTokenRegistration$${TState?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_ChangeTokenRegistration$$ = $v))(TState);
            }
            //--TRIMMABLE-BOUNDARY-END(327765)
            
            static $h = 262229;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229525),
    {
      "r": 91095041,
      "p": [
        {
          "n": "changeTokenProducer",
          "p": $.$$.S.Func$$($.$mep.MEP.IChangeToken).$h
        },
        {
          "n": "changeTokenConsumer",
          "p": 43122689
        }
      ],
      "n": "OnChange",
      "d": 262229,
      "h": 4295229525,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295229525),
//--TRIMMABLE-BOUNDARY-START(8590196821),
    {
      "r": 91095041,
      "p": [
        {
          "n": "changeTokenProducer",
          "p": $.$$.S.Func$$($.$mep.MEP.IChangeToken).$h
        },
        {
          "n": "changeTokenConsumer",
          "p": (TState) => $.$$.S.Action$$(TState).$h
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "OnChange",
      "o": "@$1",
      "d": 262229,
      "h": 8590196821,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590196821)
  ],
  "h": 262229
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mep.MEP.ChangeToken.ChangeTokenRegistration$$(TState) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.ChangeToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}ChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262229)
        
        

        //--TRIMMABLE-BOUNDARY-START(196693)
        $asm.$cls(`$mep.MEP.CancellationChangeToken`, ($self) => class CancellationChangeToken extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885098581)
            $ctor$1(/*CancellationToken*/ cancellationToken)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098581);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Token = cancellationToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098581)
            
            //--TRIMMABLE-BOUNDARY-START(17180065877)
            /*bool*/ ActiveChangeCallbacks = false;
            //--TRIMMABLE-BOUNDARY-END(17180065877)
            
            //--TRIMMABLE-BOUNDARY-START(47244836949)
            /*bool */ get HasChanged()
            {
                return this.Token.IsCancellationRequested;
            }
            //--TRIMMABLE-BOUNDARY-END(47244836949)
            
            //--TRIMMABLE-BOUNDARY-START(64424706133)
            /*CancellationToken*/ Token;
            //--TRIMMABLE-BOUNDARY-END(64424706133)
            
            //--TRIMMABLE-BOUNDARY-START(51539804245)
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.MEI.ChangeCallbackRegistrar.UnsafeRegisterChangeCallback($.$mep.MEP.CancellationChangeToken, callback, state, this.Token, new ($.$$.S.Action$$($.$mep.MEP.CancellationChangeToken))().$ctor($.$mep.MEP.CancellationChangeToken, /*static*/ (/*s*/ s) =>
                {
                    return s.ActiveChangeCallbacks = false;
                }, $jrucrb ??= {"r":65537,"p":[{"n":"s","p":196693}],"n":"","d":196693,"h":0,"f":17825826}), this);
            }
            //--TRIMMABLE-BOUNDARY-END(51539804245)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get MEP$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get MEP$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //--TRIMMABLE-BOUNDARY-START(30065492053)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            MEP$IChangeToken$RegisterChangeCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterChangeCallback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492053)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180065877)
                this.ActiveChangeCallbacks = true;
                //--TRIMMABLE-BOUNDARY-END(17180065877)
                
                //--TRIMMABLE-BOUNDARY-START(64424706133)
                this.Token = $.$default($.$$.ST$1.CancellationToken);
                //--TRIMMABLE-BOUNDARY-END(64424706133)
                
            }
            static $h = 196693;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180065877),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770000469,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129738837,
        "f": 83886082
      },
      "n": "ActiveChangeCallbacks",
      "d": 196693,
      "h": 17180065877,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180065877),
//--TRIMMABLE-BOUNDARY-START(47244836949),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359935061,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 196693,
      "h": 47244836949,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244836949),
//--TRIMMABLE-BOUNDARY-START(64424706133),
    {
      "p": 170852353,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869653,
        "f": 50331650
      },
      "n": "Token",
      "d": 196693,
      "h": 64424706133,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64424706133)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539804245),
    {
      "r": 91095041,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterChangeCallback",
      "d": 196693,
      "h": 51539804245,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539804245)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098581),
    {
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196693,
      "h": 12885098581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098581)
  ],
  "h": 196693,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "HasChanged = {HasChanged}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.MEP.IChangeToken ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.CancellationChangeToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}CancellationChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196693)
        
        

        //--TRIMMABLE-BOUNDARY-START(458837)
        $asm.$cls(`$mep.MEP.CompositeChangeToken`, ($self) => class CompositeChangeToken extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180328021)
            /*Action<object?>*/ static _onChangeDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(17180328021)
            
            //--TRIMMABLE-BOUNDARY-START(4295426133)
            /*object*/ _callbackLock = null;
            //--TRIMMABLE-BOUNDARY-END(4295426133)
            
            //--TRIMMABLE-BOUNDARY-START(8590393429)
            /*CancellationTokenSource?*/ _cancellationTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(8590393429)
            
            //--TRIMMABLE-BOUNDARY-START(12885360725)
            /*List<IDisposable>?*/ _disposables = null;
            //--TRIMMABLE-BOUNDARY-END(12885360725)
            
            //--TRIMMABLE-BOUNDARY-START(103079673941)
            /*bool*/ RegisteredCallbackProxy = false;
            //--TRIMMABLE-BOUNDARY-END(103079673941)
            
            //--TRIMMABLE-BOUNDARY-START(38655164501)
            $ctor$1(/*IReadOnlyList<IChangeToken>*/ changeTokens)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655164501);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (changeTokens === null)
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.changeTokens*/);
                    }
                    this.ChangeTokens = changeTokens;
                    for(/*int*/ let i = 0; i < this.ChangeTokens.SCG$IReadOnlyCollection$$$Count; i++)
                    {
                        if (this.ChangeTokens.SCG$IReadOnlyList$$$get_Item(i).MEP$IChangeToken$ActiveChangeCallbacks)
                        {
                            this.ActiveChangeCallbacks = true;
                            break;
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655164501)
            
            //--TRIMMABLE-BOUNDARY-START(47245099093)
            /*IReadOnlyList<IChangeToken>*/ ChangeTokens = null;
            //--TRIMMABLE-BOUNDARY-END(47245099093)
            
            //--TRIMMABLE-BOUNDARY-START(98784706645)
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureCallbacksInitialized();
                return this._cancellationTokenSource.Token.Register$4(callback, state);
            }
            //--TRIMMABLE-BOUNDARY-END(98784706645)
            
            //--TRIMMABLE-BOUNDARY-START(90194772053)
            /*bool */ get HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._cancellationTokenSource !== null && this._cancellationTokenSource.Token.IsCancellationRequested)
                {
                    return true;
                }
                for(/*int*/ let i = 0; i < this.ChangeTokens.SCG$IReadOnlyCollection$$$Count; i++)
                {
                    if (this.ChangeTokens.SCG$IReadOnlyList$$$get_Item(i).MEP$IChangeToken$HasChanged)
                    {
                        $.$mep.MEP.CompositeChangeToken.OnChange(this);
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(90194772053)
            
            //--TRIMMABLE-BOUNDARY-START(42950131797)
            /*bool*/ ActiveChangeCallbacks = false;
            //--TRIMMABLE-BOUNDARY-END(42950131797)
            
            //--TRIMMABLE-BOUNDARY-START(51540066389)
            /*void */ EnsureCallbacksInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.RegisteredCallbackProxy)
                {
                    return;
                }
                //lock(_callbackLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._callbackLock)
                    {
                        if (this.RegisteredCallbackProxy)
                        {
                            return;
                        }
                        this._cancellationTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                        this._disposables = new ($.$$.SCG.List$$($.$$.S.IDisposable))().$ctor$1();
                        for(/*int*/ let i = 0; i < this.ChangeTokens.SCG$IReadOnlyCollection$$$Count; i++)
                        {
                            if (this.ChangeTokens.SCG$IReadOnlyList$$$get_Item(i).MEP$IChangeToken$ActiveChangeCallbacks)
                            {
                                /*IDisposable*/ let disposable = this.ChangeTokens.SCG$IReadOnlyList$$$get_Item(i).MEP$IChangeToken$RegisterChangeCallback($.$mep.MEP.CompositeChangeToken._onChangeDelegate, this);
                                if (this._cancellationTokenSource.IsCancellationRequested)
                                {
                                    disposable.S$IDisposable$Dispose();
                                    break;
                                }
                                this._disposables.Add(disposable);
                            }
                        }
                        this.RegisteredCallbackProxy = true;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._callbackLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540066389)
            
            //--TRIMMABLE-BOUNDARY-START(94489739349)
            static /*void */ OnChange(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(state !== null, "state != null");
                /*var*/ let compositeChangeTokenState = $.$cast(state, $.$mep.MEP.CompositeChangeToken);
                if (compositeChangeTokenState._cancellationTokenSource === null)
                {
                    return;
                }
                //lock(compositeChangeTokenState._callbackLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(compositeChangeTokenState._callbackLock)
                    {
                        if (compositeChangeTokenState._cancellationTokenSource.IsCancellationRequested)
                        {
                            return;
                        }
                        try
                        {
                            compositeChangeTokenState._cancellationTokenSource.Cancel();
                        }
                        catch($e)
                        {
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(compositeChangeTokenState._callbackLock)
                }
                /*List<IDisposable>?*/ let disposables = compositeChangeTokenState._disposables;
                $.$$.SD.Debug.Assert$4(disposables !== null, "disposables != null");
                for(/*int*/ let i = 0; i < disposables.Count; i++)
                {
                    disposables.get_Item(i).S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489739349)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get MEP$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get MEP$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //--TRIMMABLE-BOUNDARY-START(30065492053)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            MEP$IChangeToken$RegisterChangeCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterChangeCallback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492053)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295426133)
                this._callbackLock = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(4295426133)
                
            }
            //--TRIMMABLE-BOUNDARY-START(34360197205)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17180328021)
                    this._onChangeDelegate = new ($.$$.S.Action$$($.$$.S.Object))().$ctor($.$mep.MEP.CompositeChangeToken, $.$mep.MEP.CompositeChangeToken.OnChange);
                    //--TRIMMABLE-BOUNDARY-END(17180328021)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360197205)
            
            static $h = 458837;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079673941),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899804757,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669608533,
        "f": 83886082
      },
      "n": "RegisteredCallbackProxy",
      "d": 458837,
      "h": 103079673941,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(103079673941),
//--TRIMMABLE-BOUNDARY-START(47245099093),
    {
      "p": $.$$.SCG.IReadOnlyList$$($.$mep.MEP.IChangeToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719935573,
        "f": 50331649
      },
      "n": "ChangeTokens",
      "d": 458837,
      "h": 47245099093,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245099093),
//--TRIMMABLE-BOUNDARY-START(90194772053),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309870165,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 458837,
      "h": 90194772053,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194772053),
//--TRIMMABLE-BOUNDARY-START(42950131797),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130000981,
        "f": 50331649
      },
      "n": "ActiveChangeCallbacks",
      "d": 458837,
      "h": 42950131797,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950131797)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784706645),
    {
      "r": 91095041,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterChangeCallback",
      "d": 458837,
      "h": 98784706645,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784706645),
//--TRIMMABLE-BOUNDARY-START(51540066389),
    {
      "r": 65537,
      "n": "EnsureCallbacksInitialized",
      "d": 458837,
      "h": 51540066389,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540066389),
//--TRIMMABLE-BOUNDARY-START(94489739349),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "OnChange",
      "d": 458837,
      "h": 94489739349,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489739349)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180328021),
    {
      "t": $.$$.S.Action$$($.$$.S.Object).$h,
      "n": "_onChangeDelegate",
      "d": 458837,
      "h": 17180328021,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180328021),
//--TRIMMABLE-BOUNDARY-START(4295426133),
    {
      "t": 131073,
      "n": "_callbackLock",
      "d": 458837,
      "h": 4295426133,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426133),
//--TRIMMABLE-BOUNDARY-START(8590393429),
    {
      "t": 170983425,
      "n": "_cancellationTokenSource",
      "d": 458837,
      "h": 8590393429,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393429),
//--TRIMMABLE-BOUNDARY-START(12885360725),
    {
      "t": $.$$.SCG.List$$($.$$.S.IDisposable).$h,
      "n": "_disposables",
      "d": 458837,
      "h": 12885360725,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360725)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655164501),
    {
      "p": [
        {
          "n": "changeTokens",
          "p": $.$$.SCG.IReadOnlyList$$($.$mep.MEP.IChangeToken).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458837,
      "h": 38655164501,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655164501)
  ],
  "h": 458837,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "HasChanged = {HasChanged}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.MEP.IChangeToken ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.CompositeChangeToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}CompositeChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458837)
        
        

        //--TRIMMABLE-BOUNDARY-START(65621)
        $asm.$cls(`$mep.MEF.EmptyDisposable`, ($self) => class EmptyDisposable extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30064836693)
            /*EmptyDisposable*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30064836693)
            
            //--TRIMMABLE-BOUNDARY-START(12884967509)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967509);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967509)
            
            //--TRIMMABLE-BOUNDARY-START(17179934805)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17179934805)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12884967509)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967509)
            
            //--TRIMMABLE-BOUNDARY-START(8590000213)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30064836693)
                    this.Instance = new $.$mep.MEF.EmptyDisposable().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(30064836693)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000213)
            
            static $h = 65621;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064836693),
    {
      "p": 65621,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869397,
        "f": 50331681
      },
      "n": "Instance",
      "d": 65621,
      "h": 30064836693,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836693)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934805),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 65621,
      "h": 17179934805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934805)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967509),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65621,
      "h": 12884967509,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967509)
  ],
  "h": 65621
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}EmptyDisposable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65621)
        
        

        //--TRIMMABLE-BOUNDARY-START(786517)
        $asm.$str(`$mep.MEP.InplaceStringBuilder`, ($self) => class InplaceStringBuilder extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590721109)
            /*int*/ _offset = 0;
            //--TRIMMABLE-BOUNDARY-END(8590721109)
            
            //--TRIMMABLE-BOUNDARY-START(4295753813)
            /*int*/ _capacity = 0;
            //--TRIMMABLE-BOUNDARY-END(4295753813)
            
            //--TRIMMABLE-BOUNDARY-START(12885688405)
            /*string?*/ _value = null;
            //--TRIMMABLE-BOUNDARY-END(12885688405)
            
            //--TRIMMABLE-BOUNDARY-START(21475622997)
            $ctor$3(/*int*/ capacity)
            {
                this.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475622997);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (capacity < 0)
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(8/*ExceptionArgument.capacity*/);
                    }
                    this._capacity = capacity;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475622997)
            
            //--TRIMMABLE-BOUNDARY-START(42950459477)
            /*int */ get Capacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835361365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._capacity;
            }
            /*int */ set Capacity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425295957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(7/*ExceptionArgument.value*/);
                }
                if (this._offset > 0)
                {
                    $.$mep.MEP.ThrowHelper.ThrowInvalidOperationException$1(2/*ExceptionResource.Capacity_CannotChangeAfterWriteStarted*/);
                }
                this._capacity = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459477)
            
            //--TRIMMABLE-BOUNDARY-START(38655492181)
            /*void */ Append$3(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.value*/);
                }
                this.Append$2(value, 0, value.length);
            }
            //--TRIMMABLE-BOUNDARY-END(38655492181)
            
            //--TRIMMABLE-BOUNDARY-START(25770590293)
            /*void */ Append(/*StringSegment*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Append$2(segment.Buffer, segment.Offset, segment.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(25770590293)
            
            //--TRIMMABLE-BOUNDARY-START(34360524885)
            /*void */ Append$2(/*string?*/ value, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureValueIsInitialized();
                if (value === null || offset < 0 || ((value.length - offset) | 0) < count || ((this.Capacity - this._offset) | 0) < count)
                {
                    this.ThrowValidationError(value, offset, count);
                }
                /*fixed*/ 
                {
                    /*char**/ let destination = $.$$.S.String.GetPinnableReference.call(this._value);
                    /*fixed*/ 
                    {
                        /*char**/ let source = $.$$.S.String.GetPinnableReference.call(value);
                        $.$$.SRC.Unsafe.CopyBlockUnaligned$1(destination.Add(this._offset), source.Add(offset), (((count >>> 0) * 2) >>> 0));
                        this._offset += count;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360524885)
            
            //--TRIMMABLE-BOUNDARY-START(30065557589)
            /*void */ Append$1(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureValueIsInitialized();
                if (this._offset >= this.Capacity)
                {
                    $.$mep.MEP.ThrowHelper.ThrowInvalidOperationException(3/*ExceptionResource.Capacity_NotEnough*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(1, $.$$.S.Int32), $.$box(((this.Capacity - this._offset) | 0), $.$$.S.Int32) ], null, null));
                }
                /*fixed*/ 
                {
                    /*char**/ let destination = $.$$.S.String.GetPinnableReference.call(this._value);
                    destination.SetAt(c, this._offset++);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065557589)
            
            //--TRIMMABLE-BOUNDARY-START(73015230549)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015230549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Capacity !== this._offset)
                {
                    $.$mep.MEP.ThrowHelper.ThrowInvalidOperationException(4/*ExceptionResource.Capacity_NotUsedEntirely*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(this.Capacity, $.$$.S.Int32), $.$box(this._offset, $.$$.S.Int32) ], null, null));
                }
                return this._value;
            }
            //--TRIMMABLE-BOUNDARY-END(73015230549)
            
            //--TRIMMABLE-BOUNDARY-START(47245426773)
            /*void */ EnsureValueIsInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._value ??= $.$$.S.String.Create(/*\u0000*/ 0, this._capacity);
            }
            //--TRIMMABLE-BOUNDARY-END(47245426773)
            
            //--TRIMMABLE-BOUNDARY-START(68720263253)
            /*void */ ThrowValidationError(/*string?*/ value, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.value*/);
                }
                if (offset < 0 || ((value.length - offset) | 0) < count)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.offset*/);
                }
                if (((this.Capacity - this._offset) | 0) < count)
                {
                    $.$mep.MEP.ThrowHelper.ThrowInvalidOperationException(3/*ExceptionResource.Capacity_NotEnough*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(value.length, $.$$.S.Int32), $.$box(((this.Capacity - this._offset) | 0), $.$$.S.Int32) ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720263253)
            
            //--TRIMMABLE-BOUNDARY-START(17180655701)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655701)
            
            //--TRIMMABLE-BOUNDARY-START(17180655701)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180655701)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._offset = this._offset;
                copy._capacity = this._capacity;
                copy._value = this._value;
                return copy;
            }
            static $h = 786517;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950459477),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361365,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425295957,
        "f": 83886081
      },
      "n": "Capacity",
      "d": 786517,
      "h": 42950459477,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950459477)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655492181),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Append",
      "o": "@$3",
      "d": 786517,
      "h": 38655492181,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655492181),
//--TRIMMABLE-BOUNDARY-START(25770590293),
    {
      "r": 65537,
      "p": [
        {
          "n": "segment",
          "p": 852053
        }
      ],
      "n": "Append",
      "d": 786517,
      "h": 25770590293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590293),
//--TRIMMABLE-BOUNDARY-START(34360524885),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 786517,
      "h": 34360524885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360524885),
//--TRIMMABLE-BOUNDARY-START(30065557589),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": 786517,
      "h": 30065557589,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557589),
//--TRIMMABLE-BOUNDARY-START(73015230549),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 786517,
      "h": 73015230549,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015230549),
//--TRIMMABLE-BOUNDARY-START(47245426773),
    {
      "r": 65537,
      "n": "EnsureValueIsInitialized",
      "d": 786517,
      "h": 47245426773,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245426773),
//--TRIMMABLE-BOUNDARY-START(68720263253),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ThrowValidationError",
      "d": 786517,
      "h": 68720263253,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720263253)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721109),
    {
      "t": 655361,
      "n": "_offset",
      "d": 786517,
      "h": 8590721109,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721109),
//--TRIMMABLE-BOUNDARY-START(4295753813),
    {
      "t": 655361,
      "n": "_capacity",
      "d": 786517,
      "h": 4295753813,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753813),
//--TRIMMABLE-BOUNDARY-START(12885688405),
    {
      "t": 1310721,
      "n": "_value",
      "d": 786517,
      "h": 12885688405,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688405)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475622997),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786517,
      "h": 21475622997,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475622997),
//--TRIMMABLE-BOUNDARY-START(17180655701),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786517,
      "h": 17180655701,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655701)
  ],
  "h": 786517,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Value = {_value}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    },
    {
      "t": 104464385,
      "c": 25874268161,
      "a": [
        {
          "v": "This type is retained only for compatibility. The recommended alternative is string.Create\u003CTState\u003E (int length, TState state, System.Buffers.SpanAction\u003Cchar,TState\u003E action).",
          "t": 1310721
        },
        {
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.InplaceStringBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}InplaceStringBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786517)
        
        

        //--TRIMMABLE-BOUNDARY-START(524373)
        $asm.$str(`$mep.MEP.ExceptionArgument`, ($self) => class ExceptionArgument extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static buffer = 0;
            static offset = 1;
            static length = 2;
            static text = 3;
            static start = 4;
            static count = 5;
            static index = 6;
            static value = 7;
            static capacity = 8;
            static separators = 9;
            static comparisonType = 10;
            static changeTokens = 11;
            static changeTokenProducer = 12;
            static changeTokenConsumer = 13;
            static array = 14;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "buffer": 0n,
                    "offset": 1n,
                    "length": 2n,
                    "text": 3n,
                    "start": 4n,
                    "count": 5n,
                    "index": 6n,
                    "value": 7n,
                    "capacity": 8n,
                    "separators": 9n,
                    "comparisonType": 10n,
                    "changeTokens": 11n,
                    "changeTokenProducer": 12n,
                    "changeTokenConsumer": 13n,
                    "array": 14n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295491669)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491669)
            
            //--TRIMMABLE-BOUNDARY-START(4295491669)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491669)
            
            static $h = 524373;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885426261),
    {
      "t": 524373,
      "n": "buffer",
      "d": 524373,
      "h": 12885426261,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426261),
//--TRIMMABLE-BOUNDARY-START(51540131925),
    {
      "t": 524373,
      "n": "offset",
      "d": 524373,
      "h": 51540131925,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540131925),
//--TRIMMABLE-BOUNDARY-START(47245164629),
    {
      "t": 524373,
      "n": "length",
      "d": 524373,
      "h": 47245164629,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245164629),
//--TRIMMABLE-BOUNDARY-START(64425033813),
    {
      "t": 524373,
      "n": "text",
      "d": 524373,
      "h": 64425033813,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425033813),
//--TRIMMABLE-BOUNDARY-START(60130066517),
    {
      "t": 524373,
      "n": "start",
      "d": 524373,
      "h": 60130066517,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066517),
//--TRIMMABLE-BOUNDARY-START(38655230037),
    {
      "t": 524373,
      "n": "count",
      "d": 524373,
      "h": 38655230037,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655230037),
//--TRIMMABLE-BOUNDARY-START(42950197333),
    {
      "t": 524373,
      "n": "index",
      "d": 524373,
      "h": 42950197333,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197333),
//--TRIMMABLE-BOUNDARY-START(68720001109),
    {
      "t": 524373,
      "n": "value",
      "d": 524373,
      "h": 68720001109,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720001109),
//--TRIMMABLE-BOUNDARY-START(17180393557),
    {
      "t": 524373,
      "n": "capacity",
      "d": 524373,
      "h": 17180393557,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393557),
//--TRIMMABLE-BOUNDARY-START(55835099221),
    {
      "t": 524373,
      "n": "separators",
      "d": 524373,
      "h": 55835099221,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835099221),
//--TRIMMABLE-BOUNDARY-START(34360262741),
    {
      "t": 524373,
      "n": "comparisonType",
      "d": 524373,
      "h": 34360262741,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262741),
//--TRIMMABLE-BOUNDARY-START(30065295445),
    {
      "t": 524373,
      "n": "changeTokens",
      "d": 524373,
      "h": 30065295445,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295445),
//--TRIMMABLE-BOUNDARY-START(25770328149),
    {
      "t": 524373,
      "n": "changeTokenProducer",
      "d": 524373,
      "h": 25770328149,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328149),
//--TRIMMABLE-BOUNDARY-START(21475360853),
    {
      "t": 524373,
      "n": "changeTokenConsumer",
      "d": 524373,
      "h": 21475360853,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360853),
//--TRIMMABLE-BOUNDARY-START(8590458965),
    {
      "t": 524373,
      "n": "array",
      "d": 524373,
      "h": 8590458965,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491669),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524373,
      "h": 4295491669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491669)
  ],
  "h": 524373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.ExceptionArgument`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}ExceptionArgument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524373)
        
        

        //--TRIMMABLE-BOUNDARY-START(589909)
        $asm.$str(`$mep.MEP.ExceptionResource`, ($self) => class ExceptionResource extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Argument_InvalidOffsetLength = 0;
            static Argument_InvalidOffsetLengthStringSegment = 1;
            static Capacity_CannotChangeAfterWriteStarted = 2;
            static Capacity_NotEnough = 3;
            static Capacity_NotUsedEntirely = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Argument_InvalidOffsetLength": 0n,
                    "Argument_InvalidOffsetLengthStringSegment": 1n,
                    "Capacity_CannotChangeAfterWriteStarted": 2n,
                    "Capacity_NotEnough": 3n,
                    "Capacity_NotUsedEntirely": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295557205)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557205)
            
            //--TRIMMABLE-BOUNDARY-START(4295557205)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557205)
            
            static $h = 589909;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524501),
    {
      "t": 589909,
      "n": "Argument_InvalidOffsetLength",
      "d": 589909,
      "h": 8590524501,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524501),
//--TRIMMABLE-BOUNDARY-START(12885491797),
    {
      "t": 589909,
      "n": "Argument_InvalidOffsetLengthStringSegment",
      "d": 589909,
      "h": 12885491797,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491797),
//--TRIMMABLE-BOUNDARY-START(17180459093),
    {
      "t": 589909,
      "n": "Capacity_CannotChangeAfterWriteStarted",
      "d": 589909,
      "h": 17180459093,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180459093),
//--TRIMMABLE-BOUNDARY-START(21475426389),
    {
      "t": 589909,
      "n": "Capacity_NotEnough",
      "d": 589909,
      "h": 21475426389,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475426389),
//--TRIMMABLE-BOUNDARY-START(25770393685),
    {
      "t": 589909,
      "n": "Capacity_NotUsedEntirely",
      "d": 589909,
      "h": 25770393685,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770393685)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557205),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589909,
      "h": 4295557205,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557205)
  ],
  "h": 589909
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.ExceptionResource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}ExceptionResource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589909)
        
        

        //--TRIMMABLE-BOUNDARY-START(852053)
        $asm.$str(`$mep.MEP.StringSegment`, ($self) => class StringSegment extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(64425361493)
            /*StringSegment*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(64425361493)
            
            //--TRIMMABLE-BOUNDARY-START(30065623125)
            $ctor$4(/*string?*/ buffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065623125);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Buffer = buffer;
                    this.Offset = 0;
                    const $t1 = buffer;
                    this.Length = $.$ifnn($t1, ($t) => $t.length) ?? 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065623125)
            
            //--TRIMMABLE-BOUNDARY-START(25770655829)
            $ctor$3(/*string*/ buffer, /*int*/ offset, /*int*/ length)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770655829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (buffer === null || (offset >>> 0) > (buffer.length >>> 0) || (length >>> 0) > ((((buffer.length - offset) | 0)) >>> 0))
                    {
                        $.$mep.MEP.StringSegment.ThrowInvalidArguments$1(buffer, offset, length);
                    }
                    this.Buffer = buffer;
                    this.Offset = offset;
                    this.Length = length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655829)
            
            //--TRIMMABLE-BOUNDARY-START(51540459605)
            /*string?*/ Buffer = null;
            //--TRIMMABLE-BOUNDARY-END(51540459605)
            
            //--TRIMMABLE-BOUNDARY-START(197569347669)
            /*int*/ Offset = 0;
            //--TRIMMABLE-BOUNDARY-END(197569347669)
            
            //--TRIMMABLE-BOUNDARY-START(193274380373)
            /*int*/ Length = 0;
            //--TRIMMABLE-BOUNDARY-END(193274380373)
            
            //--TRIMMABLE-BOUNDARY-START(279173726293)
            /*string? */ get Value()
            {
                return this.HasValue ? this.Buffer.substr(this.Offset, this.Length) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(279173726293)
            
            //--TRIMMABLE-BOUNDARY-START(154619674709)
            /*bool */ get HasValue()
            {
                return this.Buffer !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(154619674709)
            
            //--TRIMMABLE-BOUNDARY-START(249108955221)
            /*char*/ get_Item$1(/*int*/ index)
            {
                if ((index >>> 0) >= (this.Length >>> 0))
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.index*/);
                }
                $.$$.SD.Debug.Assert$4(!(this.Buffer === null), "Buffer is not null");
                return $.$$.S.String.get_Chars.call(this.Buffer, ((this.Offset + index) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(249108955221)
            
            //--TRIMMABLE-BOUNDARY-START(38655557717)
            /*ReadOnlySpan<char> */ AsSpan()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655557717);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.MemoryExtensions.AsSpan$1(this.Buffer, this.Offset, this.Length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655557717)
            
            //--TRIMMABLE-BOUNDARY-START(47245492309)
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.HasValue || start < 0)
                {
                    this.ThrowInvalidArguments(start, ((this.Length - start) | 0), 4/*ExceptionArgument.start*/);
                }
                return $.$$.S.MemoryExtensions.AsSpan$1(this.Buffer, ((this.Offset + start) | 0), ((this.Length - start) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(47245492309)
            
            //--TRIMMABLE-BOUNDARY-START(42950525013)
            /*ReadOnlySpan<char> */ AsSpan$1(/*int*/ start, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950525013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.HasValue || start < 0 || length < 0 || ((((start + length) | 0)) >>> 0) > (this.Length >>> 0))
                {
                    this.ThrowInvalidArguments(start, length, 4/*ExceptionArgument.start*/);
                }
                return $.$$.S.MemoryExtensions.AsSpan$1(this.Buffer, ((this.Offset + start) | 0), length);
            }
            //--TRIMMABLE-BOUNDARY-END(42950525013)
            
            //--TRIMMABLE-BOUNDARY-START(34360590421)
            /*ReadOnlyMemory<char> */ AsMemory()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360590421);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.MemoryExtensions.AsMemory$1(this.Buffer, this.Offset, this.Length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360590421)
            
            //--TRIMMABLE-BOUNDARY-START(60130394197)
            static /*int */ Compare(/*StringSegment*/ a, /*StringSegment*/ b, /*StringComparison*/ comparisonType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (a.HasValue && b.HasValue)
                {
                    return $.$$.S.MemoryExtensions.CompareTo(a.AsSpan(), b.AsSpan(), comparisonType);
                }
                else 
                {
                    $.$mep.MEP.StringSegment.CheckStringComparison(comparisonType);
                    return !a.HasValue ? (b.HasValue ? -1 : 0) : 1;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130394197)
            
            //--TRIMMABLE-BOUNDARY-START(73015296085)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015296085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let segment;
                return $.$is(obj, $.$mep.MEP.StringSegment, { set $v($v){ segment = $v; } }) && this.Equals$6(segment);
            }
            //--TRIMMABLE-BOUNDARY-END(73015296085)
            
            //--TRIMMABLE-BOUNDARY-START(94490132565)
            /*bool */ Equals$6(/*StringSegment*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490132565);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Equals$4(other, 4/*StringComparison.Ordinal*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490132565)
            
            //--TRIMMABLE-BOUNDARY-START(85900197973)
            /*bool */ Equals$4(/*StringSegment*/ other, /*StringComparison*/ comparisonType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900197973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.HasValue && other.HasValue)
                {
                    return $.$$.S.MemoryExtensions.Equals$2(this.AsSpan(), other.AsSpan(), comparisonType);
                }
                else 
                {
                    $.$mep.MEP.StringSegment.CheckStringComparison(comparisonType);
                    return !this.HasValue && !other.HasValue;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900197973)
            
            //--TRIMMABLE-BOUNDARY-START(90195165269)
            static /*bool */ Equals$5(/*StringSegment*/ a, /*StringSegment*/ b, /*StringComparison*/ comparisonType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195165269);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return a.Equals$4(b, comparisonType);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195165269)
            
            //--TRIMMABLE-BOUNDARY-START(81605230677)
            /*bool */ Equals$3(/*string?*/ text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605230677);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Equals$2(text, 4/*StringComparison.Ordinal*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605230677)
            
            //--TRIMMABLE-BOUNDARY-START(77310263381)
            /*bool */ Equals$2(/*string?*/ text, /*StringComparison*/ comparisonType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.HasValue || text === null)
                {
                    $.$mep.MEP.StringSegment.CheckStringComparison(comparisonType);
                    return text === this.Buffer;
                }
                return $.$$.S.MemoryExtensions.Equals$2(this.AsSpan(), $.$$.S.MemoryExtensions.AsSpan$4(text), comparisonType);
            }
            //--TRIMMABLE-BOUNDARY-END(77310263381)
            
            //--TRIMMABLE-BOUNDARY-START(150324707413)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324707413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.GetHashCode$2(this.AsSpan());
            }
            //--TRIMMABLE-BOUNDARY-END(150324707413)
            
            //--TRIMMABLE-BOUNDARY-START(201864314965)
            static /*bool */ op_Equality(/*StringSegment*/ left, /*StringSegment*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864314965);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return left.Equals$6(right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864314965)
            
            //--TRIMMABLE-BOUNDARY-START(206159282261)
            static /*bool */ op_Inequality(/*StringSegment*/ left, /*StringSegment*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159282261);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !left.Equals$6(right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159282261)
            
            //--TRIMMABLE-BOUNDARY-START(244813987925)
            static /*StringSegment */ op_Implicit$2(/*string?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244813987925);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mep.MEP.StringSegment().$ctor$4(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244813987925)
            
            //--TRIMMABLE-BOUNDARY-START(240519020629)
            static /*ReadOnlySpan<char> */ op_Implicit$1(/*StringSegment*/ segment)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240519020629);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return segment.AsSpan();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240519020629)
            
            //--TRIMMABLE-BOUNDARY-START(236224053333)
            static /*ReadOnlyMemory<char> */ op_Implicit(/*StringSegment*/ segment)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236224053333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return segment.AsMemory();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236224053333)
            
            //--TRIMMABLE-BOUNDARY-START(214749216853)
            /*bool */ StartsWith(/*string*/ text, /*StringComparison*/ comparisonType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749216853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (text === null)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.text*/);
                }
                if (!this.HasValue)
                {
                    $.$mep.MEP.StringSegment.CheckStringComparison(comparisonType);
                    return false;
                }
                return $.$$.S.MemoryExtensions.StartsWith(this.AsSpan(), $.$$.S.MemoryExtensions.AsSpan$4(text), comparisonType);
            }
            //--TRIMMABLE-BOUNDARY-END(214749216853)
            
            //--TRIMMABLE-BOUNDARY-START(68720328789)
            /*bool */ EndsWith(/*string*/ text, /*StringComparison*/ comparisonType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (text === null)
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.text*/);
                }
                if (!this.HasValue)
                {
                    $.$mep.MEP.StringSegment.CheckStringComparison(comparisonType);
                    return false;
                }
                return $.$$.S.MemoryExtensions.EndsWith(this.AsSpan(), $.$$.S.MemoryExtensions.AsSpan$4(text), comparisonType);
            }
            //--TRIMMABLE-BOUNDARY-END(68720328789)
            
            //--TRIMMABLE-BOUNDARY-START(231929086037)
            /*string */ Substring$1(/*int*/ offset)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231929086037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Substring(offset, ((this.Length - offset) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929086037)
            
            //--TRIMMABLE-BOUNDARY-START(227634118741)
            /*string */ Substring(/*int*/ offset, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634118741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.HasValue || offset < 0 || length < 0 || ((((offset + length) | 0)) >>> 0) > (this.Length >>> 0))
                {
                    this.ThrowInvalidArguments(offset, length, 1/*ExceptionArgument.offset*/);
                }
                return this.Buffer.substr(((this.Offset + offset) | 0), length);
            }
            //--TRIMMABLE-BOUNDARY-END(227634118741)
            
            //--TRIMMABLE-BOUNDARY-START(223339151445)
            /*StringSegment */ Subsegment$1(/*int*/ offset)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(223339151445);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Subsegment(offset, ((this.Length - offset) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339151445)
            
            //--TRIMMABLE-BOUNDARY-START(219044184149)
            /*StringSegment */ Subsegment(/*int*/ offset, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044184149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.HasValue || offset < 0 || length < 0 || ((((offset + length) | 0)) >>> 0) > (this.Length >>> 0))
                {
                    this.ThrowInvalidArguments(offset, length, 1/*ExceptionArgument.offset*/);
                }
                return new $.$mep.MEP.StringSegment().$ctor$3(this.Buffer, ((this.Offset + offset) | 0), length);
            }
            //--TRIMMABLE-BOUNDARY-END(219044184149)
            
            //--TRIMMABLE-BOUNDARY-START(158914642005)
            /*int */ IndexOf(/*char*/ c, /*int*/ start, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914642005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = -1;
                if (this.HasValue)
                {
                    if ((start >>> 0) > (this.Length >>> 0))
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.start*/);
                    }
                    if ((count >>> 0) > ((((this.Length - start) | 0)) >>> 0))
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.count*/);
                    }
                    index = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, this.AsSpan$1(start, count), c);
                    if (index >= 0)
                    {
                        index += start;
                    }
                }
                return index;
            }
            //--TRIMMABLE-BOUNDARY-END(158914642005)
            
            //--TRIMMABLE-BOUNDARY-START(163209609301)
            /*int */ IndexOf$1(/*char*/ c, /*int*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209609301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IndexOf(c, start, ((this.Length - start) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209609301)
            
            //--TRIMMABLE-BOUNDARY-START(167504576597)
            /*int */ IndexOf$2(/*char*/ c)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504576597);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IndexOf(c, 0, this.Length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504576597)
            
            //--TRIMMABLE-BOUNDARY-START(171799543893)
            /*int */ IndexOfAny(/*char[]*/ anyOf, /*int*/ startIndex, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799543893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = -1;
                if (this.HasValue)
                {
                    if ((startIndex >>> 0) > (this.Length >>> 0))
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.start*/);
                    }
                    if ((count >>> 0) > ((((this.Length - startIndex) | 0)) >>> 0))
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.count*/);
                    }
                    index = $.$$.S.String.IndexOfAny.call(this.Buffer, anyOf, ((this.Offset + startIndex) | 0), count);
                    if (index !== -1)
                    {
                        index -= this.Offset;
                    }
                }
                return index;
            }
            //--TRIMMABLE-BOUNDARY-END(171799543893)
            
            //--TRIMMABLE-BOUNDARY-START(176094511189)
            /*int */ IndexOfAny$1(/*char[]*/ anyOf, /*int*/ startIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094511189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOfAny(anyOf, startIndex, ((this.Length - startIndex) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(176094511189)
            
            //--TRIMMABLE-BOUNDARY-START(180389478485)
            /*int */ IndexOfAny$2(/*char[]*/ anyOf)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389478485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOfAny(anyOf, 0, this.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(180389478485)
            
            //--TRIMMABLE-BOUNDARY-START(188979413077)
            /*int */ LastIndexOf(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979413077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.MemoryExtensions.LastIndexOf$4($.$$.S.Char, this.AsSpan(), value);
            }
            //--TRIMMABLE-BOUNDARY-END(188979413077)
            
            //--TRIMMABLE-BOUNDARY-START(266288824405)
            /*StringSegment */ Trim()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266288824405);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TrimStart().TrimEnd();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266288824405)
            
            //--TRIMMABLE-BOUNDARY-START(274878758997)
            /*StringSegment */ TrimStart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878758997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let span = this.AsSpan();
                /*int*/ let i;
                for(i = 0; i < span.Length; i++)
                {
                    if (!$.$$.S.Char.IsWhiteSpace$1(span._reference.GetAt(i)))
                    {
                        break;
                    }
                }
                return this.Subsegment$1(i);
            }
            //--TRIMMABLE-BOUNDARY-END(274878758997)
            
            //--TRIMMABLE-BOUNDARY-START(270583791701)
            /*StringSegment */ TrimEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583791701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let span = this.AsSpan();
                /*int*/ let i;
                for(i = ((span.Length - 1) | 0); i >= 0; i--)
                {
                    if (!$.$$.S.Char.IsWhiteSpace$1(span._reference.GetAt(i)))
                    {
                        break;
                    }
                }
                return this.Subsegment(0, ((i + 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(270583791701)
            
            //--TRIMMABLE-BOUNDARY-START(210454249557)
            /*StringTokenizer */ Split(/*char[]*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454249557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mep.MEP.StringTokenizer().$ctor$3(this, chars);
            }
            //--TRIMMABLE-BOUNDARY-END(210454249557)
            
            //--TRIMMABLE-BOUNDARY-START(184684445781)
            static /*bool */ IsNullOrEmpty(/*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684445781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let res = false;
                if (!value.HasValue || value.Length === 0)
                {
                    res = true;
                }
                return res;
            }
            //--TRIMMABLE-BOUNDARY-END(184684445781)
            
            //--TRIMMABLE-BOUNDARY-START(261993857109)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993857109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(261993857109)
            
            //--TRIMMABLE-BOUNDARY-START(55835426901)
            static /*void */ CheckStringComparison(/*StringComparison*/ comparisonType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((comparisonType >>> 0) > (5/*StringComparison.OrdinalIgnoreCase*/ >>> 0))
                {
                    $.$mep.MEP.ThrowHelper.ThrowArgumentOutOfRangeException(10/*ExceptionArgument.comparisonType*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835426901)
            
            //--TRIMMABLE-BOUNDARY-START(257698889813)
            static /*void */ ThrowInvalidArguments$1(/*string?*/ buffer, /*int*/ offset, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698889813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw GetInvalidArgumentsException.call(this);
                /*Exception*/  function GetInvalidArgumentsException()
                {
                    if (buffer === null)
                    {
                        return $.$mep.MEP.ThrowHelper.GetArgumentNullException(0/*ExceptionArgument.buffer*/);
                    }
                    if (offset < 0)
                    {
                        return $.$mep.MEP.ThrowHelper.GetArgumentOutOfRangeException(1/*ExceptionArgument.offset*/);
                    }
                    if (length < 0)
                    {
                        return $.$mep.MEP.ThrowHelper.GetArgumentOutOfRangeException(2/*ExceptionArgument.length*/);
                    }
                    return $.$mep.MEP.ThrowHelper.GetArgumentException(0/*ExceptionResource.Argument_InvalidOffsetLength*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698889813)
            
            //--TRIMMABLE-BOUNDARY-START(253403922517)
            /*void */ ThrowInvalidArguments(/*int*/ offset, /*int*/ length, /*ExceptionArgument*/ offsetOrStart)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403922517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw GetInvalidArgumentsException.call(this, this.HasValue);
                /*Exception*/  function GetInvalidArgumentsException(/*bool*/ hasValue)
                {
                    if (!hasValue)
                    {
                        return $.$mep.MEP.ThrowHelper.GetArgumentOutOfRangeException(offsetOrStart);
                    }
                    if (offset < 0)
                    {
                        return $.$mep.MEP.ThrowHelper.GetArgumentOutOfRangeException(offsetOrStart);
                    }
                    if (length < 0)
                    {
                        return $.$mep.MEP.ThrowHelper.GetArgumentOutOfRangeException(2/*ExceptionArgument.length*/);
                    }
                    return $.$mep.MEP.ThrowHelper.GetArgumentException(1/*ExceptionResource.Argument_InvalidOffsetLengthStringSegment*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253403922517)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.Primitives.StringSegment>.Equals(Microsoft.Extensions.Primitives.StringSegment)
            S$IEquatable$Microsoft$Extensions$Primitives$StringSegment$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$6(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<string?>.Equals(string?)
            S$IEquatable$System$String$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(21475688533)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475688533)
            
            //--TRIMMABLE-BOUNDARY-START(21475688533)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475688533)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Buffer = this.Buffer;
                copy.Offset = this.Offset;
                copy.Length = this.Length;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(17180721237)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(64425361493)
                    this.Empty = $.$mep.MEP.StringSegment.op_Implicit$2($.$$.S.String.Empty);
                    //--TRIMMABLE-BOUNDARY-END(64425361493)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180721237)
            
            static $h = 852053;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540459605),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080067157,
        "f": 50331649
      },
      "n": "Buffer",
      "d": 852053,
      "h": 51540459605,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540459605),
//--TRIMMABLE-BOUNDARY-START(197569347669),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439805525,
        "f": 50331649
      },
      "n": "Offset",
      "d": 852053,
      "h": 197569347669,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569347669),
//--TRIMMABLE-BOUNDARY-START(193274380373),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849870933,
        "f": 50331649
      },
      "n": "Length",
      "d": 852053,
      "h": 193274380373,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274380373),
//--TRIMMABLE-BOUNDARY-START(279173726293),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029740117,
        "f": 50331649
      },
      "n": "Value",
      "d": 852053,
      "h": 279173726293,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173726293),
//--TRIMMABLE-BOUNDARY-START(154619674709),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670001749,
        "f": 50331649
      },
      "n": "HasValue",
      "d": 852053,
      "h": 154619674709,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619674709),
//--TRIMMABLE-BOUNDARY-START(249108955221),
    {
      "p": 458753,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259936341,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 852053,
      "h": 249108955221,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249108955221)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655557717),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
      "n": "AsSpan",
      "d": 852053,
      "h": 38655557717,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655557717),
//--TRIMMABLE-BOUNDARY-START(47245492309),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$2",
      "d": 852053,
      "h": 47245492309,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245492309),
//--TRIMMABLE-BOUNDARY-START(42950525013),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$1",
      "d": 852053,
      "h": 42950525013,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950525013),
//--TRIMMABLE-BOUNDARY-START(34360590421),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "n": "AsMemory",
      "d": 852053,
      "h": 34360590421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360590421),
//--TRIMMABLE-BOUNDARY-START(60130394197),
    {
      "r": 655361,
      "p": [
        {
          "n": "a",
          "p": 852053
        },
        {
          "n": "b",
          "p": 852053
        },
        {
          "n": "comparisonType",
          "p": 164364289
        }
      ],
      "n": "Compare",
      "d": 852053,
      "h": 60130394197,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130394197),
//--TRIMMABLE-BOUNDARY-START(73015296085),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 852053,
      "h": 73015296085,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015296085),
//--TRIMMABLE-BOUNDARY-START(94490132565),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 852053
        }
      ],
      "n": "Equals",
      "o": "@$6",
      "d": 852053,
      "h": 94490132565,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490132565),
//--TRIMMABLE-BOUNDARY-START(85900197973),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 852053
        },
        {
          "n": "comparisonType",
          "p": 164364289
        }
      ],
      "n": "Equals",
      "o": "@$4",
      "d": 852053,
      "h": 85900197973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900197973),
//--TRIMMABLE-BOUNDARY-START(90195165269),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 852053
        },
        {
          "n": "b",
          "p": 852053
        },
        {
          "n": "comparisonType",
          "p": 164364289
        }
      ],
      "n": "Equals",
      "o": "@$5",
      "d": 852053,
      "h": 90195165269,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90195165269),
//--TRIMMABLE-BOUNDARY-START(81605230677),
    {
      "r": 262145,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "Equals",
      "o": "@$3",
      "d": 852053,
      "h": 81605230677,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605230677),
//--TRIMMABLE-BOUNDARY-START(77310263381),
    {
      "r": 262145,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "comparisonType",
          "p": 164364289
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 852053,
      "h": 77310263381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310263381),
//--TRIMMABLE-BOUNDARY-START(150324707413),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 852053,
      "h": 150324707413,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324707413),
//--TRIMMABLE-BOUNDARY-START(214749216853),
    {
      "r": 262145,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "comparisonType",
          "p": 164364289
        }
      ],
      "n": "StartsWith",
      "d": 852053,
      "h": 214749216853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749216853),
//--TRIMMABLE-BOUNDARY-START(68720328789),
    {
      "r": 262145,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "comparisonType",
          "p": 164364289
        }
      ],
      "n": "EndsWith",
      "d": 852053,
      "h": 68720328789,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720328789),
//--TRIMMABLE-BOUNDARY-START(231929086037),
    {
      "r": 1310721,
      "p": [
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "Substring",
      "o": "@$1",
      "d": 852053,
      "h": 231929086037,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929086037),
//--TRIMMABLE-BOUNDARY-START(227634118741),
    {
      "r": 1310721,
      "p": [
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Substring",
      "d": 852053,
      "h": 227634118741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227634118741),
//--TRIMMABLE-BOUNDARY-START(223339151445),
    {
      "r": 852053,
      "p": [
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "Subsegment",
      "o": "@$1",
      "d": 852053,
      "h": 223339151445,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223339151445),
//--TRIMMABLE-BOUNDARY-START(219044184149),
    {
      "r": 852053,
      "p": [
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Subsegment",
      "d": 852053,
      "h": 219044184149,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219044184149),
//--TRIMMABLE-BOUNDARY-START(158914642005),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 458753
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "IndexOf",
      "d": 852053,
      "h": 158914642005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914642005),
//--TRIMMABLE-BOUNDARY-START(163209609301),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 458753
        },
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "IndexOf",
      "o": "@$1",
      "d": 852053,
      "h": 163209609301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209609301),
//--TRIMMABLE-BOUNDARY-START(167504576597),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "IndexOf",
      "o": "@$2",
      "d": 852053,
      "h": 167504576597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504576597),
//--TRIMMABLE-BOUNDARY-START(171799543893),
    {
      "r": 655361,
      "p": [
        {
          "n": "anyOf",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "IndexOfAny",
      "d": 852053,
      "h": 171799543893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799543893),
//--TRIMMABLE-BOUNDARY-START(176094511189),
    {
      "r": 655361,
      "p": [
        {
          "n": "anyOf",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "IndexOfAny",
      "o": "@$1",
      "d": 852053,
      "h": 176094511189,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094511189),
//--TRIMMABLE-BOUNDARY-START(180389478485),
    {
      "r": 655361,
      "p": [
        {
          "n": "anyOf",
          "p": $.$typeArray($.$$.S.Char).$h
        }
      ],
      "n": "IndexOfAny",
      "o": "@$2",
      "d": 852053,
      "h": 180389478485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389478485),
//--TRIMMABLE-BOUNDARY-START(188979413077),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "LastIndexOf",
      "d": 852053,
      "h": 188979413077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979413077),
//--TRIMMABLE-BOUNDARY-START(266288824405),
    {
      "r": 852053,
      "n": "Trim",
      "d": 852053,
      "h": 266288824405,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266288824405),
//--TRIMMABLE-BOUNDARY-START(274878758997),
    {
      "r": 852053,
      "n": "TrimStart",
      "d": 852053,
      "h": 274878758997,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274878758997),
//--TRIMMABLE-BOUNDARY-START(270583791701),
    {
      "r": 852053,
      "n": "TrimEnd",
      "d": 852053,
      "h": 270583791701,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583791701),
//--TRIMMABLE-BOUNDARY-START(210454249557),
    {
      "r": 983125,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.S.Char).$h
        }
      ],
      "n": "Split",
      "d": 852053,
      "h": 210454249557,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454249557),
//--TRIMMABLE-BOUNDARY-START(184684445781),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "IsNullOrEmpty",
      "d": 852053,
      "h": 184684445781,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(184684445781),
//--TRIMMABLE-BOUNDARY-START(261993857109),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 852053,
      "h": 261993857109,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(261993857109),
//--TRIMMABLE-BOUNDARY-START(55835426901),
    {
      "r": 65537,
      "p": [
        {
          "n": "comparisonType",
          "p": 164364289
        }
      ],
      "n": "CheckStringComparison",
      "d": 852053,
      "h": 55835426901,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835426901),
//--TRIMMABLE-BOUNDARY-START(257698889813),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "ThrowInvalidArguments",
      "o": "@$1",
      "d": 852053,
      "h": 257698889813,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(257698889813),
//--TRIMMABLE-BOUNDARY-START(253403922517),
    {
      "r": 65537,
      "p": [
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "offsetOrStart",
          "p": 524373
        }
      ],
      "n": "ThrowInvalidArguments",
      "d": 852053,
      "h": 253403922517,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253403922517)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425361493),
    {
      "t": 852053,
      "n": "Empty",
      "d": 852053,
      "h": 64425361493,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425361493)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065623125),
    {
      "p": [
        {
          "n": "buffer",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 852053,
      "h": 30065623125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065623125),
//--TRIMMABLE-BOUNDARY-START(25770655829),
    {
      "p": [
        {
          "n": "buffer",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852053,
      "h": 25770655829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770655829),
//--TRIMMABLE-BOUNDARY-START(21475688533),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852053,
      "h": 21475688533,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688533)
  ],
  "h": 852053,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{Value}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$mep.MEP.StringSegment), $.$$.S.IEquatable$$($.$$.S.String) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.StringSegment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}StringSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852053)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114197)
        $asm.$str(`$mep.MEP.StringValues`, ($self) => class StringValues extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(47245754453)
            /*StringValues*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(47245754453)
            
            //--TRIMMABLE-BOUNDARY-START(4296081493)
            /*object?*/ _values = null;
            //--TRIMMABLE-BOUNDARY-END(4296081493)
            
            //--TRIMMABLE-BOUNDARY-START(17180983381)
            $ctor$3(/*string?*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180983381);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._values = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180983381)
            
            //--TRIMMABLE-BOUNDARY-START(21475950677)
            $ctor$4(/*string?[]?*/ values)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475950677);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._values = values;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475950677)
            
            //--TRIMMABLE-BOUNDARY-START(283468955733)
            static /*StringValues */ op_Implicit$2(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468955733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mep.MEP.StringValues().$ctor$3(value);
            }
            //--TRIMMABLE-BOUNDARY-END(283468955733)
            
            //--TRIMMABLE-BOUNDARY-START(287763923029)
            static /*StringValues */ op_Implicit$3(/*string?[]?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763923029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mep.MEP.StringValues().$ctor$4(values);
            }
            //--TRIMMABLE-BOUNDARY-END(287763923029)
            
            //--TRIMMABLE-BOUNDARY-START(197569609813)
            static /*string? */ op_Implicit(/*StringValues*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569609813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return values.GetStringValue();
            }
            //--TRIMMABLE-BOUNDARY-END(197569609813)
            
            //--TRIMMABLE-BOUNDARY-START(201864577109)
            static /*string?[]? */ op_Implicit$1(/*StringValues*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864577109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return value.GetArrayValue();
            }
            //--TRIMMABLE-BOUNDARY-END(201864577109)
            
            //--TRIMMABLE-BOUNDARY-START(42950787157)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490394709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let value = this._values;
                if (value === null)
                {
                    return 0;
                }
                if ($.$is(value, $.$$.S.String))
                {
                    return 1;
                }
                else 
                {
                    return value.length;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950787157)
            
            //--TRIMMABLE-BOUNDARY-START(231929348181)
            /*bool */ get SCG$ICollection$$$IsReadOnly()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(231929348181)
            
            //--TRIMMABLE-BOUNDARY-START(274879021141)
            //--TRIMMABLE-BOUNDARY-START(34420359169)
            /*string?*/ SCG$IList$$$get_Item(/*int*/ index)
            {
                return this.get_Item$1(index);
            }
            /*void*/ SCG$IList$$$set_Item(/*int*/ index, /*string?*/ value)
            {
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(34420359169)
            
            //--TRIMMABLE-BOUNDARY-END(274879021141)
            
            //--TRIMMABLE-BOUNDARY-START(292058890325)
            /*string?*/ get_Item$1(/*int*/ index)
            {
                /*object?*/ let value = this._values;
                let str;
                if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                {
                    if (index === 0)
                    {
                        return str;
                    }
                }
                else if (value !== null)
                {
                    return $.$$.System.Array.$ReadT1.call(value, index);
                }
                return $.$mep.MEP.StringValues.OutOfBounds();
            }
            //--TRIMMABLE-BOUNDARY-END(292058890325)
            
            //--TRIMMABLE-BOUNDARY-START(193274642517)
            static /*string */ OutOfBounds()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274642517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call($.$$.S.Array.Empty($.$$.S.String), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(193274642517)
            
            //--TRIMMABLE-BOUNDARY-START(300648824917)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648824917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStringValue() ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(300648824917)
            
            //--TRIMMABLE-BOUNDARY-START(120260198485)
            /*string? */ GetStringValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260198485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let value = this._values;
                let s;
                if ($.$is(value, $.$$.S.String, { set $v($v){ s = $v; } }))
                {
                    return s;
                }
                else 
                {
                    return GetStringValueFromArray(value);
                }
                /*static string?*/  function GetStringValueFromArray(/*object?*/ value)
                {
                    if (value === null)
                    {
                        return null;
                    }
                    $.$$.SD.Debug.Assert$4($.$is(value, $.$typeArray($.$$.S.String)), "value is string[]");
                    /*string?[]*/ let values = value;
                    return (() =>
                    {
                        let $switch1 = values.length;
                        if ($switch1 === 0)
                        {
                            return null;
                        }
                        if ($switch1 === 1)
                        {
                            return $.$$.System.Array.$ReadT1.call(values, 0);
                        }
                        return GetJoinedStringValueFromArray(values);
                    })();
                }
                /*static string*/  function GetJoinedStringValueFromArray(/*string?[]*/ values)
                {
                    /*int*/ let length = 0;
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        /*string?*/ let value = $.$$.System.Array.$ReadT1.call(values, i);
                        if (value !== null && value.length > 0)
                        {
                            if (length > 0)
                            {
                                length++;
                            }
                            length += value.length;
                        }
                    }
                    return $.$$.S.String.Create$10($.$typeArray($.$$.S.String), length, values, new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$typeArray($.$$.S.String)))().$ctor(this,  (/*span*/ span, /*strings*/ strings) =>
                    {
                        /*int*/ let offset = 0;
                        for(/*int*/ let i = 0; i < strings.length; i++)
                        {
                            /*string?*/ let value = $.$$.System.Array.$ReadT1.call(strings, i);
                            if (value !== null && value.length > 0)
                            {
                                if (offset > 0)
                                {
                                    span._reference.SetAt(/*,*/ 44, offset);
                                    offset++;
                                }
                                $.$$.S.MemoryExtensions.AsSpan$4(value).CopyTo(span.Slice$1(offset));
                                offset += value.length;
                            }
                        }
                    }, $oLNQcb ??= {"r":65537,"p":[{"n":"span","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"strings","p":$.$typeArray($.$$.S.String).$h}],"n":"","d":1114197,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260198485)
            
            //--TRIMMABLE-BOUNDARY-START(296353857621)
            /*string?[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353857621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetArrayValue() ?? $.$$.S.Array.Empty($.$$.S.String);
            }
            //--TRIMMABLE-BOUNDARY-END(296353857621)
            
            //--TRIMMABLE-BOUNDARY-START(107375296597)
            /*string?[]? */ GetArrayValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375296597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let value = this._values;
                let values;
                if ($.$is(value, $.$typeArray($.$$.S.String), { set $v($v){ values = $v; } }))
                {
                    return values;
                }
                else if (value !== null)
                {
                    return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [value], null, null);
                }
                else 
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375296597)
            
            //--TRIMMABLE-BOUNDARY-START(253404184661)
            /*int */ SCG$IList$$$IndexOf(/*string?*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404184661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOf(item);
            }
            //--TRIMMABLE-BOUNDARY-END(253404184661)
            
            //--TRIMMABLE-BOUNDARY-START(124555165781)
            /*int */ IndexOf(/*string?*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555165781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let value = this._values;
                let values;
                if ($.$is(value, $.$typeArray($.$$.S.String), { set $v($v){ values = $v; } }))
                {
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        if ($.$$.S.String.Equals$3($.$$.System.Array.$ReadT1.call(values, i), item, 4/*StringComparison.Ordinal*/))
                        {
                            return i;
                        }
                    }
                    return -1;
                }
                if (value !== null)
                {
                    return $.$$.S.String.Equals$3(value, item, 4/*StringComparison.Ordinal*/) ? 0 : -1;
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(124555165781)
            
            //--TRIMMABLE-BOUNDARY-START(214749478997)
            /*bool */ SCG$ICollection$$$Contains(/*string?*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749478997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOf(item) >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(214749478997)
            
            //--TRIMMABLE-BOUNDARY-START(219044446293)
            /*void */ SCG$ICollection$$$CopyTo(/*string?[]*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044446293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CopyTo(array, arrayIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(219044446293)
            
            //--TRIMMABLE-BOUNDARY-START(38655819861)
            /*void */ CopyTo(/*string?[]*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655819861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let value = this._values;
                let values;
                if ($.$is(value, $.$typeArray($.$$.S.String), { set $v($v){ values = $v; } }))
                {
                    $.$$.S.Array.Copy(values, 0, array, arrayIndex, values.length);
                    return;
                }
                if (value !== null)
                {
                    if (array === null)
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.array*/);
                    }
                    if (arrayIndex < 0)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("arrayIndex");
                    }
                    if (((array.length - arrayIndex) | 0) < 1)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14(`'${$.$strNN("array")}' is not long enough to copy all the items in the collection. Check '${$.$strNN("arrayIndex")}' and '${$.$strNN("array")}' length.`);
                    }
                    $.$$.System.Array.$WriteT1.call(array, value, arrayIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655819861)
            
            //--TRIMMABLE-BOUNDARY-START(206159544405)
            /*void */ SCG$ICollection$$$Add(/*string?*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159544405);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159544405)
            
            //--TRIMMABLE-BOUNDARY-START(257699151957)
            /*void */ SCG$IList$$$Insert(/*int*/ index, /*string?*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(257699151957);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257699151957)
            
            //--TRIMMABLE-BOUNDARY-START(236224315477)
            /*bool */ SCG$ICollection$$$Remove(/*string?*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236224315477);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236224315477)
            
            //--TRIMMABLE-BOUNDARY-START(261994119253)
            /*void */ SCG$IList$$$RemoveAt(/*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261994119253);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261994119253)
            
            //--TRIMMABLE-BOUNDARY-START(210454511701)
            /*void */ SCG$ICollection$$$Clear()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(210454511701);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210454511701)
            
            //--TRIMMABLE-BOUNDARY-START(111670263893)
            /*Enumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670263893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mep.MEP.StringValues.Enumerator().$ctor$4(this._values);
            }
            //--TRIMMABLE-BOUNDARY-END(111670263893)
            
            //--TRIMMABLE-BOUNDARY-START(240519282773)
            /*IEnumerator<string?> */ SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519282773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(240519282773)
            
            //--TRIMMABLE-BOUNDARY-START(279173988437)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173988437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(279173988437)
            
            //--TRIMMABLE-BOUNDARY-START(128850133077)
            static /*bool */ IsNullOrEmpty(/*StringValues*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850133077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let data = value._values;
                if (data === null)
                {
                    return true;
                }
                let values;
                if ($.$is(data, $.$typeArray($.$$.S.String), { set $v($v){ values = $v; } }))
                {
                    return (() =>
                    {
                        let $switch2 = values.length;
                        if ($switch2 === 0)
                        {
                            return true;
                        }
                        if ($switch2 === 1)
                        {
                            return $.$$.S.String.IsNullOrEmpty($.$$.System.Array.$ReadT1.call(values, 0));
                        }
                        return false;
                    })();
                }
                else 
                {
                    return $.$$.S.String.IsNullOrEmpty(data);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850133077)
            
            //--TRIMMABLE-BOUNDARY-START(34360852565)
            static /*StringValues */ Concat$2(/*StringValues*/ values1, /*StringValues*/ values2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360852565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count1 = values1.Count;
                /*int*/ let count2 = values2.Count;
                if (count1 === 0)
                {
                    return values2;
                }
                if (count2 === 0)
                {
                    return values1;
                }
                /*var*/ let combined = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [((count1 + count2) | 0)], null);
                values1.CopyTo(combined, 0);
                values2.CopyTo(combined, count1);
                return new $.$mep.MEP.StringValues().$ctor$4(combined);
            }
            //--TRIMMABLE-BOUNDARY-END(34360852565)
            
            //--TRIMMABLE-BOUNDARY-START(25770917973)
            static /*StringValues */ Concat(/*in StringValues*/ values, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770917973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return values.$v;
                }
                /*int*/ let count = values.$v.Count;
                if (count === 0)
                {
                    return new $.$mep.MEP.StringValues().$ctor$3(value);
                }
                /*var*/ let combined = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [((count + 1) | 0)], null);
                values.$v.CopyTo(combined, 0);
                $.$$.System.Array.$WriteT1.call(combined, value, count);
                return new $.$mep.MEP.StringValues().$ctor$4(combined);
            }
            //--TRIMMABLE-BOUNDARY-END(25770917973)
            
            //--TRIMMABLE-BOUNDARY-START(30065885269)
            static /*StringValues */ Concat$1(/*string?*/ value, /*in StringValues*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return values.$v;
                }
                /*int*/ let count = values.$v.Count;
                if (count === 0)
                {
                    return new $.$mep.MEP.StringValues().$ctor$3(value);
                }
                /*var*/ let combined = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [((count + 1) | 0)], null);
                $.$$.System.Array.$WriteT1.call(combined, value, 0);
                values.$v.CopyTo(combined, 1);
                return new $.$mep.MEP.StringValues().$ctor$4(combined);
            }
            //--TRIMMABLE-BOUNDARY-END(30065885269)
            
            //--TRIMMABLE-BOUNDARY-START(81605492821)
            static /*bool */ Equals$8(/*StringValues*/ left, /*StringValues*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605492821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = left.Count;
                if (count !== right.Count)
                {
                    return false;
                }
                for(/*int*/ let i = 0; i < count; i++)
                {
                    if (left.get_Item$1(i) !== right.get_Item$1(i))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(81605492821)
            
            //--TRIMMABLE-BOUNDARY-START(158914904149)
            static /*bool */ op_Equality$6(/*StringValues*/ left, /*StringValues*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914904149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.MEP.StringValues.Equals$8(left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(158914904149)
            
            //--TRIMMABLE-BOUNDARY-START(188979675221)
            static /*bool */ op_Inequality$6(/*StringValues*/ left, /*StringValues*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979675221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !$.$mep.MEP.StringValues.Equals$8(left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(188979675221)
            
            //--TRIMMABLE-BOUNDARY-START(85900460117)
            /*bool */ Equals$9(/*StringValues*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900460117);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(this, other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900460117)
            
            //--TRIMMABLE-BOUNDARY-START(55835689045)
            static /*bool */ Equals$2(/*string?*/ left, /*StringValues*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835689045);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(new $.$mep.MEP.StringValues().$ctor$3(left), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835689045)
            
            //--TRIMMABLE-BOUNDARY-START(73015558229)
            static /*bool */ Equals$6(/*StringValues*/ left, /*string?*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015558229);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(left, new $.$mep.MEP.StringValues().$ctor$3(right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015558229)
            
            //--TRIMMABLE-BOUNDARY-START(60130656341)
            /*bool */ Equals$3(/*string?*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130656341);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(this, new $.$mep.MEP.StringValues().$ctor$3(other));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130656341)
            
            //--TRIMMABLE-BOUNDARY-START(64425623637)
            static /*bool */ Equals$4(/*string?[]?*/ left, /*StringValues*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425623637);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(new $.$mep.MEP.StringValues().$ctor$4(left), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425623637)
            
            //--TRIMMABLE-BOUNDARY-START(77310525525)
            static /*bool */ Equals$7(/*StringValues*/ left, /*string?[]?*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310525525);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(left, new $.$mep.MEP.StringValues().$ctor$4(right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310525525)
            
            //--TRIMMABLE-BOUNDARY-START(68720590933)
            /*bool */ Equals$5(/*string?[]?*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720590933);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(this, new $.$mep.MEP.StringValues().$ctor$4(other));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720590933)
            
            //--TRIMMABLE-BOUNDARY-START(150324969557)
            static /*bool */ op_Equality$4(/*StringValues*/ left, /*string?*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324969557);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(left, new $.$mep.MEP.StringValues().$ctor$3(right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324969557)
            
            //--TRIMMABLE-BOUNDARY-START(180389740629)
            static /*bool */ op_Inequality$4(/*StringValues*/ left, /*string?*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180389740629);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$mep.MEP.StringValues.Equals$8(left, new $.$mep.MEP.StringValues().$ctor$3(right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389740629)
            
            //--TRIMMABLE-BOUNDARY-START(137440067669)
            static /*bool */ op_Equality$1(/*string?*/ left, /*StringValues*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440067669);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(new $.$mep.MEP.StringValues().$ctor$3(left), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137440067669)
            
            //--TRIMMABLE-BOUNDARY-START(167504838741)
            static /*bool */ op_Inequality$1(/*string?*/ left, /*StringValues*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504838741);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$mep.MEP.StringValues.Equals$8(new $.$mep.MEP.StringValues().$ctor$3(left), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504838741)
            
            //--TRIMMABLE-BOUNDARY-START(154619936853)
            static /*bool */ op_Equality$5(/*StringValues*/ left, /*string?[]?*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619936853);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(left, new $.$mep.MEP.StringValues().$ctor$4(right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619936853)
            
            //--TRIMMABLE-BOUNDARY-START(184684707925)
            static /*bool */ op_Inequality$5(/*StringValues*/ left, /*string?[]?*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684707925);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$mep.MEP.StringValues.Equals$8(left, new $.$mep.MEP.StringValues().$ctor$4(right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684707925)
            
            //--TRIMMABLE-BOUNDARY-START(141735034965)
            static /*bool */ op_Equality$2(/*string?[]?*/ left, /*StringValues*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141735034965);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mep.MEP.StringValues.Equals$8(new $.$mep.MEP.StringValues().$ctor$4(left), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735034965)
            
            //--TRIMMABLE-BOUNDARY-START(171799806037)
            static /*bool */ op_Inequality$2(/*string?[]?*/ left, /*StringValues*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799806037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$mep.MEP.StringValues.Equals$8(new $.$mep.MEP.StringValues().$ctor$4(left), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799806037)
            
            //--TRIMMABLE-BOUNDARY-START(146030002261)
            static /*bool */ op_Equality$3(/*StringValues*/ left, /*object?*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030002261);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return left.Equals$1(right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030002261)
            
            //--TRIMMABLE-BOUNDARY-START(176094773333)
            static /*bool */ op_Inequality$3(/*StringValues*/ left, /*object?*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094773333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !left.Equals$1(right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094773333)
            
            //--TRIMMABLE-BOUNDARY-START(133145100373)
            static /*bool */ op_Equality(/*object?*/ left, /*StringValues*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133145100373);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return right.Equals$1(left);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133145100373)
            
            //--TRIMMABLE-BOUNDARY-START(163209871445)
            static /*bool */ op_Inequality(/*object?*/ left, /*StringValues*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209871445);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !right.Equals$1(left);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209871445)
            
            //--TRIMMABLE-BOUNDARY-START(51540721749)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540721749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return $.$mep.MEP.StringValues.Equals$8(this, $.$mep.MEP.StringValues.Empty);
                }
                let str;
                if ($.$is(obj, $.$$.S.String, { set $v($v){ str = $v; } }))
                {
                    return $.$mep.MEP.StringValues.Equals$6(this, str);
                }
                let array;
                if ($.$is(obj, $.$typeArray($.$$.S.String), { set $v($v){ array = $v; } }))
                {
                    return $.$mep.MEP.StringValues.Equals$7(this, array);
                }
                let stringValues;
                if ($.$is(obj, $.$mep.MEP.StringValues, { set $v($v){ stringValues = $v; } }))
                {
                    return $.$mep.MEP.StringValues.Equals$8(this, stringValues);
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(51540721749)
            
            //--TRIMMABLE-BOUNDARY-START(115965231189)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965231189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let value = this._values;
                let values;
                if ($.$is(value, $.$typeArray($.$$.S.String), { set $v($v){ values = $v; } }))
                {
                    if (this.Count === 1)
                    {
                        /*string?*/ let __ca1__;
                        return ((__ca1__ = this.get_Item$1(0)) !== null ? $.$$.S.String.GetHashCode.call(__ca1__) : $.$$.S.Int32.GetHashCode.call(this.Count));
                    }
                    /*int*/ let hashCode = 0;
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        /*string*/ let __ca2__;
                        hashCode = $.$mep.SNH.HashHelpers.Combine(hashCode, ((__ca2__ = $.$$.System.Array.$ReadT1.call(values, i)) !== null ? $.$$.S.String.GetHashCode.call(__ca2__) : 0));
                    }
                    return hashCode;
                }
                else 
                {
                    /*string*/ let __ca3__;
                    return ((__ca3__ = value) !== null ? $.$$.S.String.GetHashCode.call(__ca3__) : $.$$.S.Int32.GetHashCode.call(this.Count));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965231189)
            
            //--TRIMMABLE-BOUNDARY-START(1179733)
            static $_Enumerator;
            static get Enumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1179733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mep.MEP.StringValues;
                return $cls.$_Enumerator ??= $asm.$nstr(`$mep.MEP.StringValues.Enumerator`, ($self) => class Enumerator extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12886081621)
                    /*string?[]?*/ _values = null;
                    //--TRIMMABLE-BOUNDARY-END(12886081621)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591114325)
                    /*int*/ _index = 0;
                    //--TRIMMABLE-BOUNDARY-END(8591114325)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296147029)
                    /*string?*/ _current = null;
                    //--TRIMMABLE-BOUNDARY-END(4296147029)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770983509)
                    $ctor$4(/*object?*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770983509);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let str;
                            if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                            {
                                this._values = null;
                                this._current = str;
                            }
                            else 
                            {
                                this._current = null;
                                this._values = value;
                            }
                            this._index = 0;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770983509)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476016213)
                    $ctor$3(/*ref StringValues*/ values)
                    {
                        this.$ctor$4(values.$v._values);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476016213);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476016213)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245819989)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245819989);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let index = this._index;
                        if (index < 0)
                        {
                            return false;
                        }
                        /*string?[]?*/ let values = this._values;
                        if (values !== null)
                        {
                            if ((index >>> 0) < (values.length >>> 0))
                            {
                                this._index = ((index + 1) | 0);
                                this._current = $.$$.System.Array.$ReadT1.call(values, index);
                                return true;
                            }
                            this._index = -1;
                            return false;
                        }
                        this._index = -1;
                        return this._current !== null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245819989)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065950805)
                    /*string? */ get Current()
                    {
                        return this._current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065950805)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540787285)
                    /*object? */ get SC$1$IEnumerator$Current()
                    {
                        return this._current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540787285)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425689173)
                    /*void */ SC$1$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425689173);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.S.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425689173)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360918101)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360918101);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360918101)
                    
                    //--TRIMMABLE-BOUNDARY-START(12945326081)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<string?>.Current.get
                    get SCG$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355391489);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945326081)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(17243373569)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    SC$1$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17243373569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17243373569)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181048917)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181048917);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181048917)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181048917)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181048917)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._values = this._values;
                        copy._index = this._index;
                        copy._current = this._current;
                        return copy;
                    }
                    static $h = 1179733;
                    static $z = 12;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065950805),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950852693,
        "f": 50331649
      },
      "n": "Current",
      "d": 1179733,
      "h": 30065950805,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065950805),
//--TRIMMABLE-BOUNDARY-START(51540787285),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130721877,
        "f": 50331650
      },
      "n": "{63504385}.Current",
      "o": "SC$1$IEnumerator$Current",
      "d": 1179733,
      "h": 51540787285,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51540787285)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245819989),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1179733,
      "h": 47245819989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245819989),
//--TRIMMABLE-BOUNDARY-START(34360918101),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1179733,
      "h": 34360918101,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360918101)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886081621),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "_values",
      "d": 1179733,
      "h": 12886081621,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081621),
//--TRIMMABLE-BOUNDARY-START(8591114325),
    {
      "t": 655361,
      "n": "_index",
      "d": 1179733,
      "h": 8591114325,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114325),
//--TRIMMABLE-BOUNDARY-START(4296147029),
    {
      "t": 1310721,
      "n": "_current",
      "d": 1179733,
      "h": 4296147029,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147029)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770983509),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1179733,
      "h": 25770983509,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25770983509),
//--TRIMMABLE-BOUNDARY-START(21476016213),
    {
      "p": [
        {
          "n": "values",
          "p": 1114197,
          "f": 4
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179733,
      "h": 21476016213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016213),
//--TRIMMABLE-BOUNDARY-START(17181048917),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179733,
      "h": 17181048917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048917)
  ],
  "d": 1114197,
  "h": 1179733
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.S.String), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.StringValues+Enumerator`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}StringValues${separator}Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1179733)
            
            //--TRIMMABLE-BOUNDARY-START(30124802049)
            //Generated interface implemetation for System.Collections.Generic.ICollection<string?>.Count.get
            get SCG$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534867457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124802049)
            
            //--TRIMMABLE-BOUNDARY-START(8650817537)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<string?>.this[int].get
            SCG$IReadOnlyList$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650817537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650817537)
            
            //--TRIMMABLE-BOUNDARY-START(12945653761)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<string?>.Count.get
            get SCG$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355719169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12945653761)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.Primitives.StringValues>.Equals(Microsoft.Extensions.Primitives.StringValues)
            S$IEquatable$Microsoft$Extensions$Primitives$StringValues$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$9(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<string?>.Equals(string?)
            S$IEquatable$System$String$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<string?[]?>.Equals(string?[]?)
            [`S$IEquatable$System$Array$System$String$$Equals`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$5(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(12886016085)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886016085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886016085)
            
            //--TRIMMABLE-BOUNDARY-START(12886016085)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886016085)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._values = this._values;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(8591048789)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591048789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(47245754453)
                    this.Empty = new $.$mep.MEP.StringValues().$ctor$4($.$$.S.Array.Empty($.$$.S.String));
                    //--TRIMMABLE-BOUNDARY-END(47245754453)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591048789)
            
            static $h = 1114197;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950787157),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490394709,
        "f": 50331649
      },
      "n": "Count",
      "d": 1114197,
      "h": 42950787157,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950787157),
//--TRIMMABLE-BOUNDARY-START(231929348181),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634380885,
        "f": 50331650
      },
      "n": "{$.$$.SCG.ICollection$$($.$$.S.String).$h}.IsReadOnly",
      "o": "SCG$ICollection$$$IsReadOnly",
      "d": 1114197,
      "h": 231929348181,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(231929348181),
//--TRIMMABLE-BOUNDARY-START(274879021141),
    {
      "p": 1310721,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 249109217365,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270584053845,
        "f": 83886082
      },
      "n": "{$.$$.SCG.IList$$($.$$.S.String).$h}.this[]",
      "o": "SCG$IList$$$Item",
      "d": 1114197,
      "h": 274879021141,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(274879021141),
//--TRIMMABLE-BOUNDARY-START(292058890325),
    {
      "p": 1310721,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080329301,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 1114197,
      "h": 292058890325,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292058890325)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(193274642517),
    {
      "r": 1310721,
      "n": "OutOfBounds",
      "d": 1114197,
      "h": 193274642517,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(193274642517),
//--TRIMMABLE-BOUNDARY-START(300648824917),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1114197,
      "h": 300648824917,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(300648824917),
//--TRIMMABLE-BOUNDARY-START(120260198485),
    {
      "r": 1310721,
      "n": "GetStringValue",
      "d": 1114197,
      "h": 120260198485,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120260198485),
//--TRIMMABLE-BOUNDARY-START(296353857621),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "n": "ToArray",
      "d": 1114197,
      "h": 296353857621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296353857621),
//--TRIMMABLE-BOUNDARY-START(107375296597),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "n": "GetArrayValue",
      "d": 1114197,
      "h": 107375296597,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107375296597),
//--TRIMMABLE-BOUNDARY-START(124555165781),
    {
      "r": 655361,
      "p": [
        {
          "n": "item",
          "p": 1310721
        }
      ],
      "n": "IndexOf",
      "d": 1114197,
      "h": 124555165781,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555165781),
//--TRIMMABLE-BOUNDARY-START(38655819861),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1114197,
      "h": 38655819861,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655819861),
//--TRIMMABLE-BOUNDARY-START(111670263893),
    {
      "r": 1179733,
      "n": "GetEnumerator",
      "d": 1114197,
      "h": 111670263893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670263893),
//--TRIMMABLE-BOUNDARY-START(128850133077),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1114197
        }
      ],
      "n": "IsNullOrEmpty",
      "d": 1114197,
      "h": 128850133077,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128850133077),
//--TRIMMABLE-BOUNDARY-START(34360852565),
    {
      "r": 1114197,
      "p": [
        {
          "n": "values1",
          "p": 1114197
        },
        {
          "n": "values2",
          "p": 1114197
        }
      ],
      "n": "Concat",
      "o": "@$2",
      "d": 1114197,
      "h": 34360852565,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360852565),
//--TRIMMABLE-BOUNDARY-START(25770917973),
    {
      "r": 1114197,
      "p": [
        {
          "n": "values",
          "p": 1114197,
          "f": 8
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Concat",
      "d": 1114197,
      "h": 25770917973,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770917973),
//--TRIMMABLE-BOUNDARY-START(30065885269),
    {
      "r": 1114197,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "values",
          "p": 1114197,
          "f": 8
        }
      ],
      "n": "Concat",
      "o": "@$1",
      "d": 1114197,
      "h": 30065885269,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065885269),
//--TRIMMABLE-BOUNDARY-START(81605492821),
    {
      "r": 262145,
      "p": [
        {
          "n": "left",
          "p": 1114197
        },
        {
          "n": "right",
          "p": 1114197
        }
      ],
      "n": "Equals",
      "o": "@$8",
      "d": 1114197,
      "h": 81605492821,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605492821),
//--TRIMMABLE-BOUNDARY-START(85900460117),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1114197
        }
      ],
      "n": "Equals",
      "o": "@$9",
      "d": 1114197,
      "h": 85900460117,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900460117),
//--TRIMMABLE-BOUNDARY-START(55835689045),
    {
      "r": 262145,
      "p": [
        {
          "n": "left",
          "p": 1310721
        },
        {
          "n": "right",
          "p": 1114197
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1114197,
      "h": 55835689045,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835689045),
//--TRIMMABLE-BOUNDARY-START(73015558229),
    {
      "r": 262145,
      "p": [
        {
          "n": "left",
          "p": 1114197
        },
        {
          "n": "right",
          "p": 1310721
        }
      ],
      "n": "Equals",
      "o": "@$6",
      "d": 1114197,
      "h": 73015558229,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015558229),
//--TRIMMABLE-BOUNDARY-START(60130656341),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1310721
        }
      ],
      "n": "Equals",
      "o": "@$3",
      "d": 1114197,
      "h": 60130656341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130656341),
//--TRIMMABLE-BOUNDARY-START(64425623637),
    {
      "r": 262145,
      "p": [
        {
          "n": "left",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "right",
          "p": 1114197
        }
      ],
      "n": "Equals",
      "o": "@$4",
      "d": 1114197,
      "h": 64425623637,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425623637),
//--TRIMMABLE-BOUNDARY-START(77310525525),
    {
      "r": 262145,
      "p": [
        {
          "n": "left",
          "p": 1114197
        },
        {
          "n": "right",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": "Equals",
      "o": "@$7",
      "d": 1114197,
      "h": 77310525525,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310525525),
//--TRIMMABLE-BOUNDARY-START(68720590933),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": "Equals",
      "o": "@$5",
      "d": 1114197,
      "h": 68720590933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720590933),
//--TRIMMABLE-BOUNDARY-START(51540721749),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1114197,
      "h": 51540721749,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540721749),
//--TRIMMABLE-BOUNDARY-START(115965231189),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1114197,
      "h": 115965231189,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115965231189)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245754453),
    {
      "t": 1114197,
      "n": "Empty",
      "d": 1114197,
      "h": 47245754453,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245754453),
//--TRIMMABLE-BOUNDARY-START(4296081493),
    {
      "t": 131073,
      "n": "_values",
      "d": 1114197,
      "h": 4296081493,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081493)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180983381),
    {
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114197,
      "h": 17180983381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983381),
//--TRIMMABLE-BOUNDARY-START(21475950677),
    {
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1114197,
      "h": 21475950677,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475950677),
//--TRIMMABLE-BOUNDARY-START(12886016085),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114197,
      "h": 12886016085,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016085)
  ],
  "h": 1114197,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{ToString()}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": null,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IList$$($.$$.S.String), $.$$.SCG.ICollection$$($.$$.S.String), $.$$.SCG.IReadOnlyList$$($.$$.S.String), $.$$.SCG.IReadOnlyCollection$$($.$$.S.String), $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.SC$1.IEnumerable, $.$$.S.IEquatable$$($.$mep.MEP.StringValues), $.$$.S.IEquatable$$($.$$.S.String), $.$$.S.IEquatable$$($.$typeArray($.$$.S.String)) ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mep.MEP.StringValues.Enumerator, /*$.$mep.MEP.StringValues.StringValuesDebugView*/$.$$.DeletedObject ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.StringValues`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}StringValues`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114197)
        
        

        //--TRIMMABLE-BOUNDARY-START(983125)
        $asm.$str(`$mep.MEP.StringTokenizer`, ($self) => class StringTokenizer extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590917717)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(8590917717)
            
            //--TRIMMABLE-BOUNDARY-START(4295950421)
            /*char[]*/ _separators = null;
            //--TRIMMABLE-BOUNDARY-END(4295950421)
            
            //--TRIMMABLE-BOUNDARY-START(21475819605)
            $ctor$4(/*string*/ value, /*char[]*/ separators)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475819605);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (value === null)
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.value*/);
                    }
                    if (separators === null)
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.separators*/);
                    }
                    this._value = $.$mep.MEP.StringSegment.op_Implicit$2(value);
                    this._separators = separators;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475819605)
            
            //--TRIMMABLE-BOUNDARY-START(17180852309)
            $ctor$3(/*StringSegment*/ value, /*char[]*/ separators)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180852309);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!value.HasValue)
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.value*/);
                    }
                    if (separators === null)
                    {
                        $.$mep.MEP.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.separators*/);
                    }
                    this._value = value;
                    this._separators = separators;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180852309)
            
            //--TRIMMABLE-BOUNDARY-START(25770786901)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770786901);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mep.MEP.StringTokenizer.Enumerator().$ctor$3($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mep.MEP.StringSegment, () => this._value, ($v) => this._value = $v, null, true), this._separators);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770786901)
            
            //--TRIMMABLE-BOUNDARY-START(30065754197)
            /*IEnumerator<StringSegment> */ SCG$IEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065754197);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065754197)
            
            //--TRIMMABLE-BOUNDARY-START(34360721493)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360721493);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360721493)
            
            //--TRIMMABLE-BOUNDARY-START(1048661)
            static $_Enumerator;
            static get Enumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mep.MEP.StringTokenizer;
                return $cls.$_Enumerator ??= $asm.$nstr(`$mep.MEP.StringTokenizer.Enumerator`, ($self) => class Enumerator extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885950549)
                    /*StringSegment*/ _value;
                    //--TRIMMABLE-BOUNDARY-END(12885950549)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590983253)
                    /*char[]*/ _separators = null;
                    //--TRIMMABLE-BOUNDARY-END(8590983253)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015957)
                    /*int*/ _index = 0;
                    //--TRIMMABLE-BOUNDARY-END(4296015957)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770852437)
                    $ctor$3(/*in StringSegment*/ value, /*char[]*/ separators)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770852437);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._value = value.$v;
                            this._separators = separators;
                            this.Current = new $.$mep.MEP.StringSegment();
                            this._index = 0;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770852437)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065819733)
                    $ctor$4(/*ref StringTokenizer*/ tokenizer)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065819733);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._value = tokenizer.$v._value;
                            this._separators = tokenizer.$v._separators;
                            this.Current = $.$default($.$mep.MEP.StringSegment);
                            this._index = 0;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065819733)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360787029)
                    /*StringSegment*/ Current;
                    //--TRIMMABLE-BOUNDARY-END(34360787029)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720525397)
                    /*object */ get SC$1$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720525397)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655754325)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655754325);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655754325)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540656213)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540656213);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._value.HasValue || this._index > this._value.Length)
                        {
                            this.Current = $.$default($.$mep.MEP.StringSegment);
                            return false;
                        }
                        /*int*/ let next = this._value.IndexOfAny$1(this._separators, this._index);
                        if (next === -1)
                        {
                            next = this._value.Length;
                        }
                        this.Current = this._value.Subsegment(this._index, ((next - this._index) | 0));
                        this._index = ((next + 1) | 0);
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540656213)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835623509)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835623509);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.Current = $.$default($.$mep.MEP.StringSegment);
                        this._index = 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835623509)
                    
                    //--TRIMMABLE-BOUNDARY-START(12945326081)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<Microsoft.Extensions.Primitives.StringSegment>.Current.get
                    get SCG$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355391489);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945326081)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(17243373569)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    SC$1$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17243373569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17243373569)
                    
                    //--TRIMMABLE-BOUNDARY-START(21538340865)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    SC$1$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21538340865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21538340865)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475885141)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475885141);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475885141)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475885141)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475885141)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._value = this._value.$clone();
                        copy._separators = this._separators;
                        copy._index = this._index;
                        copy.Current = this.Current.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12885950549)
                        this._value = $.$default($.$mep.MEP.StringSegment);
                        //--TRIMMABLE-BOUNDARY-END(12885950549)
                        
                        //--TRIMMABLE-BOUNDARY-START(34360787029)
                        this.Current = $.$default($.$mep.MEP.StringSegment);
                        //--TRIMMABLE-BOUNDARY-END(34360787029)
                        
                    }
                    static $h = 1048661;
                    static $z = 32;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360787029),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245688917,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425558101,
        "f": 83886082
      },
      "n": "Current",
      "d": 1048661,
      "h": 34360787029,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360787029),
//--TRIMMABLE-BOUNDARY-START(68720525397),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310459989,
        "f": 50331650
      },
      "n": "{63504385}.Current",
      "o": "SC$1$IEnumerator$Current",
      "d": 1048661,
      "h": 68720525397,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68720525397)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655754325),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1048661,
      "h": 38655754325,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655754325),
//--TRIMMABLE-BOUNDARY-START(51540656213),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1048661,
      "h": 51540656213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540656213),
//--TRIMMABLE-BOUNDARY-START(55835623509),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1048661,
      "h": 55835623509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835623509)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885950549),
    {
      "t": 852053,
      "n": "_value",
      "d": 1048661,
      "h": 12885950549,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885950549),
//--TRIMMABLE-BOUNDARY-START(8590983253),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_separators",
      "d": 1048661,
      "h": 8590983253,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983253),
//--TRIMMABLE-BOUNDARY-START(4296015957),
    {
      "t": 655361,
      "n": "_index",
      "d": 1048661,
      "h": 4296015957,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015957)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770852437),
    {
      "p": [
        {
          "n": "value",
          "p": 852053,
          "f": 8
        },
        {
          "n": "separators",
          "p": $.$typeArray($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048661,
      "h": 25770852437,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25770852437),
//--TRIMMABLE-BOUNDARY-START(30065819733),
    {
      "p": [
        {
          "n": "tokenizer",
          "p": 983125,
          "f": 4
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1048661,
      "h": 30065819733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065819733),
//--TRIMMABLE-BOUNDARY-START(21475885141),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048661,
      "h": 21475885141,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885141)
  ],
  "d": 983125,
  "h": 1048661
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$mep.MEP.StringSegment), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.StringTokenizer+Enumerator`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}StringTokenizer${separator}Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048661)
            
            //--TRIMMABLE-BOUNDARY-START(12885885013)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885885013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885885013)
            
            //--TRIMMABLE-BOUNDARY-START(12885885013)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885885013)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._value = this._value.$clone();
                copy._separators = this._separators;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590917717)
                this._value = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8590917717)
                
            }
            static $h = 983125;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770786901),
    {
      "r": 1048661,
      "n": "GetEnumerator",
      "d": 983125,
      "h": 25770786901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770786901)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590917717),
    {
      "t": 852053,
      "n": "_value",
      "d": 983125,
      "h": 8590917717,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917717),
//--TRIMMABLE-BOUNDARY-START(4295950421),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_separators",
      "d": 983125,
      "h": 4295950421,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950421)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475819605),
    {
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "separators",
          "p": $.$typeArray($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 983125,
      "h": 21475819605,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475819605),
//--TRIMMABLE-BOUNDARY-START(17180852309),
    {
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "separators",
          "p": $.$typeArray($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 983125,
      "h": 17180852309,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180852309),
//--TRIMMABLE-BOUNDARY-START(12885885013),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983125,
      "h": 12885885013,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885885013)
  ],
  "h": 983125
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerable$$($.$mep.MEP.StringSegment), $.$$.SC$1.IEnumerable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mep.MEP.StringTokenizer.Enumerator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.StringTokenizer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}StringTokenizer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983125)
        
        

        //--TRIMMABLE-BOUNDARY-START(917589)
        $asm.$cls(`$mep.MEP.StringSegmentComparer`, ($self) => class StringSegmentComparer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85900263509)
            /*StringSegmentComparer*/ static Ordinal = null;
            //--TRIMMABLE-BOUNDARY-END(85900263509)
            
            //--TRIMMABLE-BOUNDARY-START(90195230805)
            /*StringSegmentComparer*/ static OrdinalIgnoreCase = null;
            //--TRIMMABLE-BOUNDARY-END(90195230805)
            
            //--TRIMMABLE-BOUNDARY-START(25770721365)
            $ctor$1(/*StringComparison*/ comparison, /*StringComparer*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770721365);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Comparison = comparison;
                    this.Comparer = comparer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770721365)
            
            //--TRIMMABLE-BOUNDARY-START(38655623253)
            /*StringComparison*/ Comparison = 0;
            //--TRIMMABLE-BOUNDARY-END(38655623253)
            
            //--TRIMMABLE-BOUNDARY-START(34360655957)
            /*StringComparer*/ Comparer = null;
            //--TRIMMABLE-BOUNDARY-END(34360655957)
            
            //--TRIMMABLE-BOUNDARY-START(30065688661)
            /*int */ Compare(/*StringSegment*/ x, /*StringSegment*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065688661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.MEP.StringSegment.Compare(x, y, this.Comparison);
            }
            //--TRIMMABLE-BOUNDARY-END(30065688661)
            
            //--TRIMMABLE-BOUNDARY-START(42950590549)
            /*bool */ Equals$2(/*StringSegment*/ x, /*StringSegment*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.MEP.StringSegment.Equals$5(x, y, this.Comparison);
            }
            //--TRIMMABLE-BOUNDARY-END(42950590549)
            
            //--TRIMMABLE-BOUNDARY-START(81605296213)
            /*int */ GetHashCode$1(/*StringSegment*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.GetHashCode$1(obj.AsSpan(), this.Comparison);
            }
            //--TRIMMABLE-BOUNDARY-END(81605296213)
            
            //--TRIMMABLE-BOUNDARY-START(4355129345)
            //Generated interface implemetation for System.Collections.Generic.IComparer<Microsoft.Extensions.Primitives.StringSegment>.Compare(Microsoft.Extensions.Primitives.StringSegment, Microsoft.Extensions.Primitives.StringSegment)
            SCG$IComparer$Microsoft$Extensions$Primitives$StringSegment$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355129345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355129345)
            
            //--TRIMMABLE-BOUNDARY-START(4355457025)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<Microsoft.Extensions.Primitives.StringSegment>.Equals(Microsoft.Extensions.Primitives.StringSegment, Microsoft.Extensions.Primitives.StringSegment)
            SCG$IEqualityComparer$Microsoft$Extensions$Primitives$StringSegment$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355457025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355457025)
            
            //--TRIMMABLE-BOUNDARY-START(8650424321)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<Microsoft.Extensions.Primitives.StringSegment>.GetHashCode(Microsoft.Extensions.Primitives.StringSegment)
            SCG$IEqualityComparer$Microsoft$Extensions$Primitives$StringSegment$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650424321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650424321)
            
            //--TRIMMABLE-BOUNDARY-START(21475754069)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475754069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(85900263509)
                    this.Ordinal = new $.$mep.MEP.StringSegmentComparer().$ctor$1(4/*StringComparison.Ordinal*/, $.$$.S.StringComparer.Ordinal);
                    //--TRIMMABLE-BOUNDARY-END(85900263509)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195230805)
                    this.OrdinalIgnoreCase = new $.$mep.MEP.StringSegmentComparer().$ctor$1(5/*StringComparison.OrdinalIgnoreCase*/, $.$$.S.StringComparer.OrdinalIgnoreCase);
                    //--TRIMMABLE-BOUNDARY-END(90195230805)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475754069)
            
            static $h = 917589;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900263509),
    {
      "p": 917589,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720394325,
        "f": 50331681
      },
      "n": "Ordinal",
      "d": 917589,
      "h": 85900263509,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(85900263509),
//--TRIMMABLE-BOUNDARY-START(90195230805),
    {
      "p": 917589,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310328917,
        "f": 50331681
      },
      "n": "OrdinalIgnoreCase",
      "d": 917589,
      "h": 90195230805,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(90195230805),
//--TRIMMABLE-BOUNDARY-START(38655623253),
    {
      "p": 164364289,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130459733,
        "f": 50331650
      },
      "n": "Comparison",
      "d": 917589,
      "h": 38655623253,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38655623253),
//--TRIMMABLE-BOUNDARY-START(34360655957),
    {
      "p": 164298753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540525141,
        "f": 50331650
      },
      "n": "Comparer",
      "d": 917589,
      "h": 34360655957,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34360655957)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065688661),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": 852053
        },
        {
          "n": "y",
          "p": 852053
        }
      ],
      "n": "Compare",
      "d": 917589,
      "h": 30065688661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688661),
//--TRIMMABLE-BOUNDARY-START(42950590549),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": 852053
        },
        {
          "n": "y",
          "p": 852053
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 917589,
      "h": 42950590549,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950590549),
//--TRIMMABLE-BOUNDARY-START(81605296213),
    {
      "r": 655361,
      "p": [
        {
          "n": "obj",
          "p": 852053
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 917589,
      "h": 81605296213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605296213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770721365),
    {
      "p": [
        {
          "n": "comparison",
          "p": 164364289
        },
        {
          "n": "comparer",
          "p": 164298753
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917589,
      "h": 25770721365,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770721365)
  ],
  "h": 917589
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IComparer$$($.$mep.MEP.StringSegment), $.$$.SCG.IEqualityComparer$$($.$mep.MEP.StringSegment) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Primitives.StringSegmentComparer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Primitives${separator}StringSegmentComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917589)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory"));
})();
//--TRIMMABLE-BOUNDARY-END(85)
