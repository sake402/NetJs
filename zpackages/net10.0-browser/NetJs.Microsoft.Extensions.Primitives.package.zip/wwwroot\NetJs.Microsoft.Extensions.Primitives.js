
(function ($global, $, $spc, $sm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Primitives", 
    {"h":2,"f":"Microsoft.Extensions.Primitives","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mep.Microsoft.Extensions.Primitives.IChangeToken", ($self) => class IChangeToken
        {
            static $h = 720898;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590655490,"f":257},"n":"HasChanged","o":"Microsoft$Extensions$Primitives$IChangeToken$HasChanged","d":720898,"h":4295688194,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":17180590082,"f":257},"n":"ActiveChangeCallbacks","o":"Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks","d":720898,"h":12885622786,"f":257}],"m":[{"r":57475073,"p":[{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"RegisterChangeCallback","o":"Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback","d":720898,"h":21475557378,"f":257}],"h":720898}; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.IChangeToken`; }
        });
        
        $asm.$cls("$mep.System.Numerics.Hashing.HashHelpers", ($self) => class HashHelpers
        {
            static /*int */ Combine(/*int*/ h1, /*int*/ h2)
            {
                /*uint*/ let rol5 = (((h1 >>> 0) << 5) >>> 0) | ((h1 >>> 0) >>> 27);
                return ((((rol5 | 0) + h1) | 0)) ^ h2;
            }
            static $h = 1310722;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"h1","p":655361},{"n":"h2","p":655361}],"n":"Combine","d":1310722,"h":4296278018,"f":33}],"h":1310722}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Numerics.Hashing.HashHelpers`; }
        });
        
        $asm.$cls("$mep.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mep.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Primitives", $.$mep.System.SR.$type.Assembly);
                    $.$mep.System.SR.s_resourceManager = temp;
                }
                return $.$mep.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mep.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mep.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_InvalidOffsetLength()
            {
                return "Offset and length are out of bounds for the string or length is greater than the number of characters from index to the end of the string.";
            }
            static /*string */ get Argument_InvalidOffsetLengthStringSegment()
            {
                return "Offset and length are out of bounds for this StringSegment or length is greater than the number of characters to the end of this StringSegment.";
            }
            static /*string */ get Capacity_CannotChangeAfterWriteStarted()
            {
                return "Cannot change capacity after write started.";
            }
            static /*string */ get Capacity_NotEnough()
            {
                return "Not enough capacity to write '{0}' characters, only '{1}' left.";
            }
            static /*string */ FormatCapacity_NotEnough(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Not enough capacity to write '{0}' characters, only '{1}' left.", arg1, arg2);
            }
            static /*string */ get Capacity_NotUsedEntirely()
            {
                return "Entire reserved capacity was not used. Capacity: '{0}', written '{1}'.";
            }
            static /*string */ FormatCapacity_NotUsedEntirely(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Entire reserved capacity was not used. Capacity: '{0}', written '{1}'.", arg1, arg2);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mep.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mep.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mep.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mep.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mep.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mep.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mep.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mep.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mep.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mep.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mep.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mep.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mep.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1376258;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1376258}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mep.Microsoft.Extensions.Internal.ChangeCallbackRegistrar", ($self) => class ChangeCallbackRegistrar
        {
            static /*IDisposable */ UnsafeRegisterChangeCallback(T, /*Action<object?>*/ callback, /*object?*/ state, /*CancellationToken*/ token, /*Action<T>*/ onFailure, /*T*/ onFailureState)
            {
                try
                {
                    return token.UnsafeRegister(callback, state);
                }
                catch($e)
                {
                    onFailure.Invoke(onFailureState);
                }
                return $.$mep.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
            }
            static $h = 131074;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":57475073,"p":[{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":125960193},{"n":"onFailure","p":(T) => $.$spc.System.Action$$(T).$h},{"n":"onFailureState","p":0}],"g":["T"],"n":"UnsafeRegisterChangeCallback","d":131074,"h":4295098370,"f":131112}],"h":131074}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.ChangeCallbackRegistrar`; }
        });
        
        $asm.$cls("$mep.Microsoft.Extensions.Primitives.ChangeToken", ($self) => class ChangeToken
        {
            static /*IDisposable */ OnChange(/*Func<IChangeToken?>*/ changeTokenProducer, /*Action*/ changeTokenConsumer)
            {
                if (changeTokenProducer === null)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.changeTokenProducer*/);
                }
                if (changeTokenConsumer === null)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.changeTokenConsumer*/);
                }
                return new ($.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$($.$spc.System.Action))().$ctor$1(changeTokenProducer, new ($.$spc.System.Action$$($.$spc.System.Action))().$ctor(this,  (/*callback*/ callback) =>
                {
                    return callback.Invoke();
                }), changeTokenConsumer);
            }
            static /*IDisposable */ OnChange$1(TState, /*Func<IChangeToken?>*/ changeTokenProducer, /*Action<TState>*/ changeTokenConsumer, /*TState*/ state)
            {
                if (changeTokenProducer === null)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.changeTokenProducer*/);
                }
                if (changeTokenConsumer === null)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.changeTokenConsumer*/);
                }
                return new ($.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState))().$ctor$1(changeTokenProducer, changeTokenConsumer, state);
            }
            static $_ChangeTokenRegistration$$;
            static ChangeTokenRegistration$$(TState)
            {
                let $cls = $.$mep.Microsoft.Extensions.Primitives.ChangeToken;
                return ($cls.$_ChangeTokenRegistration$$ ??= $asm.$ncls("$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration<>", (TState) => $asm.$gt("$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration<>", [TState], ($self) => class ChangeTokenRegistration$$ extends $.$spc.System.Object
                {
                    /*Func<IChangeToken?>*/ _changeTokenProducer = null;
                    /*Action<TState>*/ _changeTokenConsumer = null;
                    /*TState*/ _state = $.$default(TState);
                    /*IDisposable?*/ _disposable = null;
                    /*NoopDisposable*/ static _disposedSentinel = null;
                    $ctor$1(/*Func<IChangeToken?>*/ changeTokenProducer, /*Action<TState>*/ changeTokenConsumer, /*TState*/ state)
                    {
                        super.$ctor();
                        {
                            this._changeTokenProducer = changeTokenProducer;
                            this._changeTokenConsumer = changeTokenConsumer;
                            this._state = state;
                            /*IChangeToken?*/ let token = changeTokenProducer.Invoke();
                            this.RegisterChangeTokenCallback(token);
                        }
                        return this;
                    }
                    /*void */ OnChangeTokenFired()
                    {
                        /*IChangeToken?*/ let token = this._changeTokenProducer.Invoke();
                        try
                        {
                            this._changeTokenConsumer.Invoke(this._state);
                        }
                        finally
                        {
                            {
                                this.RegisterChangeTokenCallback(token);
                            }
                        }
                    }
                    /*void */ RegisterChangeTokenCallback(/*IChangeToken?*/ token)
                    {
                        if (token === null)
                        {
                            return;
                        }
                        /*IDisposable*/ let registraton = token.Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*s*/ s) =>
                        {
                            return ($.$cast(s, $.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState))).OnChangeTokenFired();
                        }), this);
                        if (token.Microsoft$Extensions$Primitives$IChangeToken$HasChanged && token.Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks)
                        {
                            registraton?.System$IDisposable$Dispose();
                            return;
                        }
                        this.SetDisposable(registraton);
                    }
                    /*void */ SetDisposable(/*IDisposable*/ disposable)
                    {
                        /*IDisposable?*/ let current = $.$ref(() => this._disposable, ($v) => this._disposable = $v, $.$spc.System.IDisposable).$v;
                        if (current === $.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState)._disposedSentinel)
                        {
                            disposable.System$IDisposable$Dispose();
                            return;
                        }
                        /*IDisposable?*/ let previous = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.IDisposable, $.$ref(() => this._disposable, ($v) => this._disposable = $v, $.$spc.System.IDisposable), disposable, current);
                        if (previous === $.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState)._disposedSentinel)
                        {
                            disposable.System$IDisposable$Dispose();
                        }
                        else if (previous === current)
                        {
                        }
                        else 
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("Somebody else set the _disposable field");
                        }
                    }
                    /*void */ Dispose()
                    {
                        $.$spc.System.Threading.Interlocked.Exchange$14($.$spc.System.IDisposable, $.$ref(() => this._disposable, ($v) => this._disposable = $v, $.$spc.System.IDisposable), $.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState)._disposedSentinel)?.System$IDisposable$Dispose();
                    }
                    static $_NoopDisposable;
                    static get NoopDisposable()
                    {
                        let $cls = $.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState);
                        return $cls.$_NoopDisposable ??= $asm.$ncls("$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$.NoopDisposable", ($self) => class NoopDisposable extends $.$spc.System.Object
                        {
                            /*void */ Dispose()
                            {
                            }
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                return this.Dispose(...arguments);
                            }
                            //default reference type constructor overload
                            $ctor$1()
                            {
                                super.$ctor();
                                return this;
                            }
                            static $h = 393218;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[57475073],"d":$.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState).$h,"h":this.$h}; }
                            static get $b() { return $.$spc.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                            static get $fullName() { return `Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration<${TState?.$fullName}>.NoopDisposable`; }
                        }, $cls, ($v) => $cls.$_NoopDisposable = $v);
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this._disposedSentinel = new ($.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState).NoopDisposable)().$ctor$1();
                        }
                    }
                    static $h = 327682;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"OnChangeTokenFired","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},{"r":65537,"p":[{"n":"token","p":720898}],"n":"RegisterChangeTokenCallback","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2},{"r":65537,"p":[{"n":"disposable","p":57475073}],"n":"SetDisposable","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1}],"l":[{"t":$.$spc.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken).$h,"n":"_changeTokenProducer","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$spc.System.Action$$(TState).$h,"n":"_changeTokenConsumer","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":TState?.$h??1507328,"n":"_state","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":57475073,"n":"_disposable","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":$.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState).NoopDisposable.$h,"n":"_disposedSentinel","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":34}],"c":[{"p":[{"n":"changeTokenProducer","p":$.$spc.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken).$h},{"n":"changeTokenConsumer","p":$.$spc.System.Action$$(TState).$h},{"n":"state","p":TState?.$h??1507328}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"i":[57475073],"g":[TState?.$h??1507328],"j":[$.$mep.Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration$$(TState).NoopDisposable.$h],"r":1,"d":262146,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Primitives.ChangeToken.ChangeTokenRegistration<${TState?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ChangeTokenRegistration$$ = $v))(TState);
            }
            static $h = 262146;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":57475073,"p":[{"n":"changeTokenProducer","p":$.$spc.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken).$h},{"n":"changeTokenConsumer","p":11665409}],"n":"OnChange","d":262146,"h":4295229442,"f":33},{"r":57475073,"p":[{"n":"changeTokenProducer","p":$.$spc.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken).$h},{"n":"changeTokenConsumer","p":(TState) => $.$spc.System.Action$$(TState).$h},{"n":"state","p":4298571776}],"g":["TState"],"n":"OnChange","o":"@$1","d":262146,"h":8590196738,"f":131105}],"j":[327682],"h":262146}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.ChangeToken`; }
        });
        
        $asm.$cls("$mep.Microsoft.Extensions.Primitives.Extensions", ($self) => class Extensions
        {
            static /*StringBuilder */ Append(/*this StringBuilder*/ builder, /*StringSegment*/ segment)
            {
                return builder.Append$3(segment.Buffer, segment.Offset, segment.Length);
            }
            static $h = 655362;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":122945537,"p":[{"n":"builder","p":122945537},{"n":"segment","p":851970}],"n":"Append","d":655362,"h":4295622658,"f":33}],"h":655362}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.Extensions`; }
        });
        
        $asm.$cls("$mep.Microsoft.Extensions.Primitives.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw new $.$spc.System.ArgumentNullException().$ctor$16($.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentName(argument));
            }
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentName(argument));
            }
            static /*void */ ThrowArgumentException(/*ExceptionResource*/ resource)
            {
                throw new $.$spc.System.ArgumentException().$ctor$10($.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetResourceText(resource));
            }
            static /*void */ ThrowInvalidOperationException(/*ExceptionResource*/ resource)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetResourceText(resource));
            }
            static /*void */ ThrowInvalidOperationException$1(/*ExceptionResource*/ resource, /*params object[]*/ args)
            {
                /*string*/ let message = $.$spc.System.String.Format$3($.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetResourceText(resource), args);
                throw new $.$spc.System.InvalidOperationException().$ctor$10(message);
            }
            static /*ArgumentNullException */ GetArgumentNullException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentNullException().$ctor$16($.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentName(argument));
            }
            static /*ArgumentOutOfRangeException */ GetArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentName(argument));
            }
            static /*ArgumentException */ GetArgumentException(/*ExceptionResource*/ resource)
            {
                return new $.$spc.System.ArgumentException().$ctor$10($.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetResourceText(resource));
            }
            static /*string */ GetResourceText(/*ExceptionResource*/ resource)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Enum.IsDefined$1($.$mep.Microsoft.Extensions.Primitives.ExceptionResource.$type, $.$box(resource, $.$mep.Microsoft.Extensions.Primitives.ExceptionResource)), "The enum value is not defined, please check the ExceptionResource Enum.");
                switch(resource)
                {
                    case 0/*ExceptionResource.Argument_InvalidOffsetLength*/:
                    return $.$mep.System.SR.Argument_InvalidOffsetLength;
                    case 1/*ExceptionResource.Argument_InvalidOffsetLengthStringSegment*/:
                    return $.$mep.System.SR.Argument_InvalidOffsetLengthStringSegment;
                    case 2/*ExceptionResource.Capacity_CannotChangeAfterWriteStarted*/:
                    return $.$mep.System.SR.Capacity_CannotChangeAfterWriteStarted;
                    case 3/*ExceptionResource.Capacity_NotEnough*/:
                    return $.$mep.System.SR.Capacity_NotEnough;
                    case 4/*ExceptionResource.Capacity_NotUsedEntirely*/:
                    return $.$mep.System.SR.Capacity_NotUsedEntirely;
                    default:
                    $.$spc.System.Diagnostics.Debug.Fail(`Unexpected resource ${resource}`);
                    return "";
                }
            }
            static /*string */ GetArgumentName(/*ExceptionArgument*/ argument)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Enum.IsDefined$1($.$mep.Microsoft.Extensions.Primitives.ExceptionArgument.$type, $.$box(argument, $.$mep.Microsoft.Extensions.Primitives.ExceptionArgument)), "The enum value is not defined, please check the ExceptionArgument Enum.");
                return $.$spc.System.Enum.ToStringT($.$mep.Microsoft.Extensions.Primitives.ExceptionArgument, $.$spc.System.UInt32, argument);
            }
            static $h = 1245186;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":524290}],"n":"ThrowArgumentNullException","d":1245186,"h":4296212482,"f":40},{"r":65537,"p":[{"n":"argument","p":524290}],"n":"ThrowArgumentOutOfRangeException","d":1245186,"h":8591179778,"f":40},{"r":65537,"p":[{"n":"resource","p":589826}],"n":"ThrowArgumentException","d":1245186,"h":12886147074,"f":40},{"r":65537,"p":[{"n":"resource","p":589826}],"n":"ThrowInvalidOperationException","d":1245186,"h":17181114370,"f":40},{"r":65537,"p":[{"n":"resource","p":589826},{"n":"args","p":0,"f":16}],"n":"ThrowInvalidOperationException","o":"@$1","d":1245186,"h":21476081666,"f":40},{"r":13434881,"p":[{"n":"argument","p":524290}],"n":"GetArgumentNullException","d":1245186,"h":25771048962,"f":40},{"r":13500417,"p":[{"n":"argument","p":524290}],"n":"GetArgumentOutOfRangeException","d":1245186,"h":30066016258,"f":40},{"r":13369345,"p":[{"n":"resource","p":589826}],"n":"GetArgumentException","d":1245186,"h":34360983554,"f":40},{"r":1310721,"p":[{"n":"resource","p":589826}],"n":"GetResourceText","d":1245186,"h":38655950850,"f":34},{"r":1310721,"p":[{"n":"argument","p":524290}],"n":"GetArgumentName","d":1245186,"h":42950918146,"f":34}],"h":1245186}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.ThrowHelper`; }
        });
        
        $asm.$cls("$mep.Microsoft.Extensions.FileProviders.EmptyDisposable", ($self) => class EmptyDisposable extends $.$spc.System.Object
        {
            /*EmptyDisposable*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mep.Microsoft.Extensions.FileProviders.EmptyDisposable().$ctor$1();
                }
            }
            static $h = 65538;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":65538,"g":{"r":0,"d":0,"h":12884967426,"f":33},"n":"Instance","d":65538,"h":8590000130,"f":33}],"m":[{"r":65537,"n":"Dispose","d":65538,"h":21474902018,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":65538,"h":17179934722,"f":2}],"i":[57475073],"h":65538}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
        });
        
        $asm.$cls("$mep.Microsoft.Extensions.Primitives.CancellationChangeToken", ($self) => class CancellationChangeToken extends $.$spc.System.Object
        {
            $ctor$1(/*CancellationToken*/ cancellationToken)
            {
                super.$ctor();
                {
                    this.Token = cancellationToken;
                }
                return this;
            }
            /*bool*/ ActiveChangeCallbacks = false;
            /*bool */ get HasChanged()
            {
                return this.Token.IsCancellationRequested;
            }
            /*CancellationToken*/ Token;
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                return $.$mep.Microsoft.Extensions.Internal.ChangeCallbackRegistrar.UnsafeRegisterChangeCallback($.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken, callback, state, this.Token, new ($.$spc.System.Action$$($.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken))().$ctor(null, /*static*/ (/*s*/ s) =>
                {
                    return s.ActiveChangeCallbacks = false;
                }), this);
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                return this.HasChanged;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                return this.ActiveChangeCallbacks;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback()
            {
                return this.RegisterChangeCallback(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.ActiveChangeCallbacks = true;
                this.Token = $.$default($.$spc.System.Threading.CancellationToken);
            }
            static $h = 196610;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180065794,"f":1},"s":{"r":0,"d":0,"h":21475033090,"f":2},"n":"ActiveChangeCallbacks","d":196610,"h":12885098498,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30064967682,"f":1},"n":"HasChanged","d":196610,"h":25770000386,"f":1},{"p":125960193,"g":{"r":0,"d":0,"h":42949869570,"f":2},"n":"Token","d":196610,"h":38654902274,"f":2}],"m":[{"r":57475073,"p":[{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"RegisterChangeCallback","d":196610,"h":47244836866,"f":1}],"c":[{"p":[{"n":"cancellationToken","p":125960193}],"n":".ctor","o":"$ctor$1","d":196610,"h":4295163906,"f":1}],"i":[720898],"h":196610,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"HasChanged = {HasChanged}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.CancellationChangeToken`; }
        });
        
        $asm.$cls("$mep.Microsoft.Extensions.Primitives.CompositeChangeToken", ($self) => class CompositeChangeToken extends $.$spc.System.Object
        {
            /*Action<object?>*/ static _onChangeDelegate = null;
            /*object*/ _callbackLock = null;
            /*CancellationTokenSource?*/ _cancellationTokenSource = null;
            /*List<IDisposable>?*/ _disposables = null;
            /*bool*/ RegisteredCallbackProxy = false;
            $ctor$1(/*IReadOnlyList<IChangeToken>*/ changeTokens)
            {
                super.$ctor();
                {
                    if (changeTokens === null)
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.changeTokens*/);
                    }
                    this.ChangeTokens = changeTokens;
                    for(/*int*/ let i = 0; i < this.ChangeTokens.System$Collections$Generic$IReadOnlyCollection$$$Count; i++)
                    {
                        if (this.ChangeTokens.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$mep.Microsoft.Extensions.Primitives.IChangeToken]).Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks)
                        {
                            this.ActiveChangeCallbacks = true;
                            break;
                        }
                    }
                }
                return this;
            }
            /*IReadOnlyList<IChangeToken>*/ ChangeTokens = null;
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                this.EnsureCallbacksInitialized();
                return this._cancellationTokenSource.Token.Register$2(callback, state);
            }
            /*bool */ get HasChanged()
            {
                if (this._cancellationTokenSource !== null && this._cancellationTokenSource.Token.IsCancellationRequested)
                {
                    return true;
                }
                for(/*int*/ let i = 0; i < this.ChangeTokens.System$Collections$Generic$IReadOnlyCollection$$$Count; i++)
                {
                    if (this.ChangeTokens.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$mep.Microsoft.Extensions.Primitives.IChangeToken]).Microsoft$Extensions$Primitives$IChangeToken$HasChanged)
                    {
                        $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken.OnChange(this);
                        return true;
                    }
                }
                return false;
            }
            /*bool*/ ActiveChangeCallbacks = false;
            /*void */ EnsureCallbacksInitialized()
            {
                if (this.RegisteredCallbackProxy)
                {
                    return;
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._callbackLock)
                    {
                        if (this.RegisteredCallbackProxy)
                        {
                            return;
                        }
                        this._cancellationTokenSource = new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                        this._disposables = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.IDisposable))().$ctor$1();
                        for(/*int*/ let i = 0; i < this.ChangeTokens.System$Collections$Generic$IReadOnlyCollection$$$Count; i++)
                        {
                            if (this.ChangeTokens.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$mep.Microsoft.Extensions.Primitives.IChangeToken]).Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks)
                            {
                                /*IDisposable*/ let disposable = this.ChangeTokens.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$mep.Microsoft.Extensions.Primitives.IChangeToken]).Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback($.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken._onChangeDelegate, this);
                                if (this._cancellationTokenSource.IsCancellationRequested)
                                {
                                    disposable.System$IDisposable$Dispose();
                                    break;
                                }
                                this._disposables.Add(disposable);
                            }
                        }
                        this.RegisteredCallbackProxy = true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._callbackLock)
                }
            }
            static /*void */ OnChange(/*object?*/ state)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(state !== null, "state != null");
                /*var*/ let compositeChangeTokenState = $.$cast(state, $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken);
                if (compositeChangeTokenState._cancellationTokenSource === null)
                {
                    return;
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(compositeChangeTokenState._callbackLock)
                    {
                        if (compositeChangeTokenState._cancellationTokenSource.IsCancellationRequested)
                        {
                            return;
                        }
                        try
                        {
                            compositeChangeTokenState._cancellationTokenSource.Cancel();
                        }
                        catch($e)
                        {
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(compositeChangeTokenState._callbackLock)
                }
                /*List<IDisposable>?*/ let disposables = compositeChangeTokenState._disposables;
                $.$spc.System.Diagnostics.Debug.Assert$1(disposables !== null, "disposables != null");
                for(/*int*/ let i = 0; i < disposables.Count; i++)
                {
                    disposables.get_Item(i).System$IDisposable$Dispose();
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                return this.HasChanged;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                return this.ActiveChangeCallbacks;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback()
            {
                return this.RegisterChangeCallback(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._callbackLock = new $.$spc.System.Object().$ctor();
                this.RegisteredCallbackProxy = false;
                this.ActiveChangeCallbacks = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._onChangeDelegate = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(null, $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken.OnChange);
                }
            }
            static $h = 458754;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30065229826,"f":2},"s":{"r":0,"d":0,"h":34360197122,"f":2},"n":"RegisteredCallbackProxy","d":458754,"h":25770262530,"f":2},{"p":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken).$h,"g":{"r":0,"d":0,"h":51540066306,"f":1},"n":"ChangeTokens","d":458754,"h":47245099010,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424968194,"f":1},"n":"HasChanged","d":458754,"h":60130000898,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309870082,"f":1},"n":"ActiveChangeCallbacks","d":458754,"h":73014902786,"f":1}],"m":[{"r":57475073,"p":[{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"RegisterChangeCallback","d":458754,"h":55835033602,"f":1},{"r":65537,"n":"EnsureCallbacksInitialized","d":458754,"h":81604837378,"f":2},{"r":65537,"p":[{"n":"state","p":131073}],"n":"OnChange","d":458754,"h":85899804674,"f":34}],"l":[{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"_onChangeDelegate","d":458754,"h":4295426050,"f":34},{"t":131073,"n":"_callbackLock","d":458754,"h":8590393346,"f":2},{"t":126091265,"n":"_cancellationTokenSource","d":458754,"h":12885360642,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.IDisposable).$h,"n":"_disposables","d":458754,"h":17180327938,"f":2}],"c":[{"p":[{"n":"changeTokens","p":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken).$h}],"n":".ctor","o":"$ctor$1","d":458754,"h":38655164418,"f":1}],"i":[720898],"h":458754,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"HasChanged = {HasChanged}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.CompositeChangeToken`; }
        });
        
        $asm.$str("$mep.Microsoft.Extensions.Primitives.InplaceStringBuilder", ($self) => class InplaceStringBuilder extends $.$spc.System.ValueType
        {
            /*int*/  get _offset() { return this.$getField(0, 4); }
            /*int*/  set _offset(value) { this.$setField(0, 4, value); }
            /*int*/  get _capacity() { return this.$getField(4, 4); }
            /*int*/  set _capacity(value) { this.$setField(4, 4, value); }
            /*string?*/  get _value() { return this.$getField(8, 4); }
            /*string?*/  set _value(value) { this.$setField(8, 4, value); }
            $ctor$2(/*int*/ capacity)
            {
                this.$ctor$3();
                {
                    if (capacity < 0)
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(8/*ExceptionArgument.capacity*/);
                    }
                    this._capacity = capacity;
                }
                return this;
            }
            /*int */ get Capacity()
            {
                return this._capacity;
            }
            /*int */ set Capacity(value)
            {
                if (value < 0)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(7/*ExceptionArgument.value*/);
                }
                if (this._offset > 0)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowInvalidOperationException(2/*ExceptionResource.Capacity_CannotChangeAfterWriteStarted*/);
                }
                this._capacity = value;
            }
            /*void */ Append(/*string?*/ value)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.value*/);
                }
                this.Append$2(value, 0, value.length);
            }
            /*void */ Append$1(/*StringSegment*/ segment)
            {
                this.Append$2(segment.Buffer, segment.Offset, segment.Length);
            }
            /*void */ Append$2(/*string?*/ value, /*int*/ offset, /*int*/ count)
            {
                this.EnsureValueIsInitialized();
                if ($.$spc.System.String.op_Equality(value, null) || offset < 0 || ((value.length - offset) | 0) < count || ((this.Capacity - this._offset) | 0) < count)
                {
                    this.ThrowValidationError(value, offset, count);
                }
                /*fixed*/ 
                {
                    /*char**/ let destination = $.$spc.System.String.GetPinnableReference.call(this._value);
                    /*fixed*/ 
                    {
                        /*char**/ let source = $.$spc.System.String.GetPinnableReference.call(value);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.CopyBlockUnaligned(destination.Add(this._offset), source.Add(offset), (((count >>> 0) * 2) >>> 0));
                        this._offset += count;
                    }
                }
            }
            /*void */ Append$3(/*char*/ c)
            {
                this.EnsureValueIsInitialized();
                if (this._offset >= this.Capacity)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowInvalidOperationException$1(3/*ExceptionResource.Capacity_NotEnough*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(1, $.$spc.System.Int32), $.$box(((this.Capacity - this._offset) | 0), $.$spc.System.Int32) ], null, null));
                }
                /*fixed*/ 
                {
                    /*char**/ let destination = $.$spc.System.String.GetPinnableReference.call(this._value);
                    destination.SetAt(c, this._offset++);
                }
            }
            static/*conventional*/ /*string? */ ToString()
            {
                if (this.Capacity !== this._offset)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowInvalidOperationException$1(4/*ExceptionResource.Capacity_NotUsedEntirely*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(this.Capacity, $.$spc.System.Int32), $.$box(this._offset, $.$spc.System.Int32) ], null, null));
                }
                return this._value;
            }
            //Static convention instance redirect
            /*string? */ ToString() { return $.$mep.Microsoft.Extensions.Primitives.InplaceStringBuilder.ToString.apply(this, arguments); }
            /*void */ EnsureValueIsInitialized()
            {
                this._value ??= $.$spc.System.String.Create$6(/*\u0000*/ 0, this._capacity);
            }
            /*void */ ThrowValidationError(/*string?*/ value, /*int*/ offset, /*int*/ count)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.value*/);
                }
                if (offset < 0 || ((value.length - offset) | 0) < count)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.offset*/);
                }
                if (((this.Capacity - this._offset) | 0) < count)
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowInvalidOperationException$1(3/*ExceptionResource.Capacity_NotEnough*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(value.length, $.$spc.System.Int32), $.$box(((this.Capacity - this._offset) | 0), $.$spc.System.Int32) ], null, null));
                }
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._offset = this._offset;
                copy._capacity = this._capacity;
                copy._value = this._value;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._offset = 0;
                this._capacity = 0;
                this._value = null;
            }
            static $h = 786434;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25770590210,"f":1},"s":{"r":0,"d":0,"h":30065557506,"f":1},"n":"Capacity","d":786434,"h":21475622914,"f":1}],"m":[{"r":65537,"p":[{"n":"value","p":1310721}],"n":"Append","d":786434,"h":34360524802,"f":1},{"r":65537,"p":[{"n":"segment","p":851970}],"n":"Append","o":"@$1","d":786434,"h":38655492098,"f":1},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Append","o":"@$2","d":786434,"h":42950459394,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","o":"@$3","d":786434,"h":47245426690,"f":1},{"r":1310721,"n":"ToString","d":786434,"h":51540393986,"f":32769},{"r":65537,"n":"EnsureValueIsInitialized","d":786434,"h":55835361282,"f":2},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"ThrowValidationError","d":786434,"h":60130328578,"f":2}],"l":[{"t":655361,"n":"_offset","d":786434,"h":4295753730,"f":2},{"t":655361,"n":"_capacity","d":786434,"h":8590721026,"f":2},{"t":1310721,"n":"_value","d":786434,"h":12885688322,"f":2}],"c":[{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":786434,"h":17180655618,"f":1},{"n":".ctor","o":"$ctor$3","d":786434,"h":64425295874,"f":1}],"h":786434,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"Value = {_value}","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This type is retained only for compatibility. The recommended alternative is string.Create\u003CTState\u003E (int length, TState state, System.Buffers.SpanAction\u003Cchar,TState\u003E action).","t":1310721},{"v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.InplaceStringBuilder`; }
        });
        
        $asm.$str("$mep.Microsoft.Extensions.Primitives.ExceptionArgument", ($self) => class ExceptionArgument extends $.$spc.System.Enum
        {
            static buffer = 0;
            static offset = 1;
            static length = 2;
            static text = 3;
            static start = 4;
            static count = 5;
            static index = 6;
            static value = 7;
            static capacity = 8;
            static separators = 9;
            static comparisonType = 10;
            static changeTokens = 11;
            static changeTokenProducer = 12;
            static changeTokenConsumer = 13;
            static array = 14;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "buffer": 0n,
                    "offset": 1n,
                    "length": 2n,
                    "text": 3n,
                    "start": 4n,
                    "count": 5n,
                    "index": 6n,
                    "value": 7n,
                    "capacity": 8n,
                    "separators": 9n,
                    "comparisonType": 10n,
                    "changeTokens": 11n,
                    "changeTokenProducer": 12n,
                    "changeTokenConsumer": 13n,
                    "array": 14n
                };
            }
            static $h = 524290;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":524290,"n":"buffer","d":524290,"h":4295491586,"f":33},{"t":524290,"n":"offset","d":524290,"h":8590458882,"f":33},{"t":524290,"n":"length","d":524290,"h":12885426178,"f":33},{"t":524290,"n":"text","d":524290,"h":17180393474,"f":33},{"t":524290,"n":"start","d":524290,"h":21475360770,"f":33},{"t":524290,"n":"count","d":524290,"h":25770328066,"f":33},{"t":524290,"n":"index","d":524290,"h":30065295362,"f":33},{"t":524290,"n":"value","d":524290,"h":34360262658,"f":33},{"t":524290,"n":"capacity","d":524290,"h":38655229954,"f":33},{"t":524290,"n":"separators","d":524290,"h":42950197250,"f":33},{"t":524290,"n":"comparisonType","d":524290,"h":47245164546,"f":33},{"t":524290,"n":"changeTokens","d":524290,"h":51540131842,"f":33},{"t":524290,"n":"changeTokenProducer","d":524290,"h":55835099138,"f":33},{"t":524290,"n":"changeTokenConsumer","d":524290,"h":60130066434,"f":33},{"t":524290,"n":"array","d":524290,"h":64425033730,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":524290,"h":68720001026,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":524290}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.ExceptionArgument`; }
        });
        
        $asm.$str("$mep.Microsoft.Extensions.Primitives.ExceptionResource", ($self) => class ExceptionResource extends $.$spc.System.Enum
        {
            static Argument_InvalidOffsetLength = 0;
            static Argument_InvalidOffsetLengthStringSegment = 1;
            static Capacity_CannotChangeAfterWriteStarted = 2;
            static Capacity_NotEnough = 3;
            static Capacity_NotUsedEntirely = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Argument_InvalidOffsetLength": 0n,
                    "Argument_InvalidOffsetLengthStringSegment": 1n,
                    "Capacity_CannotChangeAfterWriteStarted": 2n,
                    "Capacity_NotEnough": 3n,
                    "Capacity_NotUsedEntirely": 4n
                };
            }
            static $h = 589826;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":589826,"n":"Argument_InvalidOffsetLength","d":589826,"h":4295557122,"f":33},{"t":589826,"n":"Argument_InvalidOffsetLengthStringSegment","d":589826,"h":8590524418,"f":33},{"t":589826,"n":"Capacity_CannotChangeAfterWriteStarted","d":589826,"h":12885491714,"f":33},{"t":589826,"n":"Capacity_NotEnough","d":589826,"h":17180459010,"f":33},{"t":589826,"n":"Capacity_NotUsedEntirely","d":589826,"h":21475426306,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":589826,"h":25770393602,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":589826}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.ExceptionResource`; }
        });
        
        $asm.$typeProxy("$mep.Microsoft.Extensions.Primitives.StringSegment");
        $asm.$cls("$mep.Microsoft.Extensions.Primitives.StringSegmentComparer", ($self) => class StringSegmentComparer extends $.$spc.System.Object
        {
            /*StringSegmentComparer*/ static Ordinal = null;
            /*StringSegmentComparer*/ static OrdinalIgnoreCase = null;
            $ctor$1(/*StringComparison*/ comparison, /*StringComparer*/ comparer)
            {
                super.$ctor();
                {
                    this.Comparison = comparison;
                    this.Comparer = comparer;
                }
                return this;
            }
            /*StringComparison*/ Comparison = 0;
            /*StringComparer*/ Comparer = null;
            /*int */ Compare(/*StringSegment*/ x, /*StringSegment*/ y)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Compare(x, y, this.Comparison);
            }
            /*bool */ Equals$2(/*StringSegment*/ x, /*StringSegment*/ y)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$4(x, y, this.Comparison);
            }
            /*int */ GetHashCode$1(/*StringSegment*/ obj)
            {
                return $.$spc.System.String.GetHashCode$3(obj.AsSpan(), this.Comparison);
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<Microsoft.Extensions.Primitives.StringSegment>.Compare(Microsoft.Extensions.Primitives.StringSegment, Microsoft.Extensions.Primitives.StringSegment)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<Microsoft.Extensions.Primitives.StringSegment>.Equals(Microsoft.Extensions.Primitives.StringSegment, Microsoft.Extensions.Primitives.StringSegment)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<Microsoft.Extensions.Primitives.StringSegment>.GetHashCode(Microsoft.Extensions.Primitives.StringSegment)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Comparison = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Ordinal = new $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer().$ctor$1(4/*StringComparison.Ordinal*/, $.$spc.System.StringComparer.Ordinal);
                }
                {
                    this.OrdinalIgnoreCase = new $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer().$ctor$1(5/*StringComparison.OrdinalIgnoreCase*/, $.$spc.System.StringComparer.OrdinalIgnoreCase);
                }
            }
            static $h = 917506;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917506,"g":{"r":0,"d":0,"h":12885819394,"f":33},"n":"Ordinal","d":917506,"h":8590852098,"f":33},{"p":917506,"g":{"r":0,"d":0,"h":25770721282,"f":33},"n":"OrdinalIgnoreCase","d":917506,"h":21475753986,"f":33},{"p":119472129,"g":{"r":0,"d":0,"h":42950590466,"f":2},"n":"Comparison","d":917506,"h":38655623170,"f":2},{"p":119406593,"g":{"r":0,"d":0,"h":55835492354,"f":2},"n":"Comparer","d":917506,"h":51540525058,"f":2}],"m":[{"r":655361,"p":[{"n":"x","p":851970},{"n":"y","p":851970}],"n":"Compare","d":917506,"h":60130459650,"f":1},{"r":262145,"p":[{"n":"x","p":851970},{"n":"y","p":851970}],"n":"Equals","o":"@$2","d":917506,"h":64425426946,"f":1},{"r":655361,"p":[{"n":"obj","p":851970}],"n":"GetHashCode","o":"@$1","d":917506,"h":68720394242,"f":1}],"c":[{"p":[{"n":"comparison","p":119472129},{"n":"comparer","p":119406593}],"n":".ctor","o":"$ctor$1","d":917506,"h":30065688578,"f":2}],"i":[$.$spc.System.Collections.Generic.IComparer$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,$.$spc.System.Collections.Generic.IEqualityComparer$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h],"h":917506}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IComparer$$($.$mep.Microsoft.Extensions.Primitives.StringSegment), $.$spc.System.Collections.Generic.IEqualityComparer$$($.$mep.Microsoft.Extensions.Primitives.StringSegment) ]; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.StringSegmentComparer`; }
        });
        
        $asm.$str("$mep.Microsoft.Extensions.Primitives.StringTokenizer", ($self) => class StringTokenizer extends $.$spc.System.ValueType
        {
            /*StringSegment*/  get _value() { return this.$getField(0, 12); }
            /*StringSegment*/  set _value(value) { this.$setField(0, 12, value); }
            /*char[]*/  get _separators() { return this.$getField(12, 4); }
            /*char[]*/  set _separators(value) { this.$setField(12, 4, value); }
            $ctor$2(/*string*/ value, /*char[]*/ separators)
            {
                super.$ctor$1();
                {
                    if ($.$spc.System.String.op_Equality(value, null))
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.value*/);
                    }
                    if (separators === null)
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.separators*/);
                    }
                    this._value = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit(value);
                    this._separators = separators;
                }
                return this;
            }
            $ctor$3(/*StringSegment*/ value, /*char[]*/ separators)
            {
                super.$ctor$1();
                {
                    if (!value.HasValue)
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.value*/);
                    }
                    if (separators === null)
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.separators*/);
                    }
                    this._value = value;
                    this._separators = separators;
                }
                return this;
            }
            /*Enumerator */ GetEnumerator()
            {
                return new $.$mep.Microsoft.Extensions.Primitives.StringTokenizer.Enumerator().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$mep.Microsoft.Extensions.Primitives.StringSegment, () => this._value, ($v) => this._value = $v, null), this._separators);
            }
            /*IEnumerator<StringSegment> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$mep.Microsoft.Extensions.Primitives.StringTokenizer;
                return $cls.$_Enumerator ??= $asm.$nstr("$mep.Microsoft.Extensions.Primitives.StringTokenizer.Enumerator", ($self) => class Enumerator extends $.$spc.System.ValueType
                {
                    /*StringSegment*/  get _value() { return this.$getField(0, 12); }
                    /*StringSegment*/  set _value(value) { this.$setField(0, 12, value); }
                    /*char[]*/  get _separators() { return this.$getField(12, 4); }
                    /*char[]*/  set _separators(value) { this.$setField(12, 4, value); }
                    /*int*/  get _index() { return this.$getField(16, 4); }
                    /*int*/  set _index(value) { this.$setField(16, 4, value); }
                    $ctor$2(/*in StringSegment*/ value, /*char[]*/ separators)
                    {
                        super.$ctor$1();
                        {
                            this._value = value.$v;
                            this._separators = separators;
                            this.Current = new $.$mep.Microsoft.Extensions.Primitives.StringSegment();
                            this._index = 0;
                        }
                        return this;
                    }
                    $ctor$3(/*ref StringTokenizer*/ tokenizer)
                    {
                        super.$ctor$1();
                        {
                            this._value = tokenizer.$v._value;
                            this._separators = tokenizer.$v._separators;
                            this.Current = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                            this._index = 0;
                        }
                        return this;
                    }
                    /*StringSegment*/ Current;
                    /*object */ get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    /*void */ Dispose()
                    {
                    }
                    /*bool */ MoveNext()
                    {
                        if (!this._value.HasValue || this._index > this._value.Length)
                        {
                            this.Current = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                            return false;
                        }
                        /*int*/ let next = this._value.IndexOfAny$1(this._separators, this._index);
                        if (next === -1)
                        {
                            next = this._value.Length;
                        }
                        this.Current = this._value.Subsegment$1(this._index, ((next - this._index) | 0));
                        this._index = ((next + 1) | 0);
                        return true;
                    }
                    /*void */ Reset()
                    {
                        this.Current = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                        this._index = 0;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<Microsoft.Extensions.Primitives.StringSegment>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._value = this._value.Clone();
                        copy._separators = this._separators;
                        copy._index = this._index;
                        copy.Current = this.Current.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                        this._separators = null;
                        this._index = 0;
                        this.Current = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                    }
                    static $h = 1048578;
                    static $z = 32;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":851970,"g":{"r":0,"d":0,"h":34360786946,"f":1},"s":{"r":0,"d":0,"h":38655754242,"f":2},"n":"Current","d":1048578,"h":30065819650,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":47245688834,"f":2},"n":"{31719425}.Current","o":"System$Collections$IEnumerator$Current","d":1048578,"h":42950721538,"f":2}],"m":[{"r":65537,"n":"Dispose","d":1048578,"h":51540656130,"f":1},{"r":262145,"n":"MoveNext","d":1048578,"h":55835623426,"f":1},{"r":65537,"n":"Reset","d":1048578,"h":60130590722,"f":1}],"l":[{"t":851970,"n":"_value","d":1048578,"h":4296015874,"f":2},{"t":0,"n":"_separators","d":1048578,"h":8590983170,"f":2},{"t":655361,"n":"_index","d":1048578,"h":12885950466,"f":2}],"c":[{"p":[{"n":"value","p":851970,"f":8},{"n":"separators","p":0}],"n":".ctor","o":"$ctor$2","d":1048578,"h":17180917762,"f":8},{"p":[{"n":"tokenizer","p":983042,"f":4}],"n":".ctor","o":"$ctor$3","d":1048578,"h":21475885058,"f":1},{"n":".ctor","o":"$ctor$4","d":1048578,"h":64425558018,"f":1}],"i":[$.$spc.System.Collections.Generic.IEnumerator$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,57475073,31719425],"d":983042,"h":1048578}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$($.$mep.Microsoft.Extensions.Primitives.StringSegment), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `Microsoft.Extensions.Primitives.StringTokenizer.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._value = this._value.Clone();
                copy._separators = this._separators;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this._separators = null;
            }
            static $h = 983042;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":1048578,"n":"GetEnumerator","d":983042,"h":21475819522,"f":1}],"l":[{"t":851970,"n":"_value","d":983042,"h":4295950338,"f":2},{"t":0,"n":"_separators","d":983042,"h":8590917634,"f":2}],"c":[{"p":[{"n":"value","p":1310721},{"n":"separators","p":0}],"n":".ctor","o":"$ctor$2","d":983042,"h":12885884930,"f":1},{"p":[{"n":"value","p":851970},{"n":"separators","p":0}],"n":".ctor","o":"$ctor$3","d":983042,"h":17180852226,"f":1},{"n":".ctor","o":"$ctor$4","d":983042,"h":38655688706,"f":1}],"i":[$.$spc.System.Collections.Generic.IEnumerable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,31588353],"j":[1048578],"h":983042}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.StringTokenizer`; }
        });
        
        $asm.$str("$mep.Microsoft.Extensions.Primitives.StringSegment", ($self) => class StringSegment extends $.$spc.System.ValueType
        {
            /*StringSegment*/ static Empty;
            $ctor$2(/*string?*/ buffer)
            {
                super.$ctor$1();
                {
                    this.Buffer = buffer;
                    this.Offset = 0;
                    const $t1 = buffer;
                    this.Length = $.$ifnn($t1, ($t) => $t.length) ?? 0;
                }
                return this;
            }
            $ctor$3(/*string*/ buffer, /*int*/ offset, /*int*/ length)
            {
                super.$ctor$1();
                {
                    if ($.$spc.System.String.op_Equality(buffer, null) || (offset >>> 0) > (buffer.length >>> 0) || (length >>> 0) > ((((buffer.length - offset) | 0)) >>> 0))
                    {
                        $.$mep.Microsoft.Extensions.Primitives.StringSegment.ThrowInvalidArguments(buffer, offset, length);
                    }
                    this.Buffer = buffer;
                    this.Offset = offset;
                    this.Length = length;
                }
                return this;
            }
            /*string?*/ Buffer = null;
            /*int*/ Offset = 0;
            /*int*/ Length = 0;
            /*string? */ get Value()
            {
                return this.HasValue ? $.$spc.System.String.Substring$1.call(this.Buffer, this.Offset, this.Length) : null;
            }
            /*bool */ get HasValue()
            {
                return $.$spc.System.String.op_Inequality(this.Buffer, null);
            }
            /*char*/ get_Item(/*int*/ index)
            {
                if ((index >>> 0) >= (this.Length >>> 0))
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.index*/);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this.Buffer === null), "Buffer is not null");
                return $.$spc.System.String.get_Chars.call(this.Buffer, ((this.Offset + index) | 0));
            }
            /*ReadOnlySpan<char> */ AsSpan()
            {
                return $.$spc.System.MemoryExtensions.AsSpan$7(this.Buffer, this.Offset, this.Length);
            }
            /*ReadOnlySpan<char> */ AsSpan$1(/*int*/ start)
            {
                if (!this.HasValue || start < 0)
                {
                    this.ThrowInvalidArguments$1(start, ((this.Length - start) | 0), 4/*ExceptionArgument.start*/);
                }
                return $.$spc.System.MemoryExtensions.AsSpan$7(this.Buffer, ((this.Offset + start) | 0), ((this.Length - start) | 0));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                if (!this.HasValue || start < 0 || length < 0 || ((((start + length) | 0)) >>> 0) > (this.Length >>> 0))
                {
                    this.ThrowInvalidArguments$1(start, length, 4/*ExceptionArgument.start*/);
                }
                return $.$spc.System.MemoryExtensions.AsSpan$7(this.Buffer, ((this.Offset + start) | 0), length);
            }
            /*ReadOnlyMemory<char> */ AsMemory()
            {
                return $.$spc.System.MemoryExtensions.AsMemory$3(this.Buffer, this.Offset, this.Length);
            }
            static /*int */ Compare(/*StringSegment*/ a, /*StringSegment*/ b, /*StringComparison*/ comparisonType)
            {
                if (a.HasValue && b.HasValue)
                {
                    return $.$spc.System.MemoryExtensions.CompareTo(a.AsSpan(), b.AsSpan(), comparisonType);
                }
                else 
                {
                    $.$mep.Microsoft.Extensions.Primitives.StringSegment.CheckStringComparison(comparisonType);
                    return !a.HasValue ? (b.HasValue ? -1 : 0) : 1;
                }
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let segment;
                return $.$is(obj, $.$mep.Microsoft.Extensions.Primitives.StringSegment, { set $v(v){ segment = v; } }) && this.Equals$2(segment);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*StringSegment*/ other)
            {
                return this.Equals$3(other, 4/*StringComparison.Ordinal*/);
            }
            /*bool */ Equals$3(/*StringSegment*/ other, /*StringComparison*/ comparisonType)
            {
                if (this.HasValue && other.HasValue)
                {
                    return $.$spc.System.MemoryExtensions.Equals$2(this.AsSpan(), other.AsSpan(), comparisonType);
                }
                else 
                {
                    $.$mep.Microsoft.Extensions.Primitives.StringSegment.CheckStringComparison(comparisonType);
                    return !this.HasValue && !other.HasValue;
                }
            }
            static /*bool */ Equals$4(/*StringSegment*/ a, /*StringSegment*/ b, /*StringComparison*/ comparisonType)
            {
                return a.Equals$3(b, comparisonType);
            }
            /*bool */ Equals$5(/*string?*/ text)
            {
                return this.Equals$6(text, 4/*StringComparison.Ordinal*/);
            }
            /*bool */ Equals$6(/*string?*/ text, /*StringComparison*/ comparisonType)
            {
                if (!this.HasValue || $.$spc.System.String.op_Equality(text, null))
                {
                    $.$mep.Microsoft.Extensions.Primitives.StringSegment.CheckStringComparison(comparisonType);
                    return $.$spc.System.String.op_Equality(text, this.Buffer);
                }
                return $.$spc.System.MemoryExtensions.Equals$2(this.AsSpan(), $.$spc.System.MemoryExtensions.AsSpan$3(text), comparisonType);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.String.GetHashCode$2(this.AsSpan());
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*StringSegment*/ left, /*StringSegment*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*StringSegment*/ left, /*StringSegment*/ right)
            {
                return !left.Equals$2(right);
            }
            static /*StringSegment */ op_Implicit(/*string?*/ value)
            {
                return new $.$mep.Microsoft.Extensions.Primitives.StringSegment().$ctor$2(value);
            }
            static /*ReadOnlySpan<char> */ op_Implicit$1(/*StringSegment*/ segment)
            {
                return segment.AsSpan();
            }
            static /*ReadOnlyMemory<char> */ op_Implicit$2(/*StringSegment*/ segment)
            {
                return segment.AsMemory();
            }
            /*bool */ StartsWith(/*string*/ text, /*StringComparison*/ comparisonType)
            {
                if ($.$spc.System.String.op_Equality(text, null))
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.text*/);
                }
                if (!this.HasValue)
                {
                    $.$mep.Microsoft.Extensions.Primitives.StringSegment.CheckStringComparison(comparisonType);
                    return false;
                }
                return $.$spc.System.MemoryExtensions.StartsWith$5(this.AsSpan(), $.$spc.System.MemoryExtensions.AsSpan$3(text), comparisonType);
            }
            /*bool */ EndsWith(/*string*/ text, /*StringComparison*/ comparisonType)
            {
                if ($.$spc.System.String.op_Equality(text, null))
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.text*/);
                }
                if (!this.HasValue)
                {
                    $.$mep.Microsoft.Extensions.Primitives.StringSegment.CheckStringComparison(comparisonType);
                    return false;
                }
                return $.$spc.System.MemoryExtensions.EndsWith$5(this.AsSpan(), $.$spc.System.MemoryExtensions.AsSpan$3(text), comparisonType);
            }
            /*string */ Substring(/*int*/ offset)
            {
                return this.Substring$1(offset, ((this.Length - offset) | 0));
            }
            /*string */ Substring$1(/*int*/ offset, /*int*/ length)
            {
                if (!this.HasValue || offset < 0 || length < 0 || ((((offset + length) | 0)) >>> 0) > (this.Length >>> 0))
                {
                    this.ThrowInvalidArguments$1(offset, length, 1/*ExceptionArgument.offset*/);
                }
                return $.$spc.System.String.Substring$1.call(this.Buffer, ((this.Offset + offset) | 0), length);
            }
            /*StringSegment */ Subsegment(/*int*/ offset)
            {
                return this.Subsegment$1(offset, ((this.Length - offset) | 0));
            }
            /*StringSegment */ Subsegment$1(/*int*/ offset, /*int*/ length)
            {
                if (!this.HasValue || offset < 0 || length < 0 || ((((offset + length) | 0)) >>> 0) > (this.Length >>> 0))
                {
                    this.ThrowInvalidArguments$1(offset, length, 1/*ExceptionArgument.offset*/);
                }
                return new $.$mep.Microsoft.Extensions.Primitives.StringSegment().$ctor$3(this.Buffer, ((this.Offset + offset) | 0), length);
            }
            /*int */ IndexOf(/*char*/ c, /*int*/ start, /*int*/ count)
            {
                /*int*/ let index = -1;
                if (this.HasValue)
                {
                    if ((start >>> 0) > (this.Length >>> 0))
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.start*/);
                    }
                    if ((count >>> 0) > ((((this.Length - start) | 0)) >>> 0))
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.count*/);
                    }
                    index = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, this.AsSpan$2(start, count), c);
                    if (index >= 0)
                    {
                        index += start;
                    }
                }
                return index;
            }
            /*int */ IndexOf$1(/*char*/ c, /*int*/ start)
            {
                return this.IndexOf(c, start, ((this.Length - start) | 0));
            }
            /*int */ IndexOf$2(/*char*/ c)
            {
                return this.IndexOf(c, 0, this.Length);
            }
            /*int */ IndexOfAny(/*char[]*/ anyOf, /*int*/ startIndex, /*int*/ count)
            {
                /*int*/ let index = -1;
                if (this.HasValue)
                {
                    if ((startIndex >>> 0) > (this.Length >>> 0))
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.start*/);
                    }
                    if ((count >>> 0) > ((((this.Length - startIndex) | 0)) >>> 0))
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.count*/);
                    }
                    index = $.$spc.System.String.IndexOfAny$2.call(this.Buffer, anyOf, ((this.Offset + startIndex) | 0), count);
                    if (index !== -1)
                    {
                        index -= this.Offset;
                    }
                }
                return index;
            }
            /*int */ IndexOfAny$1(/*char[]*/ anyOf, /*int*/ startIndex)
            {
                return this.IndexOfAny(anyOf, startIndex, ((this.Length - startIndex) | 0));
            }
            /*int */ IndexOfAny$2(/*char[]*/ anyOf)
            {
                return this.IndexOfAny(anyOf, 0, this.Length);
            }
            /*int */ LastIndexOf(/*char*/ value)
            {
                return $.$spc.System.MemoryExtensions.LastIndexOf$2($.$spc.System.Char, this.AsSpan(), value);
            }
            /*StringSegment */ Trim()
            {
                return this.TrimStart().TrimEnd();
            }
            /*StringSegment */ TrimStart()
            {
                /*ReadOnlySpan<char>*/ let span = this.AsSpan();
                /*int*/ let i;
                for(i = 0; i < span.Length; i++)
                {
                    if (!$.$spc.System.Char.IsWhiteSpace(span.get_Item(i).$v))
                    {
                        break;
                    }
                }
                return this.Subsegment(i);
            }
            /*StringSegment */ TrimEnd()
            {
                /*ReadOnlySpan<char>*/ let span = this.AsSpan();
                /*int*/ let i;
                for(i = ((span.Length - 1) | 0); i >= 0; i--)
                {
                    if (!$.$spc.System.Char.IsWhiteSpace(span.get_Item(i).$v))
                    {
                        break;
                    }
                }
                return this.Subsegment$1(0, ((i + 1) | 0));
            }
            /*StringTokenizer */ Split(/*char[]*/ chars)
            {
                return new $.$mep.Microsoft.Extensions.Primitives.StringTokenizer().$ctor$3(this, chars);
            }
            static /*bool */ IsNullOrEmpty(/*StringSegment*/ value)
            {
                /*bool*/ let res = false;
                if (!value.HasValue || value.Length === 0)
                {
                    res = true;
                }
                return res;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Value ?? $.$spc.System.String.Empty;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.apply(this, arguments); }
            static /*void */ CheckStringComparison(/*StringComparison*/ comparisonType)
            {
                if ((comparisonType >>> 0) > (5/*StringComparison.OrdinalIgnoreCase*/ >>> 0))
                {
                    $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentOutOfRangeException(10/*ExceptionArgument.comparisonType*/);
                }
            }
            static /*void */ ThrowInvalidArguments(/*string?*/ buffer, /*int*/ offset, /*int*/ length)
            {
                throw GetInvalidArgumentsException.call(this);
                /*Exception*/  function GetInvalidArgumentsException()
                {
                    if ($.$spc.System.String.op_Equality(buffer, null))
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentNullException(0/*ExceptionArgument.buffer*/);
                    }
                    if (offset < 0)
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentOutOfRangeException(1/*ExceptionArgument.offset*/);
                    }
                    if (length < 0)
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentOutOfRangeException(2/*ExceptionArgument.length*/);
                    }
                    return $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentException(0/*ExceptionResource.Argument_InvalidOffsetLength*/);
                }
            }
            /*void */ ThrowInvalidArguments$1(/*int*/ offset, /*int*/ length, /*ExceptionArgument*/ offsetOrStart)
            {
                throw GetInvalidArgumentsException.call(this, this.HasValue);
                /*Exception*/  function GetInvalidArgumentsException(/*bool*/ hasValue)
                {
                    if (!hasValue)
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentOutOfRangeException(offsetOrStart);
                    }
                    if (offset < 0)
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentOutOfRangeException(offsetOrStart);
                    }
                    if (length < 0)
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentOutOfRangeException(2/*ExceptionArgument.length*/);
                    }
                    return $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.GetArgumentException(1/*ExceptionResource.Argument_InvalidOffsetLengthStringSegment*/);
                }
            }
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.Primitives.StringSegment>.Equals(Microsoft.Extensions.Primitives.StringSegment)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.IEquatable<string?>.Equals(string?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$5(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Buffer = this.Buffer;
                copy.Offset = this.Offset;
                copy.Length = this.Length;
                return copy;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit($.$spc.System.String.Empty);
                }
            }
            static $h = 851970;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770655746,"f":1},"n":"Buffer","d":851970,"h":21475688450,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655557634,"f":1},"n":"Offset","d":851970,"h":34360590338,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540459522,"f":1},"n":"Length","d":851970,"h":47245492226,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60130394114,"f":1},"n":"Value","d":851970,"h":55835426818,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68720328706,"f":1},"n":"HasValue","d":851970,"h":64425361410,"f":1},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":77310263298,"f":1},"n":"Item","o":"@$2","d":851970,"h":73015296002,"f":1}],"m":[{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"n":"AsSpan","d":851970,"h":81605230594,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$1","d":851970,"h":85900197890,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$2","d":851970,"h":90195165186,"f":1},{"r":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Char).$h,"n":"AsMemory","d":851970,"h":94490132482,"f":1},{"r":655361,"p":[{"n":"a","p":851970},{"n":"b","p":851970},{"n":"comparisonType","p":119472129}],"n":"Compare","d":851970,"h":98785099778,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":851970,"h":103080067074,"f":32769},{"r":262145,"p":[{"n":"other","p":851970}],"n":"Equals","o":"@$2","d":851970,"h":107375034370,"f":1},{"r":262145,"p":[{"n":"other","p":851970},{"n":"comparisonType","p":119472129}],"n":"Equals","o":"@$3","d":851970,"h":111670001666,"f":1},{"r":262145,"p":[{"n":"a","p":851970},{"n":"b","p":851970},{"n":"comparisonType","p":119472129}],"n":"Equals","o":"@$4","d":851970,"h":115964968962,"f":33},{"r":262145,"p":[{"n":"text","p":1310721}],"n":"Equals","o":"@$5","d":851970,"h":120259936258,"f":1},{"r":262145,"p":[{"n":"text","p":1310721},{"n":"comparisonType","p":119472129}],"n":"Equals","o":"@$6","d":851970,"h":124554903554,"f":1},{"r":655361,"n":"GetHashCode","d":851970,"h":128849870850,"f":32769},{"r":262145,"p":[{"n":"text","p":1310721},{"n":"comparisonType","p":119472129}],"n":"StartsWith","d":851970,"h":154619674626,"f":1},{"r":262145,"p":[{"n":"text","p":1310721},{"n":"comparisonType","p":119472129}],"n":"EndsWith","d":851970,"h":158914641922,"f":1},{"r":1310721,"p":[{"n":"offset","p":655361}],"n":"Substring","d":851970,"h":163209609218,"f":1},{"r":1310721,"p":[{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"Substring","o":"@$1","d":851970,"h":167504576514,"f":1},{"r":851970,"p":[{"n":"offset","p":655361}],"n":"Subsegment","d":851970,"h":171799543810,"f":1},{"r":851970,"p":[{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"Subsegment","o":"@$1","d":851970,"h":176094511106,"f":1},{"r":655361,"p":[{"n":"c","p":458753},{"n":"start","p":655361},{"n":"count","p":655361}],"n":"IndexOf","d":851970,"h":180389478402,"f":1},{"r":655361,"p":[{"n":"c","p":458753},{"n":"start","p":655361}],"n":"IndexOf","o":"@$1","d":851970,"h":184684445698,"f":1},{"r":655361,"p":[{"n":"c","p":458753}],"n":"IndexOf","o":"@$2","d":851970,"h":188979412994,"f":1},{"r":655361,"p":[{"n":"anyOf","p":0},{"n":"startIndex","p":655361},{"n":"count","p":655361}],"n":"IndexOfAny","d":851970,"h":193274380290,"f":1},{"r":655361,"p":[{"n":"anyOf","p":0},{"n":"startIndex","p":655361}],"n":"IndexOfAny","o":"@$1","d":851970,"h":197569347586,"f":1},{"r":655361,"p":[{"n":"anyOf","p":0}],"n":"IndexOfAny","o":"@$2","d":851970,"h":201864314882,"f":1},{"r":655361,"p":[{"n":"value","p":458753}],"n":"LastIndexOf","d":851970,"h":206159282178,"f":1},{"r":851970,"n":"Trim","d":851970,"h":210454249474,"f":1},{"r":851970,"n":"TrimStart","d":851970,"h":214749216770,"f":1},{"r":851970,"n":"TrimEnd","d":851970,"h":219044184066,"f":1},{"r":983042,"p":[{"n":"chars","p":0}],"n":"Split","d":851970,"h":223339151362,"f":1},{"r":262145,"p":[{"n":"value","p":851970}],"n":"IsNullOrEmpty","d":851970,"h":227634118658,"f":33},{"r":1310721,"n":"ToString","d":851970,"h":231929085954,"f":32769},{"r":65537,"p":[{"n":"comparisonType","p":119472129}],"n":"CheckStringComparison","d":851970,"h":236224053250,"f":34},{"r":65537,"p":[{"n":"buffer","p":1310721},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"ThrowInvalidArguments","d":851970,"h":240519020546,"f":34},{"r":65537,"p":[{"n":"offset","p":655361},{"n":"length","p":655361},{"n":"offsetOrStart","p":524290}],"n":"ThrowInvalidArguments","o":"@$1","d":851970,"h":244813987842,"f":2}],"l":[{"t":851970,"n":"Empty","d":851970,"h":4295819266,"f":33}],"c":[{"p":[{"n":"buffer","p":1310721}],"n":".ctor","o":"$ctor$2","d":851970,"h":8590786562,"f":1},{"p":[{"n":"buffer","p":1310721},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":".ctor","o":"$ctor$3","d":851970,"h":12885753858,"f":1},{"n":".ctor","o":"$ctor$4","d":851970,"h":249108955138,"f":1}],"i":[$.$spc.System.IEquatable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,$.$spc.System.IEquatable$$($.$spc.System.String).$h],"h":851970,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{Value}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment), $.$spc.System.IEquatable$$($.$spc.System.String) ]; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.StringSegment`; }
        });
        
        $asm.$str("$mep.Microsoft.Extensions.Primitives.StringValues", ($self) => class StringValues extends $.$spc.System.ValueType
        {
            /*StringValues*/ static Empty;
            /*object?*/  get _values() { return this.$getField(0, 4); }
            /*object?*/  set _values(value) { this.$setField(0, 4, value); }
            $ctor$2(/*string?*/ value)
            {
                super.$ctor$1();
                {
                    this._values = value;
                }
                return this;
            }
            $ctor$3(/*string?[]?*/ values)
            {
                super.$ctor$1();
                {
                    this._values = values;
                }
                return this;
            }
            static /*StringValues */ op_Implicit(/*string?*/ value)
            {
                return new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(value);
            }
            static /*StringValues */ op_Implicit$1(/*string?[]?*/ values)
            {
                return new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(values);
            }
            static /*string? */ op_Implicit$2(/*StringValues*/ values)
            {
                return values.GetStringValue();
            }
            static /*string?[]? */ op_Implicit$3(/*StringValues*/ value)
            {
                return value.GetArrayValue();
            }
            /*int */ get Count()
            {
                /*object?*/ let value = this._values;
                if (value === null)
                {
                    return 0;
                }
                if ($.$is(value, $.$spc.System.String))
                {
                    return 1;
                }
                else 
                {
                    return value.length;
                }
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return true;
            }
            /*string?*/ System$Collections$Generic$IList$$$get_Item(/*int*/ index)
            {
                return this.get_Item(index);
            }
            /*void*/ System$Collections$Generic$IList$$$set_Item(/*int*/ index, /*string?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*string?*/ get_Item(/*int*/ index)
            {
                /*object?*/ let value = this._values;
                let str;
                if ($.$is(value, $.$spc.System.String, { set $v(v){ str = v; } }))
                {
                    if (index === 0)
                    {
                        return str;
                    }
                }
                else if (value !== null)
                {
                    return $.$spc.System.Array.$ReadT1.call(value, index);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.OutOfBounds();
            }
            static /*string */ OutOfBounds()
            {
                return $.$spc.System.Array.$ReadT1.call($.$spc.System.Array.Empty($.$spc.System.String), 0);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.GetStringValue() ?? $.$spc.System.String.Empty;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mep.Microsoft.Extensions.Primitives.StringValues.ToString.apply(this, arguments); }
            /*string? */ GetStringValue()
            {
                /*object?*/ let value = this._values;
                let s;
                if ($.$is(value, $.$spc.System.String, { set $v(v){ s = v; } }))
                {
                    return s;
                }
                else 
                {
                    return GetStringValueFromArray(value);
                }
                /*static string?*/  function GetStringValueFromArray(/*object?*/ value)
                {
                    if (value === null)
                    {
                        return null;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(value, $.$typeArray($.$spc.System.String)), "value is string[]");
                    /*string?[]*/ let values = value;
                    return (() =>
                    {
                        let $switch1 = values.length;
                        if ($switch1 === 0)
                        {
                            return null;
                        }
                        if ($switch1 === 1)
                        {
                            return $.$spc.System.Array.$ReadT1.call(values, 0);
                        }
                        return GetJoinedStringValueFromArray(values);
                    })();
                }
                /*static string*/  function GetJoinedStringValueFromArray(/*string?[]*/ values)
                {
                    /*int*/ let length = 0;
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        /*string?*/ let value = $.$spc.System.Array.$ReadT1.call(values, i);
                        if ($.$spc.System.String.op_Inequality(value, null) && value.length > 0)
                        {
                            if (length > 0)
                            {
                                length++;
                            }
                            length += value.length;
                        }
                    }
                    return $.$spc.System.String.Create$8($.$typeArray($.$spc.System.String), length, values, new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$typeArray($.$spc.System.String)))().$ctor(this,  (/*span*/ span, /*strings*/ strings) =>
                    {
                        /*int*/ let offset = 0;
                        for(/*int*/ let i = 0; i < strings.length; i++)
                        {
                            /*string?*/ let value = $.$spc.System.Array.$ReadT1.call(strings, i);
                            if ($.$spc.System.String.op_Inequality(value, null) && value.length > 0)
                            {
                                if (offset > 0)
                                {
                                    span.get_Item(offset).$v = /*,*/ 44;
                                    offset++;
                                }
                                $.$spc.System.MemoryExtensions.AsSpan$3(value).CopyTo(span.Slice(offset));
                                offset += value.length;
                            }
                        }
                    }));
                }
            }
            /*string?[] */ ToArray()
            {
                return this.GetArrayValue() ?? $.$spc.System.Array.Empty($.$spc.System.String);
            }
            /*string?[]? */ GetArrayValue()
            {
                /*object?*/ let value = this._values;
                let values;
                if ($.$is(value, $.$typeArray($.$spc.System.String), { set $v(v){ values = v; } }))
                {
                    return values;
                }
                else if (value !== null)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [value], null, null);
                }
                else 
                {
                    return null;
                }
            }
            /*int */ System$Collections$Generic$IList$$$IndexOf(/*string?*/ item)
            {
                return this.IndexOf(item);
            }
            /*int */ IndexOf(/*string?*/ item)
            {
                /*object?*/ let value = this._values;
                let values;
                if ($.$is(value, $.$typeArray($.$spc.System.String), { set $v(v){ values = v; } }))
                {
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        if ($.$spc.System.String.Equals$5($.$spc.System.Array.$ReadT1.call(values, i), item, 4/*StringComparison.Ordinal*/))
                        {
                            return i;
                        }
                    }
                    return -1;
                }
                if (value !== null)
                {
                    return $.$spc.System.String.Equals$5(value, item, 4/*StringComparison.Ordinal*/) ? 0 : -1;
                }
                return -1;
            }
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*string?*/ item)
            {
                return this.IndexOf(item) >= 0;
            }
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*string?[]*/ array, /*int*/ arrayIndex)
            {
                this.CopyTo(array, arrayIndex);
            }
            /*void */ CopyTo(/*string?[]*/ array, /*int*/ arrayIndex)
            {
                /*object?*/ let value = this._values;
                let values;
                if ($.$is(value, $.$typeArray($.$spc.System.String), { set $v(v){ values = v; } }))
                {
                    $.$spc.System.Array.Copy$1(values, 0, array, arrayIndex, values.length);
                    return;
                }
                if (value !== null)
                {
                    if (array === null)
                    {
                        $.$mep.Microsoft.Extensions.Primitives.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.array*/);
                    }
                    if (arrayIndex < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("arrayIndex");
                    }
                    if (((array.length - arrayIndex) | 0) < 1)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10(`'${"array"}' is not long enough to copy all the items in the collection. Check '${"arrayIndex"}' and '${"array"}' length.`);
                    }
                    $.$spc.System.Array.$WriteT1.call(array, value, arrayIndex);
                }
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*string?*/ item)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*string?*/ item)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*string?*/ item)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ System$Collections$Generic$ICollection$$$Clear()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*Enumerator */ GetEnumerator()
            {
                return new $.$mep.Microsoft.Extensions.Primitives.StringValues.Enumerator().$ctor$2(this._values);
            }
            /*IEnumerator<string?> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            static /*bool */ IsNullOrEmpty(/*StringValues*/ value)
            {
                /*object?*/ let data = value._values;
                if (data === null)
                {
                    return true;
                }
                let values;
                if ($.$is(data, $.$typeArray($.$spc.System.String), { set $v(v){ values = v; } }))
                {
                    return (() =>
                    {
                        let $switch1 = values.length;
                        if ($switch1 === 0)
                        {
                            return true;
                        }
                        if ($switch1 === 1)
                        {
                            return $.$spc.System.String.IsNullOrEmpty($.$spc.System.Array.$ReadT1.call(values, 0));
                        }
                        return false;
                    })();
                }
                else 
                {
                    return $.$spc.System.String.IsNullOrEmpty(data);
                }
            }
            static /*StringValues */ Concat(/*StringValues*/ values1, /*StringValues*/ values2)
            {
                /*int*/ let count1 = values1.Count;
                /*int*/ let count2 = values2.Count;
                if (count1 === 0)
                {
                    return values2;
                }
                if (count2 === 0)
                {
                    return values1;
                }
                /*var*/ let combined = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), null, [((count1 + count2) | 0)], null);
                values1.CopyTo(combined, 0);
                values2.CopyTo(combined, count1);
                return new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(combined);
            }
            static /*StringValues */ Concat$1(/*in StringValues*/ values, /*string?*/ value)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    return values.$v;
                }
                /*int*/ let count = values.$v.Count;
                if (count === 0)
                {
                    return new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(value);
                }
                /*var*/ let combined = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), null, [((count + 1) | 0)], null);
                values.$v.CopyTo(combined, 0);
                $.$spc.System.Array.$WriteT1.call(combined, value, count);
                return new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(combined);
            }
            static /*StringValues */ Concat$2(/*string?*/ value, /*in StringValues*/ values)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    return values.$v;
                }
                /*int*/ let count = values.$v.Count;
                if (count === 0)
                {
                    return new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(value);
                }
                /*var*/ let combined = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), null, [((count + 1) | 0)], null);
                $.$spc.System.Array.$WriteT1.call(combined, value, 0);
                values.$v.CopyTo(combined, 1);
                return new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(combined);
            }
            static /*bool */ Equals$2(/*StringValues*/ left, /*StringValues*/ right)
            {
                /*int*/ let count = left.Count;
                if (count !== right.Count)
                {
                    return false;
                }
                for(/*int*/ let i = 0; i < count; i++)
                {
                    if ($.$spc.System.String.op_Inequality(left.get_Item(i), right.get_Item(i)))
                    {
                        return false;
                    }
                }
                return true;
            }
            static /*bool */ op_Equality(/*StringValues*/ left, /*StringValues*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(left, right);
            }
            static /*bool */ op_Inequality(/*StringValues*/ left, /*StringValues*/ right)
            {
                return !$.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(left, right);
            }
            /*bool */ Equals$3(/*StringValues*/ other)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(this, other);
            }
            static /*bool */ Equals$4(/*string?*/ left, /*StringValues*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(left), right);
            }
            static /*bool */ Equals$5(/*StringValues*/ left, /*string?*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(left, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(right));
            }
            /*bool */ Equals$6(/*string?*/ other)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(this, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(other));
            }
            static /*bool */ Equals$7(/*string?[]?*/ left, /*StringValues*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(left), right);
            }
            static /*bool */ Equals$8(/*StringValues*/ left, /*string?[]?*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(left, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(right));
            }
            /*bool */ Equals$9(/*string?[]?*/ other)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(this, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(other));
            }
            static /*bool */ op_Equality$1(/*StringValues*/ left, /*string?*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(left, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(right));
            }
            static /*bool */ op_Inequality$1(/*StringValues*/ left, /*string?*/ right)
            {
                return !$.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(left, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(right));
            }
            static /*bool */ op_Equality$2(/*string?*/ left, /*StringValues*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(left), right);
            }
            static /*bool */ op_Inequality$2(/*string?*/ left, /*StringValues*/ right)
            {
                return !$.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$2(left), right);
            }
            static /*bool */ op_Equality$3(/*StringValues*/ left, /*string?[]?*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(left, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(right));
            }
            static /*bool */ op_Inequality$3(/*StringValues*/ left, /*string?[]?*/ right)
            {
                return !$.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(left, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(right));
            }
            static /*bool */ op_Equality$4(/*string?[]?*/ left, /*StringValues*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(left), right);
            }
            static /*bool */ op_Inequality$4(/*string?[]?*/ left, /*StringValues*/ right)
            {
                return !$.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(left), right);
            }
            static /*bool */ op_Equality$5(/*StringValues*/ left, /*object?*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals.call(left, right);
            }
            static /*bool */ op_Inequality$5(/*StringValues*/ left, /*object?*/ right)
            {
                return !$.$mep.Microsoft.Extensions.Primitives.StringValues.Equals.call(left, right);
            }
            static /*bool */ op_Equality$6(/*object?*/ left, /*StringValues*/ right)
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals.call(right, left);
            }
            static /*bool */ op_Inequality$6(/*object?*/ left, /*StringValues*/ right)
            {
                return !$.$mep.Microsoft.Extensions.Primitives.StringValues.Equals.call(right, left);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                if (obj === null)
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(this, $.$mep.Microsoft.Extensions.Primitives.StringValues.Empty);
                }
                let str;
                if ($.$is(obj, $.$spc.System.String, { set $v(v){ str = v; } }))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$5(this, str);
                }
                let array;
                if ($.$is(obj, $.$typeArray($.$spc.System.String), { set $v(v){ array = v; } }))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$8(this, array);
                }
                let stringValues;
                if ($.$is(obj, $.$mep.Microsoft.Extensions.Primitives.StringValues, { set $v(v){ stringValues = v; } }))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals$2(this, stringValues);
                }
                return false;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$mep.Microsoft.Extensions.Primitives.StringValues.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*object?*/ let value = this._values;
                let values;
                if ($.$is(value, $.$typeArray($.$spc.System.String), { set $v(v){ values = v; } }))
                {
                    if (this.Count === 1)
                    {
                        const $t1 = () => this.get_Item(0);
                        return $.$ifnn($t1, ($t) => $.$spc.System.String.GetHashCode.call($t)) ?? $.$spc.System.Int32.GetHashCode.call(this.Count);
                    }
                    /*int*/ let hashCode = 0;
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        const $t1 = () => $.$spc.System.Array.$ReadT1.call(values, i);
                        hashCode = $.$mep.System.Numerics.Hashing.HashHelpers.Combine(hashCode, $.$ifnn($t1, ($t) => $.$spc.System.String.GetHashCode.call($t)) ?? 0);
                    }
                    return hashCode;
                }
                else 
                {
                    const $t1 = () => value;
                    return $.$ifnn($t1, ($t) => $.$spc.System.String.GetHashCode.call($t)) ?? $.$spc.System.Int32.GetHashCode.call(this.Count);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mep.Microsoft.Extensions.Primitives.StringValues.GetHashCode.apply(this, arguments); }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$mep.Microsoft.Extensions.Primitives.StringValues;
                return $cls.$_Enumerator ??= $asm.$nstr("$mep.Microsoft.Extensions.Primitives.StringValues.Enumerator", ($self) => class Enumerator extends $.$spc.System.ValueType
                {
                    /*string?[]?*/  get _values() { return this.$getField(0, 4); }
                    /*string?[]?*/  set _values(value) { this.$setField(0, 4, value); }
                    /*int*/  get _index() { return this.$getField(4, 4); }
                    /*int*/  set _index(value) { this.$setField(4, 4, value); }
                    /*string?*/  get _current() { return this.$getField(8, 4); }
                    /*string?*/  set _current(value) { this.$setField(8, 4, value); }
                    $ctor$2(/*object?*/ value)
                    {
                        super.$ctor$1();
                        {
                            let str;
                            if ($.$is(value, $.$spc.System.String, { set $v(v){ str = v; } }))
                            {
                                this._values = null;
                                this._current = str;
                            }
                            else 
                            {
                                this._current = null;
                                this._values = value;
                            }
                            this._index = 0;
                        }
                        return this;
                    }
                    $ctor$3(/*ref StringValues*/ values)
                    {
                        this.$ctor$2(values.$v._values);
                        {
                        }
                        return this;
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let index = this._index;
                        if (index < 0)
                        {
                            return false;
                        }
                        /*string?[]?*/ let values = this._values;
                        if (values !== null)
                        {
                            if ((index >>> 0) < (values.length >>> 0))
                            {
                                this._index = ((index + 1) | 0);
                                this._current = $.$spc.System.Array.$ReadT1.call(values, index);
                                return true;
                            }
                            this._index = -1;
                            return false;
                        }
                        this._index = -1;
                        return $.$spc.System.String.op_Inequality(this._current, null);
                    }
                    /*string? */ get Current()
                    {
                        return this._current;
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        return this._current;
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ Dispose()
                    {
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<string?>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._values = this._values;
                        copy._index = this._index;
                        copy._current = this._current;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._values = null;
                        this._index = 0;
                        this._current = null;
                    }
                    static $h = 1179650;
                    static $z = 12;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":34360918018,"f":1},"n":"Current","d":1179650,"h":30065950722,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":42950852610,"f":2},"n":"{31719425}.Current","o":"System$Collections$IEnumerator$Current","d":1179650,"h":38655885314,"f":2}],"m":[{"r":262145,"n":"MoveNext","d":1179650,"h":25770983426,"f":1},{"r":65537,"n":"Dispose","d":1179650,"h":51540787202,"f":1}],"l":[{"t":0,"n":"_values","d":1179650,"h":4296146946,"f":2},{"t":655361,"n":"_index","d":1179650,"h":8591114242,"f":2},{"t":1310721,"n":"_current","d":1179650,"h":12886081538,"f":2}],"c":[{"p":[{"n":"value","p":131073}],"n":".ctor","o":"$ctor$2","d":1179650,"h":17181048834,"f":8},{"p":[{"n":"values","p":1114114,"f":4}],"n":".ctor","o":"$ctor$3","d":1179650,"h":21476016130,"f":1},{"n":".ctor","o":"$ctor$4","d":1179650,"h":55835754498,"f":1}],"i":[$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.String).$h,57475073,31719425],"d":1114114,"h":1179650}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.String), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `Microsoft.Extensions.Primitives.StringValues.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<string?>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<string?>.this[int].get
            System$Collections$Generic$IReadOnlyList$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<string?>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.Primitives.StringValues>.Equals(Microsoft.Extensions.Primitives.StringValues)
            System$IEquatable$$$Equals()
            {
                return this.Equals$3(...arguments);
            }
            //Generated interface implemetation for System.IEquatable<string?>.Equals(string?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$6(...arguments);
            }
            //Generated interface implemetation for System.IEquatable<string?[]?>.Equals(string?[]?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$9(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._values = this._values;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._values = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3($.$spc.System.Array.Empty($.$spc.System.String));
                }
            }
            static $h = 1114114;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42950787074,"f":1},"n":"Count","d":1114114,"h":38655819778,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540721666,"f":2},"n":"{$.$spc.System.Collections.Generic.ICollection$$($.$spc.System.String).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":1114114,"h":47245754370,"f":2},{"p":1310721,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":60130656258,"f":2},"s":{"r":0,"d":0,"h":64425623554,"f":2},"n":"{$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h}.this[]","o":"System$Collections$Generic$IList$$$Item","d":1114114,"h":55835688962,"f":2},{"p":1310721,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":73015558146,"f":1},"n":"Item","o":"@$2","d":1114114,"h":68720590850,"f":1}],"m":[{"r":1310721,"n":"OutOfBounds","d":1114114,"h":77310525442,"f":34},{"r":1310721,"n":"ToString","d":1114114,"h":81605492738,"f":32769},{"r":1310721,"n":"GetStringValue","d":1114114,"h":85900460034,"f":2},{"r":0,"n":"ToArray","d":1114114,"h":90195427330,"f":1},{"r":0,"n":"GetArrayValue","d":1114114,"h":94490394626,"f":2},{"r":655361,"p":[{"n":"item","p":1310721}],"n":"IndexOf","d":1114114,"h":103080329218,"f":2},{"r":65537,"p":[{"n":"array","p":0},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":1114114,"h":115965231106,"f":2},{"r":1179650,"n":"GetEnumerator","d":1114114,"h":141735034882,"f":1},{"r":262145,"p":[{"n":"value","p":1114114}],"n":"IsNullOrEmpty","d":1114114,"h":154619936770,"f":33},{"r":1114114,"p":[{"n":"values1","p":1114114},{"n":"values2","p":1114114}],"n":"Concat","d":1114114,"h":158914904066,"f":33},{"r":1114114,"p":[{"n":"values","p":1114114,"f":8},{"n":"value","p":1310721}],"n":"Concat","o":"@$1","d":1114114,"h":163209871362,"f":33},{"r":1114114,"p":[{"n":"value","p":1310721},{"n":"values","p":1114114,"f":8}],"n":"Concat","o":"@$2","d":1114114,"h":167504838658,"f":33},{"r":262145,"p":[{"n":"left","p":1114114},{"n":"right","p":1114114}],"n":"Equals","o":"@$2","d":1114114,"h":171799805954,"f":33},{"r":262145,"p":[{"n":"other","p":1114114}],"n":"Equals","o":"@$3","d":1114114,"h":184684707842,"f":1},{"r":262145,"p":[{"n":"left","p":1310721},{"n":"right","p":1114114}],"n":"Equals","o":"@$4","d":1114114,"h":188979675138,"f":33},{"r":262145,"p":[{"n":"left","p":1114114},{"n":"right","p":1310721}],"n":"Equals","o":"@$5","d":1114114,"h":193274642434,"f":33},{"r":262145,"p":[{"n":"other","p":1310721}],"n":"Equals","o":"@$6","d":1114114,"h":197569609730,"f":1},{"r":262145,"p":[{"n":"left","p":0},{"n":"right","p":1114114}],"n":"Equals","o":"@$7","d":1114114,"h":201864577026,"f":33},{"r":262145,"p":[{"n":"left","p":1114114},{"n":"right","p":0}],"n":"Equals","o":"@$8","d":1114114,"h":206159544322,"f":33},{"r":262145,"p":[{"n":"other","p":0}],"n":"Equals","o":"@$9","d":1114114,"h":210454511618,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1114114,"h":266289086466,"f":32769},{"r":655361,"n":"GetHashCode","d":1114114,"h":270584053762,"f":32769}],"l":[{"t":1114114,"n":"Empty","d":1114114,"h":4296081410,"f":33},{"t":131073,"n":"_values","d":1114114,"h":8591048706,"f":2}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$2","d":1114114,"h":12886016002,"f":1},{"p":[{"n":"values","p":0}],"n":".ctor","o":"$ctor$3","d":1114114,"h":17180983298,"f":1},{"n":".ctor","o":"$ctor$4","d":1114114,"h":283468955650,"f":1}],"i":[$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,$.$spc.System.Collections.Generic.ICollection$$($.$spc.System.String).$h,$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.String).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.String).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,31588353,$.$spc.System.IEquatable$$($.$mep.Microsoft.Extensions.Primitives.StringValues).$h,$.$spc.System.IEquatable$$($.$spc.System.String).$h,$.$spc.System.IEquatable$$($.$typeArray($.$spc.System.String)).$h],"j":[1179650],"h":1114114,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{ToString()}","t":1310721}]},{"t":37879809,"c":8627814401,"a":[{"v":null,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$($.$spc.System.String), $.$spc.System.Collections.Generic.ICollection$$($.$spc.System.String), $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.String), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.String), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String), $.$spc.System.Collections.IEnumerable, $.$spc.System.IEquatable$$($.$mep.Microsoft.Extensions.Primitives.StringValues), $.$spc.System.IEquatable$$($.$spc.System.String), $.$spc.System.IEquatable$$($.$typeArray($.$spc.System.String)) ]; }
            static get $fullName() { return `Microsoft.Extensions.Primitives.StringValues`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory"))