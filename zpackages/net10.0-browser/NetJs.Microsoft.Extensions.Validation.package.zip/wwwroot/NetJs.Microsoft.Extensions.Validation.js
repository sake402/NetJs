
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $sipl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Validation", 
    {"h":29,"f":"Microsoft.Extensions.Validation","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Common validation abstractions and validation infrastructure for .NET applications.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Validation","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Validation","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.Extensions.Validation.Tests","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver", ($self) => class IValidatableInfoResolver
        {
            static $h = 196637;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"type","p":142475265},{"n":"validatableInfo","p":131101,"f":2}],"n":"TryGetValidatableTypeInfo","o":"Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableTypeInfo","d":196637,"h":4295163933,"f":16777473},{"r":262145,"p":[{"n":"parameterInfo","p":81133569},{"n":"validatableInfo","p":131101,"f":2}],"n":"TryGetValidatableParameterInfo","o":"Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableParameterInfo","d":196637,"h":8590131229,"f":16777473}],"h":196637}; }
            static get $fullName() { return `IValidatableInfoResolver`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.IValidatableInfo", ($self) => class IValidatableInfo
        {
            static $h = 131101;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133169153,"p":[{"n":"value","p":131073},{"n":"context","p":786461},{"n":"cancellationToken","p":125829121}],"n":"ValidateAsync","o":"Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync","d":131101,"h":4295098397,"f":16777473}],"h":131101}; }
            static get $fullName() { return `IValidatableInfo`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidatableParameterInfo", ($self) => class ValidatableParameterInfo extends $.$$.System.Object
        {
            /*RequiredAttribute?*/ _requiredAttribute = null;
            $ctor$1(/*Type*/ parameterType, /*string*/ name, /*string*/ displayName)
            {
                super.$ctor();
                {
                    this.ParameterType = parameterType;
                    this.Name = name;
                    this.DisplayName = displayName;
                }
                return this;
            }
            /*Type*/ ParameterType = null;
            /*string*/ Name = null;
            /*string*/ DisplayName = null;
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (value === null && $.$mev.Microsoft.Extensions.Validation.TypeExtensions.IsNullable(this.ParameterType))
                    {
                        return;
                    }
                    context.ValidationContext.DisplayName = this.DisplayName;
                    context.ValidationContext.MemberName = this.Name;
                    /*var*/ let validationAttributes = this.GetValidationAttributes();
                    if (!(this._requiredAttribute === null) || $.$mev.Microsoft.Extensions.Validation.TypeExtensions.TryGetRequiredAttribute(validationAttributes, $.$ref(() => this._requiredAttribute, ($v) => this._requiredAttribute = $v, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute)))
                    {
                        /*var*/ let result = this._requiredAttribute.GetValidationResult(value, context.ValidationContext);
                        if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                        {
                            /*var*/ let key = $.$$.System.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${context.CurrentValidationPath}.${this.Name}`;
                            context.AddValidationError(this.Name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ result.ErrorMessage ], null, null), null);
                            return;
                        }
                    }
                    for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                    {
                        /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                        try
                        {
                            /*var*/ let result = attribute.GetValidationResult(value, context.ValidationContext);
                            if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                            {
                                /*var*/ let key = $.$$.System.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${context.CurrentValidationPath}.${this.Name}`;
                                context.AddOrExtendValidationErrors(this.Name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ result.ErrorMessage ], null, null), null);
                            }
                        }
                        catch(ex)
                        {
                            /*var*/ let key = $.$$.System.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${context.CurrentValidationPath}.${this.Name}`;
                            context.AddValidationError(this.Name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ ex.Message ], null, null), null);
                        }
                    }
                    let enumerable;
                    if ($.$mev.Microsoft.Extensions.Validation.TypeExtensions.IsEnumerable(this.ParameterType) && $.$is(value, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                    {
                        /*var*/ let index = 0;
                        /*var*/ let currentPrefix = context.CurrentValidationPath;
                        var $en4 = enumerable.System$Collections$IEnumerable$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$IEnumerator$Current;
                            {
                                if (item !== null)
                                {
                                    context.CurrentValidationPath = $.$$.System.String.IsNullOrEmpty(currentPrefix) ? `${this.Name}[${index}]` : `${currentPrefix}.${this.Name}[${index}]`;
                                    /*var*/ let validatableType;
                                    if (context.ValidationOptions.TryGetValidatableTypeInfo($.$$.System.Object.GetType.call(item), $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)))
                                    {
                                        await validatableType.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(item, context, cancellationToken);
                                    }
                                }
                                index++;
                            }
                        }
                        context.CurrentValidationPath = currentPrefix;
                    }
                    else if (value !== null)
                    {
                        /*var*/ let valueType = $.$$.System.Object.GetType.call(value);
                        /*var*/ let validatableType;
                        if (context.ValidationOptions.TryGetValidatableTypeInfo(valueType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)))
                        {
                            await validatableType.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(value, context, cancellationToken);
                        }
                    }
                });
            }
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync()
            {
                return this.ValidateAsync(...arguments);
            }
            static $h = 524317;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":21475360797,"f":50331656},"n":"ParameterType","d":524317,"h":17180393501,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":34360262685,"f":50331656},"n":"Name","d":524317,"h":30065295389,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":47245164573,"f":50331656},"n":"DisplayName","d":524317,"h":42950197277,"f":2097160}],"m":[{"r":$.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,"n":"GetValidationAttributes","d":524317,"h":51540131869,"f":16777476},{"r":133169153,"p":[{"n":"value","p":131073},{"n":"context","p":786461},{"n":"cancellationToken","p":125829121}],"n":"ValidateAsync","d":524317,"h":55835099165,"f":16781441}],"l":[{"t":2228262,"n":"_requiredAttribute","d":524317,"h":4295491613,"f":4194306}],"c":[{"p":[{"n":"parameterType","p":142475265},{"n":"name","p":1310721},{"n":"displayName","p":1310721}],"n":".ctor","o":"$ctor$1","d":524317,"h":8590458909,"f":16777220}],"i":[131101],"h":524317}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfo ]; }
            static get $fullName() { return `ValidatableParameterInfo`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidatablePropertyInfo", ($self) => class ValidatablePropertyInfo extends $.$$.System.Object
        {
            /*RequiredAttribute?*/ _requiredAttribute = null;
            $ctor$1(/*Type*/ declaringType, /*Type*/ propertyType, /*string*/ name, /*string*/ displayName)
            {
                super.$ctor();
                {
                    this.DeclaringType = declaringType;
                    this.PropertyType = propertyType;
                    this.Name = name;
                    this.DisplayName = displayName;
                }
                return this;
            }
            /*Type*/ DeclaringType = null;
            /*Type*/ PropertyType = null;
            /*string*/ Name = null;
            /*string*/ DisplayName = null;
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*var*/ let property = $.$firstOf(this.DeclaringType.GetProperty$6(this.Name), () => { throw new $.$$.System.InvalidOperationException().$ctor$12(`Property '${this.Name}' not found on type '${this.DeclaringType.Name}'.`) });
                    /*var*/ let propertyValue = property.GetValue$2(value);
                    /*var*/ let validationAttributes = this.GetValidationAttributes();
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    if ($.$$.System.String.IsNullOrEmpty(originalPrefix))
                    {
                        context.CurrentValidationPath = this.Name;
                    }
                    else 
                    {
                        context.CurrentValidationPath = `${originalPrefix}.${this.Name}`;
                    }
                    context.ValidationContext.DisplayName = this.DisplayName;
                    context.ValidationContext.MemberName = this.Name;
                    if (!(this._requiredAttribute === null) || $.$mev.Microsoft.Extensions.Validation.TypeExtensions.TryGetRequiredAttribute(validationAttributes, $.$ref(() => this._requiredAttribute, ($v) => this._requiredAttribute = $v, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute)))
                    {
                        /*var*/ let result = this._requiredAttribute.GetValidationResult(propertyValue, context.ValidationContext);
                        if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                        {
                            context.AddValidationError(this.Name, context.CurrentValidationPath, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ result.ErrorMessage ], null, null), value);
                            context.CurrentValidationPath = originalPrefix;
                            return;
                        }
                    }
                    ValidateValue.call(this, propertyValue, this.Name, context.CurrentValidationPath, validationAttributes, value);
                    if (context.CurrentDepth >= context.ValidationOptions.MaxDepth)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Maximum validation depth of ${context.ValidationOptions.MaxDepth} exceeded at '${context.CurrentValidationPath}' in '${this.DeclaringType.Name}.${this.Name}'. ` + "This is likely caused by a circular reference in the object graph. " + "Consider increasing the MaxDepth in ValidationOptions if deeper validation is required.");
                    }
                    context.CurrentDepth++;
                    try
                    {
                        let enumerable;
                        if ($.$mev.Microsoft.Extensions.Validation.TypeExtensions.IsEnumerable(this.PropertyType) && $.$is(propertyValue, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                        {
                            /*var*/ let index = 0;
                            /*var*/ let currentPrefix = context.CurrentValidationPath;
                            var $en5 = enumerable.System$Collections$IEnumerable$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$IEnumerator$Current;
                                {
                                    context.CurrentValidationPath = `${currentPrefix}[${index}]`;
                                    if (item !== null)
                                    {
                                        /*var*/ let itemType = $.$$.System.Object.GetType.call(item);
                                        /*var*/ let validatableType;
                                        if (context.ValidationOptions.TryGetValidatableTypeInfo(itemType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)))
                                        {
                                            await validatableType.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(item, context, cancellationToken);
                                        }
                                    }
                                    index++;
                                }
                            }
                            context.CurrentValidationPath = currentPrefix;
                        }
                        else if (propertyValue !== null)
                        {
                            /*var*/ let valueType = $.$$.System.Object.GetType.call(propertyValue);
                            /*var*/ let validatableType;
                            if (context.ValidationOptions.TryGetValidatableTypeInfo(valueType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)))
                            {
                                await validatableType.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(propertyValue, context, cancellationToken);
                            }
                        }
                    }
                    finally
                    {
                        {
                            context.CurrentDepth--;
                            context.CurrentValidationPath = originalPrefix;
                        }
                    }
                    /*void*/  function ValidateValue(/*object?*/ val, /*string*/ name, /*string*/ errorPrefix, /*ValidationAttribute[]*/ validationAttributes, /*object?*/ container)
                    {
                        for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                        {
                            /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                            try
                            {
                                /*var*/ let result = attribute.GetValidationResult(val, context.ValidationContext);
                                if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                                {
                                    /*var*/ let key = $.$$.System.String.TrimStart$1.call(errorPrefix, /*.*/ 46);
                                    context.AddOrExtendValidationErrors(name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ result.ErrorMessage ], null, null), container);
                                }
                            }
                            catch(ex)
                            {
                                /*var*/ let key = $.$$.System.String.TrimStart$1.call(errorPrefix, /*.*/ 46);
                                context.AddOrExtendValidationErrors(name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ ex.Message ], null, null), container);
                            }
                        }
                    }
                });
            }
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync()
            {
                return this.ValidateAsync(...arguments);
            }
            static $h = 589853;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":21475426333,"f":50331656},"n":"DeclaringType","d":589853,"h":17180459037,"f":2097160},{"p":142475265,"g":{"r":0,"d":0,"h":34360328221,"f":50331656},"n":"PropertyType","d":589853,"h":30065360925,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":47245230109,"f":50331656},"n":"Name","d":589853,"h":42950262813,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":60130131997,"f":50331656},"n":"DisplayName","d":589853,"h":55835164701,"f":2097160}],"m":[{"r":$.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,"n":"GetValidationAttributes","d":589853,"h":64425099293,"f":16777476},{"r":133169153,"p":[{"n":"value","p":131073},{"n":"context","p":786461},{"n":"cancellationToken","p":125829121}],"n":"ValidateAsync","d":589853,"h":68720066589,"f":16781441}],"l":[{"t":2228262,"n":"_requiredAttribute","d":589853,"h":4295557149,"f":4194306}],"c":[{"p":[{"n":"declaringType","p":142475265},{"n":"propertyType","p":142475265},{"n":"name","p":1310721},{"n":"displayName","p":1310721}],"n":".ctor","o":"$ctor$1","d":589853,"h":8590524445,"f":16777220}],"i":[131101],"h":589853}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfo ]; }
            static get $fullName() { return `ValidatablePropertyInfo`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidatableTypeInfo", ($self) => class ValidatableTypeInfo extends $.$$.System.Object
        {
            /*int*/ _membersCount = 0;
            /*List<Type>*/ _superTypes = null;
            $ctor$1(/*Type*/ type, /*IReadOnlyList<ValidatablePropertyInfo>*/ members)
            {
                super.$ctor();
                {
                    this.Type = type;
                    this.Members = members;
                    this._membersCount = members.System$Collections$Generic$IReadOnlyCollection$$$Count;
                    this._superTypes = $.$mev.Microsoft.Extensions.Validation.TypeExtensions.GetAllImplementedTypes(type);
                }
                return this;
            }
            /*Type*/ Type = null;
            /*IReadOnlyList<ValidatablePropertyInfo>*/ Members = null;
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (value === null)
                    {
                        return;
                    }
                    if (context.CurrentDepth >= context.ValidationOptions.MaxDepth)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Maximum validation depth of ${context.ValidationOptions.MaxDepth} exceeded at '${context.CurrentValidationPath}' in '${this.Type.Name}'. ` + "This is likely caused by a circular reference in the object graph. " + "Consider increasing the MaxDepth in ValidationOptions if deeper validation is required.");
                    }
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    /*var*/ let originalErrorCount = (context.ValidationErrors?.Count ?? null) ?? 0;
                    try
                    {
                        await this.ValidateMembersAsync(value, context, cancellationToken);
                        /*var*/ let actualType = $.$$.System.Object.GetType.call(value);
                        var $en4 = this.GetSuperTypeInfos(actualType, context).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var superTypeInfo = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                await superTypeInfo.ValidateMembersAsync(value, context, cancellationToken);
                            }
                        }
                        if (!(context.ValidationErrors === null) && context.ValidationErrors.Count > originalErrorCount)
                        {
                            return;
                        }
                        this.ValidateTypeAttributes(value, context);
                        if (!(context.ValidationErrors === null) && context.ValidationErrors.Count > originalErrorCount)
                        {
                            return;
                        }
                        this.ValidateValidatableObjectInterface(value, context);
                    }
                    finally
                    {
                        {
                            context.CurrentValidationPath = originalPrefix;
                        }
                    }
                });
            }
            /*Task *//*async*/  ValidateMembersAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    for(/*var*/ let i = 0; i < this._membersCount; i++)
                    {
                        try
                        {
                            await this.Members.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$mev.Microsoft.Extensions.Validation.ValidatablePropertyInfo]).ValidateAsync(value, context, cancellationToken);
                        }
                        finally
                        {
                            {
                                context.CurrentValidationPath = originalPrefix;
                            }
                        }
                    }
                });
            }
            /*void */ ValidateTypeAttributes(/*object?*/ value, /*ValidateContext*/ context)
            {
                /*var*/ let validationAttributes = this.GetValidationAttributes();
                /*var*/ let errorPrefix = context.CurrentValidationPath;
                for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                {
                    /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                    /*var*/ let result = attribute.GetValidationResult(value, context.ValidationContext);
                    if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                    {
                        var $en4 = result.MemberNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var memberName = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*var*/ let key = $.$$.System.String.IsNullOrEmpty(errorPrefix) ? memberName : `${errorPrefix}.${memberName}`;
                                context.AddOrExtendValidationError(memberName, key, result.ErrorMessage, value);
                            }
                        }
                        if (!$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, result.MemberNames))
                        {
                            context.AddOrExtendValidationError($.$$.System.String.Empty, errorPrefix, result.ErrorMessage, value);
                        }
                    }
                }
            }
            /*void */ ValidateValidatableObjectInterface(/*object?*/ value, /*ValidateContext*/ context)
            {
                let validatable;
                if ($.$mev.Microsoft.Extensions.Validation.TypeExtensions.ImplementsInterface(this.Type, $.$sca.System.ComponentModel.DataAnnotations.IValidatableObject.$type) && $.$is(value, $.$sca.System.ComponentModel.DataAnnotations.IValidatableObject, { set $v(v){ validatable = v; } }))
                {
                    /*var*/ let originalDisplayName = context.ValidationContext.DisplayName;
                    /*var*/ let originalMemberName = context.ValidationContext.MemberName;
                    /*var*/ let errorPrefix = context.CurrentValidationPath;
                    context.ValidationContext.DisplayName = this.Type.Name;
                    context.ValidationContext.MemberName = null;
                    /*var*/ let validationResults = validatable.System$ComponentModel$DataAnnotations$IValidatableObject$Validate(context.ValidationContext);
                    var $en3 = validationResults.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var validationResult = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (validationResult !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(validationResult.ErrorMessage === null))
                            {
                                var $en6 = validationResult.MemberNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var memberName = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        /*var*/ let key = $.$$.System.String.IsNullOrEmpty(errorPrefix) ? memberName : `${errorPrefix}.${memberName}`;
                                        context.AddOrExtendValidationError(memberName, key, validationResult.ErrorMessage, value);
                                    }
                                }
                                if (!$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, validationResult.MemberNames))
                                {
                                    context.AddOrExtendValidationError($.$$.System.String.Empty, $.$$.System.String.Empty, validationResult.ErrorMessage, value);
                                }
                            }
                        }
                    }
                    context.ValidationContext.DisplayName = originalDisplayName;
                    context.ValidationContext.MemberName = originalMemberName;
                }
            }
            /*IEnumerable<ValidatableTypeInfo> */ GetSuperTypeInfos(/*Type*/ actualType, /*ValidateContext*/ context)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = $.$sl.System.Linq.Enumerable.Where($.$$.System.Type, this._superTypes, new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.IsAssignableFrom(actualType);
                    }, {"r":262145,"p":[{"n":"t","p":142475265}],"n":"","d":720925,"h":0,"f":17825794})).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var superType = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*var*/ let found;
                            let superTypeInfo;
                            if (context.ValidationOptions.TryGetValidatableTypeInfo(superType, $.$ref(() => found, ($v) => found = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)) && $.$is(found, $.$mev.Microsoft.Extensions.Validation.ValidatableTypeInfo, { set $v(v){ superTypeInfo = v; } }))
                            {
                                yield superTypeInfo;
                            }
                        }
                    }
                }.bind(this));
            }
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync()
            {
                return this.ValidateAsync(...arguments);
            }
            static $h = 720925;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":30065491997,"f":50331656},"n":"Type","d":720925,"h":25770524701,"f":2097160},{"p":$.$$.System.Collections.Generic.IReadOnlyList$$($.$mev.Microsoft.Extensions.Validation.ValidatablePropertyInfo).$h,"g":{"r":0,"d":0,"h":42950393885,"f":50331656},"n":"Members","d":720925,"h":38655426589,"f":2097160}],"m":[{"r":$.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,"n":"GetValidationAttributes","d":720925,"h":17180590109,"f":16777476},{"r":133169153,"p":[{"n":"value","p":131073},{"n":"context","p":786461},{"n":"cancellationToken","p":125829121}],"n":"ValidateAsync","d":720925,"h":47245361181,"f":16781441},{"r":133169153,"p":[{"n":"value","p":131073},{"n":"context","p":786461},{"n":"cancellationToken","p":125829121}],"n":"ValidateMembersAsync","d":720925,"h":51540328477,"f":16781314},{"r":65537,"p":[{"n":"value","p":131073},{"n":"context","p":786461}],"n":"ValidateTypeAttributes","d":720925,"h":55835295773,"f":16777218},{"r":65537,"p":[{"n":"value","p":131073},{"n":"context","p":786461}],"n":"ValidateValidatableObjectInterface","d":720925,"h":60130263069,"f":16777218},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mev.Microsoft.Extensions.Validation.ValidatableTypeInfo).$h,"p":[{"n":"actualType","p":142475265},{"n":"context","p":786461}],"n":"GetSuperTypeInfos","d":720925,"h":64425230365,"f":16777218}],"l":[{"t":655361,"n":"_membersCount","d":720925,"h":4295688221,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Type).$h,"n":"_superTypes","d":720925,"h":8590655517,"f":4194306}],"c":[{"p":[{"n":"type","p":142475265},{"n":"members","p":$.$$.System.Collections.Generic.IReadOnlyList$$($.$mev.Microsoft.Extensions.Validation.ValidatablePropertyInfo).$h}],"n":".ctor","o":"$ctor$1","d":720925,"h":12885622813,"f":16777220}],"i":[131101],"h":720925}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfo ]; }
            static get $fullName() { return `ValidatableTypeInfo`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidationOptions", ($self) => class ValidationOptions extends $.$$.System.Object
        {
            /*IList<IValidatableInfoResolver>*/ Resolvers = null;
            /*int*/ MaxDepth = 0;
            /*bool */ TryGetValidatableTypeInfo(/*Type*/ type, /*out IValidatableInfo?*/ validatableTypeInfo)
            {
                var $en2 = this.Resolvers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var resolver = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (resolver.Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableTypeInfo(type, validatableTypeInfo))
                        {
                            return true;
                        }
                    }
                }
                validatableTypeInfo.$v = null;
                return false;
            }
            /*bool */ TryGetValidatableParameterInfo(/*ParameterInfo*/ parameterInfo, /*out IValidatableInfo?*/ validatableInfo)
            {
                var $en2 = this.Resolvers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var resolver = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (resolver.Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableParameterInfo(parameterInfo, validatableInfo))
                        {
                            return true;
                        }
                    }
                }
                validatableInfo.$v = null;
                return false;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Resolvers = (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver))().$ctor$1();
                    return $t1;
                })();
                this.MaxDepth = 32;
            }
            static $h = 917533;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IList$$($.$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver).$h,"g":{"r":0,"d":0,"h":12885819421,"f":50331649},"n":"Resolvers","d":917533,"h":8590852125,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25770721309,"f":50331649},"s":{"r":0,"d":0,"h":30065688605,"f":83886081},"n":"MaxDepth","d":917533,"h":21475754013,"f":2097153}],"m":[{"r":262145,"p":[{"n":"type","p":142475265},{"n":"validatableTypeInfo","p":131101,"f":2}],"n":"TryGetValidatableTypeInfo","d":917533,"h":34360655901,"f":16777217},{"r":262145,"p":[{"n":"parameterInfo","p":81133569},{"n":"validatableInfo","p":131101,"f":2}],"n":"TryGetValidatableParameterInfo","d":917533,"h":38655623197,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":917533,"h":42950590493,"f":16777217}],"h":917533}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ValidationOptions`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.TypeExtensions", ($self) => class TypeExtensions
        {
            static /*bool */ IsEnumerable(/*this Type*/ type)
            {
                if (type.IsGenericType && ($.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type) || $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.ICollection$$().$type) || $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.List$$().$type) || $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IList$$().$type)))
                {
                    return true;
                }
                if (type.IsArray)
                {
                    return true;
                }
                if ($.$$.System.Collections.IEnumerable.$type.IsAssignableFrom(type) && $.$$.System.Type.op_Inequality$1(type, $.$$.System.String.$type))
                {
                    return true;
                }
                return false;
            }
            static /*bool */ IsNullable(/*this Type*/ type)
            {
                if (type.IsValueType)
                {
                    return false;
                }
                if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type))
                {
                    return true;
                }
                return false;
            }
            static /*bool */ TryGetRequiredAttribute(/*this ValidationAttribute[]*/ attributes, /*out RequiredAttribute?*/ requiredAttribute)
            {
                let $i1 = 0;
                let $arr1 = attributes;
                while ($i1 < $arr1.length)
                {
                    let attribute = $arr1[$i1++];
                    let requiredAttr;
                    if ($.$is(attribute, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute, { set $v(v){ requiredAttr = v; } }))
                    {
                        requiredAttribute.$v = requiredAttr;
                        return true;
                    }
                }
                requiredAttribute.$v = null;
                return false;
            }
            static /*List<Type> */ GetAllImplementedTypes(/*this Type*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*var*/ let implementedTypes = new ($.$$.System.Collections.Generic.List$$($.$$.System.Type))().$ctor$1();
                let $i1 = 0;
                let $arr1 = type.GetInterfaces();
                while ($i1 < $arr1.length)
                {
                    let interfaceType = $arr1[$i1++];
                    implementedTypes.Add(interfaceType);
                }
                /*var*/ let baseType = type.BaseType;
                while($.$$.System.Type.op_Inequality$1(baseType, null) && $.$$.System.Type.op_Inequality$1(baseType, $.$$.System.Object.$type))
                {
                    implementedTypes.Add(baseType);
                    baseType = baseType.BaseType;
                }
                return implementedTypes;
            }
            static /*bool */ ImplementsInterface(/*this Type*/ type, /*Type*/ interfaceType)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(interfaceType, "interfaceType");
                if (!interfaceType.IsInterface)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13(`Type ${interfaceType.FullName} is not an interface.`, "interfaceType");
                }
                return interfaceType.IsAssignableFrom(type);
            }
            static $h = 458781;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"type","p":142475265}],"n":"IsEnumerable","d":458781,"h":4295426077,"f":16777249},{"r":262145,"p":[{"n":"type","p":142475265}],"n":"IsNullable","d":458781,"h":8590393373,"f":16777249},{"r":262145,"p":[{"n":"attributes","p":$.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h},{"n":"requiredAttribute","p":2228262,"f":2}],"n":"TryGetRequiredAttribute","d":458781,"h":12885360669,"f":16777249},{"r":$.$$.System.Collections.Generic.List$$($.$$.System.Type).$h,"p":[{"n":"type","p":142475265}],"n":"GetAllImplementedTypes","d":458781,"h":17180327965,"f":16777249},{"r":262145,"p":[{"n":"type","p":142475265},{"n":"interfaceType","p":142475265}],"n":"ImplementsInterface","d":458781,"h":21475295261,"f":16777249}],"h":458781}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `TypeExtensions`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.DependencyInjection.ValidationServiceCollectionExtensions", ($self) => class ValidationServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddValidation(/*this IServiceCollection*/ services, /*Action<ValidationOptions>?*/ configureOptions)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mev.Microsoft.Extensions.Validation.ValidationOptions, services, new ($.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    if (!(configureOptions === null))
                    {
                        configureOptions.Invoke(options);
                    }
                    options.Resolvers.System$Collections$Generic$ICollection$$$Add(new $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver().$ctor$1(), [$.$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver]);
                }, {"r":65537,"p":[{"n":"options","p":917533}],"n":"","d":65565,"h":0,"f":17825794}));
                return services;
            }
            static $h = 65565;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435},{"n":"configureOptions","p":$.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationOptions).$h,"f":65}],"n":"AddValidation","d":65565,"h":4295032861,"f":16777249}],"h":65565}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ValidationServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidateContext", ($self) => class ValidateContext extends $.$$.System.Object
        {
            /*ValidationContext*/ ValidationContext = null;
            /*string*/ CurrentValidationPath = null;
            /*ValidationOptions*/ ValidationOptions = null;
            /*Dictionary<string, string[]>?*/ ValidationErrors = null;
            /*int*/ CurrentDepth = 0;
            /*Action<ValidationErrorContext>?*/ OnValidationError = null;
            add_OnValidationError(/*Action<ValidationErrorContext>?*/ value)
            {
                this.OnValidationError = $.$$.System.Delegate.Combine(this.OnValidationError, value);
            }
            remove_OnValidationError(/*Action<ValidationErrorContext>?*/ value)
            {
                this.OnValidationError = $.$$.System.Delegate.Remove(this.OnValidationError, value);
            }
            /*void */ AddValidationError(/*string*/ propertyName, /*string*/ key, /*string[]*/ error, /*object?*/ container)
            {
                this.ValidationErrors ??= (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.String)))().$ctor$1();
                    return $t1;
                })();
                this.ValidationErrors.set_Item(key, error);
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext()
                    const $t1 = $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext;
                    const $i1 = new $t1();
                    $i1.Name = propertyName;
                    $i1.Path = key;
                    $i1.Errors = error;
                    $i1.Container = container;
                    return $i1;
                })());
            }
            /*void */ AddOrExtendValidationErrors(/*string*/ propertyName, /*string*/ key, /*string[]*/ errors, /*object?*/ container)
            {
                this.ValidationErrors ??= (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.String)))().$ctor$1();
                    return $t1;
                })();
                /*var*/ let existingErrors;
                if (this.ValidationErrors.TryGetValue(key, $.$ref(() => existingErrors, ($v) => existingErrors = $v, $.$typeArray($.$$.System.String))))
                {
                    /*var*/ let newErrors = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [((existingErrors.length + errors.length) | 0)], null);
                    existingErrors.CopyTo(newErrors, 0);
                    errors.CopyTo(newErrors, existingErrors.length);
                    this.ValidationErrors.set_Item(key, newErrors);
                }
                else 
                {
                    this.ValidationErrors.set_Item(key, errors);
                }
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext()
                    const $t2 = $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext;
                    const $i2 = new $t2();
                    $i2.Name = propertyName;
                    $i2.Path = key;
                    $i2.Errors = errors;
                    $i2.Container = container;
                    return $i2;
                })());
            }
            /*void */ AddOrExtendValidationError(/*string*/ name, /*string*/ key, /*string*/ error, /*object?*/ container)
            {
                this.ValidationErrors ??= (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.String)))().$ctor$1();
                    return $t1;
                })();
                /*var*/ let existingErrors;
                if (this.ValidationErrors.TryGetValue(key, $.$ref(() => existingErrors, ($v) => existingErrors = $v, $.$typeArray($.$$.System.String))) && !$.$$.System.MemoryExtensions.Contains$2($.$$.System.String, $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1(existingErrors), error))
                {
                    this.ValidationErrors.set_Item(key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ ...existingErrors, error ], null, null));
                }
                else 
                {
                    this.ValidationErrors.set_Item(key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ error ], null, null));
                }
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext()
                    const $t2 = $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext;
                    const $i2 = new $t2();
                    $i2.Name = name;
                    $i2.Path = key;
                    $i2.Errors = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ error ], null, null);
                    $i2.Container = container;
                    return $i2;
                })());
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.CurrentValidationPath = $.$$.System.String.Empty;
            }
            static $h = 786461;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3538982,"g":{"r":0,"d":0,"h":12885688349,"f":50331649},"s":{"r":0,"d":0,"h":17180655645,"f":83886081},"n":"ValidationContext","d":786461,"h":8590721053,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065557533,"f":50331649},"s":{"r":0,"d":0,"h":34360524829,"f":83886081},"n":"CurrentValidationPath","d":786461,"h":25770590237,"f":2097153},{"p":917533,"g":{"r":0,"d":0,"h":47245426717,"f":50331649},"s":{"r":0,"d":0,"h":51540394013,"f":83886081},"n":"ValidationOptions","d":786461,"h":42950459421,"f":2097153},{"p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.String)).$h,"g":{"r":0,"d":0,"h":64425295901,"f":50331649},"s":{"r":0,"d":0,"h":68720263197,"f":83886081},"n":"ValidationErrors","d":786461,"h":60130328605,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":81605165085,"f":50331649},"s":{"r":0,"d":0,"h":85900132381,"f":83886081},"n":"CurrentDepth","d":786461,"h":77310197789,"f":2097153}],"m":[{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"key","p":1310721},{"n":"error","p":$.$typeArray($.$$.System.String).$h},{"n":"container","p":131073}],"n":"AddValidationError","d":786461,"h":103080001565,"f":16777224},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"key","p":1310721},{"n":"errors","p":$.$typeArray($.$$.System.String).$h},{"n":"container","p":131073}],"n":"AddOrExtendValidationErrors","d":786461,"h":107374968861,"f":16777224},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"key","p":1310721},{"n":"error","p":1310721},{"n":"container","p":131073}],"n":"AddOrExtendValidationError","d":786461,"h":111669936157,"f":16777224}],"c":[{"n":".ctor","o":"$ctor$1","d":786461,"h":115964903453,"f":16777217}],"e":[{"e":$.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext).$h}],"n":"add_OnValidationError","d":786461,"h":90195099677,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext).$h}],"n":"remove_OnValidationError","d":786461,"h":94490066973,"f":285212673},"n":"OnValidationError","d":786461,"h":98785034269,"f":8388609}],"h":786461}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ValidateContext`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver", ($self) => class RuntimeValidatableParameterInfoResolver extends $.$$.System.Object
        {
            /*bool */ TryGetValidatableTypeInfo(/*Type*/ type, /*out IValidatableInfo?*/ validatableInfo)
            {
                validatableInfo.$v = null;
                return false;
            }
            /*bool */ TryGetValidatableParameterInfo(/*ParameterInfo*/ parameterInfo, /*out IValidatableInfo?*/ validatableInfo)
            {
                if ($.$$.System.String.op_Equality(parameterInfo.Name, null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Encountered a parameter of type '${$.$$.System.Type.ToString.call(parameterInfo.ParameterType)}' without a name. Parameters must have a name.`);
                }
                if ($.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$11($.$mev.Microsoft.Extensions.Validation.SkipValidationAttribute, parameterInfo) !== null || $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$8($.$mev.Microsoft.Extensions.Validation.SkipValidationAttribute, parameterInfo.ParameterType) !== null)
                {
                    validatableInfo.$v = null;
                    return false;
                }
                /*var*/ let validationAttributes = $.$sl.System.Linq.Enumerable.ToArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute, $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$17($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute, parameterInfo));
                if (validationAttributes.length === 0 && !$.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.IsComplexType(parameterInfo.ParameterType))
                {
                    validatableInfo.$v = null;
                    return false;
                }
                validatableInfo.$v = new $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo().$ctor$2(parameterInfo.ParameterType, parameterInfo.Name, $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.GetDisplayName(parameterInfo), validationAttributes);
                return true;
            }
            static /*string */ GetDisplayName(/*ParameterInfo*/ parameterInfo)
            {
                /*var*/ let displayAttribute = $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$11($.$sca.System.ComponentModel.DataAnnotations.DisplayAttribute, parameterInfo);
                if (displayAttribute !== null)
                {
                    return displayAttribute.Name ?? parameterInfo.Name;
                }
                return parameterInfo.Name;
            }
            static $_RuntimeValidatableParameterInfo;
            static get RuntimeValidatableParameterInfo()
            {
                let $cls = $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver;
                return $cls.$_RuntimeValidatableParameterInfo ??= $asm.$ncls("$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo", ($self) => class RuntimeValidatableParameterInfo extends $.$mev.Microsoft.Extensions.Validation.ValidatableParameterInfo
                {
                    /*ValidationAttribute[] */ GetValidationAttributes()
                    {
                        return this._validationAttributes;
                    }
                    /*ValidationAttribute[]*/ _validationAttributes = null;
                    //Begin primary constructor
                    /*Type*/ parameterType = null;
                    /*string*/ name = null;
                    /*string*/ displayName = null;
                    /*ValidationAttribute[]*/ validationAttributes = null;
                    $ctor$2(/*Type*/$parameterType, /*string*/$name, /*string*/$displayName, /*ValidationAttribute[]*/$validationAttributes)
                    {
                        this.parameterType = $parameterType;
                        this.name = $name;
                        this.displayName = $displayName;
                        this.validationAttributes = $validationAttributes;
                        //depends on primary constructor parameter
                        this._validationAttributes = this.validationAttributes;
                        return this
                    }
                    //End primary constructor
                    static $h = 327709;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":524317,"m":[{"r":$.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,"n":"GetValidationAttributes","d":327709,"h":8590262301,"f":16809988}],"l":[{"t":$.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,"n":"_validationAttributes","d":327709,"h":12885229597,"f":4194306}],"c":[{"p":[{"n":"parameterType","p":142475265},{"n":"name","p":1310721},{"n":"displayName","p":1310721},{"n":"validationAttributes","p":$.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h}],"n":".ctor","o":"$ctor$2","d":327709,"h":4295295005,"f":16777217}],"i":[131101],"d":262173,"h":327709}; }
                    static get $b() { return $.$mev.Microsoft.Extensions.Validation.ValidatableParameterInfo; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfo ]; }
                    static get $fullName() { return `RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo`; }
                }, $cls, ($v) => $cls.$_RuntimeValidatableParameterInfo = $v);
            }
            static /*bool */ IsComplexType(/*Type*/ type)
            {
                if (type.IsPrimitive || type.IsEnum || $.$$.System.Type.op_Equality$1(type, $.$$.System.String.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.Decimal.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.DateTime.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.DateTimeOffset.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.TimeOnly.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.DateOnly.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.TimeSpan.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.Guid.$type) || $.$$.System.Type.op_Equality$1(type, $.$ssc.System.Security.Claims.ClaimsPrincipal.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.Threading.CancellationToken.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.IO.Stream.$type) || $.$$.System.Type.op_Equality$1(type, $.$sipl.System.IO.Pipelines.PipeReader.$type))
                {
                    return false;
                }
                let nullableType;
                if ($.$$.System.Nullable.GetUnderlyingType(type) !== null && ((nullableType = $.$$.System.Nullable.GetUnderlyingType(type), nullableType != null && true)))
                {
                    return $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.IsComplexType(nullableType);
                }
                return type.IsClass || type.IsValueType;
            }
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfoResolver.TryGetValidatableTypeInfo(System.Type, out Microsoft.Extensions.Validation.IValidatableInfo?)
            Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableTypeInfo()
            {
                return this.TryGetValidatableTypeInfo(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfoResolver.TryGetValidatableParameterInfo(System.Reflection.ParameterInfo, out Microsoft.Extensions.Validation.IValidatableInfo?)
            Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableParameterInfo()
            {
                return this.TryGetValidatableParameterInfo(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 262173;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"type","p":142475265},{"n":"validatableInfo","p":131101,"f":2}],"n":"TryGetValidatableTypeInfo","d":262173,"h":4295229469,"f":16777217},{"r":262145,"p":[{"n":"parameterInfo","p":81133569},{"n":"validatableInfo","p":131101,"f":2}],"n":"TryGetValidatableParameterInfo","d":262173,"h":8590196765,"f":16777217},{"r":1310721,"p":[{"n":"parameterInfo","p":81133569}],"n":"GetDisplayName","d":262173,"h":12885164061,"f":16777250},{"r":262145,"p":[{"n":"type","p":142475265}],"n":"IsComplexType","d":262173,"h":21475098653,"f":16777250}],"c":[{"n":".ctor","o":"$ctor$1","d":262173,"h":25770065949,"f":16777217}],"i":[196637],"j":[327709],"h":262173}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver ]; }
            static get $fullName() { return `RuntimeValidatableParameterInfoResolver`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.SkipValidationAttribute", ($self) => class SkipValidationAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 393245;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":393245,"h":4295360541,"f":16777217}],"h":393245,"a":[{"t":14745601,"c":21489582081,"a":[{"v":2180,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `SkipValidationAttribute`; }
        });
        
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 655389;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":655389,"h":4295622685,"f":16777217}],"h":655389,"a":[{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `ValidatableTypeAttribute`; }
        });
        
        $asm.$str("$mev.Microsoft.Extensions.Validation.ValidationErrorContext", ($self) => class ValidationErrorContext extends $.$$.System.ValueType
        {
            /*string*/ Name = null;
            /*string*/ Path = null;
            /*IReadOnlyList<string>*/ Errors = null;
            /*object?*/ Container = null;
            /*string */ GetDebuggerDisplay()
            {
                return `${this.Path}: ${$.$$.System.String.Join$5(",", this.Errors)}`;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.Path = this.Path;
                copy.Errors = this.Errors;
                copy.Container = this.Container;
                return copy;
            }
            static $h = 851997;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885753885,"f":50331649},"s":{"r":0,"d":0,"h":17180721181,"f":83886081},"n":"Name","d":851997,"h":8590786589,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065623069,"f":50331649},"s":{"r":0,"d":0,"h":34360590365,"f":83886081},"n":"Path","d":851997,"h":25770655773,"f":2097153},{"p":$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":47245492253,"f":50331649},"s":{"r":0,"d":0,"h":51540459549,"f":83886081},"n":"Errors","d":851997,"h":42950524957,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":64425361437,"f":50331649},"s":{"r":0,"d":0,"h":68720328733,"f":83886081},"n":"Container","d":851997,"h":60130394141,"f":2097153}],"m":[{"r":1310721,"n":"GetDebuggerDisplay","d":851997,"h":73015296029,"f":16777218}],"c":[{"n":".ctor","o":"$ctor$2","d":851997,"h":77310263325,"f":16777217}],"h":851997,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{GetDebuggerDisplay(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ValidationErrorContext`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.System.IO.Pipelines"))