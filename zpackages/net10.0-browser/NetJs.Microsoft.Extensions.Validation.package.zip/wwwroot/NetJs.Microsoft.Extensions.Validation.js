
//--TRIMMABLE-BOUNDARY-START(113)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $sipl) {
    "use strict";
    let _;
    let $pgBhve;
    let $EUYeOd;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Validation", 
    {
  "h": 113,
  "f": "Microsoft.Extensions.Validation",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Common validation abstractions and validation infrastructure for .NET applications.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Validation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Validation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Extensions.Validation.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131185)
        $asm.$cls(`$mev.MEV.IValidatableInfo`, ($self) => class IValidatableInfo
        {
            static $h = 131185;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098481),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786545
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateAsync",
      "o": "MEV$IValidatableInfo$ValidateAsync",
      "d": 131185,
      "h": 4295098481,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098481)
  ],
  "h": 131185
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.IValidatableInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}IValidatableInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131185)
        
        

        //--TRIMMABLE-BOUNDARY-START(196721)
        $asm.$cls(`$mev.MEV.IValidatableInfoResolver`, ($self) => class IValidatableInfoResolver
        {
            static $h = 196721;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131313),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "validatableInfo",
          "p": 131185,
          "f": 2
        }
      ],
      "n": "TryGetValidatableTypeInfo",
      "o": "MEV$IValidatableInfoResolver$TryGetValidatableTypeInfo",
      "d": 196721,
      "h": 8590131313,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590131313),
//--TRIMMABLE-BOUNDARY-START(4295164017),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameterInfo",
          "p": 119078913
        },
        {
          "n": "validatableInfo",
          "p": 131185,
          "f": 2
        }
      ],
      "n": "TryGetValidatableParameterInfo",
      "o": "MEV$IValidatableInfoResolver$TryGetValidatableParameterInfo",
      "d": 196721,
      "h": 4295164017,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295164017)
  ],
  "h": 196721
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.IValidatableInfoResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}IValidatableInfoResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196721)
        
        

        //--TRIMMABLE-BOUNDARY-START(524401)
        $asm.$cls(`$mev.MEV.ValidatableParameterInfo`, ($self) => class ValidatableParameterInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295491697)
            /*RequiredAttribute?*/ _requiredAttribute = null;
            //--TRIMMABLE-BOUNDARY-END(4295491697)
            
            //--TRIMMABLE-BOUNDARY-START(21475360881)
            $ctor$1(/*Type*/ parameterType, /*string*/ name, /*string*/ displayName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360881);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ParameterType = parameterType;
                    this.Name = name;
                    this.DisplayName = displayName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360881)
            
            //--TRIMMABLE-BOUNDARY-START(64425033841)
            /*Type*/ ParameterType = null;
            //--TRIMMABLE-BOUNDARY-END(64425033841)
            
            //--TRIMMABLE-BOUNDARY-START(60130066545)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(60130066545)
            
            //--TRIMMABLE-BOUNDARY-START(25770328177)
            /*string*/ DisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(25770328177)
            
            //--TRIMMABLE-BOUNDARY-START(68720001137)
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720001137);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (value === null && $.$mev.MEV.TypeExtensions.IsNullable(this.ParameterType))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    context.ValidationContext.DisplayName = this.DisplayName;
                    context.ValidationContext.MemberName = this.Name;
                    /*var*/ let validationAttributes = this.GetValidationAttributes();
                    if (!(this._requiredAttribute === null) || $.$mev.MEV.TypeExtensions.TryGetRequiredAttribute(validationAttributes, $.$ref(() => this._requiredAttribute, ($v) => this._requiredAttribute = $v, $.$sca.SCD.RequiredAttribute)))
                    {
                        /*var*/ let result = this._requiredAttribute.GetValidationResult(value, context.ValidationContext);
                        if (!(result === null) && result !== $.$sca.SCD.ValidationResult.Success && !(result.ErrorMessage === null))
                        {
                            /*var*/ let key = $.$$.S.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${$.$strNN(context.CurrentValidationPath)}.${$.$strNN(this.Name)}`;
                            context.AddValidationError(this.Name, key, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ result.ErrorMessage ], null, null), null);
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                    }
                    for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                    {
                        /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                        try
                        {
                            /*var*/ let result = attribute.GetValidationResult(value, context.ValidationContext);
                            if (!(result === null) && result !== $.$sca.SCD.ValidationResult.Success && !(result.ErrorMessage === null))
                            {
                                /*var*/ let key = $.$$.S.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${$.$strNN(context.CurrentValidationPath)}.${$.$strNN(this.Name)}`;
                                context.AddOrExtendValidationErrors(this.Name, key, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ result.ErrorMessage ], null, null), null);
                            }
                        }
                        catch(ex)
                        {
                            /*var*/ let key = $.$$.S.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${$.$strNN(context.CurrentValidationPath)}.${$.$strNN(this.Name)}`;
                            context.AddValidationError(this.Name, key, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ ex.Message ], null, null), null);
                        }
                    }
                    let enumerable;
                    if ($.$mev.MEV.TypeExtensions.IsEnumerable(this.ParameterType) && $.$is(value, $.$$.SC$1.IEnumerable, { set $v($v){ enumerable = $v; } }))
                    {
                        /*var*/ let index = 0;
                        /*var*/ let currentPrefix = context.CurrentValidationPath;
                        let $en2 = enumerable.SC$1$IEnumerable$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let item = $en2.SC$1$IEnumerator$Current;
                            {
                                if (item !== null)
                                {
                                    /*var*/ let validatableType;
                                    context.CurrentValidationPath = $.$$.S.String.IsNullOrEmpty(currentPrefix) ? `${$.$strNN(this.Name)}[${$.$strNN(index)}]` : `${$.$strNN(currentPrefix)}.${$.$strNN(this.Name)}[${$.$strNN(index)}]`;
                                    if (context.ValidationOptions.TryGetValidatableTypeInfo($.$$.S.Object.GetType.call(item), $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.MEV.IValidatableInfo)))
                                    {
                                        let $t4, $r4;
                                        ($t4 = validatableType.MEV$IValidatableInfo$ValidateAsync(item, context, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    }
                                }
                                index++;
                            }
                        }
                        context.CurrentValidationPath = currentPrefix;
                    }
                    else if (value !== null)
                    {
                        /*var*/ let validatableType;
                        /*var*/ let valueType = $.$$.S.Object.GetType.call(value);
                        if (context.ValidationOptions.TryGetValidatableTypeInfo(valueType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.MEV.IValidatableInfo)))
                        {
                            let $t6, $r6;
                            ($t6 = validatableType.MEV$IValidatableInfo$ValidateAsync(value, context, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720001137)
            
            //--TRIMMABLE-BOUNDARY-START(4295098481)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            MEV$IValidatableInfo$ValidateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098481)
            
            static $h = 524401;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425033841),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540131953,
        "f": 50331656
      },
      "n": "ParameterType",
      "d": 524401,
      "h": 64425033841,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(64425033841),
//--TRIMMABLE-BOUNDARY-START(60130066545),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197361,
        "f": 50331656
      },
      "n": "Name",
      "d": 524401,
      "h": 60130066545,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60130066545),
//--TRIMMABLE-BOUNDARY-START(25770328177),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360262769,
        "f": 50331656
      },
      "n": "DisplayName",
      "d": 524401,
      "h": 25770328177,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25770328177)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835099249),
    {
      "r": $.$typeArray($.$sca.SCD.ValidationAttribute).$h,
      "n": "GetValidationAttributes",
      "d": 524401,
      "h": 55835099249,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(55835099249),
//--TRIMMABLE-BOUNDARY-START(68720001137),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786545
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateAsync",
      "d": 524401,
      "h": 68720001137,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(68720001137)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491697),
    {
      "t": 2228263,
      "n": "_requiredAttribute",
      "d": 524401,
      "h": 4295491697,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491697)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475360881),
    {
      "p": [
        {
          "n": "parameterType",
          "p": 188547073
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "displayName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524401,
      "h": 21475360881,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21475360881)
  ],
  "h": 524401
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.MEV.IValidatableInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.ValidatableParameterInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}ValidatableParameterInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524401)
        
        

        //--TRIMMABLE-BOUNDARY-START(589937)
        $asm.$cls(`$mev.MEV.ValidatablePropertyInfo`, ($self) => class ValidatablePropertyInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557233)
            /*RequiredAttribute?*/ _requiredAttribute = null;
            //--TRIMMABLE-BOUNDARY-END(4295557233)
            
            //--TRIMMABLE-BOUNDARY-START(25770393713)
            $ctor$1(/*Type*/ declaringType, /*Type*/ propertyType, /*string*/ name, /*string*/ displayName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393713);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DeclaringType = declaringType;
                    this.PropertyType = propertyType;
                    this.Name = name;
                    this.DisplayName = displayName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393713)
            
            //--TRIMMABLE-BOUNDARY-START(30065361009)
            /*Type*/ DeclaringType = null;
            //--TRIMMABLE-BOUNDARY-END(30065361009)
            
            //--TRIMMABLE-BOUNDARY-START(81604968561)
            /*Type*/ PropertyType = null;
            //--TRIMMABLE-BOUNDARY-END(81604968561)
            
            //--TRIMMABLE-BOUNDARY-START(77310001265)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(77310001265)
            
            //--TRIMMABLE-BOUNDARY-START(34360328305)
            /*string*/ DisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(34360328305)
            
            //--TRIMMABLE-BOUNDARY-START(85899935857)
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899935857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let property = $.$firstOf(this.DeclaringType.GetProperty$6(this.Name), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Property '${$.$strNN(this.Name)}' not found on type '${$.$strNN(this.DeclaringType.Name)}'.`) });
                    /*var*/ let propertyValue = property.GetValue$2(value);
                    /*var*/ let validationAttributes = this.GetValidationAttributes();
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    if ($.$$.S.String.IsNullOrEmpty(originalPrefix))
                    {
                        context.CurrentValidationPath = this.Name;
                    }
                    else 
                    {
                        context.CurrentValidationPath = `${$.$strNN(originalPrefix)}.${$.$strNN(this.Name)}`;
                    }
                    context.ValidationContext.DisplayName = this.DisplayName;
                    context.ValidationContext.MemberName = this.Name;
                    if (!(this._requiredAttribute === null) || $.$mev.MEV.TypeExtensions.TryGetRequiredAttribute(validationAttributes, $.$ref(() => this._requiredAttribute, ($v) => this._requiredAttribute = $v, $.$sca.SCD.RequiredAttribute)))
                    {
                        /*var*/ let result = this._requiredAttribute.GetValidationResult(propertyValue, context.ValidationContext);
                        if (!(result === null) && result !== $.$sca.SCD.ValidationResult.Success && !(result.ErrorMessage === null))
                        {
                            context.AddValidationError(this.Name, context.CurrentValidationPath, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ result.ErrorMessage ], null, null), value);
                            context.CurrentValidationPath = originalPrefix;
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                    }
                    ValidateValue.call(this, propertyValue, this.Name, context.CurrentValidationPath, validationAttributes, value);
                    if (context.CurrentDepth >= context.ValidationOptions.MaxDepth)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$strNN($.$strNN(`Maximum validation depth of ${$.$strNN(context.ValidationOptions.MaxDepth)} exceeded at '${$.$strNN(context.CurrentValidationPath)}' in '${$.$strNN(this.DeclaringType.Name)}.${$.$strNN(this.Name)}'. `) + "This is likely caused by a circular reference in the object graph. ") + "Consider increasing the MaxDepth in ValidationOptions if deeper validation is required.");
                    }
                    context.CurrentDepth++;
                    try
                    {
                        let enumerable;
                        if ($.$mev.MEV.TypeExtensions.IsEnumerable(this.PropertyType) && $.$is(propertyValue, $.$$.SC$1.IEnumerable, { set $v($v){ enumerable = $v; } }))
                        {
                            /*var*/ let index = 0;
                            /*var*/ let currentPrefix = context.CurrentValidationPath;
                            let $en2 = enumerable.SC$1$IEnumerable$GetEnumerator();
                            while ($en2.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en2.SC$1$IEnumerator$Current;
                                {
                                    context.CurrentValidationPath = `${$.$strNN(currentPrefix)}[${$.$strNN(index)}]`;
                                    if (item !== null)
                                    {
                                        /*var*/ let validatableType;
                                        /*var*/ let itemType = $.$$.S.Object.GetType.call(item);
                                        if (context.ValidationOptions.TryGetValidatableTypeInfo(itemType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.MEV.IValidatableInfo)))
                                        {
                                            let $t4, $r4;
                                            ($t4 = validatableType.MEV$IValidatableInfo$ValidateAsync(item, context, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                        }
                                    }
                                    index++;
                                }
                            }
                            context.CurrentValidationPath = currentPrefix;
                        }
                        else if (propertyValue !== null)
                        {
                            /*var*/ let validatableType;
                            /*var*/ let valueType = $.$$.S.Object.GetType.call(propertyValue);
                            if (context.ValidationOptions.TryGetValidatableTypeInfo(valueType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.MEV.IValidatableInfo)))
                            {
                                let $t6, $r6;
                                ($t6 = validatableType.MEV$IValidatableInfo$ValidateAsync(propertyValue, context, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                            }
                        }
                    }
                    finally
                    {
                        {
                            context.CurrentDepth--;
                            context.CurrentValidationPath = originalPrefix;
                        }
                    }
                    /*void*/  function ValidateValue(/*object?*/ val, /*string*/ name, /*string*/ errorPrefix, /*ValidationAttribute[]*/ validationAttributes, /*object?*/ container)
                    {
                        for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                        {
                            /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                            try
                            {
                                /*var*/ let result = attribute.GetValidationResult(val, context.ValidationContext);
                                if (!(result === null) && result !== $.$sca.SCD.ValidationResult.Success && !(result.ErrorMessage === null))
                                {
                                    /*var*/ let key = $.$$.S.String.TrimStart$1.call(errorPrefix, /*.*/ 46);
                                    context.AddOrExtendValidationErrors(name, key, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ result.ErrorMessage ], null, null), container);
                                }
                            }
                            catch(ex)
                            {
                                /*var*/ let key = $.$$.S.String.TrimStart$1.call(errorPrefix, /*.*/ 46);
                                context.AddOrExtendValidationErrors(name, key, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ ex.Message ], null, null), container);
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899935857)
            
            //--TRIMMABLE-BOUNDARY-START(4295098481)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            MEV$IValidatableInfo$ValidateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098481)
            
            static $h = 589937;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065361009),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262897,
        "f": 50331656
      },
      "n": "DeclaringType",
      "d": 589937,
      "h": 30065361009,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(30065361009),
//--TRIMMABLE-BOUNDARY-START(81604968561),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066673,
        "f": 50331656
      },
      "n": "PropertyType",
      "d": 589937,
      "h": 81604968561,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(81604968561),
//--TRIMMABLE-BOUNDARY-START(77310001265),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132081,
        "f": 50331656
      },
      "n": "Name",
      "d": 589937,
      "h": 77310001265,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(77310001265),
//--TRIMMABLE-BOUNDARY-START(34360328305),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197489,
        "f": 50331656
      },
      "n": "DisplayName",
      "d": 589937,
      "h": 34360328305,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(34360328305)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015033969),
    {
      "r": $.$typeArray($.$sca.SCD.ValidationAttribute).$h,
      "n": "GetValidationAttributes",
      "d": 589937,
      "h": 73015033969,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(73015033969),
//--TRIMMABLE-BOUNDARY-START(85899935857),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786545
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateAsync",
      "d": 589937,
      "h": 85899935857,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(85899935857)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557233),
    {
      "t": 2228263,
      "n": "_requiredAttribute",
      "d": 589937,
      "h": 4295557233,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557233)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770393713),
    {
      "p": [
        {
          "n": "declaringType",
          "p": 188547073
        },
        {
          "n": "propertyType",
          "p": 188547073
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "displayName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589937,
      "h": 25770393713,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25770393713)
  ],
  "h": 589937
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.MEV.IValidatableInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.ValidatablePropertyInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}ValidatablePropertyInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589937)
        
        

        //--TRIMMABLE-BOUNDARY-START(721009)
        $asm.$cls(`$mev.MEV.ValidatableTypeInfo`, ($self) => class ValidatableTypeInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688305)
            /*int*/ _membersCount = 0;
            //--TRIMMABLE-BOUNDARY-END(4295688305)
            
            //--TRIMMABLE-BOUNDARY-START(8590655601)
            /*List<Type>*/ _superTypes = null;
            //--TRIMMABLE-BOUNDARY-END(8590655601)
            
            //--TRIMMABLE-BOUNDARY-START(21475557489)
            $ctor$1(/*Type*/ type, /*IReadOnlyList<ValidatablePropertyInfo>*/ members)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Type = type;
                    this.Members = members;
                    this._membersCount = members.SCG$IReadOnlyCollection$$$Count;
                    this._superTypes = $.$mev.MEV.TypeExtensions.GetAllImplementedTypes(type);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557489)
            
            //--TRIMMABLE-BOUNDARY-START(55835295857)
            /*Type*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(55835295857)
            
            //--TRIMMABLE-BOUNDARY-START(51540328561)
            /*IReadOnlyList<ValidatablePropertyInfo>*/ Members = null;
            //--TRIMMABLE-BOUNDARY-END(51540328561)
            
            //--TRIMMABLE-BOUNDARY-START(60130263153)
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130263153);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (value === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    if (context.CurrentDepth >= context.ValidationOptions.MaxDepth)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$strNN($.$strNN(`Maximum validation depth of ${$.$strNN(context.ValidationOptions.MaxDepth)} exceeded at '${$.$strNN(context.CurrentValidationPath)}' in '${$.$strNN(this.Type.Name)}'. `) + "This is likely caused by a circular reference in the object graph. ") + "Consider increasing the MaxDepth in ValidationOptions if deeper validation is required.");
                    }
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    /*var*/ let originalErrorCount = (context.ValidationErrors?.Count ?? null) ?? 0;
                    try
                    {
                        let $t1, $r1;
                        ($t1 = this.ValidateMembersAsync(value, context, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        /*var*/ let actualType = $.$$.S.Object.GetType.call(value);
                        let $en2 = this.GetSuperTypeInfos(actualType, context).SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let superTypeInfo = $en2.SCG$IEnumerator$$$Current;
                            {
                                let $t3, $r3;
                                ($t3 = superTypeInfo.ValidateMembersAsync(value, context, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            }
                        }
                        if (!(context.ValidationErrors === null) && context.ValidationErrors.Count > originalErrorCount)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        this.ValidateTypeAttributes(value, context);
                        if (!(context.ValidationErrors === null) && context.ValidationErrors.Count > originalErrorCount)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        this.ValidateValidatableObjectInterface(value, context);
                    }
                    finally
                    {
                        {
                            context.CurrentValidationPath = originalPrefix;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60130263153)
            
            //--TRIMMABLE-BOUNDARY-START(64425230449)
            /*Task *//*async*/  ValidateMembersAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425230449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    for(/*var*/ let i = 0; i < this._membersCount; i++)
                    {
                        try
                        {
                            let $t4, $r4;
                            ($t4 = this.Members.SCG$IReadOnlyList$$$get_Item(i).ValidateAsync(value, context, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        }
                        finally
                        {
                            {
                                context.CurrentValidationPath = originalPrefix;
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425230449)
            
            //--TRIMMABLE-BOUNDARY-START(68720197745)
            /*void */ ValidateTypeAttributes(/*object?*/ value, /*ValidateContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let validationAttributes = this.GetValidationAttributes();
                /*var*/ let errorPrefix = context.CurrentValidationPath;
                for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                {
                    /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                    /*var*/ let result = attribute.GetValidationResult(value, context.ValidationContext);
                    if (!(result === null) && result !== $.$sca.SCD.ValidationResult.Success && !(result.ErrorMessage === null))
                    {
                        let $en5 = result.MemberNames.SCG$IEnumerable$$$GetEnumerator();
                        while ($en5.SC$1$IEnumerator$MoveNext())
                        {
                            let memberName = $en5.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let key = $.$$.S.String.IsNullOrEmpty(errorPrefix) ? memberName : `${$.$strNN(errorPrefix)}.${$.$strNN(memberName)}`;
                                context.AddOrExtendValidationError(memberName, key, result.ErrorMessage, value);
                            }
                        }
                        if (!$.$sl.SL.Enumerable.Any$1($.$$.S.String, result.MemberNames))
                        {
                            context.AddOrExtendValidationError($.$$.S.String.Empty, errorPrefix, result.ErrorMessage, value);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720197745)
            
            //--TRIMMABLE-BOUNDARY-START(73015165041)
            /*void */ ValidateValidatableObjectInterface(/*object?*/ value, /*ValidateContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let validatable;
                if ($.$mev.MEV.TypeExtensions.ImplementsInterface(this.Type, $.$sca.SCD.IValidatableObject.$type) && $.$is(value, $.$sca.SCD.IValidatableObject, { set $v($v){ validatable = $v; } }))
                {
                    /*var*/ let originalDisplayName = context.ValidationContext.DisplayName;
                    /*var*/ let originalMemberName = context.ValidationContext.MemberName;
                    /*var*/ let errorPrefix = context.CurrentValidationPath;
                    context.ValidationContext.DisplayName = this.Type.Name;
                    context.ValidationContext.MemberName = null;
                    /*var*/ let validationResults = validatable.SCD$IValidatableObject$Validate(context.ValidationContext);
                    let $en6 = validationResults.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let validationResult = $en6.SCG$IEnumerator$$$Current;
                        {
                            if (validationResult !== $.$sca.SCD.ValidationResult.Success && !(validationResult.ErrorMessage === null))
                            {
                                let $en7 = validationResult.MemberNames.SCG$IEnumerable$$$GetEnumerator();
                                while ($en7.SC$1$IEnumerator$MoveNext())
                                {
                                    let memberName = $en7.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let key = $.$$.S.String.IsNullOrEmpty(errorPrefix) ? memberName : `${$.$strNN(errorPrefix)}.${$.$strNN(memberName)}`;
                                        context.AddOrExtendValidationError(memberName, key, validationResult.ErrorMessage, value);
                                    }
                                }
                                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.String, validationResult.MemberNames))
                                {
                                    context.AddOrExtendValidationError($.$$.S.String.Empty, $.$$.S.String.Empty, validationResult.ErrorMessage, value);
                                }
                            }
                        }
                    }
                    context.ValidationContext.DisplayName = originalDisplayName;
                    context.ValidationContext.MemberName = originalMemberName;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015165041)
            
            //--TRIMMABLE-BOUNDARY-START(42950393969)
            /*IEnumerable<ValidatableTypeInfo> */ GetSuperTypeInfos(/*Type*/ actualType, /*ValidateContext*/ context)
            {
                return new ($.$$.N.YieldToIterator$$($.$mev.MEV.ValidatableTypeInfo))().$ctor$1(function*()
                {
                    let $en8 = $.$sl.SL.Enumerable.Where($.$$.S.Type, this._superTypes, new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.IsAssignableFrom(actualType);
                    }, $EUYeOd ??= {"r":262145,"p":[{"n":"t","p":188547073}],"n":"","d":721009,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let superType = $en8.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let found;
                            let superTypeInfo;
                            if (context.ValidationOptions.TryGetValidatableTypeInfo(superType, $.$ref(() => found, ($v) => found = $v, $.$mev.MEV.IValidatableInfo)) && $.$is(found, $.$mev.MEV.ValidatableTypeInfo, { set $v($v){ superTypeInfo = $v; } }))
                            {
                                yield superTypeInfo;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(42950393969)
            
            //--TRIMMABLE-BOUNDARY-START(4295098481)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            MEV$IValidatableInfo$ValidateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098481)
            
            static $h = 721009;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835295857),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426673,
        "f": 50331656
      },
      "n": "Type",
      "d": 721009,
      "h": 55835295857,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55835295857),
//--TRIMMABLE-BOUNDARY-START(51540328561),
    {
      "p": $.$$.SCG.IReadOnlyList$$($.$mev.MEV.ValidatablePropertyInfo).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065492081,
        "f": 50331656
      },
      "n": "Members",
      "d": 721009,
      "h": 51540328561,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51540328561)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245361265),
    {
      "r": $.$typeArray($.$sca.SCD.ValidationAttribute).$h,
      "n": "GetValidationAttributes",
      "d": 721009,
      "h": 47245361265,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(47245361265),
//--TRIMMABLE-BOUNDARY-START(60130263153),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786545
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateAsync",
      "d": 721009,
      "h": 60130263153,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(60130263153),
//--TRIMMABLE-BOUNDARY-START(64425230449),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786545
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateMembersAsync",
      "d": 721009,
      "h": 64425230449,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(64425230449),
//--TRIMMABLE-BOUNDARY-START(68720197745),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786545
        }
      ],
      "n": "ValidateTypeAttributes",
      "d": 721009,
      "h": 68720197745,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720197745),
//--TRIMMABLE-BOUNDARY-START(73015165041),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786545
        }
      ],
      "n": "ValidateValidatableObjectInterface",
      "d": 721009,
      "h": 73015165041,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015165041),
//--TRIMMABLE-BOUNDARY-START(42950393969),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mev.MEV.ValidatableTypeInfo).$h,
      "p": [
        {
          "n": "actualType",
          "p": 188547073
        },
        {
          "n": "context",
          "p": 786545
        }
      ],
      "n": "GetSuperTypeInfos",
      "d": 721009,
      "h": 42950393969,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393969)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688305),
    {
      "t": 655361,
      "n": "_membersCount",
      "d": 721009,
      "h": 4295688305,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688305),
//--TRIMMABLE-BOUNDARY-START(8590655601),
    {
      "t": $.$$.SCG.List$$($.$$.S.Type).$h,
      "n": "_superTypes",
      "d": 721009,
      "h": 8590655601,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655601)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557489),
    {
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "members",
          "p": $.$$.SCG.IReadOnlyList$$($.$mev.MEV.ValidatablePropertyInfo).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721009,
      "h": 21475557489,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21475557489)
  ],
  "h": 721009
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.MEV.IValidatableInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.ValidatableTypeInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}ValidatableTypeInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721009)
        
        

        //--TRIMMABLE-BOUNDARY-START(917617)
        $asm.$cls(`$mev.MEV.ValidationOptions`, ($self) => class ValidationOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655623281)
            /*IList<IValidatableInfoResolver>*/ Resolvers = null;
            //--TRIMMABLE-BOUNDARY-END(38655623281)
            
            //--TRIMMABLE-BOUNDARY-START(34360655985)
            /*int*/ MaxDepth = 0;
            //--TRIMMABLE-BOUNDARY-END(34360655985)
            
            //--TRIMMABLE-BOUNDARY-START(55835492465)
            /*bool */ TryGetValidatableTypeInfo(/*Type*/ type, /*out IValidatableInfo?*/ validatableTypeInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835492465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = this.Resolvers.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let resolver = $en1.SCG$IEnumerator$$$Current;
                    {
                        if (resolver.MEV$IValidatableInfoResolver$TryGetValidatableTypeInfo(type, validatableTypeInfo))
                        {
                            return true;
                        }
                    }
                }
                validatableTypeInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(55835492465)
            
            //--TRIMMABLE-BOUNDARY-START(51540525169)
            /*bool */ TryGetValidatableParameterInfo(/*ParameterInfo*/ parameterInfo, /*out IValidatableInfo?*/ validatableInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en3 = this.Resolvers.SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let resolver = $en3.SCG$IEnumerator$$$Current;
                    {
                        if (resolver.MEV$IValidatableInfoResolver$TryGetValidatableParameterInfo(parameterInfo, validatableInfo))
                        {
                            return true;
                        }
                    }
                }
                validatableInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525169)
            
            //--TRIMMABLE-BOUNDARY-START(12885819505)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819505)
            
            //--TRIMMABLE-BOUNDARY-START(12885819505)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885819505)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655623281)
                this.Resolvers = (() =>
                {
                    let $t5 = new ($.$$.SCG.List$$($.$mev.MEV.IValidatableInfoResolver))().$ctor$1();
                    return $t5;
                })();
                //--TRIMMABLE-BOUNDARY-END(38655623281)
                
                //--TRIMMABLE-BOUNDARY-START(34360655985)
                this.MaxDepth = 32;
                //--TRIMMABLE-BOUNDARY-END(34360655985)
                
            }
            static $h = 917617;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655623281),
    {
      "p": $.$$.SCG.IList$$($.$mev.MEV.IValidatableInfoResolver).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065688689,
        "f": 50331649
      },
      "n": "Resolvers",
      "d": 917617,
      "h": 38655623281,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655623281),
//--TRIMMABLE-BOUNDARY-START(34360655985),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475754097,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245557873,
        "f": 83886081
      },
      "n": "MaxDepth",
      "d": 917617,
      "h": 34360655985,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360655985)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835492465),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "validatableTypeInfo",
          "p": 131185,
          "f": 2
        }
      ],
      "n": "TryGetValidatableTypeInfo",
      "d": 917617,
      "h": 55835492465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835492465),
//--TRIMMABLE-BOUNDARY-START(51540525169),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameterInfo",
          "p": 119078913
        },
        {
          "n": "validatableInfo",
          "p": 131185,
          "f": 2
        }
      ],
      "n": "TryGetValidatableParameterInfo",
      "d": 917617,
      "h": 51540525169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540525169)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819505),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917617,
      "h": 12885819505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819505)
  ],
  "h": 917617
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.ValidationOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}ValidationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917617)
        
        

        //--TRIMMABLE-BOUNDARY-START(458865)
        $asm.$cls(`$mev.MEV.TypeExtensions`, ($self) => class TypeExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885360753)
            static /*bool */ IsEnumerable(/*this Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsGenericType && (type.GetGenericTypeDefinition() === $.$$.SCG.IEnumerable$$().$type || type.GetGenericTypeDefinition() === $.$$.SCG.ICollection$$().$type || type.GetGenericTypeDefinition() === $.$$.SCG.List$$().$type || type.GetGenericTypeDefinition() === $.$$.SCG.IList$$().$type))
                {
                    return true;
                }
                if (type.IsArray)
                {
                    return true;
                }
                if ($.$$.SC$1.IEnumerable.$type.IsAssignableFrom(type) && type !== $.$$.S.String.$type)
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360753)
            
            //--TRIMMABLE-BOUNDARY-START(17180328049)
            static /*bool */ IsNullable(/*this Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsValueType)
                {
                    return false;
                }
                if (type.IsGenericType && type.GetGenericTypeDefinition() === $.$$.S.Nullable$$().$type)
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328049)
            
            //--TRIMMABLE-BOUNDARY-START(21475295345)
            static /*bool */ TryGetRequiredAttribute(/*this ValidationAttribute[]*/ attributes, /*out RequiredAttribute?*/ requiredAttribute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = attributes;
                while ($i1 < $arr1.length)
                {
                    let attribute = $arr1[$i1++];
                    let requiredAttr;
                    if ($.$is(attribute, $.$sca.SCD.RequiredAttribute, { set $v($v){ requiredAttr = $v; } }))
                    {
                        requiredAttribute.$v = requiredAttr;
                        return true;
                    }
                }
                requiredAttribute.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295345)
            
            //--TRIMMABLE-BOUNDARY-START(4295426161)
            static /*List<Type> */ GetAllImplementedTypes(/*this Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*var*/ let implementedTypes = new ($.$$.SCG.List$$($.$$.S.Type))().$ctor$1();
                let $i2 = 0;
                let $arr2 = type.GetInterfaces();
                while ($i2 < $arr2.length)
                {
                    let interfaceType = $arr2[$i2++];
                    implementedTypes.Add(interfaceType);
                }
                /*var*/ let baseType = type.BaseType;
                while(baseType !== null && baseType !== $.$$.S.Object.$type)
                {
                    implementedTypes.Add(baseType);
                    baseType = baseType.BaseType;
                }
                return implementedTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426161)
            
            //--TRIMMABLE-BOUNDARY-START(8590393457)
            static /*bool */ ImplementsInterface(/*this Type*/ type, /*Type*/ interfaceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(interfaceType, "interfaceType");
                if (!interfaceType.IsInterface)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13(`Type ${$.$strNN(interfaceType.FullName)} is not an interface.`, "interfaceType");
                }
                return interfaceType.IsAssignableFrom(type);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393457)
            
            static $h = 458865;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360753),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "IsEnumerable",
      "d": 458865,
      "h": 12885360753,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885360753),
//--TRIMMABLE-BOUNDARY-START(17180328049),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "IsNullable",
      "d": 458865,
      "h": 17180328049,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180328049),
//--TRIMMABLE-BOUNDARY-START(21475295345),
    {
      "r": 262145,
      "p": [
        {
          "n": "attributes",
          "p": $.$typeArray($.$sca.SCD.ValidationAttribute).$h
        },
        {
          "n": "requiredAttribute",
          "p": 2228263,
          "f": 2
        }
      ],
      "n": "TryGetRequiredAttribute",
      "d": 458865,
      "h": 21475295345,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475295345),
//--TRIMMABLE-BOUNDARY-START(4295426161),
    {
      "r": $.$$.SCG.List$$($.$$.S.Type).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetAllImplementedTypes",
      "d": 458865,
      "h": 4295426161,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295426161),
//--TRIMMABLE-BOUNDARY-START(8590393457),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "interfaceType",
          "p": 188547073
        }
      ],
      "n": "ImplementsInterface",
      "d": 458865,
      "h": 8590393457,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590393457)
  ],
  "h": 458865
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.TypeExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}TypeExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458865)
        
        

        //--TRIMMABLE-BOUNDARY-START(786545)
        $asm.$cls(`$mev.MEV.ValidateContext`, ($self) => class ValidateContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(158914576497)
            /*ValidationContext*/ ValidationContext = null;
            //--TRIMMABLE-BOUNDARY-END(158914576497)
            
            //--TRIMMABLE-BOUNDARY-START(55835361393)
            /*string*/ CurrentValidationPath = null;
            //--TRIMMABLE-BOUNDARY-END(55835361393)
            
            //--TRIMMABLE-BOUNDARY-START(167504511089)
            /*ValidationOptions*/ ValidationOptions = null;
            //--TRIMMABLE-BOUNDARY-END(167504511089)
            
            //--TRIMMABLE-BOUNDARY-START(163209543793)
            /*Dictionary<string, string[]>?*/ ValidationErrors = null;
            //--TRIMMABLE-BOUNDARY-END(163209543793)
            
            //--TRIMMABLE-BOUNDARY-START(51540394097)
            /*int*/ CurrentDepth = 0;
            //--TRIMMABLE-BOUNDARY-END(51540394097)
            
            //--TRIMMABLE-BOUNDARY-START(103080001649)
            /*Action<ValidationErrorContext>?*/ OnValidationError = null;
            //--TRIMMABLE-BOUNDARY-END(103080001649)
            
            //--TRIMMABLE-BOUNDARY-START(103080001649)
            //--TRIMMABLE-BOUNDARY-START(34360524913)
            add_OnValidationError(/*Action<ValidationErrorContext>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationError = $.$$.S.Delegate.Combine$2(this.OnValidationError, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360524913)
            
            //--TRIMMABLE-BOUNDARY-START(111669936241)
            remove_OnValidationError(/*Action<ValidationErrorContext>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669936241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationError = $.$$.S.Delegate.Remove(this.OnValidationError, value);
            }
            //--TRIMMABLE-BOUNDARY-END(111669936241)
            
            //--TRIMMABLE-BOUNDARY-END(103080001649)
            
            //--TRIMMABLE-BOUNDARY-START(47245426801)
            /*void */ AddValidationError(/*string*/ propertyName, /*string*/ key, /*string[]*/ error, /*object?*/ container)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidationErrors ??= (() =>
                {
                    let $t1 = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.String)))().$ctor$1();
                    return $t1;
                })();
                this.ValidationErrors.set_Item(key, error);
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.MEV.ValidationErrorContext()
                    const $t2 = $.$mev.MEV.ValidationErrorContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Name = propertyName;
                    $i2.Path = key;
                    $i2.Errors = error;
                    $i2.Container = container;
                    return $i2;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(47245426801)
            
            //--TRIMMABLE-BOUNDARY-START(42950459505)
            /*void */ AddOrExtendValidationErrors(/*string*/ propertyName, /*string*/ key, /*string[]*/ errors, /*object?*/ container)
            {
                /*var*/ let existingErrors;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidationErrors ??= (() =>
                {
                    let $t3 = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.String)))().$ctor$1();
                    return $t3;
                })();
                if (this.ValidationErrors.TryGetValue(key, $.$ref(() => existingErrors, ($v) => existingErrors = $v, $.$typeArray($.$$.S.String))))
                {
                    /*var*/ let newErrors = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [((existingErrors.length + errors.length) | 0)], null);
                    existingErrors.CopyTo(newErrors, 0);
                    errors.CopyTo(newErrors, existingErrors.length);
                    this.ValidationErrors.set_Item(key, newErrors);
                }
                else 
                {
                    this.ValidationErrors.set_Item(key, errors);
                }
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.MEV.ValidationErrorContext()
                    const $t5 = $.$mev.MEV.ValidationErrorContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Name = propertyName;
                    $i5.Path = key;
                    $i5.Errors = errors;
                    $i5.Container = container;
                    return $i5;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(42950459505)
            
            //--TRIMMABLE-BOUNDARY-START(38655492209)
            /*void */ AddOrExtendValidationError(/*string*/ name, /*string*/ key, /*string*/ error, /*object?*/ container)
            {
                /*var*/ let existingErrors;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidationErrors ??= (() =>
                {
                    let $t6 = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.String)))().$ctor$1();
                    return $t6;
                })();
                if (this.ValidationErrors.TryGetValue(key, $.$ref(() => existingErrors, ($v) => existingErrors = $v, $.$typeArray($.$$.S.String))) && !$.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(existingErrors), error))
                {
                    this.ValidationErrors.set_Item(key, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ ...existingErrors, error ], null, null));
                }
                else 
                {
                    this.ValidationErrors.set_Item(key, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ error ], null, null));
                }
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.MEV.ValidationErrorContext()
                    const $t8 = $.$mev.MEV.ValidationErrorContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Name = name;
                    $i8.Path = key;
                    $i8.Errors = (() =>
                    {
                        let $t9 = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                        $t9.Add(error);
                        return $t9;
                    })();
                    $i8.Container = container;
                    return $i8;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(38655492209)
            
            //--TRIMMABLE-BOUNDARY-START(25770590321)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590321)
            
            //--TRIMMABLE-BOUNDARY-START(25770590321)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770590321)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55835361393)
                this.CurrentValidationPath = $.$$.S.String.Empty;
                //--TRIMMABLE-BOUNDARY-END(55835361393)
                
            }
            static $h = 786545;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914576497),
    {
      "p": 3538983,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605165169,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439740017,
        "f": 83886081
      },
      "n": "ValidationContext",
      "d": 786545,
      "h": 158914576497,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914576497),
//--TRIMMABLE-BOUNDARY-START(55835361393),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015230577,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849805425,
        "f": 83886081
      },
      "n": "CurrentValidationPath",
      "d": 786545,
      "h": 55835361393,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835361393),
//--TRIMMABLE-BOUNDARY-START(167504511089),
    {
      "p": 917617,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785034353,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619609201,
        "f": 83886081
      },
      "n": "ValidationOptions",
      "d": 786545,
      "h": 167504511089,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504511089),
//--TRIMMABLE-BOUNDARY-START(163209543793),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195099761,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029674609,
        "f": 83886081
      },
      "n": "ValidationErrors",
      "d": 786545,
      "h": 163209543793,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209543793),
//--TRIMMABLE-BOUNDARY-START(51540394097),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425295985,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259870833,
        "f": 83886081
      },
      "n": "CurrentDepth",
      "d": 786545,
      "h": 51540394097,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540394097)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245426801),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "error",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "container",
          "p": 131073
        }
      ],
      "n": "AddValidationError",
      "d": 786545,
      "h": 47245426801,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47245426801),
//--TRIMMABLE-BOUNDARY-START(42950459505),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "errors",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "container",
          "p": 131073
        }
      ],
      "n": "AddOrExtendValidationErrors",
      "d": 786545,
      "h": 42950459505,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42950459505),
//--TRIMMABLE-BOUNDARY-START(38655492209),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "error",
          "p": 1310721
        },
        {
          "n": "container",
          "p": 131073
        }
      ],
      "n": "AddOrExtendValidationError",
      "d": 786545,
      "h": 38655492209,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38655492209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590321),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786545,
      "h": 25770590321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590321)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(103080001649),
    {
      "e": $.$$.S.Action$$($.$mev.MEV.ValidationErrorContext).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.Action$$($.$mev.MEV.ValidationErrorContext).$h
          }
        ],
        "n": "add_OnValidationError",
        "d": 786545,
        "h": 34360524913,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.Action$$($.$mev.MEV.ValidationErrorContext).$h
          }
        ],
        "n": "remove_OnValidationError",
        "d": 786545,
        "h": 111669936241,
        "f": 285212673
      },
      "n": "OnValidationError",
      "d": 786545,
      "h": 103080001649,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(103080001649)
  ],
  "h": 786545
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.ValidateContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}ValidateContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786545)
        
        

        //--TRIMMABLE-BOUNDARY-START(65649)
        $asm.$cls(`$mev.MED.ValidationServiceCollectionExtensions`, ($self) => class ValidationServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295032945)
            static /*IServiceCollection */ AddValidation(/*this IServiceCollection*/ services, /*Action<ValidationOptions>?*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$mev.MEV.ValidationOptions, services, new ($.$$.S.Action$$($.$mev.MEV.ValidationOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    if (!(configureOptions === null))
                    {
                        configureOptions.Invoke(options);
                    }
                    options.Resolvers.SCG$ICollection$$$Add(new $.$mev.MEV.RuntimeValidatableParameterInfoResolver().$ctor$1());
                }, $pgBhve ??= {"r":65537,"p":[{"n":"options","p":917617}],"n":"","d":65649,"h":0,"f":17825794}));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032945)
            
            static $h = 65649;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032945),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": $.$$.S.Action$$($.$mev.MEV.ValidationOptions).$h,
          "f": 65
        }
      ],
      "n": "AddValidation",
      "d": 65649,
      "h": 4295032945,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032945)
  ],
  "h": 65649
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ValidationServiceCollectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ValidationServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65649)
        
        

        //--TRIMMABLE-BOUNDARY-START(262257)
        $asm.$cls(`$mev.MEV.RuntimeValidatableParameterInfoResolver`, ($self) => class RuntimeValidatableParameterInfoResolver extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475098737)
            /*bool */ TryGetValidatableTypeInfo(/*Type*/ type, /*out IValidatableInfo?*/ validatableInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                validatableInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098737)
            
            //--TRIMMABLE-BOUNDARY-START(17180131441)
            /*bool */ TryGetValidatableParameterInfo(/*ParameterInfo*/ parameterInfo, /*out IValidatableInfo?*/ validatableInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (parameterInfo.Name === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Encountered a parameter of type '${$.$strNN(parameterInfo.ParameterType.ToString())}' without a name. Parameters must have a name.`);
                }
                if ($.$$.SR.CustomAttributeExtensions.GetCustomAttribute$11($.$mev.MEV.SkipValidationAttribute, parameterInfo) !== null || $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$8($.$mev.MEV.SkipValidationAttribute, parameterInfo.ParameterType) !== null)
                {
                    validatableInfo.$v = null;
                    return false;
                }
                /*var*/ let validationAttributes = $.$sl.SL.Enumerable.ToArray($.$sca.SCD.ValidationAttribute, $.$$.SR.CustomAttributeExtensions.GetCustomAttributes$17($.$sca.SCD.ValidationAttribute, parameterInfo));
                if (validationAttributes.length === 0 && !$.$mev.MEV.RuntimeValidatableParameterInfoResolver.IsComplexType(parameterInfo.ParameterType))
                {
                    validatableInfo.$v = null;
                    return false;
                }
                validatableInfo.$v = new $.$mev.MEV.RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo().$ctor$2(parameterInfo.ParameterType, parameterInfo.Name, $.$mev.MEV.RuntimeValidatableParameterInfoResolver.GetDisplayName(parameterInfo), validationAttributes);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131441)
            
            //--TRIMMABLE-BOUNDARY-START(8590196849)
            static /*string */ GetDisplayName(/*ParameterInfo*/ parameterInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let displayAttribute = $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$11($.$sca.SCD.DisplayAttribute, parameterInfo);
                if (displayAttribute !== null)
                {
                    return displayAttribute.Name ?? parameterInfo.Name;
                }
                return parameterInfo.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196849)
            
            //--TRIMMABLE-BOUNDARY-START(327793)
            static $_RuntimeValidatableParameterInfo;
            static get RuntimeValidatableParameterInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mev.MEV.RuntimeValidatableParameterInfoResolver;
                return $cls.$_RuntimeValidatableParameterInfo ??= $asm.$ncls(`$mev.MEV.RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo`, ($self) => class RuntimeValidatableParameterInfo extends $.$mev.MEV.ValidatableParameterInfo
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229681)
                    /*ValidationAttribute[] */ GetValidationAttributes()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885229681);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._validationAttributes;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885229681)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295295089)
                    /*ValidationAttribute[]*/ _validationAttributes = null;
                    //--TRIMMABLE-BOUNDARY-END(4295295089)
                    
                    //Begin primary constructor
                    /*Type*/ parameterType = null;
                    /*string*/ name = null;
                    /*string*/ displayName = null;
                    /*ValidationAttribute[]*/ validationAttributes = null;
                    $ctor$2(/*Type*/parameterType, /*string*/name, /*string*/displayName, /*ValidationAttribute[]*/validationAttributes)
                    {
                        this.parameterType = parameterType;
                        this.name = name;
                        this.displayName = displayName;
                        this.validationAttributes = validationAttributes;
                        super.$ctor$1(this.parameterType, this.name, this.displayName);
                        //--TRIMMABLE-BOUNDARY-START(4295295089)
                        //depends on primary constructor parameter
                        this._validationAttributes = this.validationAttributes;
                        //--TRIMMABLE-BOUNDARY-END(4295295089)
                        
                        return this
                    }
                    //End primary constructor
                    static $h = 327793;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$mev.MEV.ValidatableParameterInfo; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229681),
    {
      "r": $.$typeArray($.$sca.SCD.ValidationAttribute).$h,
      "n": "GetValidationAttributes",
      "d": 327793,
      "h": 12885229681,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885229681)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295089),
    {
      "t": $.$typeArray($.$sca.SCD.ValidationAttribute).$h,
      "n": "_validationAttributes",
      "d": 327793,
      "h": 4295295089,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295089)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262385),
    {
      "p": [
        {
          "n": "parameterType",
          "p": 188547073
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "validationAttributes",
          "p": $.$typeArray($.$sca.SCD.ValidationAttribute).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327793,
      "h": 8590262385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262385)
  ],
  "d": 262257,
  "h": 327793
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mev.MEV.IValidatableInfo ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver+RuntimeValidatableParameterInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}RuntimeValidatableParameterInfoResolver${separator}RuntimeValidatableParameterInfo`; }
                }, $cls, ($v) => $cls.$_RuntimeValidatableParameterInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327793)
            
            //--TRIMMABLE-BOUNDARY-START(12885164145)
            static /*bool */ IsComplexType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsPrimitive || type.IsEnum || type === $.$$.S.String.$type || type === $.$$.S.Decimal.$type || type === $.$$.S.DateTime.$type || type === $.$$.S.DateTimeOffset.$type || type === $.$$.S.TimeOnly.$type || type === $.$$.S.DateOnly.$type || type === $.$$.S.TimeSpan.$type || type === $.$$.S.Guid.$type || type === $.$ssc.SSC.ClaimsPrincipal.$type || type === $.$$.ST$1.CancellationToken.$type || type === $.$$.SI.Stream.$type || type === $.$sipl.SIP.PipeReader.$type)
                {
                    return false;
                }
                let nullableType;
                if ($.$$.S.Nullable.GetUnderlyingType(type) !== null && ((nullableType = $.$$.S.Nullable.GetUnderlyingType(type), nullableType != null && true)))
                {
                    return $.$mev.MEV.RuntimeValidatableParameterInfoResolver.IsComplexType(nullableType);
                }
                return type.IsClass || type.IsValueType;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164145)
            
            //--TRIMMABLE-BOUNDARY-START(8590131313)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfoResolver.TryGetValidatableTypeInfo(System.Type, out Microsoft.Extensions.Validation.IValidatableInfo?)
            MEV$IValidatableInfoResolver$TryGetValidatableTypeInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValidatableTypeInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131313)
            
            //--TRIMMABLE-BOUNDARY-START(4295164017)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfoResolver.TryGetValidatableParameterInfo(System.Reflection.ParameterInfo, out Microsoft.Extensions.Validation.IValidatableInfo?)
            MEV$IValidatableInfoResolver$TryGetValidatableParameterInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValidatableParameterInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164017)
            
            //--TRIMMABLE-BOUNDARY-START(4295229553)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229553)
            
            //--TRIMMABLE-BOUNDARY-START(4295229553)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229553)
            
            static $h = 262257;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475098737),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "validatableInfo",
          "p": 131185,
          "f": 2
        }
      ],
      "n": "TryGetValidatableTypeInfo",
      "d": 262257,
      "h": 21475098737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098737),
//--TRIMMABLE-BOUNDARY-START(17180131441),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameterInfo",
          "p": 119078913
        },
        {
          "n": "validatableInfo",
          "p": 131185,
          "f": 2
        }
      ],
      "n": "TryGetValidatableParameterInfo",
      "d": 262257,
      "h": 17180131441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131441),
//--TRIMMABLE-BOUNDARY-START(8590196849),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parameterInfo",
          "p": 119078913
        }
      ],
      "n": "GetDisplayName",
      "d": 262257,
      "h": 8590196849,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590196849),
//--TRIMMABLE-BOUNDARY-START(12885164145),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "IsComplexType",
      "d": 262257,
      "h": 12885164145,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885164145)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229553),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262257,
      "h": 4295229553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229553)
  ],
  "h": 262257
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.MEV.IValidatableInfoResolver ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mev.MEV.RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}RuntimeValidatableParameterInfoResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262257)
        
        

        //--TRIMMABLE-BOUNDARY-START(393329)
        $asm.$cls(`$mev.MEV.SkipValidationAttribute`, ($self) => class SkipValidationAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295360625)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360625)
            
            //--TRIMMABLE-BOUNDARY-START(4295360625)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360625)
            
            static $h = 393329;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360625),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393329,
      "h": 4295360625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360625)
  ],
  "h": 393329,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 2180,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.SkipValidationAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}SkipValidationAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393329)
        
        

        //--TRIMMABLE-BOUNDARY-START(655473)
        $asm.$cls(`$mev.MEV.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295622769)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622769)
            
            //--TRIMMABLE-BOUNDARY-START(4295622769)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622769)
            
            static $h = 655473;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622769),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655473,
      "h": 4295622769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622769)
  ],
  "h": 655473,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655473)
        
        

        //--TRIMMABLE-BOUNDARY-START(852081)
        $asm.$str(`$mev.MEV.ValidationErrorContext`, ($self) => class ValidationErrorContext extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(73015296113)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(73015296113)
            
            //--TRIMMABLE-BOUNDARY-START(77310263409)
            /*string*/ Path = null;
            //--TRIMMABLE-BOUNDARY-END(77310263409)
            
            //--TRIMMABLE-BOUNDARY-START(30065623153)
            /*IReadOnlyList<string>*/ Errors = null;
            //--TRIMMABLE-BOUNDARY-END(30065623153)
            
            //--TRIMMABLE-BOUNDARY-START(25770655857)
            /*object?*/ Container = null;
            //--TRIMMABLE-BOUNDARY-END(25770655857)
            
            //--TRIMMABLE-BOUNDARY-START(68720328817)
            /*string */ GetDebuggerDisplay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Path)}: ${$.$strNN($.$$.S.String.Join$5(",", this.Errors))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(68720328817)
            
            //--TRIMMABLE-BOUNDARY-START(21475688561)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475688561)
            
            //--TRIMMABLE-BOUNDARY-START(21475688561)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475688561)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.Path = this.Path;
                copy.Errors = this.Errors;
                copy.Container = this.Container;
                return copy;
            }
            static $h = 852081;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015296113),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835426929,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080067185,
        "f": 83886081
      },
      "n": "Name",
      "d": 852081,
      "h": 73015296113,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015296113),
//--TRIMMABLE-BOUNDARY-START(77310263409),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425361521,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670001777,
        "f": 83886081
      },
      "n": "Path",
      "d": 852081,
      "h": 77310263409,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310263409),
//--TRIMMABLE-BOUNDARY-START(30065623153),
    {
      "p": $.$$.SCG.IReadOnlyList$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245492337,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490132593,
        "f": 83886081
      },
      "n": "Errors",
      "d": 852081,
      "h": 30065623153,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065623153),
//--TRIMMABLE-BOUNDARY-START(25770655857),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655557745,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900198001,
        "f": 83886081
      },
      "n": "Container",
      "d": 852081,
      "h": 25770655857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770655857)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720328817),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 852081,
      "h": 68720328817,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720328817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475688561),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852081,
      "h": 21475688561,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688561)
  ],
  "h": 852081,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.ValidationErrorContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}ValidationErrorContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852081)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.System.IO.Pipelines"));
})();
//--TRIMMABLE-BOUNDARY-END(113)
