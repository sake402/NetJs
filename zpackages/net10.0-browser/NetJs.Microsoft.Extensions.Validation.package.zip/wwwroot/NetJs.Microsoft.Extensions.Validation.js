
//--TRIMMABLE-BOUNDARY-START(106)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $sipl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Validation", 
    {
  "h": 106,
  "f": "Microsoft.Extensions.Validation",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "Common validation abstractions and validation infrastructure for .NET applications.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Validation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Validation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.Extensions.Validation.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131178)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.IValidatableInfo", ($self) => class IValidatableInfo
        {
            static $h = 131178;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098474),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786538
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateAsync",
      "o": "Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync",
      "d": 131178,
      "h": 4295098474,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098474)
  ],
  "h": 131178
}; }
            static get $fullName() { return `IValidatableInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131178)
        
        
        //--TRIMMABLE-BOUNDARY-START(196714)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver", ($self) => class IValidatableInfoResolver
        {
            static $h = 196714;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131306),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "validatableInfo",
          "p": 131178,
          "f": 2
        }
      ],
      "n": "TryGetValidatableTypeInfo",
      "o": "Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableTypeInfo",
      "d": 196714,
      "h": 8590131306,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590131306),
//--TRIMMABLE-BOUNDARY-START(4295164010),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameterInfo",
          "p": 118358017
        },
        {
          "n": "validatableInfo",
          "p": 131178,
          "f": 2
        }
      ],
      "n": "TryGetValidatableParameterInfo",
      "o": "Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableParameterInfo",
      "d": 196714,
      "h": 4295164010,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295164010)
  ],
  "h": 196714
}; }
            static get $fullName() { return `IValidatableInfoResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196714)
        
        
        //--TRIMMABLE-BOUNDARY-START(524394)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidatableParameterInfo", ($self) => class ValidatableParameterInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295491690)
            /*RequiredAttribute?*/ _requiredAttribute = null;
            //--TRIMMABLE-BOUNDARY-END(4295491690)
            
            //--TRIMMABLE-BOUNDARY-START(21475360874)
            $ctor$1(/*Type*/ parameterType, /*string*/ name, /*string*/ displayName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360874);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ParameterType = parameterType;
                    this.Name = name;
                    this.DisplayName = displayName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360874)
            
            //--TRIMMABLE-BOUNDARY-START(64425033834)
            /*Type*/ ParameterType = null;
            //--TRIMMABLE-BOUNDARY-END(64425033834)
            
            //--TRIMMABLE-BOUNDARY-START(60130066538)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(60130066538)
            
            //--TRIMMABLE-BOUNDARY-START(25770328170)
            /*string*/ DisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(25770328170)
            
            //--TRIMMABLE-BOUNDARY-START(68720001130)
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720001130);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (value === null && $.$mev.Microsoft.Extensions.Validation.TypeExtensions.IsNullable(this.ParameterType))
                    {
                        return;
                    }
                    context.ValidationContext.DisplayName = this.DisplayName;
                    context.ValidationContext.MemberName = this.Name;
                    /*var*/ let validationAttributes = this.GetValidationAttributes();
                    if (!(this._requiredAttribute === null) || $.$mev.Microsoft.Extensions.Validation.TypeExtensions.TryGetRequiredAttribute(validationAttributes, $.$ref(() => this._requiredAttribute, ($v) => this._requiredAttribute = $v, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute)))
                    {
                        /*var*/ let result = this._requiredAttribute.GetValidationResult(value, context.ValidationContext);
                        if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                        {
                            /*var*/ let key = $.$$.System.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${context.CurrentValidationPath}.${this.Name}`;
                            context.AddValidationError(this.Name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ result.ErrorMessage ], null, null), null);
                            return;
                        }
                    }
                    for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                    {
                        /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                        try
                        {
                            /*var*/ let result = attribute.GetValidationResult(value, context.ValidationContext);
                            if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                            {
                                /*var*/ let key = $.$$.System.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${context.CurrentValidationPath}.${this.Name}`;
                                context.AddOrExtendValidationErrors(this.Name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ result.ErrorMessage ], null, null), null);
                            }
                        }
                        catch(ex)
                        {
                            /*var*/ let key = $.$$.System.String.IsNullOrEmpty(context.CurrentValidationPath) ? this.Name : `${context.CurrentValidationPath}.${this.Name}`;
                            context.AddValidationError(this.Name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ ex.Message ], null, null), null);
                        }
                    }
                    let enumerable;
                    if ($.$mev.Microsoft.Extensions.Validation.TypeExtensions.IsEnumerable(this.ParameterType) && $.$is(value, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                    {
                        /*var*/ let index = 0;
                        /*var*/ let currentPrefix = context.CurrentValidationPath;
                        var $en4 = enumerable.System$Collections$IEnumerable$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$IEnumerator$Current;
                            {
                                if (item !== null)
                                {
                                    context.CurrentValidationPath = $.$$.System.String.IsNullOrEmpty(currentPrefix) ? `${this.Name}[${index}]` : `${currentPrefix}.${this.Name}[${index}]`;
                                    /*var*/ let validatableType;
                                    if (context.ValidationOptions.TryGetValidatableTypeInfo($.$$.System.Object.GetType.call(item), $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)))
                                    {
                                        await validatableType.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(item, context, cancellationToken);
                                    }
                                }
                                index++;
                            }
                        }
                        context.CurrentValidationPath = currentPrefix;
                    }
                    else if (value !== null)
                    {
                        /*var*/ let valueType = $.$$.System.Object.GetType.call(value);
                        /*var*/ let validatableType;
                        if (context.ValidationOptions.TryGetValidatableTypeInfo(valueType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)))
                        {
                            await validatableType.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(value, context, cancellationToken);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720001130)
            
            //--TRIMMABLE-BOUNDARY-START(4295098474)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098474)
            
            static $h = 524394;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425033834),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540131946,
        "f": 50331656
      },
      "n": "ParameterType",
      "d": 524394,
      "h": 64425033834,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(64425033834),
//--TRIMMABLE-BOUNDARY-START(60130066538),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197354,
        "f": 50331656
      },
      "n": "Name",
      "d": 524394,
      "h": 60130066538,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60130066538),
//--TRIMMABLE-BOUNDARY-START(25770328170),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360262762,
        "f": 50331656
      },
      "n": "DisplayName",
      "d": 524394,
      "h": 25770328170,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25770328170)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835099242),
    {
      "r": $.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,
      "n": "GetValidationAttributes",
      "d": 524394,
      "h": 55835099242,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(55835099242),
//--TRIMMABLE-BOUNDARY-START(68720001130),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786538
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateAsync",
      "d": 524394,
      "h": 68720001130,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(68720001130)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491690),
    {
      "t": 2228263,
      "n": "_requiredAttribute",
      "d": 524394,
      "h": 4295491690,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475360874),
    {
      "p": [
        {
          "n": "parameterType",
          "p": 187760641
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "displayName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524394,
      "h": 21475360874,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21475360874)
  ],
  "i": [131178
  ],
  "h": 524394
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfo ]; }
            static get $fullName() { return `ValidatableParameterInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524394)
        
        
        //--TRIMMABLE-BOUNDARY-START(589930)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidatablePropertyInfo", ($self) => class ValidatablePropertyInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557226)
            /*RequiredAttribute?*/ _requiredAttribute = null;
            //--TRIMMABLE-BOUNDARY-END(4295557226)
            
            //--TRIMMABLE-BOUNDARY-START(25770393706)
            $ctor$1(/*Type*/ declaringType, /*Type*/ propertyType, /*string*/ name, /*string*/ displayName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393706);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DeclaringType = declaringType;
                    this.PropertyType = propertyType;
                    this.Name = name;
                    this.DisplayName = displayName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393706)
            
            //--TRIMMABLE-BOUNDARY-START(30065361002)
            /*Type*/ DeclaringType = null;
            //--TRIMMABLE-BOUNDARY-END(30065361002)
            
            //--TRIMMABLE-BOUNDARY-START(81604968554)
            /*Type*/ PropertyType = null;
            //--TRIMMABLE-BOUNDARY-END(81604968554)
            
            //--TRIMMABLE-BOUNDARY-START(77310001258)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(77310001258)
            
            //--TRIMMABLE-BOUNDARY-START(34360328298)
            /*string*/ DisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(34360328298)
            
            //--TRIMMABLE-BOUNDARY-START(85899935850)
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899935850);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let property = $.$firstOf(this.DeclaringType.GetProperty$6(this.Name), () => { throw new $.$$.System.InvalidOperationException().$ctor$12(`Property '${this.Name}' not found on type '${this.DeclaringType.Name}'.`) });
                    /*var*/ let propertyValue = property.GetValue$2(value);
                    /*var*/ let validationAttributes = this.GetValidationAttributes();
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    if ($.$$.System.String.IsNullOrEmpty(originalPrefix))
                    {
                        context.CurrentValidationPath = this.Name;
                    }
                    else 
                    {
                        context.CurrentValidationPath = `${originalPrefix}.${this.Name}`;
                    }
                    context.ValidationContext.DisplayName = this.DisplayName;
                    context.ValidationContext.MemberName = this.Name;
                    if (!(this._requiredAttribute === null) || $.$mev.Microsoft.Extensions.Validation.TypeExtensions.TryGetRequiredAttribute(validationAttributes, $.$ref(() => this._requiredAttribute, ($v) => this._requiredAttribute = $v, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute)))
                    {
                        /*var*/ let result = this._requiredAttribute.GetValidationResult(propertyValue, context.ValidationContext);
                        if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                        {
                            context.AddValidationError(this.Name, context.CurrentValidationPath, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ result.ErrorMessage ], null, null), value);
                            context.CurrentValidationPath = originalPrefix;
                            return;
                        }
                    }
                    ValidateValue.call(this, propertyValue, this.Name, context.CurrentValidationPath, validationAttributes, value);
                    if (context.CurrentDepth >= context.ValidationOptions.MaxDepth)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Maximum validation depth of ${context.ValidationOptions.MaxDepth} exceeded at '${context.CurrentValidationPath}' in '${this.DeclaringType.Name}.${this.Name}'. ` + "This is likely caused by a circular reference in the object graph. " + "Consider increasing the MaxDepth in ValidationOptions if deeper validation is required.");
                    }
                    context.CurrentDepth++;
                    try
                    {
                        let enumerable;
                        if ($.$mev.Microsoft.Extensions.Validation.TypeExtensions.IsEnumerable(this.PropertyType) && $.$is(propertyValue, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                        {
                            /*var*/ let index = 0;
                            /*var*/ let currentPrefix = context.CurrentValidationPath;
                            var $en5 = enumerable.System$Collections$IEnumerable$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$IEnumerator$Current;
                                {
                                    context.CurrentValidationPath = `${currentPrefix}[${index}]`;
                                    if (item !== null)
                                    {
                                        /*var*/ let itemType = $.$$.System.Object.GetType.call(item);
                                        /*var*/ let validatableType;
                                        if (context.ValidationOptions.TryGetValidatableTypeInfo(itemType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)))
                                        {
                                            await validatableType.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(item, context, cancellationToken);
                                        }
                                    }
                                    index++;
                                }
                            }
                            context.CurrentValidationPath = currentPrefix;
                        }
                        else if (propertyValue !== null)
                        {
                            /*var*/ let valueType = $.$$.System.Object.GetType.call(propertyValue);
                            /*var*/ let validatableType;
                            if (context.ValidationOptions.TryGetValidatableTypeInfo(valueType, $.$ref(() => validatableType, ($v) => validatableType = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)))
                            {
                                await validatableType.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(propertyValue, context, cancellationToken);
                            }
                        }
                    }
                    finally
                    {
                        {
                            context.CurrentDepth--;
                            context.CurrentValidationPath = originalPrefix;
                        }
                    }
                    /*void*/  function ValidateValue(/*object?*/ val, /*string*/ name, /*string*/ errorPrefix, /*ValidationAttribute[]*/ validationAttributes, /*object?*/ container)
                    {
                        for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                        {
                            /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                            try
                            {
                                /*var*/ let result = attribute.GetValidationResult(val, context.ValidationContext);
                                if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                                {
                                    /*var*/ let key = $.$$.System.String.TrimStart$1.call(errorPrefix, /*.*/ 46);
                                    context.AddOrExtendValidationErrors(name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ result.ErrorMessage ], null, null), container);
                                }
                            }
                            catch(ex)
                            {
                                /*var*/ let key = $.$$.System.String.TrimStart$1.call(errorPrefix, /*.*/ 46);
                                context.AddOrExtendValidationErrors(name, key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ ex.Message ], null, null), container);
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899935850)
            
            //--TRIMMABLE-BOUNDARY-START(4295098474)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098474)
            
            static $h = 589930;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065361002),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262890,
        "f": 50331656
      },
      "n": "DeclaringType",
      "d": 589930,
      "h": 30065361002,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(30065361002),
//--TRIMMABLE-BOUNDARY-START(81604968554),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066666,
        "f": 50331656
      },
      "n": "PropertyType",
      "d": 589930,
      "h": 81604968554,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(81604968554),
//--TRIMMABLE-BOUNDARY-START(77310001258),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132074,
        "f": 50331656
      },
      "n": "Name",
      "d": 589930,
      "h": 77310001258,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(77310001258),
//--TRIMMABLE-BOUNDARY-START(34360328298),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197482,
        "f": 50331656
      },
      "n": "DisplayName",
      "d": 589930,
      "h": 34360328298,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(34360328298)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015033962),
    {
      "r": $.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,
      "n": "GetValidationAttributes",
      "d": 589930,
      "h": 73015033962,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(73015033962),
//--TRIMMABLE-BOUNDARY-START(85899935850),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786538
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateAsync",
      "d": 589930,
      "h": 85899935850,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(85899935850)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557226),
    {
      "t": 2228263,
      "n": "_requiredAttribute",
      "d": 589930,
      "h": 4295557226,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557226)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770393706),
    {
      "p": [
        {
          "n": "declaringType",
          "p": 187760641
        },
        {
          "n": "propertyType",
          "p": 187760641
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "displayName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589930,
      "h": 25770393706,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25770393706)
  ],
  "i": [131178
  ],
  "h": 589930
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfo ]; }
            static get $fullName() { return `ValidatablePropertyInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589930)
        
        
        //--TRIMMABLE-BOUNDARY-START(721002)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidatableTypeInfo", ($self) => class ValidatableTypeInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688298)
            /*int*/ _membersCount = 0;
            //--TRIMMABLE-BOUNDARY-END(4295688298)
            
            //--TRIMMABLE-BOUNDARY-START(8590655594)
            /*List<Type>*/ _superTypes = null;
            //--TRIMMABLE-BOUNDARY-END(8590655594)
            
            //--TRIMMABLE-BOUNDARY-START(21475557482)
            $ctor$1(/*Type*/ type, /*IReadOnlyList<ValidatablePropertyInfo>*/ members)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557482);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Type = type;
                    this.Members = members;
                    this._membersCount = members.System$Collections$Generic$IReadOnlyCollection$$$Count;
                    this._superTypes = $.$mev.Microsoft.Extensions.Validation.TypeExtensions.GetAllImplementedTypes(type);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557482)
            
            //--TRIMMABLE-BOUNDARY-START(55835295850)
            /*Type*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(55835295850)
            
            //--TRIMMABLE-BOUNDARY-START(51540328554)
            /*IReadOnlyList<ValidatablePropertyInfo>*/ Members = null;
            //--TRIMMABLE-BOUNDARY-END(51540328554)
            
            //--TRIMMABLE-BOUNDARY-START(60130263146)
            /*Task *//*async*/  ValidateAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130263146);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (value === null)
                    {
                        return;
                    }
                    if (context.CurrentDepth >= context.ValidationOptions.MaxDepth)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Maximum validation depth of ${context.ValidationOptions.MaxDepth} exceeded at '${context.CurrentValidationPath}' in '${this.Type.Name}'. ` + "This is likely caused by a circular reference in the object graph. " + "Consider increasing the MaxDepth in ValidationOptions if deeper validation is required.");
                    }
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    /*var*/ let originalErrorCount = (context.ValidationErrors?.Count ?? null) ?? 0;
                    try
                    {
                        await this.ValidateMembersAsync(value, context, cancellationToken);
                        /*var*/ let actualType = $.$$.System.Object.GetType.call(value);
                        var $en4 = this.GetSuperTypeInfos(actualType, context).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var superTypeInfo = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                await superTypeInfo.ValidateMembersAsync(value, context, cancellationToken);
                            }
                        }
                        if (!(context.ValidationErrors === null) && context.ValidationErrors.Count > originalErrorCount)
                        {
                            return;
                        }
                        this.ValidateTypeAttributes(value, context);
                        if (!(context.ValidationErrors === null) && context.ValidationErrors.Count > originalErrorCount)
                        {
                            return;
                        }
                        this.ValidateValidatableObjectInterface(value, context);
                    }
                    finally
                    {
                        {
                            context.CurrentValidationPath = originalPrefix;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60130263146)
            
            //--TRIMMABLE-BOUNDARY-START(64425230442)
            /*Task *//*async*/  ValidateMembersAsync(/*object?*/ value, /*ValidateContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425230442);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let originalPrefix = context.CurrentValidationPath;
                    for(/*var*/ let i = 0; i < this._membersCount; i++)
                    {
                        try
                        {
                            await this.Members.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$mev.Microsoft.Extensions.Validation.ValidatablePropertyInfo]).ValidateAsync(value, context, cancellationToken);
                        }
                        finally
                        {
                            {
                                context.CurrentValidationPath = originalPrefix;
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425230442)
            
            //--TRIMMABLE-BOUNDARY-START(68720197738)
            /*void */ ValidateTypeAttributes(/*object?*/ value, /*ValidateContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let validationAttributes = this.GetValidationAttributes();
                /*var*/ let errorPrefix = context.CurrentValidationPath;
                for(/*var*/ let i = 0; i < validationAttributes.length; i++)
                {
                    /*var*/ let attribute = $.$$.System.Array.$ReadT1.call(validationAttributes, i);
                    /*var*/ let result = attribute.GetValidationResult(value, context.ValidationContext);
                    if (!(result === null) && result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(result.ErrorMessage === null))
                    {
                        var $en4 = result.MemberNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var memberName = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*var*/ let key = $.$$.System.String.IsNullOrEmpty(errorPrefix) ? memberName : `${errorPrefix}.${memberName}`;
                                context.AddOrExtendValidationError(memberName, key, result.ErrorMessage, value);
                            }
                        }
                        if (!$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, result.MemberNames))
                        {
                            context.AddOrExtendValidationError($.$$.System.String.Empty, errorPrefix, result.ErrorMessage, value);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720197738)
            
            //--TRIMMABLE-BOUNDARY-START(73015165034)
            /*void */ ValidateValidatableObjectInterface(/*object?*/ value, /*ValidateContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let validatable;
                if ($.$mev.Microsoft.Extensions.Validation.TypeExtensions.ImplementsInterface(this.Type, $.$sca.System.ComponentModel.DataAnnotations.IValidatableObject.$type) && $.$is(value, $.$sca.System.ComponentModel.DataAnnotations.IValidatableObject, { set $v(v){ validatable = v; } }))
                {
                    /*var*/ let originalDisplayName = context.ValidationContext.DisplayName;
                    /*var*/ let originalMemberName = context.ValidationContext.MemberName;
                    /*var*/ let errorPrefix = context.CurrentValidationPath;
                    context.ValidationContext.DisplayName = this.Type.Name;
                    context.ValidationContext.MemberName = null;
                    /*var*/ let validationResults = validatable.System$ComponentModel$DataAnnotations$IValidatableObject$Validate(context.ValidationContext);
                    var $en3 = validationResults.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var validationResult = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (validationResult !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success && !(validationResult.ErrorMessage === null))
                            {
                                var $en6 = validationResult.MemberNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var memberName = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        /*var*/ let key = $.$$.System.String.IsNullOrEmpty(errorPrefix) ? memberName : `${errorPrefix}.${memberName}`;
                                        context.AddOrExtendValidationError(memberName, key, validationResult.ErrorMessage, value);
                                    }
                                }
                                if (!$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, validationResult.MemberNames))
                                {
                                    context.AddOrExtendValidationError($.$$.System.String.Empty, $.$$.System.String.Empty, validationResult.ErrorMessage, value);
                                }
                            }
                        }
                    }
                    context.ValidationContext.DisplayName = originalDisplayName;
                    context.ValidationContext.MemberName = originalMemberName;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015165034)
            
            //--TRIMMABLE-BOUNDARY-START(42950393962)
            /*IEnumerable<ValidatableTypeInfo> */ GetSuperTypeInfos(/*Type*/ actualType, /*ValidateContext*/ context)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = $.$sl.System.Linq.Enumerable.Where($.$$.System.Type, this._superTypes, new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.IsAssignableFrom(actualType);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "t",
      "p": 187760641
    }
  ],
  "n": "",
  "d": 721002,
  "h": 0,
  "f": 17825794
})).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var superType = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*var*/ let found;
                            let superTypeInfo;
                            if (context.ValidationOptions.TryGetValidatableTypeInfo(superType, $.$ref(() => found, ($v) => found = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)) && $.$is(found, $.$mev.Microsoft.Extensions.Validation.ValidatableTypeInfo, { set $v(v){ superTypeInfo = v; } }))
                            {
                                yield superTypeInfo;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(42950393962)
            
            //--TRIMMABLE-BOUNDARY-START(4295098474)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfo.ValidateAsync(object?, Microsoft.Extensions.Validation.ValidateContext, System.Threading.CancellationToken)
            Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098474)
            
            static $h = 721002;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835295850),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426666,
        "f": 50331656
      },
      "n": "Type",
      "d": 721002,
      "h": 55835295850,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55835295850),
//--TRIMMABLE-BOUNDARY-START(51540328554),
    {
      "p": $.$$.System.Collections.Generic.IReadOnlyList$$($.$mev.Microsoft.Extensions.Validation.ValidatablePropertyInfo).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065492074,
        "f": 50331656
      },
      "n": "Members",
      "d": 721002,
      "h": 51540328554,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51540328554)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245361258),
    {
      "r": $.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,
      "n": "GetValidationAttributes",
      "d": 721002,
      "h": 47245361258,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(47245361258),
//--TRIMMABLE-BOUNDARY-START(60130263146),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786538
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateAsync",
      "d": 721002,
      "h": 60130263146,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(60130263146),
//--TRIMMABLE-BOUNDARY-START(64425230442),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786538
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateMembersAsync",
      "d": 721002,
      "h": 64425230442,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(64425230442),
//--TRIMMABLE-BOUNDARY-START(68720197738),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786538
        }
      ],
      "n": "ValidateTypeAttributes",
      "d": 721002,
      "h": 68720197738,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720197738),
//--TRIMMABLE-BOUNDARY-START(73015165034),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "context",
          "p": 786538
        }
      ],
      "n": "ValidateValidatableObjectInterface",
      "d": 721002,
      "h": 73015165034,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015165034),
//--TRIMMABLE-BOUNDARY-START(42950393962),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mev.Microsoft.Extensions.Validation.ValidatableTypeInfo).$h,
      "p": [
        {
          "n": "actualType",
          "p": 187760641
        },
        {
          "n": "context",
          "p": 786538
        }
      ],
      "n": "GetSuperTypeInfos",
      "d": 721002,
      "h": 42950393962,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393962)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688298),
    {
      "t": 655361,
      "n": "_membersCount",
      "d": 721002,
      "h": 4295688298,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688298),
//--TRIMMABLE-BOUNDARY-START(8590655594),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.Type).$h,
      "n": "_superTypes",
      "d": 721002,
      "h": 8590655594,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655594)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557482),
    {
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "members",
          "p": $.$$.System.Collections.Generic.IReadOnlyList$$($.$mev.Microsoft.Extensions.Validation.ValidatablePropertyInfo).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721002,
      "h": 21475557482,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21475557482)
  ],
  "i": [131178
  ],
  "h": 721002
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfo ]; }
            static get $fullName() { return `ValidatableTypeInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721002)
        
        
        //--TRIMMABLE-BOUNDARY-START(65642)
        $asm.$cls("$mev.Microsoft.Extensions.DependencyInjection.ValidationServiceCollectionExtensions", ($self) => class ValidationServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295032938)
            static /*IServiceCollection */ AddValidation(/*this IServiceCollection*/ services, /*Action<ValidationOptions>?*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mev.Microsoft.Extensions.Validation.ValidationOptions, services, new ($.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    if (!(configureOptions === null))
                    {
                        configureOptions.Invoke(options);
                    }
                    options.Resolvers.System$Collections$Generic$ICollection$$$Add(new $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver().$ctor$1(), [$.$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver]);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "options",
      "p": 917610
    }
  ],
  "n": "",
  "d": 65642,
  "h": 0,
  "f": 17825794
}));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032938)
            
            static $h = 65642;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032938),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configureOptions",
          "p": $.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationOptions).$h,
          "f": 65
        }
      ],
      "n": "AddValidation",
      "d": 65642,
      "h": 4295032938,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032938)
  ],
  "h": 65642
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ValidationServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65642)
        
        
        //--TRIMMABLE-BOUNDARY-START(917610)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidationOptions", ($self) => class ValidationOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655623274)
            /*IList<IValidatableInfoResolver>*/ Resolvers = null;
            //--TRIMMABLE-BOUNDARY-END(38655623274)
            
            //--TRIMMABLE-BOUNDARY-START(34360655978)
            /*int*/ MaxDepth = 0;
            //--TRIMMABLE-BOUNDARY-END(34360655978)
            
            //--TRIMMABLE-BOUNDARY-START(55835492458)
            /*bool */ TryGetValidatableTypeInfo(/*Type*/ type, /*out IValidatableInfo?*/ validatableTypeInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835492458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this.Resolvers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var resolver = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (resolver.Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableTypeInfo(type, validatableTypeInfo))
                        {
                            return true;
                        }
                    }
                }
                validatableTypeInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(55835492458)
            
            //--TRIMMABLE-BOUNDARY-START(51540525162)
            /*bool */ TryGetValidatableParameterInfo(/*ParameterInfo*/ parameterInfo, /*out IValidatableInfo?*/ validatableInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this.Resolvers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var resolver = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (resolver.Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableParameterInfo(parameterInfo, validatableInfo))
                        {
                            return true;
                        }
                    }
                }
                validatableInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525162)
            
            //--TRIMMABLE-BOUNDARY-START(12885819498)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819498)
            
            //default member initializer
            constructor()
            {
                super();
                this.Resolvers = (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver))().$ctor$1();
                    return $t1;
                })();
                this.MaxDepth = 32;
            }
            static $h = 917610;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655623274),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065688682,
        "f": 50331649
      },
      "n": "Resolvers",
      "d": 917610,
      "h": 38655623274,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655623274),
//--TRIMMABLE-BOUNDARY-START(34360655978),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475754090,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245557866,
        "f": 83886081
      },
      "n": "MaxDepth",
      "d": 917610,
      "h": 34360655978,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360655978)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835492458),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "validatableTypeInfo",
          "p": 131178,
          "f": 2
        }
      ],
      "n": "TryGetValidatableTypeInfo",
      "d": 917610,
      "h": 55835492458,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835492458),
//--TRIMMABLE-BOUNDARY-START(51540525162),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameterInfo",
          "p": 118358017
        },
        {
          "n": "validatableInfo",
          "p": 131178,
          "f": 2
        }
      ],
      "n": "TryGetValidatableParameterInfo",
      "d": 917610,
      "h": 51540525162,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540525162)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819498),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917610,
      "h": 12885819498,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819498)
  ],
  "h": 917610
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ValidationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917610)
        
        
        //--TRIMMABLE-BOUNDARY-START(458858)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.TypeExtensions", ($self) => class TypeExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885360746)
            static /*bool */ IsEnumerable(/*this Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsGenericType && ($.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type) || $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.ICollection$$().$type) || $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.List$$().$type) || $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IList$$().$type)))
                {
                    return true;
                }
                if (type.IsArray)
                {
                    return true;
                }
                if ($.$$.System.Collections.IEnumerable.$type.IsAssignableFrom(type) && $.$$.System.Type.op_Inequality$1(type, $.$$.System.String.$type))
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360746)
            
            //--TRIMMABLE-BOUNDARY-START(17180328042)
            static /*bool */ IsNullable(/*this Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsValueType)
                {
                    return false;
                }
                if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type))
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328042)
            
            //--TRIMMABLE-BOUNDARY-START(21475295338)
            static /*bool */ TryGetRequiredAttribute(/*this ValidationAttribute[]*/ attributes, /*out RequiredAttribute?*/ requiredAttribute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = attributes;
                while ($i1 < $arr1.length)
                {
                    let attribute = $arr1[$i1++];
                    let requiredAttr;
                    if ($.$is(attribute, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute, { set $v(v){ requiredAttr = v; } }))
                    {
                        requiredAttribute.$v = requiredAttr;
                        return true;
                    }
                }
                requiredAttribute.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295338)
            
            //--TRIMMABLE-BOUNDARY-START(4295426154)
            static /*List<Type> */ GetAllImplementedTypes(/*this Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*var*/ let implementedTypes = new ($.$$.System.Collections.Generic.List$$($.$$.System.Type))().$ctor$1();
                let $i1 = 0;
                let $arr1 = type.GetInterfaces();
                while ($i1 < $arr1.length)
                {
                    let interfaceType = $arr1[$i1++];
                    implementedTypes.Add(interfaceType);
                }
                /*var*/ let baseType = type.BaseType;
                while($.$$.System.Type.op_Inequality$1(baseType, null) && $.$$.System.Type.op_Inequality$1(baseType, $.$$.System.Object.$type))
                {
                    implementedTypes.Add(baseType);
                    baseType = baseType.BaseType;
                }
                return implementedTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426154)
            
            //--TRIMMABLE-BOUNDARY-START(8590393450)
            static /*bool */ ImplementsInterface(/*this Type*/ type, /*Type*/ interfaceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(interfaceType, "interfaceType");
                if (!interfaceType.IsInterface)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13(`Type ${interfaceType.FullName} is not an interface.`, "interfaceType");
                }
                return interfaceType.IsAssignableFrom(type);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393450)
            
            static $h = 458858;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360746),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "IsEnumerable",
      "d": 458858,
      "h": 12885360746,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885360746),
//--TRIMMABLE-BOUNDARY-START(17180328042),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "IsNullable",
      "d": 458858,
      "h": 17180328042,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180328042),
//--TRIMMABLE-BOUNDARY-START(21475295338),
    {
      "r": 262145,
      "p": [
        {
          "n": "attributes",
          "p": $.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h
        },
        {
          "n": "requiredAttribute",
          "p": 2228263,
          "f": 2
        }
      ],
      "n": "TryGetRequiredAttribute",
      "d": 458858,
      "h": 21475295338,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475295338),
//--TRIMMABLE-BOUNDARY-START(4295426154),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$$.System.Type).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetAllImplementedTypes",
      "d": 458858,
      "h": 4295426154,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295426154),
//--TRIMMABLE-BOUNDARY-START(8590393450),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "interfaceType",
          "p": 187760641
        }
      ],
      "n": "ImplementsInterface",
      "d": 458858,
      "h": 8590393450,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590393450)
  ],
  "h": 458858
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `TypeExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458858)
        
        
        //--TRIMMABLE-BOUNDARY-START(786538)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidateContext", ($self) => class ValidateContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(158914576490)
            /*ValidationContext*/ ValidationContext = null;
            //--TRIMMABLE-BOUNDARY-END(158914576490)
            
            //--TRIMMABLE-BOUNDARY-START(55835361386)
            /*string*/ CurrentValidationPath = null;
            //--TRIMMABLE-BOUNDARY-END(55835361386)
            
            //--TRIMMABLE-BOUNDARY-START(167504511082)
            /*ValidationOptions*/ ValidationOptions = null;
            //--TRIMMABLE-BOUNDARY-END(167504511082)
            
            //--TRIMMABLE-BOUNDARY-START(163209543786)
            /*Dictionary<string, string[]>?*/ ValidationErrors = null;
            //--TRIMMABLE-BOUNDARY-END(163209543786)
            
            //--TRIMMABLE-BOUNDARY-START(51540394090)
            /*int*/ CurrentDepth = 0;
            //--TRIMMABLE-BOUNDARY-END(51540394090)
            
            //--TRIMMABLE-BOUNDARY-START(103080001642)
            /*Action<ValidationErrorContext>?*/ OnValidationError = null;
            //--TRIMMABLE-BOUNDARY-END(103080001642)
            
            //--TRIMMABLE-BOUNDARY-START(103080001642)
            //--TRIMMABLE-BOUNDARY-START(34360524906)
            add_OnValidationError(/*Action<ValidationErrorContext>?*/ value)
            {
                this.OnValidationError = $.$$.System.Delegate.Combine(this.OnValidationError, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360524906)
            
            //--TRIMMABLE-BOUNDARY-START(111669936234)
            remove_OnValidationError(/*Action<ValidationErrorContext>?*/ value)
            {
                this.OnValidationError = $.$$.System.Delegate.Remove(this.OnValidationError, value);
            }
            //--TRIMMABLE-BOUNDARY-END(111669936234)
            
            //--TRIMMABLE-BOUNDARY-END(103080001642)
            
            //--TRIMMABLE-BOUNDARY-START(47245426794)
            /*void */ AddValidationError(/*string*/ propertyName, /*string*/ key, /*string[]*/ error, /*object?*/ container)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidationErrors ??= (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.String)))().$ctor$1();
                    return $t1;
                })();
                this.ValidationErrors.set_Item(key, error);
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext()
                    const $t1 = $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext;
                    const $i1 = new $t1();
                    $i1.Name = propertyName;
                    $i1.Path = key;
                    $i1.Errors = error;
                    $i1.Container = container;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(47245426794)
            
            //--TRIMMABLE-BOUNDARY-START(42950459498)
            /*void */ AddOrExtendValidationErrors(/*string*/ propertyName, /*string*/ key, /*string[]*/ errors, /*object?*/ container)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidationErrors ??= (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.String)))().$ctor$1();
                    return $t1;
                })();
                /*var*/ let existingErrors;
                if (this.ValidationErrors.TryGetValue(key, $.$ref(() => existingErrors, ($v) => existingErrors = $v, $.$typeArray($.$$.System.String))))
                {
                    /*var*/ let newErrors = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [((existingErrors.length + errors.length) | 0)], null);
                    existingErrors.CopyTo(newErrors, 0);
                    errors.CopyTo(newErrors, existingErrors.length);
                    this.ValidationErrors.set_Item(key, newErrors);
                }
                else 
                {
                    this.ValidationErrors.set_Item(key, errors);
                }
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext()
                    const $t2 = $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext;
                    const $i2 = new $t2();
                    $i2.Name = propertyName;
                    $i2.Path = key;
                    $i2.Errors = errors;
                    $i2.Container = container;
                    return $i2;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(42950459498)
            
            //--TRIMMABLE-BOUNDARY-START(38655492202)
            /*void */ AddOrExtendValidationError(/*string*/ name, /*string*/ key, /*string*/ error, /*object?*/ container)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidationErrors ??= (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.String)))().$ctor$1();
                    return $t1;
                })();
                /*var*/ let existingErrors;
                if (this.ValidationErrors.TryGetValue(key, $.$ref(() => existingErrors, ($v) => existingErrors = $v, $.$typeArray($.$$.System.String))) && !$.$$.System.MemoryExtensions.Contains$2($.$$.System.String, $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1(existingErrors), error))
                {
                    this.ValidationErrors.set_Item(key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ ...existingErrors, error ], null, null));
                }
                else 
                {
                    this.ValidationErrors.set_Item(key, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ error ], null, null));
                }
                this.OnValidationError?.Invoke((() =>
                {
                    //new $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext()
                    const $t2 = $.$mev.Microsoft.Extensions.Validation.ValidationErrorContext;
                    const $i2 = new $t2();
                    $i2.Name = name;
                    $i2.Path = key;
                    $i2.Errors = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ error ], null, null);
                    $i2.Container = container;
                    return $i2;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(38655492202)
            
            //--TRIMMABLE-BOUNDARY-START(25770590314)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590314)
            
            //default member initializer
            constructor()
            {
                super();
                this.CurrentValidationPath = $.$$.System.String.Empty;
            }
            static $h = 786538;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914576490),
    {
      "p": 3538983,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605165162,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439740010,
        "f": 83886081
      },
      "n": "ValidationContext",
      "d": 786538,
      "h": 158914576490,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914576490),
//--TRIMMABLE-BOUNDARY-START(55835361386),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015230570,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849805418,
        "f": 83886081
      },
      "n": "CurrentValidationPath",
      "d": 786538,
      "h": 55835361386,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835361386),
//--TRIMMABLE-BOUNDARY-START(167504511082),
    {
      "p": 917610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785034346,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619609194,
        "f": 83886081
      },
      "n": "ValidationOptions",
      "d": 786538,
      "h": 167504511082,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504511082),
//--TRIMMABLE-BOUNDARY-START(163209543786),
    {
      "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195099754,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029674602,
        "f": 83886081
      },
      "n": "ValidationErrors",
      "d": 786538,
      "h": 163209543786,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209543786),
//--TRIMMABLE-BOUNDARY-START(51540394090),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425295978,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259870826,
        "f": 83886081
      },
      "n": "CurrentDepth",
      "d": 786538,
      "h": 51540394090,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540394090)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245426794),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "error",
          "p": $.$typeArray($.$$.System.String).$h
        },
        {
          "n": "container",
          "p": 131073
        }
      ],
      "n": "AddValidationError",
      "d": 786538,
      "h": 47245426794,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47245426794),
//--TRIMMABLE-BOUNDARY-START(42950459498),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "errors",
          "p": $.$typeArray($.$$.System.String).$h
        },
        {
          "n": "container",
          "p": 131073
        }
      ],
      "n": "AddOrExtendValidationErrors",
      "d": 786538,
      "h": 42950459498,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42950459498),
//--TRIMMABLE-BOUNDARY-START(38655492202),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "error",
          "p": 1310721
        },
        {
          "n": "container",
          "p": 131073
        }
      ],
      "n": "AddOrExtendValidationError",
      "d": 786538,
      "h": 38655492202,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38655492202)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590314),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786538,
      "h": 25770590314,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590314)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(103080001642),
    {
      "e": $.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext).$h
          }
        ],
        "n": "add_OnValidationError",
        "d": 786538,
        "h": 34360524906,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext).$h
          }
        ],
        "n": "remove_OnValidationError",
        "d": 786538,
        "h": 111669936234,
        "f": 285212673
      },
      "n": "OnValidationError",
      "d": 786538,
      "h": 103080001642,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(103080001642)
  ],
  "h": 786538
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ValidateContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786538)
        
        
        //--TRIMMABLE-BOUNDARY-START(262250)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver", ($self) => class RuntimeValidatableParameterInfoResolver extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770066026)
            /*bool */ TryGetValidatableTypeInfo(/*Type*/ type, /*out IValidatableInfo?*/ validatableInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770066026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                validatableInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25770066026)
            
            //--TRIMMABLE-BOUNDARY-START(21475098730)
            /*bool */ TryGetValidatableParameterInfo(/*ParameterInfo*/ parameterInfo, /*out IValidatableInfo?*/ validatableInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(parameterInfo.Name, null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Encountered a parameter of type '${$.$$.System.Type.ToString.call(parameterInfo.ParameterType)}' without a name. Parameters must have a name.`);
                }
                if ($.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$11($.$mev.Microsoft.Extensions.Validation.SkipValidationAttribute, parameterInfo) !== null || $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$8($.$mev.Microsoft.Extensions.Validation.SkipValidationAttribute, parameterInfo.ParameterType) !== null)
                {
                    validatableInfo.$v = null;
                    return false;
                }
                /*var*/ let validationAttributes = $.$sl.System.Linq.Enumerable.ToArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute, $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$17($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute, parameterInfo));
                if (validationAttributes.length === 0 && !$.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.IsComplexType(parameterInfo.ParameterType))
                {
                    validatableInfo.$v = null;
                    return false;
                }
                validatableInfo.$v = new $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo().$ctor$2(parameterInfo.ParameterType, parameterInfo.Name, $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.GetDisplayName(parameterInfo), validationAttributes);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098730)
            
            //--TRIMMABLE-BOUNDARY-START(12885164138)
            static /*string */ GetDisplayName(/*ParameterInfo*/ parameterInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let displayAttribute = $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$11($.$sca.System.ComponentModel.DataAnnotations.DisplayAttribute, parameterInfo);
                if (displayAttribute !== null)
                {
                    return displayAttribute.Name ?? parameterInfo.Name;
                }
                return parameterInfo.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164138)
            
            //--TRIMMABLE-BOUNDARY-START(327786)
            static $_RuntimeValidatableParameterInfo;
            static get RuntimeValidatableParameterInfo()
            {
                let $cls = $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver;
                return $cls.$_RuntimeValidatableParameterInfo ??= $asm.$ncls("$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo", ($self) => class RuntimeValidatableParameterInfo extends $.$mev.Microsoft.Extensions.Validation.ValidatableParameterInfo
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229674)
                    /*ValidationAttribute[] */ GetValidationAttributes()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885229674);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._validationAttributes;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885229674)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295295082)
                    /*ValidationAttribute[]*/ _validationAttributes = null;
                    //--TRIMMABLE-BOUNDARY-END(4295295082)
                    
                    //Begin primary constructor
                    /*Type*/ parameterType = null;
                    /*string*/ name = null;
                    /*string*/ displayName = null;
                    /*ValidationAttribute[]*/ validationAttributes = null;
                    $ctor$2(/*Type*/parameterType, /*string*/name, /*string*/displayName, /*ValidationAttribute[]*/validationAttributes)
                    {
                        this.parameterType = parameterType;
                        this.name = name;
                        this.displayName = displayName;
                        this.validationAttributes = validationAttributes;
                        super.$ctor$1(this.parameterType, this.name, this.displayName);
                        //--TRIMMABLE-BOUNDARY-START(4295295082)
                        //depends on primary constructor parameter
                        this._validationAttributes = this.validationAttributes;
                        //--TRIMMABLE-BOUNDARY-END(4295295082)
                        
                        return this
                    }
                    //End primary constructor
                    static $h = 327786;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 524394,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229674),
    {
      "r": $.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,
      "n": "GetValidationAttributes",
      "d": 327786,
      "h": 12885229674,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885229674)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295082),
    {
      "t": $.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,
      "n": "_validationAttributes",
      "d": 327786,
      "h": 4295295082,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295082)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262378),
    {
      "p": [
        {
          "n": "parameterType",
          "p": 187760641
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "validationAttributes",
          "p": $.$typeArray($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327786,
      "h": 8590262378,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262378)
  ],
  "i": [131178
  ],
  "d": 262250,
  "h": 327786
}; }
                    static get $b() { return $.$mev.Microsoft.Extensions.Validation.ValidatableParameterInfo; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfo ]; }
                    static get $fullName() { return `RuntimeValidatableParameterInfoResolver.RuntimeValidatableParameterInfo`; }
                }, $cls, ($v) => $cls.$_RuntimeValidatableParameterInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327786)
            
            //--TRIMMABLE-BOUNDARY-START(17180131434)
            static /*bool */ IsComplexType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsPrimitive || type.IsEnum || $.$$.System.Type.op_Equality$1(type, $.$$.System.String.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.Decimal.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.DateTime.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.DateTimeOffset.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.TimeOnly.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.DateOnly.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.TimeSpan.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.Guid.$type) || $.$$.System.Type.op_Equality$1(type, $.$ssc.System.Security.Claims.ClaimsPrincipal.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.Threading.CancellationToken.$type) || $.$$.System.Type.op_Equality$1(type, $.$$.System.IO.Stream.$type) || $.$$.System.Type.op_Equality$1(type, $.$sipl.System.IO.Pipelines.PipeReader.$type))
                {
                    return false;
                }
                let nullableType;
                if ($.$$.System.Nullable.GetUnderlyingType(type) !== null && ((nullableType = $.$$.System.Nullable.GetUnderlyingType(type), nullableType != null && true)))
                {
                    return $.$mev.Microsoft.Extensions.Validation.RuntimeValidatableParameterInfoResolver.IsComplexType(nullableType);
                }
                return type.IsClass || type.IsValueType;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131434)
            
            //--TRIMMABLE-BOUNDARY-START(8590131306)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfoResolver.TryGetValidatableTypeInfo(System.Type, out Microsoft.Extensions.Validation.IValidatableInfo?)
            Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableTypeInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValidatableTypeInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131306)
            
            //--TRIMMABLE-BOUNDARY-START(4295164010)
            //Generated interface implemetation for Microsoft.Extensions.Validation.IValidatableInfoResolver.TryGetValidatableParameterInfo(System.Reflection.ParameterInfo, out Microsoft.Extensions.Validation.IValidatableInfo?)
            Microsoft$Extensions$Validation$IValidatableInfoResolver$TryGetValidatableParameterInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValidatableParameterInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164010)
            
            //--TRIMMABLE-BOUNDARY-START(8590196842)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196842)
            
            static $h = 262250;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770066026),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "validatableInfo",
          "p": 131178,
          "f": 2
        }
      ],
      "n": "TryGetValidatableTypeInfo",
      "d": 262250,
      "h": 25770066026,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770066026),
//--TRIMMABLE-BOUNDARY-START(21475098730),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameterInfo",
          "p": 118358017
        },
        {
          "n": "validatableInfo",
          "p": 131178,
          "f": 2
        }
      ],
      "n": "TryGetValidatableParameterInfo",
      "d": 262250,
      "h": 21475098730,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098730),
//--TRIMMABLE-BOUNDARY-START(12885164138),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parameterInfo",
          "p": 118358017
        }
      ],
      "n": "GetDisplayName",
      "d": 262250,
      "h": 12885164138,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885164138),
//--TRIMMABLE-BOUNDARY-START(17180131434),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "IsComplexType",
      "d": 262250,
      "h": 17180131434,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180131434)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196842),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262250,
      "h": 8590196842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196842)
  ],
  "i": [196714
  ],
  "j": [327786
  ],
  "h": 262250
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mev.Microsoft.Extensions.Validation.IValidatableInfoResolver ]; }
            static get $fullName() { return `RuntimeValidatableParameterInfoResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262250)
        
        
        //--TRIMMABLE-BOUNDARY-START(852074)
        $asm.$str("$mev.Microsoft.Extensions.Validation.ValidationErrorContext", ($self) => class ValidationErrorContext extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(73015296106)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(73015296106)
            
            //--TRIMMABLE-BOUNDARY-START(77310263402)
            /*string*/ Path = null;
            //--TRIMMABLE-BOUNDARY-END(77310263402)
            
            //--TRIMMABLE-BOUNDARY-START(30065623146)
            /*IReadOnlyList<string>*/ Errors = null;
            //--TRIMMABLE-BOUNDARY-END(30065623146)
            
            //--TRIMMABLE-BOUNDARY-START(25770655850)
            /*object?*/ Container = null;
            //--TRIMMABLE-BOUNDARY-END(25770655850)
            
            //--TRIMMABLE-BOUNDARY-START(68720328810)
            /*string */ GetDebuggerDisplay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${this.Path}: ${$.$$.System.String.Join$5(",", this.Errors)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(68720328810)
            
            //--TRIMMABLE-BOUNDARY-START(21475688554)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475688554)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.Path = this.Path;
                copy.Errors = this.Errors;
                copy.Container = this.Container;
                return copy;
            }
            static $h = 852074;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015296106),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835426922,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080067178,
        "f": 83886081
      },
      "n": "Name",
      "d": 852074,
      "h": 73015296106,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015296106),
//--TRIMMABLE-BOUNDARY-START(77310263402),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425361514,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670001770,
        "f": 83886081
      },
      "n": "Path",
      "d": 852074,
      "h": 77310263402,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310263402),
//--TRIMMABLE-BOUNDARY-START(30065623146),
    {
      "p": $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245492330,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490132586,
        "f": 83886081
      },
      "n": "Errors",
      "d": 852074,
      "h": 30065623146,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065623146),
//--TRIMMABLE-BOUNDARY-START(25770655850),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655557738,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900197994,
        "f": 83886081
      },
      "n": "Container",
      "d": 852074,
      "h": 25770655850,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770655850)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720328810),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 852074,
      "h": 68720328810,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720328810)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475688554),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852074,
      "h": 21475688554,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688554)
  ],
  "h": 852074,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ValidationErrorContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852074)
        
        
        //--TRIMMABLE-BOUNDARY-START(655466)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295622762)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622762)
            
            static $h = 655466;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622762),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655466,
      "h": 4295622762,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622762)
  ],
  "h": 655466,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655466)
        
        
        //--TRIMMABLE-BOUNDARY-START(393322)
        $asm.$cls("$mev.Microsoft.Extensions.Validation.SkipValidationAttribute", ($self) => class SkipValidationAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295360618)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360618)
            
            static $h = 393322;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360618),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393322,
      "h": 4295360618,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360618)
  ],
  "h": 393322,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2180,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `SkipValidationAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393322)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.System.IO.Pipelines"))
//--TRIMMABLE-BOUNDARY-END(106)
