
//--TRIMMABLE-BOUNDARY-START(124)
(async function () {
(function ($global, $, $$) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.Abstractions", 
    {
  "h": 124,
  "f": "Microsoft.IdentityModel.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "Serviceable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 140836865,
      "c": 8730771457,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsAotCompatible",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "Microsoft Corporation.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107347969,
      "c": 8697282561,
      "a": [
        {
          "v": "\u00A9 Microsoft Corporation. All rights reserved.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "A package containing thin abstractions for Microsoft.IdentityModel.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "9.0.0.26315",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "Microsoft IdentityModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.IdentityModel.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131196)
        $asm.$cls(`$mia.MIA.IIdentityLogger`, ($self) => class IIdentityLogger
        {
            static $h = 131196;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098492),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventLogLevel",
          "p": 65660
        }
      ],
      "n": "IsEnabled",
      "o": "MIA$IIdentityLogger$IsEnabled",
      "d": 131196,
      "h": 4295098492,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098492),
//--TRIMMABLE-BOUNDARY-START(8590065788),
    {
      "r": 65537,
      "p": [
        {
          "n": "entry",
          "p": 262268
        }
      ],
      "n": "Log",
      "o": "MIA$IIdentityLogger$Log",
      "d": 131196,
      "h": 8590065788,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590065788)
  ],
  "h": 131196
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Abstractions.IIdentityLogger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Abstractions${separator}IIdentityLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131196)
        
        

        //--TRIMMABLE-BOUNDARY-START(196732)
        $asm.$cls(`$mia.MIA.ITelemetryClient`, ($self) => class ITelemetryClient
        {
            static $h = 196732;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295164028),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885098620,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34359935100,
        "f": 83886337
      },
      "n": "ClientId",
      "o": "MIA$ITelemetryClient$ClientId",
      "d": 196732,
      "h": 4295164028,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295164028)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065916),
    {
      "r": 65537,
      "n": "Initialize",
      "o": "MIA$ITelemetryClient$Initialize",
      "d": 196732,
      "h": 17180065916,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180065916),
//--TRIMMABLE-BOUNDARY-START(21475033212),
    {
      "r": 262145,
      "n": "IsEnabled",
      "o": "MIA$ITelemetryClient$IsEnabled",
      "d": 196732,
      "h": 21475033212,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475033212),
//--TRIMMABLE-BOUNDARY-START(25770000508),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        }
      ],
      "n": "IsEnabled",
      "o": "MIA$ITelemetryClient$IsEnabled$1",
      "d": 196732,
      "h": 25770000508,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770000508),
//--TRIMMABLE-BOUNDARY-START(38654902396),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventDetails",
          "p": 524412
        }
      ],
      "n": "TrackEvent",
      "o": "MIA$ITelemetryClient$TrackEvent",
      "d": 196732,
      "h": 38654902396,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38654902396),
//--TRIMMABLE-BOUNDARY-START(42949869692),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        },
        {
          "n": "stringProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "longProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Int64).$h,
          "f": 65
        },
        {
          "n": "boolProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Boolean).$h,
          "f": 65
        },
        {
          "n": "dateTimeProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.DateTime).$h,
          "f": 65
        },
        {
          "n": "doubleProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Double).$h,
          "f": 65
        },
        {
          "n": "guidProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Guid).$h,
          "f": 65
        }
      ],
      "n": "TrackEvent",
      "o": "MIA$ITelemetryClient$TrackEvent$1",
      "d": 196732,
      "h": 42949869692,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42949869692)
  ],
  "h": 196732
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Abstractions.ITelemetryClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Abstractions${separator}ITelemetryClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196732)
        
        

        //--TRIMMABLE-BOUNDARY-START(524412)
        $asm.$cls(`$mia.MIA.TelemetryEventDetails`, ($self) => class TelemetryEventDetails extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540131964)
            /*IDictionary<string, object>*/ PropertyValues = null;
            //--TRIMMABLE-BOUNDARY-END(51540131964)
            
            //--TRIMMABLE-BOUNDARY-START(42950197372)
            /*string?*/ $Name = null;
            /*string? */ get Name()
            {
                return this.$Name;
            }
            /*string? */ set Name(value)
            {
                this.$Name = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197372)
            
            //--TRIMMABLE-BOUNDARY-START(47245164668)
            /*IReadOnlyDictionary<string, object> */ get Properties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this.PropertyValues, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(47245164668)
            
            //--TRIMMABLE-BOUNDARY-START(85899870332)
            /*void */ SetProperty$5(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899870332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(85899870332)
            
            //--TRIMMABLE-BOUNDARY-START(81604903036)
            /*void */ SetProperty$4(/*string*/ key, /*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604903036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, $.$box(value, $.$$.S.Int64));
            }
            //--TRIMMABLE-BOUNDARY-END(81604903036)
            
            //--TRIMMABLE-BOUNDARY-START(64425033852)
            /*void */ SetProperty(/*string*/ key, /*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, $.$box(value, $.$$.S.Boolean));
            }
            //--TRIMMABLE-BOUNDARY-END(64425033852)
            
            //--TRIMMABLE-BOUNDARY-START(68720001148)
            /*void */ SetProperty$1(/*string*/ key, /*DateTime*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(68720001148)
            
            //--TRIMMABLE-BOUNDARY-START(73014968444)
            /*void */ SetProperty$2(/*string*/ key, /*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, $.$box(value, $.$$.S.Double));
            }
            //--TRIMMABLE-BOUNDARY-END(73014968444)
            
            //--TRIMMABLE-BOUNDARY-START(77309935740)
            /*void */ SetProperty$3(/*string*/ key, /*Guid*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(77309935740)
            
            //--TRIMMABLE-BOUNDARY-START(90194837628)
            /*void */ SetPropertyCore(/*string*/ key, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("key");
                }
                this.PropertyValues.SCG$IDictionary$$$$set_Item(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(90194837628)
            
            //--TRIMMABLE-BOUNDARY-START(12885426300)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426300)
            
            //--TRIMMABLE-BOUNDARY-START(12885426300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885426300)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540131964)
                this.PropertyValues = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(51540131964)
                
            }
            static $h = 524412;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540131964),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655230076,
        "f": 50331664
      },
      "n": "PropertyValues",
      "d": 524412,
      "h": 51540131964,
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(51540131964),
//--TRIMMABLE-BOUNDARY-START(42950197372),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360892,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130066556,
        "f": 83886209
      },
      "n": "Name",
      "d": 524412,
      "h": 42950197372,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(42950197372),
//--TRIMMABLE-BOUNDARY-START(47245164668),
    {
      "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065295484,
        "f": 50331777
      },
      "n": "Properties",
      "d": 524412,
      "h": 47245164668,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47245164668)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85899870332),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "SetProperty",
      "o": "@$5",
      "d": 524412,
      "h": 85899870332,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85899870332),
//--TRIMMABLE-BOUNDARY-START(81604903036),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetProperty",
      "o": "@$4",
      "d": 524412,
      "h": 81604903036,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81604903036),
//--TRIMMABLE-BOUNDARY-START(64425033852),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "SetProperty",
      "d": 524412,
      "h": 64425033852,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64425033852),
//--TRIMMABLE-BOUNDARY-START(68720001148),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 65994753
        }
      ],
      "n": "SetProperty",
      "o": "@$1",
      "d": 524412,
      "h": 68720001148,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720001148),
//--TRIMMABLE-BOUNDARY-START(73014968444),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "SetProperty",
      "o": "@$2",
      "d": 524412,
      "h": 73014968444,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73014968444),
//--TRIMMABLE-BOUNDARY-START(77309935740),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 89784321
        }
      ],
      "n": "SetProperty",
      "o": "@$3",
      "d": 524412,
      "h": 77309935740,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77309935740),
//--TRIMMABLE-BOUNDARY-START(90194837628),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetPropertyCore",
      "d": 524412,
      "h": 90194837628,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90194837628)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426300),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524412,
      "h": 12885426300,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12885426300)
  ],
  "h": 524412
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Abstractions.TelemetryEventDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Abstractions${separator}TelemetryEventDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524412)
        
        

        //--TRIMMABLE-BOUNDARY-START(458876)
        $asm.$cls(`$mia.MIA.ObservabilityConstants`, ($self) => class ObservabilityConstants
        {
            //--TRIMMABLE-BOUNDARY-START(17180328060)
            /*string*/ static Succeeded = null;
            //--TRIMMABLE-BOUNDARY-END(17180328060)
            
            //--TRIMMABLE-BOUNDARY-START(12885360764)
            /*string*/ static Duration = null;
            //--TRIMMABLE-BOUNDARY-END(12885360764)
            
            //--TRIMMABLE-BOUNDARY-START(4295426172)
            /*string*/ static ActivityId = null;
            //--TRIMMABLE-BOUNDARY-END(4295426172)
            
            //--TRIMMABLE-BOUNDARY-START(8590393468)
            /*string*/ static ClientId = null;
            //--TRIMMABLE-BOUNDARY-END(8590393468)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180328060)
                    this.Succeeded = "Succeeded";
                    //--TRIMMABLE-BOUNDARY-END(17180328060)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885360764)
                    this.Duration = "Duration";
                    //--TRIMMABLE-BOUNDARY-END(12885360764)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295426172)
                    this.ActivityId = "ActivityId";
                    //--TRIMMABLE-BOUNDARY-END(4295426172)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393468)
                    this.ClientId = "ClientId";
                    //--TRIMMABLE-BOUNDARY-END(8590393468)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 458876;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180328060),
    {
      "t": 1310721,
      "n": "Succeeded",
      "d": 458876,
      "h": 17180328060,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328060),
//--TRIMMABLE-BOUNDARY-START(12885360764),
    {
      "t": 1310721,
      "n": "Duration",
      "d": 458876,
      "h": 12885360764,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360764),
//--TRIMMABLE-BOUNDARY-START(4295426172),
    {
      "t": 1310721,
      "n": "ActivityId",
      "d": 458876,
      "h": 4295426172,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295426172),
//--TRIMMABLE-BOUNDARY-START(8590393468),
    {
      "t": 1310721,
      "n": "ClientId",
      "d": 458876,
      "h": 8590393468,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393468)
  ],
  "h": 458876
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Abstractions.ObservabilityConstants`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Abstractions${separator}ObservabilityConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458876)
        
        

        //--TRIMMABLE-BOUNDARY-START(262268)
        $asm.$cls(`$mia.MIA.LogEntry`, ($self) => class LogEntry extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770066044)
            /*EventLogLevel*/ EventLogLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(25770066044)
            
            //--TRIMMABLE-BOUNDARY-START(55834837116)
            /*string?*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(55834837116)
            
            //--TRIMMABLE-BOUNDARY-START(21475098748)
            /*string?*/ CorrelationId = null;
            //--TRIMMABLE-BOUNDARY-END(21475098748)
            
            //--TRIMMABLE-BOUNDARY-START(17180131452)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131452)
            
            //--TRIMMABLE-BOUNDARY-START(17180131452)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180131452)
            
            static $h = 262268;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770066044),
    {
      "p": 65660,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949935228,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014706300,
        "f": 83886081
      },
      "n": "EventLogLevel",
      "d": 262268,
      "h": 25770066044,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770066044),
//--TRIMMABLE-BOUNDARY-START(55834837116),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539869820,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604640892,
        "f": 83886081
      },
      "n": "Message",
      "d": 262268,
      "h": 55834837116,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837116),
//--TRIMMABLE-BOUNDARY-START(21475098748),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000636,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424771708,
        "f": 83886081
      },
      "n": "CorrelationId",
      "d": 262268,
      "h": 21475098748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098748)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131452),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262268,
      "h": 17180131452,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131452)
  ],
  "h": 262268
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Abstractions.LogEntry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Abstractions${separator}LogEntry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262268)
        
        

        //--TRIMMABLE-BOUNDARY-START(327804)
        $asm.$cls(`$mia.MIA.NullIdentityModelLogger`, ($self) => class NullIdentityModelLogger extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770131580)
            /*NullIdentityModelLogger*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(25770131580)
            
            //--TRIMMABLE-BOUNDARY-START(12885229692)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229692);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229692)
            
            //--TRIMMABLE-BOUNDARY-START(30065098876)
            /*bool */ IsEnabled(/*EventLogLevel*/ eventLogLevel)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065098876)
            
            //--TRIMMABLE-BOUNDARY-START(34360066172)
            /*void */ Log(/*LogEntry*/ entry)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34360066172)
            
            //--TRIMMABLE-BOUNDARY-START(4295098492)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.IIdentityLogger.IsEnabled(Microsoft.IdentityModel.Abstractions.EventLogLevel)
            MIA$IIdentityLogger$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098492)
            
            //--TRIMMABLE-BOUNDARY-START(8590065788)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.IIdentityLogger.Log(Microsoft.IdentityModel.Abstractions.LogEntry)
            MIA$IIdentityLogger$Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065788)
            
            //--TRIMMABLE-BOUNDARY-START(12885229692)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885229692)
            
            //--TRIMMABLE-BOUNDARY-START(8590262396)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770131580)
                    this.Instance = new $.$mia.MIA.NullIdentityModelLogger().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25770131580)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590262396)
            
            static $h = 327804;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770131580),
    {
      "p": 327804,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475164284,
        "f": 50331681
      },
      "n": "Instance",
      "d": 327804,
      "h": 25770131580,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770131580)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065098876),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventLogLevel",
          "p": 65660
        }
      ],
      "n": "IsEnabled",
      "d": 327804,
      "h": 30065098876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098876),
//--TRIMMABLE-BOUNDARY-START(34360066172),
    {
      "r": 65537,
      "p": [
        {
          "n": "entry",
          "p": 262268
        }
      ],
      "n": "Log",
      "d": 327804,
      "h": 34360066172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066172)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885229692),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327804,
      "h": 12885229692,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885229692)
  ],
  "h": 327804
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mia.MIA.IIdentityLogger ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Abstractions${separator}NullIdentityModelLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327804)
        
        

        //--TRIMMABLE-BOUNDARY-START(393340)
        $asm.$cls(`$mia.MIA.NullTelemetryClient`, ($self) => class NullTelemetryClient extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475229820)
            /*string*/ ClientId = null;
            //--TRIMMABLE-BOUNDARY-END(21475229820)
            
            //--TRIMMABLE-BOUNDARY-START(47245033596)
            /*NullTelemetryClient*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(47245033596)
            
            //--TRIMMABLE-BOUNDARY-START(17180262524)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262524)
            
            //--TRIMMABLE-BOUNDARY-START(51540000892)
            /*bool */ IsEnabled()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540000892);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540000892)
            
            //--TRIMMABLE-BOUNDARY-START(55834968188)
            /*bool */ IsEnabled$1(/*string*/ eventName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834968188);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834968188)
            
            //--TRIMMABLE-BOUNDARY-START(42950066300)
            /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950066300)
            
            //--TRIMMABLE-BOUNDARY-START(68719870076)
            /*void */ TrackEvent(/*TelemetryEventDetails*/ eventDetails)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719870076)
            
            //--TRIMMABLE-BOUNDARY-START(73014837372)
            /*void */ TrackEvent$1(/*string*/ eventName, /*IDictionary<string, string>?*/ stringProperties, /*IDictionary<string, long>?*/ longProperties, /*IDictionary<string, bool>?*/ boolProperties, /*IDictionary<string, DateTime>?*/ dateTimeProperties, /*IDictionary<string, double>?*/ doubleProperties, /*IDictionary<string, Guid>?*/ guidProperties)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73014837372)
            
            //--TRIMMABLE-BOUNDARY-START(12885098620)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.ClientId.get
            get MIA$ITelemetryClient$ClientId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ClientId;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098620)
            
            //--TRIMMABLE-BOUNDARY-START(34359935100)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.ClientId.set
            set MIA$ITelemetryClient$ClientId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ClientId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935100)
            
            //--TRIMMABLE-BOUNDARY-START(17180065916)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.Initialize()
            MIA$ITelemetryClient$Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Initialize(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180065916)
            
            //--TRIMMABLE-BOUNDARY-START(21475033212)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.IsEnabled()
            MIA$ITelemetryClient$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475033212)
            
            //--TRIMMABLE-BOUNDARY-START(25770000508)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.IsEnabled(string)
            MIA$ITelemetryClient$IsEnabled$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770000508)
            
            //--TRIMMABLE-BOUNDARY-START(38654902396)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.TrackEvent(Microsoft.IdentityModel.Abstractions.TelemetryEventDetails)
            MIA$ITelemetryClient$TrackEvent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TrackEvent(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38654902396)
            
            //--TRIMMABLE-BOUNDARY-START(42949869692)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.TrackEvent(string, System.Collections.Generic.IDictionary<string, string>?, System.Collections.Generic.IDictionary<string, long>?, System.Collections.Generic.IDictionary<string, bool>?, System.Collections.Generic.IDictionary<string, System.DateTime>?, System.Collections.Generic.IDictionary<string, double>?, System.Collections.Generic.IDictionary<string, System.Guid>?)
            MIA$ITelemetryClient$TrackEvent$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TrackEvent$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42949869692)
            
            //--TRIMMABLE-BOUNDARY-START(17180262524)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180262524)
            
            //--TRIMMABLE-BOUNDARY-START(12885295228)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(47245033596)
                    this.Instance = new $.$mia.MIA.NullTelemetryClient().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(47245033596)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885295228)
            
            static $h = 393340;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229820),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065164412,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424902780,
        "f": 83886081
      },
      "n": "ClientId",
      "d": 393340,
      "h": 21475229820,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475229820),
//--TRIMMABLE-BOUNDARY-START(47245033596),
    {
      "p": 393340,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655099004,
        "f": 50331681
      },
      "n": "Instance",
      "d": 393340,
      "h": 47245033596,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47245033596)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540000892),
    {
      "r": 262145,
      "n": "IsEnabled",
      "d": 393340,
      "h": 51540000892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540000892),
//--TRIMMABLE-BOUNDARY-START(55834968188),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        }
      ],
      "n": "IsEnabled",
      "o": "@$1",
      "d": 393340,
      "h": 55834968188,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834968188),
//--TRIMMABLE-BOUNDARY-START(42950066300),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 393340,
      "h": 42950066300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950066300),
//--TRIMMABLE-BOUNDARY-START(68719870076),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventDetails",
          "p": 524412
        }
      ],
      "n": "TrackEvent",
      "d": 393340,
      "h": 68719870076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719870076),
//--TRIMMABLE-BOUNDARY-START(73014837372),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        },
        {
          "n": "stringProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "longProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Int64).$h,
          "f": 65
        },
        {
          "n": "boolProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Boolean).$h,
          "f": 65
        },
        {
          "n": "dateTimeProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.DateTime).$h,
          "f": 65
        },
        {
          "n": "doubleProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Double).$h,
          "f": 65
        },
        {
          "n": "guidProperties",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Guid).$h,
          "f": 65
        }
      ],
      "n": "TrackEvent",
      "o": "@$1",
      "d": 393340,
      "h": 73014837372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014837372)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180262524),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393340,
      "h": 17180262524,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180262524)
  ],
  "h": 393340
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mia.MIA.ITelemetryClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Abstractions.NullTelemetryClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Abstractions${separator}NullTelemetryClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393340)
        
        

        //--TRIMMABLE-BOUNDARY-START(65660)
        $asm.$str(`$mia.MIA.EventLogLevel`, ($self) => class EventLogLevel extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static LogAlways = 0;
            static Critical = 1;
            static Error = 2;
            static Warning = 3;
            static Informational = 4;
            static Verbose = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(65660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "LogAlways": 0n,
                    "Critical": 1n,
                    "Error": 2n,
                    "Warning": 3n,
                    "Informational": 4n,
                    "Verbose": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295032956)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032956)
            
            //--TRIMMABLE-BOUNDARY-START(4295032956)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032956)
            
            static $h = 65660;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21474902140),
    {
      "t": 65660,
      "n": "LogAlways",
      "d": 65660,
      "h": 21474902140,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474902140),
//--TRIMMABLE-BOUNDARY-START(8590000252),
    {
      "t": 65660,
      "n": "Critical",
      "d": 65660,
      "h": 8590000252,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000252),
//--TRIMMABLE-BOUNDARY-START(12884967548),
    {
      "t": 65660,
      "n": "Error",
      "d": 65660,
      "h": 12884967548,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967548),
//--TRIMMABLE-BOUNDARY-START(30064836732),
    {
      "t": 65660,
      "n": "Warning",
      "d": 65660,
      "h": 30064836732,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064836732),
//--TRIMMABLE-BOUNDARY-START(17179934844),
    {
      "t": 65660,
      "n": "Informational",
      "d": 65660,
      "h": 17179934844,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17179934844),
//--TRIMMABLE-BOUNDARY-START(25769869436),
    {
      "t": 65660,
      "n": "Verbose",
      "d": 65660,
      "h": 25769869436,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769869436)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032956),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65660,
      "h": 4295032956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032956)
  ],
  "h": 65660
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Abstractions.EventLogLevel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Abstractions${separator}EventLogLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65660)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib"));
})();
//--TRIMMABLE-BOUNDARY-END(124)
