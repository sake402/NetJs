
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.Abstractions", 
    {"h":63876,"f":"Microsoft.IdentityModel.Abstractions","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"Serviceable","t":1310721},{"v":"True","t":1310721}]},{"t":23527425,"c":8613462017,"a":[{"v":true,"t":262145}]},{"t":102432769,"c":4397400065,"a":[{"v":false,"t":262145}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsAotCompatible","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"Microsoft Corporation.","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":73793537,"c":4368760833,"a":[{"v":"\u00A9 Microsoft Corporation. All rights reserved.","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"A package containing thin abstractions for Microsoft.IdentityModel.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"9.0.0.26241","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft IdentityModel","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.IdentityModel.Abstractions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"RepositoryUrl","t":1310721},{"v":"https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.IIdentityLogger", ($self) => class IIdentityLogger
        {
            static $h = 194948;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"eventLogLevel","p":129412}],"n":"IsEnabled","o":"Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled","d":194948,"h":4295162244,"f":16777473},{"r":65537,"p":[{"n":"entry","p":326020}],"n":"Log","o":"Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log","d":194948,"h":8590129540,"f":16777473}],"h":194948}; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.IIdentityLogger`; }
        });
        
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.ITelemetryClient", ($self) => class ITelemetryClient
        {
            static $h = 260484;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590195076,"f":50331905},"s":{"r":0,"d":0,"h":12885162372,"f":83886337},"n":"ClientId","o":"Microsoft$IdentityModel$Abstractions$ITelemetryClient$ClientId","d":260484,"h":4295227780,"f":2097409}],"m":[{"r":65537,"n":"Initialize","o":"Microsoft$IdentityModel$Abstractions$ITelemetryClient$Initialize","d":260484,"h":17180129668,"f":16777473},{"r":262145,"n":"IsEnabled","o":"Microsoft$IdentityModel$Abstractions$ITelemetryClient$IsEnabled","d":260484,"h":21475096964,"f":16777473},{"r":262145,"p":[{"n":"eventName","p":1310721}],"n":"IsEnabled","o":"Microsoft$IdentityModel$Abstractions$ITelemetryClient$IsEnabled$1","d":260484,"h":25770064260,"f":16777473},{"r":65537,"p":[{"n":"eventDetails","p":588164}],"n":"TrackEvent","o":"Microsoft$IdentityModel$Abstractions$ITelemetryClient$TrackEvent$1","d":260484,"h":30065031556,"f":16777473},{"r":65537,"p":[{"n":"eventName","p":1310721},{"n":"stringProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"f":65},{"n":"longProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Int64).$h,"f":65},{"n":"boolProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Boolean).$h,"f":65},{"n":"dateTimeProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.DateTime).$h,"f":65},{"n":"doubleProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Double).$h,"f":65},{"n":"guidProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Guid).$h,"f":65}],"n":"TrackEvent","o":"Microsoft$IdentityModel$Abstractions$ITelemetryClient$TrackEvent","d":260484,"h":34359998852,"f":16777473}],"h":260484}; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.ITelemetryClient`; }
        });
        
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.TelemetryEventDetails", ($self) => class TelemetryEventDetails extends $.$$.System.Object
        {
            /*IDictionary<string, object>*/ PropertyValues = null;
            /*string?*/ Name = null;
            /*IReadOnlyDictionary<string, object> */ get Properties()
            {
                return $.$cast(this.PropertyValues, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object));
            }
            /*void */ SetProperty$5(/*string*/ key, /*string*/ value)
            {
                this.SetPropertyCore(key, value);
            }
            /*void */ SetProperty$4(/*string*/ key, /*long*/ value)
            {
                this.SetPropertyCore(key, $.$box(value, $.$$.System.Int64));
            }
            /*void */ SetProperty(/*string*/ key, /*bool*/ value)
            {
                this.SetPropertyCore(key, $.$box(value, $.$$.System.Boolean));
            }
            /*void */ SetProperty$1(/*string*/ key, /*DateTime*/ value)
            {
                this.SetPropertyCore(key, value);
            }
            /*void */ SetProperty$2(/*string*/ key, /*double*/ value)
            {
                this.SetPropertyCore(key, $.$box(value, $.$$.System.Double));
            }
            /*void */ SetProperty$3(/*string*/ key, /*Guid*/ value)
            {
                this.SetPropertyCore(key, value);
            }
            /*void */ SetPropertyCore(/*string*/ key, /*object*/ value)
            {
                if ($.$$.System.String.op_Equality(key, null))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("key");
                }
                this.PropertyValues.System$Collections$Generic$IDictionary$$$$set_Item(key, value, [$.$$.System.String, $.$$.System.Object]);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PropertyValues = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
            }
            static $h = 588164;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":12885490052,"f":50331664},"n":"PropertyValues","d":588164,"h":8590522756,"f":2097168},{"p":1310721,"g":{"r":0,"d":0,"h":25770391940,"f":50331777},"s":{"r":0,"d":0,"h":30065359236,"f":83886209},"n":"Name","d":588164,"h":21475424644,"f":2097281},{"p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":38655293828,"f":50331777},"n":"Properties","d":588164,"h":34360326532,"f":2097281}],"m":[{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"SetProperty","o":"@$5","d":588164,"h":42950261124,"f":16777345},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":917505}],"n":"SetProperty","o":"@$4","d":588164,"h":47245228420,"f":16777345},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":262145}],"n":"SetProperty","d":588164,"h":51540195716,"f":16777345},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":34275329}],"n":"SetProperty","o":"@$1","d":588164,"h":55835163012,"f":16777345},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":1179649}],"n":"SetProperty","o":"@$2","d":588164,"h":60130130308,"f":16777345},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":56229889}],"n":"SetProperty","o":"@$3","d":588164,"h":64425097604,"f":16777345},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":131073}],"n":"SetPropertyCore","d":588164,"h":68720064900,"f":16777218}],"c":[{"n":".ctor","o":"$ctor$1","d":588164,"h":73015032196,"f":16777220}],"h":588164}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.TelemetryEventDetails`; }
        });
        
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.LogEntry", ($self) => class LogEntry extends $.$$.System.Object
        {
            /*EventLogLevel*/ EventLogLevel = 0;
            /*string?*/ Message = null;
            /*string?*/ CorrelationId = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.EventLogLevel = 0;
            }
            static $h = 326020;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":129412,"g":{"r":0,"d":0,"h":12885227908,"f":50331649},"s":{"r":0,"d":0,"h":17180195204,"f":83886081},"n":"EventLogLevel","d":326020,"h":8590260612,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065097092,"f":50331649},"s":{"r":0,"d":0,"h":34360064388,"f":83886081},"n":"Message","d":326020,"h":25770129796,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47244966276,"f":50331649},"s":{"r":0,"d":0,"h":51539933572,"f":83886081},"n":"CorrelationId","d":326020,"h":42949998980,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":326020,"h":55834900868,"f":16777217}],"h":326020}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.LogEntry`; }
        });
        
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.ObservabilityConstants", ($self) => class ObservabilityConstants
        {
            /*string*/ static Succeeded = null;
            /*string*/ static Duration = null;
            /*string*/ static ActivityId = null;
            /*string*/ static ClientId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Succeeded = "Succeeded";
                }
                {
                    this.Duration = "Duration";
                }
                {
                    this.ActivityId = "ActivityId";
                }
                {
                    this.ClientId = "ClientId";
                }
            }
            static $h = 522628;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Succeeded","d":522628,"h":4295489924,"f":4194337},{"t":1310721,"n":"Duration","d":522628,"h":8590457220,"f":4194337},{"t":1310721,"n":"ActivityId","d":522628,"h":12885424516,"f":4194337},{"t":1310721,"n":"ClientId","d":522628,"h":17180391812,"f":4194337}],"h":522628}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.ObservabilityConstants`; }
        });
        
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.NullTelemetryClient", ($self) => class NullTelemetryClient extends $.$$.System.Object
        {
            /*string*/ ClientId = null;
            /*NullTelemetryClient*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ IsEnabled()
            {
                return false;
            }
            /*bool */ IsEnabled$1(/*string*/ eventName)
            {
                return false;
            }
            /*void */ Initialize()
            {
            }
            /*void */ TrackEvent$1(/*TelemetryEventDetails*/ eventDetails)
            {
            }
            /*void */ TrackEvent(/*string*/ eventName, /*IDictionary<string, string>?*/ stringProperties, /*IDictionary<string, long>?*/ longProperties, /*IDictionary<string, bool>?*/ boolProperties, /*IDictionary<string, DateTime>?*/ dateTimeProperties, /*IDictionary<string, double>?*/ doubleProperties, /*IDictionary<string, Guid>?*/ guidProperties)
            {
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.ClientId.get
            get Microsoft$IdentityModel$Abstractions$ITelemetryClient$ClientId()
            {
                return this.ClientId;
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.ClientId.set
            set Microsoft$IdentityModel$Abstractions$ITelemetryClient$ClientId(value)
            {
                this.ClientId = value;
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.Initialize()
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$Initialize()
            {
                return this.Initialize(...arguments);
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.IsEnabled()
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$IsEnabled()
            {
                return this.IsEnabled(...arguments);
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.IsEnabled(string)
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$IsEnabled$1()
            {
                return this.IsEnabled$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.TrackEvent(Microsoft.IdentityModel.Abstractions.TelemetryEventDetails)
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$TrackEvent$1()
            {
                return this.TrackEvent$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.TrackEvent(string, System.Collections.Generic.IDictionary<string, string>?, System.Collections.Generic.IDictionary<string, long>?, System.Collections.Generic.IDictionary<string, bool>?, System.Collections.Generic.IDictionary<string, System.DateTime>?, System.Collections.Generic.IDictionary<string, double>?, System.Collections.Generic.IDictionary<string, System.Guid>?)
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$TrackEvent()
            {
                return this.TrackEvent(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mia.Microsoft.IdentityModel.Abstractions.NullTelemetryClient().$ctor$1();
                }
            }
            static $h = 457092;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885358980,"f":50331649},"s":{"r":0,"d":0,"h":17180326276,"f":83886081},"n":"ClientId","d":457092,"h":8590391684,"f":2097153},{"p":457092,"g":{"r":0,"d":0,"h":30065228164,"f":50331681},"n":"Instance","d":457092,"h":25770260868,"f":2097185}],"m":[{"r":262145,"n":"IsEnabled","d":457092,"h":38655162756,"f":16777217},{"r":262145,"p":[{"n":"eventName","p":1310721}],"n":"IsEnabled","o":"@$1","d":457092,"h":42950130052,"f":16777217},{"r":65537,"n":"Initialize","d":457092,"h":47245097348,"f":16777217},{"r":65537,"p":[{"n":"eventDetails","p":588164}],"n":"TrackEvent","o":"@$1","d":457092,"h":51540064644,"f":16777217},{"r":65537,"p":[{"n":"eventName","p":1310721},{"n":"stringProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"f":65},{"n":"longProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Int64).$h,"f":65},{"n":"boolProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Boolean).$h,"f":65},{"n":"dateTimeProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.DateTime).$h,"f":65},{"n":"doubleProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Double).$h,"f":65},{"n":"guidProperties","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Guid).$h,"f":65}],"n":"TrackEvent","d":457092,"h":55835031940,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":457092,"h":34360195460,"f":16777218}],"i":[260484],"h":457092}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mia.Microsoft.IdentityModel.Abstractions.ITelemetryClient ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.NullTelemetryClient`; }
        });
        
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger", ($self) => class NullIdentityModelLogger extends $.$$.System.Object
        {
            /*NullIdentityModelLogger*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ IsEnabled(/*EventLogLevel*/ eventLogLevel)
            {
                return false;
            }
            /*void */ Log(/*LogEntry*/ entry)
            {
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.IIdentityLogger.IsEnabled(Microsoft.IdentityModel.Abstractions.EventLogLevel)
            Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled()
            {
                return this.IsEnabled(...arguments);
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.IIdentityLogger.Log(Microsoft.IdentityModel.Abstractions.LogEntry)
            Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log()
            {
                return this.Log(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mia.Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger().$ctor$1();
                }
            }
            static $h = 391556;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":391556,"g":{"r":0,"d":0,"h":12885293444,"f":50331681},"n":"Instance","d":391556,"h":8590326148,"f":2097185}],"m":[{"r":262145,"p":[{"n":"eventLogLevel","p":129412}],"n":"IsEnabled","d":391556,"h":21475228036,"f":16777217},{"r":65537,"p":[{"n":"entry","p":326020}],"n":"Log","d":391556,"h":25770195332,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":391556,"h":17180260740,"f":16777218}],"i":[194948],"h":391556}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mia.Microsoft.IdentityModel.Abstractions.IIdentityLogger ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger`; }
        });
        
        $asm.$str("$mia.Microsoft.IdentityModel.Abstractions.EventLogLevel", ($self) => class EventLogLevel extends $.$$.System.Enum
        {
            static LogAlways = 0;
            static Critical = 1;
            static Error = 2;
            static Warning = 3;
            static Informational = 4;
            static Verbose = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "LogAlways": 0n,
                    "Critical": 1n,
                    "Error": 2n,
                    "Warning": 3n,
                    "Informational": 4n,
                    "Verbose": 5n
                };
            }
            static $h = 129412;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":129412,"n":"LogAlways","d":129412,"h":4295096708,"f":4194337},{"t":129412,"n":"Critical","d":129412,"h":8590064004,"f":4194337},{"t":129412,"n":"Error","d":129412,"h":12885031300,"f":4194337},{"t":129412,"n":"Warning","d":129412,"h":17179998596,"f":4194337},{"t":129412,"n":"Informational","d":129412,"h":21474965892,"f":4194337},{"t":129412,"n":"Verbose","d":129412,"h":25769933188,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":129412,"h":30064900484,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":129412}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.EventLogLevel`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))