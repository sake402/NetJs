
//--TRIMMABLE-BOUNDARY-START(117)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.Abstractions", 
    {
  "h": 117,
  "f": "Microsoft.IdentityModel.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "Serviceable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 139919361,
      "c": 4434886657,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsAotCompatible",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "Microsoft Corporation.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 4401463297,
      "a": [
        {
          "v": "\u00A9 Microsoft Corporation. All rights reserved.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "A package containing thin abstractions for Microsoft.IdentityModel.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "9.0.0.26247",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "Microsoft IdentityModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.IdentityModel.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131189)
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.IIdentityLogger", ($self) => class IIdentityLogger
        {
            static $h = 131189;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098485),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventLogLevel",
          "p": 65653
        }
      ],
      "n": "IsEnabled",
      "o": "Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled",
      "d": 131189,
      "h": 4295098485,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098485),
//--TRIMMABLE-BOUNDARY-START(8590065781),
    {
      "r": 65537,
      "p": [
        {
          "n": "entry",
          "p": 262261
        }
      ],
      "n": "Log",
      "o": "Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log",
      "d": 131189,
      "h": 8590065781,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590065781)
  ],
  "h": 131189
}; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.IIdentityLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131189)
        
        
        //--TRIMMABLE-BOUNDARY-START(196725)
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.ITelemetryClient", ($self) => class ITelemetryClient
        {
            static $h = 196725;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295164021),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885098613,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34359935093,
        "f": 83886337
      },
      "n": "ClientId",
      "o": "Microsoft$IdentityModel$Abstractions$ITelemetryClient$ClientId",
      "d": 196725,
      "h": 4295164021,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295164021)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065909),
    {
      "r": 65537,
      "n": "Initialize",
      "o": "Microsoft$IdentityModel$Abstractions$ITelemetryClient$Initialize",
      "d": 196725,
      "h": 17180065909,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180065909),
//--TRIMMABLE-BOUNDARY-START(21475033205),
    {
      "r": 262145,
      "n": "IsEnabled",
      "o": "Microsoft$IdentityModel$Abstractions$ITelemetryClient$IsEnabled",
      "d": 196725,
      "h": 21475033205,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475033205),
//--TRIMMABLE-BOUNDARY-START(25770000501),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        }
      ],
      "n": "IsEnabled",
      "o": "Microsoft$IdentityModel$Abstractions$ITelemetryClient$IsEnabled$1",
      "d": 196725,
      "h": 25770000501,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770000501),
//--TRIMMABLE-BOUNDARY-START(38654902389),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventDetails",
          "p": 524405
        }
      ],
      "n": "TrackEvent",
      "o": "Microsoft$IdentityModel$Abstractions$ITelemetryClient$TrackEvent$1",
      "d": 196725,
      "h": 38654902389,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38654902389),
//--TRIMMABLE-BOUNDARY-START(42949869685),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        },
        {
          "n": "stringProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
          "f": 65
        },
        {
          "n": "longProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Int64).$h,
          "f": 65
        },
        {
          "n": "boolProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Boolean).$h,
          "f": 65
        },
        {
          "n": "dateTimeProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.DateTime).$h,
          "f": 65
        },
        {
          "n": "doubleProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Double).$h,
          "f": 65
        },
        {
          "n": "guidProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Guid).$h,
          "f": 65
        }
      ],
      "n": "TrackEvent",
      "o": "Microsoft$IdentityModel$Abstractions$ITelemetryClient$TrackEvent",
      "d": 196725,
      "h": 42949869685,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42949869685)
  ],
  "h": 196725
}; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.ITelemetryClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196725)
        
        
        //--TRIMMABLE-BOUNDARY-START(524405)
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.TelemetryEventDetails", ($self) => class TelemetryEventDetails extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540131957)
            /*IDictionary<string, object>*/ PropertyValues = null;
            //--TRIMMABLE-BOUNDARY-END(51540131957)
            
            //--TRIMMABLE-BOUNDARY-START(42950197365)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(42950197365)
            
            //--TRIMMABLE-BOUNDARY-START(47245164661)
            /*IReadOnlyDictionary<string, object> */ get Properties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this.PropertyValues, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(47245164661)
            
            //--TRIMMABLE-BOUNDARY-START(64425033845)
            /*void */ SetProperty$5(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425033845)
            
            //--TRIMMABLE-BOUNDARY-START(68720001141)
            /*void */ SetProperty$4(/*string*/ key, /*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, $.$box(value, $.$$.System.Int64));
            }
            //--TRIMMABLE-BOUNDARY-END(68720001141)
            
            //--TRIMMABLE-BOUNDARY-START(73014968437)
            /*void */ SetProperty(/*string*/ key, /*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, $.$box(value, $.$$.System.Boolean));
            }
            //--TRIMMABLE-BOUNDARY-END(73014968437)
            
            //--TRIMMABLE-BOUNDARY-START(77309935733)
            /*void */ SetProperty$1(/*string*/ key, /*DateTime*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(77309935733)
            
            //--TRIMMABLE-BOUNDARY-START(81604903029)
            /*void */ SetProperty$2(/*string*/ key, /*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604903029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, $.$box(value, $.$$.System.Double));
            }
            //--TRIMMABLE-BOUNDARY-END(81604903029)
            
            //--TRIMMABLE-BOUNDARY-START(85899870325)
            /*void */ SetProperty$3(/*string*/ key, /*Guid*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899870325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetPropertyCore(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(85899870325)
            
            //--TRIMMABLE-BOUNDARY-START(90194837621)
            /*void */ SetPropertyCore(/*string*/ key, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(key, null))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("key");
                }
                this.PropertyValues.System$Collections$Generic$IDictionary$$$$set_Item(key, value, [$.$$.System.String, $.$$.System.Object]);
            }
            //--TRIMMABLE-BOUNDARY-END(90194837621)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PropertyValues = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
            }
            static $h = 524405;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540131957),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655230069,
        "f": 50331664
      },
      "n": "PropertyValues",
      "d": 524405,
      "h": 51540131957,
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(51540131957),
//--TRIMMABLE-BOUNDARY-START(42950197365),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360885,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130066549,
        "f": 83886209
      },
      "n": "Name",
      "d": 524405,
      "h": 42950197365,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(42950197365),
//--TRIMMABLE-BOUNDARY-START(47245164661),
    {
      "p": $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065295477,
        "f": 50331777
      },
      "n": "Properties",
      "d": 524405,
      "h": 47245164661,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47245164661)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425033845),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "SetProperty",
      "o": "@$5",
      "d": 524405,
      "h": 64425033845,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64425033845),
//--TRIMMABLE-BOUNDARY-START(68720001141),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetProperty",
      "o": "@$4",
      "d": 524405,
      "h": 68720001141,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720001141),
//--TRIMMABLE-BOUNDARY-START(73014968437),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "SetProperty",
      "d": 524405,
      "h": 73014968437,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73014968437),
//--TRIMMABLE-BOUNDARY-START(77309935733),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 65142785
        }
      ],
      "n": "SetProperty",
      "o": "@$1",
      "d": 524405,
      "h": 77309935733,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77309935733),
//--TRIMMABLE-BOUNDARY-START(81604903029),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "SetProperty",
      "o": "@$2",
      "d": 524405,
      "h": 81604903029,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81604903029),
//--TRIMMABLE-BOUNDARY-START(85899870325),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 88866817
        }
      ],
      "n": "SetProperty",
      "o": "@$3",
      "d": 524405,
      "h": 85899870325,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85899870325),
//--TRIMMABLE-BOUNDARY-START(90194837621),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetPropertyCore",
      "d": 524405,
      "h": 90194837621,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90194837621)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491701),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524405,
      "h": 4295491701,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295491701)
  ],
  "h": 524405
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.TelemetryEventDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524405)
        
        
        //--TRIMMABLE-BOUNDARY-START(262261)
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.LogEntry", ($self) => class LogEntry extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770066037)
            /*EventLogLevel*/ EventLogLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(25770066037)
            
            //--TRIMMABLE-BOUNDARY-START(55834837109)
            /*string?*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(55834837109)
            
            //--TRIMMABLE-BOUNDARY-START(21475098741)
            /*string?*/ CorrelationId = null;
            //--TRIMMABLE-BOUNDARY-END(21475098741)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 262261;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770066037),
    {
      "p": 65653,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949935221,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014706293,
        "f": 83886081
      },
      "n": "EventLogLevel",
      "d": 262261,
      "h": 25770066037,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770066037),
//--TRIMMABLE-BOUNDARY-START(55834837109),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539869813,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604640885,
        "f": 83886081
      },
      "n": "Message",
      "d": 262261,
      "h": 55834837109,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837109),
//--TRIMMABLE-BOUNDARY-START(21475098741),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000629,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424771701,
        "f": 83886081
      },
      "n": "CorrelationId",
      "d": 262261,
      "h": 21475098741,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098741)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229557),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262261,
      "h": 4295229557,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229557)
  ],
  "h": 262261
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.LogEntry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262261)
        
        
        //--TRIMMABLE-BOUNDARY-START(458869)
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.ObservabilityConstants", ($self) => class ObservabilityConstants
        {
            //--TRIMMABLE-BOUNDARY-START(17180328053)
            /*string*/ static Succeeded = null;
            //--TRIMMABLE-BOUNDARY-END(17180328053)
            
            //--TRIMMABLE-BOUNDARY-START(12885360757)
            /*string*/ static Duration = null;
            //--TRIMMABLE-BOUNDARY-END(12885360757)
            
            //--TRIMMABLE-BOUNDARY-START(4295426165)
            /*string*/ static ActivityId = null;
            //--TRIMMABLE-BOUNDARY-END(4295426165)
            
            //--TRIMMABLE-BOUNDARY-START(8590393461)
            /*string*/ static ClientId = null;
            //--TRIMMABLE-BOUNDARY-END(8590393461)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180328053)
                    this.Succeeded = "Succeeded";
                    //--TRIMMABLE-BOUNDARY-END(17180328053)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885360757)
                    this.Duration = "Duration";
                    //--TRIMMABLE-BOUNDARY-END(12885360757)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295426165)
                    this.ActivityId = "ActivityId";
                    //--TRIMMABLE-BOUNDARY-END(4295426165)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393461)
                    this.ClientId = "ClientId";
                    //--TRIMMABLE-BOUNDARY-END(8590393461)
                    
                }
            }
            static $h = 458869;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180328053),
    {
      "t": 1310721,
      "n": "Succeeded",
      "d": 458869,
      "h": 17180328053,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328053),
//--TRIMMABLE-BOUNDARY-START(12885360757),
    {
      "t": 1310721,
      "n": "Duration",
      "d": 458869,
      "h": 12885360757,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360757),
//--TRIMMABLE-BOUNDARY-START(4295426165),
    {
      "t": 1310721,
      "n": "ActivityId",
      "d": 458869,
      "h": 4295426165,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295426165),
//--TRIMMABLE-BOUNDARY-START(8590393461),
    {
      "t": 1310721,
      "n": "ClientId",
      "d": 458869,
      "h": 8590393461,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393461)
  ],
  "h": 458869
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.ObservabilityConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458869)
        
        
        //--TRIMMABLE-BOUNDARY-START(327797)
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger", ($self) => class NullIdentityModelLogger extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770131573)
            /*NullIdentityModelLogger*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(25770131573)
            
            //--TRIMMABLE-BOUNDARY-START(8590262389)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262389);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262389)
            
            //--TRIMMABLE-BOUNDARY-START(30065098869)
            /*bool */ IsEnabled(/*EventLogLevel*/ eventLogLevel)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098869);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065098869)
            
            //--TRIMMABLE-BOUNDARY-START(34360066165)
            /*void */ Log(/*LogEntry*/ entry)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34360066165)
            
            //--TRIMMABLE-BOUNDARY-START(4295098485)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.IIdentityLogger.IsEnabled(Microsoft.IdentityModel.Abstractions.EventLogLevel)
            Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098485)
            
            //--TRIMMABLE-BOUNDARY-START(8590065781)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.IIdentityLogger.Log(Microsoft.IdentityModel.Abstractions.LogEntry)
            Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065781)
            
            //--TRIMMABLE-BOUNDARY-START(4295295093)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mia.Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295295093)
            
            static $h = 327797;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770131573),
    {
      "p": 327797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475164277,
        "f": 50331681
      },
      "n": "Instance",
      "d": 327797,
      "h": 25770131573,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770131573)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065098869),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventLogLevel",
          "p": 65653
        }
      ],
      "n": "IsEnabled",
      "d": 327797,
      "h": 30065098869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098869),
//--TRIMMABLE-BOUNDARY-START(34360066165),
    {
      "r": 65537,
      "p": [
        {
          "n": "entry",
          "p": 262261
        }
      ],
      "n": "Log",
      "d": 327797,
      "h": 34360066165,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066165)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262389),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327797,
      "h": 8590262389,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590262389)
  ],
  "i": [131189
  ],
  "h": 327797
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mia.Microsoft.IdentityModel.Abstractions.IIdentityLogger ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327797)
        
        
        //--TRIMMABLE-BOUNDARY-START(393333)
        $asm.$cls("$mia.Microsoft.IdentityModel.Abstractions.NullTelemetryClient", ($self) => class NullTelemetryClient extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475229813)
            /*string*/ ClientId = null;
            //--TRIMMABLE-BOUNDARY-END(21475229813)
            
            //--TRIMMABLE-BOUNDARY-START(47245033589)
            /*NullTelemetryClient*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(47245033589)
            
            //--TRIMMABLE-BOUNDARY-START(8590327925)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327925);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327925)
            
            //--TRIMMABLE-BOUNDARY-START(51540000885)
            /*bool */ IsEnabled()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540000885);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540000885)
            
            //--TRIMMABLE-BOUNDARY-START(55834968181)
            /*bool */ IsEnabled$1(/*string*/ eventName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834968181);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834968181)
            
            //--TRIMMABLE-BOUNDARY-START(42950066293)
            /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950066293)
            
            //--TRIMMABLE-BOUNDARY-START(68719870069)
            /*void */ TrackEvent$1(/*TelemetryEventDetails*/ eventDetails)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719870069)
            
            //--TRIMMABLE-BOUNDARY-START(73014837365)
            /*void */ TrackEvent(/*string*/ eventName, /*IDictionary<string, string>?*/ stringProperties, /*IDictionary<string, long>?*/ longProperties, /*IDictionary<string, bool>?*/ boolProperties, /*IDictionary<string, DateTime>?*/ dateTimeProperties, /*IDictionary<string, double>?*/ doubleProperties, /*IDictionary<string, Guid>?*/ guidProperties)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73014837365)
            
            //--TRIMMABLE-BOUNDARY-START(12885098613)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.ClientId.get
            get Microsoft$IdentityModel$Abstractions$ITelemetryClient$ClientId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ClientId;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098613)
            
            //--TRIMMABLE-BOUNDARY-START(34359935093)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.ClientId.set
            set Microsoft$IdentityModel$Abstractions$ITelemetryClient$ClientId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ClientId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935093)
            
            //--TRIMMABLE-BOUNDARY-START(17180065909)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.Initialize()
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Initialize(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180065909)
            
            //--TRIMMABLE-BOUNDARY-START(21475033205)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.IsEnabled()
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475033205)
            
            //--TRIMMABLE-BOUNDARY-START(25770000501)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.IsEnabled(string)
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$IsEnabled$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770000501)
            
            //--TRIMMABLE-BOUNDARY-START(38654902389)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.TrackEvent(Microsoft.IdentityModel.Abstractions.TelemetryEventDetails)
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$TrackEvent$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TrackEvent$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38654902389)
            
            //--TRIMMABLE-BOUNDARY-START(42949869685)
            //Generated interface implemetation for Microsoft.IdentityModel.Abstractions.ITelemetryClient.TrackEvent(string, System.Collections.Generic.IDictionary<string, string>?, System.Collections.Generic.IDictionary<string, long>?, System.Collections.Generic.IDictionary<string, bool>?, System.Collections.Generic.IDictionary<string, System.DateTime>?, System.Collections.Generic.IDictionary<string, double>?, System.Collections.Generic.IDictionary<string, System.Guid>?)
            Microsoft$IdentityModel$Abstractions$ITelemetryClient$TrackEvent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TrackEvent(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42949869685)
            
            //--TRIMMABLE-BOUNDARY-START(4295360629)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mia.Microsoft.IdentityModel.Abstractions.NullTelemetryClient().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360629)
            
            static $h = 393333;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229813),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065164405,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424902773,
        "f": 83886081
      },
      "n": "ClientId",
      "d": 393333,
      "h": 21475229813,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475229813),
//--TRIMMABLE-BOUNDARY-START(47245033589),
    {
      "p": 393333,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655098997,
        "f": 50331681
      },
      "n": "Instance",
      "d": 393333,
      "h": 47245033589,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47245033589)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540000885),
    {
      "r": 262145,
      "n": "IsEnabled",
      "d": 393333,
      "h": 51540000885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540000885),
//--TRIMMABLE-BOUNDARY-START(55834968181),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        }
      ],
      "n": "IsEnabled",
      "o": "@$1",
      "d": 393333,
      "h": 55834968181,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834968181),
//--TRIMMABLE-BOUNDARY-START(42950066293),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 393333,
      "h": 42950066293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950066293),
//--TRIMMABLE-BOUNDARY-START(68719870069),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventDetails",
          "p": 524405
        }
      ],
      "n": "TrackEvent",
      "o": "@$1",
      "d": 393333,
      "h": 68719870069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719870069),
//--TRIMMABLE-BOUNDARY-START(73014837365),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        },
        {
          "n": "stringProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
          "f": 65
        },
        {
          "n": "longProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Int64).$h,
          "f": 65
        },
        {
          "n": "boolProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Boolean).$h,
          "f": 65
        },
        {
          "n": "dateTimeProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.DateTime).$h,
          "f": 65
        },
        {
          "n": "doubleProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Double).$h,
          "f": 65
        },
        {
          "n": "guidProperties",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Guid).$h,
          "f": 65
        }
      ],
      "n": "TrackEvent",
      "d": 393333,
      "h": 73014837365,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014837365)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327925),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393333,
      "h": 8590327925,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590327925)
  ],
  "i": [196725
  ],
  "h": 393333
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mia.Microsoft.IdentityModel.Abstractions.ITelemetryClient ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.NullTelemetryClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393333)
        
        
        //--TRIMMABLE-BOUNDARY-START(65653)
        $asm.$str("$mia.Microsoft.IdentityModel.Abstractions.EventLogLevel", ($self) => class EventLogLevel extends $.$$.System.Enum
        {
            static LogAlways = 0;
            static Critical = 1;
            static Error = 2;
            static Warning = 3;
            static Informational = 4;
            static Verbose = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(65653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "LogAlways": 0n,
                    "Critical": 1n,
                    "Error": 2n,
                    "Warning": 3n,
                    "Informational": 4n,
                    "Verbose": 5n
                };
            }
            static $h = 65653;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21474902133),
    {
      "t": 65653,
      "n": "LogAlways",
      "d": 65653,
      "h": 21474902133,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474902133),
//--TRIMMABLE-BOUNDARY-START(8590000245),
    {
      "t": 65653,
      "n": "Critical",
      "d": 65653,
      "h": 8590000245,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000245),
//--TRIMMABLE-BOUNDARY-START(12884967541),
    {
      "t": 65653,
      "n": "Error",
      "d": 65653,
      "h": 12884967541,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967541),
//--TRIMMABLE-BOUNDARY-START(30064836725),
    {
      "t": 65653,
      "n": "Warning",
      "d": 65653,
      "h": 30064836725,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064836725),
//--TRIMMABLE-BOUNDARY-START(17179934837),
    {
      "t": 65653,
      "n": "Informational",
      "d": 65653,
      "h": 17179934837,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17179934837),
//--TRIMMABLE-BOUNDARY-START(25769869429),
    {
      "t": 65653,
      "n": "Verbose",
      "d": 65653,
      "h": 25769869429,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769869429)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032949),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65653,
      "h": 4295032949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032949)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 65653
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Abstractions.EventLogLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65653)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(117)
