
//--TRIMMABLE-BOUNDARY-START(127)
(async function () {
(function ($global, $, $$, $mia, $sc, $sm, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mil, $scm, $so, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $mexla, $mep, $scp, $scs, $sdp, $srw, $srl, $srsf, $str, $sdts, $spx, $spxl, $sxxd, $sct, $sca, $meo, $mexl, $sipl, $stew, $stj, $mit) {
    "use strict";
    let _;
    let $ybJkji;
    let $oeAxXc;
    let $eMZQTd;
    let $XYcHok;
    let $MmlvHh;
    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.JsonWebTokens", 
    {
  "h": 127,
  "f": "Microsoft.IdentityModel.JsonWebTokens",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsAotCompatible",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "Microsoft Corporation.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107347969,
      "c": 8697282561,
      "a": [
        {
          "v": "\u00A9 Microsoft Corporation. All rights reserved.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Includes types that provide support for creating, serializing and validating JSON Web Tokens. This is a newer, faster version of System.IdentityModel.Tokens.Jwt that has additional functionality.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "9.0.0.26312",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "Microsoft IdentityModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.IdentityModel.JsonWebTokens",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "NetJs.System.IdentityModel.Tokens.Jwt",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "Serviceable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 140836865,
      "c": 8730771457,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.JsonWebTokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Protocols.SignedHttpRequest, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "System.IdentityModel.Tokens.Jwt, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "System.IdentityModel.Tokens.Jwt.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tokens, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Benchmarks, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Validators, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.JsonWebTokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.TestUtils, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196735)
        $asm.$cls(`$mij.MIJ.JsonClaimValueTypes`, ($self) => class JsonClaimValueTypes
        {
            //--TRIMMABLE-BOUNDARY-START(4295164031)
            /*string*/ static Json = null;
            //--TRIMMABLE-BOUNDARY-END(4295164031)
            
            //--TRIMMABLE-BOUNDARY-START(8590131327)
            /*string*/ static JsonArray = null;
            //--TRIMMABLE-BOUNDARY-END(8590131327)
            
            //--TRIMMABLE-BOUNDARY-START(12885098623)
            /*string*/ static JsonNull = null;
            //--TRIMMABLE-BOUNDARY-END(12885098623)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295164031)
                    this.Json = "JSON";
                    //--TRIMMABLE-BOUNDARY-END(4295164031)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590131327)
                    this.JsonArray = "JSON_ARRAY";
                    //--TRIMMABLE-BOUNDARY-END(8590131327)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885098623)
                    this.JsonNull = "JSON_NULL";
                    //--TRIMMABLE-BOUNDARY-END(12885098623)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 196735;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295164031),
    {
      "t": 1310721,
      "n": "Json",
      "d": 196735,
      "h": 4295164031,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295164031),
//--TRIMMABLE-BOUNDARY-START(8590131327),
    {
      "t": 1310721,
      "n": "JsonArray",
      "d": 196735,
      "h": 8590131327,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131327),
//--TRIMMABLE-BOUNDARY-START(12885098623),
    {
      "t": 1310721,
      "n": "JsonNull",
      "d": 196735,
      "h": 12885098623,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098623)
  ],
  "h": 196735
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JsonClaimValueTypes`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JsonClaimValueTypes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196735)
        
        

        //--TRIMMABLE-BOUNDARY-START(458879)
        $asm.$cls(`$mij.MIJ.JwtConstants`, ($self) => class JwtConstants
        {
            //--TRIMMABLE-BOUNDARY-START(8590393471)
            /*string*/ static HeaderType = null;
            //--TRIMMABLE-BOUNDARY-END(8590393471)
            
            //--TRIMMABLE-BOUNDARY-START(12885360767)
            /*string*/ static HeaderTypeAlt = null;
            //--TRIMMABLE-BOUNDARY-END(12885360767)
            
            //--TRIMMABLE-BOUNDARY-START(38655164543)
            /*string*/ static TokenType = null;
            //--TRIMMABLE-BOUNDARY-END(38655164543)
            
            //--TRIMMABLE-BOUNDARY-START(42950131839)
            /*string*/ static TokenTypeAlt = null;
            //--TRIMMABLE-BOUNDARY-END(42950131839)
            
            //--TRIMMABLE-BOUNDARY-START(17180328063)
            /*string*/ static JsonCompactSerializationRegex = null;
            //--TRIMMABLE-BOUNDARY-END(17180328063)
            
            //--TRIMMABLE-BOUNDARY-START(21475295359)
            /*string*/ static JweCompactSerializationRegex = null;
            //--TRIMMABLE-BOUNDARY-END(21475295359)
            
            //--TRIMMABLE-BOUNDARY-START(25770262655)
            /*int*/ static JweSegmentCount = 5;
            //--TRIMMABLE-BOUNDARY-END(25770262655)
            
            //--TRIMMABLE-BOUNDARY-START(30065229951)
            /*int*/ static JwsSegmentCount = 3;
            //--TRIMMABLE-BOUNDARY-END(30065229951)
            
            //--TRIMMABLE-BOUNDARY-START(34360197247)
            /*int*/ static MaxJwtSegmentCount = 5;
            //--TRIMMABLE-BOUNDARY-END(34360197247)
            
            //--TRIMMABLE-BOUNDARY-START(4295426175)
            /*string*/ static DirectKeyUseAlg = null;
            //--TRIMMABLE-BOUNDARY-END(4295426175)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393471)
                    this.HeaderType = "JWT";
                    //--TRIMMABLE-BOUNDARY-END(8590393471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885360767)
                    this.HeaderTypeAlt = "http://openid.net/specs/jwt/1.0";
                    //--TRIMMABLE-BOUNDARY-END(12885360767)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655164543)
                    this.TokenType = "JWT";
                    //--TRIMMABLE-BOUNDARY-END(38655164543)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950131839)
                    this.TokenTypeAlt = "urn:ietf:params:oauth:token-type:jwt";
                    //--TRIMMABLE-BOUNDARY-END(42950131839)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180328063)
                    this.JsonCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                    //--TRIMMABLE-BOUNDARY-END(17180328063)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475295359)
                    this.JweCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                    //--TRIMMABLE-BOUNDARY-END(21475295359)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295426175)
                    this.DirectKeyUseAlg = "dir";
                    //--TRIMMABLE-BOUNDARY-END(4295426175)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 458879;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393471),
    {
      "t": 1310721,
      "n": "HeaderType",
      "d": 458879,
      "h": 8590393471,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393471),
//--TRIMMABLE-BOUNDARY-START(12885360767),
    {
      "t": 1310721,
      "n": "HeaderTypeAlt",
      "d": 458879,
      "h": 12885360767,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360767),
//--TRIMMABLE-BOUNDARY-START(38655164543),
    {
      "t": 1310721,
      "n": "TokenType",
      "d": 458879,
      "h": 38655164543,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655164543),
//--TRIMMABLE-BOUNDARY-START(42950131839),
    {
      "t": 1310721,
      "n": "TokenTypeAlt",
      "d": 458879,
      "h": 42950131839,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950131839),
//--TRIMMABLE-BOUNDARY-START(17180328063),
    {
      "t": 1310721,
      "n": "JsonCompactSerializationRegex",
      "d": 458879,
      "h": 17180328063,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328063),
//--TRIMMABLE-BOUNDARY-START(21475295359),
    {
      "t": 1310721,
      "n": "JweCompactSerializationRegex",
      "d": 458879,
      "h": 21475295359,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295359),
//--TRIMMABLE-BOUNDARY-START(25770262655),
    {
      "t": 655361,
      "n": "JweSegmentCount",
      "d": 458879,
      "h": 25770262655,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770262655),
//--TRIMMABLE-BOUNDARY-START(30065229951),
    {
      "t": 655361,
      "n": "JwsSegmentCount",
      "d": 458879,
      "h": 30065229951,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065229951),
//--TRIMMABLE-BOUNDARY-START(34360197247),
    {
      "t": 655361,
      "n": "MaxJwtSegmentCount",
      "d": 458879,
      "h": 34360197247,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360197247),
//--TRIMMABLE-BOUNDARY-START(4295426175),
    {
      "t": 1310721,
      "n": "DirectKeyUseAlg",
      "d": 458879,
      "h": 4295426175,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295426175)
  ],
  "h": 458879
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JwtConstants`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JwtConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458879)
        
        

        //--TRIMMABLE-BOUNDARY-START(786559)
        $asm.$cls(`$mij.MIJ.JwtTokenDecryptionParameters`, ($self) => class JwtTokenDecryptionParameters extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(90195099775)
            /*byte[]*/ CipherTextBytes = null;
            //--TRIMMABLE-BOUNDARY-END(90195099775)
            
            //--TRIMMABLE-BOUNDARY-START(240518955135)
            /*byte[]*/ HeaderAsciiBytes = null;
            //--TRIMMABLE-BOUNDARY-END(240518955135)
            
            //--TRIMMABLE-BOUNDARY-START(249108889727)
            /*byte[]*/ InitializationVectorBytes = null;
            //--TRIMMABLE-BOUNDARY-END(249108889727)
            
            //--TRIMMABLE-BOUNDARY-START(81605165183)
            /*byte[]*/ AuthenticationTagBytes = null;
            //--TRIMMABLE-BOUNDARY-END(81605165183)
            
            //--TRIMMABLE-BOUNDARY-START(73015230591)
            /*string*/ Alg = null;
            //--TRIMMABLE-BOUNDARY-END(73015230591)
            
            //--TRIMMABLE-BOUNDARY-START(77310197887)
            /*string*/ AuthenticationTag = null;
            //--TRIMMABLE-BOUNDARY-END(77310197887)
            
            //--TRIMMABLE-BOUNDARY-START(85900132479)
            /*string*/ Ciphertext = null;
            //--TRIMMABLE-BOUNDARY-END(85900132479)
            
            //--TRIMMABLE-BOUNDARY-START(94490067071)
            /*Func<byte[], string, int, string>*/ DecompressionFunction = null;
            //--TRIMMABLE-BOUNDARY-END(94490067071)
            
            //--TRIMMABLE-BOUNDARY-START(98785034367)
            /*string*/ Enc = null;
            //--TRIMMABLE-BOUNDARY-END(98785034367)
            
            //--TRIMMABLE-BOUNDARY-START(103080001663)
            /*string*/ EncodedHeader = null;
            //--TRIMMABLE-BOUNDARY-END(103080001663)
            
            //--TRIMMABLE-BOUNDARY-START(107374968959)
            /*string*/ EncodedToken = null;
            //--TRIMMABLE-BOUNDARY-END(107374968959)
            
            //--TRIMMABLE-BOUNDARY-START(244813922431)
            /*string*/ InitializationVector = null;
            //--TRIMMABLE-BOUNDARY-END(244813922431)
            
            //--TRIMMABLE-BOUNDARY-START(253403857023)
            /*IEnumerable<SecurityKey>*/ Keys = null;
            //--TRIMMABLE-BOUNDARY-END(253403857023)
            
            //--TRIMMABLE-BOUNDARY-START(257698824319)
            /*int*/ MaximumDeflateSize = 0;
            //--TRIMMABLE-BOUNDARY-END(257698824319)
            
            //--TRIMMABLE-BOUNDARY-START(390842810495)
            /*string*/ Zip = null;
            //--TRIMMABLE-BOUNDARY-END(390842810495)
            
            //--TRIMMABLE-BOUNDARY-START(68720263295)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720263295)
            
            //--TRIMMABLE-BOUNDARY-START(68720263295)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(68720263295)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(257698824319)
                this.MaximumDeflateSize = 256000;
                //--TRIMMABLE-BOUNDARY-END(257698824319)
                
            }
            static $h = 786559;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195099775),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324641919,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300648497279,
        "f": 83886081
      },
      "n": "CipherTextBytes",
      "d": 786559,
      "h": 90195099775,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195099775),
//--TRIMMABLE-BOUNDARY-START(240518955135),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274314879,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343598170239,
        "f": 83886081
      },
      "n": "HeaderAsciiBytes",
      "d": 786559,
      "h": 240518955135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240518955135),
//--TRIMMABLE-BOUNDARY-START(249108889727),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454184063,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360778039423,
        "f": 83886081
      },
      "n": "InitializationVectorBytes",
      "d": 786559,
      "h": 249108889727,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249108889727),
//--TRIMMABLE-BOUNDARY-START(81605165183),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144772735,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468628095,
        "f": 83886081
      },
      "n": "AuthenticationTagBytes",
      "d": 786559,
      "h": 81605165183,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605165183),
//--TRIMMABLE-BOUNDARY-START(73015230591),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964903551,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288758911,
        "f": 83886081
      },
      "n": "Alg",
      "d": 786559,
      "h": 73015230591,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015230591),
//--TRIMMABLE-BOUNDARY-START(77310197887),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554838143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878693503,
        "f": 83886081
      },
      "n": "AuthenticationTag",
      "d": 786559,
      "h": 77310197887,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310197887),
//--TRIMMABLE-BOUNDARY-START(85900132479),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734707327,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058562687,
        "f": 83886081
      },
      "n": "Ciphertext",
      "d": 786559,
      "h": 85900132479,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900132479),
//--TRIMMABLE-BOUNDARY-START(94490067071),
    {
      "p": $.$$.S.Func$$$$$($.$typeArray($.$$.S.Byte), $.$$.S.String, $.$$.S.Int32, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914576511,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309238431871,
        "f": 83886081
      },
      "n": "DecompressionFunction",
      "d": 786559,
      "h": 94490067071,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490067071),
//--TRIMMABLE-BOUNDARY-START(98785034367),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504511103,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828366463,
        "f": 83886081
      },
      "n": "Enc",
      "d": 786559,
      "h": 98785034367,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785034367),
//--TRIMMABLE-BOUNDARY-START(103080001663),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094445695,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418301055,
        "f": 83886081
      },
      "n": "EncodedHeader",
      "d": 786559,
      "h": 103080001663,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080001663),
//--TRIMMABLE-BOUNDARY-START(107374968959),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684380287,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335008235647,
        "f": 83886081
      },
      "n": "EncodedToken",
      "d": 786559,
      "h": 107374968959,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374968959),
//--TRIMMABLE-BOUNDARY-START(244813922431),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864249471,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352188104831,
        "f": 83886081
      },
      "n": "InitializationVector",
      "d": 786559,
      "h": 244813922431,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244813922431),
//--TRIMMABLE-BOUNDARY-START(253403857023),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044118655,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369367974015,
        "f": 83886081
      },
      "n": "Keys",
      "d": 786559,
      "h": 253403857023,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403857023),
//--TRIMMABLE-BOUNDARY-START(257698824319),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634053247,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377957908607,
        "f": 83886081
      },
      "n": "MaximumDeflateSize",
      "d": 786559,
      "h": 257698824319,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698824319),
//--TRIMMABLE-BOUNDARY-START(390842810495),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223987839,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386547843199,
        "f": 83886081
      },
      "n": "Zip",
      "d": 786559,
      "h": 390842810495,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(390842810495)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(68720263295),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786559,
      "h": 68720263295,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720263295)
  ],
  "h": 786559
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JwtTokenDecryptionParameters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786559)
        
        

        //--TRIMMABLE-BOUNDARY-START(917631)
        $asm.$cls(`$mij.MIJ.LogMessages`, ($self) => class LogMessages
        {
            //--TRIMMABLE-BOUNDARY-START(4295884927)
            /*string*/ static IDX14000 = null;
            //--TRIMMABLE-BOUNDARY-END(4295884927)
            
            //--TRIMMABLE-BOUNDARY-START(8590852223)
            /*string*/ static IDX14100 = null;
            //--TRIMMABLE-BOUNDARY-END(8590852223)
            
            //--TRIMMABLE-BOUNDARY-START(12885819519)
            /*string*/ static IDX14101 = null;
            //--TRIMMABLE-BOUNDARY-END(12885819519)
            
            //--TRIMMABLE-BOUNDARY-START(17180786815)
            /*string*/ static IDX14102 = null;
            //--TRIMMABLE-BOUNDARY-END(17180786815)
            
            //--TRIMMABLE-BOUNDARY-START(21475754111)
            /*string*/ static IDX14103 = null;
            //--TRIMMABLE-BOUNDARY-END(21475754111)
            
            //--TRIMMABLE-BOUNDARY-START(25770721407)
            /*string*/ static IDX14107 = null;
            //--TRIMMABLE-BOUNDARY-END(25770721407)
            
            //--TRIMMABLE-BOUNDARY-START(30065688703)
            /*string*/ static IDX14112 = null;
            //--TRIMMABLE-BOUNDARY-END(30065688703)
            
            //--TRIMMABLE-BOUNDARY-START(34360655999)
            /*string*/ static IDX14113 = null;
            //--TRIMMABLE-BOUNDARY-END(34360655999)
            
            //--TRIMMABLE-BOUNDARY-START(38655623295)
            /*string*/ static IDX14114 = null;
            //--TRIMMABLE-BOUNDARY-END(38655623295)
            
            //--TRIMMABLE-BOUNDARY-START(42950590591)
            /*string*/ static IDX14116 = null;
            //--TRIMMABLE-BOUNDARY-END(42950590591)
            
            //--TRIMMABLE-BOUNDARY-START(47245557887)
            /*string*/ static IDX14117 = null;
            //--TRIMMABLE-BOUNDARY-END(47245557887)
            
            //--TRIMMABLE-BOUNDARY-START(51540525183)
            /*string*/ static IDX14120 = null;
            //--TRIMMABLE-BOUNDARY-END(51540525183)
            
            //--TRIMMABLE-BOUNDARY-START(55835492479)
            /*string*/ static IDX14121 = null;
            //--TRIMMABLE-BOUNDARY-END(55835492479)
            
            //--TRIMMABLE-BOUNDARY-START(60130459775)
            /*string*/ static IDX14122 = null;
            //--TRIMMABLE-BOUNDARY-END(60130459775)
            
            //--TRIMMABLE-BOUNDARY-START(64425427071)
            /*string*/ static IDX14200 = null;
            //--TRIMMABLE-BOUNDARY-END(64425427071)
            
            //--TRIMMABLE-BOUNDARY-START(68720394367)
            /*string*/ static IDX14201 = null;
            //--TRIMMABLE-BOUNDARY-END(68720394367)
            
            //--TRIMMABLE-BOUNDARY-START(73015361663)
            /*string*/ static IDX14304 = null;
            //--TRIMMABLE-BOUNDARY-END(73015361663)
            
            //--TRIMMABLE-BOUNDARY-START(77310328959)
            /*string*/ static IDX14305 = null;
            //--TRIMMABLE-BOUNDARY-END(77310328959)
            
            //--TRIMMABLE-BOUNDARY-START(81605296255)
            /*string*/ static IDX14306 = null;
            //--TRIMMABLE-BOUNDARY-END(81605296255)
            
            //--TRIMMABLE-BOUNDARY-START(85900263551)
            /*string*/ static IDX14307 = null;
            //--TRIMMABLE-BOUNDARY-END(85900263551)
            
            //--TRIMMABLE-BOUNDARY-START(90195230847)
            /*string*/ static IDX14308 = null;
            //--TRIMMABLE-BOUNDARY-END(90195230847)
            
            //--TRIMMABLE-BOUNDARY-START(94490198143)
            /*string*/ static IDX14309 = null;
            //--TRIMMABLE-BOUNDARY-END(94490198143)
            
            //--TRIMMABLE-BOUNDARY-START(98785165439)
            /*string*/ static IDX14310 = null;
            //--TRIMMABLE-BOUNDARY-END(98785165439)
            
            //--TRIMMABLE-BOUNDARY-START(103080132735)
            /*string*/ static IDX14311 = null;
            //--TRIMMABLE-BOUNDARY-END(103080132735)
            
            //--TRIMMABLE-BOUNDARY-START(107375100031)
            /*string*/ static IDX14312 = null;
            //--TRIMMABLE-BOUNDARY-END(107375100031)
            
            //--TRIMMABLE-BOUNDARY-START(111670067327)
            /*string*/ static IDX14317 = null;
            //--TRIMMABLE-BOUNDARY-END(111670067327)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295884927)
                    this.IDX14000 = "IDX14000: Signature validation of this JWT is not supported for: Algorithm: '{0}', SecurityKey: '{1}'.";
                    //--TRIMMABLE-BOUNDARY-END(4295884927)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852223)
                    this.IDX14100 = "IDX14100: JWT is not well formed, there are no dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(8590852223)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885819519)
                    this.IDX14101 = "IDX14101: Unable to decode the payload '{0}' as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(12885819519)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180786815)
                    this.IDX14102 = "IDX14102: Unable to decode the header '{0}' as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(17180786815)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475754111)
                    this.IDX14103 = "IDX14103: Failed to create the token encryption provider.";
                    //--TRIMMABLE-BOUNDARY-END(21475754111)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770721407)
                    this.IDX14107 = "IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)";
                    //--TRIMMABLE-BOUNDARY-END(25770721407)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065688703)
                    this.IDX14112 = "IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'";
                    //--TRIMMABLE-BOUNDARY-END(30065688703)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360655999)
                    this.IDX14113 = "IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used.";
                    //--TRIMMABLE-BOUNDARY-END(34360655999)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655623295)
                    this.IDX14114 = "IDX14114: Both '{0}.{1}' and '{0}.{2}' are null or empty.";
                    //--TRIMMABLE-BOUNDARY-END(38655623295)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950590591)
                    this.IDX14116 = "IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation.";
                    //--TRIMMABLE-BOUNDARY-END(42950590591)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245557887)
                    this.IDX14117 = "IDX14117: Cannot create a 'JsonWebToken' with a replaced header from an encrypted (JWE) token. The provided token must be a JWS so that its decoded payload can be reused.";
                    //--TRIMMABLE-BOUNDARY-END(47245557887)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540525183)
                    this.IDX14120 = "IDX14120: JWT is not well formed, there is only one dot (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(51540525183)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835492479)
                    this.IDX14121 = "IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(55835492479)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130459775)
                    this.IDX14122 = "IDX14122: JWT is not a well formed JWE, there are more than four dots (.) a JWE can have at most 4 dots.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(60130459775)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425427071)
                    this.IDX14200 = "IDX14200: Creating raw signature using the signature credentials.";
                    //--TRIMMABLE-BOUNDARY-END(64425427071)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720394367)
                    this.IDX14201 = "IDX14201: Creating raw signature using the signature credentials. Caching SignatureProvider: '{0}'.";
                    //--TRIMMABLE-BOUNDARY-END(68720394367)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015361663)
                    this.IDX14304 = "IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet.";
                    //--TRIMMABLE-BOUNDARY-END(73015361663)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310328959)
                    this.IDX14305 = "IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'.";
                    //--TRIMMABLE-BOUNDARY-END(77310328959)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605296255)
                    this.IDX14306 = "IDX14306: JWE Ciphertext cannot be an empty string.";
                    //--TRIMMABLE-BOUNDARY-END(81605296255)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900263551)
                    this.IDX14307 = "IDX14307: JWE header is missing.";
                    //--TRIMMABLE-BOUNDARY-END(85900263551)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195230847)
                    this.IDX14308 = "IDX14308: JWE initialization vector is missing.";
                    //--TRIMMABLE-BOUNDARY-END(90195230847)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490198143)
                    this.IDX14309 = "IDX14309: Unable to decode the initialization vector as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(94490198143)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98785165439)
                    this.IDX14310 = "IDX14310: JWE authentication tag is missing.";
                    //--TRIMMABLE-BOUNDARY-END(98785165439)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080132735)
                    this.IDX14311 = "IDX14311: Unable to decode the authentication tag as a Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(103080132735)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375100031)
                    this.IDX14312 = "IDX14312: Unable to decode the cipher text as a Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(107375100031)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670067327)
                    this.IDX14317 = "IDX14317: JsonWebTokenHandler.MaxActorChainLength must be greater than or equal to 1. Value provided was: '{0}'.";
                    //--TRIMMABLE-BOUNDARY-END(111670067327)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 917631;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884927),
    {
      "t": 1310721,
      "n": "IDX14000",
      "d": 917631,
      "h": 4295884927,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295884927),
//--TRIMMABLE-BOUNDARY-START(8590852223),
    {
      "t": 1310721,
      "n": "IDX14100",
      "d": 917631,
      "h": 8590852223,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590852223),
//--TRIMMABLE-BOUNDARY-START(12885819519),
    {
      "t": 1310721,
      "n": "IDX14101",
      "d": 917631,
      "h": 12885819519,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885819519),
//--TRIMMABLE-BOUNDARY-START(17180786815),
    {
      "t": 1310721,
      "n": "IDX14102",
      "d": 917631,
      "h": 17180786815,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180786815),
//--TRIMMABLE-BOUNDARY-START(21475754111),
    {
      "t": 1310721,
      "n": "IDX14103",
      "d": 917631,
      "h": 21475754111,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475754111),
//--TRIMMABLE-BOUNDARY-START(25770721407),
    {
      "t": 1310721,
      "n": "IDX14107",
      "d": 917631,
      "h": 25770721407,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770721407),
//--TRIMMABLE-BOUNDARY-START(30065688703),
    {
      "t": 1310721,
      "n": "IDX14112",
      "d": 917631,
      "h": 30065688703,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065688703),
//--TRIMMABLE-BOUNDARY-START(34360655999),
    {
      "t": 1310721,
      "n": "IDX14113",
      "d": 917631,
      "h": 34360655999,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360655999),
//--TRIMMABLE-BOUNDARY-START(38655623295),
    {
      "t": 1310721,
      "n": "IDX14114",
      "d": 917631,
      "h": 38655623295,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655623295),
//--TRIMMABLE-BOUNDARY-START(42950590591),
    {
      "t": 1310721,
      "n": "IDX14116",
      "d": 917631,
      "h": 42950590591,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950590591),
//--TRIMMABLE-BOUNDARY-START(47245557887),
    {
      "t": 1310721,
      "n": "IDX14117",
      "d": 917631,
      "h": 47245557887,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245557887),
//--TRIMMABLE-BOUNDARY-START(51540525183),
    {
      "t": 1310721,
      "n": "IDX14120",
      "d": 917631,
      "h": 51540525183,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540525183),
//--TRIMMABLE-BOUNDARY-START(55835492479),
    {
      "t": 1310721,
      "n": "IDX14121",
      "d": 917631,
      "h": 55835492479,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835492479),
//--TRIMMABLE-BOUNDARY-START(60130459775),
    {
      "t": 1310721,
      "n": "IDX14122",
      "d": 917631,
      "h": 60130459775,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130459775),
//--TRIMMABLE-BOUNDARY-START(64425427071),
    {
      "t": 1310721,
      "n": "IDX14200",
      "d": 917631,
      "h": 64425427071,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425427071),
//--TRIMMABLE-BOUNDARY-START(68720394367),
    {
      "t": 1310721,
      "n": "IDX14201",
      "d": 917631,
      "h": 68720394367,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720394367),
//--TRIMMABLE-BOUNDARY-START(73015361663),
    {
      "t": 1310721,
      "n": "IDX14304",
      "d": 917631,
      "h": 73015361663,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015361663),
//--TRIMMABLE-BOUNDARY-START(77310328959),
    {
      "t": 1310721,
      "n": "IDX14305",
      "d": 917631,
      "h": 77310328959,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310328959),
//--TRIMMABLE-BOUNDARY-START(81605296255),
    {
      "t": 1310721,
      "n": "IDX14306",
      "d": 917631,
      "h": 81605296255,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605296255),
//--TRIMMABLE-BOUNDARY-START(85900263551),
    {
      "t": 1310721,
      "n": "IDX14307",
      "d": 917631,
      "h": 85900263551,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900263551),
//--TRIMMABLE-BOUNDARY-START(90195230847),
    {
      "t": 1310721,
      "n": "IDX14308",
      "d": 917631,
      "h": 90195230847,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90195230847),
//--TRIMMABLE-BOUNDARY-START(94490198143),
    {
      "t": 1310721,
      "n": "IDX14309",
      "d": 917631,
      "h": 94490198143,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94490198143),
//--TRIMMABLE-BOUNDARY-START(98785165439),
    {
      "t": 1310721,
      "n": "IDX14310",
      "d": 917631,
      "h": 98785165439,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98785165439),
//--TRIMMABLE-BOUNDARY-START(103080132735),
    {
      "t": 1310721,
      "n": "IDX14311",
      "d": 917631,
      "h": 103080132735,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103080132735),
//--TRIMMABLE-BOUNDARY-START(107375100031),
    {
      "t": 1310721,
      "n": "IDX14312",
      "d": 917631,
      "h": 107375100031,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107375100031),
//--TRIMMABLE-BOUNDARY-START(111670067327),
    {
      "t": 1310721,
      "n": "IDX14317",
      "d": 917631,
      "h": 111670067327,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111670067327)
  ],
  "h": 917631
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.LogMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}LogMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917631)
        
        

        //--TRIMMABLE-BOUNDARY-START(852095)
        $asm.$cls(`$mij.MIJ.JwtTokenUtilities`, ($self) => class JwtTokenUtilities extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60130394239)
            static /*ValidationResult<string, ValidationError> */ DecryptJwtToken(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*JwtTokenDecryptionParameters*/ decryptionParameters, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters === null)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("validationParameters", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JwtTokenUtilities.DecryptTokenResult.cs", 34, 1)));
                }
                if (decryptionParameters === null)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("decryptionParameters", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JwtTokenUtilities.DecryptTokenResult.cs", 43, 1)));
                }
                /*bool*/ let decryptionSucceeded = false;
                /*bool*/ let algorithmNotSupportedByCryptoProvider = false;
                /*byte[]*/ let decryptedTokenBytes = null;
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*string*/ let zipAlgorithm = null;
                let $en1 = decryptionParameters.Keys.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let key = $en1.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                        if (cryptoProviderFactory === null)
                        {
                            continue;
                        }
                        try
                        {
                            if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Enc, key))
                            {
                                algorithmNotSupportedByCryptoProvider = true;
                                continue;
                            }
                            /*ValidationResult<string, ValidationError>*/ let result = validationParameters.AlgorithmValidator.MITE$IAlgorithmValidator$ValidateAlgorithm(zipAlgorithm, jsonWebToken, validationParameters, callContext);
                            if (!result.Succeeded)
                            {
                                (exceptionStrings ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(result.Error.MessageDetail.Message);
                                continue;
                            }
                            decryptedTokenBytes = $.$mij.MIJ.JwtTokenUtilities.DecryptToken(cryptoProviderFactory, key, jsonWebToken.Enc, jsonWebToken.CipherTextBytes, jsonWebToken.HeaderAsciiBytes, jsonWebToken.InitializationVectorBytes, jsonWebToken.AuthenticationTagBytes);
                            zipAlgorithm = jsonWebToken.Zip;
                            decryptionSucceeded = true;
                            break;
                        }
                        catch(ex)
                        {
                            (exceptionStrings ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(ex.ToString());
                        }
                        if (key !== null)
                        {
                            (keysAttempted ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(key.KeyId);
                        }
                    }
                }
                if (!decryptionSucceeded)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit($.$mij.MIJ.JwtTokenUtilities.GetDecryptionError(decryptionParameters, algorithmNotSupportedByCryptoProvider, exceptionStrings, keysAttempted, callContext));
                }
                try
                {
                    /*string*/ let decodedString;
                    if ($.$$.S.String.IsNullOrEmpty(zipAlgorithm))
                    {
                        decodedString = $.$$.ST.Encoding.UTF8.GetString$1(decryptedTokenBytes);
                    }
                    else 
                    {
                        decodedString = decryptionParameters.DecompressionFunction.Invoke(decryptedTokenBytes, zipAlgorithm, decryptionParameters.MaximumDeflateSize);
                    }
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit$1(decodedString);
                }
                catch(ex)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.ValidationError().$ctor$1(new $.$mit.MITE.MessageDetail().$ctor$2($.$mij.MIJ.JwtTokenUtilities.GetIDX10679LogMessage(zipAlgorithm)), $.$mit.MITE.ValidationFailureType.TokenDecompressionFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JwtTokenUtilities.DecryptTokenResult.cs", 143, 1), ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130394239)
            
            //--TRIMMABLE-BOUNDARY-START(85900198015)
            static /*ValidationError */ GetDecryptionError(/*JwtTokenDecryptionParameters*/ decryptionParameters, /*bool*/ algorithmNotSupportedByCryptoProvider, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900198015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(keysAttempted === null))
                {
                    return new $.$mit.MITE.ValidationError().$ctor$2(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10603: Decryption failed. Keys tried: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'"/*TokenLogMessages.IDX10603*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted.ToString()), (exceptionStrings?.ToString() ?? null) ?? $.$$.S.String.Empty, $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.ValidationFailureType.TokenDecryptionFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JwtTokenUtilities.DecryptTokenResult.cs", 167, 1));
                }
                else if (algorithmNotSupportedByCryptoProvider)
                {
                    return new $.$mit.MITE.ValidationError().$ctor$2(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10619: Decryption failed. Algorithm: '{0}'. Either the Encryption Algorithm: '{1}' or none of the Security Keys are supported by the CryptoProviderFactory."/*TokenLogMessages.IDX10619*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(decryptionParameters.Alg), $.$mil.MIL.LogHelper.MarkAsNonPII(decryptionParameters.Enc) ], null, null)), $.$mit.MITE.ValidationFailureType.TokenDecryptionFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JwtTokenUtilities.DecryptTokenResult.cs", 180, 1));
                }
                else 
                {
                    return new $.$mit.MITE.ValidationError().$ctor$2(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.ValidationFailureType.TokenDecryptionFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JwtTokenUtilities.DecryptTokenResult.cs", 192, 1));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900198015)
            
            //--TRIMMABLE-BOUNDARY-START(47245492351)
            static /*global::System.Text.RegularExpressions.Regex */ CreateJwsRegex()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245492351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.STRG.CreateJwsRegex_0.Instance;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245492351)
            
            //--TRIMMABLE-BOUNDARY-START(42950525055)
            static /*global::System.Text.RegularExpressions.Regex */ CreateJweRegex()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950525055);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.STRG.CreateJweRegex_1.Instance;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950525055)
            
            //--TRIMMABLE-BOUNDARY-START(4295819391)
            /*int*/ static _regexMatchTimeoutMilliseconds = 100;
            //--TRIMMABLE-BOUNDARY-END(4295819391)
            
            //--TRIMMABLE-BOUNDARY-START(8590786687)
            /*string*/ static _unrecognizedEncodedToken = null;
            //--TRIMMABLE-BOUNDARY-END(8590786687)
            
            //--TRIMMABLE-BOUNDARY-START(111670001791)
            /*Regex*/ static RegexJws = null;
            //--TRIMMABLE-BOUNDARY-END(111670001791)
            
            //--TRIMMABLE-BOUNDARY-START(107375034495)
            /*Regex*/ static RegexJwe = null;
            //--TRIMMABLE-BOUNDARY-END(107375034495)
            
            //--TRIMMABLE-BOUNDARY-START(73015296127)
            /*List<string>*/ static DefaultHeaderParameters = null;
            //--TRIMMABLE-BOUNDARY-END(73015296127)
            
            //--TRIMMABLE-BOUNDARY-START(38655557759)
            static /*string */ CreateEncodedSignature$2(/*string*/ input, /*SigningCredentials*/ signingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (input === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials");
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm);
                if (signatureProvider === null)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.MIL.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null))));
                }
                try
                {
                    $.$mil.MIL.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    return $.$mit.MIT$1.Base64UrlEncoder.Encode$1(signatureProvider.Sign$1($.$$.ST.Encoding.UTF8.GetBytes$8(input)));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655557759)
            
            //--TRIMMABLE-BOUNDARY-START(34360590463)
            static /*string */ CreateEncodedSignature$1(/*string*/ input, /*SigningCredentials*/ signingCredentials, /*bool*/ cacheProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (input === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials");
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = cryptoProviderFactory.CreateForSigning(signingCredentials.Key, signingCredentials.Algorithm, cacheProvider);
                if (signatureProvider === null)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.MIL.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null))));
                }
                try
                {
                    if ($.$mil.MIL.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.MIL.LogHelper.LogVerbose($.$mil.MIL.LogHelper.FormatInvariant("IDX14201: Creating raw signature using the signature credentials. Caching SignatureProvider: '{0}'."/*LogMessages.IDX14201*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(cacheProvider, $.$$.S.Boolean)) ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    return $.$mit.MIT$1.Base64UrlEncoder.Encode$1(signatureProvider.Sign$1($.$$.ST.Encoding.UTF8.GetBytes$8(input)));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360590463)
            
            //--TRIMMABLE-BOUNDARY-START(30065623167)
            static /*byte[] */ CreateEncodedSignature(/*byte[]*/ input, /*int*/ offset, /*int*/ count, /*SigningCredentials*/ signingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (input === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    return null;
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = $.$firstOf(cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm), () => { throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.MIL.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null)))) });
                try
                {
                    if ($.$mil.MIL.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.MIL.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    return signatureProvider.Sign(input, offset, count);
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065623167)
            
            //--TRIMMABLE-BOUNDARY-START(51540459647)
            static /*bool */ CreateSignature(/*ReadOnlySpan<byte>*/ data, /*Span<byte>*/ destination, /*SigningCredentials*/ signingCredentials, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540459647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bytesWritten.$v = 0;
                if (signingCredentials === null)
                {
                    return false;
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = $.$firstOf(cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm), () => { throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.MIL.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null)))) });
                try
                {
                    if ($.$mil.MIL.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.MIL.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    return signatureProvider.Sign$2(data, destination, bytesWritten);
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540459647)
            
            //--TRIMMABLE-BOUNDARY-START(55835426943)
            static /*string */ DecompressToken(/*byte[]*/ tokenBytes, /*string*/ algorithm, /*int*/ maximumDeflateSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenBytes === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("tokenBytes");
                }
                if ($.$$.S.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("algorithm");
                }
                if (!$.$mit.MIT$1.CompressionProviderFactory.Default.IsSupportedAlgorithm(algorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.NotSupportedException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10682: Compression algorithm '{0}' is not supported."/*TokenLogMessages.IDX10682*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(algorithm) ], null, null))));
                }
                /*var*/ let compressionProvider = $.$mit.MIT$1.CompressionProviderFactory.Default.CreateCompressionProvider(algorithm, maximumDeflateSize);
                /*var*/ let decompressedBytes = compressionProvider.MIT$1$ICompressionProvider$Decompress(tokenBytes);
                return decompressedBytes !== null ? $.$$.ST.Encoding.UTF8.GetString$1(decompressedBytes) : (() =>
                {
        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenDecompressionFailedException().$ctor$14($.$mij.MIJ.JwtTokenUtilities.GetIDX10679LogMessage(algorithm)))        })();
            }
            //--TRIMMABLE-BOUNDARY-END(55835426943)
            
            //--TRIMMABLE-BOUNDARY-START(90195165311)
            static /*string */ GetIDX10679LogMessage(/*string*/ algorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.FormatInvariant("IDX10679: Failed to decompress using algorithm '{0}'."/*TokenLogMessages.IDX10679*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(algorithm) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(90195165311)
            
            //--TRIMMABLE-BOUNDARY-START(64425361535)
            static /*string */ DecryptJwtToken$1(/*SecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters, /*JwtTokenDecryptionParameters*/ decryptionParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425361535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (decryptionParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("decryptionParameters");
                }
                /*bool*/ let decryptionSucceeded = false;
                /*bool*/ let algorithmNotSupportedByCryptoProvider = false;
                /*byte[]*/ let decryptedTokenBytes = null;
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*string*/ let zipAlgorithm = null;
                let $en3 = decryptionParameters.Keys.SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let key = $en3.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                        if (cryptoProviderFactory === null)
                        {
                            if ($.$mil.MIL.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.MIL.LogHelper.LogWarning("IDX10607: Decryption skipping key: '{0}', both validationParameters.CryptoProviderFactory and key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10607*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                            }
                            continue;
                        }
                        try
                        {
                            if (!cryptoProviderFactory.IsSupportedAlgorithm(decryptionParameters.Enc, key))
                            {
                                if ($.$mil.MIL.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                                {
                                    $.$mil.MIL.LogHelper.LogWarning("IDX10611: Decryption failed. Encryption is not supported for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10611*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(decryptionParameters.Enc), $.$mil.MIL.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                                }
                                algorithmNotSupportedByCryptoProvider = true;
                                continue;
                            }
                            $.$mit.MIT$1.Validators.ValidateAlgorithm(decryptionParameters.Enc, key, securityToken, validationParameters);
                            decryptedTokenBytes = $.$mij.MIJ.JwtTokenUtilities.DecryptToken(cryptoProviderFactory, key, decryptionParameters.Enc, decryptionParameters.CipherTextBytes, decryptionParameters.HeaderAsciiBytes, decryptionParameters.InitializationVectorBytes, decryptionParameters.AuthenticationTagBytes);
                            zipAlgorithm = decryptionParameters.Zip;
                            decryptionSucceeded = true;
                            break;
                        }
                        catch(ex)
                        {
                            (exceptionStrings ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(ex.ToString());
                        }
                        if (key !== null)
                        {
                            (keysAttempted ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(key.KeyId);
                        }
                    }
                }
                $.$mij.MIJ.JwtTokenUtilities.ValidateDecryption(decryptionParameters, decryptionSucceeded, algorithmNotSupportedByCryptoProvider, exceptionStrings, keysAttempted);
                try
                {
                    if ($.$$.S.String.IsNullOrEmpty(zipAlgorithm))
                    {
                        return $.$$.ST.Encoding.UTF8.GetString$1(decryptedTokenBytes);
                    }
                    return decryptionParameters.DecompressionFunction.Invoke(decryptedTokenBytes, zipAlgorithm, decryptionParameters.MaximumDeflateSize);
                }
                catch(ex)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenDecompressionFailedException().$ctor$13($.$mij.MIJ.JwtTokenUtilities.GetIDX10679LogMessage(zipAlgorithm), ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425361535)
            
            //--TRIMMABLE-BOUNDARY-START(128849870975)
            static /*void */ ValidateDecryption(/*JwtTokenDecryptionParameters*/ decryptionParameters, /*bool*/ decryptionSucceeded, /*bool*/ algorithmNotSupportedByCryptoProvider, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849870975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!decryptionSucceeded && !(keysAttempted === null))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.MIL.LogHelper.FormatInvariant("IDX10603: Decryption failed. Keys tried: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'"/*TokenLogMessages.IDX10603*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted.ToString()), exceptionStrings ?? $.$$.S.String.Empty, $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                }
                if (!decryptionSucceeded && algorithmNotSupportedByCryptoProvider)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.MIL.LogHelper.FormatInvariant("IDX10619: Decryption failed. Algorithm: '{0}'. Either the Encryption Algorithm: '{1}' or none of the Security Keys are supported by the CryptoProviderFactory."/*TokenLogMessages.IDX10619*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(decryptionParameters.Alg), $.$mil.MIL.LogHelper.MarkAsNonPII(decryptionParameters.Enc) ], null, null))));
                }
                if (!decryptionSucceeded)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.MIL.LogHelper.FormatInvariant("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849870975)
            
            //--TRIMMABLE-BOUNDARY-START(68720328831)
            static /*byte[] */ DecryptToken(/*CryptoProviderFactory*/ cryptoProviderFactory, /*SecurityKey*/ key, /*string*/ encAlg, /*byte[]*/ ciphertext, /*byte[]*/ headerAscii, /*byte[]*/ initializationVector, /*byte[]*/ authenticationTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let decryptionProvider = null;
                try
                {
                    decryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(key, encAlg);
                    if (decryptionProvider === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10610: Decryption failed. Could not create decryption provider. Key: '{0}', Algorithm: '{1}'."/*TokenLogMessages.IDX10610*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key.KeyId), $.$mil.MIL.LogHelper.MarkAsNonPII(encAlg) ], null, null))));
                    }
                    return decryptionProvider.Decrypt(ciphertext, headerAscii, initializationVector, authenticationTag);
                }
                finally
                {
                    decryptionProvider?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720328831)
            
            //--TRIMMABLE-BOUNDARY-START(77310263423)
            static /*byte[] */ GenerateKeyBytes(/*int*/ sizeInBits)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let key = null;
                if (sizeInBits !== 256 && sizeInBits !== 384 && sizeInBits !== 512)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$13("IDX10401: Invalid requested key size. Valid key sizes are: 256, 384, and 512."/*TokenLogMessages.IDX10401*/, "sizeInBits"));
                }
                let aes = null;
                try
                {
                    aes = $.$sscr.SSC.Aes.Create$2();
                    /*int*/ let halfSizeInBytes = sizeInBits >> 4;
                    key = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [halfSizeInBytes << 1], null);
                    aes.KeySize = sizeInBits >> 1;
                    aes.GenerateKey();
                    $.$$.S.Array.Copy$2(aes.Key, key, halfSizeInBytes);
                    aes.GenerateKey();
                    $.$$.S.Array.Copy(aes.Key, 0, key, halfSizeInBytes, halfSizeInBytes);
                }
                finally
                {
                    aes?.S$IDisposable$Dispose();
                }
                return key;
            }
            //--TRIMMABLE-BOUNDARY-END(77310263423)
            
            //--TRIMMABLE-BOUNDARY-START(94490132607)
            static /*SecurityKey */ GetSecurityKey(/*EncryptingCredentials*/ encryptingCredentials, /*CryptoProviderFactory*/ cryptoProviderFactory, /*IDictionary<string, object>*/ additionalHeaderClaims, /*out byte[]*/ wrappedKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SecurityKey*/ let securityKey = null;
                /*KeyWrapProvider*/ let kwProvider = null;
                wrappedKey.$v = null;
                if ($.$$.S.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg))
                {
                    if (!cryptoProviderFactory.IsSupportedAlgorithm(encryptingCredentials.Enc, encryptingCredentials.Key))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10615: Encryption failed. No support for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10615*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null))));
                    }
                    securityKey = encryptingCredentials.Key;
                }
                else if ($.$mit.MIT$1.SupportedAlgorithms.EcdsaWrapAlgorithms.SCG$ICollection$$$Contains(encryptingCredentials.Alg))
                {
                    /*string*/ let apu = null, apv = null;
                    if (additionalHeaderClaims !== null && additionalHeaderClaims.SCG$ICollection$$$Count > 0)
                    {
                        /*object*/ let objApu;
                        /*object*/ let objApv;
                        if (additionalHeaderClaims.SCG$IDictionary$$$$TryGetValue("apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => objApu, ($v) => objApu = $v, $.$$.S.Object)))
                        {
                            /*object*/ let __ca1__;
                            apu = ((__ca1__ = objApu) !== null ? $.$dsp(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
                        }
                        if (additionalHeaderClaims.SCG$IDictionary$$$$TryGetValue("apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => objApv, ($v) => objApv = $v, $.$$.S.Object)))
                        {
                            /*object*/ let __ca2__;
                            apv = ((__ca2__ = objApv) !== null ? $.$dsp(__ca2__, $.$$.S.Object, ($t) => $t.ToString) : null);
                        }
                    }
                    /*EcdhKeyExchangeProvider*/ let ecdhKeyExchangeProvider = new $.$mit.MIT$1.EcdhKeyExchangeProvider().$ctor$1($.$as(encryptingCredentials.Key, $.$mit.MIT$1.ECDsaSecurityKey), encryptingCredentials.KeyExchangePublicKey, encryptingCredentials.Alg, encryptingCredentials.Enc);
                    /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                    kwProvider = cryptoProviderFactory.CreateKeyWrapProvider$1(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                    if ($.$$.S.String.Equals$2.call("A128KW"/*SecurityAlgorithms.Aes128KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4($.$mij.MIJ.JwtTokenUtilities.GenerateKeyBytes(256));
                    }
                    else if ($.$$.S.String.Equals$2.call("A192KW"/*SecurityAlgorithms.Aes192KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4($.$mij.MIJ.JwtTokenUtilities.GenerateKeyBytes(384));
                    }
                    else if ($.$$.S.String.Equals$2.call("A256KW"/*SecurityAlgorithms.Aes256KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4($.$mij.MIJ.JwtTokenUtilities.GenerateKeyBytes(512));
                    }
                    else 
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10617: Encryption failed. Keywrap is only supported for: '{0}', '{1}' and '{2}'. The content encryption specified is: '{3}'."/*TokenLogMessages.IDX10617*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("A128KW"/*SecurityAlgorithms.Aes128KW*/), $.$mil.MIL.LogHelper.MarkAsNonPII("A192KW"/*SecurityAlgorithms.Aes192KW*/), $.$mil.MIL.LogHelper.MarkAsNonPII("A256KW"/*SecurityAlgorithms.Aes256KW*/), $.$mil.MIL.LogHelper.MarkAsNonPII(kwProvider.Algorithm) ], null, null))));
                    }
                    wrappedKey.$v = kwProvider.WrapKey(($.$cast(securityKey, $.$mit.MIT$1.SymmetricSecurityKey)).Key);
                }
                else 
                {
                    if (!cryptoProviderFactory.IsSupportedAlgorithm(encryptingCredentials.Alg, encryptingCredentials.Key))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10615: Encryption failed. No support for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10615*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Alg), $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null))));
                    }
                    if ($.$$.S.String.Equals$5.call("A128CBC-HS256"/*SecurityAlgorithms.Aes128CbcHmacSha256*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4($.$mij.MIJ.JwtTokenUtilities.GenerateKeyBytes(256));
                    }
                    else if ($.$$.S.String.Equals$5.call("A192CBC-HS384"/*SecurityAlgorithms.Aes192CbcHmacSha384*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4($.$mij.MIJ.JwtTokenUtilities.GenerateKeyBytes(384));
                    }
                    else if ($.$$.S.String.Equals$5.call("A256CBC-HS512"/*SecurityAlgorithms.Aes256CbcHmacSha512*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4($.$mij.MIJ.JwtTokenUtilities.GenerateKeyBytes(512));
                    }
                    else 
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10617: Encryption failed. Keywrap is only supported for: '{0}', '{1}' and '{2}'. The content encryption specified is: '{3}'."/*TokenLogMessages.IDX10617*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("A128CBC-HS256"/*SecurityAlgorithms.Aes128CbcHmacSha256*/), $.$mil.MIL.LogHelper.MarkAsNonPII("A192CBC-HS384"/*SecurityAlgorithms.Aes192CbcHmacSha384*/), $.$mil.MIL.LogHelper.MarkAsNonPII("A256CBC-HS512"/*SecurityAlgorithms.Aes256CbcHmacSha512*/), $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Enc) ], null, null))));
                    }
                    kwProvider = cryptoProviderFactory.CreateKeyWrapProvider$1(encryptingCredentials.Key, encryptingCredentials.Alg);
                    wrappedKey.$v = kwProvider.WrapKey(($.$cast(securityKey, $.$mit.MIT$1.SymmetricSecurityKey)).Key);
                }
                return securityKey;
            }
            //--TRIMMABLE-BOUNDARY-END(94490132607)
            
            //--TRIMMABLE-BOUNDARY-START(81605230719)
            static /*IEnumerable<SecurityKey> */ GetAllDecryptionKeys(/*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("validationParameters");
                }
                /*var*/ let decryptionKeys = new ($.$$.SCO.Collection$$($.$mit.MIT$1.SecurityKey))().$ctor$1();
                if (validationParameters.TokenDecryptionKey !== null)
                {
                    decryptionKeys.Add(validationParameters.TokenDecryptionKey);
                }
                if (validationParameters.TokenDecryptionKeys !== null)
                {
                    let $en6 = validationParameters.TokenDecryptionKeys.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let key = $en6.SCG$IEnumerator$$$Current;
                        {
                            decryptionKeys.Add(key);
                        }
                    }
                }
                return decryptionKeys;
            }
            //--TRIMMABLE-BOUNDARY-END(81605230719)
            
            //--TRIMMABLE-BOUNDARY-START(124554903679)
            static /*string */ SafeLogJwtToken(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554903679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return $.$$.S.String.Empty;
                }
                let token;
                if (!($.$is(obj, $.$$.S.String, { set $v($v){ token = $v; } })))
                {
                    return $.$$.S.Object.GetType.call(obj).ToString();
                }
                /*int*/ let lastDot = $.$$.S.String.LastIndexOf$2.call(token, /*.*/ 46);
                if (lastDot === -1)
                {
                    return "UnrecognizedEncodedToken"/*_unrecognizedEncodedToken*/;
                }
                return $.$$.S.String.Substring.call(token, 0, lastDot);
            }
            //--TRIMMABLE-BOUNDARY-END(124554903679)
            
            //--TRIMMABLE-BOUNDARY-START(115964969087)
            static /*SecurityKey */ ResolveTokenSigningKey(/*string*/ kid, /*string*/ x5t, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.JwtTokenUtilities.ResolveTokenSigningKey$1(kid, x5t, (configuration?.SigningKeys ?? null)) ?? $.$mij.MIJ.JwtTokenUtilities.ResolveTokenSigningKey$1(kid, x5t, $.$mij.MIJ.JwtTokenUtilities.ConcatSigningKeys(validationParameters));
            }
            //--TRIMMABLE-BOUNDARY-END(115964969087)
            
            //--TRIMMABLE-BOUNDARY-START(120259936383)
            static /*SecurityKey */ ResolveTokenSigningKey$1(/*string*/ kid, /*string*/ x5t, /*IEnumerable<SecurityKey>*/ signingKeys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259936383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (signingKeys === null)
                {
                    return null;
                }
                let $en7 = signingKeys.SCG$IEnumerable$$$GetEnumerator();
                while ($en7.SC$1$IEnumerator$MoveNext())
                {
                    let signingKey = $en7.SCG$IEnumerator$$$Current;
                    {
                        if (signingKey !== null)
                        {
                            let x509Key;
                            if ($.$is(signingKey, $.$mit.MIT$1.X509SecurityKey, { set $v($v){ x509Key = $v; } }))
                            {
                                if ((!$.$$.S.String.IsNullOrEmpty(kid) && $.$$.S.String.Equals$3(signingKey.KeyId, kid, 5/*StringComparison.OrdinalIgnoreCase*/)) || (!$.$$.S.String.IsNullOrEmpty(x5t) && $.$$.S.String.Equals$3(x509Key.X5t, x5t, 5/*StringComparison.OrdinalIgnoreCase*/)))
                                {
                                    return signingKey;
                                }
                            }
                            else if (!$.$$.S.String.IsNullOrEmpty(signingKey.KeyId))
                            {
                                if ($.$$.S.String.Equals$4(signingKey.KeyId, kid) || $.$$.S.String.Equals$4(signingKey.KeyId, x5t))
                                {
                                    return signingKey;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(120259936383)
            
            //--TRIMMABLE-BOUNDARY-START(25770655871)
            static /*int */ CountJwtTokenPart(/*string*/ token, /*int*/ maxCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let count = 1;
                /*var*/ let index = 0;
                while(index < token.length)
                {
                    /*var*/ let dotIndex = $.$$.S.String.IndexOf$1.call(token, /*.*/ 46, index);
                    if (dotIndex < 0)
                    {
                        break;
                    }
                    count++;
                    index = ((dotIndex + 1) | 0);
                    if (count === maxCount)
                    {
                        break;
                    }
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655871)
            
            //--TRIMMABLE-BOUNDARY-START(21475688575)
            static /*IEnumerable<SecurityKey> */ ConcatSigningKeys(/*TokenValidationParameters*/ tvp)
            {
                return new ($.$$.N.YieldToIterator$$($.$mit.MIT$1.SecurityKey))().$ctor$1(function*()
                {
                    if (tvp === null)
                    {
                        return;
                    }
                    yield tvp.IssuerSigningKey;
                    if (tvp.IssuerSigningKeys !== null)
                    {
                        let $en8 = tvp.IssuerSigningKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en8.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en8.SCG$IEnumerator$$$Current;
                            {
                                yield key;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(21475688575)
            
            //--TRIMMABLE-BOUNDARY-START(103080067199)
            static /*string */ GetStringClaimValueType$1(/*string*/ str)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080067199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.JwtTokenUtilities.GetStringClaimValueType(str, $.$$.S.String.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(103080067199)
            
            //--TRIMMABLE-BOUNDARY-START(98785099903)
            static /*string */ GetStringClaimValueType(/*string*/ str, /*string*/ claimType)
            {
                /*DateTime*/ let dateTimeValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785099903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.String.IsNullOrEmpty(claimType) && !$.$mit.MIT$1.AppContextSwitches.TryAllStringClaimsAsDateTime && $.$mit.MITJ.JsonSerializerPrimitives.IsKnownToNotBeDateTime(claimType))
                {
                    return "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
                }
                if ($.$$.S.DateTime.TryParse$3(str, $.$ref(() => dateTimeValue, ($v) => dateTimeValue = $v, $.$$.S.DateTime)))
                {
                    /*string*/ let dtUniversal = dateTimeValue.ToUniversalTime().ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture);
                    if ($.$$.S.String.Equals$2.call(dtUniversal, str, 4/*StringComparison.Ordinal*/))
                    {
                        return "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/;
                    }
                }
                return "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099903)
            
            //--TRIMMABLE-BOUNDARY-START(17180721279)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721279)
            
            //--TRIMMABLE-BOUNDARY-START(17180721279)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180721279)
            
            //--TRIMMABLE-BOUNDARY-START(12885753983)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590786687)
                    this._unrecognizedEncodedToken = "UnrecognizedEncodedToken";
                    //--TRIMMABLE-BOUNDARY-END(8590786687)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670001791)
                    this.RegexJws = $.$mij.MIJ.JwtTokenUtilities.CreateJwsRegex();
                    //--TRIMMABLE-BOUNDARY-END(111670001791)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375034495)
                    this.RegexJwe = $.$mij.MIJ.JwtTokenUtilities.CreateJweRegex();
                    //--TRIMMABLE-BOUNDARY-END(107375034495)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015296127)
                    this.DefaultHeaderParameters = (() =>
                    {
                        //new $.$$.SCG.List$$($.$$.S.String)()
                        const $t10 = $.$$.SCG.List$$($.$$.S.String);
                        const $i10 = new $t10();
                        $i10.$ctor$1();
                        $i10.Add("alg"/*JwtHeaderParameterNames.Alg*/);
                        $i10.Add("kid"/*JwtHeaderParameterNames.Kid*/);
                        $i10.Add("x5t"/*JwtHeaderParameterNames.X5t*/);
                        $i10.Add("enc"/*JwtHeaderParameterNames.Enc*/);
                        $i10.Add("zip"/*JwtHeaderParameterNames.Zip*/);
                        return $i10;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(73015296127)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885753983)
            
            static $h = 852095;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130394239),
    {
      "r": $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "decryptionParameters",
          "p": 786559
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "DecryptJwtToken",
      "d": 852095,
      "h": 60130394239,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(60130394239),
//--TRIMMABLE-BOUNDARY-START(85900198015),
    {
      "r": 9568382,
      "p": [
        {
          "n": "decryptionParameters",
          "p": 786559
        },
        {
          "n": "algorithmNotSupportedByCryptoProvider",
          "p": 262145
        },
        {
          "n": "exceptionStrings",
          "p": 167837697
        },
        {
          "n": "keysAttempted",
          "p": 167837697
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "GetDecryptionError",
      "d": 852095,
      "h": 85900198015,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85900198015),
//--TRIMMABLE-BOUNDARY-START(47245492351),
    {
      "r": 1900602,
      "n": "CreateJwsRegex",
      "d": 852095,
      "h": 47245492351,
      "f": 16777250,
      "a": [
        {
          "t": 1245242,
          "c": 25771049018,
          "a": [
            {
              "v": "^[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]*$",
              "t": 1310721
            },
            {
              "v": 512,
              "t": 3539002
            },
            {
              "v": 100,
              "t": 655361
            }
          ]
        },
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "System.Text.RegularExpressions.Generator",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245492351),
//--TRIMMABLE-BOUNDARY-START(42950525055),
    {
      "r": 1900602,
      "n": "CreateJweRegex",
      "d": 852095,
      "h": 42950525055,
      "f": 16777250,
      "a": [
        {
          "t": 1245242,
          "c": 25771049018,
          "a": [
            {
              "v": "^[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B$",
              "t": 1310721
            },
            {
              "v": 512,
              "t": 3539002
            },
            {
              "v": 100,
              "t": 655361
            }
          ]
        },
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "System.Text.RegularExpressions.Generator",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950525055),
//--TRIMMABLE-BOUNDARY-START(38655557759),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        }
      ],
      "n": "CreateEncodedSignature",
      "o": "@$2",
      "d": 852095,
      "h": 38655557759,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655557759),
//--TRIMMABLE-BOUNDARY-START(34360590463),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "cacheProvider",
          "p": 262145
        }
      ],
      "n": "CreateEncodedSignature",
      "o": "@$1",
      "d": 852095,
      "h": 34360590463,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360590463),
//--TRIMMABLE-BOUNDARY-START(30065623167),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        }
      ],
      "n": "CreateEncodedSignature",
      "d": 852095,
      "h": 30065623167,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065623167),
//--TRIMMABLE-BOUNDARY-START(51540459647),
    {
      "r": 262145,
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "CreateSignature",
      "d": 852095,
      "h": 51540459647,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51540459647),
//--TRIMMABLE-BOUNDARY-START(55835426943),
    {
      "r": 1310721,
      "p": [
        {
          "n": "tokenBytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "algorithm",
          "p": 1310721
        },
        {
          "n": "maximumDeflateSize",
          "p": 655361
        }
      ],
      "n": "DecompressToken",
      "d": 852095,
      "h": 55835426943,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835426943),
//--TRIMMABLE-BOUNDARY-START(90195165311),
    {
      "r": 1310721,
      "p": [
        {
          "n": "algorithm",
          "p": 1310721
        }
      ],
      "n": "GetIDX10679LogMessage",
      "d": 852095,
      "h": 90195165311,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90195165311),
//--TRIMMABLE-BOUNDARY-START(64425361535),
    {
      "r": 1310721,
      "p": [
        {
          "n": "securityToken",
          "p": 13762686
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "decryptionParameters",
          "p": 786559
        }
      ],
      "n": "DecryptJwtToken",
      "o": "@$1",
      "d": 852095,
      "h": 64425361535,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64425361535),
//--TRIMMABLE-BOUNDARY-START(128849870975),
    {
      "r": 65537,
      "p": [
        {
          "n": "decryptionParameters",
          "p": 786559
        },
        {
          "n": "decryptionSucceeded",
          "p": 262145
        },
        {
          "n": "algorithmNotSupportedByCryptoProvider",
          "p": 262145
        },
        {
          "n": "exceptionStrings",
          "p": 167837697
        },
        {
          "n": "keysAttempted",
          "p": 167837697
        }
      ],
      "n": "ValidateDecryption",
      "d": 852095,
      "h": 128849870975,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(128849870975),
//--TRIMMABLE-BOUNDARY-START(68720328831),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "cryptoProviderFactory",
          "p": 2949246
        },
        {
          "n": "key",
          "p": 13631614
        },
        {
          "n": "encAlg",
          "p": 1310721
        },
        {
          "n": "ciphertext",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "headerAscii",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "initializationVector",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "authenticationTag",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "DecryptToken",
      "d": 852095,
      "h": 68720328831,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720328831),
//--TRIMMABLE-BOUNDARY-START(77310263423),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeInBits",
          "p": 655361
        }
      ],
      "n": "GenerateKeyBytes",
      "d": 852095,
      "h": 77310263423,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310263423),
//--TRIMMABLE-BOUNDARY-START(94490132607),
    {
      "r": 13631614,
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "cryptoProviderFactory",
          "p": 2949246
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "wrappedKey",
          "p": $.$typeArray($.$$.S.Byte).$h,
          "f": 2
        }
      ],
      "n": "GetSecurityKey",
      "d": 852095,
      "h": 94490132607,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(94490132607),
//--TRIMMABLE-BOUNDARY-START(81605230719),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h,
      "p": [
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "GetAllDecryptionKeys",
      "d": 852095,
      "h": 81605230719,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605230719),
//--TRIMMABLE-BOUNDARY-START(124554903679),
    {
      "r": 1310721,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "SafeLogJwtToken",
      "d": 852095,
      "h": 124554903679,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(124554903679),
//--TRIMMABLE-BOUNDARY-START(115964969087),
    {
      "r": 13631614,
      "p": [
        {
          "n": "kid",
          "p": 1310721
        },
        {
          "n": "x5t",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ResolveTokenSigningKey",
      "d": 852095,
      "h": 115964969087,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(115964969087),
//--TRIMMABLE-BOUNDARY-START(120259936383),
    {
      "r": 13631614,
      "p": [
        {
          "n": "kid",
          "p": 1310721
        },
        {
          "n": "x5t",
          "p": 1310721
        },
        {
          "n": "signingKeys",
          "p": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h
        }
      ],
      "n": "ResolveTokenSigningKey",
      "o": "@$1",
      "d": 852095,
      "h": 120259936383,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(120259936383),
//--TRIMMABLE-BOUNDARY-START(25770655871),
    {
      "r": 655361,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "maxCount",
          "p": 655361
        }
      ],
      "n": "CountJwtTokenPart",
      "d": 852095,
      "h": 25770655871,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770655871),
//--TRIMMABLE-BOUNDARY-START(21475688575),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h,
      "p": [
        {
          "n": "tvp",
          "p": 16777342
        }
      ],
      "n": "ConcatSigningKeys",
      "d": 852095,
      "h": 21475688575,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475688575),
//--TRIMMABLE-BOUNDARY-START(103080067199),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "GetStringClaimValueType",
      "o": "@$1",
      "d": 852095,
      "h": 103080067199,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(103080067199),
//--TRIMMABLE-BOUNDARY-START(98785099903),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetStringClaimValueType",
      "d": 852095,
      "h": 98785099903,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(98785099903)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819391),
    {
      "t": 655361,
      "n": "_regexMatchTimeoutMilliseconds",
      "d": 852095,
      "h": 4295819391,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295819391),
//--TRIMMABLE-BOUNDARY-START(8590786687),
    {
      "t": 1310721,
      "n": "_unrecognizedEncodedToken",
      "d": 852095,
      "h": 8590786687,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590786687),
//--TRIMMABLE-BOUNDARY-START(111670001791),
    {
      "t": 1900602,
      "n": "RegexJws",
      "d": 852095,
      "h": 111670001791,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670001791),
//--TRIMMABLE-BOUNDARY-START(107375034495),
    {
      "t": 1900602,
      "n": "RegexJwe",
      "d": 852095,
      "h": 107375034495,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375034495),
//--TRIMMABLE-BOUNDARY-START(73015296127),
    {
      "t": $.$$.SCG.List$$($.$$.S.String).$h,
      "n": "DefaultHeaderParameters",
      "d": 852095,
      "h": 73015296127,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015296127)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180721279),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852095,
      "h": 17180721279,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721279)
  ],
  "h": 852095
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JwtTokenUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852095)
        
        

        //--TRIMMABLE-BOUNDARY-START(65663)
        $asm.$cls(`$mij.MIJ.ClaimTypeMapping`, ($self) => class ClaimTypeMapping
        {
            //--TRIMMABLE-BOUNDARY-START(55834640511)
            /*Dictionary<string, string>*/ static shortToLongClaimTypeMapping = null;
            //--TRIMMABLE-BOUNDARY-END(55834640511)
            
            //--TRIMMABLE-BOUNDARY-START(47244705919)
            /*Dictionary<string, string>*/ static longToShortClaimTypeMapping = null;
            //--TRIMMABLE-BOUNDARY-END(47244705919)
            
            //--TRIMMABLE-BOUNDARY-START(34359804031)
            /*HashSet<string>*/ static inboundClaimFilter = null;
            //--TRIMMABLE-BOUNDARY-END(34359804031)
            
            //--TRIMMABLE-BOUNDARY-START(4295032959)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = $.$mij.MIJ.ClaimTypeMapping.shortToLongClaimTypeMapping.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let kv = $en1.Current;
                    {
                        if ($.$mij.MIJ.ClaimTypeMapping.longToShortClaimTypeMapping.ContainsKey(kv.Value))
                        {
                            continue;
                        }
                        $.$mij.MIJ.ClaimTypeMapping.longToShortClaimTypeMapping.Add(kv.Value, kv.Key);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032959)
            
            //--TRIMMABLE-BOUNDARY-START(42949738623)
            static /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.ClaimTypeMapping.shortToLongClaimTypeMapping;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738623)
            
            //--TRIMMABLE-BOUNDARY-START(51539673215)
            static /*IDictionary<string, string> */ get OutboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.ClaimTypeMapping.longToShortClaimTypeMapping;
            }
            //--TRIMMABLE-BOUNDARY-END(51539673215)
            
            //--TRIMMABLE-BOUNDARY-START(38654771327)
            static /*ISet<string> */ get InboundClaimFilter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.ClaimTypeMapping.inboundClaimFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771327)
            
            //--TRIMMABLE-BOUNDARY-START(4295032959)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640511)
                    this.shortToLongClaimTypeMapping = (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add("actort"/*JwtRegisteredClaimNames.Actort*/, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/);
                        $i2.Add("birthdate"/*JwtRegisteredClaimNames.Birthdate*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth"/*ClaimTypes.DateOfBirth*/);
                        $i2.Add("email"/*JwtRegisteredClaimNames.Email*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"/*ClaimTypes.Email*/);
                        $i2.Add("family_name"/*JwtRegisteredClaimNames.FamilyName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"/*ClaimTypes.Surname*/);
                        $i2.Add("gender"/*JwtRegisteredClaimNames.Gender*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender"/*ClaimTypes.Gender*/);
                        $i2.Add("given_name"/*JwtRegisteredClaimNames.GivenName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"/*ClaimTypes.GivenName*/);
                        $i2.Add("nameid"/*JwtRegisteredClaimNames.NameId*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/);
                        $i2.Add("sub"/*JwtRegisteredClaimNames.Sub*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/);
                        $i2.Add("website"/*JwtRegisteredClaimNames.Website*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage"/*ClaimTypes.Webpage*/);
                        $i2.Add("unique_name"/*JwtRegisteredClaimNames.UniqueName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimTypes.Name*/);
                        $i2.Add("oid", "http://schemas.microsoft.com/identity/claims/objectidentifier");
                        $i2.Add("scp", "http://schemas.microsoft.com/identity/claims/scope");
                        $i2.Add("tid", "http://schemas.microsoft.com/identity/claims/tenantid");
                        $i2.Add("acr", "http://schemas.microsoft.com/claims/authnclassreference");
                        $i2.Add("adfs1email", "http://schemas.xmlsoap.org/claims/EmailAddress");
                        $i2.Add("adfs1upn", "http://schemas.xmlsoap.org/claims/UPN");
                        $i2.Add("amr", "http://schemas.microsoft.com/claims/authnmethodsreferences");
                        $i2.Add("authmethod", "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod"/*ClaimTypes.AuthenticationMethod*/);
                        $i2.Add("certapppolicy", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/applicationpolicy");
                        $i2.Add("certauthoritykeyidentifier", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/authoritykeyidentifier");
                        $i2.Add("certbasicconstraints", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/basicconstraints");
                        $i2.Add("certeku", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/eku");
                        $i2.Add("certissuer", "http://schemas.microsoft.com/2012/12/certificatecontext/field/issuer");
                        $i2.Add("certissuername", "http://schemas.microsoft.com/2012/12/certificatecontext/field/issuername");
                        $i2.Add("certkeyusage", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/keyusage");
                        $i2.Add("certnotafter", "http://schemas.microsoft.com/2012/12/certificatecontext/field/notafter");
                        $i2.Add("certnotbefore", "http://schemas.microsoft.com/2012/12/certificatecontext/field/notbefore");
                        $i2.Add("certpolicy", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatepolicy");
                        $i2.Add("certpublickey", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa"/*ClaimTypes.Rsa*/);
                        $i2.Add("certrawdata", "http://schemas.microsoft.com/2012/12/certificatecontext/field/rawdata");
                        $i2.Add("certserialnumber", "http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber"/*ClaimTypes.SerialNumber*/);
                        $i2.Add("certsignaturealgorithm", "http://schemas.microsoft.com/2012/12/certificatecontext/field/signaturealgorithm");
                        $i2.Add("certsubject", "http://schemas.microsoft.com/2012/12/certificatecontext/field/subject");
                        $i2.Add("certsubjectaltname", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/san");
                        $i2.Add("certsubjectkeyidentifier", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/subjectkeyidentifier");
                        $i2.Add("certsubjectname", "http://schemas.microsoft.com/2012/12/certificatecontext/field/subjectname");
                        $i2.Add("certtemplateinformation", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatetemplateinformation");
                        $i2.Add("certtemplatename", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatetemplatename");
                        $i2.Add("certthumbprint", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint"/*ClaimTypes.Thumbprint*/);
                        $i2.Add("certx509version", "http://schemas.microsoft.com/2012/12/certificatecontext/field/x509version");
                        $i2.Add("clientapplication", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application");
                        $i2.Add("clientip", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-ip");
                        $i2.Add("clientuseragent", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-user-agent");
                        $i2.Add("commonname", "http://schemas.xmlsoap.org/claims/CommonName");
                        $i2.Add("denyonlyprimarygroupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid"/*ClaimTypes.DenyOnlyPrimaryGroupSid*/);
                        $i2.Add("denyonlyprimarysid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid"/*ClaimTypes.DenyOnlyPrimarySid*/);
                        $i2.Add("denyonlysid", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid"/*ClaimTypes.DenyOnlySid*/);
                        $i2.Add("devicedispname", "http://schemas.microsoft.com/2012/01/devicecontext/claims/displayname");
                        $i2.Add("deviceid", "http://schemas.microsoft.com/2012/01/devicecontext/claims/identifier");
                        $i2.Add("deviceismanaged", "http://schemas.microsoft.com/2012/01/devicecontext/claims/ismanaged");
                        $i2.Add("deviceostype", "http://schemas.microsoft.com/2012/01/devicecontext/claims/ostype");
                        $i2.Add("deviceosver", "http://schemas.microsoft.com/2012/01/devicecontext/claims/osversion");
                        $i2.Add("deviceowner", "http://schemas.microsoft.com/2012/01/devicecontext/claims/userowner");
                        $i2.Add("deviceregid", "http://schemas.microsoft.com/2012/01/devicecontext/claims/registrationid");
                        $i2.Add("endpointpath", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path");
                        $i2.Add("forwardedclientip", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip");
                        $i2.Add("group", "http://schemas.xmlsoap.org/claims/Group");
                        $i2.Add("groups", "http://schemas.microsoft.com/ws/2008/06/identity/claims/groups");
                        $i2.Add("groupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid"/*ClaimTypes.GroupSid*/);
                        $i2.Add("idp", "http://schemas.microsoft.com/identity/claims/identityprovider");
                        $i2.Add("insidecorporatenetwork", "http://schemas.microsoft.com/ws/2012/01/insidecorporatenetwork");
                        $i2.Add("isregistereduser", "http://schemas.microsoft.com/2012/01/devicecontext/claims/isregistereduser");
                        $i2.Add("ppid", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/privatepersonalidentifier");
                        $i2.Add("primarygroupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid"/*ClaimTypes.PrimaryGroupSid*/);
                        $i2.Add("primarysid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid"/*ClaimTypes.PrimarySid*/);
                        $i2.Add("proxy", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy");
                        $i2.Add("pwdchgurl", "http://schemas.microsoft.com/ws/2012/01/passwordchangeurl");
                        $i2.Add("pwdexpdays", "http://schemas.microsoft.com/ws/2012/01/passwordexpirationdays");
                        $i2.Add("pwdexptime", "http://schemas.microsoft.com/ws/2012/01/passwordexpirationtime");
                        $i2.Add("relyingpartytrustid", "http://schemas.microsoft.com/2012/01/requestcontext/claims/relyingpartytrustid");
                        $i2.Add("role", "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/);
                        $i2.Add("roles", "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/);
                        $i2.Add("upn", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn"/*ClaimTypes.Upn*/);
                        $i2.Add("winaccountname", "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname"/*ClaimTypes.WindowsAccountName*/);
                        return $i2;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(55834640511)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244705919)
                    this.longToShortClaimTypeMapping = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(47244705919)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359804031)
                    this.inboundClaimFilter = $.$mij.MIJ.ClaimTypeMapping.inboundClaimFilter = new ($.$$.SCG.HashSet$$($.$$.S.String))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(34359804031)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032959)
            
            static $h = 65663;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949738623),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474902143,
        "f": 50331681
      },
      "n": "InboundClaimTypeMap",
      "d": 65663,
      "h": 42949738623,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42949738623),
//--TRIMMABLE-BOUNDARY-START(51539673215),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064836735,
        "f": 50331681
      },
      "n": "OutboundClaimTypeMap",
      "d": 65663,
      "h": 51539673215,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51539673215),
//--TRIMMABLE-BOUNDARY-START(38654771327),
    {
      "p": $.$$.SCG.ISet$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12884967551,
        "f": 50331681
      },
      "n": "InboundClaimFilter",
      "d": 65663,
      "h": 38654771327,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38654771327)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55834640511),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "shortToLongClaimTypeMapping",
      "d": 65663,
      "h": 55834640511,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834640511),
//--TRIMMABLE-BOUNDARY-START(47244705919),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "longToShortClaimTypeMapping",
      "d": 65663,
      "h": 47244705919,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244705919),
//--TRIMMABLE-BOUNDARY-START(34359804031),
    {
      "t": $.$$.SCG.HashSet$$($.$$.S.String).$h,
      "n": "inboundClaimFilter",
      "d": 65663,
      "h": 34359804031,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359804031)
  ],
  "h": 65663
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}ClaimTypeMapping`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65663)
        
        

        //--TRIMMABLE-BOUNDARY-START(131199)
        $asm.$cls(`$mij.MIJ.JsonClaimSet`, ($self) => class JsonClaimSet extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30064902271)
            /*string*/ static ClassName = null;
            //--TRIMMABLE-BOUNDARY-END(30064902271)
            
            //--TRIMMABLE-BOUNDARY-START(8590065791)
            /*Lock*/ _claimsLock = null;
            //--TRIMMABLE-BOUNDARY-END(8590065791)
            
            //--TRIMMABLE-BOUNDARY-START(12885033087)
            /*Dictionary<string, object>*/ _jsonClaims = null;
            //--TRIMMABLE-BOUNDARY-END(12885033087)
            
            //--TRIMMABLE-BOUNDARY-START(4295098495)
            /*List<Claim>*/ _claims = null;
            //--TRIMMABLE-BOUNDARY-END(4295098495)
            
            //--TRIMMABLE-BOUNDARY-START(17180000383)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsonClaims = (() =>
                    {
                        let $t1 = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                        return $t1;
                    })();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000383)
            
            //--TRIMMABLE-BOUNDARY-START(21474967679)
            $ctor$2(/*Dictionary<string, object>*/ jsonClaims)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474967679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsonClaims = jsonClaims;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967679)
            
            //--TRIMMABLE-BOUNDARY-START(25769934975)
            /*List<Claim> */ Claims(/*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._claims === null)
                {
                    //lock(_claimsLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this._claimsLock)
                        this._claims ??= this.CreateClaims(issuer);
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this._claimsLock)
                    }
                }
                return this._claims;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934975)
            
            //--TRIMMABLE-BOUNDARY-START(42949804159)
            /*List<Claim> */ CreateClaims(/*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let claims = new ($.$$.SCG.List$$($.$ssc.SSC.Claim))().$ctor$3(this._jsonClaims.Count);
                let $en2 = this._jsonClaims.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let kvp = $en2.Current;
                    {
                        $.$mij.MIJ.JsonClaimSet.CreateClaimFromObject(claims, kvp.Key, kvp.Value, issuer);
                    }
                }
                return claims;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804159)
            
            //--TRIMMABLE-BOUNDARY-START(38654836863)
            static /*void */ CreateClaimFromObject(/*List<Claim>*/ claims, /*string*/ claimType, /*object*/ value, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let str;
                let i;
                let l;
                let b;
                let d;
                let dt;
                let f;
                let m;
                let iList;
                let j;
                if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, str, $.$mij.MIJ.JwtTokenUtilities.GetStringClaimValueType(str, claimType), issuer, issuer));
                }
                else if ($.$is(value, $.$$.S.Int32, { set $v($v){ i = $v; } }))
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.Int32.ToString$1.call(i, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.S.Int64, { set $v($v){ l = $v; } }))
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.Int64.ToString$1.call(l, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.S.Boolean, { set $v($v){ b = $v; } }))
                {
                    if (b)
                    {
                        claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                    }
                    else 
                    {
                        claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                    }
                }
                else if ($.$is(value, $.$$.S.Double, { set $v($v){ d = $v; } }))
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.Double.ToString$1.call(d, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.S.DateTime, { set $v($v){ dt = $v; } }))
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, dt.ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.S.Single, { set $v($v){ f = $v; } }))
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.Single.ToString$1.call(f, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.S.Decimal, { set $v($v){ m = $v; } }))
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, m.ToString$1($.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if (value === null)
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.SC$1.IList, { set $v($v){ iList = $v; } }))
                {
                    let $en3 = iList.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        let item = $en3.SCG$IEnumerator$$$Current;
                        {
                            $.$mij.MIJ.JsonClaimSet.CreateClaimFromObject(claims, claimType, item, issuer);
                        }
                    }
                }
                else if ($.$is(value, $.$stj.STJ.JsonElement, { set $v($v){ j = $v; } }))
                {
                    if (j.ValueKind === 2/*JsonValueKind.Array*/)
                    {
                        let $en4 = j.EnumerateArray().GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            let jsonElement = $en4.Current;
                            {
                                /*Claim*/ let claim = $.$mij.MIJ.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, jsonElement);
                                if (claim !== null)
                                {
                                    claims.Add(claim);
                                }
                            }
                        }
                    }
                    else 
                    {
                        /*Claim*/ let claim = $.$mij.MIJ.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, j);
                        if (claim !== null)
                        {
                            claims.Add(claim);
                        }
                    }
                }
                else 
                {
                    claims.Add(new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$dsp(value, $.$$.S.Object, ($t) => $t.ToString), "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, issuer, issuer));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654836863)
            
            //--TRIMMABLE-BOUNDARY-START(34359869567)
            static /*Claim */ CreateClaimFromJsonElement(/*string*/ claimType, /*string*/ issuer, /*JsonElement*/ jsonElement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jsonElement.ValueKind === 3/*JsonValueKind.String*/)
                {
                    /*string*/ let claimValue = jsonElement.ToString();
                    return new $.$ssc.SSC.Claim().$ctor$5(claimType, claimValue, $.$mij.MIJ.JwtTokenUtilities.GetStringClaimValueType(claimValue, claimType), issuer, issuer);
                }
                else if (jsonElement.ValueKind === 7/*JsonValueKind.Null*/)
                {
                    return new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 1/*JsonValueKind.Object*/)
                {
                    return new $.$ssc.SSC.Claim().$ctor$5(claimType, jsonElement.ToString(), "JSON"/*JsonClaimValueTypes.Json*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 6/*JsonValueKind.False*/)
                {
                    return new $.$ssc.SSC.Claim().$ctor$5(claimType, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 5/*JsonValueKind.True*/)
                {
                    return new $.$ssc.SSC.Claim().$ctor$5(claimType, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 4/*JsonValueKind.Number*/)
                {
                    /*int*/ let i;
                    /*long*/ let l;
                    /*double*/ let d;
                    /*uint*/ let u;
                    /*ulong*/ let ul;
                    /*float*/ let f;
                    /*decimal*/ let m;
                    if (jsonElement.TryGetInt32($.$ref(() => i, ($v) => i = $v, $.$$.S.Int32)))
                    {
                        return new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.Int32.ToString$1.call(i, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetInt64($.$ref(() => l, ($v) => l = $v, $.$$.S.Int64)))
                    {
                        return new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.Int64.ToString$1.call(l, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetDouble($.$ref(() => d, ($v) => d = $v, $.$$.S.Double)))
                    {
                        return new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.Double.ToString$1.call(d, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetUInt32($.$ref(() => u, ($v) => u = $v, $.$$.S.UInt32)))
                    {
                        return new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.UInt32.ToString$1.call(u, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#uinteger32"/*ClaimValueTypes.UInteger32*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetUInt64($.$ref(() => ul, ($v) => ul = $v, $.$$.S.UInt64)))
                    {
                        return new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.UInt64.ToString$1.call(ul, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#uinteger64"/*ClaimValueTypes.UInteger64*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetSingle($.$ref(() => f, ($v) => f = $v, $.$$.S.Single)))
                    {
                        return new $.$ssc.SSC.Claim().$ctor$5(claimType, $.$$.S.Single.ToString$1.call(f, $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetDecimal($.$ref(() => m, ($v) => m = $v, $.$$.S.Decimal)))
                    {
                        return new $.$ssc.SSC.Claim().$ctor$5(claimType, m.ToString$1($.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                }
                else if (jsonElement.ValueKind === 2/*JsonValueKind.Array*/)
                {
                    return new $.$ssc.SSC.Claim().$ctor$5(claimType, jsonElement.ToString(), "JSON_ARRAY"/*JsonClaimValueTypes.JsonArray*/, issuer, issuer);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34359869567)
            
            //--TRIMMABLE-BOUNDARY-START(47244771455)
            /*Claim */ GetClaim(/*string*/ key, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("key");
                }
                if (this._jsonClaims.TryGetValue(key, $.$discardRef()))
                {
                    let $en12 = this.Claims(issuer).GetEnumerator();
                    while ($en12.MoveNext())
                    {
                        let claim = $en12.Current;
                        {
                            if (claim.Type === key)
                            {
                                return claim;
                            }
                        }
                    }
                }
                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet."/*LogMessages.IDX14304*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ key ], null, null))));
            }
            //--TRIMMABLE-BOUNDARY-END(47244771455)
            
            //--TRIMMABLE-BOUNDARY-START(55834706047)
            /*string */ GetStringValue(/*string*/ key)
            {
                /*object*/ let obj;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._jsonClaims.TryGetValue(key, $.$ref(() => obj, ($v) => obj = $v, $.$$.S.Object)))
                {
                    if (obj === null)
                    {
                        return null;
                    }
                    return $.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString);
                }
                return $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706047)
            
            //--TRIMMABLE-BOUNDARY-START(51539738751)
            /*DateTime */ GetDateTime(/*string*/ key)
            {
                /*bool*/ let found;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let l = this.GetValue($.$$.S.Int64, key, false, $.$ref(() => found, ($v) => found = $v, $.$$.S.Boolean));
                if (found)
                {
                    return $.$mit.MIT$1.EpochTime.DateTime(l);
                }
                return $.$$.S.DateTime.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(51539738751)
            
            //--TRIMMABLE-BOUNDARY-START(64424640639)
            /*T */ GetValue$1(T, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424640639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValue(T, key, true, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(64424640639)
            
            //--TRIMMABLE-BOUNDARY-START(60129673343)
            /*T */ GetValue(T, /*string*/ key, /*bool*/ throwEx, /*out bool*/ found)
            {
                /*object*/ let obj;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                found.$v = this._jsonClaims.TryGetValue(key, $.$ref(() => obj, ($v) => obj = $v, $.$$.S.Object));
                if (!found.$v)
                {
                    return throwEx ? (() =>
                    {
        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet."/*LogMessages.IDX14304*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ key ], null, null))))            })() : $.$default(T);
                }
                if (obj === null)
                {
                    if (T.$type === $.$$.S.Object.$type || T.$type.IsClass || $.$$.S.Nullable.GetUnderlyingType(T.$type) !== null)
                    {
                        return $.$cast(null, T);
                    }
                    else 
                    {
                        return $.$default(T);
                    }
                }
                /*Type*/ let objType = $.$$.S.Object.GetType.call(obj);
                if (T.$type === objType)
                {
                    return $.$cast((obj), T);
                }
                if (T.$type === $.$$.S.Object.$type)
                {
                    return $.$cast(obj, T);
                }
                let jsonElement;
                if ($.$is(obj, $.$stj.STJ.JsonElement, { set $v($v){ jsonElement = $v; } }))
                {
                    /*T*/ let t;
                    if ($.$mit.MITJ.JsonSerializerPrimitives.TryCreateTypeFromJsonElement(T, jsonElement, $.$ref(() => t, ($v) => t = $v, T)))
                    {
                        return t;
                    }
                }
                else if (T.$type === $.$$.S.String.$type)
                {
                    if (objType === $.$$.S.DateTime.$type)
                    {
                        return $.$cast((($.$cast(obj, $.$$.S.DateTime)).ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture)), T);
                    }
                    let list;
                    if ($.$is(obj, $.$$.SCG.List$$($.$$.S.String), { set $v($v){ list = $v; } }))
                    {
                        if (list.Count === 1)
                        {
                            return $.$cast(((list.get_Item(0))), T);
                        }
                    }
                    else 
                    {
                        return $.$cast(($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString)), T);
                    }
                }
                else if (T.$type === $.$$.S.Boolean.$type)
                {
                    /*bool*/ let value;
                    if ($.$$.S.Boolean.TryParse$1($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.Boolean)))
                    {
                        return $.$cast($.$box(value, $.$$.S.Boolean), T);
                    }
                }
                else if (T.$type === $.$$.S.Int32.$type)
                {
                    /*int*/ let value;
                    if ($.$$.S.Int32.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.Int32)))
                    {
                        return $.$cast($.$box(value, $.$$.S.Int32), T);
                    }
                }
                else if (T.$type === $.$$.S.Int64.$type)
                {
                    /*long*/ let value;
                    if (objType === $.$$.S.Int32.$type)
                    {
                        return $.$cast($.$box($.$cast($.$cast(obj, $.$$.S.Int32), $.$$.S.Int64), $.$$.S.Int64), T);
                    }
                    if ($.$$.S.Int64.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.Int64)))
                    {
                        return $.$cast($.$box(value, $.$$.S.Int64), T);
                    }
                }
                else if (T.$type === $.$typeArray($.$$.S.String).$type)
                {
                    if (objType === $.$$.S.String.$type)
                    {
                        return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [$.$cast(obj, $.$$.S.String)], [-1], null), $.$$.S.Object), T);
                    }
                    if (objType === $.$$.S.DateTime.$type)
                    {
                        return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [($.$cast(obj, $.$$.S.DateTime)).ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture)], [-1], null), $.$$.S.Object), T);
                    }
                    return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [$.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString)], [-1], null), $.$$.S.Object), T);
                }
                else if (T.$type === $.$$.SCG.List$$($.$$.S.String).$type)
                {
                    if (objType === $.$$.S.String.$type)
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.SCG.List$$($.$$.S.String)()
                            const $t20 = $.$$.SCG.List$$($.$$.S.String);
                            const $i20 = new $t20();
                            $i20.$ctor$1();
                            $i20.Add($.$cast(obj, $.$$.S.String));
                            return $i20;
                        })(), T);
                    }
                    if (objType === $.$$.S.DateTime.$type)
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.SCG.List$$($.$$.S.String)()
                            const $t21 = $.$$.SCG.List$$($.$$.S.String);
                            const $i21 = new $t21();
                            $i21.$ctor$1();
                            $i21.Add(($.$cast(obj, $.$$.S.DateTime)).ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture));
                            return $i21;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.SCG.List$$($.$$.S.String)()
                        const $t22 = $.$$.SCG.List$$($.$$.S.String);
                        const $i22 = new $t22();
                        $i22.$ctor$1();
                        $i22.Add($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString));
                        return $i22;
                    })(), T);
                }
                else if (T.$type === $.$$.SCO.Collection$$($.$$.S.String).$type)
                {
                    if (objType === $.$$.S.String.$type)
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.SCO.Collection$$($.$$.S.String)()
                            const $t23 = $.$$.SCO.Collection$$($.$$.S.String);
                            const $i23 = new $t23();
                            $i23.$ctor$1();
                            $i23.Add($.$cast(obj, $.$$.S.String));
                            return $i23;
                        })(), T);
                    }
                    if (objType === $.$$.S.DateTime.$type)
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.SCO.Collection$$($.$$.S.String)()
                            const $t24 = $.$$.SCO.Collection$$($.$$.S.String);
                            const $i24 = new $t24();
                            $i24.$ctor$1();
                            $i24.Add(($.$cast(obj, $.$$.S.DateTime)).ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture));
                            return $i24;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.SCO.Collection$$($.$$.S.String)()
                        const $t25 = $.$$.SCO.Collection$$($.$$.S.String);
                        const $i25 = new $t25();
                        $i25.$ctor$1();
                        $i25.Add($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString));
                        return $i25;
                    })(), T);
                }
                else if (T.$type === $.$$.SCG.IList$$($.$$.S.String).$type)
                {
                    if (objType === $.$$.S.String.$type)
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.SCG.List$$($.$$.S.String)()
                            const $t26 = $.$$.SCG.List$$($.$$.S.String);
                            const $i26 = new $t26();
                            $i26.$ctor$1();
                            $i26.Add($.$cast(obj, $.$$.S.String));
                            return $i26;
                        })(), T);
                    }
                    if (objType === $.$$.S.DateTime.$type)
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.SCG.List$$($.$$.S.String)()
                            const $t27 = $.$$.SCG.List$$($.$$.S.String);
                            const $i27 = new $t27();
                            $i27.$ctor$1();
                            $i27.Add(($.$cast(obj, $.$$.S.DateTime)).ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture));
                            return $i27;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.SCG.List$$($.$$.S.String)()
                        const $t28 = $.$$.SCG.List$$($.$$.S.String);
                        const $i28 = new $t28();
                        $i28.$ctor$1();
                        $i28.Add($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString));
                        return $i28;
                    })(), T);
                }
                else if (T.$type === $.$$.SCG.ICollection$$($.$$.S.String).$type)
                {
                    if (objType === $.$$.S.String.$type)
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.SCO.Collection$$($.$$.S.String)()
                            const $t29 = $.$$.SCO.Collection$$($.$$.S.String);
                            const $i29 = new $t29();
                            $i29.$ctor$1();
                            $i29.Add($.$cast(obj, $.$$.S.String));
                            return $i29;
                        })(), T);
                    }
                    if (objType === $.$$.S.DateTime.$type)
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.SCO.Collection$$($.$$.S.String)()
                            const $t30 = $.$$.SCO.Collection$$($.$$.S.String);
                            const $i30 = new $t30();
                            $i30.$ctor$1();
                            $i30.Add(($.$cast(obj, $.$$.S.DateTime)).ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture));
                            return $i30;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.SCO.Collection$$($.$$.S.String)()
                        const $t31 = $.$$.SCO.Collection$$($.$$.S.String);
                        const $i31 = new $t31();
                        $i31.$ctor$1();
                        $i31.Add($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString));
                        return $i31;
                    })(), T);
                }
                else if (T.$type === $.$typeArray($.$$.S.Object).$type)
                {
                    return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [obj], [-1], null), $.$$.S.Object), T);
                }
                else if (T.$type === $.$$.SCG.List$$($.$$.S.Object).$type)
                {
                    return $.$cast((() =>
                    {
                        //new $.$$.SCG.List$$($.$$.S.Object)()
                        const $t32 = $.$$.SCG.List$$($.$$.S.Object);
                        const $i32 = new $t32();
                        $i32.$ctor$1();
                        $i32.Add(obj);
                        return $i32;
                    })(), T);
                }
                else if (T.$type === $.$$.SCO.Collection$$($.$$.S.Object).$type)
                {
                    return $.$cast((() =>
                    {
                        //new $.$$.SCO.Collection$$($.$$.S.Object)()
                        const $t33 = $.$$.SCO.Collection$$($.$$.S.Object);
                        const $i33 = new $t33();
                        $i33.$ctor$1();
                        $i33.Add(obj);
                        return $i33;
                    })(), T);
                }
                else if (T.$type.IsEnum)
                {
                    return $.$cast($.$$.S.Enum.Parse$2(T.$type, $.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), true), T);
                }
                else if (T.$type === $.$$.S.DateTime.$type)
                {
                    /*DateTime*/ let value;
                    if ($.$$.S.DateTime.TryParse$3($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.DateTime)))
                    {
                        return $.$cast($.$cast(value, $.$$.S.Object), T);
                    }
                }
                else if (T.$type === $.$typeArray($.$$.S.Int32).$type)
                {
                    /*int*/ let value;
                    if (objType === $.$$.S.Int32.$type)
                    {
                        return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [$.$cast(obj, $.$$.S.Int32)], [-1], null), $.$$.S.Object), T);
                    }
                    if ($.$$.S.Int32.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.Int32)))
                    {
                        return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [value], [-1], null), $.$$.S.Object), T);
                    }
                }
                else if (T.$type === $.$typeArray($.$$.S.Int64).$type)
                {
                    /*long*/ let value;
                    if (objType === $.$$.S.Int64.$type)
                    {
                        return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int64), [$.$cast(obj, $.$$.S.Int64)], [-1], null), $.$$.S.Object), T);
                    }
                    if (objType === $.$$.S.Int32.$type)
                    {
                        return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int64), [BigInt($.$cast(obj, $.$$.S.Int32))], [-1], null), $.$$.S.Object), T);
                    }
                    if ($.$$.S.Int64.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.Int64)))
                    {
                        return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int64), [value], [-1], null), $.$$.S.Object), T);
                    }
                }
                else if (T.$type === $.$$.S.Double.$type)
                {
                    /*double*/ let value;
                    if ($.$$.S.Double.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.Double)))
                    {
                        return $.$cast($.$box(value, $.$$.S.Double), T);
                    }
                }
                else if (T.$type === $.$$.S.UInt32.$type)
                {
                    /*uint*/ let value;
                    if ($.$$.S.UInt32.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.UInt32)))
                    {
                        return $.$cast($.$box(value, $.$$.S.UInt32), T);
                    }
                }
                else if (T.$type === $.$$.S.UInt64.$type)
                {
                    /*ulong*/ let value;
                    if ($.$$.S.UInt64.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.UInt64)))
                    {
                        return $.$cast($.$box(value, $.$$.S.UInt64), T);
                    }
                }
                else if (T.$type === $.$$.S.Single.$type)
                {
                    /*float*/ let value;
                    if ($.$$.S.Single.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.Single)))
                    {
                        return $.$cast($.$box(value, $.$$.S.Single), T);
                    }
                }
                else if (T.$type === $.$$.S.Decimal.$type)
                {
                    /*decimal*/ let value;
                    if ($.$$.S.Decimal.TryParse$6($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, $.$$.S.Decimal)))
                    {
                        return $.$cast($.$cast(value, $.$$.S.Object), T);
                    }
                }
                found.$v = false;
                if (throwEx)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'."/*LogMessages.IDX14305*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key), $.$mil.MIL.LogHelper.MarkAsNonPII(T.$type), $.$mil.MIL.LogHelper.MarkAsNonPII(objType), $.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString) ], null, null))));
                }
                else 
                {
                    $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'."/*LogMessages.IDX14305*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key), $.$mil.MIL.LogHelper.MarkAsNonPII(T.$type), $.$mil.MIL.LogHelper.MarkAsNonPII(objType), $.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString) ], null, null))));
                }
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(60129673343)
            
            //--TRIMMABLE-BOUNDARY-START(73014575231)
            /*bool */ TryGetClaim(/*string*/ key, /*string*/ issuer, /*out Claim*/ claim)
            {
                /*object*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                claim.$v = null;
                if (!this._jsonClaims.TryGetValue(key, $.$ref(() => value, ($v) => value = $v, $.$$.S.Object)))
                {
                    return false;
                }
                let $en43 = this.Claims(issuer).GetEnumerator();
                while ($en43.MoveNext())
                {
                    let c = $en43.Current;
                    {
                        if (c.Type === key)
                        {
                            claim.$v = c;
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(73014575231)
            
            //--TRIMMABLE-BOUNDARY-START(77309542527)
            /*bool */ TryGetValue(T, /*string*/ key, /*out T*/ value)
            {
                /*bool*/ let found;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309542527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value.$v = this.GetValue(T, key, false, $.$ref(() => found, ($v) => found = $v, $.$$.S.Boolean));
                return found;
            }
            //--TRIMMABLE-BOUNDARY-END(77309542527)
            
            //--TRIMMABLE-BOUNDARY-START(68719607935)
            /*bool */ HasClaim(/*string*/ claimName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._jsonClaims.TryGetValue(claimName, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(68719607935)
            
            //--TRIMMABLE-BOUNDARY-START(17180000383)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180000383)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590065791)
                this._claimsLock = new $.$$.ST$1.Lock().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590065791)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(30064902271)
                    this.ClassName = "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet";
                    //--TRIMMABLE-BOUNDARY-END(30064902271)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 131199;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769934975),
    {
      "r": $.$$.SCG.List$$($.$ssc.SSC.Claim).$h,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "Claims",
      "d": 131199,
      "h": 25769934975,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25769934975),
//--TRIMMABLE-BOUNDARY-START(42949804159),
    {
      "r": $.$$.SCG.List$$($.$ssc.SSC.Claim).$h,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaims",
      "d": 131199,
      "h": 42949804159,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42949804159),
//--TRIMMABLE-BOUNDARY-START(38654836863),
    {
      "r": 65537,
      "p": [
        {
          "n": "claims",
          "p": $.$$.SCG.List$$($.$ssc.SSC.Claim).$h
        },
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimFromObject",
      "d": 131199,
      "h": 38654836863,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38654836863),
//--TRIMMABLE-BOUNDARY-START(34359869567),
    {
      "r": 131141,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "jsonElement",
          "p": 2097236
        }
      ],
      "n": "CreateClaimFromJsonElement",
      "d": 131199,
      "h": 34359869567,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34359869567),
//--TRIMMABLE-BOUNDARY-START(47244771455),
    {
      "r": 131141,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "GetClaim",
      "d": 131199,
      "h": 47244771455,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47244771455),
//--TRIMMABLE-BOUNDARY-START(55834706047),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetStringValue",
      "d": 131199,
      "h": 55834706047,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55834706047),
//--TRIMMABLE-BOUNDARY-START(51539738751),
    {
      "r": 65994753,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetDateTime",
      "d": 131199,
      "h": 51539738751,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51539738751),
//--TRIMMABLE-BOUNDARY-START(64424640639),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValue",
      "o": "@$1",
      "d": 131199,
      "h": 64424640639,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(64424640639),
//--TRIMMABLE-BOUNDARY-START(60129673343),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "throwEx",
          "p": 262145
        },
        {
          "n": "found",
          "p": 262145,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValue",
      "d": 131199,
      "h": 60129673343,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(60129673343),
//--TRIMMABLE-BOUNDARY-START(73014575231),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "claim",
          "p": 131141,
          "f": 2
        }
      ],
      "n": "TryGetClaim",
      "d": 131199,
      "h": 73014575231,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73014575231),
//--TRIMMABLE-BOUNDARY-START(77309542527),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetValue",
      "d": 131199,
      "h": 77309542527,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(77309542527),
//--TRIMMABLE-BOUNDARY-START(68719607935),
    {
      "r": 262145,
      "p": [
        {
          "n": "claimName",
          "p": 1310721
        }
      ],
      "n": "HasClaim",
      "d": 131199,
      "h": 68719607935,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68719607935)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30064902271),
    {
      "t": 1310721,
      "n": "ClassName",
      "d": 131199,
      "h": 30064902271,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064902271),
//--TRIMMABLE-BOUNDARY-START(8590065791),
    {
      "t": 172556289,
      "n": "_claimsLock",
      "d": 131199,
      "h": 8590065791,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590065791),
//--TRIMMABLE-BOUNDARY-START(12885033087),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "n": "_jsonClaims",
      "d": 131199,
      "h": 12885033087,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885033087),
//--TRIMMABLE-BOUNDARY-START(4295098495),
    {
      "t": $.$$.SCG.List$$($.$ssc.SSC.Claim).$h,
      "n": "_claims",
      "d": 131199,
      "h": 4295098495,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098495)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180000383),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131199,
      "h": 17180000383,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180000383),
//--TRIMMABLE-BOUNDARY-START(21474967679),
    {
      "p": [
        {
          "n": "jsonClaims",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131199,
      "h": 21474967679,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21474967679)
  ],
  "h": 131199
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JsonClaimSet`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131199)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376383)
        $asm.$cls(`$mij.STRG.Utilities`, ($self) => class Utilities
        {
            //--TRIMMABLE-BOUNDARY-START(8591310975)
            /*SearchValues<char>*/ static s_asciiLettersAndDigitsAndDashUnderscore = null;
            //--TRIMMABLE-BOUNDARY-END(8591310975)
            
            //--TRIMMABLE-BOUNDARY-START(4296343679)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8591310975)
                    this.s_asciiLettersAndDigitsAndDashUnderscore = $.$$.SB.SearchValues.Create$1($.$$.S.String.op_Implicit("-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz"));
                    //--TRIMMABLE-BOUNDARY-END(8591310975)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296343679)
            
            static $h = 1376383;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591310975),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "s_asciiLettersAndDigitsAndDashUnderscore",
      "d": 1376383,
      "h": 8591310975,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8591310975)
  ],
  "h": 1376383,
  "a": [
    {
      "t": 55050241,
      "c": 12939952129,
      "a": [
        {
          "v": "System.Text.RegularExpressions.Generator",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.RegularExpressions.Generated.Utilities`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}RegularExpressions${separator}Generated${separator}Utilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376383)
        
        

        //--TRIMMABLE-BOUNDARY-START(524415)
        $asm.$str(`$mij.MIJ.JwtHeaderParameterNames`, ($self) => class JwtHeaderParameterNames extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590459007)
            /*string*/ static Alg = null;
            //--TRIMMABLE-BOUNDARY-END(8590459007)
            
            //--TRIMMABLE-BOUNDARY-START(12885426303)
            /*string*/ static Apu = null;
            //--TRIMMABLE-BOUNDARY-END(12885426303)
            
            //--TRIMMABLE-BOUNDARY-START(17180393599)
            /*string*/ static Apv = null;
            //--TRIMMABLE-BOUNDARY-END(17180393599)
            
            //--TRIMMABLE-BOUNDARY-START(30065295487)
            /*string*/ static Epk = null;
            //--TRIMMABLE-BOUNDARY-END(30065295487)
            
            //--TRIMMABLE-BOUNDARY-START(21475360895)
            /*string*/ static Cty = null;
            //--TRIMMABLE-BOUNDARY-END(21475360895)
            
            //--TRIMMABLE-BOUNDARY-START(25770328191)
            /*string*/ static Enc = null;
            //--TRIMMABLE-BOUNDARY-END(25770328191)
            
            //--TRIMMABLE-BOUNDARY-START(34360262783)
            /*string*/ static IV = null;
            //--TRIMMABLE-BOUNDARY-END(34360262783)
            
            //--TRIMMABLE-BOUNDARY-START(38655230079)
            /*string*/ static Jku = null;
            //--TRIMMABLE-BOUNDARY-END(38655230079)
            
            //--TRIMMABLE-BOUNDARY-START(42950197375)
            /*string*/ static Jwk = null;
            //--TRIMMABLE-BOUNDARY-END(42950197375)
            
            //--TRIMMABLE-BOUNDARY-START(47245164671)
            /*string*/ static Kid = null;
            //--TRIMMABLE-BOUNDARY-END(47245164671)
            
            //--TRIMMABLE-BOUNDARY-START(51540131967)
            /*string*/ static Typ = null;
            //--TRIMMABLE-BOUNDARY-END(51540131967)
            
            //--TRIMMABLE-BOUNDARY-START(55835099263)
            /*string*/ static X5c = null;
            //--TRIMMABLE-BOUNDARY-END(55835099263)
            
            //--TRIMMABLE-BOUNDARY-START(60130066559)
            /*string*/ static X5t = null;
            //--TRIMMABLE-BOUNDARY-END(60130066559)
            
            //--TRIMMABLE-BOUNDARY-START(64425033855)
            /*string*/ static X5u = null;
            //--TRIMMABLE-BOUNDARY-END(64425033855)
            
            //--TRIMMABLE-BOUNDARY-START(68720001151)
            /*string*/ static Zip = null;
            //--TRIMMABLE-BOUNDARY-END(68720001151)
            
            //--TRIMMABLE-BOUNDARY-START(4295491711)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491711)
            
            //--TRIMMABLE-BOUNDARY-START(4295491711)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491711)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590459007)
                    this.Alg = "alg";
                    //--TRIMMABLE-BOUNDARY-END(8590459007)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426303)
                    this.Apu = "apu";
                    //--TRIMMABLE-BOUNDARY-END(12885426303)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180393599)
                    this.Apv = "apv";
                    //--TRIMMABLE-BOUNDARY-END(17180393599)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065295487)
                    this.Epk = "epk";
                    //--TRIMMABLE-BOUNDARY-END(30065295487)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475360895)
                    this.Cty = "cty";
                    //--TRIMMABLE-BOUNDARY-END(21475360895)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328191)
                    this.Enc = "enc";
                    //--TRIMMABLE-BOUNDARY-END(25770328191)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360262783)
                    this.IV = "iv";
                    //--TRIMMABLE-BOUNDARY-END(34360262783)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655230079)
                    this.Jku = "jku";
                    //--TRIMMABLE-BOUNDARY-END(38655230079)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950197375)
                    this.Jwk = "jwk";
                    //--TRIMMABLE-BOUNDARY-END(42950197375)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245164671)
                    this.Kid = "kid";
                    //--TRIMMABLE-BOUNDARY-END(47245164671)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540131967)
                    this.Typ = "typ";
                    //--TRIMMABLE-BOUNDARY-END(51540131967)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835099263)
                    this.X5c = "x5c";
                    //--TRIMMABLE-BOUNDARY-END(55835099263)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130066559)
                    this.X5t = "x5t";
                    //--TRIMMABLE-BOUNDARY-END(60130066559)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425033855)
                    this.X5u = "x5u";
                    //--TRIMMABLE-BOUNDARY-END(64425033855)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720001151)
                    this.Zip = "zip";
                    //--TRIMMABLE-BOUNDARY-END(68720001151)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 524415;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590459007),
    {
      "t": 1310721,
      "n": "Alg",
      "d": 524415,
      "h": 8590459007,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590459007),
//--TRIMMABLE-BOUNDARY-START(12885426303),
    {
      "t": 1310721,
      "n": "Apu",
      "d": 524415,
      "h": 12885426303,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426303),
//--TRIMMABLE-BOUNDARY-START(17180393599),
    {
      "t": 1310721,
      "n": "Apv",
      "d": 524415,
      "h": 17180393599,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393599),
//--TRIMMABLE-BOUNDARY-START(30065295487),
    {
      "t": 1310721,
      "n": "Epk",
      "d": 524415,
      "h": 30065295487,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295487),
//--TRIMMABLE-BOUNDARY-START(21475360895),
    {
      "t": 1310721,
      "n": "Cty",
      "d": 524415,
      "h": 21475360895,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360895),
//--TRIMMABLE-BOUNDARY-START(25770328191),
    {
      "t": 1310721,
      "n": "Enc",
      "d": 524415,
      "h": 25770328191,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328191),
//--TRIMMABLE-BOUNDARY-START(34360262783),
    {
      "t": 1310721,
      "n": "IV",
      "d": 524415,
      "h": 34360262783,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262783),
//--TRIMMABLE-BOUNDARY-START(38655230079),
    {
      "t": 1310721,
      "n": "Jku",
      "d": 524415,
      "h": 38655230079,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655230079),
//--TRIMMABLE-BOUNDARY-START(42950197375),
    {
      "t": 1310721,
      "n": "Jwk",
      "d": 524415,
      "h": 42950197375,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197375),
//--TRIMMABLE-BOUNDARY-START(47245164671),
    {
      "t": 1310721,
      "n": "Kid",
      "d": 524415,
      "h": 47245164671,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245164671),
//--TRIMMABLE-BOUNDARY-START(51540131967),
    {
      "t": 1310721,
      "n": "Typ",
      "d": 524415,
      "h": 51540131967,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540131967),
//--TRIMMABLE-BOUNDARY-START(55835099263),
    {
      "t": 1310721,
      "n": "X5c",
      "d": 524415,
      "h": 55835099263,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835099263),
//--TRIMMABLE-BOUNDARY-START(60130066559),
    {
      "t": 1310721,
      "n": "X5t",
      "d": 524415,
      "h": 60130066559,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066559),
//--TRIMMABLE-BOUNDARY-START(64425033855),
    {
      "t": 1310721,
      "n": "X5u",
      "d": 524415,
      "h": 64425033855,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425033855),
//--TRIMMABLE-BOUNDARY-START(68720001151),
    {
      "t": 1310721,
      "n": "Zip",
      "d": 524415,
      "h": 68720001151,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720001151)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491711),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524415,
      "h": 4295491711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491711)
  ],
  "h": 524415
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JwtHeaderParameterNames`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JwtHeaderParameterNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524415)
        
        

        //--TRIMMABLE-BOUNDARY-START(721023)
        $asm.$str(`$mij.MIJ.JwtRegisteredClaimNames`, ($self) => class JwtRegisteredClaimNames extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885622911)
            /*string*/ static Act = null;
            //--TRIMMABLE-BOUNDARY-END(12885622911)
            
            //--TRIMMABLE-BOUNDARY-START(17180590207)
            /*string*/ static Actort = null;
            //--TRIMMABLE-BOUNDARY-END(17180590207)
            
            //--TRIMMABLE-BOUNDARY-START(8590655615)
            /*string*/ static Acr = null;
            //--TRIMMABLE-BOUNDARY-END(8590655615)
            
            //--TRIMMABLE-BOUNDARY-START(21475557503)
            /*string*/ static Address = null;
            //--TRIMMABLE-BOUNDARY-END(21475557503)
            
            //--TRIMMABLE-BOUNDARY-START(25770524799)
            /*string*/ static Alg = null;
            //--TRIMMABLE-BOUNDARY-END(25770524799)
            
            //--TRIMMABLE-BOUNDARY-START(30065492095)
            /*string*/ static Amr = null;
            //--TRIMMABLE-BOUNDARY-END(30065492095)
            
            //--TRIMMABLE-BOUNDARY-START(38655426687)
            /*string*/ static Aud = null;
            //--TRIMMABLE-BOUNDARY-END(38655426687)
            
            //--TRIMMABLE-BOUNDARY-START(42950393983)
            /*string*/ static AuthTime = null;
            //--TRIMMABLE-BOUNDARY-END(42950393983)
            
            //--TRIMMABLE-BOUNDARY-START(47245361279)
            /*string*/ static Azp = null;
            //--TRIMMABLE-BOUNDARY-END(47245361279)
            
            //--TRIMMABLE-BOUNDARY-START(51540328575)
            /*string*/ static Birthdate = null;
            //--TRIMMABLE-BOUNDARY-END(51540328575)
            
            //--TRIMMABLE-BOUNDARY-START(55835295871)
            /*string*/ static CHash = null;
            //--TRIMMABLE-BOUNDARY-END(55835295871)
            
            //--TRIMMABLE-BOUNDARY-START(34360459391)
            /*string*/ static AtHash = null;
            //--TRIMMABLE-BOUNDARY-END(34360459391)
            
            //--TRIMMABLE-BOUNDARY-START(60130263167)
            /*string*/ static Email = null;
            //--TRIMMABLE-BOUNDARY-END(60130263167)
            
            //--TRIMMABLE-BOUNDARY-START(64425230463)
            /*string*/ static EmailVerified = null;
            //--TRIMMABLE-BOUNDARY-END(64425230463)
            
            //--TRIMMABLE-BOUNDARY-START(68720197759)
            /*string*/ static Exp = null;
            //--TRIMMABLE-BOUNDARY-END(68720197759)
            
            //--TRIMMABLE-BOUNDARY-START(77310132351)
            /*string*/ static Gender = null;
            //--TRIMMABLE-BOUNDARY-END(77310132351)
            
            //--TRIMMABLE-BOUNDARY-START(73015165055)
            /*string*/ static FamilyName = null;
            //--TRIMMABLE-BOUNDARY-END(73015165055)
            
            //--TRIMMABLE-BOUNDARY-START(81605099647)
            /*string*/ static GivenName = null;
            //--TRIMMABLE-BOUNDARY-END(81605099647)
            
            //--TRIMMABLE-BOUNDARY-START(85900066943)
            /*string*/ static Iat = null;
            //--TRIMMABLE-BOUNDARY-END(85900066943)
            
            //--TRIMMABLE-BOUNDARY-START(90195034239)
            /*string*/ static Iss = null;
            //--TRIMMABLE-BOUNDARY-END(90195034239)
            
            //--TRIMMABLE-BOUNDARY-START(94490001535)
            /*string*/ static Jti = null;
            //--TRIMMABLE-BOUNDARY-END(94490001535)
            
            //--TRIMMABLE-BOUNDARY-START(98784968831)
            /*string*/ static Locale = null;
            //--TRIMMABLE-BOUNDARY-END(98784968831)
            
            //--TRIMMABLE-BOUNDARY-START(103079936127)
            /*string*/ static MiddleName = null;
            //--TRIMMABLE-BOUNDARY-END(103079936127)
            
            //--TRIMMABLE-BOUNDARY-START(107374903423)
            /*string*/ static Name = null;
            //--TRIMMABLE-BOUNDARY-END(107374903423)
            
            //--TRIMMABLE-BOUNDARY-START(111669870719)
            /*string*/ static NameId = null;
            //--TRIMMABLE-BOUNDARY-END(111669870719)
            
            //--TRIMMABLE-BOUNDARY-START(120259805311)
            /*string*/ static Nickname = null;
            //--TRIMMABLE-BOUNDARY-END(120259805311)
            
            //--TRIMMABLE-BOUNDARY-START(124554772607)
            /*string*/ static Nonce = null;
            //--TRIMMABLE-BOUNDARY-END(124554772607)
            
            //--TRIMMABLE-BOUNDARY-START(115964838015)
            /*string*/ static Nbf = null;
            //--TRIMMABLE-BOUNDARY-END(115964838015)
            
            //--TRIMMABLE-BOUNDARY-START(128849739903)
            /*string*/ static PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(128849739903)
            
            //--TRIMMABLE-BOUNDARY-START(133144707199)
            /*string*/ static PhoneNumberVerified = null;
            //--TRIMMABLE-BOUNDARY-END(133144707199)
            
            //--TRIMMABLE-BOUNDARY-START(137439674495)
            /*string*/ static Picture = null;
            //--TRIMMABLE-BOUNDARY-END(137439674495)
            
            //--TRIMMABLE-BOUNDARY-START(146029609087)
            /*string*/ static Prn = null;
            //--TRIMMABLE-BOUNDARY-END(146029609087)
            
            //--TRIMMABLE-BOUNDARY-START(141734641791)
            /*string*/ static PreferredUsername = null;
            //--TRIMMABLE-BOUNDARY-END(141734641791)
            
            //--TRIMMABLE-BOUNDARY-START(150324576383)
            /*string*/ static Profile = null;
            //--TRIMMABLE-BOUNDARY-END(150324576383)
            
            //--TRIMMABLE-BOUNDARY-START(154619543679)
            /*string*/ static Sid = null;
            //--TRIMMABLE-BOUNDARY-END(154619543679)
            
            //--TRIMMABLE-BOUNDARY-START(158914510975)
            /*string*/ static Sub = null;
            //--TRIMMABLE-BOUNDARY-END(158914510975)
            
            //--TRIMMABLE-BOUNDARY-START(163209478271)
            /*string*/ static Typ = null;
            //--TRIMMABLE-BOUNDARY-END(163209478271)
            
            //--TRIMMABLE-BOUNDARY-START(167504445567)
            /*string*/ static UniqueName = null;
            //--TRIMMABLE-BOUNDARY-END(167504445567)
            
            //--TRIMMABLE-BOUNDARY-START(171799412863)
            /*string*/ static UpdatedAt = null;
            //--TRIMMABLE-BOUNDARY-END(171799412863)
            
            //--TRIMMABLE-BOUNDARY-START(176094380159)
            /*string*/ static Website = null;
            //--TRIMMABLE-BOUNDARY-END(176094380159)
            
            //--TRIMMABLE-BOUNDARY-START(180389347455)
            /*string*/ static ZoneInfo = null;
            //--TRIMMABLE-BOUNDARY-END(180389347455)
            
            //--TRIMMABLE-BOUNDARY-START(4295688319)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688319)
            
            //--TRIMMABLE-BOUNDARY-START(4295688319)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688319)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885622911)
                    this.Act = "act";
                    //--TRIMMABLE-BOUNDARY-END(12885622911)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180590207)
                    this.Actort = "actort";
                    //--TRIMMABLE-BOUNDARY-END(17180590207)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590655615)
                    this.Acr = "acr";
                    //--TRIMMABLE-BOUNDARY-END(8590655615)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475557503)
                    this.Address = "address";
                    //--TRIMMABLE-BOUNDARY-END(21475557503)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770524799)
                    this.Alg = "alg";
                    //--TRIMMABLE-BOUNDARY-END(25770524799)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065492095)
                    this.Amr = "amr";
                    //--TRIMMABLE-BOUNDARY-END(30065492095)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655426687)
                    this.Aud = "aud";
                    //--TRIMMABLE-BOUNDARY-END(38655426687)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950393983)
                    this.AuthTime = "auth_time";
                    //--TRIMMABLE-BOUNDARY-END(42950393983)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245361279)
                    this.Azp = "azp";
                    //--TRIMMABLE-BOUNDARY-END(47245361279)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540328575)
                    this.Birthdate = "birthdate";
                    //--TRIMMABLE-BOUNDARY-END(51540328575)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835295871)
                    this.CHash = "c_hash";
                    //--TRIMMABLE-BOUNDARY-END(55835295871)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360459391)
                    this.AtHash = "at_hash";
                    //--TRIMMABLE-BOUNDARY-END(34360459391)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130263167)
                    this.Email = "email";
                    //--TRIMMABLE-BOUNDARY-END(60130263167)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425230463)
                    this.EmailVerified = "email_verified";
                    //--TRIMMABLE-BOUNDARY-END(64425230463)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720197759)
                    this.Exp = "exp";
                    //--TRIMMABLE-BOUNDARY-END(68720197759)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310132351)
                    this.Gender = "gender";
                    //--TRIMMABLE-BOUNDARY-END(77310132351)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015165055)
                    this.FamilyName = "family_name";
                    //--TRIMMABLE-BOUNDARY-END(73015165055)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605099647)
                    this.GivenName = "given_name";
                    //--TRIMMABLE-BOUNDARY-END(81605099647)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900066943)
                    this.Iat = "iat";
                    //--TRIMMABLE-BOUNDARY-END(85900066943)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195034239)
                    this.Iss = "iss";
                    //--TRIMMABLE-BOUNDARY-END(90195034239)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490001535)
                    this.Jti = "jti";
                    //--TRIMMABLE-BOUNDARY-END(94490001535)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784968831)
                    this.Locale = "locale";
                    //--TRIMMABLE-BOUNDARY-END(98784968831)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079936127)
                    this.MiddleName = "middle_name";
                    //--TRIMMABLE-BOUNDARY-END(103079936127)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374903423)
                    this.Name = "name";
                    //--TRIMMABLE-BOUNDARY-END(107374903423)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669870719)
                    this.NameId = "nameid";
                    //--TRIMMABLE-BOUNDARY-END(111669870719)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259805311)
                    this.Nickname = "nickname";
                    //--TRIMMABLE-BOUNDARY-END(120259805311)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554772607)
                    this.Nonce = "nonce";
                    //--TRIMMABLE-BOUNDARY-END(124554772607)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964838015)
                    this.Nbf = "nbf";
                    //--TRIMMABLE-BOUNDARY-END(115964838015)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849739903)
                    this.PhoneNumber = "phone_number";
                    //--TRIMMABLE-BOUNDARY-END(128849739903)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144707199)
                    this.PhoneNumberVerified = "phone_number_verified";
                    //--TRIMMABLE-BOUNDARY-END(133144707199)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439674495)
                    this.Picture = "picture";
                    //--TRIMMABLE-BOUNDARY-END(137439674495)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029609087)
                    this.Prn = "prn";
                    //--TRIMMABLE-BOUNDARY-END(146029609087)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734641791)
                    this.PreferredUsername = "preferred_username";
                    //--TRIMMABLE-BOUNDARY-END(141734641791)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324576383)
                    this.Profile = "profile";
                    //--TRIMMABLE-BOUNDARY-END(150324576383)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619543679)
                    this.Sid = "sid";
                    //--TRIMMABLE-BOUNDARY-END(154619543679)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914510975)
                    this.Sub = "sub";
                    //--TRIMMABLE-BOUNDARY-END(158914510975)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209478271)
                    this.Typ = "typ";
                    //--TRIMMABLE-BOUNDARY-END(163209478271)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504445567)
                    this.UniqueName = "unique_name";
                    //--TRIMMABLE-BOUNDARY-END(167504445567)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799412863)
                    this.UpdatedAt = "updated_at";
                    //--TRIMMABLE-BOUNDARY-END(171799412863)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094380159)
                    this.Website = "website";
                    //--TRIMMABLE-BOUNDARY-END(176094380159)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389347455)
                    this.ZoneInfo = "zoneinfo";
                    //--TRIMMABLE-BOUNDARY-END(180389347455)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 721023;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622911),
    {
      "t": 1310721,
      "n": "Act",
      "d": 721023,
      "h": 12885622911,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622911),
//--TRIMMABLE-BOUNDARY-START(17180590207),
    {
      "t": 1310721,
      "n": "Actort",
      "d": 721023,
      "h": 17180590207,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590207),
//--TRIMMABLE-BOUNDARY-START(8590655615),
    {
      "t": 1310721,
      "n": "Acr",
      "d": 721023,
      "h": 8590655615,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655615),
//--TRIMMABLE-BOUNDARY-START(21475557503),
    {
      "t": 1310721,
      "n": "Address",
      "d": 721023,
      "h": 21475557503,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557503),
//--TRIMMABLE-BOUNDARY-START(25770524799),
    {
      "t": 1310721,
      "n": "Alg",
      "d": 721023,
      "h": 25770524799,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524799),
//--TRIMMABLE-BOUNDARY-START(30065492095),
    {
      "t": 1310721,
      "n": "Amr",
      "d": 721023,
      "h": 30065492095,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065492095),
//--TRIMMABLE-BOUNDARY-START(38655426687),
    {
      "t": 1310721,
      "n": "Aud",
      "d": 721023,
      "h": 38655426687,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655426687),
//--TRIMMABLE-BOUNDARY-START(42950393983),
    {
      "t": 1310721,
      "n": "AuthTime",
      "d": 721023,
      "h": 42950393983,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950393983),
//--TRIMMABLE-BOUNDARY-START(47245361279),
    {
      "t": 1310721,
      "n": "Azp",
      "d": 721023,
      "h": 47245361279,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245361279),
//--TRIMMABLE-BOUNDARY-START(51540328575),
    {
      "t": 1310721,
      "n": "Birthdate",
      "d": 721023,
      "h": 51540328575,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540328575),
//--TRIMMABLE-BOUNDARY-START(55835295871),
    {
      "t": 1310721,
      "n": "CHash",
      "d": 721023,
      "h": 55835295871,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835295871),
//--TRIMMABLE-BOUNDARY-START(34360459391),
    {
      "t": 1310721,
      "n": "AtHash",
      "d": 721023,
      "h": 34360459391,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360459391),
//--TRIMMABLE-BOUNDARY-START(60130263167),
    {
      "t": 1310721,
      "n": "Email",
      "d": 721023,
      "h": 60130263167,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130263167),
//--TRIMMABLE-BOUNDARY-START(64425230463),
    {
      "t": 1310721,
      "n": "EmailVerified",
      "d": 721023,
      "h": 64425230463,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425230463),
//--TRIMMABLE-BOUNDARY-START(68720197759),
    {
      "t": 1310721,
      "n": "Exp",
      "d": 721023,
      "h": 68720197759,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720197759),
//--TRIMMABLE-BOUNDARY-START(77310132351),
    {
      "t": 1310721,
      "n": "Gender",
      "d": 721023,
      "h": 77310132351,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310132351),
//--TRIMMABLE-BOUNDARY-START(73015165055),
    {
      "t": 1310721,
      "n": "FamilyName",
      "d": 721023,
      "h": 73015165055,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015165055),
//--TRIMMABLE-BOUNDARY-START(81605099647),
    {
      "t": 1310721,
      "n": "GivenName",
      "d": 721023,
      "h": 81605099647,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605099647),
//--TRIMMABLE-BOUNDARY-START(85900066943),
    {
      "t": 1310721,
      "n": "Iat",
      "d": 721023,
      "h": 85900066943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900066943),
//--TRIMMABLE-BOUNDARY-START(90195034239),
    {
      "t": 1310721,
      "n": "Iss",
      "d": 721023,
      "h": 90195034239,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195034239),
//--TRIMMABLE-BOUNDARY-START(94490001535),
    {
      "t": 1310721,
      "n": "Jti",
      "d": 721023,
      "h": 94490001535,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490001535),
//--TRIMMABLE-BOUNDARY-START(98784968831),
    {
      "t": 1310721,
      "n": "Locale",
      "d": 721023,
      "h": 98784968831,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784968831),
//--TRIMMABLE-BOUNDARY-START(103079936127),
    {
      "t": 1310721,
      "n": "MiddleName",
      "d": 721023,
      "h": 103079936127,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079936127),
//--TRIMMABLE-BOUNDARY-START(107374903423),
    {
      "t": 1310721,
      "n": "Name",
      "d": 721023,
      "h": 107374903423,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374903423),
//--TRIMMABLE-BOUNDARY-START(111669870719),
    {
      "t": 1310721,
      "n": "NameId",
      "d": 721023,
      "h": 111669870719,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669870719),
//--TRIMMABLE-BOUNDARY-START(120259805311),
    {
      "t": 1310721,
      "n": "Nickname",
      "d": 721023,
      "h": 120259805311,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259805311),
//--TRIMMABLE-BOUNDARY-START(124554772607),
    {
      "t": 1310721,
      "n": "Nonce",
      "d": 721023,
      "h": 124554772607,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554772607),
//--TRIMMABLE-BOUNDARY-START(115964838015),
    {
      "t": 1310721,
      "n": "Nbf",
      "d": 721023,
      "h": 115964838015,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964838015),
//--TRIMMABLE-BOUNDARY-START(128849739903),
    {
      "t": 1310721,
      "n": "PhoneNumber",
      "d": 721023,
      "h": 128849739903,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849739903),
//--TRIMMABLE-BOUNDARY-START(133144707199),
    {
      "t": 1310721,
      "n": "PhoneNumberVerified",
      "d": 721023,
      "h": 133144707199,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144707199),
//--TRIMMABLE-BOUNDARY-START(137439674495),
    {
      "t": 1310721,
      "n": "Picture",
      "d": 721023,
      "h": 137439674495,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439674495),
//--TRIMMABLE-BOUNDARY-START(146029609087),
    {
      "t": 1310721,
      "n": "Prn",
      "d": 721023,
      "h": 146029609087,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029609087),
//--TRIMMABLE-BOUNDARY-START(141734641791),
    {
      "t": 1310721,
      "n": "PreferredUsername",
      "d": 721023,
      "h": 141734641791,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734641791),
//--TRIMMABLE-BOUNDARY-START(150324576383),
    {
      "t": 1310721,
      "n": "Profile",
      "d": 721023,
      "h": 150324576383,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324576383),
//--TRIMMABLE-BOUNDARY-START(154619543679),
    {
      "t": 1310721,
      "n": "Sid",
      "d": 721023,
      "h": 154619543679,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619543679),
//--TRIMMABLE-BOUNDARY-START(158914510975),
    {
      "t": 1310721,
      "n": "Sub",
      "d": 721023,
      "h": 158914510975,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914510975),
//--TRIMMABLE-BOUNDARY-START(163209478271),
    {
      "t": 1310721,
      "n": "Typ",
      "d": 721023,
      "h": 163209478271,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209478271),
//--TRIMMABLE-BOUNDARY-START(167504445567),
    {
      "t": 1310721,
      "n": "UniqueName",
      "d": 721023,
      "h": 167504445567,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504445567),
//--TRIMMABLE-BOUNDARY-START(171799412863),
    {
      "t": 1310721,
      "n": "UpdatedAt",
      "d": 721023,
      "h": 171799412863,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799412863),
//--TRIMMABLE-BOUNDARY-START(176094380159),
    {
      "t": 1310721,
      "n": "Website",
      "d": 721023,
      "h": 176094380159,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094380159),
//--TRIMMABLE-BOUNDARY-START(180389347455),
    {
      "t": 1310721,
      "n": "ZoneInfo",
      "d": 721023,
      "h": 180389347455,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389347455)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688319),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721023,
      "h": 4295688319,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688319)
  ],
  "h": 721023
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JwtRegisteredClaimNames`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JwtRegisteredClaimNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721023)
        
        

        //--TRIMMABLE-BOUNDARY-START(589951)
        $asm.$str(`$mij.MIJ.JwtHeaderUtf8Bytes`, ($self) => class JwtHeaderUtf8Bytes extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590524543)
            static /*ReadOnlySpan<byte> */ get Alg()
            {
                return this.$cacheAlg ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 108, 103]);
            }
            //--TRIMMABLE-BOUNDARY-END(8590524543)
            
            //--TRIMMABLE-BOUNDARY-START(12885491839)
            static /*ReadOnlySpan<byte> */ get Apu()
            {
                return this.$cacheApu ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 112, 117]);
            }
            //--TRIMMABLE-BOUNDARY-END(12885491839)
            
            //--TRIMMABLE-BOUNDARY-START(17180459135)
            static /*ReadOnlySpan<byte> */ get Apv()
            {
                return this.$cacheApv ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 112, 118]);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459135)
            
            //--TRIMMABLE-BOUNDARY-START(21475426431)
            static /*ReadOnlySpan<byte> */ get Cty()
            {
                return this.$cacheCty ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([99, 116, 121]);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426431)
            
            //--TRIMMABLE-BOUNDARY-START(25770393727)
            static /*ReadOnlySpan<byte> */ get Enc()
            {
                return this.$cacheEnc ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([101, 110, 99]);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393727)
            
            //--TRIMMABLE-BOUNDARY-START(30065361023)
            static /*ReadOnlySpan<byte> */ get Epk()
            {
                return this.$cacheEpk ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([101, 112, 107]);
            }
            //--TRIMMABLE-BOUNDARY-END(30065361023)
            
            //--TRIMMABLE-BOUNDARY-START(163209347199)
            static /*ReadOnlySpan<byte> */ get IV()
            {
                return this.$cacheIV ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([105, 118]);
            }
            //--TRIMMABLE-BOUNDARY-END(163209347199)
            
            //--TRIMMABLE-BOUNDARY-START(167504314495)
            static /*ReadOnlySpan<byte> */ get Jku()
            {
                return this.$cacheJku ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([106, 107, 117]);
            }
            //--TRIMMABLE-BOUNDARY-END(167504314495)
            
            //--TRIMMABLE-BOUNDARY-START(171799281791)
            static /*ReadOnlySpan<byte> */ get Jwk()
            {
                return this.$cacheJwk ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([106, 119, 107]);
            }
            //--TRIMMABLE-BOUNDARY-END(171799281791)
            
            //--TRIMMABLE-BOUNDARY-START(176094249087)
            static /*ReadOnlySpan<byte> */ get Kid()
            {
                return this.$cacheKid ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([107, 105, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(176094249087)
            
            //--TRIMMABLE-BOUNDARY-START(180389216383)
            static /*ReadOnlySpan<byte> */ get Typ()
            {
                return this.$cacheTyp ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([116, 121, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(180389216383)
            
            //--TRIMMABLE-BOUNDARY-START(184684183679)
            static /*ReadOnlySpan<byte> */ get X5c()
            {
                return this.$cacheX5c ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([120, 53, 99]);
            }
            //--TRIMMABLE-BOUNDARY-END(184684183679)
            
            //--TRIMMABLE-BOUNDARY-START(188979150975)
            static /*ReadOnlySpan<byte> */ get X5t()
            {
                return this.$cacheX5t ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([120, 53, 116]);
            }
            //--TRIMMABLE-BOUNDARY-END(188979150975)
            
            //--TRIMMABLE-BOUNDARY-START(193274118271)
            static /*ReadOnlySpan<byte> */ get X5u()
            {
                return this.$cacheX5u ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([120, 53, 117]);
            }
            //--TRIMMABLE-BOUNDARY-END(193274118271)
            
            //--TRIMMABLE-BOUNDARY-START(197569085567)
            static /*ReadOnlySpan<byte> */ get Zip()
            {
                return this.$cacheZip ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([122, 105, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(197569085567)
            
            //--TRIMMABLE-BOUNDARY-START(4295557247)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557247)
            
            //--TRIMMABLE-BOUNDARY-START(4295557247)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557247)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 589951;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590524543),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655295615,
        "f": 50331681
      },
      "n": "Alg",
      "d": 589951,
      "h": 8590524543,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(8590524543),
//--TRIMMABLE-BOUNDARY-START(12885491839),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245230207,
        "f": 50331681
      },
      "n": "Apu",
      "d": 589951,
      "h": 12885491839,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885491839),
//--TRIMMABLE-BOUNDARY-START(17180459135),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835164799,
        "f": 50331681
      },
      "n": "Apv",
      "d": 589951,
      "h": 17180459135,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180459135),
//--TRIMMABLE-BOUNDARY-START(21475426431),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425099391,
        "f": 50331681
      },
      "n": "Cty",
      "d": 589951,
      "h": 21475426431,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21475426431),
//--TRIMMABLE-BOUNDARY-START(25770393727),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015033983,
        "f": 50331681
      },
      "n": "Enc",
      "d": 589951,
      "h": 25770393727,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770393727),
//--TRIMMABLE-BOUNDARY-START(30065361023),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604968575,
        "f": 50331681
      },
      "n": "Epk",
      "d": 589951,
      "h": 30065361023,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30065361023),
//--TRIMMABLE-BOUNDARY-START(163209347199),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194903167,
        "f": 50331681
      },
      "n": "IV",
      "d": 589951,
      "h": 163209347199,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(163209347199),
//--TRIMMABLE-BOUNDARY-START(167504314495),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784837759,
        "f": 50331681
      },
      "n": "Jku",
      "d": 589951,
      "h": 167504314495,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(167504314495),
//--TRIMMABLE-BOUNDARY-START(171799281791),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374772351,
        "f": 50331681
      },
      "n": "Jwk",
      "d": 589951,
      "h": 171799281791,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(171799281791),
//--TRIMMABLE-BOUNDARY-START(176094249087),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964706943,
        "f": 50331681
      },
      "n": "Kid",
      "d": 589951,
      "h": 176094249087,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(176094249087),
//--TRIMMABLE-BOUNDARY-START(180389216383),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554641535,
        "f": 50331681
      },
      "n": "Typ",
      "d": 589951,
      "h": 180389216383,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(180389216383),
//--TRIMMABLE-BOUNDARY-START(184684183679),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144576127,
        "f": 50331681
      },
      "n": "X5c",
      "d": 589951,
      "h": 184684183679,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(184684183679),
//--TRIMMABLE-BOUNDARY-START(188979150975),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734510719,
        "f": 50331681
      },
      "n": "X5t",
      "d": 589951,
      "h": 188979150975,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(188979150975),
//--TRIMMABLE-BOUNDARY-START(193274118271),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324445311,
        "f": 50331681
      },
      "n": "X5u",
      "d": 589951,
      "h": 193274118271,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(193274118271),
//--TRIMMABLE-BOUNDARY-START(197569085567),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914379903,
        "f": 50331681
      },
      "n": "Zip",
      "d": 589951,
      "h": 197569085567,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(197569085567)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557247),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589951,
      "h": 4295557247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557247)
  ],
  "h": 589951
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JwtHeaderUtf8Bytes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589951)
        
        

        //--TRIMMABLE-BOUNDARY-START(655487)
        $asm.$str(`$mij.MIJ.JwtPayloadUtf8Bytes`, ($self) => class JwtPayloadUtf8Bytes extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885557375)
            static /*ReadOnlySpan<byte> */ get Actort()
            {
                return this.$cacheActort ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 99, 116, 111, 114, 116]);
            }
            //--TRIMMABLE-BOUNDARY-END(12885557375)
            
            //--TRIMMABLE-BOUNDARY-START(8590590079)
            static /*ReadOnlySpan<byte> */ get Acr()
            {
                return this.$cacheAcr ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 99, 114]);
            }
            //--TRIMMABLE-BOUNDARY-END(8590590079)
            
            //--TRIMMABLE-BOUNDARY-START(17180524671)
            static /*ReadOnlySpan<byte> */ get Amr()
            {
                return this.$cacheAmr ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 109, 114]);
            }
            //--TRIMMABLE-BOUNDARY-END(17180524671)
            
            //--TRIMMABLE-BOUNDARY-START(21475491967)
            static /*ReadOnlySpan<byte> */ get AtHash()
            {
                return this.$cacheAtHash ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 116, 95, 104, 97, 115, 104]);
            }
            //--TRIMMABLE-BOUNDARY-END(21475491967)
            
            //--TRIMMABLE-BOUNDARY-START(25770459263)
            static /*ReadOnlySpan<byte> */ get Aud()
            {
                return this.$cacheAud ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 117, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(25770459263)
            
            //--TRIMMABLE-BOUNDARY-START(30065426559)
            static /*ReadOnlySpan<byte> */ get AuthTime()
            {
                return this.$cacheAuthTime ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 117, 116, 104, 95, 116, 105, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(30065426559)
            
            //--TRIMMABLE-BOUNDARY-START(34360393855)
            static /*ReadOnlySpan<byte> */ get Azp()
            {
                return this.$cacheAzp ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([97, 122, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(34360393855)
            
            //--TRIMMABLE-BOUNDARY-START(38655361151)
            static /*ReadOnlySpan<byte> */ get Birthdate()
            {
                return this.$cacheBirthdate ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([98, 105, 114, 116, 104, 100, 97, 116, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(38655361151)
            
            //--TRIMMABLE-BOUNDARY-START(42950328447)
            static /*ReadOnlySpan<byte> */ get CHash()
            {
                return this.$cacheCHash ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([99, 95, 104, 97, 115, 104]);
            }
            //--TRIMMABLE-BOUNDARY-END(42950328447)
            
            //--TRIMMABLE-BOUNDARY-START(47245295743)
            static /*ReadOnlySpan<byte> */ get Email()
            {
                return this.$cacheEmail ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([101, 109, 97, 105, 108]);
            }
            //--TRIMMABLE-BOUNDARY-END(47245295743)
            
            //--TRIMMABLE-BOUNDARY-START(51540263039)
            static /*ReadOnlySpan<byte> */ get Exp()
            {
                return this.$cacheExp ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([101, 120, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(51540263039)
            
            //--TRIMMABLE-BOUNDARY-START(60130197631)
            static /*ReadOnlySpan<byte> */ get Gender()
            {
                return this.$cacheGender ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([103, 101, 110, 100, 101, 114]);
            }
            //--TRIMMABLE-BOUNDARY-END(60130197631)
            
            //--TRIMMABLE-BOUNDARY-START(55835230335)
            static /*ReadOnlySpan<byte> */ get FamilyName()
            {
                return this.$cacheFamilyName ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([102, 97, 109, 105, 108, 121, 95, 110, 97, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(55835230335)
            
            //--TRIMMABLE-BOUNDARY-START(313533268095)
            static /*ReadOnlySpan<byte> */ get GivenName()
            {
                return this.$cacheGivenName ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([103, 105, 118, 101, 110, 95, 110, 97, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(313533268095)
            
            //--TRIMMABLE-BOUNDARY-START(317828235391)
            static /*ReadOnlySpan<byte> */ get Iat()
            {
                return this.$cacheIat ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([105, 97, 116]);
            }
            //--TRIMMABLE-BOUNDARY-END(317828235391)
            
            //--TRIMMABLE-BOUNDARY-START(322123202687)
            static /*ReadOnlySpan<byte> */ get Iss()
            {
                return this.$cacheIss ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([105, 115, 115]);
            }
            //--TRIMMABLE-BOUNDARY-END(322123202687)
            
            //--TRIMMABLE-BOUNDARY-START(326418169983)
            static /*ReadOnlySpan<byte> */ get Jti()
            {
                return this.$cacheJti ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([106, 116, 105]);
            }
            //--TRIMMABLE-BOUNDARY-END(326418169983)
            
            //--TRIMMABLE-BOUNDARY-START(330713137279)
            static /*ReadOnlySpan<byte> */ get Name()
            {
                return this.$cacheName ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([110, 97, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(330713137279)
            
            //--TRIMMABLE-BOUNDARY-START(335008104575)
            static /*ReadOnlySpan<byte> */ get NameId()
            {
                return this.$cacheNameId ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([110, 97, 109, 101, 105, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(335008104575)
            
            //--TRIMMABLE-BOUNDARY-START(343598039167)
            static /*ReadOnlySpan<byte> */ get Nonce()
            {
                return this.$cacheNonce ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([110, 111, 110, 99, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(343598039167)
            
            //--TRIMMABLE-BOUNDARY-START(339303071871)
            static /*ReadOnlySpan<byte> */ get Nbf()
            {
                return this.$cacheNbf ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([110, 98, 102]);
            }
            //--TRIMMABLE-BOUNDARY-END(339303071871)
            
            //--TRIMMABLE-BOUNDARY-START(347893006463)
            static /*ReadOnlySpan<byte> */ get PhoneNumber()
            {
                return this.$cachePhoneNumber ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([112, 104, 111, 110, 101, 95, 110, 117, 109, 98, 101, 114]);
            }
            //--TRIMMABLE-BOUNDARY-END(347893006463)
            
            //--TRIMMABLE-BOUNDARY-START(352187973759)
            static /*ReadOnlySpan<byte> */ get PhoneNumberVerified()
            {
                return this.$cachePhoneNumberVerified ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([112, 104, 111, 110, 101, 95, 110, 117, 109, 98, 101, 114, 95, 118, 101, 114, 105, 102, 105, 101, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(352187973759)
            
            //--TRIMMABLE-BOUNDARY-START(356482941055)
            static /*ReadOnlySpan<byte> */ get Prn()
            {
                return this.$cachePrn ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([112, 114, 110]);
            }
            //--TRIMMABLE-BOUNDARY-END(356482941055)
            
            //--TRIMMABLE-BOUNDARY-START(360777908351)
            static /*ReadOnlySpan<byte> */ get Sid()
            {
                return this.$cacheSid ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([115, 105, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(360777908351)
            
            //--TRIMMABLE-BOUNDARY-START(365072875647)
            static /*ReadOnlySpan<byte> */ get Sub()
            {
                return this.$cacheSub ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([115, 117, 98]);
            }
            //--TRIMMABLE-BOUNDARY-END(365072875647)
            
            //--TRIMMABLE-BOUNDARY-START(369367842943)
            static /*ReadOnlySpan<byte> */ get Typ()
            {
                return this.$cacheTyp ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([116, 121, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(369367842943)
            
            //--TRIMMABLE-BOUNDARY-START(373662810239)
            static /*ReadOnlySpan<byte> */ get UniqueName()
            {
                return this.$cacheUniqueName ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([117, 110, 105, 113, 117, 101, 95, 110, 97, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(373662810239)
            
            //--TRIMMABLE-BOUNDARY-START(377957777535)
            static /*ReadOnlySpan<byte> */ get Website()
            {
                return this.$cacheWebsite ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([119, 101, 98, 115, 105, 116, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(377957777535)
            
            //--TRIMMABLE-BOUNDARY-START(4295622783)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622783)
            
            //--TRIMMABLE-BOUNDARY-START(4295622783)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622783)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 655487;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885557375),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310066815,
        "f": 50331681
      },
      "n": "Actort",
      "d": 655487,
      "h": 12885557375,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885557375),
//--TRIMMABLE-BOUNDARY-START(8590590079),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132223,
        "f": 50331681
      },
      "n": "Acr",
      "d": 655487,
      "h": 8590590079,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(8590590079),
//--TRIMMABLE-BOUNDARY-START(17180524671),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900001407,
        "f": 50331681
      },
      "n": "Amr",
      "d": 655487,
      "h": 17180524671,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180524671),
//--TRIMMABLE-BOUNDARY-START(21475491967),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489935999,
        "f": 50331681
      },
      "n": "AtHash",
      "d": 655487,
      "h": 21475491967,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21475491967),
//--TRIMMABLE-BOUNDARY-START(25770459263),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079870591,
        "f": 50331681
      },
      "n": "Aud",
      "d": 655487,
      "h": 25770459263,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770459263),
//--TRIMMABLE-BOUNDARY-START(30065426559),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669805183,
        "f": 50331681
      },
      "n": "AuthTime",
      "d": 655487,
      "h": 30065426559,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30065426559),
//--TRIMMABLE-BOUNDARY-START(34360393855),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259739775,
        "f": 50331681
      },
      "n": "Azp",
      "d": 655487,
      "h": 34360393855,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360393855),
//--TRIMMABLE-BOUNDARY-START(38655361151),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849674367,
        "f": 50331681
      },
      "n": "Birthdate",
      "d": 655487,
      "h": 38655361151,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38655361151),
//--TRIMMABLE-BOUNDARY-START(42950328447),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439608959,
        "f": 50331681
      },
      "n": "CHash",
      "d": 655487,
      "h": 42950328447,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42950328447),
//--TRIMMABLE-BOUNDARY-START(47245295743),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029543551,
        "f": 50331681
      },
      "n": "Email",
      "d": 655487,
      "h": 47245295743,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47245295743),
//--TRIMMABLE-BOUNDARY-START(51540263039),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619478143,
        "f": 50331681
      },
      "n": "Exp",
      "d": 655487,
      "h": 51540263039,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51540263039),
//--TRIMMABLE-BOUNDARY-START(60130197631),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799347327,
        "f": 50331681
      },
      "n": "Gender",
      "d": 655487,
      "h": 60130197631,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(60130197631),
//--TRIMMABLE-BOUNDARY-START(55835230335),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209412735,
        "f": 50331681
      },
      "n": "FamilyName",
      "d": 655487,
      "h": 55835230335,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(55835230335),
//--TRIMMABLE-BOUNDARY-START(313533268095),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389281919,
        "f": 50331681
      },
      "n": "GivenName",
      "d": 655487,
      "h": 313533268095,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(313533268095),
//--TRIMMABLE-BOUNDARY-START(317828235391),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979216511,
        "f": 50331681
      },
      "n": "Iat",
      "d": 655487,
      "h": 317828235391,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(317828235391),
//--TRIMMABLE-BOUNDARY-START(322123202687),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569151103,
        "f": 50331681
      },
      "n": "Iss",
      "d": 655487,
      "h": 322123202687,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(322123202687),
//--TRIMMABLE-BOUNDARY-START(326418169983),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159085695,
        "f": 50331681
      },
      "n": "Jti",
      "d": 655487,
      "h": 326418169983,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(326418169983),
//--TRIMMABLE-BOUNDARY-START(330713137279),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749020287,
        "f": 50331681
      },
      "n": "Name",
      "d": 655487,
      "h": 330713137279,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(330713137279),
//--TRIMMABLE-BOUNDARY-START(335008104575),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338954879,
        "f": 50331681
      },
      "n": "NameId",
      "d": 655487,
      "h": 335008104575,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(335008104575),
//--TRIMMABLE-BOUNDARY-START(343598039167),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518824063,
        "f": 50331681
      },
      "n": "Nonce",
      "d": 655487,
      "h": 343598039167,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(343598039167),
//--TRIMMABLE-BOUNDARY-START(339303071871),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928889471,
        "f": 50331681
      },
      "n": "Nbf",
      "d": 655487,
      "h": 339303071871,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(339303071871),
//--TRIMMABLE-BOUNDARY-START(347893006463),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108758655,
        "f": 50331681
      },
      "n": "PhoneNumber",
      "d": 655487,
      "h": 347893006463,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(347893006463),
//--TRIMMABLE-BOUNDARY-START(352187973759),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698693247,
        "f": 50331681
      },
      "n": "PhoneNumberVerified",
      "d": 655487,
      "h": 352187973759,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(352187973759),
//--TRIMMABLE-BOUNDARY-START(356482941055),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288627839,
        "f": 50331681
      },
      "n": "Prn",
      "d": 655487,
      "h": 356482941055,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(356482941055),
//--TRIMMABLE-BOUNDARY-START(360777908351),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878562431,
        "f": 50331681
      },
      "n": "Sid",
      "d": 655487,
      "h": 360777908351,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(360777908351),
//--TRIMMABLE-BOUNDARY-START(365072875647),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468497023,
        "f": 50331681
      },
      "n": "Sub",
      "d": 655487,
      "h": 365072875647,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(365072875647),
//--TRIMMABLE-BOUNDARY-START(369367842943),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292058431615,
        "f": 50331681
      },
      "n": "Typ",
      "d": 655487,
      "h": 369367842943,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(369367842943),
//--TRIMMABLE-BOUNDARY-START(373662810239),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300648366207,
        "f": 50331681
      },
      "n": "UniqueName",
      "d": 655487,
      "h": 373662810239,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(373662810239),
//--TRIMMABLE-BOUNDARY-START(377957777535),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309238300799,
        "f": 50331681
      },
      "n": "Website",
      "d": 655487,
      "h": 377957777535,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(377957777535)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622783),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655487,
      "h": 4295622783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622783)
  ],
  "h": 655487
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JwtPayloadUtf8Bytes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655487)
        
        

        //--TRIMMABLE-BOUNDARY-START(262271)
        $asm.$cls(`$mij.MIJ.JsonWebToken`, ($self) => class JsonWebToken extends $.$mit.MIT$1.SecurityToken
        {
            //--TRIMMABLE-BOUNDARY-START(317827842175)
            /*JsonClaimSet */ CreateHeaderClaimSet$1(/*byte[]*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827842175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateHeaderClaimSet$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$14($.$$.S.Byte, bytes)));
            }
            //--TRIMMABLE-BOUNDARY-END(317827842175)
            
            //--TRIMMABLE-BOUNDARY-START(313532874879)
            /*JsonClaimSet */ CreateHeaderClaimSet(/*byte[]*/ bytes, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532874879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateHeaderClaimSet$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, bytes, 0, length)));
            }
            //--TRIMMABLE-BOUNDARY-END(313532874879)
            
            //--TRIMMABLE-BOUNDARY-START(322122809471)
            /*JsonClaimSet */ CreateHeaderClaimSet$2(/*ReadOnlySpan<byte>*/ byteSpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122809471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Utf8JsonReader*/ let reader = new $.$stj.STJ.Utf8JsonReader().$ctor$6(byteSpan, new $.$stj.STJ.JsonReaderOptions());
                if (!$.$mit.MITJ.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$stj.STJ.JsonException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Tokens.LogMessages.IDX11023*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.STJ.JsonTokenType)), $.$mil.MIL.LogHelper.MarkAsNonPII("Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.S.Int64)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.S.Int64)) ], null, null))));
                }
                /*Dictionary<string, object>*/ let claims = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$8($.trunc(byteSpan.Length / 32/*AverageJsonClaimLengthInBytes*/));
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        this.ReadHeaderValue($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), claims);
                    }
                    else if ($.$mit.MITJ.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), 2/*JsonTokenType.EndObject*/, false))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return new $.$mij.MIJ.JsonClaimSet().$ctor$2(claims);
            }
            //--TRIMMABLE-BOUNDARY-END(322122809471)
            
            //--TRIMMABLE-BOUNDARY-START(889058492543)
            /*void */ ReadHeaderValue(/*ref Utf8JsonReader*/ reader, /*IDictionary<string, object>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(889058492543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtHeaderUtf8Bytes.Alg))
                {
                    claims.SCG$IDictionary$$$$set_Item("alg"/*JwtHeaderParameterNames.Alg*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "alg"/*JwtHeaderParameterNames.Alg*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtHeaderUtf8Bytes.Cty))
                {
                    claims.SCG$IDictionary$$$$set_Item("cty"/*JwtHeaderParameterNames.Cty*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "cty"/*JwtHeaderParameterNames.Cty*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtHeaderUtf8Bytes.Kid))
                {
                    claims.SCG$IDictionary$$$$set_Item("kid"/*JwtHeaderParameterNames.Kid*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "kid"/*JwtHeaderParameterNames.Kid*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtHeaderUtf8Bytes.Typ))
                {
                    claims.SCG$IDictionary$$$$set_Item("typ"/*JwtHeaderParameterNames.Typ*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "typ"/*JwtHeaderParameterNames.Typ*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtHeaderUtf8Bytes.X5t))
                {
                    claims.SCG$IDictionary$$$$set_Item("x5t"/*JwtHeaderParameterNames.X5t*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "x5t"/*JwtHeaderParameterNames.X5t*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtHeaderUtf8Bytes.Zip))
                {
                    claims.SCG$IDictionary$$$$set_Item("zip"/*JwtHeaderParameterNames.Zip*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "zip"/*JwtHeaderParameterNames.Zip*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else 
                {
                    /*string*/ let claimName = reader.$v.GetString();
                    if (this.TryReadJwtClaim !== null)
                    {
                        /*object*/ let claimValue;
                        reader.$v.Read();
                        if (this.TryReadJwtClaim.Invoke(reader, 0/*JwtSegmentType.Header*/, claimName, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.S.Object)))
                        {
                            claims.SCG$IDictionary$$$$set_Item(claimName, claimValue);
                            reader.$v.Read();
                        }
                        else 
                        {
                            claims.SCG$IDictionary$$$$set_Item(claimName, $.$mit.MITJ.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, false));
                        }
                    }
                    else 
                    {
                        claims.SCG$IDictionary$$$$set_Item(claimName, $.$mit.MITJ.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, true));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(889058492543)
            
            //--TRIMMABLE-BOUNDARY-START(283468103807)
            /*int*/ static AverageJsonClaimLengthInBytes = 32;
            //--TRIMMABLE-BOUNDARY-END(283468103807)
            
            //--TRIMMABLE-BOUNDARY-START(326417776767)
            /*JsonClaimSet */ CreatePayloadClaimSet(/*byte[]*/ bytes, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417776767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreatePayloadClaimSet$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, bytes, 0, length)));
            }
            //--TRIMMABLE-BOUNDARY-END(326417776767)
            
            //--TRIMMABLE-BOUNDARY-START(330712744063)
            /*JsonClaimSet */ CreatePayloadClaimSet$1(/*ReadOnlySpan<byte>*/ byteSpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712744063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (byteSpan.Length === 0)
                {
                    return new $.$mij.MIJ.JsonClaimSet().$ctor$2((() =>
                    {
                        let $t14 = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                        return $t14;
                    })());
                }
                /*Utf8JsonReader*/ let reader = new $.$stj.STJ.Utf8JsonReader().$ctor$6(byteSpan, new $.$stj.STJ.JsonReaderOptions());
                if (!$.$mit.MITJ.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$stj.STJ.JsonException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Tokens.LogMessages.IDX11023*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.STJ.JsonTokenType)), $.$mil.MIL.LogHelper.MarkAsNonPII("Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.S.Int64)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.S.Int64)) ], null, null))));
                }
                /*Dictionary<string, object>*/ let claims = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$8($.trunc(byteSpan.Length / 32/*AverageJsonClaimLengthInBytes*/));
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        this.ReadPayloadValue($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), claims);
                    }
                    else if ($.$mit.MITJ.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), 2/*JsonTokenType.EndObject*/, false))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return new $.$mij.MIJ.JsonClaimSet().$ctor$2(claims);
            }
            //--TRIMMABLE-BOUNDARY-END(330712744063)
            
            //--TRIMMABLE-BOUNDARY-START(893353459839)
            /*void */ ReadPayloadValue(/*ref Utf8JsonReader*/ reader, /*IDictionary<string, object>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(893353459839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Aud))
                {
                    /*List<string>*/ let _audiences = (() =>
                    {
                        let $t18 = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                        return $t18;
                    })();
                    reader.$v.Read();
                    if (reader.$v.TokenType === 3/*JsonTokenType.StartArray*/)
                    {
                        $.$mit.MITJ.JsonSerializerPrimitives.ReadStringsSkipNulls(reader, _audiences, "aud"/*JwtRegisteredClaimNames.Aud*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/);
                        claims.SCG$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences);
                    }
                    else 
                    {
                        if (reader.$v.TokenType !== 11/*JsonTokenType.Null*/)
                        {
                            _audiences.Add($.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "aud"/*JwtRegisteredClaimNames.Aud*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, false));
                            claims.SCG$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences.get_Item(0));
                        }
                        else 
                        {
                            claims.SCG$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences);
                        }
                    }
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Azp))
                {
                    claims.SCG$IDictionary$$$$set_Item("azp"/*JwtRegisteredClaimNames.Azp*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "azp"/*JwtRegisteredClaimNames.Azp*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Exp))
                {
                    claims.SCG$IDictionary$$$$set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box($.$mit.MITJ.JsonSerializerPrimitives.ReadLong(reader, "exp"/*JwtRegisteredClaimNames.Exp*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.S.Int64));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Iat))
                {
                    claims.SCG$IDictionary$$$$set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box($.$mit.MITJ.JsonSerializerPrimitives.ReadLong(reader, "iat"/*JwtRegisteredClaimNames.Iat*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.S.Int64));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Iss))
                {
                    claims.SCG$IDictionary$$$$set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "iss"/*JwtRegisteredClaimNames.Iss*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Jti))
                {
                    claims.SCG$IDictionary$$$$set_Item("jti"/*JwtRegisteredClaimNames.Jti*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadString(reader, "jti"/*JwtRegisteredClaimNames.Jti*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Nbf))
                {
                    claims.SCG$IDictionary$$$$set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box($.$mit.MITJ.JsonSerializerPrimitives.ReadLong(reader, "nbf"/*JwtRegisteredClaimNames.Nbf*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.S.Int64));
                }
                else if (reader.$v.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Sub))
                {
                    claims.SCG$IDictionary$$$$set_Item("sub"/*JwtRegisteredClaimNames.Sub*/, $.$mit.MITJ.JsonSerializerPrimitives.ReadStringOrNumberAsString(reader, "sub"/*JwtRegisteredClaimNames.Sub*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true));
                }
                else 
                {
                    /*string*/ let claimName = reader.$v.GetString();
                    if (this.TryReadJwtClaim !== null)
                    {
                        /*object*/ let claimValue;
                        reader.$v.Read();
                        if (this.TryReadJwtClaim.Invoke(reader, 1/*JwtSegmentType.Payload*/, claimName, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.S.Object)))
                        {
                            claims.SCG$IDictionary$$$$set_Item(claimName, claimValue);
                            reader.$v.Read();
                        }
                        else 
                        {
                            claims.SCG$IDictionary$$$$set_Item(claimName, $.$mit.MITJ.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, false));
                        }
                    }
                    else 
                    {
                        claims.SCG$IDictionary$$$$set_Item(claimName, $.$mit.MITJ.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, true));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(893353459839)
            
            //--TRIMMABLE-BOUNDARY-START(304942940287)
            /*string*/ static ClassName = null;
            //--TRIMMABLE-BOUNDARY-END(304942940287)
            
            //--TRIMMABLE-BOUNDARY-START(4295229567)
            /*string*/ _act = null;
            //--TRIMMABLE-BOUNDARY-END(4295229567)
            
            //--TRIMMABLE-BOUNDARY-START(17180131455)
            /*string*/ _authenticationTag = null;
            //--TRIMMABLE-BOUNDARY-END(17180131455)
            
            //--TRIMMABLE-BOUNDARY-START(25770066047)
            /*string*/ _ciphertext = null;
            //--TRIMMABLE-BOUNDARY-END(25770066047)
            
            //--TRIMMABLE-BOUNDARY-START(38654967935)
            /*string*/ _encodedHeader = null;
            //--TRIMMABLE-BOUNDARY-END(38654967935)
            
            //--TRIMMABLE-BOUNDARY-START(42949935231)
            /*string*/ _encodedPayload = null;
            //--TRIMMABLE-BOUNDARY-END(42949935231)
            
            //--TRIMMABLE-BOUNDARY-START(47244902527)
            /*string*/ _encodedSignature = null;
            //--TRIMMABLE-BOUNDARY-END(47244902527)
            
            //--TRIMMABLE-BOUNDARY-START(51539869823)
            /*string*/ _encodedToken = null;
            //--TRIMMABLE-BOUNDARY-END(51539869823)
            
            //--TRIMMABLE-BOUNDARY-START(60129804415)
            /*string*/ _encryptedKey = null;
            //--TRIMMABLE-BOUNDARY-END(60129804415)
            
            //--TRIMMABLE-BOUNDARY-START(85899608191)
            /*string*/ _initializationVector = null;
            //--TRIMMABLE-BOUNDARY-END(85899608191)
            
            //--TRIMMABLE-BOUNDARY-START(12885164159)
            /*List<string>*/ _audiences = null;
            //--TRIMMABLE-BOUNDARY-END(12885164159)
            
            //--TRIMMABLE-BOUNDARY-START(55834837119)
            /*ReadOnlyMemory<char>*/ _encodedTokenMemory;
            //--TRIMMABLE-BOUNDARY-END(55834837119)
            
            //--TRIMMABLE-BOUNDARY-START(8590196863)
            /*string*/ _alg = null;
            //--TRIMMABLE-BOUNDARY-END(8590196863)
            
            //--TRIMMABLE-BOUNDARY-START(30065033343)
            /*string*/ _cty = null;
            //--TRIMMABLE-BOUNDARY-END(30065033343)
            
            //--TRIMMABLE-BOUNDARY-START(34360000639)
            /*string*/ _enc = null;
            //--TRIMMABLE-BOUNDARY-END(34360000639)
            
            //--TRIMMABLE-BOUNDARY-START(98784510079)
            /*string*/ _kid = null;
            //--TRIMMABLE-BOUNDARY-END(98784510079)
            
            //--TRIMMABLE-BOUNDARY-START(115964379263)
            /*string*/ _typ = null;
            //--TRIMMABLE-BOUNDARY-END(115964379263)
            
            //--TRIMMABLE-BOUNDARY-START(128849281151)
            /*string*/ _x5t = null;
            //--TRIMMABLE-BOUNDARY-END(128849281151)
            
            //--TRIMMABLE-BOUNDARY-START(133144248447)
            /*string*/ _zip = null;
            //--TRIMMABLE-BOUNDARY-END(133144248447)
            
            //--TRIMMABLE-BOUNDARY-START(21475098751)
            /*string*/ _azp = null;
            //--TRIMMABLE-BOUNDARY-END(21475098751)
            
            //--TRIMMABLE-BOUNDARY-START(64424771711)
            /*long?*/ _exp = null;
            //--TRIMMABLE-BOUNDARY-END(64424771711)
            
            //--TRIMMABLE-BOUNDARY-START(68719739007)
            /*DateTime?*/ _expDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(68719739007)
            
            //--TRIMMABLE-BOUNDARY-START(73014706303)
            /*long?*/ _iat = null;
            //--TRIMMABLE-BOUNDARY-END(73014706303)
            
            //--TRIMMABLE-BOUNDARY-START(77309673599)
            /*DateTime?*/ _iatDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(77309673599)
            
            //--TRIMMABLE-BOUNDARY-START(81604640895)
            /*string*/ _id = null;
            //--TRIMMABLE-BOUNDARY-END(81604640895)
            
            //--TRIMMABLE-BOUNDARY-START(90194575487)
            /*string*/ _iss = null;
            //--TRIMMABLE-BOUNDARY-END(90194575487)
            
            //--TRIMMABLE-BOUNDARY-START(94489542783)
            /*string*/ _jti = null;
            //--TRIMMABLE-BOUNDARY-END(94489542783)
            
            //--TRIMMABLE-BOUNDARY-START(111669411967)
            /*string*/ _sub = null;
            //--TRIMMABLE-BOUNDARY-END(111669411967)
            
            //--TRIMMABLE-BOUNDARY-START(103079477375)
            /*long?*/ _nbf = null;
            //--TRIMMABLE-BOUNDARY-END(103079477375)
            
            //--TRIMMABLE-BOUNDARY-START(107374444671)
            /*DateTime?*/ _nbfDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(107374444671)
            
            //--TRIMMABLE-BOUNDARY-START(120259346559)
            /*DateTime?*/ _validFrom = null;
            //--TRIMMABLE-BOUNDARY-END(120259346559)
            
            //--TRIMMABLE-BOUNDARY-START(124554313855)
            /*DateTime?*/ _validTo = null;
            //--TRIMMABLE-BOUNDARY-END(124554313855)
            
            //--TRIMMABLE-BOUNDARY-START(244813398143)
            $ctor$7(/*string*/ jwtEncodedString)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244813398143);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrEmpty(jwtEncodedString))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentNullException().$ctor$19("jwtEncodedString"));
                    }
                    this.ReadToken($.$$.S.MemoryExtensions.AsMemory$4(jwtEncodedString));
                    this._encodedToken = jwtEncodedString;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(244813398143)
            
            //--TRIMMABLE-BOUNDARY-START(231928496255)
            $ctor$4(/*string*/ jwtEncodedString, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231928496255);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrEmpty(jwtEncodedString))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentNullException().$ctor$19("jwtEncodedString"));
                    }
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken($.$$.S.MemoryExtensions.AsMemory$4(jwtEncodedString));
                    this._encodedToken = jwtEncodedString;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(231928496255)
            
            //--TRIMMABLE-BOUNDARY-START(227633528959)
            $ctor$3(/*ReadOnlyMemory<char>*/ encodedTokenMemory)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633528959);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (encodedTokenMemory.IsEmpty)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentNullException().$ctor$19("encodedTokenMemory"));
                    }
                    this.ReadToken(encodedTokenMemory);
                    this._encodedTokenMemory = encodedTokenMemory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(227633528959)
            
            //--TRIMMABLE-BOUNDARY-START(223338561663)
            $ctor$2(/*ReadOnlyMemory<char>*/ encodedTokenMemory, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(223338561663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (encodedTokenMemory.IsEmpty)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentNullException().$ctor$19("encodedTokenMemory"));
                    }
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken(encodedTokenMemory);
                    this._encodedTokenMemory = encodedTokenMemory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(223338561663)
            
            //--TRIMMABLE-BOUNDARY-START(240518430847)
            $ctor$6(/*string*/ header, /*string*/ payload)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240518430847);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrEmpty(header))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("header");
                    }
                    _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                    /*var*/ let encodedHeader = $.$mit.MIT$1.Base64UrlEncoder.Encode$3(header);
                    /*var*/ let encodedPayload = $.$mit.MIT$1.Base64UrlEncoder.Encode$3(payload);
                    /*var*/ let encodedToken = $.$strNN($.$strNN($.$strNN(encodedHeader) + ".") + $.$strNN(encodedPayload)) + ".";
                    this.ReadToken($.$$.S.MemoryExtensions.AsMemory$4(encodedToken));
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(240518430847)
            
            //--TRIMMABLE-BOUNDARY-START(236223463551)
            $ctor$5(/*string*/ header, /*string*/ payload, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236223463551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrEmpty(header))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("header");
                    }
                    _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                    /*var*/ let encodedHeader = $.$mit.MIT$1.Base64UrlEncoder.Encode$3(header);
                    /*var*/ let encodedPayload = $.$mit.MIT$1.Base64UrlEncoder.Encode$3(payload);
                    /*var*/ let encodedToken = $.$strNN($.$strNN($.$strNN(encodedHeader) + ".") + $.$strNN(encodedPayload)) + ".";
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken($.$$.S.MemoryExtensions.AsMemory$4(encodedToken));
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(236223463551)
            
            //--TRIMMABLE-BOUNDARY-START(249108365439)
            $ctor$8(/*JsonWebToken*/ jsonWebToken, /*string*/ encodedHeader)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249108365439);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = $.$firstOf(jsonWebToken, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("jsonWebToken") });
                    if ($.$$.S.String.IsNullOrEmpty(encodedHeader))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("encodedHeader");
                    }
                    if (jsonWebToken.IsEncrypted)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$13("IDX14117: Cannot create a 'JsonWebToken' with a replaced header from an encrypted (JWE) token. The provided token must be a JWS so that its decoded payload can be reused."/*LogMessages.IDX14117*/, "jsonWebToken"));
                    }
                    /*string*/ let encodedPayload = jsonWebToken.EncodedPayload;
                    /*string*/ let encodedSignature = jsonWebToken.EncodedSignature;
                    /*int*/ let totalLength = ((((((((encodedHeader.length + 1) | 0) + encodedPayload.length) | 0) + 1) | 0) + encodedSignature.length) | 0);
                    /*string*/ let encodedToken = $.$$.S.String.Create$10($.$$.S.ValueTuple$$$$($.$$.S.String, $.$$.S.String, $.$$.S.String), totalLength, new ($.$$.S.ValueTuple$$$$($.$$.S.String, $.$$.S.String, $.$$.S.String))().$ctor$3(encodedHeader, encodedPayload, encodedSignature), new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$$.S.ValueTuple$$$$($.$$.S.String, $.$$.S.String, $.$$.S.String)))().$ctor($.$mij.MIJ.JsonWebToken, /*static*/ (/*span*/ span, /*state*/ state) =>
                    {
                        /*var*/ let  [ header, payload, signature ] = $.$destructure(state, 3);
                        $.$$.S.MemoryExtensions.AsSpan$4(header).CopyTo(span);
                        /*int*/ let pos = header.length;
                        span._reference.SetAt(/*.*/ 46, pos++);
                        $.$$.S.MemoryExtensions.AsSpan$4(payload).CopyTo(span.Slice$1(pos));
                        pos += payload.length;
                        span._reference.SetAt(/*.*/ 46, pos++);
                        $.$$.S.MemoryExtensions.AsSpan$4(signature).CopyTo(span.Slice$1(pos));
                    }, $ybJkji ??= {"r":65537,"p":[{"n":"span","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"state","p":$.$$.S.ValueTuple$$$$($.$$.S.String, $.$$.S.String, $.$$.S.String).$h}],"n":"","d":262271,"h":0,"f":17825826}));
                    this.Dot1 = encodedHeader.length;
                    this.Dot2 = ((((this.Dot1 + 1) | 0) + encodedPayload.length) | 0);
                    this.Dot3 = -1;
                    this.IsSigned = encodedSignature.length > 0;
                    this.Header = this.CreateClaimSet($.$$.S.MemoryExtensions.AsSpan$4(encodedToken), 0, this.Dot1, true);
                    this.Payload = jsonWebToken.Payload;
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(249108365439)
            
            //--TRIMMABLE-BOUNDARY-START(1108101824639)
            /*TryReadJwtClaim*/ TryReadJwtClaim = null;
            //--TRIMMABLE-BOUNDARY-END(1108101824639)
            
            //--TRIMMABLE-BOUNDARY-START(261993267327)
            /*string*/ ActualIssuer = null;
            //--TRIMMABLE-BOUNDARY-END(261993267327)
            
            //--TRIMMABLE-BOUNDARY-START(257698300031)
            /*ClaimsIdentity*/ ActorClaimsIdentity = null;
            //--TRIMMABLE-BOUNDARY-END(257698300031)
            
            //--TRIMMABLE-BOUNDARY-START(274878169215)
            /*string */ get AuthenticationTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433791959167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._authenticationTag ??= this.AuthenticationTagBytes === null ? $.$$.S.String.Empty : $.$$.ST.Encoding.UTF8.GetString$1(this.AuthenticationTagBytes);
                return this._authenticationTag;
            }
            //--TRIMMABLE-BOUNDARY-END(274878169215)
            
            //--TRIMMABLE-BOUNDARY-START(279173136511)
            /*byte[]*/ AuthenticationTagBytes = null;
            //--TRIMMABLE-BOUNDARY-END(279173136511)
            
            //--TRIMMABLE-BOUNDARY-START(292058038399)
            /*string */ get Ciphertext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459561762943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._ciphertext ??= this.CipherTextBytes === null ? $.$$.S.String.Empty : $.$$.ST.Encoding.UTF8.GetString$1(this.CipherTextBytes);
                return this._ciphertext;
            }
            //--TRIMMABLE-BOUNDARY-END(292058038399)
            
            //--TRIMMABLE-BOUNDARY-START(296353005695)
            /*byte[]*/ CipherTextBytes = null;
            //--TRIMMABLE-BOUNDARY-END(296353005695)
            
            //--TRIMMABLE-BOUNDARY-START(339302678655)
            /*int*/ Dot1 = 0;
            //--TRIMMABLE-BOUNDARY-END(339302678655)
            
            //--TRIMMABLE-BOUNDARY-START(343597645951)
            /*int*/ Dot2 = 0;
            //--TRIMMABLE-BOUNDARY-END(343597645951)
            
            //--TRIMMABLE-BOUNDARY-START(347892613247)
            /*int*/ Dot3 = 0;
            //--TRIMMABLE-BOUNDARY-END(347892613247)
            
            //--TRIMMABLE-BOUNDARY-START(352187580543)
            /*int*/ Dot4 = 0;
            //--TRIMMABLE-BOUNDARY-END(352187580543)
            
            //--TRIMMABLE-BOUNDARY-START(360777515135)
            /*string */ get EncodedHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871174271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encodedHeader === null)
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedHeader = this._encodedTokenMemory.Span.Slice(0, this.Dot1).ToString();
                    }
                    else 
                    {
                        this._encodedHeader = (!(this._encodedToken === null)) ? $.$$.S.String.Substring.call(this._encodedToken, 0, this.Dot1) : $.$$.S.String.Empty;
                    }
                }
                return this._encodedHeader;
            }
            //--TRIMMABLE-BOUNDARY-END(360777515135)
            
            //--TRIMMABLE-BOUNDARY-START(377957384319)
            /*string */ get EncryptedKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571230912639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encryptedKey === null)
                {
                    this._encryptedKey = this.EncryptedKeyBytes === null ? $.$$.S.String.Empty : $.$$.ST.Encoding.UTF8.GetString$1(this.EncryptedKeyBytes);
                }
                return this._encryptedKey;
            }
            //--TRIMMABLE-BOUNDARY-END(377957384319)
            
            //--TRIMMABLE-BOUNDARY-START(382252351615)
            /*byte[]*/ EncryptedKeyBytes = null;
            //--TRIMMABLE-BOUNDARY-END(382252351615)
            
            //--TRIMMABLE-BOUNDARY-START(365072482431)
            /*string */ get EncodedPayload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461108863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encodedPayload === null)
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedPayload = this.IsEncrypted ? $.$$.S.String.Empty : this._encodedTokenMemory.Span.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0)).ToString();
                    }
                    else 
                    {
                        if (!(this._encodedToken === null))
                        {
                            this._encodedPayload = this.IsEncrypted ? $.$$.S.String.Empty : $.$$.S.String.Substring.call(this._encodedToken, ((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0));
                        }
                        else 
                        {
                            this._encodedPayload = $.$$.S.String.Empty;
                        }
                    }
                }
                return this._encodedPayload;
            }
            //--TRIMMABLE-BOUNDARY-END(365072482431)
            
            //--TRIMMABLE-BOUNDARY-START(369367449727)
            /*string */ get EncodedSignature()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051043455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encodedSignature === null)
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedSignature = this.IsEncrypted ? $.$$.S.String.Empty : this._encodedTokenMemory.Span.Slice(((this.Dot2 + 1) | 0), ((((this._encodedTokenMemory.Length - this.Dot2) | 0) - 1) | 0)).ToString();
                    }
                    else 
                    {
                        if (!(this._encodedToken === null))
                        {
                            this._encodedSignature = this.IsEncrypted ? $.$$.S.String.Empty : $.$$.S.String.Substring.call(this._encodedToken, ((this.Dot2 + 1) | 0), ((((this._encodedToken.length - this.Dot2) | 0) - 1) | 0));
                        }
                        else 
                        {
                            this._encodedSignature = $.$$.S.String.Empty;
                        }
                    }
                }
                return this._encodedSignature;
            }
            //--TRIMMABLE-BOUNDARY-END(369367449727)
            
            //--TRIMMABLE-BOUNDARY-START(373662417023)
            /*string */ get EncodedToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562640978047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encodedToken === null && !this._encodedTokenMemory.IsEmpty)
                {
                    this._encodedToken = this._encodedTokenMemory.ToString();
                }
                return this._encodedToken;
            }
            //--TRIMMABLE-BOUNDARY-END(373662417023)
            
            //--TRIMMABLE-BOUNDARY-START(824633983103)
            /*JsonClaimSet*/ Header = null;
            //--TRIMMABLE-BOUNDARY-END(824633983103)
            
            //--TRIMMABLE-BOUNDARY-START(828928950399)
            /*byte[]*/ HeaderAsciiBytes = null;
            //--TRIMMABLE-BOUNDARY-END(828928950399)
            
            //--TRIMMABLE-BOUNDARY-START(841813852287)
            /*byte[]*/ InitializationVectorBytes = null;
            //--TRIMMABLE-BOUNDARY-END(841813852287)
            
            //--TRIMMABLE-BOUNDARY-START(837518884991)
            /*string */ get InitializationVector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614180585599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.InitializationVectorBytes === null)
                {
                    this._initializationVector = this.InitializationVectorBytes === null ? $.$$.S.String.Empty : $.$$.ST.Encoding.UTF8.GetString$1(this.InitializationVectorBytes);
                }
                return this._initializationVector;
            }
            //--TRIMMABLE-BOUNDARY-END(837518884991)
            
            //--TRIMMABLE-BOUNDARY-START(846108819583)
            /*JsonWebToken*/ InnerToken = null;
            //--TRIMMABLE-BOUNDARY-END(846108819583)
            
            //--TRIMMABLE-BOUNDARY-START(850403786879)
            /*bool */ get IsEncrypted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639950389375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CipherTextBytes !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(850403786879)
            
            //--TRIMMABLE-BOUNDARY-START(854698754175)
            /*bool*/ IsSigned = false;
            //--TRIMMABLE-BOUNDARY-END(854698754175)
            
            //--TRIMMABLE-BOUNDARY-START(880468557951)
            /*JsonClaimSet*/ Payload = null;
            //--TRIMMABLE-BOUNDARY-END(880468557951)
            
            //--TRIMMABLE-BOUNDARY-START(901943394431)
            /*SecurityKey*/ SecurityKey = null;
            //--TRIMMABLE-BOUNDARY-END(901943394431)
            
            //--TRIMMABLE-BOUNDARY-START(1078037053567)
            /*SecurityKey*/ SigningKey = null;
            //--TRIMMABLE-BOUNDARY-END(1078037053567)
            
            //--TRIMMABLE-BOUNDARY-START(871878623359)
            /*byte[]*/ MessageBytes = null;
            //--TRIMMABLE-BOUNDARY-END(871878623359)
            
            //--TRIMMABLE-BOUNDARY-START(876173590655)
            /*int*/ NumberOfDots = 0;
            //--TRIMMABLE-BOUNDARY-END(876173590655)
            
            //--TRIMMABLE-BOUNDARY-START(897648427135)
            /*void */ ReadToken(/*ReadOnlyMemory<char>*/ encodedTokenMemory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(897648427135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let encodedTokenSpan = encodedTokenMemory.Span;
                this.Dot1 = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, encodedTokenSpan, /*.*/ 46);
                if (this.Dot1 === -1 || this.Dot1 === ((encodedTokenSpan.Length - 1) | 0))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX14100: JWT is not well formed, there are no dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14100*/));
                }
                this.Dot2 = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, encodedTokenSpan.Slice$1(((this.Dot1 + 1) | 0)), /*.*/ 46);
                if (this.Dot2 === -1)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX14120: JWT is not well formed, there is only one dot (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14120*/));
                }
                this.Dot2 = ((((this.Dot1 + this.Dot2) | 0) + 1) | 0);
                this.Dot3 = (this.Dot2 === ((encodedTokenSpan.Length - 1) | 0)) ? -1 : $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, encodedTokenSpan.Slice$1(((this.Dot2 + 1) | 0)), /*.*/ 46);
                if (this.Dot3 === -1)
                {
                    this.IsSigned = !(((this.Dot2 + 1) | 0) === encodedTokenSpan.Length);
                    try
                    {
                        this.Header = this.CreateClaimSet(encodedTokenSpan, 0, this.Dot1, true);
                    }
                    catch(ex)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$11($.$mil.MIL.LogHelper.FormatInvariant("IDX14102: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX14102*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsUnsafeSecurityArtifact(encodedTokenSpan.Slice(0, this.Dot1).ToString(), new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$dsp(t, $.$$.S.Object, ($t) => $t.ToString);
                        }, $oeAxXc ??= {"r":1310721,"p":[{"n":"t","p":131073}],"n":"","d":262271,"h":0,"f":17825794})) ], null, null)), ex));
                    }
                    try
                    {
                        this.Payload = this.CreateClaimSet(encodedTokenSpan, ((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0), false);
                    }
                    catch(ex)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$11($.$mil.MIL.LogHelper.FormatInvariant("IDX14101: Unable to decode the payload '{0}' as Base64Url encoded string."/*LogMessages.IDX14101*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsUnsafeSecurityArtifact(encodedTokenSpan.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0)).ToString(), new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$dsp(t, $.$$.S.Object, ($t) => $t.ToString);
                        }, $eMZQTd ??= {"r":1310721,"p":[{"n":"t","p":131073}],"n":"","d":262271,"h":0,"f":17825794})) ], null, null)), ex));
                    }
                }
                else 
                {
                    this.Payload = new $.$mij.MIJ.JsonClaimSet().$ctor$1();
                    this.Dot3 = ((((this.Dot2 + this.Dot3) | 0) + 1) | 0);
                    if (this.Dot3 === ((encodedTokenSpan.Length - 1) | 0))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14121*/));
                    }
                    this.Dot4 = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, encodedTokenSpan.Slice$1(((this.Dot3 + 1) | 0)), /*.*/ 46);
                    if (this.Dot4 === -1)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14121*/));
                    }
                    this.Dot4 = ((((this.Dot3 + this.Dot4) | 0) + 1) | 0);
                    if (this.Dot4 === ((encodedTokenSpan.Length - 1) | 0))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX14310: JWE authentication tag is missing."/*LogMessages.IDX14310*/));
                    }
                    if ($.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, encodedTokenSpan.Slice$1(((this.Dot4 + 1) | 0)), /*.*/ 46) !== -1)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX14122: JWT is not a well formed JWE, there are more than four dots (.) a JWE can have at most 4 dots.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14122*/));
                    }
                    /*ReadOnlySpan<char>*/ let headerSpan = encodedTokenSpan.Slice(0, this.Dot1);
                    if (headerSpan.IsEmpty)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14("IDX14307: JWE header is missing."/*LogMessages.IDX14307*/));
                    }
                    /*byte[]*/ let headerAsciiBytes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [headerSpan.Length], null);
                    $.$$.ST.Encoding.ASCII.GetBytes$5(headerSpan, $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(headerAsciiBytes));
                    this.HeaderAsciiBytes = headerAsciiBytes;
                    try
                    {
                        this.Header = this.CreateHeaderClaimSet$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$14($.$$.S.Byte, $.$mit.MIT$1.Base64UrlEncoder.Decode$2(headerSpan))));
                    }
                    catch(ex)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$11($.$mil.MIL.LogHelper.FormatInvariant("IDX14102: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX14102*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsUnsafeSecurityArtifact(headerSpan.ToString(), new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$dsp(t, $.$$.S.Object, ($t) => $t.ToString);
                        }, $XYcHok ??= {"r":1310721,"p":[{"n":"t","p":131073}],"n":"","d":262271,"h":0,"f":17825794})) ], null, null)), ex));
                    }
                    /*ReadOnlySpan<char>*/ let encryptedKeyBytes = encodedTokenSpan.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0));
                    if (!encryptedKeyBytes.IsEmpty)
                    {
                        this.EncryptedKeyBytes = $.$mit.MIT$1.Base64UrlEncoder.Decode$2(encryptedKeyBytes);
                        this._encryptedKey = encryptedKeyBytes.ToString();
                    }
                    else 
                    {
                        this._encryptedKey = $.$$.S.String.Empty;
                    }
                    /*ReadOnlySpan<char>*/ let initializationVectorSpan = encodedTokenSpan.Slice(((this.Dot2 + 1) | 0), ((((this.Dot3 - this.Dot2) | 0) - 1) | 0));
                    if (initializationVectorSpan.IsEmpty)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14("IDX14308: JWE initialization vector is missing."/*LogMessages.IDX14308*/));
                    }
                    try
                    {
                        this.InitializationVectorBytes = $.$mit.MIT$1.Base64UrlEncoder.Decode$2(initializationVectorSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$11("IDX14309: Unable to decode the initialization vector as Base64Url encoded string."/*LogMessages.IDX14309*/, ex));
                    }
                    /*ReadOnlySpan<char>*/ let authTagSpan = encodedTokenSpan.Slice$1(((this.Dot4 + 1) | 0));
                    if (authTagSpan.IsEmpty)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14("IDX14310: JWE authentication tag is missing."/*LogMessages.IDX14310*/));
                    }
                    try
                    {
                        this.AuthenticationTagBytes = $.$mit.MIT$1.Base64UrlEncoder.Decode$2(authTagSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$11("IDX14311: Unable to decode the authentication tag as a Base64Url encoded string."/*LogMessages.IDX14311*/, ex));
                    }
                    /*ReadOnlySpan<char>*/ let cipherTextSpan = encodedTokenSpan.Slice(((this.Dot3 + 1) | 0), ((((this.Dot4 - this.Dot3) | 0) - 1) | 0));
                    if (cipherTextSpan.IsEmpty)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14("IDX14306: JWE Ciphertext cannot be an empty string."/*LogMessages.IDX14306*/));
                    }
                    try
                    {
                        this.CipherTextBytes = $.$mit.MIT$1.Base64UrlEncoder.Decode$2(cipherTextSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$11("IDX14312: Unable to decode the cipher text as a Base64Url encoded string."/*LogMessages.IDX14312*/, ex));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(897648427135)
            
            //--TRIMMABLE-BOUNDARY-START(309237907583)
            /*JsonClaimSet */ CreateClaimSet(/*ReadOnlySpan<char>*/ strSpan, /*int*/ startIndex, /*int*/ length, /*bool*/ createHeaderClaimSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237907583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let outputSize = $.$mit.MIT$1.Base64UrlEncoding.ValidateAndGetOutputSize(strSpan, startIndex, length);
                /*byte[]*/ let rented = null;
                /*int*/ let MaxStackallocThreshold = 256;
                /*Span<byte>*/ let output = outputSize <= MaxStackallocThreshold ? $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, outputSize, null) : $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rented = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(outputSize));
                try
                {
                    $.$mit.MIT$1.Base64UrlEncoder.Decode$1(strSpan.Slice(startIndex, length), output);
                    return createHeaderClaimSet ? this.CreateHeaderClaimSet$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit(output)) : this.CreatePayloadClaimSet$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit(output));
                }
                finally
                {
                    {
                        if (!(rented === null))
                        {
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(rented, true);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309237907583)
            
            //--TRIMMABLE-BOUNDARY-START(1086626988159)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1086626988159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Substring.call(this.EncodedToken, 0, $.$$.S.String.LastIndexOf$2.call(this.EncodedToken, /*.*/ 46));
            }
            //--TRIMMABLE-BOUNDARY-END(1086626988159)
            
            //--TRIMMABLE-BOUNDARY-START(1116691759231)
            /*string */ UnsafeToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(1116691759231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.EncodedToken;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1116691759231)
            
            //--TRIMMABLE-BOUNDARY-START(300647972991)
            /*IEnumerable<Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476741632127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payload.Claims(this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/);
            }
            //--TRIMMABLE-BOUNDARY-END(300647972991)
            
            //--TRIMMABLE-BOUNDARY-START(807454113919)
            /*Claim */ GetClaim(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807454113919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payload.GetClaim(key, this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/);
            }
            //--TRIMMABLE-BOUNDARY-END(807454113919)
            
            //--TRIMMABLE-BOUNDARY-START(884763525247)
            /*IReadOnlyCollection<string> */ get PayloadClaimNames()
            {
                return this.Payload._jsonClaims.Keys;
            }
            //--TRIMMABLE-BOUNDARY-END(884763525247)
            
            //--TRIMMABLE-BOUNDARY-START(1090921955455)
            /*bool */ TryGetClaim(/*string*/ key, /*out Claim*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1090921955455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payload.TryGetClaim(key, this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(1090921955455)
            
            //--TRIMMABLE-BOUNDARY-START(820339015807)
            /*bool */ HasPayloadClaim(/*string*/ claimName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(820339015807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payload.HasClaim(claimName);
            }
            //--TRIMMABLE-BOUNDARY-END(820339015807)
            
            //--TRIMMABLE-BOUNDARY-START(811749081215)
            /*T */ GetHeaderValue(T, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811749081215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("key");
                }
                return this.Header.GetValue$1(T, key);
            }
            //--TRIMMABLE-BOUNDARY-END(811749081215)
            
            //--TRIMMABLE-BOUNDARY-START(816044048511)
            /*T */ GetPayloadValue(T, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816044048511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("key");
                }
                if (T.$type.Equals$2($.$ssc.SSC.Claim.$type))
                {
                    return $.$cast(this.GetClaim(key), T);
                }
                return this.Payload.GetValue$1(T, key);
            }
            //--TRIMMABLE-BOUNDARY-END(816044048511)
            
            //--TRIMMABLE-BOUNDARY-START(1103806857343)
            /*bool */ TryGetValue(T, /*string*/ key, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1103806857343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                return this.Payload.TryGetValue(T, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(1103806857343)
            
            //--TRIMMABLE-BOUNDARY-START(1095216922751)
            /*bool */ TryGetHeaderValue(T, /*string*/ key, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1095216922751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                return this.Header.TryGetValue(T, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(1095216922751)
            
            //--TRIMMABLE-BOUNDARY-START(1099511890047)
            /*bool */ TryGetPayloadValue(T, /*string*/ key, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1099511890047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                if (T.$type.Equals$2($.$ssc.SSC.Claim.$type))
                {
                    /*var*/ let claim;
                    /*bool*/ let foundClaim = this.TryGetClaim(key, $.$ref(() => claim, ($v) => claim = $v, $.$ssc.SSC.Claim));
                    value.$v = $.$cast(claim, T);
                    return foundClaim;
                }
                return this.Payload.TryGetValue(T, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(1099511890047)
            
            //--TRIMMABLE-BOUNDARY-START(266288234623)
            /*string */ get Alg()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612089983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._alg ??= this.Header.GetStringValue("alg"/*JwtHeaderParameterNames.Alg*/);
                return this._alg;
            }
            //--TRIMMABLE-BOUNDARY-END(266288234623)
            
            //--TRIMMABLE-BOUNDARY-START(335007711359)
            /*string */ get Cty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485331566719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._cty ??= this.Header.GetStringValue("cty"/*JwtHeaderParameterNames.Cty*/);
                return this._cty;
            }
            //--TRIMMABLE-BOUNDARY-END(335007711359)
            
            //--TRIMMABLE-BOUNDARY-START(356482547839)
            /*string */ get Enc()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281239679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._enc ??= this.Header.GetStringValue("enc"/*JwtHeaderParameterNames.Enc*/);
                return this._enc;
            }
            //--TRIMMABLE-BOUNDARY-END(356482547839)
            
            //--TRIMMABLE-BOUNDARY-START(867583656063)
            /*string */ get Kid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(674310127743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._kid ??= this.Header.GetStringValue("kid"/*JwtHeaderParameterNames.Kid*/);
                return this._kid;
            }
            //--TRIMMABLE-BOUNDARY-END(867583656063)
            
            //--TRIMMABLE-BOUNDARY-START(1112396791935)
            /*string */ get Typ()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(751619539071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._typ ??= this.Header.GetStringValue("typ"/*JwtHeaderParameterNames.Typ*/);
                return this._typ;
            }
            /*string */ set Typ(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1073742086271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._typ = value;
            }
            //--TRIMMABLE-BOUNDARY-END(1112396791935)
            
            //--TRIMMABLE-BOUNDARY-START(1138166595711)
            /*string */ get X5t()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(794569212031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._x5t ??= this.Header.GetStringValue("x5t"/*JwtHeaderParameterNames.X5t*/);
                return this._x5t;
            }
            //--TRIMMABLE-BOUNDARY-END(1138166595711)
            
            //--TRIMMABLE-BOUNDARY-START(1142461563007)
            /*string */ get Zip()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(803159146623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._zip ??= this.Header.GetStringValue("zip"/*JwtHeaderParameterNames.Zip*/);
                return this._zip;
            }
            //--TRIMMABLE-BOUNDARY-END(1142461563007)
            
            //--TRIMMABLE-BOUNDARY-START(253403332735)
            /*string */ get Actor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842286207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._act ??= this.Payload.GetStringValue("actort"/*JwtRegisteredClaimNames.Actort*/);
                return this._act;
            }
            //--TRIMMABLE-BOUNDARY-END(253403332735)
            
            //--TRIMMABLE-BOUNDARY-START(270583201919)
            /*IEnumerable<string> */ get Audiences()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202024575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._audiences === null)
                {
                    /*List<string>*/ let audiences;
                    /*List<string>*/ let tmp = this.TryGetValue($.$$.SCG.List$$($.$$.S.String), "aud"/*JwtRegisteredClaimNames.Aud*/, $.$ref(() => audiences, ($v) => audiences = $v, $.$$.SCG.List$$($.$$.S.String))) ? audiences : new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                    $.$$.ST$1.Interlocked.CompareExchange$14($.$$.SCG.List$$($.$$.S.String), $.$ref(() => this._audiences, ($v) => this._audiences = $v, $.$$.SCG.List$$($.$$.S.String)), tmp, null);
                }
                return this._audiences;
            }
            //--TRIMMABLE-BOUNDARY-END(270583201919)
            
            //--TRIMMABLE-BOUNDARY-START(287763071103)
            /*string */ get Azp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450971828351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._azp ??= this.Payload.GetStringValue("azp"/*JwtRegisteredClaimNames.Azp*/);
                return this._azp;
            }
            //--TRIMMABLE-BOUNDARY-END(287763071103)
            
            //--TRIMMABLE-BOUNDARY-START(858993721471)
            /*DateTime */ get IssuedAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657130258559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._iatDateTime ??= this.Payload.GetDateTime("iat"/*JwtRegisteredClaimNames.Iat*/);
                return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._iatDateTime);
            }
            //--TRIMMABLE-BOUNDARY-END(858993721471)
            
            //--TRIMMABLE-BOUNDARY-START(863288688767)
            /*string */ get Issuer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(665720193151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._iss ??= this.Payload.GetStringValue("iss"/*JwtRegisteredClaimNames.Iss*/);
                return this._iss;
            }
            //--TRIMMABLE-BOUNDARY-END(863288688767)
            
            //--TRIMMABLE-BOUNDARY-START(833223917695)
            /*string */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605590651007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._jti ??= this.Payload.GetStringValue("jti"/*JwtRegisteredClaimNames.Jti*/);
                return this._jti;
            }
            //--TRIMMABLE-BOUNDARY-END(833223917695)
            
            //--TRIMMABLE-BOUNDARY-START(1082332020863)
            /*string */ get Subject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(734439669887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._sub ??= this.Payload.GetStringValue("sub"/*JwtRegisteredClaimNames.Sub*/);
                return this._sub;
            }
            //--TRIMMABLE-BOUNDARY-END(1082332020863)
            
            //--TRIMMABLE-BOUNDARY-START(1120986726527)
            /*DateTime */ get ValidFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(760209473663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validFrom ??= this.Payload.GetDateTime("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._validFrom);
            }
            //--TRIMMABLE-BOUNDARY-END(1120986726527)
            
            //--TRIMMABLE-BOUNDARY-START(1125281693823)
            /*DateTime? */ get ValidFromNullable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(768799408255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validFrom ??= this.Payload.GetDateTime("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                return $.$clone(this._validFrom);
            }
            //--TRIMMABLE-BOUNDARY-END(1125281693823)
            
            //--TRIMMABLE-BOUNDARY-START(1129576661119)
            /*DateTime */ get ValidTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(777389342847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validTo ??= this.Payload.GetDateTime("exp"/*JwtRegisteredClaimNames.Exp*/);
                return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._validTo);
            }
            //--TRIMMABLE-BOUNDARY-END(1129576661119)
            
            //--TRIMMABLE-BOUNDARY-START(1133871628415)
            /*DateTime? */ get ValidToNullable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(785979277439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validTo ??= this.Payload.GetDateTime("exp"/*JwtRegisteredClaimNames.Exp*/);
                return $.$clone(this._validTo);
            }
            //--TRIMMABLE-BOUNDARY-END(1133871628415)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55834837119)
                this._encodedTokenMemory = $.$default($.$$.S.ReadOnlyMemory$$($.$$.S.Char));
                //--TRIMMABLE-BOUNDARY-END(55834837119)
                
                //--TRIMMABLE-BOUNDARY-START(68719739007)
                this._expDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(68719739007)
                
                //--TRIMMABLE-BOUNDARY-START(77309673599)
                this._iatDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(77309673599)
                
                //--TRIMMABLE-BOUNDARY-START(107374444671)
                this._nbfDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(107374444671)
                
                //--TRIMMABLE-BOUNDARY-START(120259346559)
                this._validFrom = null;
                //--TRIMMABLE-BOUNDARY-END(120259346559)
                
                //--TRIMMABLE-BOUNDARY-START(124554313855)
                this._validTo = null;
                //--TRIMMABLE-BOUNDARY-END(124554313855)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(304942940287)
                    this.ClassName = "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken";
                    //--TRIMMABLE-BOUNDARY-END(304942940287)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 262271;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mit.MIT$1.SecurityToken; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(1108101824639),
    {
      "p": 16973950,
      "g": {
        "r": 0,
        "d": 0,
        "h": 743029604479,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1065152151679,
        "f": 83886082
      },
      "n": "TryReadJwtClaim",
      "d": 262271,
      "h": 1108101824639,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(1108101824639),
//--TRIMMABLE-BOUNDARY-START(261993267327),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408022155391,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 919123263615,
        "f": 83886088
      },
      "n": "ActualIssuer",
      "d": 262271,
      "h": 261993267327,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(261993267327),
//--TRIMMABLE-BOUNDARY-START(257698300031),
    {
      "p": 262213,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399432220799,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 910533329023,
        "f": 83886088
      },
      "n": "ActorClaimsIdentity",
      "d": 262271,
      "h": 257698300031,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(257698300031),
//--TRIMMABLE-BOUNDARY-START(274878169215),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433791959167,
        "f": 50331649
      },
      "n": "AuthenticationTag",
      "d": 262271,
      "h": 274878169215,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878169215),
//--TRIMMABLE-BOUNDARY-START(279173136511),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442381893759,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 927713198207,
        "f": 83886088
      },
      "n": "AuthenticationTagBytes",
      "d": 262271,
      "h": 279173136511,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(279173136511),
//--TRIMMABLE-BOUNDARY-START(292058038399),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459561762943,
        "f": 50331649
      },
      "n": "Ciphertext",
      "d": 262271,
      "h": 292058038399,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292058038399),
//--TRIMMABLE-BOUNDARY-START(296353005695),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 468151697535,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 936303132799,
        "f": 83886088
      },
      "n": "CipherTextBytes",
      "d": 262271,
      "h": 296353005695,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(296353005695),
//--TRIMMABLE-BOUNDARY-START(339302678655),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 493921501311,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 944893067391,
        "f": 83886088
      },
      "n": "Dot1",
      "d": 262271,
      "h": 339302678655,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(339302678655),
//--TRIMMABLE-BOUNDARY-START(343597645951),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 502511435903,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 953483001983,
        "f": 83886088
      },
      "n": "Dot2",
      "d": 262271,
      "h": 343597645951,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(343597645951),
//--TRIMMABLE-BOUNDARY-START(347892613247),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 511101370495,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 962072936575,
        "f": 83886088
      },
      "n": "Dot3",
      "d": 262271,
      "h": 347892613247,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(347892613247),
//--TRIMMABLE-BOUNDARY-START(352187580543),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 519691305087,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 970662871167,
        "f": 83886088
      },
      "n": "Dot4",
      "d": 262271,
      "h": 352187580543,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(352187580543),
//--TRIMMABLE-BOUNDARY-START(360777515135),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 536871174271,
        "f": 50331649
      },
      "n": "EncodedHeader",
      "d": 262271,
      "h": 360777515135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(360777515135),
//--TRIMMABLE-BOUNDARY-START(377957384319),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 571230912639,
        "f": 50331649
      },
      "n": "EncryptedKey",
      "d": 262271,
      "h": 377957384319,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(377957384319),
//--TRIMMABLE-BOUNDARY-START(382252351615),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 579820847231,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 979252805759,
        "f": 83886088
      },
      "n": "EncryptedKeyBytes",
      "d": 262271,
      "h": 382252351615,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(382252351615),
//--TRIMMABLE-BOUNDARY-START(365072482431),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 545461108863,
        "f": 50331649
      },
      "n": "EncodedPayload",
      "d": 262271,
      "h": 365072482431,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(365072482431),
//--TRIMMABLE-BOUNDARY-START(369367449727),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 554051043455,
        "f": 50331649
      },
      "n": "EncodedSignature",
      "d": 262271,
      "h": 369367449727,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(369367449727),
//--TRIMMABLE-BOUNDARY-START(373662417023),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 562640978047,
        "f": 50331649
      },
      "n": "EncodedToken",
      "d": 262271,
      "h": 373662417023,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(373662417023),
//--TRIMMABLE-BOUNDARY-START(824633983103),
    {
      "p": 131199,
      "g": {
        "r": 0,
        "d": 0,
        "h": 588410781823,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 987842740351,
        "f": 83886088
      },
      "n": "Header",
      "d": 262271,
      "h": 824633983103,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(824633983103),
//--TRIMMABLE-BOUNDARY-START(828928950399),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 597000716415,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 996432674943,
        "f": 83886088
      },
      "n": "HeaderAsciiBytes",
      "d": 262271,
      "h": 828928950399,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(828928950399),
//--TRIMMABLE-BOUNDARY-START(841813852287),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 622770520191,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1005022609535,
        "f": 83886088
      },
      "n": "InitializationVectorBytes",
      "d": 262271,
      "h": 841813852287,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(841813852287),
//--TRIMMABLE-BOUNDARY-START(837518884991),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 614180585599,
        "f": 50331649
      },
      "n": "InitializationVector",
      "d": 262271,
      "h": 837518884991,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(837518884991),
//--TRIMMABLE-BOUNDARY-START(846108819583),
    {
      "p": 262271,
      "g": {
        "r": 0,
        "d": 0,
        "h": 631360454783,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1013612544127,
        "f": 83886088
      },
      "n": "InnerToken",
      "d": 262271,
      "h": 846108819583,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(846108819583),
//--TRIMMABLE-BOUNDARY-START(850403786879),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 639950389375,
        "f": 50331649
      },
      "n": "IsEncrypted",
      "d": 262271,
      "h": 850403786879,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(850403786879),
//--TRIMMABLE-BOUNDARY-START(854698754175),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 648540323967,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1022202478719,
        "f": 83886088
      },
      "n": "IsSigned",
      "d": 262271,
      "h": 854698754175,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(854698754175),
//--TRIMMABLE-BOUNDARY-START(880468557951),
    {
      "p": 131199,
      "g": {
        "r": 0,
        "d": 0,
        "h": 700079931519,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1047972282495,
        "f": 83886088
      },
      "n": "Payload",
      "d": 262271,
      "h": 880468557951,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(880468557951),
//--TRIMMABLE-BOUNDARY-START(901943394431),
    {
      "p": 13631614,
      "g": {
        "r": 0,
        "d": 0,
        "h": 717259800703,
        "f": 50364417
      },
      "n": "SecurityKey",
      "d": 262271,
      "h": 901943394431,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(901943394431),
//--TRIMMABLE-BOUNDARY-START(1078037053567),
    {
      "p": 13631614,
      "g": {
        "r": 0,
        "d": 0,
        "h": 725849735295,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1056562217087,
        "f": 83918849
      },
      "n": "SigningKey",
      "d": 262271,
      "h": 1078037053567,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(1078037053567),
//--TRIMMABLE-BOUNDARY-START(871878623359),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 682900062335,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1030792413311,
        "f": 83886088
      },
      "n": "MessageBytes",
      "d": 262271,
      "h": 871878623359,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(871878623359),
//--TRIMMABLE-BOUNDARY-START(876173590655),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 691489996927,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1039382347903,
        "f": 83886088
      },
      "n": "NumberOfDots",
      "d": 262271,
      "h": 876173590655,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(876173590655),
//--TRIMMABLE-BOUNDARY-START(300647972991),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 476741632127,
        "f": 50331777
      },
      "n": "Claims",
      "d": 262271,
      "h": 300647972991,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(300647972991),
//--TRIMMABLE-BOUNDARY-START(884763525247),
    {
      "p": $.$$.SCG.IReadOnlyCollection$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 708669866111,
        "f": 50331656
      },
      "n": "PayloadClaimNames",
      "d": 262271,
      "h": 884763525247,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(884763525247),
//--TRIMMABLE-BOUNDARY-START(266288234623),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416612089983,
        "f": 50331649
      },
      "n": "Alg",
      "d": 262271,
      "h": 266288234623,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266288234623),
//--TRIMMABLE-BOUNDARY-START(335007711359),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 485331566719,
        "f": 50331649
      },
      "n": "Cty",
      "d": 262271,
      "h": 335007711359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335007711359),
//--TRIMMABLE-BOUNDARY-START(356482547839),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 528281239679,
        "f": 50331649
      },
      "n": "Enc",
      "d": 262271,
      "h": 356482547839,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356482547839),
//--TRIMMABLE-BOUNDARY-START(867583656063),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 674310127743,
        "f": 50331649
      },
      "n": "Kid",
      "d": 262271,
      "h": 867583656063,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(867583656063),
//--TRIMMABLE-BOUNDARY-START(1112396791935),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 751619539071,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1073742086271,
        "f": 83886088
      },
      "n": "Typ",
      "d": 262271,
      "h": 1112396791935,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1112396791935),
//--TRIMMABLE-BOUNDARY-START(1138166595711),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 794569212031,
        "f": 50331649
      },
      "n": "X5t",
      "d": 262271,
      "h": 1138166595711,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1138166595711),
//--TRIMMABLE-BOUNDARY-START(1142461563007),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 803159146623,
        "f": 50331649
      },
      "n": "Zip",
      "d": 262271,
      "h": 1142461563007,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1142461563007),
//--TRIMMABLE-BOUNDARY-START(253403332735),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390842286207,
        "f": 50331649
      },
      "n": "Actor",
      "d": 262271,
      "h": 253403332735,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403332735),
//--TRIMMABLE-BOUNDARY-START(270583201919),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425202024575,
        "f": 50331649
      },
      "n": "Audiences",
      "d": 262271,
      "h": 270583201919,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583201919),
//--TRIMMABLE-BOUNDARY-START(287763071103),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450971828351,
        "f": 50331649
      },
      "n": "Azp",
      "d": 262271,
      "h": 287763071103,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763071103),
//--TRIMMABLE-BOUNDARY-START(858993721471),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 657130258559,
        "f": 50331649
      },
      "n": "IssuedAt",
      "d": 262271,
      "h": 858993721471,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(858993721471),
//--TRIMMABLE-BOUNDARY-START(863288688767),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 665720193151,
        "f": 50364417
      },
      "n": "Issuer",
      "d": 262271,
      "h": 863288688767,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(863288688767),
//--TRIMMABLE-BOUNDARY-START(833223917695),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 605590651007,
        "f": 50364417
      },
      "n": "Id",
      "d": 262271,
      "h": 833223917695,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(833223917695),
//--TRIMMABLE-BOUNDARY-START(1082332020863),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 734439669887,
        "f": 50331649
      },
      "n": "Subject",
      "d": 262271,
      "h": 1082332020863,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1082332020863),
//--TRIMMABLE-BOUNDARY-START(1120986726527),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 760209473663,
        "f": 50364417
      },
      "n": "ValidFrom",
      "d": 262271,
      "h": 1120986726527,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(1120986726527),
//--TRIMMABLE-BOUNDARY-START(1125281693823),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 768799408255,
        "f": 50331656
      },
      "n": "ValidFromNullable",
      "d": 262271,
      "h": 1125281693823,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(1125281693823),
//--TRIMMABLE-BOUNDARY-START(1129576661119),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 777389342847,
        "f": 50364417
      },
      "n": "ValidTo",
      "d": 262271,
      "h": 1129576661119,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(1129576661119),
//--TRIMMABLE-BOUNDARY-START(1133871628415),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 785979277439,
        "f": 50331656
      },
      "n": "ValidToNullable",
      "d": 262271,
      "h": 1133871628415,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(1133871628415)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(317827842175),
    {
      "r": 131199,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "CreateHeaderClaimSet",
      "o": "@$1",
      "d": 262271,
      "h": 317827842175,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(317827842175),
//--TRIMMABLE-BOUNDARY-START(313532874879),
    {
      "r": 131199,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CreateHeaderClaimSet",
      "d": 262271,
      "h": 313532874879,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(313532874879),
//--TRIMMABLE-BOUNDARY-START(322122809471),
    {
      "r": 131199,
      "p": [
        {
          "n": "byteSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "CreateHeaderClaimSet",
      "o": "@$2",
      "d": 262271,
      "h": 322122809471,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(322122809471),
//--TRIMMABLE-BOUNDARY-START(889058492543),
    {
      "r": 65537,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "ReadHeaderValue",
      "d": 262271,
      "h": 889058492543,
      "f": 16777344
    },
//--TRIMMABLE-BOUNDARY-END(889058492543),
//--TRIMMABLE-BOUNDARY-START(326417776767),
    {
      "r": 131199,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CreatePayloadClaimSet",
      "d": 262271,
      "h": 326417776767,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(326417776767),
//--TRIMMABLE-BOUNDARY-START(330712744063),
    {
      "r": 131199,
      "p": [
        {
          "n": "byteSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "CreatePayloadClaimSet",
      "o": "@$1",
      "d": 262271,
      "h": 330712744063,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(330712744063),
//--TRIMMABLE-BOUNDARY-START(893353459839),
    {
      "r": 65537,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "ReadPayloadValue",
      "d": 262271,
      "h": 893353459839,
      "f": 16777344
    },
//--TRIMMABLE-BOUNDARY-END(893353459839),
//--TRIMMABLE-BOUNDARY-START(897648427135),
    {
      "r": 65537,
      "p": [
        {
          "n": "encodedTokenMemory",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": "ReadToken",
      "d": 262271,
      "h": 897648427135,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(897648427135),
//--TRIMMABLE-BOUNDARY-START(309237907583),
    {
      "r": 131199,
      "p": [
        {
          "n": "strSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "createHeaderClaimSet",
          "p": 262145
        }
      ],
      "n": "CreateClaimSet",
      "d": 262271,
      "h": 309237907583,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(309237907583),
//--TRIMMABLE-BOUNDARY-START(1086626988159),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 262271,
      "h": 1086626988159,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(1086626988159),
//--TRIMMABLE-BOUNDARY-START(1116691759231),
    {
      "r": 1310721,
      "n": "UnsafeToString",
      "d": 262271,
      "h": 1116691759231,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(1116691759231),
//--TRIMMABLE-BOUNDARY-START(807454113919),
    {
      "r": 131141,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetClaim",
      "d": 262271,
      "h": 807454113919,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(807454113919),
//--TRIMMABLE-BOUNDARY-START(1090921955455),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131141,
          "f": 2
        }
      ],
      "n": "TryGetClaim",
      "d": 262271,
      "h": 1090921955455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1090921955455),
//--TRIMMABLE-BOUNDARY-START(820339015807),
    {
      "r": 262145,
      "p": [
        {
          "n": "claimName",
          "p": 1310721
        }
      ],
      "n": "HasPayloadClaim",
      "d": 262271,
      "h": 820339015807,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(820339015807),
//--TRIMMABLE-BOUNDARY-START(811749081215),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetHeaderValue",
      "d": 262271,
      "h": 811749081215,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(811749081215),
//--TRIMMABLE-BOUNDARY-START(816044048511),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetPayloadValue",
      "d": 262271,
      "h": 816044048511,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(816044048511),
//--TRIMMABLE-BOUNDARY-START(1103806857343),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetValue",
      "d": 262271,
      "h": 1103806857343,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(1103806857343),
//--TRIMMABLE-BOUNDARY-START(1095216922751),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetHeaderValue",
      "d": 262271,
      "h": 1095216922751,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(1095216922751),
//--TRIMMABLE-BOUNDARY-START(1099511890047),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetPayloadValue",
      "d": 262271,
      "h": 1099511890047,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(1099511890047)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(283468103807),
    {
      "t": 655361,
      "n": "AverageJsonClaimLengthInBytes",
      "d": 262271,
      "h": 283468103807,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283468103807),
//--TRIMMABLE-BOUNDARY-START(304942940287),
    {
      "t": 1310721,
      "n": "ClassName",
      "d": 262271,
      "h": 304942940287,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942940287),
//--TRIMMABLE-BOUNDARY-START(4295229567),
    {
      "t": 1310721,
      "n": "_act",
      "d": 262271,
      "h": 4295229567,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229567),
//--TRIMMABLE-BOUNDARY-START(17180131455),
    {
      "t": 1310721,
      "n": "_authenticationTag",
      "d": 262271,
      "h": 17180131455,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131455),
//--TRIMMABLE-BOUNDARY-START(25770066047),
    {
      "t": 1310721,
      "n": "_ciphertext",
      "d": 262271,
      "h": 25770066047,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770066047),
//--TRIMMABLE-BOUNDARY-START(38654967935),
    {
      "t": 1310721,
      "n": "_encodedHeader",
      "d": 262271,
      "h": 38654967935,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654967935),
//--TRIMMABLE-BOUNDARY-START(42949935231),
    {
      "t": 1310721,
      "n": "_encodedPayload",
      "d": 262271,
      "h": 42949935231,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949935231),
//--TRIMMABLE-BOUNDARY-START(47244902527),
    {
      "t": 1310721,
      "n": "_encodedSignature",
      "d": 262271,
      "h": 47244902527,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47244902527),
//--TRIMMABLE-BOUNDARY-START(51539869823),
    {
      "t": 1310721,
      "n": "_encodedToken",
      "d": 262271,
      "h": 51539869823,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51539869823),
//--TRIMMABLE-BOUNDARY-START(60129804415),
    {
      "t": 1310721,
      "n": "_encryptedKey",
      "d": 262271,
      "h": 60129804415,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60129804415),
//--TRIMMABLE-BOUNDARY-START(85899608191),
    {
      "t": 1310721,
      "n": "_initializationVector",
      "d": 262271,
      "h": 85899608191,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85899608191),
//--TRIMMABLE-BOUNDARY-START(12885164159),
    {
      "t": $.$$.SCG.List$$($.$$.S.String).$h,
      "n": "_audiences",
      "d": 262271,
      "h": 12885164159,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164159),
//--TRIMMABLE-BOUNDARY-START(55834837119),
    {
      "t": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "n": "_encodedTokenMemory",
      "d": 262271,
      "h": 55834837119,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834837119),
//--TRIMMABLE-BOUNDARY-START(8590196863),
    {
      "t": 1310721,
      "n": "_alg",
      "d": 262271,
      "h": 8590196863,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590196863),
//--TRIMMABLE-BOUNDARY-START(30065033343),
    {
      "t": 1310721,
      "n": "_cty",
      "d": 262271,
      "h": 30065033343,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065033343),
//--TRIMMABLE-BOUNDARY-START(34360000639),
    {
      "t": 1310721,
      "n": "_enc",
      "d": 262271,
      "h": 34360000639,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360000639),
//--TRIMMABLE-BOUNDARY-START(98784510079),
    {
      "t": 1310721,
      "n": "_kid",
      "d": 262271,
      "h": 98784510079,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(98784510079),
//--TRIMMABLE-BOUNDARY-START(115964379263),
    {
      "t": 1310721,
      "n": "_typ",
      "d": 262271,
      "h": 115964379263,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(115964379263),
//--TRIMMABLE-BOUNDARY-START(128849281151),
    {
      "t": 1310721,
      "n": "_x5t",
      "d": 262271,
      "h": 128849281151,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(128849281151),
//--TRIMMABLE-BOUNDARY-START(133144248447),
    {
      "t": 1310721,
      "n": "_zip",
      "d": 262271,
      "h": 133144248447,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(133144248447),
//--TRIMMABLE-BOUNDARY-START(21475098751),
    {
      "t": 1310721,
      "n": "_azp",
      "d": 262271,
      "h": 21475098751,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475098751),
//--TRIMMABLE-BOUNDARY-START(64424771711),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_exp",
      "d": 262271,
      "h": 64424771711,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(64424771711),
//--TRIMMABLE-BOUNDARY-START(68719739007),
    {
      "t": $.$typeNullable($.$$.S.DateTime).$h,
      "n": "_expDateTime",
      "d": 262271,
      "h": 68719739007,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(68719739007),
//--TRIMMABLE-BOUNDARY-START(73014706303),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_iat",
      "d": 262271,
      "h": 73014706303,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(73014706303),
//--TRIMMABLE-BOUNDARY-START(77309673599),
    {
      "t": $.$typeNullable($.$$.S.DateTime).$h,
      "n": "_iatDateTime",
      "d": 262271,
      "h": 77309673599,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(77309673599),
//--TRIMMABLE-BOUNDARY-START(81604640895),
    {
      "t": 1310721,
      "n": "_id",
      "d": 262271,
      "h": 81604640895,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(81604640895),
//--TRIMMABLE-BOUNDARY-START(90194575487),
    {
      "t": 1310721,
      "n": "_iss",
      "d": 262271,
      "h": 90194575487,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(90194575487),
//--TRIMMABLE-BOUNDARY-START(94489542783),
    {
      "t": 1310721,
      "n": "_jti",
      "d": 262271,
      "h": 94489542783,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(94489542783),
//--TRIMMABLE-BOUNDARY-START(111669411967),
    {
      "t": 1310721,
      "n": "_sub",
      "d": 262271,
      "h": 111669411967,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(111669411967),
//--TRIMMABLE-BOUNDARY-START(103079477375),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_nbf",
      "d": 262271,
      "h": 103079477375,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(103079477375),
//--TRIMMABLE-BOUNDARY-START(107374444671),
    {
      "t": $.$typeNullable($.$$.S.DateTime).$h,
      "n": "_nbfDateTime",
      "d": 262271,
      "h": 107374444671,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(107374444671),
//--TRIMMABLE-BOUNDARY-START(120259346559),
    {
      "t": $.$typeNullable($.$$.S.DateTime).$h,
      "n": "_validFrom",
      "d": 262271,
      "h": 120259346559,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(120259346559),
//--TRIMMABLE-BOUNDARY-START(124554313855),
    {
      "t": $.$typeNullable($.$$.S.DateTime).$h,
      "n": "_validTo",
      "d": 262271,
      "h": 124554313855,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(124554313855)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(244813398143),
    {
      "p": [
        {
          "n": "jwtEncodedString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 262271,
      "h": 244813398143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813398143),
//--TRIMMABLE-BOUNDARY-START(231928496255),
    {
      "p": [
        {
          "n": "jwtEncodedString",
          "p": 1310721
        },
        {
          "n": "tryReadJwtClaim",
          "p": 16973950
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 262271,
      "h": 231928496255,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231928496255),
//--TRIMMABLE-BOUNDARY-START(227633528959),
    {
      "p": [
        {
          "n": "encodedTokenMemory",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262271,
      "h": 227633528959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227633528959),
//--TRIMMABLE-BOUNDARY-START(223338561663),
    {
      "p": [
        {
          "n": "encodedTokenMemory",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        },
        {
          "n": "tryReadJwtClaim",
          "p": 16973950
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262271,
      "h": 223338561663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223338561663),
//--TRIMMABLE-BOUNDARY-START(240518430847),
    {
      "p": [
        {
          "n": "header",
          "p": 1310721
        },
        {
          "n": "payload",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 262271,
      "h": 240518430847,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240518430847),
//--TRIMMABLE-BOUNDARY-START(236223463551),
    {
      "p": [
        {
          "n": "header",
          "p": 1310721
        },
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "tryReadJwtClaim",
          "p": 16973950
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 262271,
      "h": 236223463551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236223463551),
//--TRIMMABLE-BOUNDARY-START(249108365439),
    {
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "encodedHeader",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 262271,
      "h": 249108365439,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(249108365439)
  ],
  "h": 262271
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.MIL.ISafeLogSecurityArtifact ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JsonWebToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JsonWebToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262271)
        
        

        //--TRIMMABLE-BOUNDARY-START(327807)
        $asm.$cls(`$mij.MIJ.JsonWebTokenHandler`, ($self) => class JsonWebTokenHandler extends $.$mit.MIT$1.TokenHandler
        {
            //--TRIMMABLE-BOUNDARY-START(356482613375)
            static /*ValidationResult<SecurityToken, ValidationError> */ ReadToken$1(/*string*/ token, /*CallContext?*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482613375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(token))
                {
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityToken, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("token", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ReadToken.cs", 30, 1)));
                }
                try
                {
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityToken, $.$mit.MITE.ValidationError).op_Implicit$1(new $.$mij.MIJ.JsonWebToken().$ctor$7(token));
                }
                catch(ex)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityToken, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.ValidationError().$ctor$1(new $.$mit.MITE.MessageDetail().$ctor$2("IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX14107*/), $.$mit.MITE.ValidationFailureType.TokenReadingFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ReadToken.cs", 44, 1), ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(356482613375)
            
            //--TRIMMABLE-BOUNDARY-START(60129869951)
            /*ClaimsIdentity */ CreateClaimsIdentity$1(/*JsonWebToken?*/ jwtToken, /*ValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken") });
                return this.CreateClaimsIdentityPrivate(jwtToken, validationParameters, $.$mij.MIJ.JsonWebTokenHandler.GetActualIssuer(jwtToken));
            }
            //--TRIMMABLE-BOUNDARY-END(60129869951)
            
            //--TRIMMABLE-BOUNDARY-START(55834902655)
            /*ClaimsIdentity */ CreateClaimsIdentity(/*JsonWebToken?*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834902655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken") });
                if ($.$$.S.String.IsNullOrWhiteSpace(issuer))
                {
                    issuer = $.$mij.MIJ.JsonWebTokenHandler.GetActualIssuer(jwtToken);
                }
                if (this.MapInboundClaims)
                {
                    return this.CreateClaimsIdentityWithMapping(jwtToken, validationParameters, issuer);
                }
                return this.CreateClaimsIdentityPrivate(jwtToken, validationParameters, issuer);
            }
            //--TRIMMABLE-BOUNDARY-END(55834902655)
            
            //--TRIMMABLE-BOUNDARY-START(73014771839)
            /*ClaimsIdentity */ CreateClaimsIdentityInternal(/*SecurityToken*/ securityToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateClaimsIdentity($.$as(securityToken, $.$mij.MIJ.JsonWebToken), validationParameters, issuer);
            }
            //--TRIMMABLE-BOUNDARY-END(73014771839)
            
            //--TRIMMABLE-BOUNDARY-START(90194641023)
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194641023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                let $en1 = jwtToken.Claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let jwtClaim = $en1.SCG$IEnumerator$$$Current;
                    {
                        /*string?*/ let type;
                        /*bool*/ let wasMapped = this._inboundClaimTypeMap.SCG$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => type, ($v) => type = $v, $.$$.S.String));
                        /*string*/ let claimType = type ?? jwtClaim.Type;
                        if (claimType === "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/)
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken?*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.MIJ.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$1(actor, validationParameters);
                            }
                        }
                        if (wasMapped)
                        {
                            /*Claim*/ let claim = new $.$ssc.SSC.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            if (jwtClaim.Properties.SCG$ICollection$$$Count > 0)
                            {
                                let $en3 = jwtClaim.Properties.SCG$IEnumerable$$$GetEnumerator();
                                while ($en3.SC$1$IEnumerator$MoveNext())
                                {
                                    let kv = $en3.SCG$IEnumerator$$$Current;
                                    {
                                        claim.Properties.SCG$IDictionary$$$$set_Item(kv.Key, kv.Value);
                                    }
                                }
                            }
                            claim.Properties.SCG$IDictionary$$$$set_Item($.$mij.MIJ.JsonWebTokenHandler.ShortClaimTypeProperty, jwtClaim.Type);
                            identity.AddClaim(claim);
                        }
                        else 
                        {
                            identity.AddClaim(jwtClaim);
                        }
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(90194641023)
            
            //--TRIMMABLE-BOUNDARY-START(81604706431)
            /*ClaimsIdentity */ CreateClaimsIdentityPrivate(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                let $en4 = jwtToken.Claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en4.SC$1$IEnumerator$MoveNext())
                {
                    let jwtClaim = $en4.SCG$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType = jwtClaim.Type;
                        if (claimType === "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/)
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken?*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.MIJ.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, validationParameters, issuer);
                            }
                        }
                        if (jwtClaim.Properties.SCG$ICollection$$$Count === 0)
                        {
                            identity.AddClaim(new $.$ssc.SSC.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity));
                        }
                        else 
                        {
                            /*Claim*/ let claim = new $.$ssc.SSC.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            let $en5 = jwtClaim.Properties.SCG$IEnumerable$$$GetEnumerator();
                            while ($en5.SC$1$IEnumerator$MoveNext())
                            {
                                let kv = $en5.SCG$IEnumerator$$$Current;
                                {
                                    claim.Properties.SCG$IDictionary$$$$set_Item(kv.Key, kv.Value);
                                }
                            }
                            identity.AddClaim(claim);
                        }
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(81604706431)
            
            //--TRIMMABLE-BOUNDARY-START(532576272511)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateTokenAsync$3(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)), $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(532576272511);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrEmpty(token))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("token", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 29, 1))));
                    }
                    if (validationParameters === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("validationParameters", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 36, 1))));
                    }
                    if (token.length > this.MaximumTokenSizeInBytes)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.ValidationError().$ctor$2(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.S.Int32)) ], null, null)), $.$mit.MITE.ValidationFailureType.SecurityTokenTooLarge, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 47, 1))));
                    }
                    /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.MIJ.JsonWebTokenHandler.ReadToken$1(token, callContext);
                    if (readResult.Succeeded)
                    {
                        let $t6, $r6;
                        /*ValidationResult<ValidatedToken, ValidationError>*/ let validationResult = ($t6 = this.ValidateTokenAsync(readResult.Result, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        if (validationResult.Succeeded)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, validationResult);
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(validationResult.Error.AddStackFrame($.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 67, 1))));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 70, 1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(532576272511)
            
            //--TRIMMABLE-BOUNDARY-START(519691370623)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateTokenAsync(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)), $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError), async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t8, $r8;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(519691370623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (token === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("token", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 84, 1))));
                    }
                    if (validationParameters === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("validationParameters", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 91, 1))));
                    }
                    let jsonWebToken;
                    if (!$.$is(token, $.$mij.MIJ.JsonWebToken, { set $v($v){ jsonWebToken = $v; } }))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.ValidationError().$ctor$2(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10001: Invalid argument '{0}'. Argument must be of type '{1}'."/*TokenLogMessages.IDX10001*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ "token", "JsonWebToken" ], null, null)), $.$mit.MITE.ValidationFailureType.SecurityTokenNotExpectedType, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 99, 1))));
                    }
                    /*BaseConfiguration?*/ let currentConfiguration = ($t7 = $.$mij.MIJ.JsonWebTokenHandler.GetCurrentConfigurationAsync(validationParameters, cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    /*ValidationResult<ValidatedToken, ValidationError>*/ let result = jsonWebToken.IsEncrypted ? ($t8 = this.ValidateJWEAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8))) : ($t9 = this.ValidateJWSAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    if (validationParameters.ConfigurationManager === null)
                    {
                        if (result.Succeeded)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, result);
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(result.Error.AddStackFrame($.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 118, 1))));
                    }
                    if (result.Succeeded)
                    {
                        if (!(currentConfiguration === null))
                        {
                            validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, result);
                    }
                    if ($.$mit.MIT$1.TokenUtilities.IsRecoverableFailureType(result.Error.FailureType, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.SCG$ICollection$$$Count > 0)))
                    {
                        if (!(currentConfiguration === null))
                        {
                            let $t10, $r10;
                            validationParameters.ConfigurationManager.RequestRefresh();
                            validationParameters.RefreshBeforeValidation = true;
                            /*BaseConfiguration*/ let lastConfig = currentConfiguration;
                            currentConfiguration = ($t10 = validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.ST$1.CancellationToken.None).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                            if (lastConfig !== currentConfiguration)
                            {
                                let $t11, $r11;
                                let $t12, $r12;
                                result = jsonWebToken.IsEncrypted ? ($t11 = this.ValidateJWEAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11))) : ($t12 = this.ValidateJWSAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                                if (result.Succeeded)
                                {
                                    validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                                }
                            }
                        }
                        if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                        {
                            validationParameters.RefreshBeforeValidation = false;
                            validationParameters.ValidateWithLKG = true;
                            /*ValidationFailureType*/ let failureType = result.Error.FailureType;
                            /*BaseConfiguration[]*/ let validConfigurations = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                            for(/*int*/ let i = 0; i < validConfigurations.length; i++)
                            {
                                /*BaseConfiguration*/ let lkgConfiguration = $.$$.System.Array.$ReadT1.call(validConfigurations, i);
                                if ($.$mit.MIT$1.TokenUtilities.IsRecoverableConfigurationAndExceptionType(jsonWebToken.Kid, currentConfiguration, lkgConfiguration, failureType))
                                {
                                    let $t13, $r13;
                                    let $t14, $r14;
                                    result = jsonWebToken.IsEncrypted ? ($t13 = this.ValidateJWEAsync(jsonWebToken, validationParameters, lkgConfiguration, callContext, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13))) : ($t14 = this.ValidateJWSAsync(jsonWebToken, validationParameters, lkgConfiguration, callContext, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                                    if (result.Succeeded)
                                    {
                                        return $.$$.N.AsyncResolver.Result($asnycContext, result);
                                    }
                                }
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(result.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 191, 1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(519691370623)
            
            //--TRIMMABLE-BOUNDARY-START(446676926591)
            /*ValueTask<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateJWEAsync(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)), $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError), async ($asnycContext) => 
                {
                    let $t15, $r15;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(446676926591);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ValidationResult<string, ValidationError>*/ let decryptionResult = this.DecryptToken(jwtToken, validationParameters, configuration, callContext);
                    if (!decryptionResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(decryptionResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 205, 1)));
                    }
                    /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.MIJ.JsonWebTokenHandler.ReadToken$1(decryptionResult.Result, callContext);
                    if (!readResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 211, 1)));
                    }
                    /*JsonWebToken*/ let decryptedToken = ($.$as(readResult.Result, $.$mij.MIJ.JsonWebToken));
                    /*ValidationResult<ValidatedToken, ValidationError>*/ let validationResult = ($t15 = this.ValidateJWSAsync(decryptedToken, validationParameters, configuration, callContext, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                    if (!validationResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(validationResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 221, 1)));
                    }
                    /*JsonWebToken*/ let jsonWebToken = ($.$as(validationResult.Result.SecurityToken, $.$mij.MIJ.JsonWebToken));
                    jwtToken.InnerToken = jsonWebToken;
                    jwtToken.Payload = jsonWebToken.Payload;
                    return $.$$.N.AsyncResolver.Result($asnycContext, validationResult);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(446676926591)
            
            //--TRIMMABLE-BOUNDARY-START(459561828479)
            /*ValueTask<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateJWSAsync(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)), $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError), async ($asnycContext) => 
                {
                    let $t17, $r17;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(459561828479);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*DateTime?*/ let expires = jsonWebToken.HasPayloadClaim("exp"/*JwtRegisteredClaimNames.Exp*/) ? jsonWebToken.ValidTo : null;
                    /*DateTime?*/ let notBefore = jsonWebToken.HasPayloadClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/) ? jsonWebToken.ValidFrom : null;
                    /*ValidationResult<ValidatedLifetime, ValidationError>*/ let lifetimeResult = $.$mit.MIT$1.Validators.ValidateLifetimeInternal($.$clone(notBefore), $.$clone(expires), jsonWebToken, validationParameters, callContext);
                    if (!lifetimeResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(lifetimeResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 253, 1)));
                    }
                    let tokenAudiences;
                    if (!$.$is(jsonWebToken.Audiences, $.$$.SCG.IList$$($.$$.S.String), { set $v($v){ tokenAudiences = $v; } }))
                    {
                        tokenAudiences = (() =>
                        {
                            let $t16 = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                            $t16.AddRange(jsonWebToken.Audiences);
                            return $t16;
                        })();
                    }
                    /*ValidationResult<string, ValidationError>*/ let audienceResult = $.$mit.MIT$1.Validators.ValidateAudienceInternal(tokenAudiences, jsonWebToken, validationParameters, callContext);
                    if (!audienceResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(audienceResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 274, 1)));
                    }
                    /*ValidationResult<ValidatedIssuer, ValidationError>*/ let issuerResult = ($t17 = $.$mit.MIT$1.Validators.ValidateIssuerInternalAsync(jsonWebToken.Issuer, jsonWebToken, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                    if (!issuerResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(issuerResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 289, 1)));
                    }
                    /*ValidationResult<DateTime?, ValidationError>?*/ let tokenReplayResult = $.$mit.MIT$1.Validators.ValidateTokenReplayInternal($.$clone(expires), jsonWebToken.EncodedToken, validationParameters, callContext);
                    if (!$.$$.S.Nullable$$($.$mit.MITE.ValidationResult$$$($.$$.S.Nullable$$($.$$.S.DateTime), $.$mit.MITE.ValidationError)).Value$get.call(tokenReplayResult).Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit($.$$.S.Nullable$$($.$mit.MITE.ValidationResult$$$($.$$.S.Nullable$$($.$$.S.DateTime), $.$mit.MITE.ValidationError)).Value$get.call(tokenReplayResult).Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 303, 1)));
                    }
                    /*ValidationResult<ValidatedTokenType, ValidationError>*/ let tokenTypeResult = $.$mit.MIT$1.Validators.ValidateTokenTypeInternal(jsonWebToken.Typ, jsonWebToken, validationParameters, callContext);
                    if (!tokenTypeResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(tokenTypeResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 317, 1)));
                    }
                    /*ValidationResult<string, ValidationError>*/ let algorithmResult = $.$mit.MIT$1.Validators.ValidateAlgorithmInternal(jsonWebToken.Alg, jsonWebToken, validationParameters, callContext);
                    if (!algorithmResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(algorithmResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 331, 1)));
                    }
                    /*ValidationResult<SecurityKey, ValidationError>*/ let signatureResult = this.ValidateSignature(jsonWebToken, validationParameters, configuration, callContext);
                    if (!signatureResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(signatureResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 346, 1)));
                    }
                    /*ValidationResult<ValidatedSignatureKey, ValidationError>*/ let signatureKeyResult = $.$mit.MIT$1.Validators.ValidateSignatureKeyInternal(jsonWebToken.SigningKey, jsonWebToken, validationParameters, callContext);
                    if (!signatureKeyResult.Succeeded)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(signatureKeyResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 360, 1)));
                    }
                    /*ValidationResult<ValidatedToken, ValidationError>?*/ let actorResult = null;
                    if (validationParameters.ValidateActor && !$.$$.S.String.IsNullOrWhiteSpace(jsonWebToken.Actor))
                    {
                        let $t18, $r18;
                        /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.MIJ.JsonWebTokenHandler.ReadToken$1(jsonWebToken.Actor, callContext);
                        if (!readResult.Succeeded)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 372, 1)));
                        }
                        if (validationParameters.ActorValidationParameters === null)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("ActorValidationParameters", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 381, 1))));
                        }
                        /*JsonWebToken*/ let actorToken = ($.$as(readResult.Result, $.$mij.MIJ.JsonWebToken));
                        actorResult = ($t18 = this.ValidateJWSAsync(actorToken, validationParameters.ActorValidationParameters, configuration, callContext, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                        if (!$.$$.S.Nullable$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)).Value$get.call(actorResult).Succeeded)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit($.$$.S.Nullable$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)).Value$get.call(actorResult).Error.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateToken.Internal.cs", 397, 1)));
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError).op_Implicit$1((() =>
                    {
                        //new $.$mit.MITE.ValidatedToken()
                        const $t19 = $.$mit.MITE.ValidatedToken;
                        const $i19 = new $t19();
                        $i19.$ctor$1(jsonWebToken, this, validationParameters);
                        $i19.ValidatedLifetime = lifetimeResult.Result;
                        $i19.ValidatedAlgorithm = algorithmResult.Result;
                        $i19.ValidatedAudience = audienceResult.Result;
                        $i19.ValidatedIssuer = issuerResult.Result;
                        $i19.ActorValidationResult = (actorResult?.Result ?? null);
                        $i19.ValidatedTokenType = tokenTypeResult.Result;
                        $i19.ValidatedSignatureKey = signatureResult.Result;
                        return $i19;
                    })()));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(459561828479)
            
            //--TRIMMABLE-BOUNDARY-START(296353071231)
            static /*Task<BaseConfiguration?> *//*async*/  GetCurrentConfigurationAsync(/*ValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MIT$1.BaseConfiguration), $.$mit.MIT$1.BaseConfiguration, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(296353071231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*BaseConfiguration?*/ let currentConfiguration = null;
                    if (!(validationParameters.ConfigurationManager === null))
                    {
                        try
                        {
                            let $t20, $r20;
                            currentConfiguration = ($t20 = validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                        }
                        catch($e)
                        {
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, currentConfiguration);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(296353071231)
            
            //--TRIMMABLE-BOUNDARY-START(339302744191)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  MITE$IResultBasedValidation$ValidateTokenAsync$3(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)), $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError), async ($asnycContext) => 
                {
                    let $t21, $r21;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(339302744191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t21 = this.ValidateTokenAsync$3(token, validationParameters, callContext, new $.$$.ST$1.CancellationToken()).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(339302744191)
            
            //--TRIMMABLE-BOUNDARY-START(335007776895)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  MITE$IResultBasedValidation$ValidateTokenAsync$2(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)), $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError), async ($asnycContext) => 
                {
                    let $t22, $r22;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(335007776895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t22 = this.ValidateTokenAsync$3(token, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(335007776895)
            
            //--TRIMMABLE-BOUNDARY-START(330712809599)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  MITE$IResultBasedValidation$ValidateTokenAsync$1(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)), $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError), async ($asnycContext) => 
                {
                    let $t23, $r23;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(330712809599);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t23 = this.ValidateTokenAsync(token, validationParameters, callContext, new $.$$.ST$1.CancellationToken()).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(330712809599)
            
            //--TRIMMABLE-BOUNDARY-START(326417842303)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  MITE$IResultBasedValidation$ValidateTokenAsync(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)), $.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError), async ($asnycContext) => 
                {
                    let $t24, $r24;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(326417842303);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t24 = this.ValidateTokenAsync(token, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(326417842303)
            
            //--TRIMMABLE-BOUNDARY-START(171799019647)
            /*ValidationResult<string, ValidationError> */ DecryptToken(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext?*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("jwtToken", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.DecryptToken.cs", 36, 1)));
                }
                if (validationParameters === null)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("validationParameters", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.DecryptToken.cs", 43, 1)));
                }
                if ($.$$.S.String.IsNullOrEmpty(jwtToken.Enc))
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.ValidationError().$ctor$2(new $.$mit.MITE.MessageDetail().$ctor$2("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/), $.$mit.MITE.ValidationFailureType.TokenDecryptionFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.DecryptToken.cs", 51, 1)));
                }
                /*(IList<SecurityKey>? ContentEncryptionKeys, ValidationError? ValidationError)*/ let result = this.GetContentEncryptionKeys(jwtToken, validationParameters, configuration, callContext);
                if (result.Item2 !== null)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit(result.Item2.AddCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.DecryptToken.cs", 60, 1));
                }
                if (result.Item1 === null || result.Item1.SCG$ICollection$$$Count === 0)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.ValidationError().$ctor$2(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.ValidationFailureType.TokenDecryptionFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.DecryptToken.cs", 71, 1)));
                }
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, result.Item1);
                return $.$mij.MIJ.JwtTokenUtilities.DecryptJwtToken(jwtToken, validationParameters, decryptionParameters, callContext);
            }
            //--TRIMMABLE-BOUNDARY-END(171799019647)
            
            //--TRIMMABLE-BOUNDARY-START(287763136639)
            /*(IList<SecurityKey>?, ValidationError?) */ GetContentEncryptionKeys(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext?*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763136639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IList<SecurityKey>?*/ let keys = null;
                if (validationParameters.DecryptionKeyResolver !== null)
                {
                    keys = validationParameters.DecryptionKeyResolver.MITE$IDecryptionKeyResolver$ResolveDecryptionKey(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, callContext);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey(jwtToken, validationParameters, callContext);
                    if (key === null && !(configuration === null))
                    {
                        key = $.$mij.MIJ.JsonWebTokenHandler.ResolveTokenDecryptionKeyFromConfig(jwtToken, configuration);
                    }
                    if (!(key === null))
                    {
                        keys = (() =>
                        {
                            let $t25 = new ($.$$.SCG.List$$($.$mit.MIT$1.SecurityKey))().$ctor$1();
                            $t25.Add(key);
                            return $t25;
                        })();
                    }
                }
                if (validationParameters.TryAllDecryptionKeys && $.$mit.MIT$1.CollectionUtilities.IsNullOrEmpty($.$mit.MIT$1.SecurityKey, keys))
                {
                    keys = validationParameters.DecryptionKeys;
                    if (configuration !== null)
                    {
                        let configurationKeys;
                        if (!$.$is(configuration.TokenDecryptionKeys, $.$$.SCG.List$$($.$mit.MIT$1.SecurityKey), { set $v($v){ configurationKeys = $v; } }))
                        {
                            configurationKeys = $.$sl.SL.Enumerable.ToList($.$mit.MIT$1.SecurityKey, configuration.TokenDecryptionKeys);
                        }
                        if (keys !== null)
                        {
                            let keysList;
                            if ($.$is(keys, $.$$.SCG.List$$($.$mit.MIT$1.SecurityKey), { set $v($v){ keysList = $v; } }))
                            {
                                keysList.AddRange(configurationKeys);
                            }
                            else 
                            {
                                keys = $.$sl.SL.Enumerable.ToList($.$mit.MIT$1.SecurityKey, $.$sl.SL.Enumerable.Concat($.$mit.MIT$1.SecurityKey, keys, configurationKeys));
                            }
                        }
                        else 
                        {
                            keys = configurationKeys;
                        }
                    }
                }
                if ($.$$.S.String.Equals$2.call(jwtToken.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/, 4/*StringComparison.Ordinal*/) || $.$$.S.String.Equals$2.call(jwtToken.Alg, "ECDH-ES"/*SecurityAlgorithms.EcdhEs*/, 4/*StringComparison.Ordinal*/))
                {
                    return new ($.$$.S.ValueTuple$$$($.$$.SCG.IList$$($.$mit.MIT$1.SecurityKey), $.$mit.MITE.ValidationError))().$ctor$3(keys, null);
                }
                if (keys === null)
                {
                    return new ($.$$.S.ValueTuple$$$($.$$.SCG.IList$$($.$mit.MIT$1.SecurityKey), $.$mit.MITE.ValidationError))().$ctor$3(keys, null);
                }
                /*var*/ let unwrappedKeys = new ($.$$.SCG.List$$($.$mit.MIT$1.SecurityKey))().$ctor$1();
                /*StringBuilder?*/ let exceptionStrings = null;
                /*StringBuilder?*/ let keysAttempted = null;
                for(/*int*/ let i = 0; i < keys.SCG$ICollection$$$Count; i++)
                {
                    /*var*/ let key = keys.SCG$IList$$$get_Item(i);
                    try
                    {
                        if ($.$mit.MIT$1.SupportedAlgorithms.EcdsaWrapAlgorithms.SCG$ICollection$$$Contains(jwtToken.Alg))
                        {
                            /*string*/ let epk;
                            jwtToken.TryGetHeaderValue($.$$.S.String, "epk"/*JwtHeaderParameterNames.Epk*/, $.$ref(() => epk, ($v) => epk = $v, $.$$.S.String));
                            /*ECDsaSecurityKey?*/ let publicKey = new $.$mit.MIT$1.ECDsaSecurityKey().$ctor$5(new $.$mit.MIT$1.JsonWebKey().$ctor$4(epk), false);
                            if (!(publicKey === null))
                            {
                                /*string*/ let apu;
                                /*string*/ let apv;
                                /*var*/ let ecdhKeyExchangeProvider = new $.$mit.MIT$1.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.MIT$1.ECDsaSecurityKey), publicKey, jwtToken.Alg, jwtToken.Enc);
                                jwtToken.TryGetHeaderValue($.$$.S.String, "apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => apu, ($v) => apu = $v, $.$$.S.String));
                                jwtToken.TryGetHeaderValue($.$$.S.String, "apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => apv, ($v) => apv = $v, $.$$.S.String));
                                /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jwtToken.EncryptedKey));
                                unwrappedKeys.Add(new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4(unwrappedKey));
                            }
                        }
                        else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Alg, key))
                        {
                            /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Alg);
                            /*var*/ let unwrappedKey = kwp.UnwrapKey(jwtToken.EncryptedKeyBytes);
                            unwrappedKeys.Add(new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4(unwrappedKey));
                        }
                    }
                    catch(ex)
                    {
                        (exceptionStrings ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(ex.ToString());
                    }
                    (keysAttempted ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(key.KeyId);
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings === null)
                {
                    return new ($.$$.S.ValueTuple$$$($.$$.SCG.IList$$($.$mit.MIT$1.SecurityKey), $.$mit.MITE.ValidationError))().$ctor$3(unwrappedKeys, null);
                }
                else 
                {
                    /*ValidationError*/ let validationError = new $.$mit.MITE.ValidationError().$ctor$2(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII((keysAttempted?.ToString() ?? null) ?? ""), (exceptionStrings?.ToString() ?? null) ?? "", $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.ValidationFailureType.KeyWrapFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.DecryptToken.cs", 241, 1));
                    return new ($.$$.S.ValueTuple$$$($.$$.SCG.IList$$($.$mit.MIT$1.SecurityKey), $.$mit.MITE.ValidationError))().$ctor$3(null, validationError);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287763136639)
            
            //--TRIMMABLE-BOUNDARY-START(377957449855)
            /*SecurityKey? */ ResolveTokenDecryptionKey(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*CallContext?*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957449855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null || validationParameters === null)
                {
                    return null;
                }
                if (!$.$$.S.String.IsNullOrEmpty(jwtToken.Kid) && validationParameters.DecryptionKeys !== null)
                {
                    for(/*int*/ let i = 0; i < validationParameters.DecryptionKeys.SCG$ICollection$$$Count; i++)
                    {
                        /*var*/ let key = validationParameters.DecryptionKeys.SCG$IList$$$get_Item(i);
                        if (key !== null && $.$$.S.String.Equals$3(key.KeyId, jwtToken.Kid, $.$mij.MIJ.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                        {
                            return key;
                        }
                    }
                }
                if (!$.$$.S.String.IsNullOrEmpty(jwtToken.X5t) && validationParameters.DecryptionKeys !== null)
                {
                    for(/*int*/ let i = 0; i < validationParameters.DecryptionKeys.SCG$ICollection$$$Count; i++)
                    {
                        /*SecurityKey?*/ let key = validationParameters.DecryptionKeys.SCG$IList$$$get_Item(i);
                        if (key !== null && $.$$.S.String.Equals$3(key.KeyId, jwtToken.X5t, $.$mij.MIJ.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                        {
                            return key;
                        }
                        let x509Key;
                        if ($.$is(key, $.$mit.MIT$1.X509SecurityKey, { set $v($v){ x509Key = $v; } }) && $.$$.S.String.Equals$3(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return key;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(377957449855)
            
            //--TRIMMABLE-BOUNDARY-START(472446730367)
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignature(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472446730367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("jwtToken", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 38, 1)));
                }
                if (validationParameters === null)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit($.$mit.MITE.ValidationError.NullParameter("validationParameters", $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 47, 1)));
                }
                if (!(validationParameters.SignatureValidator === null))
                {
                    try
                    {
                        /*ValidationResult<SecurityKey, ValidationError>*/ let signatureValidationResult = validationParameters.SignatureValidator.MITE$ISignatureValidator$ValidateSignature(jwtToken, validationParameters, configuration, callContext);
                        return signatureValidationResult;
                    }
                    catch(ex)
                    {
                        return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$3(new $.$mit.MITE.MessageDetail().$ctor$2("IDX10272: SignatureValidationDelegate threw an exception, see inner exception."/*TokenLogMessages.IDX10272*/), $.$mit.MITE.SignatureValidationFailure.ValidatorThrew, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 72, 1), ex));
                    }
                }
                if (!jwtToken.IsSigned)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.SignatureValidationFailure.TokenIsNotSigned, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 88, 1)));
                }
                /*SecurityKey?*/ let key = null;
                if (!(validationParameters.SignatureKeyResolver === null))
                {
                    key = validationParameters.SignatureKeyResolver.MITE$ISignatureKeyResolver$ResolveSignatureKey(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, configuration, callContext);
                }
                else 
                {
                    key = $.$mij.MIJ.JwtTokenUtilities.ResolveTokenSigningKey$1(jwtToken.Kid, jwtToken.X5t, (configuration?.SigningKeys ?? null)) ?? $.$mij.MIJ.JwtTokenUtilities.ResolveTokenSigningKey$1(jwtToken.Kid, jwtToken.X5t, validationParameters.SigningKeys);
                }
                if (!(key === null))
                {
                    return this.ValidateSignatureWithKey(jwtToken, validationParameters, key, callContext);
                }
                if (validationParameters.TryAllSigningKeys)
                {
                    return this.ValidateSignatureUsingAllKeys(jwtToken, validationParameters, configuration, callContext);
                }
                $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, null);
                if ($.$$.S.String.IsNullOrEmpty(jwtToken.Kid))
                {
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10526: Signature validation failed. The token's kid is missing.\nValidationParameters.TryAllIssuerSigningKeys is set to false. All keys will not be tried. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10526*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.SCG$ICollection$$$Count, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box((configuration?.SigningKeys?.SCG$ICollection$$$Count ?? null) ?? 0, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.SignatureValidationFailure.SigningKeyNotFound, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 141, 1)));
                }
                return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10527: Signature validation failed. The token's kid is: '{0}', but did not match any keys in ValidationParameters or Configuration and TryAllIssuerSigningKeys is false.\nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10527*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.SCG$ICollection$$$Count, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box((configuration?.SigningKeys?.SCG$ICollection$$$Count ?? null) ?? 0, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.SignatureValidationFailure.SigningKeyNotFound, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 153, 1)));
            }
            //--TRIMMABLE-BOUNDARY-END(472446730367)
            
            //--TRIMMABLE-BOUNDARY-START(498216534143)
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignatureUsingAllKeys(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216534143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let keysTried = false;
                /*bool*/ let kidExists = !$.$$.S.String.IsNullOrEmpty(jwtToken.Kid);
                /*IEnumerable<SecurityKey>?*/ let keys = $.$mit.MIT$1.TokenUtilities.GetAllSigningKeys(configuration, validationParameters, callContext);
                /*StringBuilder?*/ let exceptionStrings = null;
                /*StringBuilder?*/ let keysAttempted = null;
                let $en29 = keys.SCG$IEnumerable$$$GetEnumerator();
                while ($en29.SC$1$IEnumerator$MoveNext())
                {
                    let key = $en29.SCG$IEnumerator$$$Current;
                    {
                        if (key === null)
                        {
                            continue;
                        }
                        keysTried = true;
                        /*ValidationResult<SecurityKey, ValidationError>*/ let result = this.ValidateSignatureWithKey(jwtToken, validationParameters, key, callContext);
                        if (result.Succeeded)
                        {
                            return result;
                        }
                        let validationError;
                        if ($.$is(result.Error, $.$mit.MITE.ValidationError, { set $v($v){ validationError = $v; } }))
                        {
                            exceptionStrings ??= new $.$$.ST.StringBuilder().$ctor$1();
                            keysAttempted ??= new $.$$.ST.StringBuilder().$ctor$1();
                            exceptionStrings.AppendLine$3(validationError.MessageDetail.Message);
                            keysAttempted.AppendLine$3(key.ToString());
                        }
                    }
                }
                if (keysTried)
                {
                    if (kidExists)
                    {
                        return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10522: Signature validation failed. The token's kid: '{0}' did not match any keys in ValidationParameters or Configuration.\nAll keys in ValidationParameters and Configuration were tried. \nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10522*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.SCG$ICollection$$$Count, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box((configuration?.SigningKeys?.SCG$ICollection$$$Count ?? null) ?? 0, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.SignatureValidationFailure.SigningKeyNotFound, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 215, 1)));
                    }
                    else 
                    {
                        return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10523: Signature validation failed. The token's kid is empty.\nAll keys in ValidationParameters and Configuration were tried. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10523*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.SCG$ICollection$$$Count, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box((configuration?.SigningKeys?.SCG$ICollection$$$Count ?? null) ?? 0, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.SignatureValidationFailure.SigningKeyNotFound, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 226, 1)));
                    }
                }
                if (kidExists)
                {
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10524: Signature validation failed. The token's kid: '{0}' did not match any keys in ValidationParameters or Configuration.\nAll keys in ValidationParameters and Configuration were tried. No non-null keys were found. \nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10524*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.SCG$ICollection$$$Count, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box((configuration?.SigningKeys?.SCG$ICollection$$$Count ?? null) ?? 0, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.SignatureValidationFailure.SigningKeyNotFound, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 243, 1)));
                }
                return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10525: Signature validation failed. The token's kid is missing.\nAll keys in ValidationParameters and Configuration were tried. No non-null keys were found. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10525*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.SCG$ICollection$$$Count, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box((configuration?.SigningKeys?.SCG$ICollection$$$Count ?? null) ?? 0, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.MITE.SignatureValidationFailure.SigningKeyNotFound, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 253, 1)));
            }
            //--TRIMMABLE-BOUNDARY-END(498216534143)
            
            //--TRIMMABLE-BOUNDARY-START(506806468735)
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignatureWithKey(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*SecurityKey*/ key, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506806468735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CryptoProviderFactory*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Alg, key))
                {
                    $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10652: The algorithm '{0}' is not supported."/*TokenLogMessages.IDX10652*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(jsonWebToken.Alg), key ], null, null)), $.$mit.MITE.AlgorithmValidationFailure.AlgorithmIsNotSupported, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 279, 1)));
                }
                /*SignatureProvider*/ let signatureProvider;
                try
                {
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, jsonWebToken.Alg);
                }
                catch(ex)
                {
                    $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$3(new $.$mit.MITE.MessageDetail().$ctor$1("IDX11028: CryptoProviderFactory.CreateForVerifying threw an exception for key: '{0}', signatureAlgorithm: '{1}'. The platform may not support the algorithm or extracting the key material for it (for example, ML-DSA on a platform without post-quantum support). See the inner exception for details."/*TokenLogMessages.IDX11028*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.MIL.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null)), $.$mit.MITE.SignatureValidationFailure.SignatureProviderCreationFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 303, 1), ex));
                }
                try
                {
                    if (signatureProvider === null)
                    {
                        $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                        return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.MIL.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null)), $.$mit.MITE.ValidationFailureType.CryptoProviderReturnedNull, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 323, 1)));
                    }
                    /*bool*/ let valid = $.$mit.MIT$1.EncodingUtils.PerformEncodingDependentOperation($.$$.S.Boolean, $.$$.S.String, $.$$.S.Int32, $.$mit.MIT$1.SignatureProvider, jsonWebToken.EncodedToken, 0, jsonWebToken.Dot2, $.$$.ST.Encoding.UTF8, jsonWebToken.EncodedToken, jsonWebToken.Dot2, signatureProvider, new ($.$$.S.Func$$$$$$$($.$typeArray($.$$.S.Byte), $.$$.S.Int32, $.$$.S.String, $.$$.S.Int32, $.$mit.MIT$1.SignatureProvider, $.$$.S.Boolean))().$ctor($.$mij.MIJ.JsonWebTokenHandler, $.$mij.MIJ.JsonWebTokenHandler.ValidateSignature$4));
                    if (valid)
                    {
                        $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "None"/*TelemetryConstants.SignatureValidationErrors.None*/, jsonWebToken, key);
                        jsonWebToken.SigningKey = key;
                        return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit$1(key);
                    }
                    else 
                    {
                        $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                        return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$4(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10520: Signature validation failed. The key provided could not validate the signature. Key tried: '{0}'."/*TokenLogMessages.IDX10520*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key.ToString()) ], null, null)), $.$mit.MITE.SignatureValidationFailure.ValidationFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 360, 1)));
                    }
                }
                catch(ex)
                {
                    $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    return $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).op_Implicit(new $.$mit.MITE.SignatureValidationError().$ctor$3(new $.$mit.MITE.MessageDetail().$ctor$1("IDX10521: Signature validation failed.An exception was thrown when trying to validate the signature. Key tried: '{0}'. Exception: '{1}'."/*TokenLogMessages.IDX10521*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key.ToString()), $.$mil.MIL.LogHelper.MarkAsNonPII(ex.Message) ], null, null)), $.$mit.MITE.SignatureValidationFailure.ValidationFailed, $.$mit.MITE.ValidationError.GetCurrentStackFrame("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.Microsoft.IdentityModel.JsonWebTokens\\JsonWebTokenHandler.ValidateSignature.cs", 379, 1), ex));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(506806468735)
            
            //--TRIMMABLE-BOUNDARY-START(343597711487)
            static /*void */ PopulateFailedResults(/*KeyMatchFailedResult?*/ failedResult, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597711487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let result;
                if ($.$is(failedResult, $.$mij.MIJ.JsonWebTokenHandler.KeyMatchFailedResult, { set $v($v){ result = $v; } }))
                {
                    for(/*int*/ let i = 0; i < result.KeysAttempted.SCG$ICollection$$$Count; i++)
                    {
                        exceptionStrings.AppendLine$3(result.FailedResults.SCG$IList$$$get_Item(i).MessageDetail.Message);
                        keysAttempted.AppendLine$3(result.KeysAttempted.SCG$IList$$$get_Item(i).ToString());
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343597711487)
            
            //--TRIMMABLE-BOUNDARY-START(393343)
            static $_KeyMatchFailedResult;
            static get KeyMatchFailedResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mij.MIJ.JsonWebTokenHandler;
                return $cls.$_KeyMatchFailedResult ??= $asm.$nstr(`$mij.MIJ.JsonWebTokenHandler.KeyMatchFailedResult`, ($self) => class KeyMatchFailedResult extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295231)
                    /*IList<ValidationError>*/ FailedResults = null;
                    //--TRIMMABLE-BOUNDARY-END(12885295231)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180262527)
                    /*IList<SecurityKey>*/ KeysAttempted = null;
                    //--TRIMMABLE-BOUNDARY-END(17180262527)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360639)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295360639);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360639)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360639)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360639)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FailedResults = this.FailedResults;
                        copy.KeysAttempted = this.KeysAttempted;
                        return copy;
                    }
                    //Begin primary constructor
                    /*IList<ValidationError>*/ failedResults = null;
                    /*IList<SecurityKey>*/ keysAttempted = null;
                    $ctor$3(/*IList<ValidationError>*/failedResults, /*IList<SecurityKey>*/keysAttempted)
                    {
                        this.failedResults = failedResults;
                        this.keysAttempted = keysAttempted;
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(12885295231)
                        //depends on primary constructor parameter
                        this.FailedResults = this.failedResults;
                        //--TRIMMABLE-BOUNDARY-END(12885295231)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180262527)
                        //depends on primary constructor parameter
                        this.KeysAttempted = this.keysAttempted;
                        //--TRIMMABLE-BOUNDARY-END(17180262527)
                        
                        return this
                    }
                    //End primary constructor
                    static $h = 393343;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295231),
    {
      "t": $.$$.SCG.IList$$($.$mit.MITE.ValidationError).$h,
      "n": "FailedResults",
      "d": 393343,
      "h": 12885295231,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885295231),
//--TRIMMABLE-BOUNDARY-START(17180262527),
    {
      "t": $.$$.SCG.IList$$($.$mit.MIT$1.SecurityKey).$h,
      "n": "KeysAttempted",
      "d": 393343,
      "h": 17180262527,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180262527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327935),
    {
      "p": [
        {
          "n": "failedResults",
          "p": $.$$.SCG.IList$$($.$mit.MITE.ValidationError).$h
        },
        {
          "n": "keysAttempted",
          "p": $.$$.SCG.IList$$($.$mit.MIT$1.SecurityKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393343,
      "h": 8590327935,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327935),
//--TRIMMABLE-BOUNDARY-START(4295360639),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393343,
      "h": 4295360639,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360639)
  ],
  "d": 327807,
  "h": 393343
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler+KeyMatchFailedResult`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JsonWebTokenHandler${separator}KeyMatchFailedResult`; }
                }, $cls, ($v) => $cls.$_KeyMatchFailedResult = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393343)
            
            //--TRIMMABLE-BOUNDARY-START(4295295103)
            /*IDictionary<string, string>*/ _inboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(4295295103)
            
            //--TRIMMABLE-BOUNDARY-START(12885229695)
            /*string*/ static _namespace = null;
            //--TRIMMABLE-BOUNDARY-END(12885229695)
            
            //--TRIMMABLE-BOUNDARY-START(17180196991)
            /*string*/ static _shortClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(17180196991)
            
            //--TRIMMABLE-BOUNDARY-START(8590262399)
            /*bool*/ _mapInboundClaims = false;
            //--TRIMMABLE-BOUNDARY-END(8590262399)
            
            //--TRIMMABLE-BOUNDARY-START(188978888831)
            /*IDictionary<string, string>*/ static DefaultInboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(188978888831)
            
            //--TRIMMABLE-BOUNDARY-START(193273856127)
            /*bool*/ static DefaultMapInboundClaims = false;
            //--TRIMMABLE-BOUNDARY-END(193273856127)
            
            //--TRIMMABLE-BOUNDARY-START(38655033471)
            /*string*/ static Base64UrlEncodedUnsignedJWSHeader = null;
            //--TRIMMABLE-BOUNDARY-END(38655033471)
            
            //--TRIMMABLE-BOUNDARY-START(25770131583)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131583);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._mapInboundClaims)
                    {
                        this._inboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$mij.MIJ.JsonWebTokenHandler.DefaultInboundClaimTypeMap);
                    }
                    else 
                    {
                        this._inboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$1();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131583)
            
            //--TRIMMABLE-BOUNDARY-START(442381959295)
            /*Type */ get TokenType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878234751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.JsonWebToken.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(442381959295)
            
            //--TRIMMABLE-BOUNDARY-START(433792024703)
            static /*string */ get ShortClaimTypeProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288300159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.JsonWebTokenHandler._shortClaimType;
            }
            static /*string */ set ShortClaimTypeProperty(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497057407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("value");
                }
                $.$mij.MIJ.JsonWebTokenHandler._shortClaimType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(433792024703)
            
            //--TRIMMABLE-BOUNDARY-START(317827907711)
            /*bool */ get MapInboundClaims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108430975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mapInboundClaims;
            }
            /*bool */ set MapInboundClaims(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317188223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._mapInboundClaims && value && this._inboundClaimTypeMap.SCG$ICollection$$$Count === 0)
                {
                    this._inboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$mij.MIJ.JsonWebTokenHandler.DefaultInboundClaimTypeMap);
                }
                this._mapInboundClaims = value;
            }
            //--TRIMMABLE-BOUNDARY-END(317827907711)
            
            //--TRIMMABLE-BOUNDARY-START(309237973119)
            /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518496383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set InboundClaimTypeMap(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727253631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inboundClaimTypeMap = $.$firstOf(value, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("value") });
            }
            //--TRIMMABLE-BOUNDARY-END(309237973119)
            
            //--TRIMMABLE-BOUNDARY-START(42950000767)
            /*bool */ CanReadToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(token))
                {
                    return false;
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.MIL.LogHelper.LogInformation("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.S.Int32)) ], null, null));
                    }
                    return false;
                }
                /*int*/ let pos = 0;
                /*int*/ let segmentCount = 1;
                while(segmentCount <= 5/*JwtConstants.MaxJwtSegmentCount*/ && ((pos = $.$$.S.String.IndexOf$1.call(token, /*.*/ 46, pos)) >= 0))
                {
                    pos++;
                    segmentCount++;
                }
                switch(segmentCount)
                {
                    case 3/*JwtConstants.JwsSegmentCount*/:
                    return $.$mij.MIJ.JwtTokenUtilities.RegexJws.IsMatch$9(token);
                    case 5/*JwtConstants.JweSegmentCount*/:
                    return $.$mij.MIJ.JwtTokenUtilities.RegexJwe.IsMatch$9(token);
                    default:
                    $.$mil.MIL.LogHelper.LogInformation("IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX14107*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950000767)
            
            //--TRIMMABLE-BOUNDARY-START(300648038527)
            static /*StringComparison */ GetStringComparisonRuleIf509(/*SecurityKey*/ securityKey)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300648038527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(securityKey, $.$mit.MIT$1.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300648038527)
            
            //--TRIMMABLE-BOUNDARY-START(304943005823)
            static /*StringComparison */ GetStringComparisonRuleIf509OrECDsa(/*SecurityKey*/ securityKey)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(304943005823);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$is(securityKey, $.$mit.MIT$1.X509SecurityKey) || $.$is(securityKey, $.$mit.MIT$1.ECDsaSecurityKey)) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(304943005823)
            
            //--TRIMMABLE-BOUNDARY-START(68719804543)
            /*ClaimsIdentity */ CreateClaimsIdentity$3(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719804543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken") });
                return this.CreateClaimsIdentityPrivate$1(jwtToken, validationParameters, $.$mij.MIJ.JsonWebTokenHandler.GetActualIssuer(jwtToken));
            }
            //--TRIMMABLE-BOUNDARY-END(68719804543)
            
            //--TRIMMABLE-BOUNDARY-START(64424837247)
            /*ClaimsIdentity */ CreateClaimsIdentity$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken") });
                if ($.$$.S.String.IsNullOrWhiteSpace(issuer))
                {
                    issuer = $.$mij.MIJ.JsonWebTokenHandler.GetActualIssuer(jwtToken);
                }
                if (this.MapInboundClaims)
                {
                    return this.CreateClaimsIdentityWithMapping$1(jwtToken, validationParameters, issuer);
                }
                return this.CreateClaimsIdentityPrivate$1(jwtToken, validationParameters, issuer);
            }
            //--TRIMMABLE-BOUNDARY-END(64424837247)
            
            //--TRIMMABLE-BOUNDARY-START(94489608319)
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                let $en31 = jwtToken.Claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en31.SC$1$IEnumerator$MoveNext())
                {
                    let jwtClaim = $en31.SCG$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType;
                        /*bool*/ let wasMapped = this._inboundClaimTypeMap.SCG$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => claimType, ($v) => claimType = $v, $.$$.S.String));
                        if (!wasMapped)
                        {
                            claimType = jwtClaim.Type;
                        }
                        if (claimType === "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/)
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.MIJ.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$3(actor, validationParameters);
                            }
                        }
                        if (wasMapped)
                        {
                            /*Claim*/ let claim = new $.$ssc.SSC.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            if (jwtClaim.Properties.SCG$ICollection$$$Count > 0)
                            {
                                let $en33 = jwtClaim.Properties.SCG$IEnumerable$$$GetEnumerator();
                                while ($en33.SC$1$IEnumerator$MoveNext())
                                {
                                    let kv = $en33.SCG$IEnumerator$$$Current;
                                    {
                                        claim.Properties.SCG$IDictionary$$$$set_Item(kv.Key, kv.Value);
                                    }
                                }
                            }
                            claim.Properties.SCG$IDictionary$$$$set_Item($.$mij.MIJ.JsonWebTokenHandler.ShortClaimTypeProperty, jwtClaim.Type);
                            identity.AddClaim(claim);
                        }
                        else 
                        {
                            identity.AddClaim(jwtClaim);
                        }
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(94489608319)
            
            //--TRIMMABLE-BOUNDARY-START(77309739135)
            /*ClaimsIdentity */ CreateClaimsIdentityInternal$1(/*SecurityToken*/ securityToken, /*TokenValidationParameters*/ tokenValidationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateClaimsIdentity$2($.$as(securityToken, $.$mij.MIJ.JsonWebToken), tokenValidationParameters, issuer);
            }
            //--TRIMMABLE-BOUNDARY-END(77309739135)
            
            //--TRIMMABLE-BOUNDARY-START(283468169343)
            static /*string */ GetActualIssuer(/*JsonWebToken*/ jwtToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468169343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let actualIssuer = jwtToken.Issuer;
                if ($.$$.S.String.IsNullOrWhiteSpace(actualIssuer))
                {
                    if ($.$mil.MIL.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.MIL.LogHelper.LogVerbose("IDX10244: Issuer is null or empty. Using runtime default for creating claims '{0}'."/*TokenLogMessages.IDX10244*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/ ], null, null));
                    }
                    actualIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                }
                return actualIssuer;
            }
            //--TRIMMABLE-BOUNDARY-END(283468169343)
            
            //--TRIMMABLE-BOUNDARY-START(85899673727)
            /*ClaimsIdentity */ CreateClaimsIdentityPrivate$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                let $en34 = jwtToken.Claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en34.SC$1$IEnumerator$MoveNext())
                {
                    let jwtClaim = $en34.SCG$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType = jwtClaim.Type;
                        if (claimType === "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/)
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.MIJ.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$2(actor, validationParameters, issuer);
                            }
                        }
                        if (jwtClaim.Properties.SCG$ICollection$$$Count === 0)
                        {
                            identity.AddClaim(new $.$ssc.SSC.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity));
                        }
                        else 
                        {
                            /*Claim*/ let claim = new $.$ssc.SSC.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            let $en35 = jwtClaim.Properties.SCG$IEnumerable$$$GetEnumerator();
                            while ($en35.SC$1$IEnumerator$MoveNext())
                            {
                                let kv = $en35.SCG$IEnumerator$$$Current;
                                {
                                    claim.Properties.SCG$IDictionary$$$$set_Item(kv.Key, kv.Value);
                                }
                            }
                            identity.AddClaim(claim);
                        }
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(85899673727)
            
            //--TRIMMABLE-BOUNDARY-START(184683921535)
            /*Task<string> *//*async*/  DecryptTokenWithConfigurationAsync(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.String), $.$$.S.String, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184683921535);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (jwtToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                    }
                    if (validationParameters === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                    }
                    if ($.$$.S.String.IsNullOrEmpty(jwtToken.Enc))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null))));
                    }
                    /*BaseConfiguration*/ let currentConfiguration = null;
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        try
                        {
                            let $t36, $r36;
                            currentConfiguration = ($t36 = validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t36, { set $v($v) { $r36 = $v; } }) ? $r36 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t36)));
                        }
                        catch(ex)
                        {
                            if ($.$mil.MIL.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.MIL.LogHelper.LogWarning($.$mil.MIL.LogHelper.FormatInvariant("IDX10278: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token decryption in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10278*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ validationParameters.ConfigurationManager.MetadataAddress, ex.ToString() ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, this.DecryptToken$1(jwtToken, validationParameters, currentConfiguration));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(184683921535)
            
            //--TRIMMABLE-BOUNDARY-START(180388954239)
            /*string */ DecryptToken$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388954239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DecryptToken$1(jwtToken, validationParameters, null);
            }
            //--TRIMMABLE-BOUNDARY-END(180388954239)
            
            //--TRIMMABLE-BOUNDARY-START(176093986943)
            /*string */ DecryptToken$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093986943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                if ($.$$.S.String.IsNullOrEmpty(jwtToken.Enc))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null))));
                }
                /*var*/ let keys = this.GetContentEncryptionKeys$1(jwtToken, validationParameters, configuration);
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, keys);
                return $.$mij.MIJ.JwtTokenUtilities.DecryptJwtToken$1(jwtToken, validationParameters, decryptionParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(176093986943)
            
            //--TRIMMABLE-BOUNDARY-START(98784575615)
            /*JwtTokenDecryptionParameters */ CreateJwtTokenDecryptionParameters(/*JsonWebToken*/ jwtToken, /*IEnumerable<SecurityKey>*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$mij.MIJ.JwtTokenDecryptionParameters()
                    const $t37 = $.$mij.MIJ.JwtTokenDecryptionParameters;
                    const $i37 = new $t37();
                    $i37.$ctor$1();
                    $i37.Alg = jwtToken.Alg;
                    $i37.AuthenticationTagBytes = jwtToken.AuthenticationTagBytes;
                    $i37.CipherTextBytes = jwtToken.CipherTextBytes;
                    $i37.DecompressionFunction = new ($.$$.S.Func$$$$$($.$typeArray($.$$.S.Byte), $.$$.S.String, $.$$.S.Int32, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.DecompressToken);
                    $i37.Enc = jwtToken.Enc;
                    $i37.EncodedToken = jwtToken.EncodedToken;
                    $i37.HeaderAsciiBytes = jwtToken.HeaderAsciiBytes;
                    $i37.InitializationVectorBytes = jwtToken.InitializationVectorBytes;
                    $i37.MaximumDeflateSize = this.MaximumTokenSizeInBytes;
                    $i37.Keys = keys;
                    $i37.Zip = jwtToken.Zip;
                    return $i37;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(98784575615)
            
            //--TRIMMABLE-BOUNDARY-START(386547384447)
            static /*SecurityKey */ ResolveTokenDecryptionKeyFromConfig(/*JsonWebToken*/ jwtToken, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547384447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (!$.$$.S.String.IsNullOrEmpty(jwtToken.Kid) && configuration.TokenDecryptionKeys !== null)
                {
                    let $en38 = configuration.TokenDecryptionKeys.SCG$IEnumerable$$$GetEnumerator();
                    while ($en38.SC$1$IEnumerator$MoveNext())
                    {
                        let key = $en38.SCG$IEnumerator$$$Current;
                        {
                            if (key !== null && $.$$.S.String.Equals$3(key.KeyId, jwtToken.Kid, $.$mij.MIJ.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                            {
                                return key;
                            }
                        }
                    }
                }
                if (!$.$$.S.String.IsNullOrEmpty(jwtToken.X5t) && configuration.TokenDecryptionKeys !== null)
                {
                    let $en39 = configuration.TokenDecryptionKeys.SCG$IEnumerable$$$GetEnumerator();
                    while ($en39.SC$1$IEnumerator$MoveNext())
                    {
                        let key = $en39.SCG$IEnumerator$$$Current;
                        {
                            if (key !== null && $.$$.S.String.Equals$3(key.KeyId, jwtToken.X5t, $.$mij.MIJ.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                            {
                                return key;
                            }
                            /*var*/ let x509Key = $.$as(key, $.$mit.MIT$1.X509SecurityKey);
                            if (x509Key !== null && $.$$.S.String.Equals$3(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                return key;
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(386547384447)
            
            //--TRIMMABLE-BOUNDARY-START(382252417151)
            /*SecurityKey */ ResolveTokenDecryptionKey$1(/*string*/ token, /*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252417151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*StringComparison*/ let stringComparison = $.$mij.MIJ.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(validationParameters.TokenDecryptionKey);
                if (!$.$$.S.String.IsNullOrEmpty(jwtToken.Kid))
                {
                    if (validationParameters.TokenDecryptionKey !== null && $.$$.S.String.Equals$3(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Kid, stringComparison))
                    {
                        return validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        let $en40 = validationParameters.TokenDecryptionKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en40.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en40.SCG$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.S.String.Equals$3(key.KeyId, jwtToken.Kid, $.$mij.MIJ.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                if (!$.$$.S.String.IsNullOrEmpty(jwtToken.X5t))
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        if ($.$$.S.String.Equals$3(validationParameters.TokenDecryptionKey.KeyId, jwtToken.X5t, stringComparison))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                        /*var*/ let x509Key = $.$as(validationParameters.TokenDecryptionKey, $.$mit.MIT$1.X509SecurityKey);
                        if (x509Key !== null && $.$$.S.String.Equals$3(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        let $en41 = validationParameters.TokenDecryptionKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en41.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en41.SCG$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.S.String.Equals$3(key.KeyId, jwtToken.X5t, $.$mij.MIJ.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                                {
                                    return key;
                                }
                                /*var*/ let x509Key = $.$as(key, $.$mit.MIT$1.X509SecurityKey);
                                if (x509Key !== null && $.$$.S.String.Equals$3(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(382252417151)
            
            //--TRIMMABLE-BOUNDARY-START(352187646079)
            /*JsonWebToken */ ReadJsonWebToken$1(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187646079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(token))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("token");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.S.Int32)) ], null, null))));
                }
                return new $.$mij.MIJ.JsonWebToken().$ctor$7(token);
            }
            //--TRIMMABLE-BOUNDARY-END(352187646079)
            
            //--TRIMMABLE-BOUNDARY-START(347892678783)
            /*JsonWebToken */ ReadJsonWebToken(/*ReadOnlyMemory<char>*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892678783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token.IsEmpty)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("token");
                }
                if (token.Span.Length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(token.Length, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.S.Int32)) ], null, null))));
                }
                return new $.$mij.MIJ.JsonWebToken().$ctor$3(token);
            }
            //--TRIMMABLE-BOUNDARY-END(347892678783)
            
            //--TRIMMABLE-BOUNDARY-START(373662482559)
            /*JsonWebToken */ ReplaceTokenHeader(/*JsonWebToken*/ jsonWebToken, /*string*/ encodedHeader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662482559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mij.MIJ.JsonWebToken().$ctor$8(jsonWebToken, encodedHeader);
            }
            //--TRIMMABLE-BOUNDARY-END(373662482559)
            
            //--TRIMMABLE-BOUNDARY-START(365072547967)
            /*SecurityToken */ ReadToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072547967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadJsonWebToken$1(token);
            }
            //--TRIMMABLE-BOUNDARY-END(365072547967)
            
            //--TRIMMABLE-BOUNDARY-START(360777580671)
            static /*TokenValidationResult */ ReadToken$2(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777580671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JsonWebToken*/ let jsonWebToken = null;
                if (validationParameters.TokenReader !== null)
                {
                    /*var*/ let securityToken = validationParameters.TokenReader.Invoke(token, validationParameters);
                    if (securityToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10510: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader returned null when reading token: '{0}'."/*TokenLogMessages.IDX10510*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    jsonWebToken = $.$as(securityToken, $.$mij.MIJ.JsonWebToken);
                    if (jsonWebToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10509: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader did not return a '{0}', but returned a '{1}' when reading token: '{2}'."/*TokenLogMessages.IDX10509*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mij.MIJ.JsonWebToken.$type, $.$$.S.Object.GetType.call(securityToken), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                }
                else 
                {
                    try
                    {
                        jsonWebToken = new $.$mij.MIJ.JsonWebToken().$ctor$4(token, validationParameters.TryReadJwtClaim);
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t42 = $.$mit.MIT$1.TokenValidationResult;
                            const $i42 = new $t42();
                            $i42.$ctor$1();
                            $i42.Exception = ex;
                            $i42.IsValid = false;
                            return $i42;
                        })();
                    }
                }
                return (() =>
                {
                    //new $.$mit.MIT$1.TokenValidationResult()
                    const $t43 = $.$mit.MIT$1.TokenValidationResult;
                    const $i43 = new $t43();
                    $i43.$ctor$1();
                    $i43.SecurityToken = jsonWebToken;
                    $i43.IsValid = true;
                    return $i43;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(360777580671)
            
            //--TRIMMABLE-BOUNDARY-START(438086991999)
            /*Telemetry.ITelemetryClient*/ TelemetryClient = null;
            //--TRIMMABLE-BOUNDARY-END(438086991999)
            
            //--TRIMMABLE-BOUNDARY-START(47244968063)
            /*bool */ get CanValidateToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928561791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(47244968063)
            
            //--TRIMMABLE-BOUNDARY-START(455266861183)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWEAsync$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    let $t44, $r44;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(455266861183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t44 = this.ValidateJWEAsync$1(jwtToken, validationParameters, configuration, $.$$.ST$1.CancellationToken.None).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t44, { set $v($v) { $r44 = $v; } }) ? $r44 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t44))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(455266861183)
            
            //--TRIMMABLE-BOUNDARY-START(450971893887)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWEAsync$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(450971893887);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t45, $r45;
                        /*TokenValidationResult*/ let tokenValidationResult = $.$mij.MIJ.JsonWebTokenHandler.ReadToken$2(this.DecryptToken$1(jwtToken, validationParameters, configuration), validationParameters);
                        if (!tokenValidationResult.IsValid)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, tokenValidationResult);
                        }
                        tokenValidationResult = ($t45 = this.ValidateJWSAsync$1($.$as(tokenValidationResult.SecurityToken, $.$mij.MIJ.JsonWebToken), validationParameters, configuration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t45, { set $v($v) { $r45 = $v; } }) ? $r45 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t45)));
                        if (!tokenValidationResult.IsValid)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, tokenValidationResult);
                        }
                        jwtToken.InnerToken = $.$as(tokenValidationResult.SecurityToken, $.$mij.MIJ.JsonWebToken);
                        jwtToken.Payload = ($.$as(tokenValidationResult.SecurityToken, $.$mij.MIJ.JsonWebToken)).Payload;
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t46 = $.$mit.MIT$1.TokenValidationResult;
                            const $i46 = new $t46();
                            $i46.$ctor$1();
                            $i46.SecurityToken = jwtToken;
                            $i46.ClaimsIdentityNoLocking = tokenValidationResult.ClaimsIdentityNoLocking;
                            $i46.IsValid = true;
                            $i46.TokenType = tokenValidationResult.TokenType;
                            return $i46;
                        })());
                    }
                    catch(ex)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t47 = $.$mit.MIT$1.TokenValidationResult;
                            const $i47 = new $t47();
                            $i47.$ctor$1();
                            $i47.Exception = ex;
                            $i47.IsValid = false;
                            $i47.TokenOnFailedValidation = validationParameters.IncludeTokenOnFailedValidation ? jwtToken : null;
                            return $i47;
                        })());
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(450971893887)
            
            //--TRIMMABLE-BOUNDARY-START(468151763071)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWSAsync$2(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    let $t48, $r48;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(468151763071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t48 = this.ValidateJWSAsync$1(jsonWebToken, validationParameters, configuration, $.$$.ST$1.CancellationToken.None).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t48, { set $v($v) { $r48 = $v; } }) ? $r48 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t48))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(468151763071)
            
            //--TRIMMABLE-BOUNDARY-START(463856795775)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWSAsync$1(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(463856795775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        /*TokenValidationResult*/ let tokenValidationResult;
                        if (validationParameters.TransformBeforeSignatureValidation !== null)
                        {
                            jsonWebToken = $.$as(validationParameters.TransformBeforeSignatureValidation.Invoke(jsonWebToken, validationParameters), $.$mij.MIJ.JsonWebToken);
                        }
                        if (validationParameters.SignatureValidator !== null || validationParameters.SignatureValidatorUsingConfiguration !== null)
                        {
                            let $t49, $r49;
                            /*var*/ let validatedToken = $.$mij.MIJ.JsonWebTokenHandler.ValidateSignatureUsingDelegates(jsonWebToken, validationParameters);
                            tokenValidationResult = ($t49 = this.ValidateTokenPayloadAsync(validatedToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t49, { set $v($v) { $r49 = $v; } }) ? $r49 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t49)));
                            $.$mit.MIT$1.Validators.ValidateIssuerSecurityKey$1(validatedToken.SigningKey, validatedToken, validationParameters);
                        }
                        else 
                        {
                            if (validationParameters.ValidateSignatureLast)
                            {
                                let $t50, $r50;
                                tokenValidationResult = ($t50 = this.ValidateTokenPayloadAsync(jsonWebToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t50, { set $v($v) { $r50 = $v; } }) ? $r50 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t50)));
                                if (tokenValidationResult.IsValid)
                                {
                                    tokenValidationResult.SecurityToken = this.ValidateSignatureAndIssuerSecurityKey(jsonWebToken, validationParameters, configuration);
                                }
                            }
                            else 
                            {
                                let $t51, $r51;
                                /*var*/ let validatedToken = this.ValidateSignatureAndIssuerSecurityKey(jsonWebToken, validationParameters, configuration);
                                tokenValidationResult = ($t51 = this.ValidateTokenPayloadAsync(validatedToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t51, { set $v($v) { $r51 = $v; } }) ? $r51 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t51)));
                            }
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, tokenValidationResult);
                    }
                    catch(ex)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t52 = $.$mit.MIT$1.TokenValidationResult;
                            const $i52 = new $t52();
                            $i52.$ctor$1();
                            $i52.Exception = ex;
                            $i52.IsValid = false;
                            $i52.TokenOnFailedValidation = validationParameters.IncludeTokenOnFailedValidation ? jsonWebToken : null;
                            return $i52;
                        })());
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(463856795775)
            
            //--TRIMMABLE-BOUNDARY-START(493921566847)
            /*JsonWebToken */ ValidateSignatureAndIssuerSecurityKey(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493921566847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JsonWebToken*/ let validatedToken = this.ValidateSignature$3(jsonWebToken, validationParameters, configuration);
                $.$mit.MIT$1.Validators.ValidateIssuerSecurityKey(validatedToken.SigningKey, jsonWebToken, validationParameters, configuration);
                return validatedToken;
            }
            //--TRIMMABLE-BOUNDARY-END(493921566847)
            
            //--TRIMMABLE-BOUNDARY-START(485331632255)
            /*JsonWebToken */ ValidateSignature$3(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485331632255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let kidMatched = false;
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (!jwtToken.IsSigned)
                {
                    if (validationParameters.RequireSignedTokens)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    else 
                    {
                        return jwtToken;
                    }
                }
                if (validationParameters.IssuerSigningKeyResolverUsingConfiguration !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolverUsingConfiguration.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, configuration);
                }
                else if (validationParameters.IssuerSigningKeyResolver !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolver.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = $.$mij.MIJ.JwtTokenUtilities.ResolveTokenSigningKey(jwtToken.Kid, jwtToken.X5t, validationParameters, configuration);
                    if (key !== null)
                    {
                        kidMatched = true;
                        keys = $.$$.SRC.RuntimeHelpers.CreateArray($.$mit.MIT$1.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (validationParameters.TryAllIssuerSigningKeys && $.$mit.MIT$1.CollectionUtilities.IsNullOrEmpty($.$mit.MIT$1.SecurityKey, keys))
                {
                    keys = $.$mit.MIT$1.TokenUtilities.GetAllSigningKeys$1(configuration, validationParameters);
                }
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*var*/ let kidExists = !$.$$.S.String.IsNullOrEmpty(jwtToken.Kid);
                if (keys !== null)
                {
                    let $en53 = keys.SCG$IEnumerable$$$GetEnumerator();
                    while ($en53.SC$1$IEnumerator$MoveNext())
                    {
                        let key = $en53.SCG$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$mij.MIJ.JsonWebTokenHandler.ValidateSignature$1(jwtToken, key, validationParameters, this.TelemetryClient))
                                {
                                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.MIL.LogHelper.LogInformation("IDX10242: Security token: '{0}' has a valid signature."/*TokenLogMessages.IDX10242*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ jwtToken ], null, null));
                                    }
                                    jwtToken.SigningKey = key;
                                    return jwtToken;
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(ex.ToString());
                            }
                            if (key !== null)
                            {
                                (keysAttempted ??= new $.$$.ST.StringBuilder().$ctor$1()).Append$21(key.ToString()).Append$21(" , KeyId: ").AppendLine$3(key.KeyId);
                                if (kidExists && !kidMatched && key.KeyId !== null)
                                {
                                    kidMatched = $.$$.S.String.Equals$2.call(jwtToken.Kid, key.KeyId, $.$is(key, $.$mit.MIT$1.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
                                }
                            }
                        }
                    }
                }
                /*var*/ let keysInTokenValidationParameters = $.$mit.MIT$1.TokenUtilities.GetAllSigningKeys$1(null, validationParameters);
                /*var*/ let keysInConfiguration = $.$mit.MIT$1.TokenUtilities.GetAllSigningKeys$1(configuration, null);
                /*var*/ let numKeysInTokenValidationParameters = $.$sl.SL.Enumerable.Count$1($.$mit.MIT$1.SecurityKey, keysInTokenValidationParameters);
                /*var*/ let numKeysInConfiguration = $.$sl.SL.Enumerable.Count$1($.$mit.MIT$1.SecurityKey, keysInConfiguration);
                if (kidExists)
                {
                    if (kidMatched)
                    {
                        /*JsonWebToken*/ let localJwtToken = jwtToken;
                        /*var*/ let isKidInTVP = $.$sl.SL.Enumerable.Any($.$mit.MIT$1.SecurityKey, keysInTokenValidationParameters, new ($.$$.S.Func$$$($.$mit.MIT$1.SecurityKey, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x) =>
                        {
                            return $.$$.S.String.Equals$5.call(x.KeyId, localJwtToken.Kid);
                        }, $MmlvHh ??= {"r":262145,"p":[{"n":"x","p":13631614}],"n":"","d":327807,"h":0,"f":17825794}));
                        /*var*/ let keyLocation = isKidInTVP ? "TokenValidationParameters" : "Configuration";
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10511: Signature validation failed. Keys tried: '{0}'. \nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'. \nMatched key was in '{3}'. \nkid: '{4}'. \nExceptions caught:\n '{5}'.\ntoken: '{6}'. See https://aka.ms/IDX10511 for details."/*TokenLogMessages.IDX10511*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII(keyLocation), $.$mil.MIL.LogHelper.MarkAsNonPII(jwtToken.Kid), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    if (!validationParameters.ValidateSignatureLast)
                    {
                        $.$mit.MIT$1.InternalValidators.ValidateAfterSignatureFailed(jwtToken, jwtToken.ValidFromNullable, jwtToken.ValidToNullable, jwtToken.Audiences, validationParameters, configuration);
                    }
                }
                if (!(keysAttempted === null))
                {
                    if (kidExists)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.MIL.LogHelper.FormatInvariant("IDX10503: Signature validation failed. The token's kid is: '{0}', but did not match any keys in TokenValidationParameters or Configuration. Keys tried: '{1}'.\nNumber of keys in TokenValidationParameters: '{2}'. \nNumber of keys in Configuration: '{3}'.\nExceptions caught:\n '{4}'.\ntoken: '{5}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10503*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.S.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    else 
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.MIL.LogHelper.FormatInvariant("IDX10517: Signature validation failed. The token's kid is missing. Keys tried: '{0}'.\nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\nExceptions caught:\n '{3}'.\ntoken: '{4}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10517*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.S.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                }
                $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, null);
                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenSignatureKeyNotFoundException().$ctor$28("IDX10500: Signature validation failed. No security keys were provided to validate the signature."/*TokenLogMessages.IDX10500*/));
            }
            //--TRIMMABLE-BOUNDARY-END(485331632255)
            
            //--TRIMMABLE-BOUNDARY-START(313532940415)
            static /*bool */ IsSignatureValid(/*byte[]*/ signatureBytes, /*int*/ signatureBytesLength, /*SignatureProvider*/ signatureProvider, /*byte[]*/ dataToVerify, /*int*/ dataToVerifyLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532940415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(signatureProvider, $.$mit.MIT$1.SymmetricSignatureProvider))
                {
                    return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, signatureBytes, 0, signatureBytesLength);
                }
                else 
                {
                    if (signatureBytes.length === signatureBytesLength)
                    {
                        return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, signatureBytes, 0, signatureBytesLength);
                    }
                    else 
                    {
                        /*byte[]*/ let sigBytes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [signatureBytesLength], null);
                        $.$$.S.Array.Copy(signatureBytes, 0, sigBytes, 0, signatureBytesLength);
                        return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, sigBytes, 0, signatureBytesLength);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(313532940415)
            
            //--TRIMMABLE-BOUNDARY-START(489626599551)
            static /*bool */ ValidateSignature$4(/*byte[]*/ bytes, /*int*/ len, /*string*/ stringWithSignature, /*int*/ signatureStartIndex, /*SignatureProvider*/ signatureProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489626599551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mit.MIT$1.Base64UrlEncoding.Decode$3($.$$.S.Boolean, $.$mit.MIT$1.SignatureProvider, $.$typeArray($.$$.S.Byte), $.$$.S.Int32, stringWithSignature, ((signatureStartIndex + 1) | 0), ((((stringWithSignature.length - signatureStartIndex) | 0) - 1) | 0), signatureProvider, bytes, len, new ($.$$.S.Func$$$$$$$($.$typeArray($.$$.S.Byte), $.$$.S.Int32, $.$mit.MIT$1.SignatureProvider, $.$typeArray($.$$.S.Byte), $.$$.S.Int32, $.$$.S.Boolean))().$ctor($.$mij.MIJ.JsonWebTokenHandler, $.$mij.MIJ.JsonWebTokenHandler.IsSignatureValid));
            }
            //--TRIMMABLE-BOUNDARY-END(489626599551)
            
            //--TRIMMABLE-BOUNDARY-START(481036664959)
            static /*bool */ ValidateSignature$2(/*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036664959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.JsonWebTokenHandler.ValidateSignature$1(jsonWebToken, key, validationParameters, $.$mit.MIT.NullTelemetryClient.Instance);
            }
            //--TRIMMABLE-BOUNDARY-END(481036664959)
            
            //--TRIMMABLE-BOUNDARY-START(369367515263)
            static /*void */ RecordSignatureValidationTelemetry(/*Telemetry.ITelemetryClient*/ telemetryClient, /*string*/ errorType, /*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367515263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mit.MIT.CryptoTelemetry.RecordSignatureValidationTelemetry)
                {
                    telemetryClient.MIT$ITelemetryClient$IncrementSignatureValidationCounter(errorType, jsonWebToken.Issuer, jsonWebToken.Alg, key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(369367515263)
            
            //--TRIMMABLE-BOUNDARY-START(476741697663)
            static /*bool */ ValidateSignature$1(/*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key, /*TokenValidationParameters*/ validationParameters, /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476741697663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Alg, key))
                {
                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.MIL.LogHelper.LogInformation("IDX14000: Signature validation of this JWT is not supported for: Algorithm: '{0}', SecurityKey: '{1}'."/*LogMessages.IDX14000*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(jsonWebToken.Alg), $.$mil.MIL.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                    }
                    $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    return false;
                }
                try
                {
                    $.$mit.MIT$1.Validators.ValidateAlgorithm(jsonWebToken.Alg, key, jsonWebToken, validationParameters);
                }
                catch($e)
                {
                    $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    throw $e;
                }
                /*SignatureProvider*/ let signatureProvider;
                try
                {
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, jsonWebToken.Alg);
                    if (signatureProvider === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.MIL.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null))));
                    }
                }
                catch($e)
                {
                    $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                    throw $e;
                }
                try
                {
                    /*bool*/ let isValid = $.$mit.MIT$1.EncodingUtils.PerformEncodingDependentOperation($.$$.S.Boolean, $.$$.S.String, $.$$.S.Int32, $.$mit.MIT$1.SignatureProvider, jsonWebToken.EncodedToken, 0, jsonWebToken.Dot2, $.$$.ST.Encoding.UTF8, jsonWebToken.EncodedToken, jsonWebToken.Dot2, signatureProvider, new ($.$$.S.Func$$$$$$$($.$typeArray($.$$.S.Byte), $.$$.S.Int32, $.$$.S.String, $.$$.S.Int32, $.$mit.MIT$1.SignatureProvider, $.$$.S.Boolean))().$ctor($.$mij.MIJ.JsonWebTokenHandler, $.$mij.MIJ.JsonWebTokenHandler.ValidateSignature$4));
                    $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, isValid ? "None"/*TelemetryConstants.SignatureValidationErrors.None*/ : "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    return isValid;
                }
                catch($e)
                {
                    $.$mij.MIJ.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    throw $e;
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(476741697663)
            
            //--TRIMMABLE-BOUNDARY-START(502511501439)
            static /*JsonWebToken */ ValidateSignatureUsingDelegates(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511501439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters.SignatureValidatorUsingConfiguration !== null)
                {
                    /*BaseConfiguration*/ let configuration = null;
                    /*var*/ let validatedToken = validationParameters.SignatureValidatorUsingConfiguration.Invoke(jsonWebToken.EncodedToken, validationParameters, configuration);
                    if (validatedToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ jsonWebToken ], null, null))));
                    }
                    let validatedJsonWebToken;
                    if (!($.$is(validatedToken, $.$mij.MIJ.JsonWebToken, { set $v($v){ validatedJsonWebToken = $v; } })))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$mij.MIJ.JsonWebToken.$type), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Object.GetType.call(validatedToken)), jsonWebToken ], null, null))));
                    }
                    return validatedJsonWebToken;
                }
                else if (validationParameters.SignatureValidator !== null)
                {
                    /*var*/ let validatedToken = validationParameters.SignatureValidator.Invoke(jsonWebToken.EncodedToken, validationParameters);
                    if (validatedToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ jsonWebToken ], null, null))));
                    }
                    let validatedJsonWebToken;
                    if (!($.$is(validatedToken, $.$mij.MIJ.JsonWebToken, { set $v($v){ validatedJsonWebToken = $v; } })))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$mij.MIJ.JsonWebToken.$type), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Object.GetType.call(validatedToken)), jsonWebToken ], null, null))));
                    }
                    return validatedJsonWebToken;
                }
                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ jsonWebToken ], null, null))));
            }
            //--TRIMMABLE-BOUNDARY-END(502511501439)
            
            //--TRIMMABLE-BOUNDARY-START(511101436031)
            /*TokenValidationResult */ ValidateToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101436031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateTokenAsync$5(token, validationParameters).ConfigureAwait$2(false).GetAwaiter().GetResult();
            }
            //--TRIMMABLE-BOUNDARY-END(511101436031)
            
            //--TRIMMABLE-BOUNDARY-START(541166207103)
            /*Task<TokenValidationResult> */ ValidateTokenAsync$5(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541166207103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateTokenAsync$4(token, validationParameters, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(541166207103)
            
            //--TRIMMABLE-BOUNDARY-START(536871239807)
            /*Task<TokenValidationResult> *//*async*/  ValidateTokenAsync$4(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(536871239807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrEmpty(token))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t54 = $.$mit.MIT$1.TokenValidationResult;
                            const $i54 = new $t54();
                            $i54.$ctor$1();
                            $i54.Exception = $.$mil.MIL.LogHelper.LogArgumentNullException("token");
                            $i54.IsValid = false;
                            return $i54;
                        })());
                    }
                    if (validationParameters === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t55 = $.$mit.MIT$1.TokenValidationResult;
                            const $i55 = new $t55();
                            $i55.$ctor$1();
                            $i55.Exception = $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                            $i55.IsValid = false;
                            return $i55;
                        })());
                    }
                    if (token.length > this.MaximumTokenSizeInBytes)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t56 = $.$mit.MIT$1.TokenValidationResult;
                            const $i56 = new $t56();
                            $i56.$ctor$1();
                            $i56.Exception = $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.S.Int32)) ], null, null))));
                            $i56.IsValid = false;
                            return $i56;
                        })());
                    }
                    try
                    {
                        /*TokenValidationResult*/ let result = $.$mij.MIJ.JsonWebTokenHandler.ReadToken$2(token, validationParameters);
                        if (result.IsValid)
                        {
                            let $t57, $r57;
                            return $.$$.N.AsyncResolver.Result($asnycContext, ($t57 = this.ValidateTokenAsync$1(result.SecurityToken, validationParameters, cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t57, { set $v($v) { $r57 = $v; } }) ? $r57 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t57))));
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, result);
                    }
                    catch(ex)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t58 = $.$mit.MIT$1.TokenValidationResult;
                            const $i58 = new $t58();
                            $i58.$ctor$1();
                            $i58.Exception = ex;
                            $i58.IsValid = false;
                            return $i58;
                        })());
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(536871239807)
            
            //--TRIMMABLE-BOUNDARY-START(528281305215)
            /*Task<TokenValidationResult> */ ValidateTokenAsync$2(/*SecurityToken*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281305215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateTokenAsync$1(token, validationParameters, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(528281305215)
            
            //--TRIMMABLE-BOUNDARY-START(523986337919)
            /*Task<TokenValidationResult> *//*async*/  ValidateTokenAsync$1(/*SecurityToken*/ token, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(523986337919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (token === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("token");
                    }
                    if (validationParameters === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t59 = $.$mit.MIT$1.TokenValidationResult;
                            const $i59 = new $t59();
                            $i59.$ctor$1();
                            $i59.Exception = $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                            $i59.IsValid = false;
                            return $i59;
                        })());
                    }
                    /*var*/ let jwt = $.$as(token, $.$mij.MIJ.JsonWebToken);
                    if (jwt === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t60 = $.$mit.MIT$1.TokenValidationResult;
                            const $i60 = new $t60();
                            $i60.$ctor$1();
                            $i60.Exception = $.$mil.MIL.LogHelper.LogArgumentException$7($.$$.S.ArgumentException, "token", `${$.$strNN("token")} must be a ${$.$strNN("JsonWebToken")}.`);
                            $i60.IsValid = false;
                            return $i60;
                        })());
                    }
                    try
                    {
                        let $t61, $r61;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t61 = this.ValidateTokenAsync$6(jwt, validationParameters, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t61, { set $v($v) { $r61 = $v; } }) ? $r61 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t61))));
                    }
                    catch(ex)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$mit.MIT$1.TokenValidationResult()
                            const $t62 = $.$mit.MIT$1.TokenValidationResult;
                            const $i62 = new $t62();
                            $i62.$ctor$1();
                            $i62.Exception = ex;
                            $i62.IsValid = false;
                            return $i62;
                        })());
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(523986337919)
            
            //--TRIMMABLE-BOUNDARY-START(515396403327)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenAsync$6(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    let $t64, $r64;
                    let $t65, $r65;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(515396403327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*BaseConfiguration*/ let currentConfiguration = null;
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        try
                        {
                            let $t63, $r63;
                            currentConfiguration = ($t63 = validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t63, { set $v($v) { $r63 = $v; } }) ? $r63 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t63)));
                        }
                        catch(ex)
                        {
                            if ($.$mil.MIL.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.MIL.LogHelper.LogWarning($.$mil.MIL.LogHelper.FormatInvariant("IDX10261: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token validation in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10261*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ validationParameters.ConfigurationManager.MetadataAddress, ex.ToString() ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                            }
                        }
                    }
                    /*TokenValidationResult*/ let tokenValidationResult = jsonWebToken.IsEncrypted ? ($t64 = this.ValidateJWEAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t64, { set $v($v) { $r64 = $v; } }) ? $r64 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t64))) : ($t65 = this.ValidateJWSAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t65, { set $v($v) { $r65 = $v; } }) ? $r65 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t65)));
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        if (tokenValidationResult.IsValid)
                        {
                            if (currentConfiguration !== null)
                            {
                                validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, tokenValidationResult);
                        }
                        else if ($.$mit.MIT$1.TokenUtilities.IsRecoverableException(tokenValidationResult.Exception, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.SCG$ICollection$$$Count > 0)))
                        {
                            if (currentConfiguration !== null)
                            {
                                let $t66, $r66;
                                this.TelemetryClient.MIT$ITelemetryClient$IncrementConfigurationRefreshRequestCounter$2(validationParameters.ConfigurationManager.MetadataAddress, "LastKnownGood"/*TelemetryConstants.Protocols.Lkg*/, "Unknown"/*TelemetryConstants.Protocols.ConfigurationSourceUnknown*/);
                                validationParameters.ConfigurationManager.RequestRefresh();
                                validationParameters.RefreshBeforeValidation = true;
                                /*var*/ let lastConfig = currentConfiguration;
                                currentConfiguration = ($t66 = validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t66, { set $v($v) { $r66 = $v; } }) ? $r66 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t66)));
                                if (lastConfig !== currentConfiguration)
                                {
                                    let $t67, $r67;
                                    let $t68, $r68;
                                    tokenValidationResult = jsonWebToken.IsEncrypted ? ($t67 = this.ValidateJWEAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t67, { set $v($v) { $r67 = $v; } }) ? $r67 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t67))) : ($t68 = this.ValidateJWSAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t68, { set $v($v) { $r68 = $v; } }) ? $r68 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t68)));
                                    if (tokenValidationResult.IsValid)
                                    {
                                        validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                        return $.$$.N.AsyncResolver.Result($asnycContext, tokenValidationResult);
                                    }
                                }
                            }
                            if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                            {
                                validationParameters.RefreshBeforeValidation = false;
                                validationParameters.ValidateWithLKG = true;
                                /*var*/ let recoverableException = tokenValidationResult.Exception;
                                let $i69 = 0;
                                let $arr69 = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                                while ($i69 < $arr69.length)
                                {
                                    let lkgConfiguration = $arr69[$i69++];
                                    if (!$.$dsp(lkgConfiguration, $.$$.S.Object, ($t) => $t.Equals$1, currentConfiguration) && $.$mit.MIT$1.TokenUtilities.IsRecoverableConfiguration(jsonWebToken.Kid, currentConfiguration, lkgConfiguration, recoverableException))
                                    {
                                        let $t70, $r70;
                                        let $t71, $r71;
                                        tokenValidationResult = jsonWebToken.IsEncrypted ? ($t70 = this.ValidateJWEAsync$1(jsonWebToken, validationParameters, lkgConfiguration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t70, { set $v($v) { $r70 = $v; } }) ? $r70 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t70))) : ($t71 = this.ValidateJWSAsync$1(jsonWebToken, validationParameters, lkgConfiguration, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t71, { set $v($v) { $r71 = $v; } }) ? $r71 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t71)));
                                        if (tokenValidationResult.IsValid)
                                        {
                                            return $.$$.N.AsyncResolver.Result($asnycContext, tokenValidationResult);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, tokenValidationResult);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(515396403327)
            
            //--TRIMMABLE-BOUNDARY-START(549756141695)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenPayloadAsync$1(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    let $t72, $r72;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(549756141695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t72 = this.ValidateTokenPayloadAsync(jsonWebToken, validationParameters, configuration, $.$$.ST$1.CancellationToken.None).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t72, { set $v($v) { $r72 = $v; } }) ? $r72 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t72))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(549756141695)
            
            //--TRIMMABLE-BOUNDARY-START(545461174399)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenPayloadAsync(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult), $.$mit.MIT$1.TokenValidationResult, async ($asnycContext) => 
                {
                    let $t73, $r73;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(545461174399);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let expires = jsonWebToken.HasPayloadClaim("exp"/*JwtRegisteredClaimNames.Exp*/) ? $.$cast(jsonWebToken.ValidTo, $.$$.S.Nullable$$($.$$.S.DateTime)) : null;
                    /*var*/ let notBefore = jsonWebToken.HasPayloadClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/) ? $.$cast(jsonWebToken.ValidFrom, $.$$.S.Nullable$$($.$$.S.DateTime)) : null;
                    $.$mit.MIT$1.Validators.ValidateLifetime$1($.$clone(notBefore), $.$clone(expires), jsonWebToken, validationParameters);
                    $.$mit.MIT$1.Validators.ValidateAudience(jsonWebToken.Audiences, jsonWebToken, validationParameters);
                    /*string*/ let issuer = ($t73 = $.$mit.MIT$1.Validators.ValidateIssuerAsync$1(jsonWebToken.Issuer, jsonWebToken, validationParameters, configuration).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t73, { set $v($v) { $r73 = $v; } }) ? $r73 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t73)));
                    $.$mit.MIT$1.Validators.ValidateTokenReplay$1($.$clone(expires), jsonWebToken.EncodedToken, validationParameters);
                    if (validationParameters.ValidateActor && !$.$$.S.String.IsNullOrWhiteSpace(jsonWebToken.Actor))
                    {
                        let $t74, $r74;
                        /*TokenValidationResult*/ let tokenValidationResult = ($t74 = this.ValidateTokenAsync$4(jsonWebToken.Actor, validationParameters.ActorValidationParameters ?? validationParameters, cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t74, { set $v($v) { $r74 = $v; } }) ? $r74 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t74)));
                        if (!tokenValidationResult.IsValid)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, tokenValidationResult);
                        }
                    }
                    /*string*/ let tokenType = $.$mit.MIT$1.Validators.ValidateTokenType$1(jsonWebToken.Typ, jsonWebToken, validationParameters);
                    return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                    {
                        //new $.$mit.MIT$1.TokenValidationResult()
                        const $t75 = $.$mit.MIT$1.TokenValidationResult;
                        const $i75 = new $t75();
                        $i75.$ctor$2(jsonWebToken, this, validationParameters.Clone(), issuer);
                        $i75.IsValid = true;
                        $i75.TokenType = tokenType;
                        return $i75;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(545461174399)
            
            //--TRIMMABLE-BOUNDARY-START(390842351743)
            /*SecurityTokenDescriptor*/ static s_emptyTokenDescriptor = null;
            //--TRIMMABLE-BOUNDARY-END(390842351743)
            
            //--TRIMMABLE-BOUNDARY-START(30065098879)
            /*string*/ static ActClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(30065098879)
            
            //--TRIMMABLE-BOUNDARY-START(395137319039)
            /*int*/ static s_maxActorChainLength = 1;
            //--TRIMMABLE-BOUNDARY-END(395137319039)
            
            //--TRIMMABLE-BOUNDARY-START(322122875007)
            static /*int */ get MaxActorChainLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698365567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.MIJ.JsonWebTokenHandler.s_maxActorChainLength;
            }
            static /*int */ set MaxActorChainLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907122815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 1)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentOutOfRangeException().$ctor$19("value", $.$mil.MIL.LogHelper.FormatInvariant("IDX14317: JsonWebTokenHandler.MaxActorChainLength must be greater than or equal to 1. Value provided was: '{0}'."/*LogMessages.IDX14317*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(value, $.$$.S.Int32)) ], null, null))));
                }
                $.$mij.MIJ.JsonWebTokenHandler.s_maxActorChainLength = value;
            }
            //--TRIMMABLE-BOUNDARY-END(322122875007)
            
            //--TRIMMABLE-BOUNDARY-START(167504052351)
            /*string */ CreateToken$15(/*string*/ payload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, $.$mij.MIJ.JsonWebTokenHandler.s_emptyTokenDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(167504052351)
            
            //--TRIMMABLE-BOUNDARY-START(163209085055)
            /*string */ CreateToken$14(/*string*/ payload, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209085055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t76 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i76 = new $t76();
                    $i76.$ctor$1();
                    $i76.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i76;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(163209085055)
            
            //--TRIMMABLE-BOUNDARY-START(158914117759)
            /*string */ CreateToken$13(/*string*/ payload, /*SigningCredentials*/ signingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914117759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t77 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i77 = new $t77();
                    $i77.$ctor$1();
                    $i77.SigningCredentials = signingCredentials;
                    return $i77;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(158914117759)
            
            //--TRIMMABLE-BOUNDARY-START(154619150463)
            /*string */ CreateToken$12(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619150463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t78 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i78 = new $t78();
                    $i78.$ctor$1();
                    $i78.SigningCredentials = signingCredentials;
                    $i78.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i78;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619150463)
            
            //--TRIMMABLE-BOUNDARY-START(107374510207)
            /*string */ CreateToken$1(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(tokenDescriptor, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("tokenDescriptor") });
                if ($.$mil.MIL.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                {
                    if ((tokenDescriptor.Subject === null || !$.$sl.SL.Enumerable.Any$1($.$ssc.SSC.Claim, tokenDescriptor.Subject.Claims)) && (tokenDescriptor.Claims === null || !$.$sl.SL.Enumerable.Any$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), tokenDescriptor.Claims)))
                    {
                        $.$mil.MIL.LogHelper.LogWarning("IDX14114: Both '{0}.{1}' and '{0}.{2}' are null or empty."/*LogMessages.IDX14114*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("SecurityTokenDescriptor"), $.$mil.MIL.LogHelper.MarkAsNonPII("Subject"), $.$mil.MIL.LogHelper.MarkAsNonPII("Claims") ], null, null));
                    }
                }
                if ($.$$.S.Int32.op_GreaterThan((tokenDescriptor.AdditionalHeaderClaims?.SCG$ICollection$$$Count ?? null), 0) && $.$sl.SL.Enumerable.Any$1($.$$.S.String, $.$sl.SL.Enumerable.Intersect($.$$.S.String, tokenDescriptor.AdditionalHeaderClaims.SCG$IDictionary$$$$Keys, $.$mij.MIJ.JwtTokenUtilities.DefaultHeaderParameters, $.$$.S.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("AdditionalHeaderClaims"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.String.Join$5(", ", $.$mij.MIJ.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                if ($.$$.S.Int32.op_GreaterThan((tokenDescriptor.AdditionalInnerHeaderClaims?.SCG$ICollection$$$Count ?? null), 0) && $.$sl.SL.Enumerable.Any$1($.$$.S.String, $.$sl.SL.Enumerable.Intersect($.$$.S.String, tokenDescriptor.AdditionalInnerHeaderClaims.SCG$IDictionary$$$$Keys, $.$mij.MIJ.JwtTokenUtilities.DefaultHeaderParameters, $.$$.S.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("AdditionalInnerHeaderClaims"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.String.Join$5(", ", $.$mij.MIJ.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken(tokenDescriptor, this.SetDefaultTimesOnTokenCreation, this.TokenLifetimeInMinutes);
            }
            //--TRIMMABLE-BOUNDARY-END(107374510207)
            
            //--TRIMMABLE-BOUNDARY-START(103079542911)
            static /*string */ CreateToken(/*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ setdefaultTimesOnTokenCreation, /*int*/ tokenLifetimeInMinutes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let utf8ByteMemoryStream = null;
                try
                {
                    utf8ByteMemoryStream = new $.$$.SI.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    /*char[]*/ let encodedChars = null;
                    /*byte[]*/ let asciiBytes = null;
                    /*byte[]*/ let signatureBytes = null;
                    try
                    {
                        writer = new $.$stj.STJ.Utf8JsonWriter().$ctor$3(utf8ByteMemoryStream, (() =>
                        {
                            //new $.$stj.STJ.JsonWriterOptions()
                            const $t79 = $.$stj.STJ.JsonWriterOptions;
                            const $i79 = new $t79();
                            $i79.$ctor$2();
                            $i79.Encoder = $.$stew.STEW.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i79;
                        })());
                        $.$mij.MIJ.JsonWebTokenHandler.WriteJwsHeader($.$ref(() => writer, ($v) => writer = $v, $.$stj.STJ.Utf8JsonWriter), tokenDescriptor);
                        /*int*/ let headerLength = $.$cast(utf8ByteMemoryStream.Length, $.$$.S.Int32);
                        writer.Reset();
                        $.$mij.MIJ.JsonWebTokenHandler.WriteJwsPayload($.$ref(() => writer, ($v) => writer = $v, $.$stj.STJ.Utf8JsonWriter), tokenDescriptor, setdefaultTimesOnTokenCreation, tokenLifetimeInMinutes);
                        /*int*/ let payloadEnd = $.$cast(utf8ByteMemoryStream.Length, $.$$.S.Int32);
                        /*int*/ let signatureSize = 0;
                        if (tokenDescriptor.SigningCredentials !== null)
                        {
                            signatureSize = $.$mit.MIT$1.SupportedAlgorithms.GetMaxByteCount(tokenDescriptor.SigningCredentials.Algorithm);
                        }
                        /*int*/ let encodedBufferSize = (($.trunc((((((payloadEnd + 4) | 0) + signatureSize) | 0)) / 3) * 4) | 0);
                        encodedChars = $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Rent(((encodedBufferSize + 4) | 0));
                        /*int*/ let sizeOfEncodedHeader = $.$mit.MIT$1.Base64UrlEncoder.Encode$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, utf8ByteMemoryStream.GetBuffer(), 0, headerLength)), $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(encodedChars));
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, sizeOfEncodedHeader);
                        /*int*/ let sizeOfEncodedPayload = $.$mit.MIT$1.Base64UrlEncoder.Encode$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, utf8ByteMemoryStream.GetBuffer(), headerLength, ((payloadEnd - headerLength) | 0))), $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Char, encodedChars, ((sizeOfEncodedHeader + 1) | 0)));
                        asciiBytes = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent($.$$.ST.Encoding.ASCII.GetMaxByteCount(encodedBufferSize));
                        /*int*/ let sizeOfEncodedHeaderAndPayloadAsciiBytes = $.$$.ST.Encoding.ASCII.GetBytes(encodedChars, 0, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0), asciiBytes, 0);
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0));
                        /*int*/ let sizeOfEncodedSignature = 0;
                        if (tokenDescriptor.SigningCredentials !== null)
                        {
                            /*int*/ let signatureLength;
                            signatureBytes = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(signatureSize);
                            /*bool*/ let signatureSucceeded = $.$mij.MIJ.JwtTokenUtilities.CreateSignature($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, asciiBytes, 0, sizeOfEncodedHeaderAndPayloadAsciiBytes)), $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(signatureBytes), tokenDescriptor.SigningCredentials, $.$ref(() => signatureLength, ($v) => signatureLength = $v, $.$$.S.Int32));
                            sizeOfEncodedSignature = $.$mit.MIT$1.Base64UrlEncoder.Encode$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, signatureBytes, 0, signatureLength)), $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Char, encodedChars, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 2) | 0)));
                        }
                        if (tokenDescriptor.EncryptingCredentials !== null)
                        {
                            return $.$mij.MIJ.JsonWebTokenHandler.EncryptToken$1($.$$.ST.Encoding.UTF8.GetBytes$1(encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)), tokenDescriptor);
                        }
                        else 
                        {
                            return $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Char, encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)).ToString();
                        }
                    }
                    finally
                    {
                        {
                            if (!(encodedChars === null))
                            {
                                $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Return(encodedChars, false);
                            }
                            if (!(signatureBytes === null))
                            {
                                $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(signatureBytes, false);
                            }
                            if (!(asciiBytes === null))
                            {
                                $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(asciiBytes, false);
                            }
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    utf8ByteMemoryStream?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079542911)
            
            //--TRIMMABLE-BOUNDARY-START(120259412095)
            /*string */ CreateToken$4(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t83 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i83 = new $t83();
                    $i83.$ctor$1();
                    $i83.EncryptingCredentials = encryptingCredentials;
                    return $i83;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(120259412095)
            
            //--TRIMMABLE-BOUNDARY-START(111669477503)
            /*string */ CreateToken$2(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t84 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i84 = new $t84();
                    $i84.$ctor$1();
                    $i84.EncryptingCredentials = encryptingCredentials;
                    $i84.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i84;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(111669477503)
            
            //--TRIMMABLE-BOUNDARY-START(150324183167)
            /*string */ CreateToken$11(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t85 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i85 = new $t85();
                    $i85.$ctor$1();
                    $i85.SigningCredentials = signingCredentials;
                    $i85.EncryptingCredentials = encryptingCredentials;
                    return $i85;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(150324183167)
            
            //--TRIMMABLE-BOUNDARY-START(128849346687)
            /*string */ CreateToken$6(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849346687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t86 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i86 = new $t86();
                    $i86.$ctor$1();
                    $i86.SigningCredentials = signingCredentials;
                    $i86.EncryptingCredentials = encryptingCredentials;
                    $i86.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i86;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(128849346687)
            
            //--TRIMMABLE-BOUNDARY-START(115964444799)
            /*string */ CreateToken$3(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload") });
                if ($.$$.S.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t87 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i87 = new $t87();
                    $i87.$ctor$1();
                    $i87.EncryptingCredentials = encryptingCredentials;
                    $i87.CompressionAlgorithm = compressionAlgorithm;
                    return $i87;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(115964444799)
            
            //--TRIMMABLE-BOUNDARY-START(146029215871)
            /*string */ CreateToken$10(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (payload === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.S.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t88 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i88 = new $t88();
                    $i88.$ctor$1();
                    $i88.SigningCredentials = signingCredentials;
                    $i88.EncryptingCredentials = encryptingCredentials;
                    $i88.CompressionAlgorithm = compressionAlgorithm;
                    return $i88;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(146029215871)
            
            //--TRIMMABLE-BOUNDARY-START(137439281279)
            /*string */ CreateToken$8(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*IDictionary<string, object>*/ additionalInnerHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439281279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (payload === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.S.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                _ = $.$firstOf(additionalInnerHeaderClaims, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalInnerHeaderClaims") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t89 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i89 = new $t89();
                    $i89.$ctor$1();
                    $i89.SigningCredentials = signingCredentials;
                    $i89.EncryptingCredentials = encryptingCredentials;
                    $i89.CompressionAlgorithm = compressionAlgorithm;
                    $i89.AdditionalHeaderClaims = additionalHeaderClaims;
                    $i89.AdditionalInnerHeaderClaims = additionalInnerHeaderClaims;
                    return $i89;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(137439281279)
            
            //--TRIMMABLE-BOUNDARY-START(141734248575)
            /*string */ CreateToken$9(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (payload === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.S.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t90 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i90 = new $t90();
                    $i90.$ctor$1();
                    $i90.SigningCredentials = signingCredentials;
                    $i90.EncryptingCredentials = encryptingCredentials;
                    $i90.CompressionAlgorithm = compressionAlgorithm;
                    $i90.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i90;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(141734248575)
            
            //--TRIMMABLE-BOUNDARY-START(133144313983)
            static /*string */ CreateToken$7(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*IDictionary<string, object>*/ additionalInnerHeaderClaims, /*string*/ tokenType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144313983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.MIJ.JsonWebTokenHandler.CreateToken$5(payload, (() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t91 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i91 = new $t91();
                        $i91.$ctor$1();
                        $i91.SigningCredentials = signingCredentials;
                        $i91.EncryptingCredentials = encryptingCredentials;
                        $i91.CompressionAlgorithm = compressionAlgorithm;
                        $i91.AdditionalHeaderClaims = additionalHeaderClaims;
                        $i91.AdditionalInnerHeaderClaims = additionalInnerHeaderClaims;
                        $i91.TokenType = tokenType;
                        return $i91;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144313983)
            
            //--TRIMMABLE-BOUNDARY-START(124554379391)
            static /*string */ CreateToken$5(/*string*/ payload, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let utf8ByteMemoryStream = null;
                try
                {
                    utf8ByteMemoryStream = new $.$$.SI.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    /*char[]*/ let encodedChars = null;
                    /*byte[]*/ let asciiBytes = null;
                    /*byte[]*/ let signatureBytes = null;
                    /*byte[]*/ let payloadBytes = null;
                    try
                    {
                        writer = new $.$stj.STJ.Utf8JsonWriter().$ctor$3(utf8ByteMemoryStream, (() =>
                        {
                            //new $.$stj.STJ.JsonWriterOptions()
                            const $t92 = $.$stj.STJ.JsonWriterOptions;
                            const $i92 = new $t92();
                            $i92.$ctor$2();
                            $i92.Encoder = $.$stew.STEW.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i92;
                        })());
                        $.$mij.MIJ.JsonWebTokenHandler.WriteJwsHeader($.$ref(() => writer, ($v) => writer = $v, $.$stj.STJ.Utf8JsonWriter), tokenDescriptor);
                        /*int*/ let headerLength = $.$cast(utf8ByteMemoryStream.Length, $.$$.S.Int32);
                        /*int*/ let signatureSize = 0;
                        /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                        if (signingCredentials !== null)
                        {
                            signatureSize = $.$mit.MIT$1.SupportedAlgorithms.GetMaxByteCount(signingCredentials.Algorithm);
                        }
                        payloadBytes = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent($.$$.ST.Encoding.UTF8.GetMaxByteCount(payload.length));
                        /*int*/ let payloadSize = $.$$.ST.Encoding.UTF8.GetBytes$6(payload, 0, payload.length, payloadBytes, 0);
                        /*int*/ let encodedBufferSize = (($.trunc((((((((headerLength + payloadSize) | 0) + 4) | 0) + signatureSize) | 0)) / 3) * 4) | 0);
                        encodedChars = $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Rent(((encodedBufferSize + 4) | 0));
                        /*int*/ let sizeOfEncodedHeader = $.$mit.MIT$1.Base64UrlEncoder.Encode$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, utf8ByteMemoryStream.GetBuffer(), 0, headerLength)), $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(encodedChars));
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, sizeOfEncodedHeader);
                        /*int*/ let sizeOfEncodedPayload = $.$mit.MIT$1.Base64UrlEncoder.Encode$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, payloadBytes, 0, payloadSize)), $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Char, encodedChars, ((sizeOfEncodedHeader + 1) | 0)));
                        asciiBytes = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent($.$$.ST.Encoding.ASCII.GetMaxByteCount(encodedBufferSize));
                        /*int*/ let sizeOfEncodedHeaderAndPayloadAsciiBytes = $.$$.ST.Encoding.ASCII.GetBytes(encodedChars, 0, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0), asciiBytes, 0);
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0));
                        /*int*/ let sizeOfEncodedSignature = 0;
                        if (signingCredentials !== null)
                        {
                            /*int*/ let signatureLength;
                            signatureBytes = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(signatureSize);
                            /*bool*/ let signatureSucceeded = $.$mij.MIJ.JwtTokenUtilities.CreateSignature($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, asciiBytes, 0, sizeOfEncodedHeaderAndPayloadAsciiBytes)), $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(signatureBytes), signingCredentials, $.$ref(() => signatureLength, ($v) => signatureLength = $v, $.$$.S.Int32));
                            sizeOfEncodedSignature = $.$mit.MIT$1.Base64UrlEncoder.Encode$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, signatureBytes, 0, signatureLength)), $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Char, encodedChars, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 2) | 0)));
                        }
                        /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                        if (encryptingCredentials !== null)
                        {
                            return $.$mij.MIJ.JsonWebTokenHandler.EncryptToken$1($.$$.ST.Encoding.UTF8.GetBytes$1(encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)), tokenDescriptor);
                        }
                        else 
                        {
                            return $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Char, encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)).ToString();
                        }
                    }
                    finally
                    {
                        {
                            if (!(encodedChars === null))
                            {
                                $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Return(encodedChars, false);
                            }
                            if (!(signatureBytes === null))
                            {
                                $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(signatureBytes, false);
                            }
                            if (!(asciiBytes === null))
                            {
                                $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(asciiBytes, false);
                            }
                            if (!(payloadBytes === null))
                            {
                                $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(payloadBytes, false);
                            }
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    utf8ByteMemoryStream?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554379391)
            
            //--TRIMMABLE-BOUNDARY-START(592705814655)
            static /*void */ WriteJwsPayload(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ setDefaultTimesOnTokenCreation, /*int*/ tokenLifetimeInMinutes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592705814655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let descriptorClaimsAudienceChecked = false;
                /*bool*/ let audienceSet = false;
                /*bool*/ let descriptorClaimsIssuerChecked = false;
                /*bool*/ let issuerSet = false;
                /*bool*/ let descriptorClaimsExpChecked = false;
                /*bool*/ let expSet = false;
                /*bool*/ let descriptorClaimsIatChecked = false;
                /*bool*/ let iatSet = false;
                /*bool*/ let descriptorClaimsNbfChecked = false;
                /*bool*/ let nbfSet = false;
                writer.$v.WriteStartObject();
                if (tokenDescriptor.Audiences.SCG$ICollection$$$Count > 0)
                {
                    if (!$.$$.S.String.IsNullOrEmpty(tokenDescriptor.Audience))
                    {
                        $.$mit.MITJ.JsonSerializerPrimitives.WriteStrings$1(writer, $.$mij.MIJ.JwtPayloadUtf8Bytes.Aud, tokenDescriptor.Audiences, tokenDescriptor.Audience);
                    }
                    else 
                    {
                        $.$mit.MITJ.JsonSerializerPrimitives.WriteStrings$2(writer, $.$mij.MIJ.JwtPayloadUtf8Bytes.Aud, tokenDescriptor.Audiences);
                    }
                    audienceSet = true;
                }
                else if (!$.$$.S.String.IsNullOrEmpty(tokenDescriptor.Audience))
                {
                    writer.$v.WritePropertyName$8($.$mij.MIJ.JwtPayloadUtf8Bytes.Aud);
                    writer.$v.WriteStringValue$5(tokenDescriptor.Audience);
                    audienceSet = true;
                }
                if (!$.$$.S.String.IsNullOrEmpty(tokenDescriptor.Issuer))
                {
                    issuerSet = true;
                    writer.$v.WritePropertyName$8($.$mij.MIJ.JwtPayloadUtf8Bytes.Iss);
                    writer.$v.WriteStringValue$5(tokenDescriptor.Issuer);
                }
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(tokenDescriptor.Expires))
                {
                    expSet = true;
                    writer.$v.WritePropertyName$8($.$mij.MIJ.JwtPayloadUtf8Bytes.Exp);
                    writer.$v.WriteNumberValue$3($.$mit.MIT$1.EpochTime.GetIntDate($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(tokenDescriptor.Expires)));
                }
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(tokenDescriptor.IssuedAt))
                {
                    iatSet = true;
                    writer.$v.WritePropertyName$8($.$mij.MIJ.JwtPayloadUtf8Bytes.Iat);
                    writer.$v.WriteNumberValue$3($.$mit.MIT$1.EpochTime.GetIntDate($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(tokenDescriptor.IssuedAt)));
                }
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(tokenDescriptor.NotBefore))
                {
                    nbfSet = true;
                    writer.$v.WritePropertyName$8($.$mij.MIJ.JwtPayloadUtf8Bytes.Nbf);
                    writer.$v.WriteNumberValue$3($.$mit.MIT$1.EpochTime.GetIntDate($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(tokenDescriptor.NotBefore)));
                }
                /*bool*/ let isActorFound = false;
                /*bool*/ let rawActClaimWritten = false;
                if (tokenDescriptor.Claims !== null && tokenDescriptor.Claims.SCG$ICollection$$$Count > 0)
                {
                    let $en97 = tokenDescriptor.Claims.SCG$IEnumerable$$$GetEnumerator();
                    while ($en97.SC$1$IEnumerator$MoveNext())
                    {
                        let kvp = $en97.SCG$IEnumerator$$$Current;
                        {
                            if ($.$$.S.String.Equals$2.call(kvp.Key, "act"/*ActClaimType*/, 4/*StringComparison.Ordinal*/))
                            {
                                if ($.$is(kvp.Value, $.$ssc.SSC.ClaimsIdentity))
                                {
                                    isActorFound = true;
                                    continue;
                                }
                                rawActClaimWritten = true;
                            }
                            if (!descriptorClaimsAudienceChecked && $.$$.S.String.Equals$2.call(kvp.Key, "aud"/*JwtRegisteredClaimNames.Aud*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsAudienceChecked = true;
                                if (audienceSet)
                                {
                                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        /*string*/ let descriptorMemberName = null;
                                        if (tokenDescriptor.Audiences.SCG$ICollection$$$Count > 0)
                                        {
                                            descriptorMemberName = "Audiences";
                                        }
                                        else if (!$.$$.S.String.IsNullOrEmpty(tokenDescriptor.Audience))
                                        {
                                            descriptorMemberName = "Audience";
                                        }
                                        $.$mil.MIL.LogHelper.LogInformation($.$mil.MIL.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(descriptorMemberName) ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                audienceSet = true;
                            }
                            if (!descriptorClaimsIssuerChecked && $.$$.S.String.Equals$2.call(kvp.Key, "iss"/*JwtRegisteredClaimNames.Iss*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsIssuerChecked = true;
                                if (issuerSet)
                                {
                                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.MIL.LogHelper.LogInformation($.$mil.MIL.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("Issuer") ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                issuerSet = true;
                            }
                            if (!descriptorClaimsExpChecked && $.$$.S.String.Equals$2.call(kvp.Key, "exp"/*JwtRegisteredClaimNames.Exp*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsExpChecked = true;
                                if (expSet)
                                {
                                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.MIL.LogHelper.LogInformation($.$mil.MIL.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                expSet = true;
                            }
                            if (!descriptorClaimsIatChecked && $.$$.S.String.Equals$2.call(kvp.Key, "iat"/*JwtRegisteredClaimNames.Iat*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsIatChecked = true;
                                if (iatSet)
                                {
                                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.MIL.LogHelper.LogInformation($.$mil.MIL.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                iatSet = true;
                            }
                            if (!descriptorClaimsNbfChecked && $.$$.S.String.Equals$2.call(kvp.Key, "nbf"/*JwtRegisteredClaimNames.Nbf*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsNbfChecked = true;
                                if (nbfSet)
                                {
                                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.MIL.LogHelper.LogInformation($.$mil.MIL.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                nbfSet = true;
                            }
                            $.$mit.MITJ.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                        }
                    }
                }
                if (isActorFound || (!((tokenDescriptor.Subject?.Actor ?? null) === null) && !rawActClaimWritten))
                {
                    $.$mij.MIJ.JsonWebTokenHandler.WriteActor(writer, tokenDescriptor);
                }
                $.$mij.MIJ.JsonWebTokenHandler.AddSubjectClaims(writer, tokenDescriptor, audienceSet, issuerSet, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => expSet, ($v) => expSet = $v, null, true), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => iatSet, ($v) => iatSet = $v, null, true), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => nbfSet, ($v) => nbfSet = $v, null, true));
                if (setDefaultTimesOnTokenCreation && !(expSet && iatSet && nbfSet))
                {
                    /*DateTime*/ let now = $.$$.S.DateTime.UtcNow;
                    if (!expSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.MIJ.JwtPayloadUtf8Bytes.Exp);
                        writer.$v.WriteNumberValue$3($.$mit.MIT$1.EpochTime.GetIntDate($.$$.S.DateTime.op_Addition(now, $.$$.S.TimeSpan.FromMinutes$2(BigInt(tokenLifetimeInMinutes)))));
                    }
                    if (!iatSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.MIJ.JwtPayloadUtf8Bytes.Iat);
                        writer.$v.WriteNumberValue$3($.$mit.MIT$1.EpochTime.GetIntDate(now));
                    }
                    if (!nbfSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.MIJ.JwtPayloadUtf8Bytes.Nbf);
                        writer.$v.WriteNumberValue$3($.$mit.MIT$1.EpochTime.GetIntDate(now));
                    }
                }
                writer.$v.WriteEndObject();
                writer.$v.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(592705814655)
            
            //--TRIMMABLE-BOUNDARY-START(34360066175)
            static /*void */ AddSubjectClaims(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ audienceSet, /*bool*/ issuerSet, /*ref bool*/ expSet, /*ref bool*/ iatSet, /*ref bool*/ nbfSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenDescriptor.Subject === null)
                {
                    return;
                }
                /*bool*/ let expReset = false;
                /*bool*/ let iatReset = false;
                /*bool*/ let nbfReset = false;
                /*var*/ let payload = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                /*bool*/ let checkClaims = tokenDescriptor.Claims !== null && tokenDescriptor.Claims.SCG$ICollection$$$Count > 0;
                /*bool*/ let subjectHasActor = !(tokenDescriptor.Subject.Actor === null);
                let $en104 = tokenDescriptor.Subject.Claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en104.SC$1$IEnumerator$MoveNext())
                {
                    let claim = $en104.SCG$IEnumerator$$$Current;
                    {
                        /*object*/ let existingValue;
                        if (claim === null)
                        {
                            continue;
                        }
                        if (subjectHasActor && $.$$.S.String.Equals$2.call(claim.Type, "act"/*ActClaimType*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if (checkClaims && tokenDescriptor.Claims.SCG$IDictionary$$$$ContainsKey(claim.Type))
                        {
                            continue;
                        }
                        if (audienceSet && $.$$.S.String.Equals$2.call(claim.Type, "aud"/*JwtRegisteredClaimNames.Aud*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if (issuerSet && $.$$.S.String.Equals$2.call(claim.Type, "iss"/*JwtRegisteredClaimNames.Iss*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if ($.$$.S.String.Equals$2.call(claim.Type, "exp"/*JwtRegisteredClaimNames.Exp*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (expSet.$v)
                            {
                                continue;
                            }
                            expReset = true;
                        }
                        if ($.$$.S.String.Equals$2.call(claim.Type, "iat"/*JwtRegisteredClaimNames.Iat*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (iatSet.$v)
                            {
                                continue;
                            }
                            iatReset = true;
                        }
                        if ($.$$.S.String.Equals$2.call(claim.Type, "nbf"/*JwtRegisteredClaimNames.Nbf*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (nbfSet.$v)
                            {
                                continue;
                            }
                            nbfReset = true;
                        }
                        /*object*/ let jsonClaimValue = $.$$.S.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.MIT$1.TokenUtilities.GetClaimValueUsingValueType(claim);
                        if (payload.TryGetValue(claim.Type, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.S.Object)))
                        {
                            let existingList;
                            if ($.$is(existingValue, $.$$.SCG.List$$($.$$.S.Object), { set $v($v){ existingList = $v; } }))
                            {
                                existingList.Add(jsonClaimValue);
                            }
                            else 
                            {
                                payload.set_Item(claim.Type, (() =>
                                {
                                    //new $.$$.SCG.List$$($.$$.S.Object)()
                                    const $t106 = $.$$.SCG.List$$($.$$.S.Object);
                                    const $i106 = new $t106();
                                    $i106.$ctor$1();
                                    $i106.Add(existingValue);
                                    $i106.Add(jsonClaimValue);
                                    return $i106;
                                })());
                            }
                        }
                        else 
                        {
                            payload.set_Item(claim.Type, jsonClaimValue);
                        }
                    }
                }
                let $en107 = payload.GetEnumerator();
                while ($en107.MoveNext())
                {
                    let kvp = $en107.Current;
                    {
                        $.$mit.MITJ.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                    }
                }
                expSet.$v = $.$$.S.Boolean.op_BitwiseOr$2(expSet.$v, expReset);
                iatSet.$v = $.$$.S.Boolean.op_BitwiseOr$2(iatSet.$v, iatReset);
                nbfSet.$v = $.$$.S.Boolean.op_BitwiseOr$2(nbfSet.$v, nbfReset);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066175)
            
            //--TRIMMABLE-BOUNDARY-START(588410847359)
            static /*void */ WriteJwsHeader$1(/*ref Utf8JsonWriter*/ writer, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ jweHeaderClaims, /*IDictionary<string, object>*/ jwsHeaderClaims, /*string*/ tokenType, /*bool*/ includeKeyIdInHeader)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(588410847359);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.MIJ.JsonWebTokenHandler.WriteJwsHeader(writer, (() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t110 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i110 = new $t110();
                        $i110.$ctor$1();
                        $i110.SigningCredentials = signingCredentials;
                        $i110.EncryptingCredentials = encryptingCredentials;
                        $i110.AdditionalHeaderClaims = jweHeaderClaims;
                        $i110.AdditionalInnerHeaderClaims = jwsHeaderClaims;
                        $i110.TokenType = tokenType;
                        $i110.IncludeKeyIdInHeader = includeKeyIdInHeader;
                        return $i110;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(588410847359)
            
            //--TRIMMABLE-BOUNDARY-START(584115880063)
            static /*void */ WriteJwsHeader(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584115880063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IDictionary<string, object>*/ let jweHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                if ($.$$.S.Int32.op_GreaterThan((jweHeaderClaims?.SCG$ICollection$$$Count ?? null), 0) && $.$sl.SL.Enumerable.Any$1($.$$.S.String, $.$sl.SL.Enumerable.Intersect($.$$.S.String, jweHeaderClaims.SCG$IDictionary$$$$Keys, $.$mij.MIJ.JwtTokenUtilities.DefaultHeaderParameters, $.$$.S.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("jweHeaderClaims"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.String.Join$5(", ", $.$mij.MIJ.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                /*IDictionary<string, object>*/ let jwsHeaderClaims = tokenDescriptor.AdditionalInnerHeaderClaims;
                if ($.$$.S.Int32.op_GreaterThan((jwsHeaderClaims?.SCG$ICollection$$$Count ?? null), 0) && $.$sl.SL.Enumerable.Any$1($.$$.S.String, $.$sl.SL.Enumerable.Intersect($.$$.S.String, jwsHeaderClaims.SCG$IDictionary$$$$Keys, $.$mij.MIJ.JwtTokenUtilities.DefaultHeaderParameters, $.$$.S.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("jwsHeaderClaims"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.String.Join$5(", ", $.$mij.MIJ.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                /*bool*/ let addJweHeaderClaims = tokenDescriptor.EncryptingCredentials === null && $.$$.S.Int32.op_GreaterThan((jweHeaderClaims?.SCG$ICollection$$$Count ?? null), 0);
                /*bool*/ let addJwsHeaderClaims = $.$$.S.Int32.op_GreaterThan((jwsHeaderClaims?.SCG$ICollection$$$Count ?? null), 0);
                /*bool*/ let typeWritten = false;
                writer.$v.WriteStartObject();
                /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                if (signingCredentials === null)
                {
                    writer.$v.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Alg, "none"/*SecurityAlgorithms.None*/);
                }
                else 
                {
                    writer.$v.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Alg, signingCredentials.Algorithm);
                    if (tokenDescriptor.IncludeKeyIdInHeader)
                    {
                        if (signingCredentials.Key.KeyId !== null)
                        {
                            writer.$v.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Kid, signingCredentials.Key.KeyId);
                        }
                        let x509SecurityKey;
                        if ($.$is(signingCredentials.Key, $.$mit.MIT$1.X509SecurityKey, { set $v($v){ x509SecurityKey = $v; } }))
                        {
                            writer.$v.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.X5t, x509SecurityKey.X5t);
                        }
                    }
                }
                if (addJweHeaderClaims)
                {
                    let $en111 = jweHeaderClaims.SCG$IEnumerable$$$GetEnumerator();
                    while ($en111.SC$1$IEnumerator$MoveNext())
                    {
                        let kvp = $en111.SCG$IEnumerator$$$Current;
                        {
                            if (addJwsHeaderClaims && jwsHeaderClaims.SCG$IDictionary$$$$ContainsKey(kvp.Key))
                            {
                                continue;
                            }
                            $.$mit.MITJ.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                            if (!typeWritten && $.$$.S.String.Equals$2.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                            {
                                typeWritten = true;
                            }
                        }
                    }
                }
                if (addJwsHeaderClaims)
                {
                    let $en113 = jwsHeaderClaims.SCG$IEnumerable$$$GetEnumerator();
                    while ($en113.SC$1$IEnumerator$MoveNext())
                    {
                        let kvp = $en113.SCG$IEnumerator$$$Current;
                        {
                            $.$mit.MITJ.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                            if (!typeWritten && $.$$.S.String.Equals$2.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                            {
                                typeWritten = true;
                            }
                        }
                    }
                }
                if (!typeWritten)
                {
                    /*string*/ let tokenType = tokenDescriptor.TokenType;
                    writer.$v.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Typ, $.$$.S.String.IsNullOrEmpty(tokenType) ? "JWT"/*JwtConstants.HeaderType*/ : tokenType);
                }
                writer.$v.WriteEndObject();
                writer.$v.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(584115880063)
            
            //--TRIMMABLE-BOUNDARY-START(575525945471)
            static /*byte[] */ WriteJweHeader(/*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*string*/ tokenType, /*IDictionary<string, object>*/ jweHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(575525945471);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.MIJ.JsonWebTokenHandler.WriteJweHeader$1((() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t115 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i115 = new $t115();
                        $i115.$ctor$1();
                        $i115.EncryptingCredentials = encryptingCredentials;
                        $i115.CompressionAlgorithm = compressionAlgorithm;
                        $i115.TokenType = tokenType;
                        $i115.AdditionalHeaderClaims = jweHeaderClaims;
                        $i115.IncludeKeyIdInHeader = includeKeyIdInHeader;
                        return $i115;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(575525945471)
            
            //--TRIMMABLE-BOUNDARY-START(579820912767)
            static /*byte[] */ WriteJweHeader$1(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579820912767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.SI.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.STJ.Utf8JsonWriter().$ctor$3(memoryStream, (() =>
                        {
                            //new $.$stj.STJ.JsonWriterOptions()
                            const $t116 = $.$stj.STJ.JsonWriterOptions;
                            const $i116 = new $t116();
                            $i116.$ctor$2();
                            $i116.Encoder = $.$stew.STEW.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i116;
                        })());
                        writer.WriteStartObject();
                        /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                        writer.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Alg, encryptingCredentials.Alg);
                        writer.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Enc, encryptingCredentials.Enc);
                        /*bool*/ let includeKeyIdInHeader = tokenDescriptor.IncludeKeyIdInHeader;
                        if ($.$mit.MIT$1.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                        {
                            if (includeKeyIdInHeader && encryptingCredentials.KeyExchangePublicKey.KeyId !== null)
                            {
                                writer.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Kid, encryptingCredentials.KeyExchangePublicKey.KeyId);
                            }
                            if ($.$mit.MIT$1.SupportedAlgorithms.EcdsaWrapAlgorithms.SCG$ICollection$$$Contains(encryptingCredentials.Alg))
                            {
                                writer.WritePropertyName$8($.$mij.MIJ.JwtHeaderUtf8Bytes.Epk);
                                /*string*/ let publicJwk = $.$mit.MIT$1.JsonWebKeyConverter.ConvertFromSecurityKey(encryptingCredentials.Key).RepresentAsAsymmetricPublicJwk();
                                writer.WriteRawValue$3(publicJwk, false);
                            }
                        }
                        else 
                        {
                            if (includeKeyIdInHeader && encryptingCredentials.Key.KeyId !== null)
                            {
                                writer.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Kid, encryptingCredentials.Key.KeyId);
                            }
                        }
                        /*string*/ let compressionAlgorithm = tokenDescriptor.CompressionAlgorithm;
                        if (!$.$$.S.String.IsNullOrEmpty(compressionAlgorithm))
                        {
                            writer.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Zip, compressionAlgorithm);
                        }
                        /*bool*/ let typeWritten = false;
                        /*bool*/ let ctyWritten = !encryptingCredentials.SetDefaultCtyClaim;
                        /*IDictionary<string, object>*/ let jweHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                        if (jweHeaderClaims !== null && jweHeaderClaims.SCG$ICollection$$$Count > 0)
                        {
                            let $en117 = jweHeaderClaims.SCG$IEnumerable$$$GetEnumerator();
                            while ($en117.SC$1$IEnumerator$MoveNext())
                            {
                                let kvp = $en117.SCG$IEnumerator$$$Current;
                                {
                                    $.$mit.MITJ.JsonSerializerPrimitives.WriteObject($.$ref(() => writer, ($v) => writer = $v, $.$stj.STJ.Utf8JsonWriter), kvp.Key, kvp.Value);
                                    if (!typeWritten && $.$$.S.String.Equals$2.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                                    {
                                        typeWritten = true;
                                    }
                                    else if (!ctyWritten && $.$$.S.String.Equals$2.call(kvp.Key, "cty"/*JwtHeaderParameterNames.Cty*/, 4/*StringComparison.Ordinal*/))
                                    {
                                        ctyWritten = true;
                                    }
                                }
                            }
                        }
                        if (!typeWritten)
                        {
                            /*string*/ let tokenType = tokenDescriptor.TokenType;
                            writer.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Typ, $.$$.S.String.IsNullOrEmpty(tokenType) ? "JWT"/*JwtConstants.HeaderType*/ : tokenType);
                        }
                        if (!ctyWritten)
                        {
                            writer.WriteString$5($.$mij.MIJ.JwtHeaderUtf8Bytes.Cty, "JWT"/*JwtConstants.HeaderType*/);
                        }
                        writer.WriteEndObject();
                        writer.Flush();
                        return memoryStream.ToArray();
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(579820912767)
            
            //--TRIMMABLE-BOUNDARY-START(554051108991)
            static /*void */ WriteActor(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051108991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ClaimsIdentity*/ let actor = $.$mij.MIJ.JsonWebTokenHandler.GetActorIdentity(tokenDescriptor);
                if (actor === null)
                {
                    return;
                }
                /*int*/ let remainingActorLevels = $.$mij.MIJ.JsonWebTokenHandler.MaxActorChainLength;
                writer.$v.WritePropertyName$11("act"/*ActClaimType*/);
                $.$mij.MIJ.JsonWebTokenHandler.WriteActorValue(writer, actor, remainingActorLevels);
            }
            //--TRIMMABLE-BOUNDARY-END(554051108991)
            
            //--TRIMMABLE-BOUNDARY-START(566936010879)
            static /*void */ WriteActorValue(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ actor, /*int*/ remainingActorLevels)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566936010879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (remainingActorLevels > 0)
                {
                    $.$mij.MIJ.JsonWebTokenHandler.WriteActorObject(writer, actor, remainingActorLevels);
                }
                else 
                {
                    writer.$v.WriteStringValue$5($.$mij.MIJ.JsonWebTokenHandler.WriteActorAsJsonString(actor));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(566936010879)
            
            //--TRIMMABLE-BOUNDARY-START(562641043583)
            static /*void */ WriteActorObject(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ actor, /*int*/ remainingActorLevels)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562641043583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.$v.WriteStartObject();
                $.$mij.MIJ.JsonWebTokenHandler.WriteIdentityClaims(writer, actor);
                if (!(actor.Actor === null))
                {
                    writer.$v.WritePropertyName$11("act"/*ActClaimType*/);
                    $.$mij.MIJ.JsonWebTokenHandler.WriteActorValue(writer, actor.Actor, ((remainingActorLevels - 1) | 0));
                }
                writer.$v.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(562641043583)
            
            //--TRIMMABLE-BOUNDARY-START(571230978175)
            static /*void */ WriteIdentityClaims(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571230978175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let payload = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                let $en123 = identity.Claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en123.SC$1$IEnumerator$MoveNext())
                {
                    let claim = $en123.SCG$IEnumerator$$$Current;
                    {
                        /*object*/ let existingValue;
                        if (claim === null)
                        {
                            continue;
                        }
                        /*object*/ let jsonClaimValue = $.$$.S.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.MIT$1.TokenUtilities.GetClaimValueUsingValueType(claim);
                        if (payload.TryGetValue(claim.Type, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.S.Object)))
                        {
                            let existingList;
                            if ($.$is(existingValue, $.$$.SCG.List$$($.$$.S.Object), { set $v($v){ existingList = $v; } }))
                            {
                                existingList.Add(jsonClaimValue);
                            }
                            else 
                            {
                                payload.set_Item(claim.Type, (() =>
                                {
                                    //new $.$$.SCG.List$$($.$$.S.Object)()
                                    const $t125 = $.$$.SCG.List$$($.$$.S.Object);
                                    const $i125 = new $t125();
                                    $i125.$ctor$1();
                                    $i125.Add(existingValue);
                                    $i125.Add(jsonClaimValue);
                                    return $i125;
                                })());
                            }
                        }
                        else 
                        {
                            payload.set_Item(claim.Type, jsonClaimValue);
                        }
                    }
                }
                let $en126 = payload.GetEnumerator();
                while ($en126.MoveNext())
                {
                    let kvp = $en126.Current;
                    {
                        $.$mit.MITJ.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(571230978175)
            
            //--TRIMMABLE-BOUNDARY-START(279173202047)
            static /*ClaimsIdentity */ GetActorIdentity(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                /*object*/ let actorValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173202047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let actorIdentity;
                if ((tokenDescriptor.Claims?.SCG$IDictionary$$$$TryGetValue("act"/*ActClaimType*/, $.$ref(() => actorValue, ($v) => actorValue = $v, $.$$.S.Object)) ?? null) === true && $.$is(actorValue, $.$ssc.SSC.ClaimsIdentity, { set $v($v){ actorIdentity = $v; } }))
                {
                    return actorIdentity;
                }
                return tokenDescriptor.Subject?.Actor ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(279173202047)
            
            //--TRIMMABLE-BOUNDARY-START(558346076287)
            static /*string */ WriteActorAsJsonString(/*ClaimsIdentity*/ actor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558346076287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let stream = null;
                try
                {
                    stream = new $.$$.SI.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let actorWriter = new $.$stj.STJ.Utf8JsonWriter().$ctor$3(stream, new $.$stj.STJ.JsonWriterOptions());
                    $.$mij.MIJ.JsonWebTokenHandler.WriteActorObject($.$ref(() => actorWriter, ($v) => actorWriter = $v, $.$stj.STJ.Utf8JsonWriter), actor, 2147483647/*int.MaxValue*/);
                    actorWriter.Flush();
                    return $.$$.ST.Encoding.UTF8.GetString(stream.GetBuffer(), 0, $.$cast(stream.Length, $.$$.S.Int32));
                }
                finally
                {
                    stream?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(558346076287)
            
            //--TRIMMABLE-BOUNDARY-START(51539935359)
            static /*byte[] */ CompressToken(/*byte[]*/ utf8Bytes, /*string*/ compressionAlgorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                if (!$.$mit.MIT$1.CompressionProviderFactory.Default.IsSupportedAlgorithm(compressionAlgorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.NotSupportedException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10682: Compression algorithm '{0}' is not supported."/*TokenLogMessages.IDX10682*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null))));
                }
                /*var*/ let compressionProvider = $.$mit.MIT$1.CompressionProviderFactory.Default.CreateCompressionProvider$1(compressionAlgorithm);
                return $.$firstOf(compressionProvider.MIT$1$ICompressionProvider$Compress(utf8Bytes), () => { throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10680: Failed to compress using algorithm '{0}'."/*TokenLogMessages.IDX10680*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null)))) });
            }
            //--TRIMMABLE-BOUNDARY-END(51539935359)
            
            //--TRIMMABLE-BOUNDARY-START(219043659903)
            /*string */ EncryptToken$5(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043659903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                return $.$mij.MIJ.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t130 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i130 = new $t130();
                    $i130.$ctor$1();
                    $i130.EncryptingCredentials = encryptingCredentials;
                    return $i130;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(219043659903)
            
            //--TRIMMABLE-BOUNDARY-START(206158758015)
            /*string */ EncryptToken$2(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158758015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if (additionalHeaderClaims === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalHeaderClaims");
                }
                return $.$mij.MIJ.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t131 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i131 = new $t131();
                    $i131.$ctor$1();
                    $i131.EncryptingCredentials = encryptingCredentials;
                    $i131.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i131;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(206158758015)
            
            //--TRIMMABLE-BOUNDARY-START(214748692607)
            /*string */ EncryptToken$4(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ algorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748692607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if ($.$$.S.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("algorithm");
                }
                return $.$mij.MIJ.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t132 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i132 = new $t132();
                    $i132.$ctor$1();
                    $i132.EncryptingCredentials = encryptingCredentials;
                    $i132.CompressionAlgorithm = algorithm;
                    return $i132;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(214748692607)
            
            //--TRIMMABLE-BOUNDARY-START(210453725311)
            /*string */ EncryptToken$3(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ algorithm, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453725311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if ($.$$.S.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("algorithm");
                }
                if (additionalHeaderClaims === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("additionalHeaderClaims");
                }
                return $.$mij.MIJ.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.MIT$1.SecurityTokenDescriptor()
                    const $t133 = $.$mit.MIT$1.SecurityTokenDescriptor;
                    const $i133 = new $t133();
                    $i133.$ctor$1();
                    $i133.EncryptingCredentials = encryptingCredentials;
                    $i133.CompressionAlgorithm = algorithm;
                    $i133.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i133;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(210453725311)
            
            //--TRIMMABLE-BOUNDARY-START(223338627199)
            static /*string */ EncryptTokenPrivate(/*string*/ innerJwt, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(223338627199);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.MIJ.JsonWebTokenHandler.EncryptToken$1($.$$.ST.Encoding.UTF8.GetBytes$8(innerJwt), tokenDescriptor);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338627199)
            
            //--TRIMMABLE-BOUNDARY-START(197568823423)
            static /*string */ EncryptToken(/*byte[]*/ innerTokenUtf8Bytes, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*string*/ tokenType, /*bool*/ includeKeyIdInHeader)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197568823423);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.MIJ.JsonWebTokenHandler.EncryptToken$1(innerTokenUtf8Bytes, (() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t134 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i134 = new $t134();
                        $i134.$ctor$1();
                        $i134.EncryptingCredentials = encryptingCredentials;
                        $i134.CompressionAlgorithm = compressionAlgorithm;
                        $i134.AdditionalHeaderClaims = additionalHeaderClaims;
                        $i134.TokenType = tokenType;
                        $i134.IncludeKeyIdInHeader = includeKeyIdInHeader;
                        return $i134;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568823423)
            
            //--TRIMMABLE-BOUNDARY-START(201863790719)
            static /*string */ EncryptToken$1(/*byte[]*/ innerTokenUtf8Bytes, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                /*byte[]*/ let wrappedKey;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863790719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                /*CryptoProviderFactory*/ let cryptoProviderFactory = encryptingCredentials.CryptoProviderFactory ?? encryptingCredentials.Key.CryptoProviderFactory;
                if (cryptoProviderFactory === null)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14("IDX10620: Unable to obtain a CryptoProviderFactory, both EncryptingCredentials.CryptoProviderFactory and EncryptingCredentials.Key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10620*/));
                }
                /*IDictionary<string, object>*/ let additionalHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                /*SecurityKey*/ let securityKey = $.$mij.MIJ.JwtTokenUtilities.GetSecurityKey(encryptingCredentials, cryptoProviderFactory, additionalHeaderClaims, $.$ref(() => wrappedKey, ($v) => wrappedKey = $v, $.$typeArray($.$$.S.Byte)));
                let encryptionProvider = null;
                try
                {
                    encryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(securityKey, encryptingCredentials.Enc);
                    if (encryptionProvider === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14("IDX14103: Failed to create the token encryption provider."/*LogMessages.IDX14103*/));
                    }
                    /*byte[]*/ let jweHeader = $.$mij.MIJ.JsonWebTokenHandler.WriteJweHeader$1(tokenDescriptor);
                    /*byte[]*/ let plainText;
                    /*string*/ let compressionAlgorithm = tokenDescriptor.CompressionAlgorithm;
                    if (!$.$$.S.String.IsNullOrEmpty(compressionAlgorithm))
                    {
                        try
                        {
                            plainText = $.$mij.MIJ.JsonWebTokenHandler.CompressToken(innerTokenUtf8Bytes, compressionAlgorithm);
                        }
                        catch(ex)
                        {
                            throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenCompressionFailedException().$ctor$13($.$mil.MIL.LogHelper.FormatInvariant("IDX10680: Failed to compress using algorithm '{0}'."/*TokenLogMessages.IDX10680*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null)), ex));
                        }
                    }
                    else 
                    {
                        plainText = innerTokenUtf8Bytes;
                    }
                    try
                    {
                        /*string*/ let rawHeader = $.$mit.MIT$1.Base64UrlEncoder.Encode$1(jweHeader);
                        /*var*/ let encryptionResult = encryptionProvider.Encrypt$1(plainText, $.$$.ST.Encoding.ASCII.GetBytes$8(rawHeader));
                        return $.$$.S.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg) ? $.$$.S.String.Join$8(".", $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1([ rawHeader, $.$$.S.String.Empty, $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag) ])) : $.$$.S.String.Join$8(".", $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1([ rawHeader, $.$mit.MIT$1.Base64UrlEncoder.Encode$1(wrappedKey), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag) ]));
                    }
                    catch(ex)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$13($.$mil.MIL.LogHelper.FormatInvariant("IDX10616: Encryption failed. EncryptionProvider failed for: Algorithm: '{0}', SecurityKey: '{1}'. See inner exception."/*TokenLogMessages.IDX10616*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null)), ex));
                    }
                }
                finally
                {
                    encryptionProvider?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201863790719)
            
            //--TRIMMABLE-BOUNDARY-START(292058103935)
            /*IEnumerable<SecurityKey> */ GetContentEncryptionKeys$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058103935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (validationParameters.TokenDecryptionKeyResolver !== null)
                {
                    keys = validationParameters.TokenDecryptionKeyResolver.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey$1(jwtToken.EncodedToken, jwtToken, validationParameters);
                    if (key !== null)
                    {
                        if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                        {
                            $.$mil.MIL.LogHelper.LogInformation("IDX10904: Token decryption key : '{0}' found in TokenValidationParameters."/*TokenLogMessages.IDX10904*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                        }
                    }
                    else if (configuration !== null)
                    {
                        key = $.$mij.MIJ.JsonWebTokenHandler.ResolveTokenDecryptionKeyFromConfig(jwtToken, configuration);
                        if (key !== null && $.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                        {
                            $.$mil.MIL.LogHelper.LogInformation("IDX10905: Token decryption key : '{0}' found in Configuration/Metadata."/*TokenLogMessages.IDX10905*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                        }
                    }
                    if (key !== null)
                    {
                        keys = $.$$.SRC.RuntimeHelpers.CreateArray($.$mit.MIT$1.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (validationParameters.TryAllDecryptionKeys && $.$mit.MIT$1.CollectionUtilities.IsNullOrEmpty($.$mit.MIT$1.SecurityKey, keys))
                {
                    keys = $.$mij.MIJ.JwtTokenUtilities.GetAllDecryptionKeys(validationParameters);
                    if (configuration !== null)
                    {
                        keys = keys === null ? configuration.TokenDecryptionKeys : $.$sl.SL.Enumerable.Concat($.$mit.MIT$1.SecurityKey, keys, configuration.TokenDecryptionKeys);
                    }
                }
                if ($.$$.S.String.Equals$2.call(jwtToken.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/, 4/*StringComparison.Ordinal*/) || $.$$.S.String.Equals$2.call(jwtToken.Alg, "ECDH-ES"/*SecurityAlgorithms.EcdhEs*/, 4/*StringComparison.Ordinal*/))
                {
                    return keys;
                }
                /*var*/ let unwrappedKeys = new ($.$$.SCG.List$$($.$mit.MIT$1.SecurityKey))().$ctor$1();
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                if (keys !== null)
                {
                    let $en136 = keys.SCG$IEnumerable$$$GetEnumerator();
                    while ($en136.SC$1$IEnumerator$MoveNext())
                    {
                        let key = $en136.SCG$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$mit.MIT$1.SupportedAlgorithms.EcdsaWrapAlgorithms.SCG$ICollection$$$Contains(jwtToken.Alg))
                                {
                                    /*string*/ let apu;
                                    /*string*/ let apv;
                                    /*ECDsaSecurityKey*/ let publicKey;
                                    if ($.$mit.MIT$1.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                                    {
                                        /*string*/ let epk;
                                        jwtToken.TryGetHeaderValue($.$$.S.String, "epk"/*JwtHeaderParameterNames.Epk*/, $.$ref(() => epk, ($v) => epk = $v, $.$$.S.String));
                                        publicKey = new $.$mit.MIT$1.ECDsaSecurityKey().$ctor$5(new $.$mit.MIT$1.JsonWebKey().$ctor$4(epk), false);
                                    }
                                    else 
                                    {
                                        publicKey = $.$as(validationParameters.TokenDecryptionKey, $.$mit.MIT$1.ECDsaSecurityKey);
                                    }
                                    /*var*/ let ecdhKeyExchangeProvider = new $.$mit.MIT$1.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.MIT$1.ECDsaSecurityKey), publicKey, jwtToken.Alg, jwtToken.Enc);
                                    jwtToken.TryGetHeaderValue($.$$.S.String, "apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => apu, ($v) => apu = $v, $.$$.S.String));
                                    jwtToken.TryGetHeaderValue($.$$.S.String, "apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => apv, ($v) => apv = $v, $.$$.S.String));
                                    /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                    /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                    /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jwtToken.EncryptedKey));
                                    unwrappedKeys.Add(new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4(unwrappedKey));
                                }
                                else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Alg, key))
                                {
                                    /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Alg);
                                    /*var*/ let unwrappedKey = kwp.UnwrapKey(jwtToken.EncryptedKeyBytes);
                                    unwrappedKeys.Add(new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4(unwrappedKey));
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(ex.ToString());
                            }
                            (keysAttempted ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(key.KeyId);
                        }
                    }
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings === null)
                {
                    return unwrappedKeys;
                }
                else 
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenKeyWrapException().$ctor$16($.$mil.MIL.LogHelper.FormatInvariant("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.MIL.LogHelper.MarkAsNonPII(exceptionStrings ?? ""), jwtToken ], null, null))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(292058103935)
            
            //--TRIMMABLE-BOUNDARY-START(25770131583)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25770131583)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590262399)
                this._mapInboundClaims = $.$mij.MIJ.JsonWebTokenHandler.DefaultMapInboundClaims;
                //--TRIMMABLE-BOUNDARY-END(8590262399)
                
                //--TRIMMABLE-BOUNDARY-START(438086991999)
                this.TelemetryClient = new $.$mit.MIT.TelemetryClient().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(438086991999)
                
            }
            //--TRIMMABLE-BOUNDARY-START(21475164287)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229695)
                    this._namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties";
                    //--TRIMMABLE-BOUNDARY-END(12885229695)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180196991)
                    this._shortClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/ShortTypeName";
                    //--TRIMMABLE-BOUNDARY-END(17180196991)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978888831)
                    this.DefaultInboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$mij.MIJ.ClaimTypeMapping.InboundClaimTypeMap);
                    //--TRIMMABLE-BOUNDARY-END(188978888831)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655033471)
                    this.Base64UrlEncodedUnsignedJWSHeader = "eyJhbGciOiJub25lIn0";
                    //--TRIMMABLE-BOUNDARY-END(38655033471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842351743)
                    this.s_emptyTokenDescriptor = new $.$mit.MIT$1.SecurityTokenDescriptor().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(390842351743)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065098879)
                    this.ActClaimType = "act";
                    //--TRIMMABLE-BOUNDARY-END(30065098879)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475164287)
            
            static $h = 327807;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mit.MIT$1.TokenHandler; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(442381959295),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878234751,
        "f": 50331649
      },
      "n": "TokenType",
      "d": 327807,
      "h": 442381959295,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(442381959295),
//--TRIMMABLE-BOUNDARY-START(433792024703),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288300159,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429497057407,
        "f": 83886113
      },
      "n": "ShortClaimTypeProperty",
      "d": 327807,
      "h": 433792024703,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(433792024703),
//--TRIMMABLE-BOUNDARY-START(317827907711),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108430975,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 412317188223,
        "f": 83886081
      },
      "n": "MapInboundClaims",
      "d": 327807,
      "h": 317827907711,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317827907711),
//--TRIMMABLE-BOUNDARY-START(309237973119),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518496383,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 403727253631,
        "f": 83886081
      },
      "n": "InboundClaimTypeMap",
      "d": 327807,
      "h": 309237973119,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309237973119),
//--TRIMMABLE-BOUNDARY-START(47244968063),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928561791,
        "f": 50331777
      },
      "n": "CanValidateToken",
      "d": 327807,
      "h": 47244968063,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47244968063),
//--TRIMMABLE-BOUNDARY-START(322122875007),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698365567,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 420907122815,
        "f": 83886113
      },
      "n": "MaxActorChainLength",
      "d": 327807,
      "h": 322122875007,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(322122875007)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(356482613375),
    {
      "r": $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityToken, $.$mit.MITE.ValidationError).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "ReadToken",
      "o": "@$1",
      "d": 327807,
      "h": 356482613375,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(356482613375),
//--TRIMMABLE-BOUNDARY-START(60129869951),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        }
      ],
      "n": "CreateClaimsIdentity",
      "o": "@$1",
      "d": 327807,
      "h": 60129869951,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(60129869951),
//--TRIMMABLE-BOUNDARY-START(55834902655),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentity",
      "d": 327807,
      "h": 55834902655,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(55834902655),
//--TRIMMABLE-BOUNDARY-START(73014771839),
    {
      "r": 262213,
      "p": [
        {
          "n": "securityToken",
          "p": 13762686
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityInternal",
      "d": 327807,
      "h": 73014771839,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(73014771839),
//--TRIMMABLE-BOUNDARY-START(90194641023),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityWithMapping",
      "d": 327807,
      "h": 90194641023,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90194641023),
//--TRIMMABLE-BOUNDARY-START(81604706431),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityPrivate",
      "d": 327807,
      "h": 81604706431,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604706431),
//--TRIMMABLE-BOUNDARY-START(532576272511),
    {
      "r": $.$$.STT.Task$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "callContext",
          "p": 1835134
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$3",
      "d": 327807,
      "h": 532576272511,
      "f": 16814088
    },
//--TRIMMABLE-BOUNDARY-END(532576272511),
//--TRIMMABLE-BOUNDARY-START(519691370623),
    {
      "r": $.$$.STT.Task$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)).$h,
      "p": [
        {
          "n": "token",
          "p": 13762686
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "callContext",
          "p": 1835134
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateTokenAsync",
      "d": 327807,
      "h": 519691370623,
      "f": 16814088
    },
//--TRIMMABLE-BOUNDARY-END(519691370623),
//--TRIMMABLE-BOUNDARY-START(446676926591),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "callContext",
          "p": 1835134
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateJWEAsync",
      "d": 327807,
      "h": 446676926591,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(446676926591),
//--TRIMMABLE-BOUNDARY-START(459561828479),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MITE.ValidationResult$$$($.$mit.MITE.ValidatedToken, $.$mit.MITE.ValidationError)).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "callContext",
          "p": 1835134
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateJWSAsync",
      "d": 327807,
      "h": 459561828479,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(459561828479),
//--TRIMMABLE-BOUNDARY-START(296353071231),
    {
      "r": $.$$.STT.Task$$($.$mit.MIT$1.BaseConfiguration).$h,
      "p": [
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "GetCurrentConfigurationAsync",
      "d": 327807,
      "h": 296353071231,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(296353071231),
//--TRIMMABLE-BOUNDARY-START(171799019647),
    {
      "r": $.$mit.MITE.ValidationResult$$$($.$$.S.String, $.$mit.MITE.ValidationError).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "DecryptToken",
      "d": 327807,
      "h": 171799019647,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(171799019647),
//--TRIMMABLE-BOUNDARY-START(287763136639),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.SCG.IList$$($.$mit.MIT$1.SecurityKey), $.$mit.MITE.ValidationError).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "GetContentEncryptionKeys",
      "d": 327807,
      "h": 287763136639,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(287763136639),
//--TRIMMABLE-BOUNDARY-START(377957449855),
    {
      "r": 13631614,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "ResolveTokenDecryptionKey",
      "d": 327807,
      "h": 377957449855,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(377957449855),
//--TRIMMABLE-BOUNDARY-START(472446730367),
    {
      "r": $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "ValidateSignature",
      "d": 327807,
      "h": 472446730367,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(472446730367),
//--TRIMMABLE-BOUNDARY-START(498216534143),
    {
      "r": $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "ValidateSignatureUsingAllKeys",
      "d": 327807,
      "h": 498216534143,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(498216534143),
//--TRIMMABLE-BOUNDARY-START(506806468735),
    {
      "r": $.$mit.MITE.ValidationResult$$$($.$mit.MIT$1.SecurityKey, $.$mit.MITE.ValidationError).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 10354814
        },
        {
          "n": "key",
          "p": 13631614
        },
        {
          "n": "callContext",
          "p": 1835134
        }
      ],
      "n": "ValidateSignatureWithKey",
      "d": 327807,
      "h": 506806468735,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(506806468735),
//--TRIMMABLE-BOUNDARY-START(343597711487),
    {
      "r": 65537,
      "p": [
        {
          "n": "failedResult",
          "p": $.$typeNullable($.$mij.MIJ.JsonWebTokenHandler.KeyMatchFailedResult).$h
        },
        {
          "n": "exceptionStrings",
          "p": 167837697
        },
        {
          "n": "keysAttempted",
          "p": 167837697
        }
      ],
      "n": "PopulateFailedResults",
      "d": 327807,
      "h": 343597711487,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(343597711487),
//--TRIMMABLE-BOUNDARY-START(42950000767),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "CanReadToken",
      "d": 327807,
      "h": 42950000767,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42950000767),
//--TRIMMABLE-BOUNDARY-START(300648038527),
    {
      "r": 164364289,
      "p": [
        {
          "n": "securityKey",
          "p": 13631614
        }
      ],
      "n": "GetStringComparisonRuleIf509",
      "d": 327807,
      "h": 300648038527,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(300648038527),
//--TRIMMABLE-BOUNDARY-START(304943005823),
    {
      "r": 164364289,
      "p": [
        {
          "n": "securityKey",
          "p": 13631614
        }
      ],
      "n": "GetStringComparisonRuleIf509OrECDsa",
      "d": 327807,
      "h": 304943005823,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(304943005823),
//--TRIMMABLE-BOUNDARY-START(68719804543),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "CreateClaimsIdentity",
      "o": "@$3",
      "d": 327807,
      "h": 68719804543,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68719804543),
//--TRIMMABLE-BOUNDARY-START(64424837247),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentity",
      "o": "@$2",
      "d": 327807,
      "h": 64424837247,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(64424837247),
//--TRIMMABLE-BOUNDARY-START(94489608319),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityWithMapping",
      "o": "@$1",
      "d": 327807,
      "h": 94489608319,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489608319),
//--TRIMMABLE-BOUNDARY-START(77309739135),
    {
      "r": 262213,
      "p": [
        {
          "n": "securityToken",
          "p": 13762686
        },
        {
          "n": "tokenValidationParameters",
          "p": 16777342
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityInternal",
      "o": "@$1",
      "d": 327807,
      "h": 77309739135,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(77309739135),
//--TRIMMABLE-BOUNDARY-START(283468169343),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        }
      ],
      "n": "GetActualIssuer",
      "d": 327807,
      "h": 283468169343,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(283468169343),
//--TRIMMABLE-BOUNDARY-START(85899673727),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityPrivate",
      "o": "@$1",
      "d": 327807,
      "h": 85899673727,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899673727),
//--TRIMMABLE-BOUNDARY-START(184683921535),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "DecryptTokenWithConfigurationAsync",
      "d": 327807,
      "h": 184683921535,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(184683921535),
//--TRIMMABLE-BOUNDARY-START(180388954239),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "DecryptToken",
      "o": "@$2",
      "d": 327807,
      "h": 180388954239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180388954239),
//--TRIMMABLE-BOUNDARY-START(176093986943),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "DecryptToken",
      "o": "@$1",
      "d": 327807,
      "h": 176093986943,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176093986943),
//--TRIMMABLE-BOUNDARY-START(98784575615),
    {
      "r": 786559,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "keys",
          "p": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h
        }
      ],
      "n": "CreateJwtTokenDecryptionParameters",
      "d": 327807,
      "h": 98784575615,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784575615),
//--TRIMMABLE-BOUNDARY-START(386547384447),
    {
      "r": 13631614,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ResolveTokenDecryptionKeyFromConfig",
      "d": 327807,
      "h": 386547384447,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(386547384447),
//--TRIMMABLE-BOUNDARY-START(382252417151),
    {
      "r": 13631614,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ResolveTokenDecryptionKey",
      "o": "@$1",
      "d": 327807,
      "h": 382252417151,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(382252417151),
//--TRIMMABLE-BOUNDARY-START(352187646079),
    {
      "r": 262271,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ReadJsonWebToken",
      "o": "@$1",
      "d": 327807,
      "h": 352187646079,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(352187646079),
//--TRIMMABLE-BOUNDARY-START(347892678783),
    {
      "r": 262271,
      "p": [
        {
          "n": "token",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": "ReadJsonWebToken",
      "d": 327807,
      "h": 347892678783,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(347892678783),
//--TRIMMABLE-BOUNDARY-START(373662482559),
    {
      "r": 262271,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "encodedHeader",
          "p": 1310721
        }
      ],
      "n": "ReplaceTokenHeader",
      "d": 327807,
      "h": 373662482559,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(373662482559),
//--TRIMMABLE-BOUNDARY-START(365072547967),
    {
      "r": 13762686,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ReadToken",
      "d": 327807,
      "h": 365072547967,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(365072547967),
//--TRIMMABLE-BOUNDARY-START(360777580671),
    {
      "r": 16842878,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ReadToken",
      "o": "@$2",
      "d": 327807,
      "h": 360777580671,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(360777580671),
//--TRIMMABLE-BOUNDARY-START(455266861183),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateJWEAsync",
      "o": "@$2",
      "d": 327807,
      "h": 455266861183,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(455266861183),
//--TRIMMABLE-BOUNDARY-START(450971893887),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateJWEAsync",
      "o": "@$1",
      "d": 327807,
      "h": 450971893887,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(450971893887),
//--TRIMMABLE-BOUNDARY-START(468151763071),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateJWSAsync",
      "o": "@$2",
      "d": 327807,
      "h": 468151763071,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(468151763071),
//--TRIMMABLE-BOUNDARY-START(463856795775),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateJWSAsync",
      "o": "@$1",
      "d": 327807,
      "h": 463856795775,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(463856795775),
//--TRIMMABLE-BOUNDARY-START(493921566847),
    {
      "r": 262271,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateSignatureAndIssuerSecurityKey",
      "d": 327807,
      "h": 493921566847,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(493921566847),
//--TRIMMABLE-BOUNDARY-START(485331632255),
    {
      "r": 262271,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateSignature",
      "o": "@$3",
      "d": 327807,
      "h": 485331632255,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(485331632255),
//--TRIMMABLE-BOUNDARY-START(313532940415),
    {
      "r": 262145,
      "p": [
        {
          "n": "signatureBytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "signatureBytesLength",
          "p": 655361
        },
        {
          "n": "signatureProvider",
          "p": 15663230
        },
        {
          "n": "dataToVerify",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "dataToVerifyLength",
          "p": 655361
        }
      ],
      "n": "IsSignatureValid",
      "d": 327807,
      "h": 313532940415,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(313532940415),
//--TRIMMABLE-BOUNDARY-START(489626599551),
    {
      "r": 262145,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "len",
          "p": 655361
        },
        {
          "n": "stringWithSignature",
          "p": 1310721
        },
        {
          "n": "signatureStartIndex",
          "p": 655361
        },
        {
          "n": "signatureProvider",
          "p": 15663230
        }
      ],
      "n": "ValidateSignature",
      "o": "@$4",
      "d": 327807,
      "h": 489626599551,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(489626599551),
//--TRIMMABLE-BOUNDARY-START(481036664959),
    {
      "r": 262145,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "key",
          "p": 13631614
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateSignature",
      "o": "@$2",
      "d": 327807,
      "h": 481036664959,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(481036664959),
//--TRIMMABLE-BOUNDARY-START(369367515263),
    {
      "r": 65537,
      "p": [
        {
          "n": "telemetryClient",
          "p": 196734
        },
        {
          "n": "errorType",
          "p": 1310721
        },
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "key",
          "p": 13631614
        }
      ],
      "n": "RecordSignatureValidationTelemetry",
      "d": 327807,
      "h": 369367515263,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(369367515263),
//--TRIMMABLE-BOUNDARY-START(476741697663),
    {
      "r": 262145,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "key",
          "p": 13631614
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "telemetryClient",
          "p": 196734
        }
      ],
      "n": "ValidateSignature",
      "o": "@$1",
      "d": 327807,
      "h": 476741697663,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(476741697663),
//--TRIMMABLE-BOUNDARY-START(502511501439),
    {
      "r": 262271,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateSignatureUsingDelegates",
      "d": 327807,
      "h": 502511501439,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(502511501439),
//--TRIMMABLE-BOUNDARY-START(511101436031),
    {
      "r": 16842878,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateToken",
      "d": 327807,
      "h": 511101436031,
      "f": 16777345,
      "a": [
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "\u0060JsonWebTokens.ValidateToken(string, TokenValidationParameters)\u0060 has been deprecated and will be removed in a future release. Use \u0060JsonWebTokens.ValidateTokenAsync(string, TokenValidationParameters)\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(511101436031),
//--TRIMMABLE-BOUNDARY-START(541166207103),
    {
      "r": $.$$.STT.Task$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$5",
      "d": 327807,
      "h": 541166207103,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(541166207103),
//--TRIMMABLE-BOUNDARY-START(536871239807),
    {
      "r": $.$$.STT.Task$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$4",
      "d": 327807,
      "h": 536871239807,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(536871239807),
//--TRIMMABLE-BOUNDARY-START(528281305215),
    {
      "r": $.$$.STT.Task$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 13762686
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$2",
      "d": 327807,
      "h": 528281305215,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(528281305215),
//--TRIMMABLE-BOUNDARY-START(523986337919),
    {
      "r": $.$$.STT.Task$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 13762686
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$1",
      "d": 327807,
      "h": 523986337919,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(523986337919),
//--TRIMMABLE-BOUNDARY-START(515396403327),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$6",
      "d": 327807,
      "h": 515396403327,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(515396403327),
//--TRIMMABLE-BOUNDARY-START(549756141695),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateTokenPayloadAsync",
      "o": "@$1",
      "d": 327807,
      "h": 549756141695,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(549756141695),
//--TRIMMABLE-BOUNDARY-START(545461174399),
    {
      "r": $.$$.STT.ValueTask$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ValidateTokenPayloadAsync",
      "d": 327807,
      "h": 545461174399,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(545461174399),
//--TRIMMABLE-BOUNDARY-START(167504052351),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        }
      ],
      "n": "CreateToken",
      "o": "@$15",
      "d": 327807,
      "h": 167504052351,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(167504052351),
//--TRIMMABLE-BOUNDARY-START(163209085055),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$14",
      "d": 327807,
      "h": 163209085055,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(163209085055),
//--TRIMMABLE-BOUNDARY-START(158914117759),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        }
      ],
      "n": "CreateToken",
      "o": "@$13",
      "d": 327807,
      "h": 158914117759,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(158914117759),
//--TRIMMABLE-BOUNDARY-START(154619150463),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$12",
      "d": 327807,
      "h": 154619150463,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(154619150463),
//--TRIMMABLE-BOUNDARY-START(107374510207),
    {
      "r": 1310721,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "CreateToken",
      "o": "@$1",
      "d": 327807,
      "h": 107374510207,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(107374510207),
//--TRIMMABLE-BOUNDARY-START(103079542911),
    {
      "r": 1310721,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090366
        },
        {
          "n": "setdefaultTimesOnTokenCreation",
          "p": 262145
        },
        {
          "n": "tokenLifetimeInMinutes",
          "p": 655361
        }
      ],
      "n": "CreateToken",
      "d": 327807,
      "h": 103079542911,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(103079542911),
//--TRIMMABLE-BOUNDARY-START(120259412095),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        }
      ],
      "n": "CreateToken",
      "o": "@$4",
      "d": 327807,
      "h": 120259412095,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120259412095),
//--TRIMMABLE-BOUNDARY-START(111669477503),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$2",
      "d": 327807,
      "h": 111669477503,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111669477503),
//--TRIMMABLE-BOUNDARY-START(150324183167),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        }
      ],
      "n": "CreateToken",
      "o": "@$11",
      "d": 327807,
      "h": 150324183167,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(150324183167),
//--TRIMMABLE-BOUNDARY-START(128849346687),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$6",
      "d": 327807,
      "h": 128849346687,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(128849346687),
//--TRIMMABLE-BOUNDARY-START(115964444799),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        }
      ],
      "n": "CreateToken",
      "o": "@$3",
      "d": 327807,
      "h": 115964444799,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(115964444799),
//--TRIMMABLE-BOUNDARY-START(146029215871),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        }
      ],
      "n": "CreateToken",
      "o": "@$10",
      "d": 327807,
      "h": 146029215871,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(146029215871),
//--TRIMMABLE-BOUNDARY-START(137439281279),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "additionalInnerHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$8",
      "d": 327807,
      "h": 137439281279,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(137439281279),
//--TRIMMABLE-BOUNDARY-START(141734248575),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$9",
      "d": 327807,
      "h": 141734248575,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(141734248575),
//--TRIMMABLE-BOUNDARY-START(133144313983),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "additionalInnerHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        }
      ],
      "n": "CreateToken",
      "o": "@$7",
      "d": 327807,
      "h": 133144313983,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(133144313983),
//--TRIMMABLE-BOUNDARY-START(124554379391),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "CreateToken",
      "o": "@$5",
      "d": 327807,
      "h": 124554379391,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(124554379391),
//--TRIMMABLE-BOUNDARY-START(592705814655),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "tokenDescriptor",
          "p": 14090366
        },
        {
          "n": "setDefaultTimesOnTokenCreation",
          "p": 262145
        },
        {
          "n": "tokenLifetimeInMinutes",
          "p": 655361
        }
      ],
      "n": "WriteJwsPayload",
      "d": 327807,
      "h": 592705814655,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(592705814655),
//--TRIMMABLE-BOUNDARY-START(34360066175),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "tokenDescriptor",
          "p": 14090366
        },
        {
          "n": "audienceSet",
          "p": 262145
        },
        {
          "n": "issuerSet",
          "p": 262145
        },
        {
          "n": "expSet",
          "p": 262145,
          "f": 4
        },
        {
          "n": "iatSet",
          "p": 262145,
          "f": 4
        },
        {
          "n": "nbfSet",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "AddSubjectClaims",
      "d": 327807,
      "h": 34360066175,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360066175),
//--TRIMMABLE-BOUNDARY-START(588410847359),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "jweHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "jwsHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": "WriteJwsHeader",
      "o": "@$1",
      "d": 327807,
      "h": 588410847359,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(588410847359),
//--TRIMMABLE-BOUNDARY-START(584115880063),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "WriteJwsHeader",
      "d": 327807,
      "h": 584115880063,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(584115880063),
//--TRIMMABLE-BOUNDARY-START(575525945471),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "jweHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": "WriteJweHeader",
      "d": 327807,
      "h": 575525945471,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(575525945471),
//--TRIMMABLE-BOUNDARY-START(579820912767),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "WriteJweHeader",
      "o": "@$1",
      "d": 327807,
      "h": 579820912767,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(579820912767),
//--TRIMMABLE-BOUNDARY-START(554051108991),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "WriteActor",
      "d": 327807,
      "h": 554051108991,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(554051108991),
//--TRIMMABLE-BOUNDARY-START(566936010879),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "actor",
          "p": 262213
        },
        {
          "n": "remainingActorLevels",
          "p": 655361
        }
      ],
      "n": "WriteActorValue",
      "d": 327807,
      "h": 566936010879,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(566936010879),
//--TRIMMABLE-BOUNDARY-START(562641043583),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "actor",
          "p": 262213
        },
        {
          "n": "remainingActorLevels",
          "p": 655361
        }
      ],
      "n": "WriteActorObject",
      "d": 327807,
      "h": 562641043583,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(562641043583),
//--TRIMMABLE-BOUNDARY-START(571230978175),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "identity",
          "p": 262213
        }
      ],
      "n": "WriteIdentityClaims",
      "d": 327807,
      "h": 571230978175,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(571230978175),
//--TRIMMABLE-BOUNDARY-START(279173202047),
    {
      "r": 262213,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "GetActorIdentity",
      "d": 327807,
      "h": 279173202047,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(279173202047),
//--TRIMMABLE-BOUNDARY-START(558346076287),
    {
      "r": 1310721,
      "p": [
        {
          "n": "actor",
          "p": 262213
        }
      ],
      "n": "WriteActorAsJsonString",
      "d": 327807,
      "h": 558346076287,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(558346076287),
//--TRIMMABLE-BOUNDARY-START(51539935359),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "utf8Bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        }
      ],
      "n": "CompressToken",
      "d": 327807,
      "h": 51539935359,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51539935359),
//--TRIMMABLE-BOUNDARY-START(219043659903),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        }
      ],
      "n": "EncryptToken",
      "o": "@$5",
      "d": 327807,
      "h": 219043659903,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219043659903),
//--TRIMMABLE-BOUNDARY-START(206158758015),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "EncryptToken",
      "o": "@$2",
      "d": 327807,
      "h": 206158758015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206158758015),
//--TRIMMABLE-BOUNDARY-START(214748692607),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "algorithm",
          "p": 1310721
        }
      ],
      "n": "EncryptToken",
      "o": "@$4",
      "d": 327807,
      "h": 214748692607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214748692607),
//--TRIMMABLE-BOUNDARY-START(210453725311),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "algorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "EncryptToken",
      "o": "@$3",
      "d": 327807,
      "h": 210453725311,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210453725311),
//--TRIMMABLE-BOUNDARY-START(223338627199),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "EncryptTokenPrivate",
      "d": 327807,
      "h": 223338627199,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(223338627199),
//--TRIMMABLE-BOUNDARY-START(197568823423),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerTokenUtf8Bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": "EncryptToken",
      "d": 327807,
      "h": 197568823423,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(197568823423),
//--TRIMMABLE-BOUNDARY-START(201863790719),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerTokenUtf8Bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "EncryptToken",
      "o": "@$1",
      "d": 327807,
      "h": 201863790719,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(201863790719),
//--TRIMMABLE-BOUNDARY-START(292058103935),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262271
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "GetContentEncryptionKeys",
      "o": "@$1",
      "d": 327807,
      "h": 292058103935,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(292058103935)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295103),
    {
      "t": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "_inboundClaimTypeMap",
      "d": 327807,
      "h": 4295295103,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295103),
//--TRIMMABLE-BOUNDARY-START(12885229695),
    {
      "t": 1310721,
      "n": "_namespace",
      "d": 327807,
      "h": 12885229695,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885229695),
//--TRIMMABLE-BOUNDARY-START(17180196991),
    {
      "t": 1310721,
      "n": "_shortClaimType",
      "d": 327807,
      "h": 17180196991,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180196991),
//--TRIMMABLE-BOUNDARY-START(8590262399),
    {
      "t": 262145,
      "n": "_mapInboundClaims",
      "d": 327807,
      "h": 8590262399,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262399),
//--TRIMMABLE-BOUNDARY-START(188978888831),
    {
      "t": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "DefaultInboundClaimTypeMap",
      "d": 327807,
      "h": 188978888831,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188978888831),
//--TRIMMABLE-BOUNDARY-START(193273856127),
    {
      "t": 262145,
      "n": "DefaultMapInboundClaims",
      "d": 327807,
      "h": 193273856127,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193273856127),
//--TRIMMABLE-BOUNDARY-START(38655033471),
    {
      "t": 1310721,
      "n": "Base64UrlEncodedUnsignedJWSHeader",
      "d": 327807,
      "h": 38655033471,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655033471),
//--TRIMMABLE-BOUNDARY-START(438086991999),
    {
      "t": 196734,
      "n": "TelemetryClient",
      "d": 327807,
      "h": 438086991999,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(438086991999),
//--TRIMMABLE-BOUNDARY-START(390842351743),
    {
      "t": 14090366,
      "n": "s_emptyTokenDescriptor",
      "d": 327807,
      "h": 390842351743,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(390842351743),
//--TRIMMABLE-BOUNDARY-START(30065098879),
    {
      "t": 1310721,
      "n": "ActClaimType",
      "d": 327807,
      "h": 30065098879,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065098879),
//--TRIMMABLE-BOUNDARY-START(395137319039),
    {
      "t": 655361,
      "n": "s_maxActorChainLength",
      "d": 327807,
      "h": 395137319039,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(395137319039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770131583),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327807,
      "h": 25770131583,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131583)
  ],
  "h": 327807
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mit.MITE.IResultBasedValidation ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mij.MIJ.JsonWebTokenHandler.KeyMatchFailedResult ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}JsonWebTokens${separator}JsonWebTokenHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327807)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179775)
        $asm.$cls(`$mij.STRG.CreateJwsRegex_0`, ($self) => class CreateJwsRegex_0 extends $.$str.STR.Regex
        {
            //--TRIMMABLE-BOUNDARY-START(12886081663)
            /*CreateJwsRegex_0*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(12886081663)
            
            //--TRIMMABLE-BOUNDARY-START(8591114367)
            $ctor$8()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114367);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.pattern = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                    this.roptions = 512/*RegexOptions.CultureInvariant*/;
                    this.internalMatchTimeout = $.$$.S.TimeSpan.FromMilliseconds$2(100n);
                    this.factory = new $.$mij.STRG.CreateJwsRegex_0.RunnerFactory().$ctor$2();
                    this.capsize = 1;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114367)
            
            //--TRIMMABLE-BOUNDARY-START(1245311)
            static $_RunnerFactory;
            static get RunnerFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1245311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mij.STRG.CreateJwsRegex_0;
                return $cls.$_RunnerFactory ??= $asm.$ncls(`$mij.STRG.CreateJwsRegex_0.RunnerFactory`, ($self) => class RunnerFactory extends $.$str.STR.RegexRunnerFactory
                {
                    //--TRIMMABLE-BOUNDARY-START(8591179903)
                    /*RegexRunner */ CreateInstance()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591179903);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$mij.STRG.CreateJwsRegex_0.RunnerFactory.Runner().$ctor$2();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591179903)
                    
                    //--TRIMMABLE-BOUNDARY-START(1310847)
                    static $_Runner;
                    static get Runner()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1310847);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$mij.STRG.CreateJwsRegex_0.RunnerFactory;
                        return $cls.$_Runner ??= $asm.$ncls(`$mij.STRG.CreateJwsRegex_0.RunnerFactory.Runner`, ($self) => class Runner extends $.$str.STR.RegexRunner
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591245439)
                            /*void */ Scan(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(8591245439);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this.TryFindNextPossibleStartingPosition(inputSpan) && !this.TryMatchAtCurrentPosition(inputSpan))
                                {
                                    this.runtextpos = inputSpan.Length;
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591245439)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886212735)
                            /*bool */ TryFindNextPossibleStartingPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(12886212735);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*int*/ let pos = this.runtextpos;
                                if (pos <= ((inputSpan.Length - 4) | 0))
                                {
                                    if (pos === 0)
                                    {
                                        return true;
                                    }
                                }
                                this.runtextpos = inputSpan.Length;
                                return false;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886212735)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181180031)
                            /*bool */ TryMatchAtCurrentPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17181180031);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*int*/ let pos = this.runtextpos;
                                /*int*/ let matchStart = pos;
                                /*ReadOnlySpan<char>*/ let slice = inputSpan.Slice$1(pos);
                                if (pos !== 0)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, slice, $.$mij.STRG.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration < 0)
                                    {
                                        iteration = slice.Length;
                                    }
                                    if (iteration === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration);
                                    pos += iteration;
                                }
                                if (slice.IsEmpty || slice._reference.GetAt(0) !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration1 = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, slice.Slice$1(1), $.$mij.STRG.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration1 < 0)
                                    {
                                        iteration1 = ((slice.Length - 1) | 0);
                                    }
                                    if (iteration1 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration1);
                                    pos += iteration1;
                                }
                                if ((slice.Length >>> 0) < 2 || slice._reference.GetAt(1) !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration2 = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, slice.Slice$1(2), $.$mij.STRG.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration2 < 0)
                                    {
                                        iteration2 = ((slice.Length - 2) | 0);
                                    }
                                    slice = slice.Slice$1(iteration2);
                                    pos += iteration2;
                                }
                                if (3 < slice.Length || (2 < slice.Length && slice._reference.GetAt(2) !== /*\n*/ 10))
                                {
                                    return false;
                                }
                                pos += 2;
                                this.runtextpos = pos;
                                super.Capture(0, matchStart, pos);
                                return true;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181180031)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296278143)
                            //default constructor overload
                            $ctor$2()
                            {
                                super.$ctor$1();
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4296278143);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296278143)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296278143)
                            //generic new constructor
                            $gctor()
                            {
                                return this.$ctor$2();
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296278143)
                            
                            static $h = 1310847;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$str.STR.RegexRunner; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591245439),
    {
      "r": 65537,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "Scan",
      "d": 1310847,
      "h": 8591245439,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591245439),
//--TRIMMABLE-BOUNDARY-START(12886212735),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "TryFindNextPossibleStartingPosition",
      "d": 1310847,
      "h": 12886212735,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886212735),
//--TRIMMABLE-BOUNDARY-START(17181180031),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "TryMatchAtCurrentPosition",
      "d": 1310847,
      "h": 17181180031,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181180031)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278143),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310847,
      "h": 4296278143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278143)
  ],
  "d": 1245311,
  "h": 1310847
}; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.Text.RegularExpressions.Generated.CreateJwsRegex_0+RunnerFactory+Runner`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}RegularExpressions${separator}Generated${separator}CreateJwsRegex_0${separator}RunnerFactory${separator}Runner`; }
                        }, $cls, ($v) => $cls.$_Runner = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1310847)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296212607)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296212607);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296212607)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296212607)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296212607)
                    
                    static $h = 1245311;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$str.STR.RegexRunnerFactory; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591179903),
    {
      "r": 3997754,
      "n": "CreateInstance",
      "d": 1245311,
      "h": 8591179903,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591179903)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212607),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245311,
      "h": 4296212607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212607)
  ],
  "d": 1179775,
  "h": 1245311
}; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$mij.STRG.CreateJwsRegex_0.RunnerFactory.Runner ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Text.RegularExpressions.Generated.CreateJwsRegex_0+RunnerFactory`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}RegularExpressions${separator}Generated${separator}CreateJwsRegex_0${separator}RunnerFactory`; }
                }, $cls, ($v) => $cls.$_RunnerFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245311)
            
            //--TRIMMABLE-BOUNDARY-START(8591114367)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(8591114367)
            
            //--TRIMMABLE-BOUNDARY-START(4296147071)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12886081663)
                    this.Instance = new $.$mij.STRG.CreateJwsRegex_0().$ctor$8();
                    //--TRIMMABLE-BOUNDARY-END(12886081663)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296147071)
            
            static $h = 1179775;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$str.STR.Regex; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886081663),
    {
      "t": 1179775,
      "n": "Instance",
      "d": 1179775,
      "h": 12886081663,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886081663)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114367),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1179775,
      "h": 8591114367,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8591114367)
  ],
  "h": 1179775,
  "a": [
    {
      "t": 55050241,
      "c": 12939952129,
      "a": [
        {
          "v": "System.Text.RegularExpressions.Generator",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mij.STRG.CreateJwsRegex_0.RunnerFactory ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.RegularExpressions.Generated.CreateJwsRegex_0`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}RegularExpressions${separator}Generated${separator}CreateJwsRegex_0`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179775)
        
        

        //--TRIMMABLE-BOUNDARY-START(983167)
        $asm.$cls(`$mij.STRG.CreateJweRegex_1`, ($self) => class CreateJweRegex_1 extends $.$str.STR.Regex
        {
            //--TRIMMABLE-BOUNDARY-START(12885885055)
            /*CreateJweRegex_1*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(12885885055)
            
            //--TRIMMABLE-BOUNDARY-START(8590917759)
            $ctor$8()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917759);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.pattern = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                    this.roptions = 512/*RegexOptions.CultureInvariant*/;
                    this.internalMatchTimeout = $.$$.S.TimeSpan.FromMilliseconds$2(100n);
                    this.factory = new $.$mij.STRG.CreateJweRegex_1.RunnerFactory().$ctor$2();
                    this.capsize = 1;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917759)
            
            //--TRIMMABLE-BOUNDARY-START(1048703)
            static $_RunnerFactory;
            static get RunnerFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mij.STRG.CreateJweRegex_1;
                return $cls.$_RunnerFactory ??= $asm.$ncls(`$mij.STRG.CreateJweRegex_1.RunnerFactory`, ($self) => class RunnerFactory extends $.$str.STR.RegexRunnerFactory
                {
                    //--TRIMMABLE-BOUNDARY-START(8590983295)
                    /*RegexRunner */ CreateInstance()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590983295);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$mij.STRG.CreateJweRegex_1.RunnerFactory.Runner().$ctor$2();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590983295)
                    
                    //--TRIMMABLE-BOUNDARY-START(1114239)
                    static $_Runner;
                    static get Runner()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1114239);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$mij.STRG.CreateJweRegex_1.RunnerFactory;
                        return $cls.$_Runner ??= $asm.$ncls(`$mij.STRG.CreateJweRegex_1.RunnerFactory.Runner`, ($self) => class Runner extends $.$str.STR.RegexRunner
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591048831)
                            /*void */ Scan(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(8591048831);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this.TryFindNextPossibleStartingPosition(inputSpan) && !this.TryMatchAtCurrentPosition(inputSpan))
                                {
                                    this.runtextpos = inputSpan.Length;
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591048831)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886016127)
                            /*bool */ TryFindNextPossibleStartingPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(12886016127);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*int*/ let pos = this.runtextpos;
                                if (pos <= ((inputSpan.Length - 8) | 0))
                                {
                                    if (pos === 0)
                                    {
                                        return true;
                                    }
                                }
                                this.runtextpos = inputSpan.Length;
                                return false;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886016127)
                            
                            //--TRIMMABLE-BOUNDARY-START(17180983423)
                            /*bool */ TryMatchAtCurrentPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17180983423);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*int*/ let pos = this.runtextpos;
                                /*int*/ let matchStart = pos;
                                /*ReadOnlySpan<char>*/ let slice = inputSpan.Slice$1(pos);
                                if (pos !== 0)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, slice, $.$mij.STRG.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration < 0)
                                    {
                                        iteration = slice.Length;
                                    }
                                    if (iteration === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration);
                                    pos += iteration;
                                }
                                if (slice.IsEmpty || slice._reference.GetAt(0) !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration1 = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, slice.Slice$1(1), $.$mij.STRG.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration1 < 0)
                                    {
                                        iteration1 = ((slice.Length - 1) | 0);
                                    }
                                    slice = slice.Slice$1(iteration1);
                                    pos += iteration1;
                                }
                                if ((slice.Length >>> 0) < 2 || slice._reference.GetAt(1) !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration2 = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, slice.Slice$1(2), $.$mij.STRG.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration2 < 0)
                                    {
                                        iteration2 = ((slice.Length - 2) | 0);
                                    }
                                    if (iteration2 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration2);
                                    pos += iteration2;
                                }
                                if ((slice.Length >>> 0) < 3 || slice._reference.GetAt(2) !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration3 = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, slice.Slice$1(3), $.$mij.STRG.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration3 < 0)
                                    {
                                        iteration3 = ((slice.Length - 3) | 0);
                                    }
                                    if (iteration3 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration3);
                                    pos += iteration3;
                                }
                                if ((slice.Length >>> 0) < 4 || slice._reference.GetAt(3) !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration4 = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, slice.Slice$1(4), $.$mij.STRG.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration4 < 0)
                                    {
                                        iteration4 = ((slice.Length - 4) | 0);
                                    }
                                    if (iteration4 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration4);
                                    pos += iteration4;
                                }
                                if (5 < slice.Length || (4 < slice.Length && slice._reference.GetAt(4) !== /*\n*/ 10))
                                {
                                    return false;
                                }
                                pos += 4;
                                this.runtextpos = pos;
                                super.Capture(0, matchStart, pos);
                                return true;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17180983423)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296081535)
                            //default constructor overload
                            $ctor$2()
                            {
                                super.$ctor$1();
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4296081535);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296081535)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296081535)
                            //generic new constructor
                            $gctor()
                            {
                                return this.$ctor$2();
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296081535)
                            
                            static $h = 1114239;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$str.STR.RegexRunner; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591048831),
    {
      "r": 65537,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "Scan",
      "d": 1114239,
      "h": 8591048831,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591048831),
//--TRIMMABLE-BOUNDARY-START(12886016127),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "TryFindNextPossibleStartingPosition",
      "d": 1114239,
      "h": 12886016127,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886016127),
//--TRIMMABLE-BOUNDARY-START(17180983423),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "TryMatchAtCurrentPosition",
      "d": 1114239,
      "h": 17180983423,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180983423)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081535),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114239,
      "h": 4296081535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081535)
  ],
  "d": 1048703,
  "h": 1114239
}; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.Text.RegularExpressions.Generated.CreateJweRegex_1+RunnerFactory+Runner`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}RegularExpressions${separator}Generated${separator}CreateJweRegex_1${separator}RunnerFactory${separator}Runner`; }
                        }, $cls, ($v) => $cls.$_Runner = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1114239)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015999)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296015999);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296015999)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015999)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296015999)
                    
                    static $h = 1048703;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$str.STR.RegexRunnerFactory; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983295),
    {
      "r": 3997754,
      "n": "CreateInstance",
      "d": 1048703,
      "h": 8590983295,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590983295)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015999),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048703,
      "h": 4296015999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015999)
  ],
  "d": 983167,
  "h": 1048703
}; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$mij.STRG.CreateJweRegex_1.RunnerFactory.Runner ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Text.RegularExpressions.Generated.CreateJweRegex_1+RunnerFactory`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}RegularExpressions${separator}Generated${separator}CreateJweRegex_1${separator}RunnerFactory`; }
                }, $cls, ($v) => $cls.$_RunnerFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048703)
            
            //--TRIMMABLE-BOUNDARY-START(8590917759)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(8590917759)
            
            //--TRIMMABLE-BOUNDARY-START(4295950463)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885885055)
                    this.Instance = new $.$mij.STRG.CreateJweRegex_1().$ctor$8();
                    //--TRIMMABLE-BOUNDARY-END(12885885055)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295950463)
            
            static $h = 983167;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$str.STR.Regex; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885885055),
    {
      "t": 983167,
      "n": "Instance",
      "d": 983167,
      "h": 12885885055,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885885055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917759),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 983167,
      "h": 8590917759,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590917759)
  ],
  "h": 983167,
  "a": [
    {
      "t": 55050241,
      "c": 12939952129,
      "a": [
        {
          "v": "System.Text.RegularExpressions.Generator",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mij.STRG.CreateJweRegex_1.RunnerFactory ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.RegularExpressions.Generated.CreateJweRegex_1`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}RegularExpressions${separator}Generated${separator}CreateJweRegex_1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983167)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Logging", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.IdentityModel.Tokens"));
})();
//--TRIMMABLE-BOUNDARY-END(127)
