
//--TRIMMABLE-BOUNDARY-START(120)
(function ($global, $, $$, $mia, $sc, $sm, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mil, $scm, $so, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $mexla, $mep, $scp, $scs, $sdp, $srw, $srl, $srsf, $str, $sdts, $spx, $spxl, $sxxd, $sct, $sca, $meo, $mexl, $sipl, $stew, $stj, $mit) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.JsonWebTokens", 
    {
  "h": 120,
  "f": "Microsoft.IdentityModel.JsonWebTokens",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Validators, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.JsonWebTokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.TestUtils, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "Serviceable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54263809,
      "c": 8644198401,
      "a": [
        {
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 140050433,
      "c": 8729985025,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.JsonWebTokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Protocols.SignedHttpRequest, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "System.IdentityModel.Tokens.Jwt, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "System.IdentityModel.Tokens.Jwt.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tokens, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Benchmarks, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsAotCompatible",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "Microsoft Corporation.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106627073,
      "c": 8696561665,
      "a": [
        {
          "v": "\u00A9 Microsoft Corporation. All rights reserved.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "Includes types that provide support for creating, serializing and validating JSON Web Tokens. This is a newer, faster version of System.IdentityModel.Tokens.Jwt that has additional functionality.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "9.0.0.26264",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "Microsoft IdentityModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.IdentityModel.JsonWebTokens",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "NetJs.System.IdentityModel.Tokens.Jwt",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(917624)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.LogMessages", ($self) => class LogMessages
        {
            //--TRIMMABLE-BOUNDARY-START(4295884920)
            /*string*/ static IDX14000 = null;
            //--TRIMMABLE-BOUNDARY-END(4295884920)
            
            //--TRIMMABLE-BOUNDARY-START(8590852216)
            /*string*/ static IDX14100 = null;
            //--TRIMMABLE-BOUNDARY-END(8590852216)
            
            //--TRIMMABLE-BOUNDARY-START(12885819512)
            /*string*/ static IDX14101 = null;
            //--TRIMMABLE-BOUNDARY-END(12885819512)
            
            //--TRIMMABLE-BOUNDARY-START(17180786808)
            /*string*/ static IDX14102 = null;
            //--TRIMMABLE-BOUNDARY-END(17180786808)
            
            //--TRIMMABLE-BOUNDARY-START(21475754104)
            /*string*/ static IDX14103 = null;
            //--TRIMMABLE-BOUNDARY-END(21475754104)
            
            //--TRIMMABLE-BOUNDARY-START(25770721400)
            /*string*/ static IDX14107 = null;
            //--TRIMMABLE-BOUNDARY-END(25770721400)
            
            //--TRIMMABLE-BOUNDARY-START(30065688696)
            /*string*/ static IDX14112 = null;
            //--TRIMMABLE-BOUNDARY-END(30065688696)
            
            //--TRIMMABLE-BOUNDARY-START(34360655992)
            /*string*/ static IDX14113 = null;
            //--TRIMMABLE-BOUNDARY-END(34360655992)
            
            //--TRIMMABLE-BOUNDARY-START(38655623288)
            /*string*/ static IDX14114 = null;
            //--TRIMMABLE-BOUNDARY-END(38655623288)
            
            //--TRIMMABLE-BOUNDARY-START(42950590584)
            /*string*/ static IDX14116 = null;
            //--TRIMMABLE-BOUNDARY-END(42950590584)
            
            //--TRIMMABLE-BOUNDARY-START(47245557880)
            /*string*/ static IDX14117 = null;
            //--TRIMMABLE-BOUNDARY-END(47245557880)
            
            //--TRIMMABLE-BOUNDARY-START(51540525176)
            /*string*/ static IDX14120 = null;
            //--TRIMMABLE-BOUNDARY-END(51540525176)
            
            //--TRIMMABLE-BOUNDARY-START(55835492472)
            /*string*/ static IDX14121 = null;
            //--TRIMMABLE-BOUNDARY-END(55835492472)
            
            //--TRIMMABLE-BOUNDARY-START(60130459768)
            /*string*/ static IDX14122 = null;
            //--TRIMMABLE-BOUNDARY-END(60130459768)
            
            //--TRIMMABLE-BOUNDARY-START(64425427064)
            /*string*/ static IDX14200 = null;
            //--TRIMMABLE-BOUNDARY-END(64425427064)
            
            //--TRIMMABLE-BOUNDARY-START(68720394360)
            /*string*/ static IDX14201 = null;
            //--TRIMMABLE-BOUNDARY-END(68720394360)
            
            //--TRIMMABLE-BOUNDARY-START(73015361656)
            /*string*/ static IDX14304 = null;
            //--TRIMMABLE-BOUNDARY-END(73015361656)
            
            //--TRIMMABLE-BOUNDARY-START(77310328952)
            /*string*/ static IDX14305 = null;
            //--TRIMMABLE-BOUNDARY-END(77310328952)
            
            //--TRIMMABLE-BOUNDARY-START(81605296248)
            /*string*/ static IDX14306 = null;
            //--TRIMMABLE-BOUNDARY-END(81605296248)
            
            //--TRIMMABLE-BOUNDARY-START(85900263544)
            /*string*/ static IDX14307 = null;
            //--TRIMMABLE-BOUNDARY-END(85900263544)
            
            //--TRIMMABLE-BOUNDARY-START(90195230840)
            /*string*/ static IDX14308 = null;
            //--TRIMMABLE-BOUNDARY-END(90195230840)
            
            //--TRIMMABLE-BOUNDARY-START(94490198136)
            /*string*/ static IDX14309 = null;
            //--TRIMMABLE-BOUNDARY-END(94490198136)
            
            //--TRIMMABLE-BOUNDARY-START(98785165432)
            /*string*/ static IDX14310 = null;
            //--TRIMMABLE-BOUNDARY-END(98785165432)
            
            //--TRIMMABLE-BOUNDARY-START(103080132728)
            /*string*/ static IDX14311 = null;
            //--TRIMMABLE-BOUNDARY-END(103080132728)
            
            //--TRIMMABLE-BOUNDARY-START(107375100024)
            /*string*/ static IDX14312 = null;
            //--TRIMMABLE-BOUNDARY-END(107375100024)
            
            //--TRIMMABLE-BOUNDARY-START(111670067320)
            /*string*/ static IDX14317 = null;
            //--TRIMMABLE-BOUNDARY-END(111670067320)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295884920)
                    this.IDX14000 = "IDX14000: Signature validation of this JWT is not supported for: Algorithm: '{0}', SecurityKey: '{1}'.";
                    //--TRIMMABLE-BOUNDARY-END(4295884920)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852216)
                    this.IDX14100 = "IDX14100: JWT is not well formed, there are no dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(8590852216)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885819512)
                    this.IDX14101 = "IDX14101: Unable to decode the payload '{0}' as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(12885819512)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180786808)
                    this.IDX14102 = "IDX14102: Unable to decode the header '{0}' as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(17180786808)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475754104)
                    this.IDX14103 = "IDX14103: Failed to create the token encryption provider.";
                    //--TRIMMABLE-BOUNDARY-END(21475754104)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770721400)
                    this.IDX14107 = "IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)";
                    //--TRIMMABLE-BOUNDARY-END(25770721400)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065688696)
                    this.IDX14112 = "IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'";
                    //--TRIMMABLE-BOUNDARY-END(30065688696)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360655992)
                    this.IDX14113 = "IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used.";
                    //--TRIMMABLE-BOUNDARY-END(34360655992)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655623288)
                    this.IDX14114 = "IDX14114: Both '{0}.{1}' and '{0}.{2}' are null or empty.";
                    //--TRIMMABLE-BOUNDARY-END(38655623288)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950590584)
                    this.IDX14116 = "IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation.";
                    //--TRIMMABLE-BOUNDARY-END(42950590584)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245557880)
                    this.IDX14117 = "IDX14117: Cannot create a 'JsonWebToken' with a replaced header from an encrypted (JWE) token. The provided token must be a JWS so that its decoded payload can be reused.";
                    //--TRIMMABLE-BOUNDARY-END(47245557880)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540525176)
                    this.IDX14120 = "IDX14120: JWT is not well formed, there is only one dot (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(51540525176)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835492472)
                    this.IDX14121 = "IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(55835492472)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130459768)
                    this.IDX14122 = "IDX14122: JWT is not a well formed JWE, there are more than four dots (.) a JWE can have at most 4 dots.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(60130459768)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425427064)
                    this.IDX14200 = "IDX14200: Creating raw signature using the signature credentials.";
                    //--TRIMMABLE-BOUNDARY-END(64425427064)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720394360)
                    this.IDX14201 = "IDX14201: Creating raw signature using the signature credentials. Caching SignatureProvider: '{0}'.";
                    //--TRIMMABLE-BOUNDARY-END(68720394360)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015361656)
                    this.IDX14304 = "IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet.";
                    //--TRIMMABLE-BOUNDARY-END(73015361656)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310328952)
                    this.IDX14305 = "IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'.";
                    //--TRIMMABLE-BOUNDARY-END(77310328952)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605296248)
                    this.IDX14306 = "IDX14306: JWE Ciphertext cannot be an empty string.";
                    //--TRIMMABLE-BOUNDARY-END(81605296248)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900263544)
                    this.IDX14307 = "IDX14307: JWE header is missing.";
                    //--TRIMMABLE-BOUNDARY-END(85900263544)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195230840)
                    this.IDX14308 = "IDX14308: JWE initialization vector is missing.";
                    //--TRIMMABLE-BOUNDARY-END(90195230840)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490198136)
                    this.IDX14309 = "IDX14309: Unable to decode the initialization vector as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(94490198136)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98785165432)
                    this.IDX14310 = "IDX14310: JWE authentication tag is missing.";
                    //--TRIMMABLE-BOUNDARY-END(98785165432)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080132728)
                    this.IDX14311 = "IDX14311: Unable to decode the authentication tag as a Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(103080132728)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375100024)
                    this.IDX14312 = "IDX14312: Unable to decode the cipher text as a Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(107375100024)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670067320)
                    this.IDX14317 = "IDX14317: JsonWebTokenHandler.MaxActorChainLength must be greater than or equal to 1. Value provided was: '{0}'.";
                    //--TRIMMABLE-BOUNDARY-END(111670067320)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 917624;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884920),
    {
      "t": 1310721,
      "n": "IDX14000",
      "d": 917624,
      "h": 4295884920,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295884920),
//--TRIMMABLE-BOUNDARY-START(8590852216),
    {
      "t": 1310721,
      "n": "IDX14100",
      "d": 917624,
      "h": 8590852216,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590852216),
//--TRIMMABLE-BOUNDARY-START(12885819512),
    {
      "t": 1310721,
      "n": "IDX14101",
      "d": 917624,
      "h": 12885819512,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885819512),
//--TRIMMABLE-BOUNDARY-START(17180786808),
    {
      "t": 1310721,
      "n": "IDX14102",
      "d": 917624,
      "h": 17180786808,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180786808),
//--TRIMMABLE-BOUNDARY-START(21475754104),
    {
      "t": 1310721,
      "n": "IDX14103",
      "d": 917624,
      "h": 21475754104,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475754104),
//--TRIMMABLE-BOUNDARY-START(25770721400),
    {
      "t": 1310721,
      "n": "IDX14107",
      "d": 917624,
      "h": 25770721400,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770721400),
//--TRIMMABLE-BOUNDARY-START(30065688696),
    {
      "t": 1310721,
      "n": "IDX14112",
      "d": 917624,
      "h": 30065688696,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065688696),
//--TRIMMABLE-BOUNDARY-START(34360655992),
    {
      "t": 1310721,
      "n": "IDX14113",
      "d": 917624,
      "h": 34360655992,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360655992),
//--TRIMMABLE-BOUNDARY-START(38655623288),
    {
      "t": 1310721,
      "n": "IDX14114",
      "d": 917624,
      "h": 38655623288,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655623288),
//--TRIMMABLE-BOUNDARY-START(42950590584),
    {
      "t": 1310721,
      "n": "IDX14116",
      "d": 917624,
      "h": 42950590584,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950590584),
//--TRIMMABLE-BOUNDARY-START(47245557880),
    {
      "t": 1310721,
      "n": "IDX14117",
      "d": 917624,
      "h": 47245557880,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245557880),
//--TRIMMABLE-BOUNDARY-START(51540525176),
    {
      "t": 1310721,
      "n": "IDX14120",
      "d": 917624,
      "h": 51540525176,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540525176),
//--TRIMMABLE-BOUNDARY-START(55835492472),
    {
      "t": 1310721,
      "n": "IDX14121",
      "d": 917624,
      "h": 55835492472,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835492472),
//--TRIMMABLE-BOUNDARY-START(60130459768),
    {
      "t": 1310721,
      "n": "IDX14122",
      "d": 917624,
      "h": 60130459768,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130459768),
//--TRIMMABLE-BOUNDARY-START(64425427064),
    {
      "t": 1310721,
      "n": "IDX14200",
      "d": 917624,
      "h": 64425427064,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425427064),
//--TRIMMABLE-BOUNDARY-START(68720394360),
    {
      "t": 1310721,
      "n": "IDX14201",
      "d": 917624,
      "h": 68720394360,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720394360),
//--TRIMMABLE-BOUNDARY-START(73015361656),
    {
      "t": 1310721,
      "n": "IDX14304",
      "d": 917624,
      "h": 73015361656,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015361656),
//--TRIMMABLE-BOUNDARY-START(77310328952),
    {
      "t": 1310721,
      "n": "IDX14305",
      "d": 917624,
      "h": 77310328952,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310328952),
//--TRIMMABLE-BOUNDARY-START(81605296248),
    {
      "t": 1310721,
      "n": "IDX14306",
      "d": 917624,
      "h": 81605296248,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605296248),
//--TRIMMABLE-BOUNDARY-START(85900263544),
    {
      "t": 1310721,
      "n": "IDX14307",
      "d": 917624,
      "h": 85900263544,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900263544),
//--TRIMMABLE-BOUNDARY-START(90195230840),
    {
      "t": 1310721,
      "n": "IDX14308",
      "d": 917624,
      "h": 90195230840,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90195230840),
//--TRIMMABLE-BOUNDARY-START(94490198136),
    {
      "t": 1310721,
      "n": "IDX14309",
      "d": 917624,
      "h": 94490198136,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94490198136),
//--TRIMMABLE-BOUNDARY-START(98785165432),
    {
      "t": 1310721,
      "n": "IDX14310",
      "d": 917624,
      "h": 98785165432,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98785165432),
//--TRIMMABLE-BOUNDARY-START(103080132728),
    {
      "t": 1310721,
      "n": "IDX14311",
      "d": 917624,
      "h": 103080132728,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103080132728),
//--TRIMMABLE-BOUNDARY-START(107375100024),
    {
      "t": 1310721,
      "n": "IDX14312",
      "d": 917624,
      "h": 107375100024,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107375100024),
//--TRIMMABLE-BOUNDARY-START(111670067320),
    {
      "t": 1310721,
      "n": "IDX14317",
      "d": 917624,
      "h": 111670067320,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111670067320)
  ],
  "h": 917624
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.LogMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917624)
        
        
        //--TRIMMABLE-BOUNDARY-START(65656)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping", ($self) => class ClaimTypeMapping
        {
            //--TRIMMABLE-BOUNDARY-START(55834640504)
            /*Dictionary<string, string>*/ static shortToLongClaimTypeMapping = null;
            //--TRIMMABLE-BOUNDARY-END(55834640504)
            
            //--TRIMMABLE-BOUNDARY-START(47244705912)
            /*Dictionary<string, string>*/ static longToShortClaimTypeMapping = null;
            //--TRIMMABLE-BOUNDARY-END(47244705912)
            
            //--TRIMMABLE-BOUNDARY-START(34359804024)
            /*HashSet<string>*/ static inboundClaimFilter = null;
            //--TRIMMABLE-BOUNDARY-END(34359804024)
            
            //--TRIMMABLE-BOUNDARY-START(4295032952)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.shortToLongClaimTypeMapping.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kv = $en2.Current;
                    {
                        if ($.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.longToShortClaimTypeMapping.ContainsKey(kv.Value))
                        {
                            continue;
                        }
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.longToShortClaimTypeMapping.Add(kv.Value, kv.Key);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032952)
            
            //--TRIMMABLE-BOUNDARY-START(42949738616)
            static /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.shortToLongClaimTypeMapping;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738616)
            
            //--TRIMMABLE-BOUNDARY-START(51539673208)
            static /*IDictionary<string, string> */ get OutboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.longToShortClaimTypeMapping;
            }
            //--TRIMMABLE-BOUNDARY-END(51539673208)
            
            //--TRIMMABLE-BOUNDARY-START(38654771320)
            static /*ISet<string> */ get InboundClaimFilter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.inboundClaimFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771320)
            
            //--TRIMMABLE-BOUNDARY-START(4295032952)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640504)
                    this.shortToLongClaimTypeMapping = (() =>
                    {
                        //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("actort"/*JwtRegisteredClaimNames.Actort*/, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/);
                        $i1.Add("birthdate"/*JwtRegisteredClaimNames.Birthdate*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth"/*ClaimTypes.DateOfBirth*/);
                        $i1.Add("email"/*JwtRegisteredClaimNames.Email*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"/*ClaimTypes.Email*/);
                        $i1.Add("family_name"/*JwtRegisteredClaimNames.FamilyName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"/*ClaimTypes.Surname*/);
                        $i1.Add("gender"/*JwtRegisteredClaimNames.Gender*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender"/*ClaimTypes.Gender*/);
                        $i1.Add("given_name"/*JwtRegisteredClaimNames.GivenName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"/*ClaimTypes.GivenName*/);
                        $i1.Add("nameid"/*JwtRegisteredClaimNames.NameId*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/);
                        $i1.Add("sub"/*JwtRegisteredClaimNames.Sub*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/);
                        $i1.Add("website"/*JwtRegisteredClaimNames.Website*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage"/*ClaimTypes.Webpage*/);
                        $i1.Add("unique_name"/*JwtRegisteredClaimNames.UniqueName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimTypes.Name*/);
                        $i1.Add("oid", "http://schemas.microsoft.com/identity/claims/objectidentifier");
                        $i1.Add("scp", "http://schemas.microsoft.com/identity/claims/scope");
                        $i1.Add("tid", "http://schemas.microsoft.com/identity/claims/tenantid");
                        $i1.Add("acr", "http://schemas.microsoft.com/claims/authnclassreference");
                        $i1.Add("adfs1email", "http://schemas.xmlsoap.org/claims/EmailAddress");
                        $i1.Add("adfs1upn", "http://schemas.xmlsoap.org/claims/UPN");
                        $i1.Add("amr", "http://schemas.microsoft.com/claims/authnmethodsreferences");
                        $i1.Add("authmethod", "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod"/*ClaimTypes.AuthenticationMethod*/);
                        $i1.Add("certapppolicy", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/applicationpolicy");
                        $i1.Add("certauthoritykeyidentifier", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/authoritykeyidentifier");
                        $i1.Add("certbasicconstraints", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/basicconstraints");
                        $i1.Add("certeku", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/eku");
                        $i1.Add("certissuer", "http://schemas.microsoft.com/2012/12/certificatecontext/field/issuer");
                        $i1.Add("certissuername", "http://schemas.microsoft.com/2012/12/certificatecontext/field/issuername");
                        $i1.Add("certkeyusage", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/keyusage");
                        $i1.Add("certnotafter", "http://schemas.microsoft.com/2012/12/certificatecontext/field/notafter");
                        $i1.Add("certnotbefore", "http://schemas.microsoft.com/2012/12/certificatecontext/field/notbefore");
                        $i1.Add("certpolicy", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatepolicy");
                        $i1.Add("certpublickey", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa"/*ClaimTypes.Rsa*/);
                        $i1.Add("certrawdata", "http://schemas.microsoft.com/2012/12/certificatecontext/field/rawdata");
                        $i1.Add("certserialnumber", "http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber"/*ClaimTypes.SerialNumber*/);
                        $i1.Add("certsignaturealgorithm", "http://schemas.microsoft.com/2012/12/certificatecontext/field/signaturealgorithm");
                        $i1.Add("certsubject", "http://schemas.microsoft.com/2012/12/certificatecontext/field/subject");
                        $i1.Add("certsubjectaltname", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/san");
                        $i1.Add("certsubjectkeyidentifier", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/subjectkeyidentifier");
                        $i1.Add("certsubjectname", "http://schemas.microsoft.com/2012/12/certificatecontext/field/subjectname");
                        $i1.Add("certtemplateinformation", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatetemplateinformation");
                        $i1.Add("certtemplatename", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatetemplatename");
                        $i1.Add("certthumbprint", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint"/*ClaimTypes.Thumbprint*/);
                        $i1.Add("certx509version", "http://schemas.microsoft.com/2012/12/certificatecontext/field/x509version");
                        $i1.Add("clientapplication", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application");
                        $i1.Add("clientip", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-ip");
                        $i1.Add("clientuseragent", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-user-agent");
                        $i1.Add("commonname", "http://schemas.xmlsoap.org/claims/CommonName");
                        $i1.Add("denyonlyprimarygroupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid"/*ClaimTypes.DenyOnlyPrimaryGroupSid*/);
                        $i1.Add("denyonlyprimarysid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid"/*ClaimTypes.DenyOnlyPrimarySid*/);
                        $i1.Add("denyonlysid", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid"/*ClaimTypes.DenyOnlySid*/);
                        $i1.Add("devicedispname", "http://schemas.microsoft.com/2012/01/devicecontext/claims/displayname");
                        $i1.Add("deviceid", "http://schemas.microsoft.com/2012/01/devicecontext/claims/identifier");
                        $i1.Add("deviceismanaged", "http://schemas.microsoft.com/2012/01/devicecontext/claims/ismanaged");
                        $i1.Add("deviceostype", "http://schemas.microsoft.com/2012/01/devicecontext/claims/ostype");
                        $i1.Add("deviceosver", "http://schemas.microsoft.com/2012/01/devicecontext/claims/osversion");
                        $i1.Add("deviceowner", "http://schemas.microsoft.com/2012/01/devicecontext/claims/userowner");
                        $i1.Add("deviceregid", "http://schemas.microsoft.com/2012/01/devicecontext/claims/registrationid");
                        $i1.Add("endpointpath", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path");
                        $i1.Add("forwardedclientip", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip");
                        $i1.Add("group", "http://schemas.xmlsoap.org/claims/Group");
                        $i1.Add("groups", "http://schemas.microsoft.com/ws/2008/06/identity/claims/groups");
                        $i1.Add("groupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid"/*ClaimTypes.GroupSid*/);
                        $i1.Add("idp", "http://schemas.microsoft.com/identity/claims/identityprovider");
                        $i1.Add("insidecorporatenetwork", "http://schemas.microsoft.com/ws/2012/01/insidecorporatenetwork");
                        $i1.Add("isregistereduser", "http://schemas.microsoft.com/2012/01/devicecontext/claims/isregistereduser");
                        $i1.Add("ppid", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/privatepersonalidentifier");
                        $i1.Add("primarygroupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid"/*ClaimTypes.PrimaryGroupSid*/);
                        $i1.Add("primarysid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid"/*ClaimTypes.PrimarySid*/);
                        $i1.Add("proxy", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy");
                        $i1.Add("pwdchgurl", "http://schemas.microsoft.com/ws/2012/01/passwordchangeurl");
                        $i1.Add("pwdexpdays", "http://schemas.microsoft.com/ws/2012/01/passwordexpirationdays");
                        $i1.Add("pwdexptime", "http://schemas.microsoft.com/ws/2012/01/passwordexpirationtime");
                        $i1.Add("relyingpartytrustid", "http://schemas.microsoft.com/2012/01/requestcontext/claims/relyingpartytrustid");
                        $i1.Add("role", "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/);
                        $i1.Add("roles", "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/);
                        $i1.Add("upn", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn"/*ClaimTypes.Upn*/);
                        $i1.Add("winaccountname", "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname"/*ClaimTypes.WindowsAccountName*/);
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(55834640504)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244705912)
                    this.longToShortClaimTypeMapping = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(47244705912)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359804024)
                    this.inboundClaimFilter = $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.inboundClaimFilter = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(34359804024)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032952)
            
            static $h = 65656;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949738616),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474902136,
        "f": 50331681
      },
      "n": "InboundClaimTypeMap",
      "d": 65656,
      "h": 42949738616,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42949738616),
//--TRIMMABLE-BOUNDARY-START(51539673208),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064836728,
        "f": 50331681
      },
      "n": "OutboundClaimTypeMap",
      "d": 65656,
      "h": 51539673208,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51539673208),
//--TRIMMABLE-BOUNDARY-START(38654771320),
    {
      "p": $.$$.System.Collections.Generic.ISet$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12884967544,
        "f": 50331681
      },
      "n": "InboundClaimFilter",
      "d": 65656,
      "h": 38654771320,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38654771320)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55834640504),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "shortToLongClaimTypeMapping",
      "d": 65656,
      "h": 55834640504,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834640504),
//--TRIMMABLE-BOUNDARY-START(47244705912),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "longToShortClaimTypeMapping",
      "d": 65656,
      "h": 47244705912,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244705912),
//--TRIMMABLE-BOUNDARY-START(34359804024),
    {
      "t": $.$$.System.Collections.Generic.HashSet$$($.$$.System.String).$h,
      "n": "inboundClaimFilter",
      "d": 65656,
      "h": 34359804024,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359804024)
  ],
  "h": 65656
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65656)
        
        
        //--TRIMMABLE-BOUNDARY-START(458872)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtConstants", ($self) => class JwtConstants
        {
            //--TRIMMABLE-BOUNDARY-START(8590393464)
            /*string*/ static HeaderType = null;
            //--TRIMMABLE-BOUNDARY-END(8590393464)
            
            //--TRIMMABLE-BOUNDARY-START(12885360760)
            /*string*/ static HeaderTypeAlt = null;
            //--TRIMMABLE-BOUNDARY-END(12885360760)
            
            //--TRIMMABLE-BOUNDARY-START(38655164536)
            /*string*/ static TokenType = null;
            //--TRIMMABLE-BOUNDARY-END(38655164536)
            
            //--TRIMMABLE-BOUNDARY-START(42950131832)
            /*string*/ static TokenTypeAlt = null;
            //--TRIMMABLE-BOUNDARY-END(42950131832)
            
            //--TRIMMABLE-BOUNDARY-START(17180328056)
            /*string*/ static JsonCompactSerializationRegex = null;
            //--TRIMMABLE-BOUNDARY-END(17180328056)
            
            //--TRIMMABLE-BOUNDARY-START(21475295352)
            /*string*/ static JweCompactSerializationRegex = null;
            //--TRIMMABLE-BOUNDARY-END(21475295352)
            
            //--TRIMMABLE-BOUNDARY-START(25770262648)
            /*int*/ static JweSegmentCount = 5;
            //--TRIMMABLE-BOUNDARY-END(25770262648)
            
            //--TRIMMABLE-BOUNDARY-START(30065229944)
            /*int*/ static JwsSegmentCount = 3;
            //--TRIMMABLE-BOUNDARY-END(30065229944)
            
            //--TRIMMABLE-BOUNDARY-START(34360197240)
            /*int*/ static MaxJwtSegmentCount = 5;
            //--TRIMMABLE-BOUNDARY-END(34360197240)
            
            //--TRIMMABLE-BOUNDARY-START(4295426168)
            /*string*/ static DirectKeyUseAlg = null;
            //--TRIMMABLE-BOUNDARY-END(4295426168)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393464)
                    this.HeaderType = "JWT";
                    //--TRIMMABLE-BOUNDARY-END(8590393464)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885360760)
                    this.HeaderTypeAlt = "http://openid.net/specs/jwt/1.0";
                    //--TRIMMABLE-BOUNDARY-END(12885360760)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655164536)
                    this.TokenType = "JWT";
                    //--TRIMMABLE-BOUNDARY-END(38655164536)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950131832)
                    this.TokenTypeAlt = "urn:ietf:params:oauth:token-type:jwt";
                    //--TRIMMABLE-BOUNDARY-END(42950131832)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180328056)
                    this.JsonCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                    //--TRIMMABLE-BOUNDARY-END(17180328056)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475295352)
                    this.JweCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                    //--TRIMMABLE-BOUNDARY-END(21475295352)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295426168)
                    this.DirectKeyUseAlg = "dir";
                    //--TRIMMABLE-BOUNDARY-END(4295426168)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 458872;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393464),
    {
      "t": 1310721,
      "n": "HeaderType",
      "d": 458872,
      "h": 8590393464,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393464),
//--TRIMMABLE-BOUNDARY-START(12885360760),
    {
      "t": 1310721,
      "n": "HeaderTypeAlt",
      "d": 458872,
      "h": 12885360760,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360760),
//--TRIMMABLE-BOUNDARY-START(38655164536),
    {
      "t": 1310721,
      "n": "TokenType",
      "d": 458872,
      "h": 38655164536,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655164536),
//--TRIMMABLE-BOUNDARY-START(42950131832),
    {
      "t": 1310721,
      "n": "TokenTypeAlt",
      "d": 458872,
      "h": 42950131832,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950131832),
//--TRIMMABLE-BOUNDARY-START(17180328056),
    {
      "t": 1310721,
      "n": "JsonCompactSerializationRegex",
      "d": 458872,
      "h": 17180328056,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328056),
//--TRIMMABLE-BOUNDARY-START(21475295352),
    {
      "t": 1310721,
      "n": "JweCompactSerializationRegex",
      "d": 458872,
      "h": 21475295352,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295352),
//--TRIMMABLE-BOUNDARY-START(25770262648),
    {
      "t": 655361,
      "n": "JweSegmentCount",
      "d": 458872,
      "h": 25770262648,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770262648),
//--TRIMMABLE-BOUNDARY-START(30065229944),
    {
      "t": 655361,
      "n": "JwsSegmentCount",
      "d": 458872,
      "h": 30065229944,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065229944),
//--TRIMMABLE-BOUNDARY-START(34360197240),
    {
      "t": 655361,
      "n": "MaxJwtSegmentCount",
      "d": 458872,
      "h": 34360197240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360197240),
//--TRIMMABLE-BOUNDARY-START(4295426168),
    {
      "t": 1310721,
      "n": "DirectKeyUseAlg",
      "d": 458872,
      "h": 4295426168,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295426168)
  ],
  "h": 458872
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458872)
        
        
        //--TRIMMABLE-BOUNDARY-START(196728)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimValueTypes", ($self) => class JsonClaimValueTypes
        {
            //--TRIMMABLE-BOUNDARY-START(4295164024)
            /*string*/ static Json = null;
            //--TRIMMABLE-BOUNDARY-END(4295164024)
            
            //--TRIMMABLE-BOUNDARY-START(8590131320)
            /*string*/ static JsonArray = null;
            //--TRIMMABLE-BOUNDARY-END(8590131320)
            
            //--TRIMMABLE-BOUNDARY-START(12885098616)
            /*string*/ static JsonNull = null;
            //--TRIMMABLE-BOUNDARY-END(12885098616)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295164024)
                    this.Json = "JSON";
                    //--TRIMMABLE-BOUNDARY-END(4295164024)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590131320)
                    this.JsonArray = "JSON_ARRAY";
                    //--TRIMMABLE-BOUNDARY-END(8590131320)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885098616)
                    this.JsonNull = "JSON_NULL";
                    //--TRIMMABLE-BOUNDARY-END(12885098616)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 196728;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295164024),
    {
      "t": 1310721,
      "n": "Json",
      "d": 196728,
      "h": 4295164024,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295164024),
//--TRIMMABLE-BOUNDARY-START(8590131320),
    {
      "t": 1310721,
      "n": "JsonArray",
      "d": 196728,
      "h": 8590131320,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131320),
//--TRIMMABLE-BOUNDARY-START(12885098616),
    {
      "t": 1310721,
      "n": "JsonNull",
      "d": 196728,
      "h": 12885098616,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098616)
  ],
  "h": 196728
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonClaimValueTypes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196728)
        
        
        //--TRIMMABLE-BOUNDARY-START(786552)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters", ($self) => class JwtTokenDecryptionParameters extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(90195099768)
            /*byte[]*/ CipherTextBytes = null;
            //--TRIMMABLE-BOUNDARY-END(90195099768)
            
            //--TRIMMABLE-BOUNDARY-START(240518955128)
            /*byte[]*/ HeaderAsciiBytes = null;
            //--TRIMMABLE-BOUNDARY-END(240518955128)
            
            //--TRIMMABLE-BOUNDARY-START(249108889720)
            /*byte[]*/ InitializationVectorBytes = null;
            //--TRIMMABLE-BOUNDARY-END(249108889720)
            
            //--TRIMMABLE-BOUNDARY-START(81605165176)
            /*byte[]*/ AuthenticationTagBytes = null;
            //--TRIMMABLE-BOUNDARY-END(81605165176)
            
            //--TRIMMABLE-BOUNDARY-START(73015230584)
            /*string*/ Alg = null;
            //--TRIMMABLE-BOUNDARY-END(73015230584)
            
            //--TRIMMABLE-BOUNDARY-START(77310197880)
            /*string*/ AuthenticationTag = null;
            //--TRIMMABLE-BOUNDARY-END(77310197880)
            
            //--TRIMMABLE-BOUNDARY-START(85900132472)
            /*string*/ Ciphertext = null;
            //--TRIMMABLE-BOUNDARY-END(85900132472)
            
            //--TRIMMABLE-BOUNDARY-START(94490067064)
            /*Func<byte[], string, int, string>*/ DecompressionFunction = null;
            //--TRIMMABLE-BOUNDARY-END(94490067064)
            
            //--TRIMMABLE-BOUNDARY-START(98785034360)
            /*string*/ Enc = null;
            //--TRIMMABLE-BOUNDARY-END(98785034360)
            
            //--TRIMMABLE-BOUNDARY-START(103080001656)
            /*string*/ EncodedHeader = null;
            //--TRIMMABLE-BOUNDARY-END(103080001656)
            
            //--TRIMMABLE-BOUNDARY-START(107374968952)
            /*string*/ EncodedToken = null;
            //--TRIMMABLE-BOUNDARY-END(107374968952)
            
            //--TRIMMABLE-BOUNDARY-START(244813922424)
            /*string*/ InitializationVector = null;
            //--TRIMMABLE-BOUNDARY-END(244813922424)
            
            //--TRIMMABLE-BOUNDARY-START(253403857016)
            /*IEnumerable<SecurityKey>*/ Keys$1 = null;
            //--TRIMMABLE-BOUNDARY-END(253403857016)
            
            //--TRIMMABLE-BOUNDARY-START(257698824312)
            /*int*/ MaximumDeflateSize = 0;
            //--TRIMMABLE-BOUNDARY-END(257698824312)
            
            //--TRIMMABLE-BOUNDARY-START(390842810488)
            /*string*/ Zip = null;
            //--TRIMMABLE-BOUNDARY-END(390842810488)
            
            //--TRIMMABLE-BOUNDARY-START(68720263288)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720263288)
            
            //default member initializer
            constructor()
            {
                super();
                this.MaximumDeflateSize = 256000;
            }
            static $h = 786552;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195099768),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324641912,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300648497272,
        "f": 83886081
      },
      "n": "CipherTextBytes",
      "d": 786552,
      "h": 90195099768,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195099768),
//--TRIMMABLE-BOUNDARY-START(240518955128),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274314872,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343598170232,
        "f": 83886081
      },
      "n": "HeaderAsciiBytes",
      "d": 786552,
      "h": 240518955128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240518955128),
//--TRIMMABLE-BOUNDARY-START(249108889720),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454184056,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360778039416,
        "f": 83886081
      },
      "n": "InitializationVectorBytes",
      "d": 786552,
      "h": 249108889720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249108889720),
//--TRIMMABLE-BOUNDARY-START(81605165176),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144772728,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468628088,
        "f": 83886081
      },
      "n": "AuthenticationTagBytes",
      "d": 786552,
      "h": 81605165176,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605165176),
//--TRIMMABLE-BOUNDARY-START(73015230584),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964903544,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288758904,
        "f": 83886081
      },
      "n": "Alg",
      "d": 786552,
      "h": 73015230584,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015230584),
//--TRIMMABLE-BOUNDARY-START(77310197880),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554838136,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878693496,
        "f": 83886081
      },
      "n": "AuthenticationTag",
      "d": 786552,
      "h": 77310197880,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310197880),
//--TRIMMABLE-BOUNDARY-START(85900132472),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734707320,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058562680,
        "f": 83886081
      },
      "n": "Ciphertext",
      "d": 786552,
      "h": 85900132472,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900132472),
//--TRIMMABLE-BOUNDARY-START(94490067064),
    {
      "p": $.$$.System.Func$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.String, $.$$.System.Int32, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914576504,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309238431864,
        "f": 83886081
      },
      "n": "DecompressionFunction",
      "d": 786552,
      "h": 94490067064,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490067064),
//--TRIMMABLE-BOUNDARY-START(98785034360),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504511096,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828366456,
        "f": 83886081
      },
      "n": "Enc",
      "d": 786552,
      "h": 98785034360,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785034360),
//--TRIMMABLE-BOUNDARY-START(103080001656),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094445688,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418301048,
        "f": 83886081
      },
      "n": "EncodedHeader",
      "d": 786552,
      "h": 103080001656,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080001656),
//--TRIMMABLE-BOUNDARY-START(107374968952),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684380280,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335008235640,
        "f": 83886081
      },
      "n": "EncodedToken",
      "d": 786552,
      "h": 107374968952,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374968952),
//--TRIMMABLE-BOUNDARY-START(244813922424),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864249464,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352188104824,
        "f": 83886081
      },
      "n": "InitializationVector",
      "d": 786552,
      "h": 244813922424,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244813922424),
//--TRIMMABLE-BOUNDARY-START(253403857016),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044118648,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369367974008,
        "f": 83886081
      },
      "n": "Keys",
      "o": "@$1",
      "d": 786552,
      "h": 253403857016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403857016),
//--TRIMMABLE-BOUNDARY-START(257698824312),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634053240,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377957908600,
        "f": 83886081
      },
      "n": "MaximumDeflateSize",
      "d": 786552,
      "h": 257698824312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698824312),
//--TRIMMABLE-BOUNDARY-START(390842810488),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223987832,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386547843192,
        "f": 83886081
      },
      "n": "Zip",
      "d": 786552,
      "h": 390842810488,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(390842810488)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(68720263288),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786552,
      "h": 68720263288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720263288)
  ],
  "h": 786552
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786552)
        
        
        //--TRIMMABLE-BOUNDARY-START(852088)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities", ($self) => class JwtTokenUtilities extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245492344)
            static /*global::System.Text.RegularExpressions.Regex */ CreateJwsRegex()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245492344);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.Instance;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245492344)
            
            //--TRIMMABLE-BOUNDARY-START(42950525048)
            static /*global::System.Text.RegularExpressions.Regex */ CreateJweRegex()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950525048);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.Instance;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950525048)
            
            //--TRIMMABLE-BOUNDARY-START(60130394232)
            static /*ValidationResult<string, ValidationError> */ DecryptJwtToken(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*JwtTokenDecryptionParameters*/ decryptionParameters, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 34, 1)));
                }
                if (decryptionParameters === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("decryptionParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 43, 1)));
                }
                /*bool*/ let decryptionSucceeded = false;
                /*bool*/ let algorithmNotSupportedByCryptoProvider = false;
                /*byte[]*/ let decryptedTokenBytes = null;
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*string*/ let zipAlgorithm = null;
                var $en2 = decryptionParameters.Keys$1.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                        if (cryptoProviderFactory === null)
                        {
                            continue;
                        }
                        try
                        {
                            if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Enc, key))
                            {
                                algorithmNotSupportedByCryptoProvider = true;
                                continue;
                            }
                            /*ValidationResult<string, ValidationError>*/ let result = validationParameters.AlgorithmValidator.Microsoft$IdentityModel$Tokens$Experimental$IAlgorithmValidator$ValidateAlgorithm(zipAlgorithm, jsonWebToken, validationParameters, callContext);
                            if (!result.Succeeded)
                            {
                                (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(result.Error.MessageDetail.Message);
                                continue;
                            }
                            decryptedTokenBytes = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptToken(cryptoProviderFactory, key, jsonWebToken.Enc, jsonWebToken.CipherTextBytes, jsonWebToken.HeaderAsciiBytes, jsonWebToken.InitializationVectorBytes, jsonWebToken.AuthenticationTagBytes);
                            zipAlgorithm = jsonWebToken.Zip;
                            decryptionSucceeded = true;
                            break;
                        }
                        catch(ex)
                        {
                            (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                        }
                        if (key !== null)
                        {
                            (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(key.KeyId);
                        }
                    }
                }
                if (!decryptionSucceeded)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetDecryptionError(decryptionParameters, algorithmNotSupportedByCryptoProvider, exceptionStrings, keysAttempted, callContext));
                }
                try
                {
                    /*string*/ let decodedString;
                    if ($.$$.System.String.IsNullOrEmpty(zipAlgorithm))
                    {
                        decodedString = $.$$.System.Text.Encoding.UTF8.GetString$1(decryptedTokenBytes);
                    }
                    else 
                    {
                        decodedString = decryptionParameters.DecompressionFunction.Invoke(decryptedTokenBytes, zipAlgorithm, decryptionParameters.MaximumDeflateSize);
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit$1(decodedString);
                }
                catch(ex)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$1(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$2($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetIDX10679LogMessage(zipAlgorithm)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecompressionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 143, 1), ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130394232)
            
            //--TRIMMABLE-BOUNDARY-START(85900198008)
            static /*ValidationError */ GetDecryptionError(/*JwtTokenDecryptionParameters*/ decryptionParameters, /*bool*/ algorithmNotSupportedByCryptoProvider, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900198008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(keysAttempted === null))
                {
                    const $t1 = exceptionStrings;
                    return new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10603: Decryption failed. Keys tried: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'"/*TokenLogMessages.IDX10603*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Text.StringBuilder.ToString.call(keysAttempted)), $.$ifnn($t1, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t)) ?? $.$$.System.String.Empty, $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 167, 1));
                }
                else if (algorithmNotSupportedByCryptoProvider)
                {
                    return new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10619: Decryption failed. Algorithm: '{0}'. Either the Encryption Algorithm: '{1}' or none of the Security Keys are supported by the CryptoProviderFactory."/*TokenLogMessages.IDX10619*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Alg), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Enc) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 180, 1));
                }
                else 
                {
                    return new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 192, 1));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900198008)
            
            //--TRIMMABLE-BOUNDARY-START(4295819384)
            /*int*/ static _regexMatchTimeoutMilliseconds = 100;
            //--TRIMMABLE-BOUNDARY-END(4295819384)
            
            //--TRIMMABLE-BOUNDARY-START(8590786680)
            /*string*/ static _unrecognizedEncodedToken = null;
            //--TRIMMABLE-BOUNDARY-END(8590786680)
            
            //--TRIMMABLE-BOUNDARY-START(111670001784)
            /*Regex*/ static RegexJws = null;
            //--TRIMMABLE-BOUNDARY-END(111670001784)
            
            //--TRIMMABLE-BOUNDARY-START(107375034488)
            /*Regex*/ static RegexJwe = null;
            //--TRIMMABLE-BOUNDARY-END(107375034488)
            
            //--TRIMMABLE-BOUNDARY-START(73015296120)
            /*List<string>*/ static DefaultHeaderParameters = null;
            //--TRIMMABLE-BOUNDARY-END(73015296120)
            
            //--TRIMMABLE-BOUNDARY-START(38655557752)
            static /*string */ CreateEncodedSignature$2(/*string*/ input, /*SigningCredentials*/ signingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(input, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials");
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm);
                if (signatureProvider === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null))));
                }
                try
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(signatureProvider.Sign$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(input)));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655557752)
            
            //--TRIMMABLE-BOUNDARY-START(34360590456)
            static /*string */ CreateEncodedSignature$1(/*string*/ input, /*SigningCredentials*/ signingCredentials, /*bool*/ cacheProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(input, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials");
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = cryptoProviderFactory.CreateForSigning(signingCredentials.Key, signingCredentials.Algorithm, cacheProvider);
                if (signatureProvider === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null))));
                }
                try
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14201: Creating raw signature using the signature credentials. Caching SignatureProvider: '{0}'."/*LogMessages.IDX14201*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(cacheProvider, $.$$.System.Boolean)) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(signatureProvider.Sign$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(input)));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360590456)
            
            //--TRIMMABLE-BOUNDARY-START(30065623160)
            static /*byte[] */ CreateEncodedSignature(/*byte[]*/ input, /*int*/ offset, /*int*/ count, /*SigningCredentials*/ signingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (input === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    return null;
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = $.$firstOf(cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm), () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null)))) });
                try
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    }
                    return signatureProvider.Sign(input, offset, count);
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065623160)
            
            //--TRIMMABLE-BOUNDARY-START(51540459640)
            static /*bool */ CreateSignature(/*ReadOnlySpan<byte>*/ data, /*Span<byte>*/ destination, /*SigningCredentials*/ signingCredentials, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540459640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bytesWritten.$v = 0;
                if (signingCredentials === null)
                {
                    return false;
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = $.$firstOf(cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm), () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null)))) });
                try
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    }
                    return signatureProvider.Sign$2(data, destination, bytesWritten);
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540459640)
            
            //--TRIMMABLE-BOUNDARY-START(55835426936)
            static /*string */ DecompressToken(/*byte[]*/ tokenBytes, /*string*/ algorithm, /*int*/ maximumDeflateSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenBytes === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenBytes");
                }
                if ($.$$.System.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("algorithm");
                }
                if (!$.$mit.Microsoft.IdentityModel.Tokens.CompressionProviderFactory.Default.IsSupportedAlgorithm(algorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.NotSupportedException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10682: Compression algorithm '{0}' is not supported."/*TokenLogMessages.IDX10682*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(algorithm) ], null, null))));
                }
                /*var*/ let compressionProvider = $.$mit.Microsoft.IdentityModel.Tokens.CompressionProviderFactory.Default.CreateCompressionProvider(algorithm, maximumDeflateSize);
                /*var*/ let decompressedBytes = compressionProvider.Microsoft$IdentityModel$Tokens$ICompressionProvider$Decompress(tokenBytes);
                return decompressedBytes !== null ? $.$$.System.Text.Encoding.UTF8.GetString$1(decompressedBytes) : (() =>
                {
        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecompressionFailedException().$ctor$14($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetIDX10679LogMessage(algorithm)))        })();
            }
            //--TRIMMABLE-BOUNDARY-END(55835426936)
            
            //--TRIMMABLE-BOUNDARY-START(90195165304)
            static /*string */ GetIDX10679LogMessage(/*string*/ algorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10679: Failed to decompress using algorithm '{0}'."/*TokenLogMessages.IDX10679*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(algorithm) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(90195165304)
            
            //--TRIMMABLE-BOUNDARY-START(64425361528)
            static /*string */ DecryptJwtToken$1(/*SecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters, /*JwtTokenDecryptionParameters*/ decryptionParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425361528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (decryptionParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("decryptionParameters");
                }
                /*bool*/ let decryptionSucceeded = false;
                /*bool*/ let algorithmNotSupportedByCryptoProvider = false;
                /*byte[]*/ let decryptedTokenBytes = null;
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*string*/ let zipAlgorithm = null;
                var $en2 = decryptionParameters.Keys$1.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                        if (cryptoProviderFactory === null)
                        {
                            if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning("IDX10607: Decryption skipping key: '{0}', both validationParameters.CryptoProviderFactory and key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10607*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                            }
                            continue;
                        }
                        try
                        {
                            if (!cryptoProviderFactory.IsSupportedAlgorithm(decryptionParameters.Enc, key))
                            {
                                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                                {
                                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning("IDX10611: Decryption failed. Encryption is not supported for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10611*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Enc), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                                }
                                algorithmNotSupportedByCryptoProvider = true;
                                continue;
                            }
                            $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAlgorithm(decryptionParameters.Enc, key, securityToken, validationParameters);
                            decryptedTokenBytes = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptToken(cryptoProviderFactory, key, decryptionParameters.Enc, decryptionParameters.CipherTextBytes, decryptionParameters.HeaderAsciiBytes, decryptionParameters.InitializationVectorBytes, decryptionParameters.AuthenticationTagBytes);
                            zipAlgorithm = decryptionParameters.Zip;
                            decryptionSucceeded = true;
                            break;
                        }
                        catch(ex)
                        {
                            (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                        }
                        if (key !== null)
                        {
                            (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(key.KeyId);
                        }
                    }
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ValidateDecryption(decryptionParameters, decryptionSucceeded, algorithmNotSupportedByCryptoProvider, exceptionStrings, keysAttempted);
                try
                {
                    if ($.$$.System.String.IsNullOrEmpty(zipAlgorithm))
                    {
                        return $.$$.System.Text.Encoding.UTF8.GetString$1(decryptedTokenBytes);
                    }
                    return decryptionParameters.DecompressionFunction.Invoke(decryptedTokenBytes, zipAlgorithm, decryptionParameters.MaximumDeflateSize);
                }
                catch(ex)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecompressionFailedException().$ctor$13($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetIDX10679LogMessage(zipAlgorithm), ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425361528)
            
            //--TRIMMABLE-BOUNDARY-START(128849870968)
            static /*void */ ValidateDecryption(/*JwtTokenDecryptionParameters*/ decryptionParameters, /*bool*/ decryptionSucceeded, /*bool*/ algorithmNotSupportedByCryptoProvider, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849870968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!decryptionSucceeded && !(keysAttempted === null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10603: Decryption failed. Keys tried: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'"/*TokenLogMessages.IDX10603*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Text.StringBuilder.ToString.call(keysAttempted)), exceptionStrings ?? $.$$.System.String.Empty, $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                }
                if (!decryptionSucceeded && algorithmNotSupportedByCryptoProvider)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10619: Decryption failed. Algorithm: '{0}'. Either the Encryption Algorithm: '{1}' or none of the Security Keys are supported by the CryptoProviderFactory."/*TokenLogMessages.IDX10619*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Alg), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Enc) ], null, null))));
                }
                if (!decryptionSucceeded)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849870968)
            
            //--TRIMMABLE-BOUNDARY-START(68720328824)
            static /*byte[] */ DecryptToken(/*CryptoProviderFactory*/ cryptoProviderFactory, /*SecurityKey*/ key, /*string*/ encAlg, /*byte[]*/ ciphertext, /*byte[]*/ headerAscii, /*byte[]*/ initializationVector, /*byte[]*/ authenticationTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let decryptionProvider = null;
                try
                {
                    decryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(key, encAlg);
                    if (decryptionProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10610: Decryption failed. Could not create decryption provider. Key: '{0}', Algorithm: '{1}'."/*TokenLogMessages.IDX10610*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encAlg) ], null, null))));
                    }
                    return decryptionProvider.Decrypt(ciphertext, headerAscii, initializationVector, authenticationTag);
                }
                finally
                {
                    decryptionProvider?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720328824)
            
            //--TRIMMABLE-BOUNDARY-START(77310263416)
            static /*byte[] */ GenerateKeyBytes(/*int*/ sizeInBits)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let key = null;
                if (sizeInBits !== 256 && sizeInBits !== 384 && sizeInBits !== 512)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$13("IDX10401: Invalid requested key size. Valid key sizes are: 256, 384, and 512."/*TokenLogMessages.IDX10401*/, "sizeInBits"));
                }
                let aes = null;
                try
                {
                    aes = $.$sscr.System.Security.Cryptography.Aes.Create$2();
                    /*int*/ let halfSizeInBytes = sizeInBits >> 4;
                    key = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [halfSizeInBytes << 1], null);
                    aes.KeySize = sizeInBits >> 1;
                    aes.GenerateKey();
                    $.$$.System.Array.Copy(aes.Key, key, halfSizeInBytes);
                    aes.GenerateKey();
                    $.$$.System.Array.Copy$2(aes.Key, 0, key, halfSizeInBytes, halfSizeInBytes);
                }
                finally
                {
                    aes?.System$IDisposable$Dispose();
                }
                return key;
            }
            //--TRIMMABLE-BOUNDARY-END(77310263416)
            
            //--TRIMMABLE-BOUNDARY-START(94490132600)
            static /*SecurityKey */ GetSecurityKey(/*EncryptingCredentials*/ encryptingCredentials, /*CryptoProviderFactory*/ cryptoProviderFactory, /*IDictionary<string, object>*/ additionalHeaderClaims, /*out byte[]*/ wrappedKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SecurityKey*/ let securityKey = null;
                /*KeyWrapProvider*/ let kwProvider = null;
                wrappedKey.$v = null;
                if ($.$$.System.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg))
                {
                    if (!cryptoProviderFactory.IsSupportedAlgorithm(encryptingCredentials.Enc, encryptingCredentials.Key))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10615: Encryption failed. No support for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10615*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null))));
                    }
                    securityKey = encryptingCredentials.Key;
                }
                else if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(encryptingCredentials.Alg, [$.$$.System.String]))
                {
                    /*string*/ let apu = null, apv = null;
                    if (additionalHeaderClaims !== null && additionalHeaderClaims.System$Collections$Generic$ICollection$$$Count > 0)
                    {
                        /*object*/ let objApu;
                        if (additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$TryGetValue("apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => objApu, ($v) => objApu = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                        {
                            const $t2 = objApu;
                            apu = $.$ifnn($t2, ($t) => $.$$.System.Object.ToString.call($t));
                        }
                        /*object*/ let objApv;
                        if (additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$TryGetValue("apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => objApv, ($v) => objApv = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                        {
                            const $t3 = objApv;
                            apv = $.$ifnn($t3, ($t) => $.$$.System.Object.ToString.call($t));
                        }
                    }
                    /*EcdhKeyExchangeProvider*/ let ecdhKeyExchangeProvider = new $.$mit.Microsoft.IdentityModel.Tokens.EcdhKeyExchangeProvider().$ctor$1($.$as(encryptingCredentials.Key, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey), encryptingCredentials.KeyExchangePublicKey, encryptingCredentials.Alg, encryptingCredentials.Enc);
                    /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                    kwProvider = cryptoProviderFactory.CreateKeyWrapProvider$1(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                    if ($.$$.System.String.Equals$4.call("A128KW"/*SecurityAlgorithms.Aes128KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(256));
                    }
                    else if ($.$$.System.String.Equals$4.call("A192KW"/*SecurityAlgorithms.Aes192KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(384));
                    }
                    else if ($.$$.System.String.Equals$4.call("A256KW"/*SecurityAlgorithms.Aes256KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(512));
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10617: Encryption failed. Keywrap is only supported for: '{0}', '{1}' and '{2}'. The content encryption specified is: '{3}'."/*TokenLogMessages.IDX10617*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A128KW"/*SecurityAlgorithms.Aes128KW*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A192KW"/*SecurityAlgorithms.Aes192KW*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A256KW"/*SecurityAlgorithms.Aes256KW*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(kwProvider.Algorithm) ], null, null))));
                    }
                    wrappedKey.$v = kwProvider.WrapKey(($.$cast(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey)).Key);
                }
                else 
                {
                    if (!cryptoProviderFactory.IsSupportedAlgorithm(encryptingCredentials.Alg, encryptingCredentials.Key))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10615: Encryption failed. No support for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10615*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Alg), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null))));
                    }
                    if ($.$$.System.String.Equals$5.call("A128CBC-HS256"/*SecurityAlgorithms.Aes128CbcHmacSha256*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(256));
                    }
                    else if ($.$$.System.String.Equals$5.call("A192CBC-HS384"/*SecurityAlgorithms.Aes192CbcHmacSha384*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(384));
                    }
                    else if ($.$$.System.String.Equals$5.call("A256CBC-HS512"/*SecurityAlgorithms.Aes256CbcHmacSha512*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(512));
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10617: Encryption failed. Keywrap is only supported for: '{0}', '{1}' and '{2}'. The content encryption specified is: '{3}'."/*TokenLogMessages.IDX10617*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A128CBC-HS256"/*SecurityAlgorithms.Aes128CbcHmacSha256*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A192CBC-HS384"/*SecurityAlgorithms.Aes192CbcHmacSha384*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A256CBC-HS512"/*SecurityAlgorithms.Aes256CbcHmacSha512*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Enc) ], null, null))));
                    }
                    kwProvider = cryptoProviderFactory.CreateKeyWrapProvider$1(encryptingCredentials.Key, encryptingCredentials.Alg);
                    wrappedKey.$v = kwProvider.WrapKey(($.$cast(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey)).Key);
                }
                return securityKey;
            }
            //--TRIMMABLE-BOUNDARY-END(94490132600)
            
            //--TRIMMABLE-BOUNDARY-START(81605230712)
            static /*IEnumerable<SecurityKey> */ GetAllDecryptionKeys(/*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters === null)
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("validationParameters");
                }
                /*var*/ let decryptionKeys = new ($.$$.System.Collections.ObjectModel.Collection$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey))().$ctor$1();
                if (validationParameters.TokenDecryptionKey !== null)
                {
                    decryptionKeys.Add(validationParameters.TokenDecryptionKey);
                }
                if (validationParameters.TokenDecryptionKeys !== null)
                {
                    var $en3 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            decryptionKeys.Add(key);
                        }
                    }
                }
                return decryptionKeys;
            }
            //--TRIMMABLE-BOUNDARY-END(81605230712)
            
            //--TRIMMABLE-BOUNDARY-START(124554903672)
            static /*string */ SafeLogJwtToken(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554903672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return $.$$.System.String.Empty;
                }
                let token;
                if (!($.$is(obj, $.$$.System.String, { set $v(v){ token = v; } })))
                {
                    return $.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(obj));
                }
                /*int*/ let lastDot = $.$$.System.String.LastIndexOf$2.call(token, /*.*/ 46);
                if (lastDot === -1)
                {
                    return "UnrecognizedEncodedToken"/*_unrecognizedEncodedToken*/;
                }
                return $.$$.System.String.Substring.call(token, 0, lastDot);
            }
            //--TRIMMABLE-BOUNDARY-END(124554903672)
            
            //--TRIMMABLE-BOUNDARY-START(120259936376)
            static /*SecurityKey */ ResolveTokenSigningKey$1(/*string*/ kid, /*string*/ x5t, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259936376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey(kid, x5t, (configuration?.SigningKeys ?? null)) ?? $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey(kid, x5t, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ConcatSigningKeys(validationParameters));
            }
            //--TRIMMABLE-BOUNDARY-END(120259936376)
            
            //--TRIMMABLE-BOUNDARY-START(115964969080)
            static /*SecurityKey */ ResolveTokenSigningKey(/*string*/ kid, /*string*/ x5t, /*IEnumerable<SecurityKey>*/ signingKeys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (signingKeys === null)
                {
                    return null;
                }
                var $en2 = signingKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var signingKey = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (signingKey !== null)
                        {
                            let x509Key;
                            if ($.$is(signingKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey, { set $v(v){ x509Key = v; } }))
                            {
                                if ((!$.$$.System.String.IsNullOrEmpty(kid) && $.$$.System.String.Equals$2(signingKey.KeyId, kid, 5/*StringComparison.OrdinalIgnoreCase*/)) || (!$.$$.System.String.IsNullOrEmpty(x5t) && $.$$.System.String.Equals$2(x509Key.X5t, x5t, 5/*StringComparison.OrdinalIgnoreCase*/)))
                                {
                                    return signingKey;
                                }
                            }
                            else if (!$.$$.System.String.IsNullOrEmpty(signingKey.KeyId))
                            {
                                if ($.$$.System.String.Equals$3(signingKey.KeyId, kid) || $.$$.System.String.Equals$3(signingKey.KeyId, x5t))
                                {
                                    return signingKey;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(115964969080)
            
            //--TRIMMABLE-BOUNDARY-START(25770655864)
            static /*int */ CountJwtTokenPart(/*string*/ token, /*int*/ maxCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let count = 1;
                /*var*/ let index = 0;
                while(index < token.length)
                {
                    /*var*/ let dotIndex = $.$$.System.String.IndexOf$1.call(token, /*.*/ 46, index);
                    if (dotIndex < 0)
                    {
                        break;
                    }
                    count++;
                    index = ((dotIndex + 1) | 0);
                    if (count === maxCount)
                    {
                        break;
                    }
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655864)
            
            //--TRIMMABLE-BOUNDARY-START(21475688568)
            static /*IEnumerable<SecurityKey> */ ConcatSigningKeys(/*TokenValidationParameters*/ tvp)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (tvp === null)
                    {
                        return;
                    }
                    yield tvp.IssuerSigningKey;
                    if (tvp.IssuerSigningKeys !== null)
                    {
                        var $en4 = tvp.IssuerSigningKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                yield key;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(21475688568)
            
            //--TRIMMABLE-BOUNDARY-START(103080067192)
            static /*string */ GetStringClaimValueType$1(/*string*/ str)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080067192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetStringClaimValueType(str, $.$$.System.String.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(103080067192)
            
            //--TRIMMABLE-BOUNDARY-START(98785099896)
            static /*string */ GetStringClaimValueType(/*string*/ str, /*string*/ claimType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785099896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.String.IsNullOrEmpty(claimType) && !$.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.TryAllStringClaimsAsDateTime && $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsKnownToNotBeDateTime(claimType))
                {
                    return "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
                }
                /*DateTime*/ let dateTimeValue;
                if ($.$$.System.DateTime.TryParse$5(str, $.$ref(() => dateTimeValue, ($v) => dateTimeValue = $v, $.$$.System.DateTime)))
                {
                    /*string*/ let dtUniversal = dateTimeValue.ToUniversalTime().ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    if ($.$$.System.String.Equals$4.call(dtUniversal, str, 4/*StringComparison.Ordinal*/))
                    {
                        return "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/;
                    }
                }
                return "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099896)
            
            //--TRIMMABLE-BOUNDARY-START(17180721272)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721272)
            
            //--TRIMMABLE-BOUNDARY-START(12885753976)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590786680)
                    this._unrecognizedEncodedToken = "UnrecognizedEncodedToken";
                    //--TRIMMABLE-BOUNDARY-END(8590786680)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670001784)
                    this.RegexJws = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateJwsRegex();
                    //--TRIMMABLE-BOUNDARY-END(111670001784)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375034488)
                    this.RegexJwe = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateJweRegex();
                    //--TRIMMABLE-BOUNDARY-END(107375034488)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015296120)
                    this.DefaultHeaderParameters = (() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("alg"/*JwtHeaderParameterNames.Alg*/);
                        $i1.Add("kid"/*JwtHeaderParameterNames.Kid*/);
                        $i1.Add("x5t"/*JwtHeaderParameterNames.X5t*/);
                        $i1.Add("enc"/*JwtHeaderParameterNames.Enc*/);
                        $i1.Add("zip"/*JwtHeaderParameterNames.Zip*/);
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(73015296120)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885753976)
            
            static $h = 852088;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130394232),
    {
      "r": $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "decryptionParameters",
          "p": 786552
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "DecryptJwtToken",
      "d": 852088,
      "h": 60130394232,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(60130394232),
//--TRIMMABLE-BOUNDARY-START(85900198008),
    {
      "r": 9568375,
      "p": [
        {
          "n": "decryptionParameters",
          "p": 786552
        },
        {
          "n": "algorithmNotSupportedByCryptoProvider",
          "p": 262145
        },
        {
          "n": "exceptionStrings",
          "p": 167051265
        },
        {
          "n": "keysAttempted",
          "p": 167051265
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "GetDecryptionError",
      "d": 852088,
      "h": 85900198008,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85900198008),
//--TRIMMABLE-BOUNDARY-START(47245492344),
    {
      "r": 1900602,
      "n": "CreateJwsRegex",
      "d": 852088,
      "h": 47245492344,
      "f": 16777250,
      "a": [
        {
          "t": 1245242,
          "c": 25771049018,
          "a": [
            {
              "v": "^[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]*$",
              "t": 1310721
            },
            {
              "v": 512,
              "t": 3539002
            },
            {
              "v": 100,
              "t": 655361
            }
          ]
        },
        {
          "t": 54329345,
          "c": 12939231233,
          "a": [
            {
              "v": "System.Text.RegularExpressions.Generator",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245492344),
//--TRIMMABLE-BOUNDARY-START(42950525048),
    {
      "r": 1900602,
      "n": "CreateJweRegex",
      "d": 852088,
      "h": 42950525048,
      "f": 16777250,
      "a": [
        {
          "t": 1245242,
          "c": 25771049018,
          "a": [
            {
              "v": "^[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B$",
              "t": 1310721
            },
            {
              "v": 512,
              "t": 3539002
            },
            {
              "v": 100,
              "t": 655361
            }
          ]
        },
        {
          "t": 54329345,
          "c": 12939231233,
          "a": [
            {
              "v": "System.Text.RegularExpressions.Generator",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950525048),
//--TRIMMABLE-BOUNDARY-START(38655557752),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        }
      ],
      "n": "CreateEncodedSignature",
      "o": "@$2",
      "d": 852088,
      "h": 38655557752,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655557752),
//--TRIMMABLE-BOUNDARY-START(34360590456),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "cacheProvider",
          "p": 262145
        }
      ],
      "n": "CreateEncodedSignature",
      "o": "@$1",
      "d": 852088,
      "h": 34360590456,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360590456),
//--TRIMMABLE-BOUNDARY-START(30065623160),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        }
      ],
      "n": "CreateEncodedSignature",
      "d": 852088,
      "h": 30065623160,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065623160),
//--TRIMMABLE-BOUNDARY-START(51540459640),
    {
      "r": 262145,
      "p": [
        {
          "n": "data",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "CreateSignature",
      "d": 852088,
      "h": 51540459640,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51540459640),
//--TRIMMABLE-BOUNDARY-START(55835426936),
    {
      "r": 1310721,
      "p": [
        {
          "n": "tokenBytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "algorithm",
          "p": 1310721
        },
        {
          "n": "maximumDeflateSize",
          "p": 655361
        }
      ],
      "n": "DecompressToken",
      "d": 852088,
      "h": 55835426936,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835426936),
//--TRIMMABLE-BOUNDARY-START(90195165304),
    {
      "r": 1310721,
      "p": [
        {
          "n": "algorithm",
          "p": 1310721
        }
      ],
      "n": "GetIDX10679LogMessage",
      "d": 852088,
      "h": 90195165304,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90195165304),
//--TRIMMABLE-BOUNDARY-START(64425361528),
    {
      "r": 1310721,
      "p": [
        {
          "n": "securityToken",
          "p": 13762679
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "decryptionParameters",
          "p": 786552
        }
      ],
      "n": "DecryptJwtToken",
      "o": "@$1",
      "d": 852088,
      "h": 64425361528,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64425361528),
//--TRIMMABLE-BOUNDARY-START(128849870968),
    {
      "r": 65537,
      "p": [
        {
          "n": "decryptionParameters",
          "p": 786552
        },
        {
          "n": "decryptionSucceeded",
          "p": 262145
        },
        {
          "n": "algorithmNotSupportedByCryptoProvider",
          "p": 262145
        },
        {
          "n": "exceptionStrings",
          "p": 167051265
        },
        {
          "n": "keysAttempted",
          "p": 167051265
        }
      ],
      "n": "ValidateDecryption",
      "d": 852088,
      "h": 128849870968,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(128849870968),
//--TRIMMABLE-BOUNDARY-START(68720328824),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "cryptoProviderFactory",
          "p": 2949239
        },
        {
          "n": "key",
          "p": 13631607
        },
        {
          "n": "encAlg",
          "p": 1310721
        },
        {
          "n": "ciphertext",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "headerAscii",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "initializationVector",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "authenticationTag",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "DecryptToken",
      "d": 852088,
      "h": 68720328824,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720328824),
//--TRIMMABLE-BOUNDARY-START(77310263416),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "sizeInBits",
          "p": 655361
        }
      ],
      "n": "GenerateKeyBytes",
      "d": 852088,
      "h": 77310263416,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310263416),
//--TRIMMABLE-BOUNDARY-START(94490132600),
    {
      "r": 13631607,
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "cryptoProviderFactory",
          "p": 2949239
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "wrappedKey",
          "p": $.$typeArray($.$$.System.Byte).$h,
          "f": 2
        }
      ],
      "n": "GetSecurityKey",
      "d": 852088,
      "h": 94490132600,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(94490132600),
//--TRIMMABLE-BOUNDARY-START(81605230712),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,
      "p": [
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "GetAllDecryptionKeys",
      "d": 852088,
      "h": 81605230712,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605230712),
//--TRIMMABLE-BOUNDARY-START(124554903672),
    {
      "r": 1310721,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "SafeLogJwtToken",
      "d": 852088,
      "h": 124554903672,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(124554903672),
//--TRIMMABLE-BOUNDARY-START(120259936376),
    {
      "r": 13631607,
      "p": [
        {
          "n": "kid",
          "p": 1310721
        },
        {
          "n": "x5t",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ResolveTokenSigningKey",
      "o": "@$1",
      "d": 852088,
      "h": 120259936376,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(120259936376),
//--TRIMMABLE-BOUNDARY-START(115964969080),
    {
      "r": 13631607,
      "p": [
        {
          "n": "kid",
          "p": 1310721
        },
        {
          "n": "x5t",
          "p": 1310721
        },
        {
          "n": "signingKeys",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h
        }
      ],
      "n": "ResolveTokenSigningKey",
      "d": 852088,
      "h": 115964969080,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(115964969080),
//--TRIMMABLE-BOUNDARY-START(25770655864),
    {
      "r": 655361,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "maxCount",
          "p": 655361
        }
      ],
      "n": "CountJwtTokenPart",
      "d": 852088,
      "h": 25770655864,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770655864),
//--TRIMMABLE-BOUNDARY-START(21475688568),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,
      "p": [
        {
          "n": "tvp",
          "p": 16777335
        }
      ],
      "n": "ConcatSigningKeys",
      "d": 852088,
      "h": 21475688568,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475688568),
//--TRIMMABLE-BOUNDARY-START(103080067192),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "GetStringClaimValueType",
      "o": "@$1",
      "d": 852088,
      "h": 103080067192,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(103080067192),
//--TRIMMABLE-BOUNDARY-START(98785099896),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetStringClaimValueType",
      "d": 852088,
      "h": 98785099896,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(98785099896)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819384),
    {
      "t": 655361,
      "n": "_regexMatchTimeoutMilliseconds",
      "d": 852088,
      "h": 4295819384,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295819384),
//--TRIMMABLE-BOUNDARY-START(8590786680),
    {
      "t": 1310721,
      "n": "_unrecognizedEncodedToken",
      "d": 852088,
      "h": 8590786680,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590786680),
//--TRIMMABLE-BOUNDARY-START(111670001784),
    {
      "t": 1900602,
      "n": "RegexJws",
      "d": 852088,
      "h": 111670001784,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670001784),
//--TRIMMABLE-BOUNDARY-START(107375034488),
    {
      "t": 1900602,
      "n": "RegexJwe",
      "d": 852088,
      "h": 107375034488,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375034488),
//--TRIMMABLE-BOUNDARY-START(73015296120),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "n": "DefaultHeaderParameters",
      "d": 852088,
      "h": 73015296120,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015296120)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180721272),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852088,
      "h": 17180721272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721272)
  ],
  "h": 852088
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852088)
        
        
        //--TRIMMABLE-BOUNDARY-START(131192)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet", ($self) => class JsonClaimSet extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30064902264)
            /*string*/ static ClassName = null;
            //--TRIMMABLE-BOUNDARY-END(30064902264)
            
            //--TRIMMABLE-BOUNDARY-START(8590065784)
            /*Lock*/ _claimsLock = null;
            //--TRIMMABLE-BOUNDARY-END(8590065784)
            
            //--TRIMMABLE-BOUNDARY-START(12885033080)
            /*Dictionary<string, object>*/ _jsonClaims = null;
            //--TRIMMABLE-BOUNDARY-END(12885033080)
            
            //--TRIMMABLE-BOUNDARY-START(4295098488)
            /*List<Claim>*/ _claims = null;
            //--TRIMMABLE-BOUNDARY-END(4295098488)
            
            //--TRIMMABLE-BOUNDARY-START(17180000376)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000376);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsonClaims = (() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                        return $t1;
                    })();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000376)
            
            //--TRIMMABLE-BOUNDARY-START(21474967672)
            $ctor$2(/*Dictionary<string, object>*/ jsonClaims)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474967672);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsonClaims = jsonClaims;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967672)
            
            //--TRIMMABLE-BOUNDARY-START(25769934968)
            /*List<Claim> */ Claims(/*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._claims === null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._claimsLock)
                        this._claims ??= this.CreateClaims(issuer);
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._claimsLock)
                    }
                }
                return this._claims;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934968)
            
            //--TRIMMABLE-BOUNDARY-START(42949804152)
            /*List<Claim> */ CreateClaims(/*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let claims = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$3(this._jsonClaims.Count);
                var $en2 = this._jsonClaims.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromObject(claims, kvp.Key, kvp.Value, issuer);
                    }
                }
                return claims;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804152)
            
            //--TRIMMABLE-BOUNDARY-START(38654836856)
            static /*void */ CreateClaimFromObject(/*List<Claim>*/ claims, /*string*/ claimType, /*object*/ value, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let str;
                let i;
                let l;
                let b;
                let d;
                let dt;
                let f;
                let m;
                let iList;
                let j;
                if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, str, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetStringClaimValueType(str, claimType), issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Int32, { set $v(v){ i = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Int32.ToString$1.call(i, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Int64, { set $v(v){ l = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Int64.ToString$1.call(l, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Boolean, { set $v(v){ b = v; } }))
                {
                    if (b)
                    {
                        claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                    }
                    else 
                    {
                        claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                    }
                }
                else if ($.$is(value, $.$$.System.Double, { set $v(v){ d = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Double.ToString$1.call(d, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.DateTime, { set $v(v){ dt = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, dt.ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Single, { set $v(v){ f = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Single.ToString$1.call(f, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Decimal, { set $v(v){ m = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, m.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if (value === null)
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Collections.IList, { set $v(v){ iList = v; } }))
                {
                    var $en3 = iList.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromObject(claims, claimType, item, issuer);
                        }
                    }
                }
                else if ($.$is(value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ j = v; } }))
                {
                    if (j.ValueKind === 2/*JsonValueKind.Array*/)
                    {
                        var $en4 = j.EnumerateArray().GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var jsonElement = $en4.Current;
                            {
                                /*Claim*/ let claim = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, jsonElement);
                                if (claim !== null)
                                {
                                    claims.Add(claim);
                                }
                            }
                        }
                    }
                    else 
                    {
                        /*Claim*/ let claim = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, j);
                        if (claim !== null)
                        {
                            claims.Add(claim);
                        }
                    }
                }
                else 
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Object.ToString.call(value), "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, issuer, issuer));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654836856)
            
            //--TRIMMABLE-BOUNDARY-START(34359869560)
            static /*Claim */ CreateClaimFromJsonElement(/*string*/ claimType, /*string*/ issuer, /*JsonElement*/ jsonElement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jsonElement.ValueKind === 3/*JsonValueKind.String*/)
                {
                    /*string*/ let claimValue = $.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement);
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, claimValue, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetStringClaimValueType(claimValue, claimType), issuer, issuer);
                }
                else if (jsonElement.ValueKind === 7/*JsonValueKind.Null*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 1/*JsonValueKind.Object*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement), "JSON"/*JsonClaimValueTypes.Json*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 6/*JsonValueKind.False*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 5/*JsonValueKind.True*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 4/*JsonValueKind.Number*/)
                {
                    /*int*/ let i;
                    /*long*/ let l;
                    /*double*/ let d;
                    /*uint*/ let u;
                    /*ulong*/ let ul;
                    /*float*/ let f;
                    /*decimal*/ let m;
                    if (jsonElement.TryGetInt32($.$ref(() => i, ($v) => i = $v, $.$$.System.Int32)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Int32.ToString$1.call(i, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetInt64($.$ref(() => l, ($v) => l = $v, $.$$.System.Int64)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Int64.ToString$1.call(l, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetDouble($.$ref(() => d, ($v) => d = $v, $.$$.System.Double)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Double.ToString$1.call(d, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetUInt32($.$ref(() => u, ($v) => u = $v, $.$$.System.UInt32)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.UInt32.ToString$1.call(u, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#uinteger32"/*ClaimValueTypes.UInteger32*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetUInt64($.$ref(() => ul, ($v) => ul = $v, $.$$.System.UInt64)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.UInt64.ToString$1.call(ul, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#uinteger64"/*ClaimValueTypes.UInteger64*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetSingle($.$ref(() => f, ($v) => f = $v, $.$$.System.Single)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Single.ToString$1.call(f, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetDecimal($.$ref(() => m, ($v) => m = $v, $.$$.System.Decimal)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, m.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                }
                else if (jsonElement.ValueKind === 2/*JsonValueKind.Array*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement), "JSON_ARRAY"/*JsonClaimValueTypes.JsonArray*/, issuer, issuer);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34359869560)
            
            //--TRIMMABLE-BOUNDARY-START(47244771448)
            /*Claim */ GetClaim(/*string*/ key, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(key, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                }
                if (this._jsonClaims.TryGetValue(key, $.$discardRef()))
                {
                    var $en3 = this.Claims(issuer).GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var claim = $en3.Current;
                        {
                            if ($.$$.System.String.op_Equality(claim.Type, key))
                            {
                                return claim;
                            }
                        }
                    }
                }
                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet."/*LogMessages.IDX14304*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ key ], null, null))));
            }
            //--TRIMMABLE-BOUNDARY-END(47244771448)
            
            //--TRIMMABLE-BOUNDARY-START(55834706040)
            /*string */ GetStringValue(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let obj;
                if (this._jsonClaims.TryGetValue(key, $.$ref(() => obj, ($v) => obj = $v, $.$$.System.Object)))
                {
                    if (obj === null)
                    {
                        return null;
                    }
                    return $.$$.System.Object.ToString.call(obj);
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706040)
            
            //--TRIMMABLE-BOUNDARY-START(51539738744)
            /*DateTime */ GetDateTime(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let found;
                /*long*/ let l = this.GetValue($.$$.System.Int64, key, false, $.$ref(() => found, ($v) => found = $v, $.$$.System.Boolean));
                if (found)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime(l);
                }
                return $.$$.System.DateTime.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(51539738744)
            
            //--TRIMMABLE-BOUNDARY-START(64424640632)
            /*T */ GetValue$1(T, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424640632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValue(T, key, true, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(64424640632)
            
            //--TRIMMABLE-BOUNDARY-START(60129673336)
            /*T */ GetValue(T, /*string*/ key, /*bool*/ throwEx, /*out bool*/ found)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let obj;
                found.$v = this._jsonClaims.TryGetValue(key, $.$ref(() => obj, ($v) => obj = $v, $.$$.System.Object));
                if (!found.$v)
                {
                    return throwEx ? (() =>
                    {
        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet."/*LogMessages.IDX14304*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ key ], null, null))))            })() : $.$default(T);
                }
                if (obj === null)
                {
                    if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Object.$type) || T.$type.IsClass || $.$$.System.Type.op_Inequality$1($.$$.System.Nullable.GetUnderlyingType(T.$type), null))
                    {
                        return $.$cast(null, T);
                    }
                    else 
                    {
                        return $.$default(T);
                    }
                }
                /*Type*/ let objType = $.$$.System.Object.GetType.call(obj);
                if ($.$$.System.Type.op_Equality$1(T.$type, objType))
                {
                    return $.$cast((obj), T);
                }
                if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Object.$type))
                {
                    return $.$cast(obj, T);
                }
                let jsonElement;
                if ($.$is(obj, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonElement = v; } }))
                {
                    /*T*/ let t;
                    if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.TryCreateTypeFromJsonElement(T, jsonElement, $.$ref(() => t, ($v) => t = $v, T)))
                    {
                        return t;
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.String.$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture)), T);
                    }
                    let list;
                    if ($.$is(obj, $.$$.System.Collections.Generic.List$$($.$$.System.String), { set $v(v){ list = v; } }))
                    {
                        if (list.Count === 1)
                        {
                            return $.$cast(((list.get_Item(0))), T);
                        }
                    }
                    else 
                    {
                        return $.$cast(($.$$.System.Object.ToString.call(obj)), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Boolean.$type))
                {
                    /*bool*/ let value;
                    if ($.$$.System.Boolean.TryParse$1($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Boolean)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Boolean), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Int32.$type))
                {
                    /*int*/ let value;
                    if ($.$$.System.Int32.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Int32)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Int32), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Int64.$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int32.$type))
                    {
                        return $.$cast($.$box($.$cast($.$cast(obj, $.$$.System.Int32), $.$$.System.Int64), $.$$.System.Int64), T);
                    }
                    /*long*/ let value;
                    if ($.$$.System.Int64.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Int64)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Int64), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$typeArray($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [$.$cast(obj, $.$$.System.String)], [-1], null), $.$$.System.Object), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture)], [-1], null), $.$$.System.Object), T);
                    }
                    return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [$.$$.System.Object.ToString.call(obj)], [-1], null), $.$$.System.Object), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.Generic.List$$($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add($.$cast(obj, $.$$.System.String));
                            return $i2;
                        })(), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add(($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            return $i2;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add($.$$.System.Object.ToString.call(obj));
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add($.$cast(obj, $.$$.System.String));
                            return $i2;
                        })(), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add(($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            return $i2;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                        const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add($.$$.System.Object.ToString.call(obj));
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.Generic.IList$$($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add($.$cast(obj, $.$$.System.String));
                            return $i2;
                        })(), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add(($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            return $i2;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add($.$$.System.Object.ToString.call(obj));
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.Generic.ICollection$$($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add($.$cast(obj, $.$$.System.String));
                            return $i2;
                        })(), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add(($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            return $i2;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                        const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add($.$$.System.Object.ToString.call(obj));
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$typeArray($.$$.System.Object).$type))
                {
                    return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [obj], [-1], null), $.$$.System.Object), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.Generic.List$$($.$$.System.Object).$type))
                {
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.Object)()
                        const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add(obj);
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.Object).$type))
                {
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.Object)()
                        const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add(obj);
                        return $i2;
                    })(), T);
                }
                else if (T.$type.IsEnum)
                {
                    return $.$cast($.$$.System.Enum.Parse$2(T.$type, $.$$.System.Object.ToString.call(obj), true), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.DateTime.$type))
                {
                    /*DateTime*/ let value;
                    if ($.$$.System.DateTime.TryParse$5($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.DateTime)))
                    {
                        return $.$cast($.$cast(value, $.$$.System.Object), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$typeArray($.$$.System.Int32).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int32.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), [$.$cast(obj, $.$$.System.Int32)], [-1], null), $.$$.System.Object), T);
                    }
                    /*int*/ let value;
                    if ($.$$.System.Int32.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Int32)))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), [value], [-1], null), $.$$.System.Object), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$typeArray($.$$.System.Int64).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int64.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), [$.$cast(obj, $.$$.System.Int64)], [-1], null), $.$$.System.Object), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int32.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), [BigInt($.$cast(obj, $.$$.System.Int32))], [-1], null), $.$$.System.Object), T);
                    }
                    /*long*/ let value;
                    if ($.$$.System.Int64.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Int64)))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), [value], [-1], null), $.$$.System.Object), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Double.$type))
                {
                    /*double*/ let value;
                    if ($.$$.System.Double.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Double)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Double), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.UInt32.$type))
                {
                    /*uint*/ let value;
                    if ($.$$.System.UInt32.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.UInt32)))
                    {
                        return $.$cast($.$box(value, $.$$.System.UInt32), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.UInt64.$type))
                {
                    /*ulong*/ let value;
                    if ($.$$.System.UInt64.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.UInt64)))
                    {
                        return $.$cast($.$box(value, $.$$.System.UInt64), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Single.$type))
                {
                    /*float*/ let value;
                    if ($.$$.System.Single.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Single)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Single), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Decimal.$type))
                {
                    /*decimal*/ let value;
                    if ($.$$.System.Decimal.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Decimal)))
                    {
                        return $.$cast($.$cast(value, $.$$.System.Object), T);
                    }
                }
                found.$v = false;
                if (throwEx)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'."/*LogMessages.IDX14305*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(T.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(objType), $.$$.System.Object.ToString.call(obj) ], null, null))));
                }
                else 
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'."/*LogMessages.IDX14305*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(T.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(objType), $.$$.System.Object.ToString.call(obj) ], null, null))));
                }
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(60129673336)
            
            //--TRIMMABLE-BOUNDARY-START(73014575224)
            /*bool */ TryGetClaim(/*string*/ key, /*string*/ issuer, /*out Claim*/ claim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                claim.$v = null;
                /*object*/ let value;
                if (!this._jsonClaims.TryGetValue(key, $.$ref(() => value, ($v) => value = $v, $.$$.System.Object)))
                {
                    return false;
                }
                var $en2 = this.Claims(issuer).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if ($.$$.System.String.op_Equality(c.Type, key))
                        {
                            claim.$v = c;
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(73014575224)
            
            //--TRIMMABLE-BOUNDARY-START(77309542520)
            /*bool */ TryGetValue(T, /*string*/ key, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309542520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let found;
                value.$v = this.GetValue(T, key, false, $.$ref(() => found, ($v) => found = $v, $.$$.System.Boolean));
                return found;
            }
            //--TRIMMABLE-BOUNDARY-END(77309542520)
            
            //--TRIMMABLE-BOUNDARY-START(68719607928)
            /*bool */ HasClaim(/*string*/ claimName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._jsonClaims.TryGetValue(claimName, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(68719607928)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590065784)
                this._claimsLock = new $.$$.System.Threading.Lock().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590065784)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(30064902264)
                    this.ClassName = "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet";
                    //--TRIMMABLE-BOUNDARY-END(30064902264)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 131192;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769934968),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "Claims",
      "d": 131192,
      "h": 25769934968,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25769934968),
//--TRIMMABLE-BOUNDARY-START(42949804152),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaims",
      "d": 131192,
      "h": 42949804152,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42949804152),
//--TRIMMABLE-BOUNDARY-START(38654836856),
    {
      "r": 65537,
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimFromObject",
      "d": 131192,
      "h": 38654836856,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38654836856),
//--TRIMMABLE-BOUNDARY-START(34359869560),
    {
      "r": 131141,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "jsonElement",
          "p": 2097236
        }
      ],
      "n": "CreateClaimFromJsonElement",
      "d": 131192,
      "h": 34359869560,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34359869560),
//--TRIMMABLE-BOUNDARY-START(47244771448),
    {
      "r": 131141,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "GetClaim",
      "d": 131192,
      "h": 47244771448,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47244771448),
//--TRIMMABLE-BOUNDARY-START(55834706040),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetStringValue",
      "d": 131192,
      "h": 55834706040,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55834706040),
//--TRIMMABLE-BOUNDARY-START(51539738744),
    {
      "r": 65273857,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetDateTime",
      "d": 131192,
      "h": 51539738744,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51539738744),
//--TRIMMABLE-BOUNDARY-START(64424640632),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValue",
      "o": "@$1",
      "d": 131192,
      "h": 64424640632,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(64424640632),
//--TRIMMABLE-BOUNDARY-START(60129673336),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "throwEx",
          "p": 262145
        },
        {
          "n": "found",
          "p": 262145,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValue",
      "d": 131192,
      "h": 60129673336,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(60129673336),
//--TRIMMABLE-BOUNDARY-START(73014575224),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "claim",
          "p": 131141,
          "f": 2
        }
      ],
      "n": "TryGetClaim",
      "d": 131192,
      "h": 73014575224,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73014575224),
//--TRIMMABLE-BOUNDARY-START(77309542520),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetValue",
      "d": 131192,
      "h": 77309542520,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(77309542520),
//--TRIMMABLE-BOUNDARY-START(68719607928),
    {
      "r": 262145,
      "p": [
        {
          "n": "claimName",
          "p": 1310721
        }
      ],
      "n": "HasClaim",
      "d": 131192,
      "h": 68719607928,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68719607928)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30064902264),
    {
      "t": 1310721,
      "n": "ClassName",
      "d": 131192,
      "h": 30064902264,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064902264),
//--TRIMMABLE-BOUNDARY-START(8590065784),
    {
      "t": 171769857,
      "n": "_claimsLock",
      "d": 131192,
      "h": 8590065784,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590065784),
//--TRIMMABLE-BOUNDARY-START(12885033080),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "n": "_jsonClaims",
      "d": 131192,
      "h": 12885033080,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885033080),
//--TRIMMABLE-BOUNDARY-START(4295098488),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,
      "n": "_claims",
      "d": 131192,
      "h": 4295098488,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098488)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180000376),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131192,
      "h": 17180000376,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180000376),
//--TRIMMABLE-BOUNDARY-START(21474967672),
    {
      "p": [
        {
          "n": "jsonClaims",
          "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131192,
      "h": 21474967672,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21474967672)
  ],
  "h": 131192
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131192)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376376)
        $asm.$cls("$mij.System.Text.RegularExpressions.Generated.Utilities", ($self) => class Utilities
        {
            //--TRIMMABLE-BOUNDARY-START(8591310968)
            /*SearchValues<char>*/ static s_asciiLettersAndDigitsAndDashUnderscore = null;
            //--TRIMMABLE-BOUNDARY-END(8591310968)
            
            //--TRIMMABLE-BOUNDARY-START(4296343672)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8591310968)
                    this.s_asciiLettersAndDigitsAndDashUnderscore = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz"));
                    //--TRIMMABLE-BOUNDARY-END(8591310968)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296343672)
            
            static $h = 1376376;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591310968),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_asciiLettersAndDigitsAndDashUnderscore",
      "d": 1376376,
      "h": 8591310968,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8591310968)
  ],
  "h": 1376376,
  "a": [
    {
      "t": 54329345,
      "c": 12939231233,
      "a": [
        {
          "v": "System.Text.RegularExpressions.Generator",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.RegularExpressions.Generated.Utilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376376)
        
        
        //--TRIMMABLE-BOUNDARY-START(721016)
        $asm.$str("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtRegisteredClaimNames", ($self) => class JwtRegisteredClaimNames extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885622904)
            /*string*/ static Act = null;
            //--TRIMMABLE-BOUNDARY-END(12885622904)
            
            //--TRIMMABLE-BOUNDARY-START(17180590200)
            /*string*/ static Actort = null;
            //--TRIMMABLE-BOUNDARY-END(17180590200)
            
            //--TRIMMABLE-BOUNDARY-START(8590655608)
            /*string*/ static Acr = null;
            //--TRIMMABLE-BOUNDARY-END(8590655608)
            
            //--TRIMMABLE-BOUNDARY-START(21475557496)
            /*string*/ static Address = null;
            //--TRIMMABLE-BOUNDARY-END(21475557496)
            
            //--TRIMMABLE-BOUNDARY-START(25770524792)
            /*string*/ static Alg = null;
            //--TRIMMABLE-BOUNDARY-END(25770524792)
            
            //--TRIMMABLE-BOUNDARY-START(30065492088)
            /*string*/ static Amr = null;
            //--TRIMMABLE-BOUNDARY-END(30065492088)
            
            //--TRIMMABLE-BOUNDARY-START(38655426680)
            /*string*/ static Aud = null;
            //--TRIMMABLE-BOUNDARY-END(38655426680)
            
            //--TRIMMABLE-BOUNDARY-START(42950393976)
            /*string*/ static AuthTime = null;
            //--TRIMMABLE-BOUNDARY-END(42950393976)
            
            //--TRIMMABLE-BOUNDARY-START(47245361272)
            /*string*/ static Azp = null;
            //--TRIMMABLE-BOUNDARY-END(47245361272)
            
            //--TRIMMABLE-BOUNDARY-START(51540328568)
            /*string*/ static Birthdate = null;
            //--TRIMMABLE-BOUNDARY-END(51540328568)
            
            //--TRIMMABLE-BOUNDARY-START(55835295864)
            /*string*/ static CHash = null;
            //--TRIMMABLE-BOUNDARY-END(55835295864)
            
            //--TRIMMABLE-BOUNDARY-START(34360459384)
            /*string*/ static AtHash = null;
            //--TRIMMABLE-BOUNDARY-END(34360459384)
            
            //--TRIMMABLE-BOUNDARY-START(60130263160)
            /*string*/ static Email = null;
            //--TRIMMABLE-BOUNDARY-END(60130263160)
            
            //--TRIMMABLE-BOUNDARY-START(64425230456)
            /*string*/ static EmailVerified = null;
            //--TRIMMABLE-BOUNDARY-END(64425230456)
            
            //--TRIMMABLE-BOUNDARY-START(68720197752)
            /*string*/ static Exp = null;
            //--TRIMMABLE-BOUNDARY-END(68720197752)
            
            //--TRIMMABLE-BOUNDARY-START(77310132344)
            /*string*/ static Gender = null;
            //--TRIMMABLE-BOUNDARY-END(77310132344)
            
            //--TRIMMABLE-BOUNDARY-START(73015165048)
            /*string*/ static FamilyName = null;
            //--TRIMMABLE-BOUNDARY-END(73015165048)
            
            //--TRIMMABLE-BOUNDARY-START(81605099640)
            /*string*/ static GivenName = null;
            //--TRIMMABLE-BOUNDARY-END(81605099640)
            
            //--TRIMMABLE-BOUNDARY-START(85900066936)
            /*string*/ static Iat = null;
            //--TRIMMABLE-BOUNDARY-END(85900066936)
            
            //--TRIMMABLE-BOUNDARY-START(90195034232)
            /*string*/ static Iss = null;
            //--TRIMMABLE-BOUNDARY-END(90195034232)
            
            //--TRIMMABLE-BOUNDARY-START(94490001528)
            /*string*/ static Jti = null;
            //--TRIMMABLE-BOUNDARY-END(94490001528)
            
            //--TRIMMABLE-BOUNDARY-START(98784968824)
            /*string*/ static Locale = null;
            //--TRIMMABLE-BOUNDARY-END(98784968824)
            
            //--TRIMMABLE-BOUNDARY-START(103079936120)
            /*string*/ static MiddleName = null;
            //--TRIMMABLE-BOUNDARY-END(103079936120)
            
            //--TRIMMABLE-BOUNDARY-START(107374903416)
            /*string*/ static Name = null;
            //--TRIMMABLE-BOUNDARY-END(107374903416)
            
            //--TRIMMABLE-BOUNDARY-START(111669870712)
            /*string*/ static NameId = null;
            //--TRIMMABLE-BOUNDARY-END(111669870712)
            
            //--TRIMMABLE-BOUNDARY-START(120259805304)
            /*string*/ static Nickname = null;
            //--TRIMMABLE-BOUNDARY-END(120259805304)
            
            //--TRIMMABLE-BOUNDARY-START(124554772600)
            /*string*/ static Nonce = null;
            //--TRIMMABLE-BOUNDARY-END(124554772600)
            
            //--TRIMMABLE-BOUNDARY-START(115964838008)
            /*string*/ static Nbf = null;
            //--TRIMMABLE-BOUNDARY-END(115964838008)
            
            //--TRIMMABLE-BOUNDARY-START(128849739896)
            /*string*/ static PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(128849739896)
            
            //--TRIMMABLE-BOUNDARY-START(133144707192)
            /*string*/ static PhoneNumberVerified = null;
            //--TRIMMABLE-BOUNDARY-END(133144707192)
            
            //--TRIMMABLE-BOUNDARY-START(137439674488)
            /*string*/ static Picture = null;
            //--TRIMMABLE-BOUNDARY-END(137439674488)
            
            //--TRIMMABLE-BOUNDARY-START(146029609080)
            /*string*/ static Prn = null;
            //--TRIMMABLE-BOUNDARY-END(146029609080)
            
            //--TRIMMABLE-BOUNDARY-START(141734641784)
            /*string*/ static PreferredUsername = null;
            //--TRIMMABLE-BOUNDARY-END(141734641784)
            
            //--TRIMMABLE-BOUNDARY-START(150324576376)
            /*string*/ static Profile = null;
            //--TRIMMABLE-BOUNDARY-END(150324576376)
            
            //--TRIMMABLE-BOUNDARY-START(154619543672)
            /*string*/ static Sid = null;
            //--TRIMMABLE-BOUNDARY-END(154619543672)
            
            //--TRIMMABLE-BOUNDARY-START(158914510968)
            /*string*/ static Sub = null;
            //--TRIMMABLE-BOUNDARY-END(158914510968)
            
            //--TRIMMABLE-BOUNDARY-START(163209478264)
            /*string*/ static Typ = null;
            //--TRIMMABLE-BOUNDARY-END(163209478264)
            
            //--TRIMMABLE-BOUNDARY-START(167504445560)
            /*string*/ static UniqueName = null;
            //--TRIMMABLE-BOUNDARY-END(167504445560)
            
            //--TRIMMABLE-BOUNDARY-START(171799412856)
            /*string*/ static UpdatedAt = null;
            //--TRIMMABLE-BOUNDARY-END(171799412856)
            
            //--TRIMMABLE-BOUNDARY-START(176094380152)
            /*string*/ static Website = null;
            //--TRIMMABLE-BOUNDARY-END(176094380152)
            
            //--TRIMMABLE-BOUNDARY-START(180389347448)
            /*string*/ static ZoneInfo = null;
            //--TRIMMABLE-BOUNDARY-END(180389347448)
            
            //--TRIMMABLE-BOUNDARY-START(4295688312)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688312)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885622904)
                    this.Act = "act";
                    //--TRIMMABLE-BOUNDARY-END(12885622904)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180590200)
                    this.Actort = "actort";
                    //--TRIMMABLE-BOUNDARY-END(17180590200)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590655608)
                    this.Acr = "acr";
                    //--TRIMMABLE-BOUNDARY-END(8590655608)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475557496)
                    this.Address = "address";
                    //--TRIMMABLE-BOUNDARY-END(21475557496)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770524792)
                    this.Alg = "alg";
                    //--TRIMMABLE-BOUNDARY-END(25770524792)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065492088)
                    this.Amr = "amr";
                    //--TRIMMABLE-BOUNDARY-END(30065492088)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655426680)
                    this.Aud = "aud";
                    //--TRIMMABLE-BOUNDARY-END(38655426680)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950393976)
                    this.AuthTime = "auth_time";
                    //--TRIMMABLE-BOUNDARY-END(42950393976)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245361272)
                    this.Azp = "azp";
                    //--TRIMMABLE-BOUNDARY-END(47245361272)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540328568)
                    this.Birthdate = "birthdate";
                    //--TRIMMABLE-BOUNDARY-END(51540328568)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835295864)
                    this.CHash = "c_hash";
                    //--TRIMMABLE-BOUNDARY-END(55835295864)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360459384)
                    this.AtHash = "at_hash";
                    //--TRIMMABLE-BOUNDARY-END(34360459384)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130263160)
                    this.Email = "email";
                    //--TRIMMABLE-BOUNDARY-END(60130263160)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425230456)
                    this.EmailVerified = "email_verified";
                    //--TRIMMABLE-BOUNDARY-END(64425230456)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720197752)
                    this.Exp = "exp";
                    //--TRIMMABLE-BOUNDARY-END(68720197752)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310132344)
                    this.Gender = "gender";
                    //--TRIMMABLE-BOUNDARY-END(77310132344)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015165048)
                    this.FamilyName = "family_name";
                    //--TRIMMABLE-BOUNDARY-END(73015165048)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605099640)
                    this.GivenName = "given_name";
                    //--TRIMMABLE-BOUNDARY-END(81605099640)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900066936)
                    this.Iat = "iat";
                    //--TRIMMABLE-BOUNDARY-END(85900066936)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195034232)
                    this.Iss = "iss";
                    //--TRIMMABLE-BOUNDARY-END(90195034232)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490001528)
                    this.Jti = "jti";
                    //--TRIMMABLE-BOUNDARY-END(94490001528)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784968824)
                    this.Locale = "locale";
                    //--TRIMMABLE-BOUNDARY-END(98784968824)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079936120)
                    this.MiddleName = "middle_name";
                    //--TRIMMABLE-BOUNDARY-END(103079936120)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374903416)
                    this.Name = "name";
                    //--TRIMMABLE-BOUNDARY-END(107374903416)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669870712)
                    this.NameId = "nameid";
                    //--TRIMMABLE-BOUNDARY-END(111669870712)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259805304)
                    this.Nickname = "nickname";
                    //--TRIMMABLE-BOUNDARY-END(120259805304)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554772600)
                    this.Nonce = "nonce";
                    //--TRIMMABLE-BOUNDARY-END(124554772600)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964838008)
                    this.Nbf = "nbf";
                    //--TRIMMABLE-BOUNDARY-END(115964838008)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849739896)
                    this.PhoneNumber = "phone_number";
                    //--TRIMMABLE-BOUNDARY-END(128849739896)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144707192)
                    this.PhoneNumberVerified = "phone_number_verified";
                    //--TRIMMABLE-BOUNDARY-END(133144707192)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439674488)
                    this.Picture = "picture";
                    //--TRIMMABLE-BOUNDARY-END(137439674488)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029609080)
                    this.Prn = "prn";
                    //--TRIMMABLE-BOUNDARY-END(146029609080)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734641784)
                    this.PreferredUsername = "preferred_username";
                    //--TRIMMABLE-BOUNDARY-END(141734641784)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324576376)
                    this.Profile = "profile";
                    //--TRIMMABLE-BOUNDARY-END(150324576376)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619543672)
                    this.Sid = "sid";
                    //--TRIMMABLE-BOUNDARY-END(154619543672)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914510968)
                    this.Sub = "sub";
                    //--TRIMMABLE-BOUNDARY-END(158914510968)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209478264)
                    this.Typ = "typ";
                    //--TRIMMABLE-BOUNDARY-END(163209478264)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504445560)
                    this.UniqueName = "unique_name";
                    //--TRIMMABLE-BOUNDARY-END(167504445560)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799412856)
                    this.UpdatedAt = "updated_at";
                    //--TRIMMABLE-BOUNDARY-END(171799412856)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094380152)
                    this.Website = "website";
                    //--TRIMMABLE-BOUNDARY-END(176094380152)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389347448)
                    this.ZoneInfo = "zoneinfo";
                    //--TRIMMABLE-BOUNDARY-END(180389347448)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 721016;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622904),
    {
      "t": 1310721,
      "n": "Act",
      "d": 721016,
      "h": 12885622904,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622904),
//--TRIMMABLE-BOUNDARY-START(17180590200),
    {
      "t": 1310721,
      "n": "Actort",
      "d": 721016,
      "h": 17180590200,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590200),
//--TRIMMABLE-BOUNDARY-START(8590655608),
    {
      "t": 1310721,
      "n": "Acr",
      "d": 721016,
      "h": 8590655608,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655608),
//--TRIMMABLE-BOUNDARY-START(21475557496),
    {
      "t": 1310721,
      "n": "Address",
      "d": 721016,
      "h": 21475557496,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557496),
//--TRIMMABLE-BOUNDARY-START(25770524792),
    {
      "t": 1310721,
      "n": "Alg",
      "d": 721016,
      "h": 25770524792,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524792),
//--TRIMMABLE-BOUNDARY-START(30065492088),
    {
      "t": 1310721,
      "n": "Amr",
      "d": 721016,
      "h": 30065492088,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065492088),
//--TRIMMABLE-BOUNDARY-START(38655426680),
    {
      "t": 1310721,
      "n": "Aud",
      "d": 721016,
      "h": 38655426680,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655426680),
//--TRIMMABLE-BOUNDARY-START(42950393976),
    {
      "t": 1310721,
      "n": "AuthTime",
      "d": 721016,
      "h": 42950393976,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950393976),
//--TRIMMABLE-BOUNDARY-START(47245361272),
    {
      "t": 1310721,
      "n": "Azp",
      "d": 721016,
      "h": 47245361272,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245361272),
//--TRIMMABLE-BOUNDARY-START(51540328568),
    {
      "t": 1310721,
      "n": "Birthdate",
      "d": 721016,
      "h": 51540328568,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540328568),
//--TRIMMABLE-BOUNDARY-START(55835295864),
    {
      "t": 1310721,
      "n": "CHash",
      "d": 721016,
      "h": 55835295864,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835295864),
//--TRIMMABLE-BOUNDARY-START(34360459384),
    {
      "t": 1310721,
      "n": "AtHash",
      "d": 721016,
      "h": 34360459384,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360459384),
//--TRIMMABLE-BOUNDARY-START(60130263160),
    {
      "t": 1310721,
      "n": "Email",
      "d": 721016,
      "h": 60130263160,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130263160),
//--TRIMMABLE-BOUNDARY-START(64425230456),
    {
      "t": 1310721,
      "n": "EmailVerified",
      "d": 721016,
      "h": 64425230456,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425230456),
//--TRIMMABLE-BOUNDARY-START(68720197752),
    {
      "t": 1310721,
      "n": "Exp",
      "d": 721016,
      "h": 68720197752,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720197752),
//--TRIMMABLE-BOUNDARY-START(77310132344),
    {
      "t": 1310721,
      "n": "Gender",
      "d": 721016,
      "h": 77310132344,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310132344),
//--TRIMMABLE-BOUNDARY-START(73015165048),
    {
      "t": 1310721,
      "n": "FamilyName",
      "d": 721016,
      "h": 73015165048,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015165048),
//--TRIMMABLE-BOUNDARY-START(81605099640),
    {
      "t": 1310721,
      "n": "GivenName",
      "d": 721016,
      "h": 81605099640,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605099640),
//--TRIMMABLE-BOUNDARY-START(85900066936),
    {
      "t": 1310721,
      "n": "Iat",
      "d": 721016,
      "h": 85900066936,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900066936),
//--TRIMMABLE-BOUNDARY-START(90195034232),
    {
      "t": 1310721,
      "n": "Iss",
      "d": 721016,
      "h": 90195034232,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195034232),
//--TRIMMABLE-BOUNDARY-START(94490001528),
    {
      "t": 1310721,
      "n": "Jti",
      "d": 721016,
      "h": 94490001528,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490001528),
//--TRIMMABLE-BOUNDARY-START(98784968824),
    {
      "t": 1310721,
      "n": "Locale",
      "d": 721016,
      "h": 98784968824,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784968824),
//--TRIMMABLE-BOUNDARY-START(103079936120),
    {
      "t": 1310721,
      "n": "MiddleName",
      "d": 721016,
      "h": 103079936120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079936120),
//--TRIMMABLE-BOUNDARY-START(107374903416),
    {
      "t": 1310721,
      "n": "Name",
      "d": 721016,
      "h": 107374903416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374903416),
//--TRIMMABLE-BOUNDARY-START(111669870712),
    {
      "t": 1310721,
      "n": "NameId",
      "d": 721016,
      "h": 111669870712,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669870712),
//--TRIMMABLE-BOUNDARY-START(120259805304),
    {
      "t": 1310721,
      "n": "Nickname",
      "d": 721016,
      "h": 120259805304,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259805304),
//--TRIMMABLE-BOUNDARY-START(124554772600),
    {
      "t": 1310721,
      "n": "Nonce",
      "d": 721016,
      "h": 124554772600,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554772600),
//--TRIMMABLE-BOUNDARY-START(115964838008),
    {
      "t": 1310721,
      "n": "Nbf",
      "d": 721016,
      "h": 115964838008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964838008),
//--TRIMMABLE-BOUNDARY-START(128849739896),
    {
      "t": 1310721,
      "n": "PhoneNumber",
      "d": 721016,
      "h": 128849739896,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849739896),
//--TRIMMABLE-BOUNDARY-START(133144707192),
    {
      "t": 1310721,
      "n": "PhoneNumberVerified",
      "d": 721016,
      "h": 133144707192,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144707192),
//--TRIMMABLE-BOUNDARY-START(137439674488),
    {
      "t": 1310721,
      "n": "Picture",
      "d": 721016,
      "h": 137439674488,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439674488),
//--TRIMMABLE-BOUNDARY-START(146029609080),
    {
      "t": 1310721,
      "n": "Prn",
      "d": 721016,
      "h": 146029609080,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029609080),
//--TRIMMABLE-BOUNDARY-START(141734641784),
    {
      "t": 1310721,
      "n": "PreferredUsername",
      "d": 721016,
      "h": 141734641784,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734641784),
//--TRIMMABLE-BOUNDARY-START(150324576376),
    {
      "t": 1310721,
      "n": "Profile",
      "d": 721016,
      "h": 150324576376,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324576376),
//--TRIMMABLE-BOUNDARY-START(154619543672),
    {
      "t": 1310721,
      "n": "Sid",
      "d": 721016,
      "h": 154619543672,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619543672),
//--TRIMMABLE-BOUNDARY-START(158914510968),
    {
      "t": 1310721,
      "n": "Sub",
      "d": 721016,
      "h": 158914510968,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914510968),
//--TRIMMABLE-BOUNDARY-START(163209478264),
    {
      "t": 1310721,
      "n": "Typ",
      "d": 721016,
      "h": 163209478264,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209478264),
//--TRIMMABLE-BOUNDARY-START(167504445560),
    {
      "t": 1310721,
      "n": "UniqueName",
      "d": 721016,
      "h": 167504445560,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504445560),
//--TRIMMABLE-BOUNDARY-START(171799412856),
    {
      "t": 1310721,
      "n": "UpdatedAt",
      "d": 721016,
      "h": 171799412856,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799412856),
//--TRIMMABLE-BOUNDARY-START(176094380152),
    {
      "t": 1310721,
      "n": "Website",
      "d": 721016,
      "h": 176094380152,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094380152),
//--TRIMMABLE-BOUNDARY-START(180389347448),
    {
      "t": 1310721,
      "n": "ZoneInfo",
      "d": 721016,
      "h": 180389347448,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389347448)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688312),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721016,
      "h": 4295688312,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688312)
  ],
  "h": 721016
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtRegisteredClaimNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721016)
        
        
        //--TRIMMABLE-BOUNDARY-START(524408)
        $asm.$str("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderParameterNames", ($self) => class JwtHeaderParameterNames extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590459000)
            /*string*/ static Alg = null;
            //--TRIMMABLE-BOUNDARY-END(8590459000)
            
            //--TRIMMABLE-BOUNDARY-START(12885426296)
            /*string*/ static Apu = null;
            //--TRIMMABLE-BOUNDARY-END(12885426296)
            
            //--TRIMMABLE-BOUNDARY-START(17180393592)
            /*string*/ static Apv = null;
            //--TRIMMABLE-BOUNDARY-END(17180393592)
            
            //--TRIMMABLE-BOUNDARY-START(30065295480)
            /*string*/ static Epk = null;
            //--TRIMMABLE-BOUNDARY-END(30065295480)
            
            //--TRIMMABLE-BOUNDARY-START(21475360888)
            /*string*/ static Cty = null;
            //--TRIMMABLE-BOUNDARY-END(21475360888)
            
            //--TRIMMABLE-BOUNDARY-START(25770328184)
            /*string*/ static Enc = null;
            //--TRIMMABLE-BOUNDARY-END(25770328184)
            
            //--TRIMMABLE-BOUNDARY-START(34360262776)
            /*string*/ static IV = null;
            //--TRIMMABLE-BOUNDARY-END(34360262776)
            
            //--TRIMMABLE-BOUNDARY-START(38655230072)
            /*string*/ static Jku = null;
            //--TRIMMABLE-BOUNDARY-END(38655230072)
            
            //--TRIMMABLE-BOUNDARY-START(42950197368)
            /*string*/ static Jwk = null;
            //--TRIMMABLE-BOUNDARY-END(42950197368)
            
            //--TRIMMABLE-BOUNDARY-START(47245164664)
            /*string*/ static Kid = null;
            //--TRIMMABLE-BOUNDARY-END(47245164664)
            
            //--TRIMMABLE-BOUNDARY-START(51540131960)
            /*string*/ static Typ = null;
            //--TRIMMABLE-BOUNDARY-END(51540131960)
            
            //--TRIMMABLE-BOUNDARY-START(55835099256)
            /*string*/ static X5c = null;
            //--TRIMMABLE-BOUNDARY-END(55835099256)
            
            //--TRIMMABLE-BOUNDARY-START(60130066552)
            /*string*/ static X5t = null;
            //--TRIMMABLE-BOUNDARY-END(60130066552)
            
            //--TRIMMABLE-BOUNDARY-START(64425033848)
            /*string*/ static X5u = null;
            //--TRIMMABLE-BOUNDARY-END(64425033848)
            
            //--TRIMMABLE-BOUNDARY-START(68720001144)
            /*string*/ static Zip = null;
            //--TRIMMABLE-BOUNDARY-END(68720001144)
            
            //--TRIMMABLE-BOUNDARY-START(4295491704)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491704)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590459000)
                    this.Alg = "alg";
                    //--TRIMMABLE-BOUNDARY-END(8590459000)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426296)
                    this.Apu = "apu";
                    //--TRIMMABLE-BOUNDARY-END(12885426296)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180393592)
                    this.Apv = "apv";
                    //--TRIMMABLE-BOUNDARY-END(17180393592)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065295480)
                    this.Epk = "epk";
                    //--TRIMMABLE-BOUNDARY-END(30065295480)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475360888)
                    this.Cty = "cty";
                    //--TRIMMABLE-BOUNDARY-END(21475360888)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328184)
                    this.Enc = "enc";
                    //--TRIMMABLE-BOUNDARY-END(25770328184)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360262776)
                    this.IV = "iv";
                    //--TRIMMABLE-BOUNDARY-END(34360262776)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655230072)
                    this.Jku = "jku";
                    //--TRIMMABLE-BOUNDARY-END(38655230072)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950197368)
                    this.Jwk = "jwk";
                    //--TRIMMABLE-BOUNDARY-END(42950197368)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245164664)
                    this.Kid = "kid";
                    //--TRIMMABLE-BOUNDARY-END(47245164664)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540131960)
                    this.Typ = "typ";
                    //--TRIMMABLE-BOUNDARY-END(51540131960)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835099256)
                    this.X5c = "x5c";
                    //--TRIMMABLE-BOUNDARY-END(55835099256)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130066552)
                    this.X5t = "x5t";
                    //--TRIMMABLE-BOUNDARY-END(60130066552)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425033848)
                    this.X5u = "x5u";
                    //--TRIMMABLE-BOUNDARY-END(64425033848)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720001144)
                    this.Zip = "zip";
                    //--TRIMMABLE-BOUNDARY-END(68720001144)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 524408;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590459000),
    {
      "t": 1310721,
      "n": "Alg",
      "d": 524408,
      "h": 8590459000,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590459000),
//--TRIMMABLE-BOUNDARY-START(12885426296),
    {
      "t": 1310721,
      "n": "Apu",
      "d": 524408,
      "h": 12885426296,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426296),
//--TRIMMABLE-BOUNDARY-START(17180393592),
    {
      "t": 1310721,
      "n": "Apv",
      "d": 524408,
      "h": 17180393592,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393592),
//--TRIMMABLE-BOUNDARY-START(30065295480),
    {
      "t": 1310721,
      "n": "Epk",
      "d": 524408,
      "h": 30065295480,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295480),
//--TRIMMABLE-BOUNDARY-START(21475360888),
    {
      "t": 1310721,
      "n": "Cty",
      "d": 524408,
      "h": 21475360888,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360888),
//--TRIMMABLE-BOUNDARY-START(25770328184),
    {
      "t": 1310721,
      "n": "Enc",
      "d": 524408,
      "h": 25770328184,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328184),
//--TRIMMABLE-BOUNDARY-START(34360262776),
    {
      "t": 1310721,
      "n": "IV",
      "d": 524408,
      "h": 34360262776,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262776),
//--TRIMMABLE-BOUNDARY-START(38655230072),
    {
      "t": 1310721,
      "n": "Jku",
      "d": 524408,
      "h": 38655230072,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655230072),
//--TRIMMABLE-BOUNDARY-START(42950197368),
    {
      "t": 1310721,
      "n": "Jwk",
      "d": 524408,
      "h": 42950197368,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197368),
//--TRIMMABLE-BOUNDARY-START(47245164664),
    {
      "t": 1310721,
      "n": "Kid",
      "d": 524408,
      "h": 47245164664,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245164664),
//--TRIMMABLE-BOUNDARY-START(51540131960),
    {
      "t": 1310721,
      "n": "Typ",
      "d": 524408,
      "h": 51540131960,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540131960),
//--TRIMMABLE-BOUNDARY-START(55835099256),
    {
      "t": 1310721,
      "n": "X5c",
      "d": 524408,
      "h": 55835099256,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835099256),
//--TRIMMABLE-BOUNDARY-START(60130066552),
    {
      "t": 1310721,
      "n": "X5t",
      "d": 524408,
      "h": 60130066552,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066552),
//--TRIMMABLE-BOUNDARY-START(64425033848),
    {
      "t": 1310721,
      "n": "X5u",
      "d": 524408,
      "h": 64425033848,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425033848),
//--TRIMMABLE-BOUNDARY-START(68720001144),
    {
      "t": 1310721,
      "n": "Zip",
      "d": 524408,
      "h": 68720001144,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720001144)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491704),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524408,
      "h": 4295491704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491704)
  ],
  "h": 524408
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtHeaderParameterNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524408)
        
        
        //--TRIMMABLE-BOUNDARY-START(589944)
        $asm.$str("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes", ($self) => class JwtHeaderUtf8Bytes extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590524536)
            static /*ReadOnlySpan<byte> */ get Alg()
            {
                return this.$cacheAlg ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 108, 103]);
            }
            //--TRIMMABLE-BOUNDARY-END(8590524536)
            
            //--TRIMMABLE-BOUNDARY-START(12885491832)
            static /*ReadOnlySpan<byte> */ get Apu()
            {
                return this.$cacheApu ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 112, 117]);
            }
            //--TRIMMABLE-BOUNDARY-END(12885491832)
            
            //--TRIMMABLE-BOUNDARY-START(17180459128)
            static /*ReadOnlySpan<byte> */ get Apv()
            {
                return this.$cacheApv ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 112, 118]);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459128)
            
            //--TRIMMABLE-BOUNDARY-START(21475426424)
            static /*ReadOnlySpan<byte> */ get Cty()
            {
                return this.$cacheCty ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([99, 116, 121]);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426424)
            
            //--TRIMMABLE-BOUNDARY-START(25770393720)
            static /*ReadOnlySpan<byte> */ get Enc()
            {
                return this.$cacheEnc ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([101, 110, 99]);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393720)
            
            //--TRIMMABLE-BOUNDARY-START(30065361016)
            static /*ReadOnlySpan<byte> */ get Epk()
            {
                return this.$cacheEpk ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([101, 112, 107]);
            }
            //--TRIMMABLE-BOUNDARY-END(30065361016)
            
            //--TRIMMABLE-BOUNDARY-START(163209347192)
            static /*ReadOnlySpan<byte> */ get IV()
            {
                return this.$cacheIV ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([105, 118]);
            }
            //--TRIMMABLE-BOUNDARY-END(163209347192)
            
            //--TRIMMABLE-BOUNDARY-START(167504314488)
            static /*ReadOnlySpan<byte> */ get Jku()
            {
                return this.$cacheJku ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([106, 107, 117]);
            }
            //--TRIMMABLE-BOUNDARY-END(167504314488)
            
            //--TRIMMABLE-BOUNDARY-START(171799281784)
            static /*ReadOnlySpan<byte> */ get Jwk()
            {
                return this.$cacheJwk ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([106, 119, 107]);
            }
            //--TRIMMABLE-BOUNDARY-END(171799281784)
            
            //--TRIMMABLE-BOUNDARY-START(176094249080)
            static /*ReadOnlySpan<byte> */ get Kid()
            {
                return this.$cacheKid ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([107, 105, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(176094249080)
            
            //--TRIMMABLE-BOUNDARY-START(180389216376)
            static /*ReadOnlySpan<byte> */ get Typ()
            {
                return this.$cacheTyp ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([116, 121, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(180389216376)
            
            //--TRIMMABLE-BOUNDARY-START(184684183672)
            static /*ReadOnlySpan<byte> */ get X5c()
            {
                return this.$cacheX5c ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([120, 53, 99]);
            }
            //--TRIMMABLE-BOUNDARY-END(184684183672)
            
            //--TRIMMABLE-BOUNDARY-START(188979150968)
            static /*ReadOnlySpan<byte> */ get X5t()
            {
                return this.$cacheX5t ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([120, 53, 116]);
            }
            //--TRIMMABLE-BOUNDARY-END(188979150968)
            
            //--TRIMMABLE-BOUNDARY-START(193274118264)
            static /*ReadOnlySpan<byte> */ get X5u()
            {
                return this.$cacheX5u ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([120, 53, 117]);
            }
            //--TRIMMABLE-BOUNDARY-END(193274118264)
            
            //--TRIMMABLE-BOUNDARY-START(197569085560)
            static /*ReadOnlySpan<byte> */ get Zip()
            {
                return this.$cacheZip ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([122, 105, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(197569085560)
            
            //--TRIMMABLE-BOUNDARY-START(4295557240)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557240)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 589944;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590524536),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655295608,
        "f": 50331681
      },
      "n": "Alg",
      "d": 589944,
      "h": 8590524536,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(8590524536),
//--TRIMMABLE-BOUNDARY-START(12885491832),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245230200,
        "f": 50331681
      },
      "n": "Apu",
      "d": 589944,
      "h": 12885491832,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885491832),
//--TRIMMABLE-BOUNDARY-START(17180459128),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835164792,
        "f": 50331681
      },
      "n": "Apv",
      "d": 589944,
      "h": 17180459128,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180459128),
//--TRIMMABLE-BOUNDARY-START(21475426424),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425099384,
        "f": 50331681
      },
      "n": "Cty",
      "d": 589944,
      "h": 21475426424,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21475426424),
//--TRIMMABLE-BOUNDARY-START(25770393720),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015033976,
        "f": 50331681
      },
      "n": "Enc",
      "d": 589944,
      "h": 25770393720,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770393720),
//--TRIMMABLE-BOUNDARY-START(30065361016),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604968568,
        "f": 50331681
      },
      "n": "Epk",
      "d": 589944,
      "h": 30065361016,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30065361016),
//--TRIMMABLE-BOUNDARY-START(163209347192),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194903160,
        "f": 50331681
      },
      "n": "IV",
      "d": 589944,
      "h": 163209347192,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(163209347192),
//--TRIMMABLE-BOUNDARY-START(167504314488),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784837752,
        "f": 50331681
      },
      "n": "Jku",
      "d": 589944,
      "h": 167504314488,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(167504314488),
//--TRIMMABLE-BOUNDARY-START(171799281784),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374772344,
        "f": 50331681
      },
      "n": "Jwk",
      "d": 589944,
      "h": 171799281784,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(171799281784),
//--TRIMMABLE-BOUNDARY-START(176094249080),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964706936,
        "f": 50331681
      },
      "n": "Kid",
      "d": 589944,
      "h": 176094249080,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(176094249080),
//--TRIMMABLE-BOUNDARY-START(180389216376),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554641528,
        "f": 50331681
      },
      "n": "Typ",
      "d": 589944,
      "h": 180389216376,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(180389216376),
//--TRIMMABLE-BOUNDARY-START(184684183672),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144576120,
        "f": 50331681
      },
      "n": "X5c",
      "d": 589944,
      "h": 184684183672,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(184684183672),
//--TRIMMABLE-BOUNDARY-START(188979150968),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734510712,
        "f": 50331681
      },
      "n": "X5t",
      "d": 589944,
      "h": 188979150968,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(188979150968),
//--TRIMMABLE-BOUNDARY-START(193274118264),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324445304,
        "f": 50331681
      },
      "n": "X5u",
      "d": 589944,
      "h": 193274118264,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(193274118264),
//--TRIMMABLE-BOUNDARY-START(197569085560),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914379896,
        "f": 50331681
      },
      "n": "Zip",
      "d": 589944,
      "h": 197569085560,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(197569085560)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557240),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589944,
      "h": 4295557240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557240)
  ],
  "h": 589944
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589944)
        
        
        //--TRIMMABLE-BOUNDARY-START(655480)
        $asm.$str("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes", ($self) => class JwtPayloadUtf8Bytes extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885557368)
            static /*ReadOnlySpan<byte> */ get Actort()
            {
                return this.$cacheActort ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 99, 116, 111, 114, 116]);
            }
            //--TRIMMABLE-BOUNDARY-END(12885557368)
            
            //--TRIMMABLE-BOUNDARY-START(8590590072)
            static /*ReadOnlySpan<byte> */ get Acr()
            {
                return this.$cacheAcr ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 99, 114]);
            }
            //--TRIMMABLE-BOUNDARY-END(8590590072)
            
            //--TRIMMABLE-BOUNDARY-START(17180524664)
            static /*ReadOnlySpan<byte> */ get Amr()
            {
                return this.$cacheAmr ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 109, 114]);
            }
            //--TRIMMABLE-BOUNDARY-END(17180524664)
            
            //--TRIMMABLE-BOUNDARY-START(21475491960)
            static /*ReadOnlySpan<byte> */ get AtHash()
            {
                return this.$cacheAtHash ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 116, 95, 104, 97, 115, 104]);
            }
            //--TRIMMABLE-BOUNDARY-END(21475491960)
            
            //--TRIMMABLE-BOUNDARY-START(25770459256)
            static /*ReadOnlySpan<byte> */ get Aud()
            {
                return this.$cacheAud ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 117, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(25770459256)
            
            //--TRIMMABLE-BOUNDARY-START(30065426552)
            static /*ReadOnlySpan<byte> */ get AuthTime()
            {
                return this.$cacheAuthTime ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 117, 116, 104, 95, 116, 105, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(30065426552)
            
            //--TRIMMABLE-BOUNDARY-START(34360393848)
            static /*ReadOnlySpan<byte> */ get Azp()
            {
                return this.$cacheAzp ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 122, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(34360393848)
            
            //--TRIMMABLE-BOUNDARY-START(38655361144)
            static /*ReadOnlySpan<byte> */ get Birthdate()
            {
                return this.$cacheBirthdate ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([98, 105, 114, 116, 104, 100, 97, 116, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(38655361144)
            
            //--TRIMMABLE-BOUNDARY-START(42950328440)
            static /*ReadOnlySpan<byte> */ get CHash()
            {
                return this.$cacheCHash ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([99, 95, 104, 97, 115, 104]);
            }
            //--TRIMMABLE-BOUNDARY-END(42950328440)
            
            //--TRIMMABLE-BOUNDARY-START(47245295736)
            static /*ReadOnlySpan<byte> */ get Email()
            {
                return this.$cacheEmail ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([101, 109, 97, 105, 108]);
            }
            //--TRIMMABLE-BOUNDARY-END(47245295736)
            
            //--TRIMMABLE-BOUNDARY-START(51540263032)
            static /*ReadOnlySpan<byte> */ get Exp()
            {
                return this.$cacheExp ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([101, 120, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(51540263032)
            
            //--TRIMMABLE-BOUNDARY-START(60130197624)
            static /*ReadOnlySpan<byte> */ get Gender()
            {
                return this.$cacheGender ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([103, 101, 110, 100, 101, 114]);
            }
            //--TRIMMABLE-BOUNDARY-END(60130197624)
            
            //--TRIMMABLE-BOUNDARY-START(55835230328)
            static /*ReadOnlySpan<byte> */ get FamilyName()
            {
                return this.$cacheFamilyName ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([102, 97, 109, 105, 108, 121, 95, 110, 97, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(55835230328)
            
            //--TRIMMABLE-BOUNDARY-START(313533268088)
            static /*ReadOnlySpan<byte> */ get GivenName()
            {
                return this.$cacheGivenName ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([103, 105, 118, 101, 110, 95, 110, 97, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(313533268088)
            
            //--TRIMMABLE-BOUNDARY-START(317828235384)
            static /*ReadOnlySpan<byte> */ get Iat()
            {
                return this.$cacheIat ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([105, 97, 116]);
            }
            //--TRIMMABLE-BOUNDARY-END(317828235384)
            
            //--TRIMMABLE-BOUNDARY-START(322123202680)
            static /*ReadOnlySpan<byte> */ get Iss()
            {
                return this.$cacheIss ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([105, 115, 115]);
            }
            //--TRIMMABLE-BOUNDARY-END(322123202680)
            
            //--TRIMMABLE-BOUNDARY-START(326418169976)
            static /*ReadOnlySpan<byte> */ get Jti()
            {
                return this.$cacheJti ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([106, 116, 105]);
            }
            //--TRIMMABLE-BOUNDARY-END(326418169976)
            
            //--TRIMMABLE-BOUNDARY-START(330713137272)
            static /*ReadOnlySpan<byte> */ get Name()
            {
                return this.$cacheName ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([110, 97, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(330713137272)
            
            //--TRIMMABLE-BOUNDARY-START(335008104568)
            static /*ReadOnlySpan<byte> */ get NameId()
            {
                return this.$cacheNameId ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([110, 97, 109, 101, 105, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(335008104568)
            
            //--TRIMMABLE-BOUNDARY-START(343598039160)
            static /*ReadOnlySpan<byte> */ get Nonce()
            {
                return this.$cacheNonce ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([110, 111, 110, 99, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(343598039160)
            
            //--TRIMMABLE-BOUNDARY-START(339303071864)
            static /*ReadOnlySpan<byte> */ get Nbf()
            {
                return this.$cacheNbf ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([110, 98, 102]);
            }
            //--TRIMMABLE-BOUNDARY-END(339303071864)
            
            //--TRIMMABLE-BOUNDARY-START(347893006456)
            static /*ReadOnlySpan<byte> */ get PhoneNumber()
            {
                return this.$cachePhoneNumber ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([112, 104, 111, 110, 101, 95, 110, 117, 109, 98, 101, 114]);
            }
            //--TRIMMABLE-BOUNDARY-END(347893006456)
            
            //--TRIMMABLE-BOUNDARY-START(352187973752)
            static /*ReadOnlySpan<byte> */ get PhoneNumberVerified()
            {
                return this.$cachePhoneNumberVerified ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([112, 104, 111, 110, 101, 95, 110, 117, 109, 98, 101, 114, 95, 118, 101, 114, 105, 102, 105, 101, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(352187973752)
            
            //--TRIMMABLE-BOUNDARY-START(356482941048)
            static /*ReadOnlySpan<byte> */ get Prn()
            {
                return this.$cachePrn ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([112, 114, 110]);
            }
            //--TRIMMABLE-BOUNDARY-END(356482941048)
            
            //--TRIMMABLE-BOUNDARY-START(360777908344)
            static /*ReadOnlySpan<byte> */ get Sid()
            {
                return this.$cacheSid ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([115, 105, 100]);
            }
            //--TRIMMABLE-BOUNDARY-END(360777908344)
            
            //--TRIMMABLE-BOUNDARY-START(365072875640)
            static /*ReadOnlySpan<byte> */ get Sub()
            {
                return this.$cacheSub ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([115, 117, 98]);
            }
            //--TRIMMABLE-BOUNDARY-END(365072875640)
            
            //--TRIMMABLE-BOUNDARY-START(369367842936)
            static /*ReadOnlySpan<byte> */ get Typ()
            {
                return this.$cacheTyp ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([116, 121, 112]);
            }
            //--TRIMMABLE-BOUNDARY-END(369367842936)
            
            //--TRIMMABLE-BOUNDARY-START(373662810232)
            static /*ReadOnlySpan<byte> */ get UniqueName()
            {
                return this.$cacheUniqueName ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([117, 110, 105, 113, 117, 101, 95, 110, 97, 109, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(373662810232)
            
            //--TRIMMABLE-BOUNDARY-START(377957777528)
            static /*ReadOnlySpan<byte> */ get Website()
            {
                return this.$cacheWebsite ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([119, 101, 98, 115, 105, 116, 101]);
            }
            //--TRIMMABLE-BOUNDARY-END(377957777528)
            
            //--TRIMMABLE-BOUNDARY-START(4295622776)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622776)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 655480;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885557368),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310066808,
        "f": 50331681
      },
      "n": "Actort",
      "d": 655480,
      "h": 12885557368,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885557368),
//--TRIMMABLE-BOUNDARY-START(8590590072),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132216,
        "f": 50331681
      },
      "n": "Acr",
      "d": 655480,
      "h": 8590590072,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(8590590072),
//--TRIMMABLE-BOUNDARY-START(17180524664),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900001400,
        "f": 50331681
      },
      "n": "Amr",
      "d": 655480,
      "h": 17180524664,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180524664),
//--TRIMMABLE-BOUNDARY-START(21475491960),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489935992,
        "f": 50331681
      },
      "n": "AtHash",
      "d": 655480,
      "h": 21475491960,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21475491960),
//--TRIMMABLE-BOUNDARY-START(25770459256),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079870584,
        "f": 50331681
      },
      "n": "Aud",
      "d": 655480,
      "h": 25770459256,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770459256),
//--TRIMMABLE-BOUNDARY-START(30065426552),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669805176,
        "f": 50331681
      },
      "n": "AuthTime",
      "d": 655480,
      "h": 30065426552,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30065426552),
//--TRIMMABLE-BOUNDARY-START(34360393848),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259739768,
        "f": 50331681
      },
      "n": "Azp",
      "d": 655480,
      "h": 34360393848,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360393848),
//--TRIMMABLE-BOUNDARY-START(38655361144),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849674360,
        "f": 50331681
      },
      "n": "Birthdate",
      "d": 655480,
      "h": 38655361144,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38655361144),
//--TRIMMABLE-BOUNDARY-START(42950328440),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439608952,
        "f": 50331681
      },
      "n": "CHash",
      "d": 655480,
      "h": 42950328440,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42950328440),
//--TRIMMABLE-BOUNDARY-START(47245295736),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029543544,
        "f": 50331681
      },
      "n": "Email",
      "d": 655480,
      "h": 47245295736,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47245295736),
//--TRIMMABLE-BOUNDARY-START(51540263032),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619478136,
        "f": 50331681
      },
      "n": "Exp",
      "d": 655480,
      "h": 51540263032,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51540263032),
//--TRIMMABLE-BOUNDARY-START(60130197624),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799347320,
        "f": 50331681
      },
      "n": "Gender",
      "d": 655480,
      "h": 60130197624,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(60130197624),
//--TRIMMABLE-BOUNDARY-START(55835230328),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209412728,
        "f": 50331681
      },
      "n": "FamilyName",
      "d": 655480,
      "h": 55835230328,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(55835230328),
//--TRIMMABLE-BOUNDARY-START(313533268088),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389281912,
        "f": 50331681
      },
      "n": "GivenName",
      "d": 655480,
      "h": 313533268088,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(313533268088),
//--TRIMMABLE-BOUNDARY-START(317828235384),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979216504,
        "f": 50331681
      },
      "n": "Iat",
      "d": 655480,
      "h": 317828235384,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(317828235384),
//--TRIMMABLE-BOUNDARY-START(322123202680),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569151096,
        "f": 50331681
      },
      "n": "Iss",
      "d": 655480,
      "h": 322123202680,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(322123202680),
//--TRIMMABLE-BOUNDARY-START(326418169976),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159085688,
        "f": 50331681
      },
      "n": "Jti",
      "d": 655480,
      "h": 326418169976,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(326418169976),
//--TRIMMABLE-BOUNDARY-START(330713137272),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749020280,
        "f": 50331681
      },
      "n": "Name",
      "d": 655480,
      "h": 330713137272,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(330713137272),
//--TRIMMABLE-BOUNDARY-START(335008104568),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338954872,
        "f": 50331681
      },
      "n": "NameId",
      "d": 655480,
      "h": 335008104568,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(335008104568),
//--TRIMMABLE-BOUNDARY-START(343598039160),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518824056,
        "f": 50331681
      },
      "n": "Nonce",
      "d": 655480,
      "h": 343598039160,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(343598039160),
//--TRIMMABLE-BOUNDARY-START(339303071864),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928889464,
        "f": 50331681
      },
      "n": "Nbf",
      "d": 655480,
      "h": 339303071864,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(339303071864),
//--TRIMMABLE-BOUNDARY-START(347893006456),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108758648,
        "f": 50331681
      },
      "n": "PhoneNumber",
      "d": 655480,
      "h": 347893006456,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(347893006456),
//--TRIMMABLE-BOUNDARY-START(352187973752),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698693240,
        "f": 50331681
      },
      "n": "PhoneNumberVerified",
      "d": 655480,
      "h": 352187973752,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(352187973752),
//--TRIMMABLE-BOUNDARY-START(356482941048),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288627832,
        "f": 50331681
      },
      "n": "Prn",
      "d": 655480,
      "h": 356482941048,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(356482941048),
//--TRIMMABLE-BOUNDARY-START(360777908344),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878562424,
        "f": 50331681
      },
      "n": "Sid",
      "d": 655480,
      "h": 360777908344,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(360777908344),
//--TRIMMABLE-BOUNDARY-START(365072875640),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468497016,
        "f": 50331681
      },
      "n": "Sub",
      "d": 655480,
      "h": 365072875640,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(365072875640),
//--TRIMMABLE-BOUNDARY-START(369367842936),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292058431608,
        "f": 50331681
      },
      "n": "Typ",
      "d": 655480,
      "h": 369367842936,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(369367842936),
//--TRIMMABLE-BOUNDARY-START(373662810232),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300648366200,
        "f": 50331681
      },
      "n": "UniqueName",
      "d": 655480,
      "h": 373662810232,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(373662810232),
//--TRIMMABLE-BOUNDARY-START(377957777528),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309238300792,
        "f": 50331681
      },
      "n": "Website",
      "d": 655480,
      "h": 377957777528,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(377957777528)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622776),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655480,
      "h": 4295622776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622776)
  ],
  "h": 655480
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655480)
        
        
        //--TRIMMABLE-BOUNDARY-START(327800)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler", ($self) => class JsonWebTokenHandler extends $.$mit.Microsoft.IdentityModel.Tokens.TokenHandler
        {
            //--TRIMMABLE-BOUNDARY-START(64424837240)
            /*ClaimsIdentity */ CreateClaimsIdentity$1(/*JsonWebToken?*/ jwtToken, /*ValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken") });
                return this.CreateClaimsIdentityPrivate(jwtToken, validationParameters, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActualIssuer(jwtToken));
            }
            //--TRIMMABLE-BOUNDARY-END(64424837240)
            
            //--TRIMMABLE-BOUNDARY-START(60129869944)
            /*ClaimsIdentity */ CreateClaimsIdentity(/*JsonWebToken?*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken") });
                if ($.$$.System.String.IsNullOrWhiteSpace(issuer))
                {
                    issuer = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActualIssuer(jwtToken);
                }
                if (this.MapInboundClaims)
                {
                    return this.CreateClaimsIdentityWithMapping(jwtToken, validationParameters, issuer);
                }
                return this.CreateClaimsIdentityPrivate(jwtToken, validationParameters, issuer);
            }
            //--TRIMMABLE-BOUNDARY-END(60129869944)
            
            //--TRIMMABLE-BOUNDARY-START(77309739128)
            /*ClaimsIdentity */ CreateClaimsIdentityInternal(/*SecurityToken*/ securityToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateClaimsIdentity($.$as(securityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken), validationParameters, issuer);
            }
            //--TRIMMABLE-BOUNDARY-END(77309739128)
            
            //--TRIMMABLE-BOUNDARY-START(94489608312)
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string?*/ let type;
                        /*bool*/ let wasMapped = this._inboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => type, ($v) => type = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]);
                        /*string*/ let claimType = type ?? jwtClaim.Type;
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken?*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$1(actor, validationParameters);
                            }
                        }
                        if (wasMapped)
                        {
                            /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count > 0)
                            {
                                var $en6 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var kv = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                    }
                                }
                            }
                            claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ShortClaimTypeProperty, jwtClaim.Type, [$.$$.System.String, $.$$.System.String]);
                            identity.AddClaim(claim);
                        }
                        else 
                        {
                            identity.AddClaim(jwtClaim);
                        }
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(94489608312)
            
            //--TRIMMABLE-BOUNDARY-START(85899673720)
            /*ClaimsIdentity */ CreateClaimsIdentityPrivate(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType = jwtClaim.Type;
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken?*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, validationParameters, issuer);
                            }
                        }
                        if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count === 0)
                        {
                            identity.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity));
                        }
                        else 
                        {
                            /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            var $en5 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kv = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                }
                            }
                            identity.AddClaim(claim);
                        }
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(85899673720)
            
            //--TRIMMABLE-BOUNDARY-START(360777580664)
            static /*ValidationResult<SecurityToken, ValidationError> */ ReadToken$1(/*string*/ token, /*CallContext?*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777580664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(token))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("token", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ReadToken.cs", 30, 1)));
                }
                try
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit$1(new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$7(token));
                }
                catch(ex)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$1(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$2("IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX14107*/), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenReadingFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ReadToken.cs", 44, 1), ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(360777580664)
            
            //--TRIMMABLE-BOUNDARY-START(519691370616)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateTokenAsync(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(519691370616);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrEmpty(token))
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("token", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 29, 1)));
                    }
                    if (validationParameters === null)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 36, 1)));
                    }
                    if (token.length > this.MaximumTokenSizeInBytes)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.SecurityTokenTooLarge, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 47, 1)));
                    }
                    /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$1(token, callContext);
                    if (readResult.Succeeded)
                    {
                        /*ValidationResult<ValidatedToken, ValidationError>*/ let validationResult = await this.ValidateTokenAsync$3(readResult.Result, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false);
                        if (validationResult.Succeeded)
                        {
                            return validationResult;
                        }
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(validationResult.Error.AddStackFrame($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 67, 1)));
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 70, 1));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(519691370616)
            
            //--TRIMMABLE-BOUNDARY-START(536871239800)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateTokenAsync$3(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(536871239800);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (token === null)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("token", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 84, 1)));
                    }
                    if (validationParameters === null)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 91, 1)));
                    }
                    let jsonWebToken;
                    if (!$.$is(token, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken, { set $v(v){ jsonWebToken = v; } }))
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10001: Invalid argument '{0}'. Argument must be of type '{1}'."/*TokenLogMessages.IDX10001*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "token", "JsonWebToken" ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.SecurityTokenNotExpectedType, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 99, 1)));
                    }
                    /*BaseConfiguration?*/ let currentConfiguration = await $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetCurrentConfigurationAsync(validationParameters, cancellationToken).ConfigureAwait$2(false);
                    /*ValidationResult<ValidatedToken, ValidationError>*/ let result = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false);
                    if (validationParameters.ConfigurationManager === null)
                    {
                        if (result.Succeeded)
                        {
                            return result;
                        }
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(result.Error.AddStackFrame($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 118, 1)));
                    }
                    if (result.Succeeded)
                    {
                        if (!(currentConfiguration === null))
                        {
                            validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                        }
                        return result;
                    }
                    if ($.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableFailureType(result.Error.FailureType, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.System$Collections$Generic$ICollection$$$Count > 0)))
                    {
                        if (!(currentConfiguration === null))
                        {
                            validationParameters.ConfigurationManager.RequestRefresh();
                            validationParameters.RefreshBeforeValidation = true;
                            /*BaseConfiguration*/ let lastConfig = currentConfiguration;
                            currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.System.Threading.CancellationToken.None).ConfigureAwait$2(false);
                            if (lastConfig !== currentConfiguration)
                            {
                                result = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false);
                                if (result.Succeeded)
                                {
                                    validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                    return result;
                                }
                            }
                        }
                        if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                        {
                            validationParameters.RefreshBeforeValidation = false;
                            validationParameters.ValidateWithLKG = true;
                            /*ValidationFailureType*/ let failureType = result.Error.FailureType;
                            /*BaseConfiguration[]*/ let validConfigurations = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                            for(/*int*/ let i = 0; i < validConfigurations.length; i++)
                            {
                                /*BaseConfiguration*/ let lkgConfiguration = $.$$.System.Array.$ReadT1.call(validConfigurations, i);
                                if ($.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableConfigurationAndExceptionType$1(jsonWebToken.Kid, currentConfiguration, lkgConfiguration, failureType))
                                {
                                    result = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync(jsonWebToken, validationParameters, lkgConfiguration, callContext, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync(jsonWebToken, validationParameters, lkgConfiguration, callContext, cancellationToken).ConfigureAwait(false);
                                    if (result.Succeeded)
                                    {
                                        return result;
                                    }
                                }
                            }
                        }
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(result.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 191, 1));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(536871239800)
            
            //--TRIMMABLE-BOUNDARY-START(450971893880)
            /*ValueTask<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateJWEAsync(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(450971893880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ValidationResult<string, ValidationError>*/ let decryptionResult = this.DecryptToken(jwtToken, validationParameters, configuration, callContext);
                    if (!decryptionResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(decryptionResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 205, 1));
                    }
                    /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$1(decryptionResult.Result, callContext);
                    if (!readResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 211, 1));
                    }
                    /*JsonWebToken*/ let decryptedToken = ($.$as(readResult.Result, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken));
                    /*ValidationResult<ValidatedToken, ValidationError>*/ let validationResult = await this.ValidateJWSAsync(decryptedToken, validationParameters, configuration, callContext, cancellationToken).ConfigureAwait(false);
                    if (!validationResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(validationResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 221, 1));
                    }
                    /*JsonWebToken*/ let jsonWebToken = ($.$as(validationResult.Result.SecurityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken));
                    jwtToken.InnerToken = jsonWebToken;
                    jwtToken.Payload = jsonWebToken.Payload;
                    return validationResult;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(450971893880)
            
            //--TRIMMABLE-BOUNDARY-START(463856795768)
            /*ValueTask<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateJWSAsync(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(463856795768);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*DateTime?*/ let expires = jsonWebToken.HasPayloadClaim("exp"/*JwtRegisteredClaimNames.Exp*/) ? jsonWebToken.ValidTo : null;
                    /*DateTime?*/ let notBefore = jsonWebToken.HasPayloadClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/) ? jsonWebToken.ValidFrom : null;
                    /*ValidationResult<ValidatedLifetime, ValidationError>*/ let lifetimeResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateLifetimeInternal(notBefore?.Clone() ?? null, expires?.Clone() ?? null, jsonWebToken, validationParameters, callContext);
                    if (!lifetimeResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(lifetimeResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 253, 1));
                    }
                    let tokenAudiences;
                    if (!$.$is(jsonWebToken.Audiences, $.$$.System.Collections.Generic.IList$$($.$$.System.String), { set $v(v){ tokenAudiences = v; } }))
                    {
                        tokenAudiences = (() =>
                        {
                            let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                            $t1.AddRange(jsonWebToken.Audiences);
                            return $t1;
                        })();
                    }
                    /*ValidationResult<string, ValidationError>*/ let audienceResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAudienceInternal(tokenAudiences, jsonWebToken, validationParameters, callContext);
                    if (!audienceResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(audienceResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 274, 1));
                    }
                    /*ValidationResult<ValidatedIssuer, ValidationError>*/ let issuerResult = await $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerInternalAsync(jsonWebToken.Issuer, jsonWebToken, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false);
                    if (!issuerResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(issuerResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 289, 1));
                    }
                    /*ValidationResult<DateTime?, ValidationError>?*/ let tokenReplayResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenReplayInternal(expires?.Clone() ?? null, jsonWebToken.EncodedToken, validationParameters, callContext);
                    if (!$.$$.System.Nullable$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.Nullable$$($.$$.System.DateTime), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).Value$get.call(tokenReplayResult).Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$$.System.Nullable$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.Nullable$$($.$$.System.DateTime), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).Value$get.call(tokenReplayResult).Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 303, 1));
                    }
                    /*ValidationResult<ValidatedTokenType, ValidationError>*/ let tokenTypeResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenTypeInternal(jsonWebToken.Typ, jsonWebToken, validationParameters, callContext);
                    if (!tokenTypeResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(tokenTypeResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 317, 1));
                    }
                    /*ValidationResult<string, ValidationError>*/ let algorithmResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAlgorithmInternal(jsonWebToken.Alg, jsonWebToken, validationParameters, callContext);
                    if (!algorithmResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(algorithmResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 331, 1));
                    }
                    /*ValidationResult<SecurityKey, ValidationError>*/ let signatureResult = this.ValidateSignature$1(jsonWebToken, validationParameters, configuration, callContext);
                    if (!signatureResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(signatureResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 346, 1));
                    }
                    /*ValidationResult<ValidatedSignatureKey, ValidationError>*/ let signatureKeyResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateSignatureKeyInternal(jsonWebToken.SigningKey, jsonWebToken, validationParameters, callContext);
                    if (!signatureKeyResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(signatureKeyResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 360, 1));
                    }
                    /*ValidationResult<ValidatedToken, ValidationError>?*/ let actorResult = null;
                    if (validationParameters.ValidateActor && !$.$$.System.String.IsNullOrWhiteSpace(jsonWebToken.Actor))
                    {
                        /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$1(jsonWebToken.Actor, callContext);
                        if (!readResult.Succeeded)
                        {
                            return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 372, 1));
                        }
                        if (validationParameters.ActorValidationParameters === null)
                        {
                            return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("ActorValidationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 381, 1)));
                        }
                        /*JsonWebToken*/ let actorToken = ($.$as(readResult.Result, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken));
                        actorResult = await this.ValidateJWSAsync(actorToken, validationParameters.ActorValidationParameters, configuration, callContext, cancellationToken).ConfigureAwait(false);
                        if (!$.$$.System.Nullable$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).Value$get.call(actorResult).Succeeded)
                        {
                            return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$$.System.Nullable$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).Value$get.call(actorResult).Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 397, 1));
                        }
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit$1((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken;
                        const $i1 = new $t1();
                        $i1.$ctor$1(jsonWebToken, this, validationParameters);
                        $i1.ValidatedLifetime = lifetimeResult.Result;
                        $i1.ValidatedAlgorithm = algorithmResult.Result;
                        $i1.ValidatedAudience = audienceResult.Result;
                        $i1.ValidatedIssuer = issuerResult.Result;
                        $i1.ActorValidationResult = (actorResult?.Result ?? null);
                        $i1.ValidatedTokenType = tokenTypeResult.Result;
                        $i1.ValidatedSignatureKey = signatureResult.Result;
                        return $i1;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(463856795768)
            
            //--TRIMMABLE-BOUNDARY-START(300648038520)
            static /*Task<BaseConfiguration?> *//*async*/  GetCurrentConfigurationAsync(/*ValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.BaseConfiguration), $.$mit.Microsoft.IdentityModel.Tokens.BaseConfiguration, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300648038520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*BaseConfiguration?*/ let currentConfiguration = null;
                    if (!(validationParameters.ConfigurationManager === null))
                    {
                        try
                        {
                            currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false);
                        }
                        catch($e)
                        {
                        }
                    }
                    return currentConfiguration;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(300648038520)
            
            //--TRIMMABLE-BOUNDARY-START(335007776888)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  Microsoft$IdentityModel$Tokens$Experimental$IResultBasedValidation$ValidateTokenAsync$1(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(335007776888);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await this.ValidateTokenAsync(token, validationParameters, callContext, new $.$$.System.Threading.CancellationToken()).ConfigureAwait$2(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(335007776888)
            
            //--TRIMMABLE-BOUNDARY-START(330712809592)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  Microsoft$IdentityModel$Tokens$Experimental$IResultBasedValidation$ValidateTokenAsync(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(330712809592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await this.ValidateTokenAsync(token, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(330712809592)
            
            //--TRIMMABLE-BOUNDARY-START(343597711480)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  Microsoft$IdentityModel$Tokens$Experimental$IResultBasedValidation$ValidateTokenAsync$3(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(343597711480);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await this.ValidateTokenAsync$3(token, validationParameters, callContext, new $.$$.System.Threading.CancellationToken()).ConfigureAwait$2(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(343597711480)
            
            //--TRIMMABLE-BOUNDARY-START(339302744184)
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  Microsoft$IdentityModel$Tokens$Experimental$IResultBasedValidation$ValidateTokenAsync$2(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(339302744184);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await this.ValidateTokenAsync$3(token, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(339302744184)
            
            //--TRIMMABLE-BOUNDARY-START(4295295096)
            /*IDictionary<string, string>*/ _inboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(4295295096)
            
            //--TRIMMABLE-BOUNDARY-START(12885229688)
            /*string*/ static _namespace = null;
            //--TRIMMABLE-BOUNDARY-END(12885229688)
            
            //--TRIMMABLE-BOUNDARY-START(17180196984)
            /*string*/ static _shortClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(17180196984)
            
            //--TRIMMABLE-BOUNDARY-START(8590262392)
            /*bool*/ _mapInboundClaims = false;
            //--TRIMMABLE-BOUNDARY-END(8590262392)
            
            //--TRIMMABLE-BOUNDARY-START(193273856120)
            /*IDictionary<string, string>*/ static DefaultInboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(193273856120)
            
            //--TRIMMABLE-BOUNDARY-START(197568823416)
            /*bool*/ static DefaultMapInboundClaims = false;
            //--TRIMMABLE-BOUNDARY-END(197568823416)
            
            //--TRIMMABLE-BOUNDARY-START(42950000760)
            /*string*/ static Base64UrlEncodedUnsignedJWSHeader = null;
            //--TRIMMABLE-BOUNDARY-END(42950000760)
            
            //--TRIMMABLE-BOUNDARY-START(30065098872)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098872);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._mapInboundClaims)
                    {
                        this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.DefaultInboundClaimTypeMap);
                    }
                    else 
                    {
                        this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065098872)
            
            //--TRIMMABLE-BOUNDARY-START(446676926584)
            /*Type */ get TokenType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173202040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(446676926584)
            
            //--TRIMMABLE-BOUNDARY-START(438086991992)
            static /*string */ get ShortClaimTypeProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583267448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler._shortClaimType;
            }
            static /*string */ set ShortClaimTypeProperty(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792024696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler._shortClaimType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(438086991992)
            
            //--TRIMMABLE-BOUNDARY-START(322122875000)
            /*bool */ get MapInboundClaims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403398264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mapInboundClaims;
            }
            /*bool */ set MapInboundClaims(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612155512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._mapInboundClaims && value && this._inboundClaimTypeMap.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.DefaultInboundClaimTypeMap);
                }
                this._mapInboundClaims = value;
            }
            //--TRIMMABLE-BOUNDARY-END(322122875000)
            
            //--TRIMMABLE-BOUNDARY-START(313532940408)
            /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813463672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set InboundClaimTypeMap(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022220920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inboundClaimTypeMap = $.$firstOf(value, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value") });
            }
            //--TRIMMABLE-BOUNDARY-END(313532940408)
            
            //--TRIMMABLE-BOUNDARY-START(47244968056)
            /*bool */ CanReadToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244968056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrWhiteSpace(token))
                {
                    return false;
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null));
                    }
                    return false;
                }
                /*int*/ let pos = 0;
                /*int*/ let segmentCount = 1;
                while(segmentCount <= 5/*JwtConstants.MaxJwtSegmentCount*/ && ((pos = $.$$.System.String.IndexOf$1.call(token, /*.*/ 46, pos)) >= 0))
                {
                    pos++;
                    segmentCount++;
                }
                switch(segmentCount)
                {
                    case 3/*JwtConstants.JwsSegmentCount*/:
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJws.IsMatch$9(token);
                    case 5/*JwtConstants.JweSegmentCount*/:
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJwe.IsMatch$9(token);
                    default:
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX14107*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244968056)
            
            //--TRIMMABLE-BOUNDARY-START(304943005816)
            static /*StringComparison */ GetStringComparisonRuleIf509(/*SecurityKey*/ securityKey)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(304943005816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(304943005816)
            
            //--TRIMMABLE-BOUNDARY-START(309237973112)
            static /*StringComparison */ GetStringComparisonRuleIf509OrECDsa(/*SecurityKey*/ securityKey)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(309237973112);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$is(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) || $.$is(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey)) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309237973112)
            
            //--TRIMMABLE-BOUNDARY-START(73014771832)
            /*ClaimsIdentity */ CreateClaimsIdentity$3(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken") });
                return this.CreateClaimsIdentityPrivate$1(jwtToken, validationParameters, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActualIssuer(jwtToken));
            }
            //--TRIMMABLE-BOUNDARY-END(73014771832)
            
            //--TRIMMABLE-BOUNDARY-START(68719804536)
            /*ClaimsIdentity */ CreateClaimsIdentity$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719804536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken") });
                if ($.$$.System.String.IsNullOrWhiteSpace(issuer))
                {
                    issuer = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActualIssuer(jwtToken);
                }
                if (this.MapInboundClaims)
                {
                    return this.CreateClaimsIdentityWithMapping$1(jwtToken, validationParameters, issuer);
                }
                return this.CreateClaimsIdentityPrivate$1(jwtToken, validationParameters, issuer);
            }
            //--TRIMMABLE-BOUNDARY-END(68719804536)
            
            //--TRIMMABLE-BOUNDARY-START(98784575608)
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType;
                        /*bool*/ let wasMapped = this._inboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => claimType, ($v) => claimType = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]);
                        if (!wasMapped)
                        {
                            claimType = jwtClaim.Type;
                        }
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$3(actor, validationParameters);
                            }
                        }
                        if (wasMapped)
                        {
                            /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count > 0)
                            {
                                var $en6 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var kv = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                    }
                                }
                            }
                            claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ShortClaimTypeProperty, jwtClaim.Type, [$.$$.System.String, $.$$.System.String]);
                            identity.AddClaim(claim);
                        }
                        else 
                        {
                            identity.AddClaim(jwtClaim);
                        }
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(98784575608)
            
            //--TRIMMABLE-BOUNDARY-START(81604706424)
            /*ClaimsIdentity */ CreateClaimsIdentityInternal$1(/*SecurityToken*/ securityToken, /*TokenValidationParameters*/ tokenValidationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateClaimsIdentity$2($.$as(securityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken), tokenValidationParameters, issuer);
            }
            //--TRIMMABLE-BOUNDARY-END(81604706424)
            
            //--TRIMMABLE-BOUNDARY-START(287763136632)
            static /*string */ GetActualIssuer(/*JsonWebToken*/ jwtToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763136632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let actualIssuer = jwtToken.Issuer;
                if ($.$$.System.String.IsNullOrWhiteSpace(actualIssuer))
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX10244: Issuer is null or empty. Using runtime default for creating claims '{0}'."/*TokenLogMessages.IDX10244*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/ ], null, null));
                    }
                    actualIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                }
                return actualIssuer;
            }
            //--TRIMMABLE-BOUNDARY-END(287763136632)
            
            //--TRIMMABLE-BOUNDARY-START(90194641016)
            /*ClaimsIdentity */ CreateClaimsIdentityPrivate$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194641016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType = jwtClaim.Type;
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$2(actor, validationParameters, issuer);
                            }
                        }
                        if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count === 0)
                        {
                            identity.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity));
                        }
                        else 
                        {
                            /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            var $en5 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kv = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                }
                            }
                            identity.AddClaim(claim);
                        }
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(90194641016)
            
            //--TRIMMABLE-BOUNDARY-START(188978888824)
            /*Task<string> *//*async*/  DecryptTokenWithConfigurationAsync(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188978888824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (jwtToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                    }
                    if (validationParameters === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                    }
                    if ($.$$.System.String.IsNullOrEmpty(jwtToken.Enc))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null))));
                    }
                    /*BaseConfiguration*/ let currentConfiguration = null;
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        try
                        {
                            currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false);
                        }
                        catch(ex)
                        {
                            if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10278: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token decryption in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10278*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ validationParameters.ConfigurationManager.MetadataAddress, $.$$.System.Exception.ToString.call(ex) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            }
                        }
                    }
                    return this.DecryptToken$1(jwtToken, validationParameters, currentConfiguration);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(188978888824)
            
            //--TRIMMABLE-BOUNDARY-START(184683921528)
            /*string */ DecryptToken$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683921528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DecryptToken$1(jwtToken, validationParameters, null);
            }
            //--TRIMMABLE-BOUNDARY-END(184683921528)
            
            //--TRIMMABLE-BOUNDARY-START(180388954232)
            /*string */ DecryptToken$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388954232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.Enc))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null))));
                }
                /*var*/ let keys = this.GetContentEncryptionKeys$1(jwtToken, validationParameters, configuration);
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, keys);
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptJwtToken$1(jwtToken, validationParameters, decryptionParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(180388954232)
            
            //--TRIMMABLE-BOUNDARY-START(103079542904)
            /*JwtTokenDecryptionParameters */ CreateJwtTokenDecryptionParameters(/*JsonWebToken*/ jwtToken, /*IEnumerable<SecurityKey>*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters()
                    const $t1 = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters;
                    const $i1 = new $t1();
                    $i1.Alg = jwtToken.Alg;
                    $i1.AuthenticationTagBytes = jwtToken.AuthenticationTagBytes;
                    $i1.CipherTextBytes = jwtToken.CipherTextBytes;
                    $i1.DecompressionFunction = new ($.$$.System.Func$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.String, $.$$.System.Int32, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecompressToken);
                    $i1.Enc = jwtToken.Enc;
                    $i1.EncodedToken = jwtToken.EncodedToken;
                    $i1.HeaderAsciiBytes = jwtToken.HeaderAsciiBytes;
                    $i1.InitializationVectorBytes = jwtToken.InitializationVectorBytes;
                    $i1.MaximumDeflateSize = this.MaximumTokenSizeInBytes;
                    $i1.Keys$1 = keys;
                    $i1.Zip = jwtToken.Zip;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(103079542904)
            
            //--TRIMMABLE-BOUNDARY-START(390842351736)
            static /*SecurityKey */ ResolveTokenDecryptionKeyFromConfig(/*JsonWebToken*/ jwtToken, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842351736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Kid) && configuration.TokenDecryptionKeys !== null)
                {
                    var $en3 = configuration.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Kid, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                            {
                                return key;
                            }
                        }
                    }
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.X5t) && configuration.TokenDecryptionKeys !== null)
                {
                    var $en3 = configuration.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.X5t, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                            {
                                return key;
                            }
                            /*var*/ let x509Key = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                            if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                return key;
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(390842351736)
            
            //--TRIMMABLE-BOUNDARY-START(382252417144)
            /*SecurityKey */ ResolveTokenDecryptionKey(/*string*/ token, /*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252417144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*StringComparison*/ let stringComparison = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(validationParameters.TokenDecryptionKey);
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Kid))
                {
                    if (validationParameters.TokenDecryptionKey !== null && $.$$.System.String.Equals$2(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Kid, stringComparison))
                    {
                        return validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Kid, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.X5t))
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        if ($.$$.System.String.Equals$2(validationParameters.TokenDecryptionKey.KeyId, jwtToken.X5t, stringComparison))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                        /*var*/ let x509Key = $.$as(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                        if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.X5t, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                                {
                                    return key;
                                }
                                /*var*/ let x509Key = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                                if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(382252417144)
            
            //--TRIMMABLE-BOUNDARY-START(356482613368)
            /*JsonWebToken */ ReadJsonWebToken$1(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482613368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(token))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                }
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$7(token);
            }
            //--TRIMMABLE-BOUNDARY-END(356482613368)
            
            //--TRIMMABLE-BOUNDARY-START(352187646072)
            /*JsonWebToken */ ReadJsonWebToken(/*ReadOnlyMemory<char>*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187646072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token.IsEmpty)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                if (token.Span.Length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.Length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                }
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$3(token);
            }
            //--TRIMMABLE-BOUNDARY-END(352187646072)
            
            //--TRIMMABLE-BOUNDARY-START(377957449848)
            /*JsonWebToken */ ReplaceTokenHeader(/*JsonWebToken*/ jsonWebToken, /*string*/ encodedHeader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957449848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$8(jsonWebToken, encodedHeader);
            }
            //--TRIMMABLE-BOUNDARY-END(377957449848)
            
            //--TRIMMABLE-BOUNDARY-START(369367515256)
            /*SecurityToken */ ReadToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367515256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadJsonWebToken$1(token);
            }
            //--TRIMMABLE-BOUNDARY-END(369367515256)
            
            //--TRIMMABLE-BOUNDARY-START(365072547960)
            static /*TokenValidationResult */ ReadToken$2(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072547960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JsonWebToken*/ let jsonWebToken = null;
                if (validationParameters.TokenReader !== null)
                {
                    /*var*/ let securityToken = validationParameters.TokenReader.Invoke(token, validationParameters);
                    if (securityToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10510: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader returned null when reading token: '{0}'."/*TokenLogMessages.IDX10510*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    jsonWebToken = $.$as(securityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                    if (jsonWebToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10509: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader did not return a '{0}', but returned a '{1}' when reading token: '{2}'."/*TokenLogMessages.IDX10509*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type, $.$$.System.Object.GetType.call(securityToken), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                }
                else 
                {
                    try
                    {
                        jsonWebToken = new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$6(token, validationParameters.TryReadJwtClaim);
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                }
                return (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SecurityToken = jsonWebToken;
                    $i1.IsValid = true;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(365072547960)
            
            //--TRIMMABLE-BOUNDARY-START(176093986936)
            /*ValidationResult<string, ValidationError> */ DecryptToken(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext?*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093986936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("jwtToken", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 36, 1)));
                }
                if (validationParameters === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 43, 1)));
                }
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.Enc))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$2("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 51, 1)));
                }
                /*(IList<SecurityKey>? ContentEncryptionKeys, ValidationError? ValidationError)*/ let result = this.GetContentEncryptionKeys(jwtToken, validationParameters, configuration, callContext);
                if (result.Item2 !== null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(result.Item2.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 60, 1));
                }
                if (result.Item1 === null || result.Item1.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 71, 1)));
                }
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, result.Item1);
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptJwtToken(jwtToken, validationParameters, decryptionParameters, callContext);
            }
            //--TRIMMABLE-BOUNDARY-END(176093986936)
            
            //--TRIMMABLE-BOUNDARY-START(292058103928)
            /*(IList<SecurityKey>?, ValidationError?) */ GetContentEncryptionKeys(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext?*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058103928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IList<SecurityKey>?*/ let keys = null;
                if (validationParameters.DecryptionKeyResolver !== null)
                {
                    keys = validationParameters.DecryptionKeyResolver.Microsoft$IdentityModel$Tokens$Experimental$IDecryptionKeyResolver$ResolveDecryptionKey(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, callContext);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey$1(jwtToken, validationParameters, callContext);
                    if (key === null && !(configuration === null))
                    {
                        key = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ResolveTokenDecryptionKeyFromConfig(jwtToken, configuration);
                    }
                    if (!(key === null))
                    {
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (validationParameters.TryAllDecryptionKeys && $.$mit.Microsoft.IdentityModel.Tokens.CollectionUtilities.IsNullOrEmpty($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys))
                {
                    keys = validationParameters.DecryptionKeys;
                    if (configuration !== null)
                    {
                        let configurationKeys;
                        if (!$.$is(configuration.TokenDecryptionKeys, $.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), { set $v(v){ configurationKeys = v; } }))
                        {
                            configurationKeys = $.$sl.System.Linq.Enumerable.ToList($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, configuration.TokenDecryptionKeys);
                        }
                        if (keys !== null)
                        {
                            let keysList;
                            if ($.$is(keys, $.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), { set $v(v){ keysList = v; } }))
                            {
                                keysList.AddRange(configurationKeys);
                            }
                            else 
                            {
                                keys = $.$sl.System.Linq.Enumerable.ToList($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$sl.System.Linq.Enumerable.Concat($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys, configurationKeys));
                            }
                        }
                        else 
                        {
                            keys = configurationKeys;
                        }
                    }
                }
                if ($.$$.System.String.Equals$4.call(jwtToken.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/, 4/*StringComparison.Ordinal*/) || $.$$.System.String.Equals$4.call(jwtToken.Alg, "ECDH-ES"/*SecurityAlgorithms.EcdhEs*/, 4/*StringComparison.Ordinal*/))
                {
                    return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError))().$ctor$3(keys, null);
                }
                if (keys === null)
                {
                    return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError))().$ctor$3(keys, null);
                }
                /*var*/ let unwrappedKeys = new ($.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey))().$ctor$1();
                /*StringBuilder?*/ let exceptionStrings = null;
                /*StringBuilder?*/ let keysAttempted = null;
                for(/*int*/ let i = 0; i < keys.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*var*/ let key = keys.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.SecurityKey]);
                    try
                    {
                        if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(jwtToken.Alg, [$.$$.System.String]))
                        {
                            /*string*/ let epk;
                            jwtToken.TryGetHeaderValue($.$$.System.String, "epk"/*JwtHeaderParameterNames.Epk*/, $.$ref(() => epk, ($v) => epk = $v, $.$$.System.String));
                            /*ECDsaSecurityKey?*/ let publicKey = new $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey().$ctor$5(new $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKey().$ctor$4(epk), false);
                            if (!(publicKey === null))
                            {
                                /*var*/ let ecdhKeyExchangeProvider = new $.$mit.Microsoft.IdentityModel.Tokens.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey), publicKey, jwtToken.Alg, jwtToken.Enc);
                                /*string*/ let apu;
                                jwtToken.TryGetHeaderValue($.$$.System.String, "apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => apu, ($v) => apu = $v, $.$$.System.String));
                                /*string*/ let apv;
                                jwtToken.TryGetHeaderValue($.$$.System.String, "apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => apv, ($v) => apv = $v, $.$$.System.String));
                                /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.EncryptedKey));
                                unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                            }
                        }
                        else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Alg, key))
                        {
                            /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Alg);
                            /*var*/ let unwrappedKey = kwp.UnwrapKey(jwtToken.EncryptedKeyBytes);
                            unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                        }
                    }
                    catch(ex)
                    {
                        (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                    }
                    (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(key.KeyId);
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings === null)
                {
                    return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError))().$ctor$3(unwrappedKeys, null);
                }
                else 
                {
                    const $t1 = keysAttempted;
                    const $t2 = exceptionStrings;
                    /*ValidationError*/ let validationError = new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$ifnn($t1, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t)) ?? ""), $.$ifnn($t2, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t)) ?? "", $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.KeyWrapFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 241, 1));
                    return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError))().$ctor$3(null, validationError);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(292058103928)
            
            //--TRIMMABLE-BOUNDARY-START(386547384440)
            /*SecurityKey? */ ResolveTokenDecryptionKey$1(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*CallContext?*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547384440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null || validationParameters === null)
                {
                    return null;
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Kid) && validationParameters.DecryptionKeys !== null)
                {
                    for(/*int*/ let i = 0; i < validationParameters.DecryptionKeys.System$Collections$Generic$ICollection$$$Count; i++)
                    {
                        /*var*/ let key = validationParameters.DecryptionKeys.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.SecurityKey]);
                        if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Kid, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                        {
                            return key;
                        }
                    }
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.X5t) && validationParameters.DecryptionKeys !== null)
                {
                    for(/*int*/ let i = 0; i < validationParameters.DecryptionKeys.System$Collections$Generic$ICollection$$$Count; i++)
                    {
                        /*SecurityKey?*/ let key = validationParameters.DecryptionKeys.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.SecurityKey]);
                        if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.X5t, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                        {
                            return key;
                        }
                        let x509Key;
                        if ($.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey, { set $v(v){ x509Key = v; } }) && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return key;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(386547384440)
            
            //--TRIMMABLE-BOUNDARY-START(481036664952)
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignature$1(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036664952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("jwtToken", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 38, 1)));
                }
                if (validationParameters === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 47, 1)));
                }
                if (!(validationParameters.SignatureValidator === null))
                {
                    try
                    {
                        /*ValidationResult<SecurityKey, ValidationError>*/ let signatureValidationResult = validationParameters.SignatureValidator.Microsoft$IdentityModel$Tokens$Experimental$ISignatureValidator$ValidateSignature(jwtToken, validationParameters, configuration, callContext);
                        return signatureValidationResult;
                    }
                    catch(ex)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$3(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$2("IDX10272: SignatureValidationDelegate threw an exception, see inner exception."/*TokenLogMessages.IDX10272*/), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.ValidatorThrew, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 72, 1), ex));
                    }
                }
                if (!jwtToken.IsSigned)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.TokenIsNotSigned, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 88, 1)));
                }
                /*SecurityKey?*/ let key = null;
                if (!(validationParameters.SignatureKeyResolver === null))
                {
                    key = validationParameters.SignatureKeyResolver.Microsoft$IdentityModel$Tokens$Experimental$ISignatureKeyResolver$ResolveSignatureKey(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, configuration, callContext);
                }
                else 
                {
                    key = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey(jwtToken.Kid, jwtToken.X5t, (configuration?.SigningKeys ?? null)) ?? $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey(jwtToken.Kid, jwtToken.X5t, validationParameters.SigningKeys);
                }
                if (!(key === null))
                {
                    return this.ValidateSignatureWithKey(jwtToken, validationParameters, key, callContext);
                }
                if (validationParameters.TryAllSigningKeys)
                {
                    return this.ValidateSignatureUsingAllKeys(jwtToken, validationParameters, configuration, callContext);
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, null);
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.Kid))
                {
                    /*Microsoft.IdentityModel.Tokens.BaseConfiguration?*/ let __ca1__;
                    /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca2__;
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10526: Signature validation failed. The token's kid is missing.\nValidationParameters.TryAllIssuerSigningKeys is set to false. All keys will not be tried. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10526*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca1__ = configuration) !== null ? ((__ca2__ = __ca1__.SigningKeys) !== null ? __ca2__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 143, 1)));
                }
                /*Microsoft.IdentityModel.Tokens.BaseConfiguration?*/ let __ca3__;
                /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca4__;
                return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10527: Signature validation failed. The token's kid is: '{0}', but did not match any keys in ValidationParameters or Configuration and TryAllIssuerSigningKeys is false.\nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10527*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca3__ = configuration) !== null ? ((__ca4__ = __ca3__.SigningKeys) !== null ? __ca4__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 157, 1)));
            }
            //--TRIMMABLE-BOUNDARY-END(481036664952)
            
            //--TRIMMABLE-BOUNDARY-START(502511501432)
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignatureUsingAllKeys(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511501432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let keysTried = false;
                /*bool*/ let kidExists = !$.$$.System.String.IsNullOrEmpty(jwtToken.Kid);
                /*IEnumerable<SecurityKey>?*/ let keys = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys(configuration, validationParameters, callContext);
                /*StringBuilder?*/ let exceptionStrings = null;
                /*StringBuilder?*/ let keysAttempted = null;
                var $en2 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (key === null)
                        {
                            continue;
                        }
                        keysTried = true;
                        /*ValidationResult<SecurityKey, ValidationError>*/ let result = this.ValidateSignatureWithKey(jwtToken, validationParameters, key, callContext);
                        if (result.Succeeded)
                        {
                            return result;
                        }
                        let validationError;
                        if ($.$is(result.Error, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError, { set $v(v){ validationError = v; } }))
                        {
                            exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                            keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                            exceptionStrings.AppendLine$2(validationError.MessageDetail.Message);
                            keysAttempted.AppendLine$2($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key));
                        }
                    }
                }
                if (keysTried)
                {
                    if (kidExists)
                    {
                        /*Microsoft.IdentityModel.Tokens.BaseConfiguration*/ let __ca5__;
                        /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca6__;
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10522: Signature validation failed. The token's kid: '{0}' did not match any keys in ValidationParameters or Configuration.\nAll keys in ValidationParameters and Configuration were tried. \nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10522*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca5__ = configuration) !== null ? ((__ca6__ = __ca5__.SigningKeys) !== null ? __ca6__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 221, 1)));
                    }
                    else 
                    {
                        /*Microsoft.IdentityModel.Tokens.BaseConfiguration*/ let __ca7__;
                        /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca8__;
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10523: Signature validation failed. The token's kid is empty.\nAll keys in ValidationParameters and Configuration were tried. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10523*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca7__ = configuration) !== null ? ((__ca8__ = __ca7__.SigningKeys) !== null ? __ca8__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 234, 1)));
                    }
                }
                if (kidExists)
                {
                    /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca10__;
                    /*Microsoft.IdentityModel.Tokens.BaseConfiguration*/ let __ca9__;
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10524: Signature validation failed. The token's kid: '{0}' did not match any keys in ValidationParameters or Configuration.\nAll keys in ValidationParameters and Configuration were tried. No non-null keys were found. \nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10524*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca9__ = configuration) !== null ? ((__ca10__ = __ca9__.SigningKeys) !== null ? __ca10__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 253, 1)));
                }
                /*Microsoft.IdentityModel.Tokens.BaseConfiguration*/ let __ca11__;
                /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca12__;
                return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10525: Signature validation failed. The token's kid is missing.\nAll keys in ValidationParameters and Configuration were tried. No non-null keys were found. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10525*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca11__ = configuration) !== null ? ((__ca12__ = __ca11__.SigningKeys) !== null ? __ca12__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 265, 1)));
            }
            //--TRIMMABLE-BOUNDARY-END(502511501432)
            
            //--TRIMMABLE-BOUNDARY-START(511101436024)
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignatureWithKey(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*SecurityKey*/ key, /*CallContext*/ callContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101436024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CryptoProviderFactory*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Alg, key))
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10652: The algorithm '{0}' is not supported."/*TokenLogMessages.IDX10652*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg), key ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.AlgorithmValidationFailure.AlgorithmIsNotSupported, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 291, 1)));
                }
                /*SignatureProvider*/ let signatureProvider;
                try
                {
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, jsonWebToken.Alg);
                }
                catch(ex)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$3(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX11028: CryptoProviderFactory.CreateForVerifying threw an exception for key: '{0}', signatureAlgorithm: '{1}'. The platform may not support the algorithm or extracting the key material for it (for example, ML-DSA on a platform without post-quantum support). See the inner exception for details."/*TokenLogMessages.IDX11028*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SignatureProviderCreationFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 315, 1), ex));
                }
                try
                {
                    if (signatureProvider === null)
                    {
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.CryptoProviderReturnedNull, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 335, 1)));
                    }
                    /*bool*/ let valid = $.$mit.Microsoft.IdentityModel.Tokens.EncodingUtils.PerformEncodingDependentOperation($.$$.System.Boolean, $.$$.System.String, $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, jsonWebToken.EncodedToken, 0, jsonWebToken.Dot2, $.$$.System.Text.Encoding.UTF8, jsonWebToken.EncodedToken, jsonWebToken.Dot2, signatureProvider, new ($.$$.System.Func$$$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$$.System.String, $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, $.$$.System.Boolean))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignature));
                    if (valid)
                    {
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "None"/*TelemetryConstants.SignatureValidationErrors.None*/, jsonWebToken, key);
                        jsonWebToken.SigningKey = key;
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit$1(key);
                    }
                    else 
                    {
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10520: Signature validation failed. The key provided could not validate the signature. Key tried: '{0}'."/*TokenLogMessages.IDX10520*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.ValidationFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 372, 1)));
                    }
                }
                catch(ex)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$3(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10521: Signature validation failed.An exception was thrown when trying to validate the signature. Key tried: '{0}'. Exception: '{1}'."/*TokenLogMessages.IDX10521*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(ex.Message) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.ValidationFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 391, 1), ex));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(511101436024)
            
            //--TRIMMABLE-BOUNDARY-START(347892678776)
            static /*void */ PopulateFailedResults(/*KeyMatchFailedResult?*/ failedResult, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892678776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let result;
                if ($.$is(failedResult, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.KeyMatchFailedResult, { set $v(v){ result = v; } }))
                {
                    for(/*int*/ let i = 0; i < result.KeysAttempted.System$Collections$Generic$ICollection$$$Count; i++)
                    {
                        exceptionStrings.AppendLine$2(result.FailedResults.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError]).MessageDetail.Message);
                        keysAttempted.AppendLine$2($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(result.KeysAttempted.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.SecurityKey])));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(347892678776)
            
            //--TRIMMABLE-BOUNDARY-START(393336)
            static $_KeyMatchFailedResult;
            static get KeyMatchFailedResult()
            {
                let $cls = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler;
                return $cls.$_KeyMatchFailedResult ??= $asm.$nstr("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.KeyMatchFailedResult", ($self) => class KeyMatchFailedResult extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295224)
                    /*IList<ValidationError>*/  get FailedResults() { return this.$getField(0, 4); }
                    /*IList<ValidationError>*/  set FailedResults(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885295224)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180262520)
                    /*IList<SecurityKey>*/  get KeysAttempted() { return this.$getField(4, 4); }
                    /*IList<SecurityKey>*/  set KeysAttempted(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180262520)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360632)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360632)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FailedResults = this.FailedResults;
                        copy.KeysAttempted = this.KeysAttempted;
                        return copy;
                    }
                    //Begin primary constructor
                    /*IList<ValidationError>*/ failedResults = null;
                    /*IList<SecurityKey>*/ keysAttempted = null;
                    $ctor$3(/*IList<ValidationError>*/failedResults, /*IList<SecurityKey>*/keysAttempted)
                    {
                        this.failedResults = failedResults;
                        this.keysAttempted = keysAttempted;
                        //--TRIMMABLE-BOUNDARY-START(12885295224)
                        //depends on primary constructor parameter
                        this.FailedResults = this.failedResults;
                        //--TRIMMABLE-BOUNDARY-END(12885295224)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180262520)
                        //depends on primary constructor parameter
                        this.KeysAttempted = this.keysAttempted;
                        //--TRIMMABLE-BOUNDARY-END(17180262520)
                        
                        return this
                    }
                    //End primary constructor
                    static $h = 393336;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295224),
    {
      "t": $.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,
      "n": "FailedResults",
      "d": 393336,
      "h": 12885295224,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885295224),
//--TRIMMABLE-BOUNDARY-START(17180262520),
    {
      "t": $.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,
      "n": "KeysAttempted",
      "d": 393336,
      "h": 17180262520,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180262520)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327928),
    {
      "p": [
        {
          "n": "failedResults",
          "p": $.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h
        },
        {
          "n": "keysAttempted",
          "p": $.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393336,
      "h": 8590327928,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327928),
//--TRIMMABLE-BOUNDARY-START(4295360632),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393336,
      "h": 4295360632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360632)
  ],
  "d": 327800,
  "h": 393336
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.KeyMatchFailedResult`; }
                }, $cls, ($v) => $cls.$_KeyMatchFailedResult = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393336)
            
            //--TRIMMABLE-BOUNDARY-START(442381959288)
            /*Telemetry.ITelemetryClient*/ TelemetryClient = null;
            //--TRIMMABLE-BOUNDARY-END(442381959288)
            
            //--TRIMMABLE-BOUNDARY-START(51539935352)
            /*bool */ get CanValidateToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223529080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(51539935352)
            
            //--TRIMMABLE-BOUNDARY-START(459561828472)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWEAsync$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(459561828472);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await this.ValidateJWEAsync$1(jwtToken, validationParameters, configuration, $.$$.System.Threading.CancellationToken.None).ConfigureAwait(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(459561828472)
            
            //--TRIMMABLE-BOUNDARY-START(455266861176)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWEAsync$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(455266861176);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        /*TokenValidationResult*/ let tokenValidationResult = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$2(this.DecryptToken$1(jwtToken, validationParameters, configuration), validationParameters);
                        if (!tokenValidationResult.IsValid)
                        {
                            return tokenValidationResult;
                        }
                        tokenValidationResult = await this.ValidateJWSAsync$1($.$as(tokenValidationResult.SecurityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken), validationParameters, configuration, cancellationToken).ConfigureAwait(false);
                        if (!tokenValidationResult.IsValid)
                        {
                            return tokenValidationResult;
                        }
                        jwtToken.InnerToken = $.$as(tokenValidationResult.SecurityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                        jwtToken.Payload = ($.$as(tokenValidationResult.SecurityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken)).Payload;
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.SecurityToken = jwtToken;
                            $i1.ClaimsIdentityNoLocking = tokenValidationResult.ClaimsIdentityNoLocking;
                            $i1.IsValid = true;
                            $i1.TokenType = tokenValidationResult.TokenType;
                            return $i1;
                        })();
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            $i1.TokenOnFailedValidation = validationParameters.IncludeTokenOnFailedValidation ? jwtToken : null;
                            return $i1;
                        })();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(455266861176)
            
            //--TRIMMABLE-BOUNDARY-START(472446730360)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWSAsync$2(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(472446730360);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await this.ValidateJWSAsync$1(jsonWebToken, validationParameters, configuration, $.$$.System.Threading.CancellationToken.None).ConfigureAwait(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(472446730360)
            
            //--TRIMMABLE-BOUNDARY-START(468151763064)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWSAsync$1(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(468151763064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        /*TokenValidationResult*/ let tokenValidationResult;
                        if (validationParameters.TransformBeforeSignatureValidation !== null)
                        {
                            jsonWebToken = $.$as(validationParameters.TransformBeforeSignatureValidation.Invoke(jsonWebToken, validationParameters), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                        }
                        if (validationParameters.SignatureValidator !== null || validationParameters.SignatureValidatorUsingConfiguration !== null)
                        {
                            /*var*/ let validatedToken = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignatureUsingDelegates(jsonWebToken, validationParameters);
                            tokenValidationResult = await this.ValidateTokenPayloadAsync(validatedToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false);
                            $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey$1(validatedToken.SigningKey, validatedToken, validationParameters);
                        }
                        else 
                        {
                            if (validationParameters.ValidateSignatureLast)
                            {
                                tokenValidationResult = await this.ValidateTokenPayloadAsync(jsonWebToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false);
                                if (tokenValidationResult.IsValid)
                                {
                                    tokenValidationResult.SecurityToken = this.ValidateSignatureAndIssuerSecurityKey(jsonWebToken, validationParameters, configuration);
                                }
                            }
                            else 
                            {
                                /*var*/ let validatedToken = this.ValidateSignatureAndIssuerSecurityKey(jsonWebToken, validationParameters, configuration);
                                tokenValidationResult = await this.ValidateTokenPayloadAsync(validatedToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false);
                            }
                        }
                        return tokenValidationResult;
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            $i1.TokenOnFailedValidation = validationParameters.IncludeTokenOnFailedValidation ? jsonWebToken : null;
                            return $i1;
                        })();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(468151763064)
            
            //--TRIMMABLE-BOUNDARY-START(498216534136)
            /*JsonWebToken */ ValidateSignatureAndIssuerSecurityKey(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216534136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JsonWebToken*/ let validatedToken = this.ValidateSignature$4(jsonWebToken, validationParameters, configuration);
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey(validatedToken.SigningKey, jsonWebToken, validationParameters, configuration);
                return validatedToken;
            }
            //--TRIMMABLE-BOUNDARY-END(498216534136)
            
            //--TRIMMABLE-BOUNDARY-START(493921566840)
            /*JsonWebToken */ ValidateSignature$4(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493921566840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let kidMatched = false;
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (!jwtToken.IsSigned)
                {
                    if (validationParameters.RequireSignedTokens)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    else 
                    {
                        return jwtToken;
                    }
                }
                if (validationParameters.IssuerSigningKeyResolverUsingConfiguration !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolverUsingConfiguration.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, configuration);
                }
                else if (validationParameters.IssuerSigningKeyResolver !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolver.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey$1(jwtToken.Kid, jwtToken.X5t, validationParameters, configuration);
                    if (key !== null)
                    {
                        kidMatched = true;
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (validationParameters.TryAllIssuerSigningKeys && $.$mit.Microsoft.IdentityModel.Tokens.CollectionUtilities.IsNullOrEmpty($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys))
                {
                    keys = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(configuration, validationParameters);
                }
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*var*/ let kidExists = !$.$$.System.String.IsNullOrEmpty(jwtToken.Kid);
                if (keys !== null)
                {
                    var $en3 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignature$2(jwtToken, key, validationParameters, this.TelemetryClient))
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10242: Security token: '{0}' has a valid signature."/*TokenLogMessages.IDX10242*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null));
                                    }
                                    jwtToken.SigningKey = key;
                                    return jwtToken;
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                            }
                            if (key !== null)
                            {
                                (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).Append$19($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key)).Append$19(" , KeyId: ").AppendLine$2(key.KeyId);
                                if (kidExists && !kidMatched && $.$$.System.String.op_Inequality(key.KeyId, null))
                                {
                                    kidMatched = $.$$.System.String.Equals$4.call(jwtToken.Kid, key.KeyId, $.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
                                }
                            }
                        }
                    }
                }
                /*var*/ let keysInTokenValidationParameters = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(null, validationParameters);
                /*var*/ let keysInConfiguration = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(configuration, null);
                /*var*/ let numKeysInTokenValidationParameters = $.$sl.System.Linq.Enumerable.Count$1($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInTokenValidationParameters);
                /*var*/ let numKeysInConfiguration = $.$sl.System.Linq.Enumerable.Count$1($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInConfiguration);
                if (kidExists)
                {
                    if (kidMatched)
                    {
                        /*JsonWebToken*/ let localJwtToken = jwtToken;
                        /*var*/ let isKidInTVP = $.$sl.System.Linq.Enumerable.Any($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInTokenValidationParameters, new ($.$$.System.Func$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$$.System.Boolean))().$ctor(this,  (/*x*/ x) =>
                        {
                            return $.$$.System.String.Equals$5.call(x.KeyId, localJwtToken.Kid);
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "x",
      "p": 13631607
    }
  ],
  "n": "",
  "d": 327800,
  "h": 0,
  "f": 17825794
}));
                        /*var*/ let keyLocation = isKidInTVP ? "TokenValidationParameters" : "Configuration";
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10511: Signature validation failed. Keys tried: '{0}'. \nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'. \nMatched key was in '{3}'. \nkid: '{4}'. \nExceptions caught:\n '{5}'.\ntoken: '{6}'. See https://aka.ms/IDX10511 for details."/*TokenLogMessages.IDX10511*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keyLocation), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    if (!validationParameters.ValidateSignatureLast)
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.InternalValidators.ValidateAfterSignatureFailed(jwtToken, jwtToken.ValidFromNullable, jwtToken.ValidToNullable, jwtToken.Audiences, validationParameters, configuration);
                    }
                }
                if (!(keysAttempted === null))
                {
                    if (kidExists)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10503: Signature validation failed. The token's kid is: '{0}', but did not match any keys in TokenValidationParameters or Configuration. Keys tried: '{1}'.\nNumber of keys in TokenValidationParameters: '{2}'. \nNumber of keys in Configuration: '{3}'.\nExceptions caught:\n '{4}'.\ntoken: '{5}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10503*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10517: Signature validation failed. The token's kid is missing. Keys tried: '{0}'.\nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\nExceptions caught:\n '{3}'.\ntoken: '{4}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10517*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, null);
                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28("IDX10500: Signature validation failed. No security keys were provided to validate the signature."/*TokenLogMessages.IDX10500*/));
            }
            //--TRIMMABLE-BOUNDARY-END(493921566840)
            
            //--TRIMMABLE-BOUNDARY-START(317827907704)
            static /*bool */ IsSignatureValid(/*byte[]*/ signatureBytes, /*int*/ signatureBytesLength, /*SignatureProvider*/ signatureProvider, /*byte[]*/ dataToVerify, /*int*/ dataToVerifyLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827907704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(signatureProvider, $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSignatureProvider))
                {
                    return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, signatureBytes, 0, signatureBytesLength);
                }
                else 
                {
                    if (signatureBytes.length === signatureBytesLength)
                    {
                        return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, signatureBytes, 0, signatureBytesLength);
                    }
                    else 
                    {
                        /*byte[]*/ let sigBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [signatureBytesLength], null);
                        $.$$.System.Array.Copy$2(signatureBytes, 0, sigBytes, 0, signatureBytesLength);
                        return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, sigBytes, 0, signatureBytesLength);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(317827907704)
            
            //--TRIMMABLE-BOUNDARY-START(476741697656)
            static /*bool */ ValidateSignature(/*byte[]*/ bytes, /*int*/ len, /*string*/ stringWithSignature, /*int*/ signatureStartIndex, /*SignatureProvider*/ signatureProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476741697656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoding.Decode$3($.$$.System.Boolean, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, $.$typeArray($.$$.System.Byte), $.$$.System.Int32, stringWithSignature, ((signatureStartIndex + 1) | 0), ((((stringWithSignature.length - signatureStartIndex) | 0) - 1) | 0), signatureProvider, bytes, len, new ($.$$.System.Func$$$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, $.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$$.System.Boolean))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.IsSignatureValid));
            }
            //--TRIMMABLE-BOUNDARY-END(476741697656)
            
            //--TRIMMABLE-BOUNDARY-START(489626599544)
            static /*bool */ ValidateSignature$3(/*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489626599544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignature$2(jsonWebToken, key, validationParameters, $.$mit.Microsoft.IdentityModel.Telemetry.NullTelemetryClient.Instance);
            }
            //--TRIMMABLE-BOUNDARY-END(489626599544)
            
            //--TRIMMABLE-BOUNDARY-START(373662482552)
            static /*void */ RecordSignatureValidationTelemetry(/*Telemetry.ITelemetryClient*/ telemetryClient, /*string*/ errorType, /*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662482552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mit.Microsoft.IdentityModel.Telemetry.CryptoTelemetry.RecordSignatureValidationTelemetry)
                {
                    telemetryClient.Microsoft$IdentityModel$Telemetry$ITelemetryClient$IncrementSignatureValidationCounter(errorType, jsonWebToken.Issuer, jsonWebToken.Alg, key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(373662482552)
            
            //--TRIMMABLE-BOUNDARY-START(485331632248)
            static /*bool */ ValidateSignature$2(/*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key, /*TokenValidationParameters*/ validationParameters, /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485331632248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Alg, key))
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX14000: Signature validation of this JWT is not supported for: Algorithm: '{0}', SecurityKey: '{1}'."/*LogMessages.IDX14000*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                    }
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    return false;
                }
                try
                {
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAlgorithm(jsonWebToken.Alg, key, jsonWebToken, validationParameters);
                }
                catch($e)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    throw $e;
                }
                /*SignatureProvider*/ let signatureProvider;
                try
                {
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, jsonWebToken.Alg);
                    if (signatureProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null))));
                    }
                }
                catch($e)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                    throw $e;
                }
                try
                {
                    /*bool*/ let isValid = $.$mit.Microsoft.IdentityModel.Tokens.EncodingUtils.PerformEncodingDependentOperation($.$$.System.Boolean, $.$$.System.String, $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, jsonWebToken.EncodedToken, 0, jsonWebToken.Dot2, $.$$.System.Text.Encoding.UTF8, jsonWebToken.EncodedToken, jsonWebToken.Dot2, signatureProvider, new ($.$$.System.Func$$$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$$.System.String, $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, $.$$.System.Boolean))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignature));
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, isValid ? "None"/*TelemetryConstants.SignatureValidationErrors.None*/ : "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    return isValid;
                }
                catch($e)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    throw $e;
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(485331632248)
            
            //--TRIMMABLE-BOUNDARY-START(506806468728)
            static /*JsonWebToken */ ValidateSignatureUsingDelegates(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506806468728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters.SignatureValidatorUsingConfiguration !== null)
                {
                    /*BaseConfiguration*/ let configuration = null;
                    /*var*/ let validatedToken = validationParameters.SignatureValidatorUsingConfiguration.Invoke(jsonWebToken.EncodedToken, validationParameters, configuration);
                    if (validatedToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jsonWebToken ], null, null))));
                    }
                    let validatedJsonWebToken;
                    if (!($.$is(validatedToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken, { set $v(v){ validatedJsonWebToken = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(validatedToken)), jsonWebToken ], null, null))));
                    }
                    return validatedJsonWebToken;
                }
                else if (validationParameters.SignatureValidator !== null)
                {
                    /*var*/ let validatedToken = validationParameters.SignatureValidator.Invoke(jsonWebToken.EncodedToken, validationParameters);
                    if (validatedToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jsonWebToken ], null, null))));
                    }
                    let validatedJsonWebToken;
                    if (!($.$is(validatedToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken, { set $v(v){ validatedJsonWebToken = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(validatedToken)), jsonWebToken ], null, null))));
                    }
                    return validatedJsonWebToken;
                }
                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jsonWebToken ], null, null))));
            }
            //--TRIMMABLE-BOUNDARY-END(506806468728)
            
            //--TRIMMABLE-BOUNDARY-START(515396403320)
            /*TokenValidationResult */ ValidateToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396403320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateTokenAsync$2(token, validationParameters).ConfigureAwait$2(false).GetAwaiter().GetResult();
            }
            //--TRIMMABLE-BOUNDARY-END(515396403320)
            
            //--TRIMMABLE-BOUNDARY-START(528281305208)
            /*Task<TokenValidationResult> */ ValidateTokenAsync$2(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281305208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateTokenAsync$1(token, validationParameters, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(528281305208)
            
            //--TRIMMABLE-BOUNDARY-START(523986337912)
            /*Task<TokenValidationResult> *//*async*/  ValidateTokenAsync$1(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(523986337912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrEmpty(token))
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    if (validationParameters === null)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    if (token.length > this.MaximumTokenSizeInBytes)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    try
                    {
                        /*TokenValidationResult*/ let result = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$2(token, validationParameters);
                        if (result.IsValid)
                        {
                            return await this.ValidateTokenAsync$4(result.SecurityToken, validationParameters, cancellationToken).ConfigureAwait$2(false);
                        }
                        return result;
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(523986337912)
            
            //--TRIMMABLE-BOUNDARY-START(545461174392)
            /*Task<TokenValidationResult> */ ValidateTokenAsync$5(/*SecurityToken*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461174392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateTokenAsync$4(token, validationParameters, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(545461174392)
            
            //--TRIMMABLE-BOUNDARY-START(541166207096)
            /*Task<TokenValidationResult> *//*async*/  ValidateTokenAsync$4(/*SecurityToken*/ token, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(541166207096);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (token === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                    }
                    if (validationParameters === null)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    /*var*/ let jwt = $.$as(token, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                    if (jwt === null)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException$7($.$$.System.ArgumentException, "token", `${"token"} must be a ${"JsonWebToken"}.`);
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    try
                    {
                        return await this.ValidateTokenAsync$6(jwt, validationParameters, cancellationToken).ConfigureAwait(false);
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(541166207096)
            
            //--TRIMMABLE-BOUNDARY-START(532576272504)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenAsync$6(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(532576272504);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*BaseConfiguration*/ let currentConfiguration = null;
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        try
                        {
                            currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false);
                        }
                        catch(ex)
                        {
                            if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10261: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token validation in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10261*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ validationParameters.ConfigurationManager.MetadataAddress, $.$$.System.Exception.ToString.call(ex) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            }
                        }
                    }
                    /*TokenValidationResult*/ let tokenValidationResult = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false);
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        if (tokenValidationResult.IsValid)
                        {
                            if (currentConfiguration !== null)
                            {
                                validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                            }
                            return tokenValidationResult;
                        }
                        else if ($.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableException(tokenValidationResult.Exception, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.System$Collections$Generic$ICollection$$$Count > 0)))
                        {
                            if (currentConfiguration !== null)
                            {
                                this.TelemetryClient.Microsoft$IdentityModel$Telemetry$ITelemetryClient$IncrementConfigurationRefreshRequestCounter$2(validationParameters.ConfigurationManager.MetadataAddress, "LastKnownGood"/*TelemetryConstants.Protocols.Lkg*/, "Unknown"/*TelemetryConstants.Protocols.ConfigurationSourceUnknown*/);
                                validationParameters.ConfigurationManager.RequestRefresh();
                                validationParameters.RefreshBeforeValidation = true;
                                /*var*/ let lastConfig = currentConfiguration;
                                currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false);
                                if (lastConfig !== currentConfiguration)
                                {
                                    tokenValidationResult = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false);
                                    if (tokenValidationResult.IsValid)
                                    {
                                        validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                        return tokenValidationResult;
                                    }
                                }
                            }
                            if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                            {
                                validationParameters.RefreshBeforeValidation = false;
                                validationParameters.ValidateWithLKG = true;
                                /*var*/ let recoverableException = tokenValidationResult.Exception;
                                let $i1 = 0;
                                let $arr1 = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                                while ($i1 < $arr1.length)
                                {
                                    let lkgConfiguration = $arr1[$i1++];
                                    if (!$.$$.System.Object.Equals$1.call(lkgConfiguration, currentConfiguration) && $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableConfiguration(jsonWebToken.Kid, currentConfiguration, lkgConfiguration, recoverableException))
                                    {
                                        tokenValidationResult = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync$1(jsonWebToken, validationParameters, lkgConfiguration, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync$1(jsonWebToken, validationParameters, lkgConfiguration, cancellationToken).ConfigureAwait(false);
                                        if (tokenValidationResult.IsValid)
                                        {
                                            return tokenValidationResult;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return tokenValidationResult;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(532576272504)
            
            //--TRIMMABLE-BOUNDARY-START(554051108984)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenPayloadAsync$1(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(554051108984);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await this.ValidateTokenPayloadAsync(jsonWebToken, validationParameters, configuration, $.$$.System.Threading.CancellationToken.None).ConfigureAwait(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(554051108984)
            
            //--TRIMMABLE-BOUNDARY-START(549756141688)
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenPayloadAsync(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(549756141688);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let expires = jsonWebToken.HasPayloadClaim("exp"/*JwtRegisteredClaimNames.Exp*/) ? $.$cast(jsonWebToken.ValidTo, $.$$.System.Nullable$$($.$$.System.DateTime)) : null;
                    /*var*/ let notBefore = jsonWebToken.HasPayloadClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/) ? $.$cast(jsonWebToken.ValidFrom, $.$$.System.Nullable$$($.$$.System.DateTime)) : null;
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateLifetime$1(notBefore?.Clone() ?? null, expires?.Clone() ?? null, jsonWebToken, validationParameters);
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAudience(jsonWebToken.Audiences, jsonWebToken, validationParameters);
                    /*string*/ let issuer = await $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerAsync$1(jsonWebToken.Issuer, jsonWebToken, validationParameters, configuration).ConfigureAwait(false);
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenReplay$1(expires?.Clone() ?? null, jsonWebToken.EncodedToken, validationParameters);
                    if (validationParameters.ValidateActor && !$.$$.System.String.IsNullOrWhiteSpace(jsonWebToken.Actor))
                    {
                        /*TokenValidationResult*/ let tokenValidationResult = await this.ValidateTokenAsync$1(jsonWebToken.Actor, validationParameters.ActorValidationParameters ?? validationParameters, cancellationToken).ConfigureAwait$2(false);
                        if (!tokenValidationResult.IsValid)
                        {
                            return tokenValidationResult;
                        }
                    }
                    /*string*/ let tokenType = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenType$1(jsonWebToken.Typ, jsonWebToken, validationParameters);
                    return (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$2(jsonWebToken, this, validationParameters.Clone(), issuer);
                        $i1.IsValid = true;
                        $i1.TokenType = tokenType;
                        return $i1;
                    })();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(549756141688)
            
            //--TRIMMABLE-BOUNDARY-START(395137319032)
            /*SecurityTokenDescriptor*/ static s_emptyTokenDescriptor = null;
            //--TRIMMABLE-BOUNDARY-END(395137319032)
            
            //--TRIMMABLE-BOUNDARY-START(34360066168)
            /*string*/ static ActClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(34360066168)
            
            //--TRIMMABLE-BOUNDARY-START(399432286328)
            /*int*/ static s_maxActorChainLength = 1;
            //--TRIMMABLE-BOUNDARY-END(399432286328)
            
            //--TRIMMABLE-BOUNDARY-START(326417842296)
            static /*int */ get MaxActorChainLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993332856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.s_maxActorChainLength;
            }
            static /*int */ set MaxActorChainLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202090104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 1)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentOutOfRangeException().$ctor$19("value", $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14317: JsonWebTokenHandler.MaxActorChainLength must be greater than or equal to 1. Value provided was: '{0}'."/*LogMessages.IDX14317*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(value, $.$$.System.Int32)) ], null, null))));
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.s_maxActorChainLength = value;
            }
            //--TRIMMABLE-BOUNDARY-END(326417842296)
            
            //--TRIMMABLE-BOUNDARY-START(163209085048)
            /*string */ CreateToken$13(/*string*/ payload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209085048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.s_emptyTokenDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(163209085048)
            
            //--TRIMMABLE-BOUNDARY-START(107374510200)
            /*string */ CreateToken(/*string*/ payload, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(107374510200)
            
            //--TRIMMABLE-BOUNDARY-START(158914117752)
            /*string */ CreateToken$12(/*string*/ payload, /*SigningCredentials*/ signingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914117752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(158914117752)
            
            //--TRIMMABLE-BOUNDARY-START(128849346680)
            /*string */ CreateToken$5(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849346680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(128849346680)
            
            //--TRIMMABLE-BOUNDARY-START(171799019640)
            /*string */ CreateToken$15(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(tokenDescriptor, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenDescriptor") });
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                {
                    if ((tokenDescriptor.Subject === null || !$.$sl.System.Linq.Enumerable.Any$1($.$ssc.System.Security.Claims.Claim, tokenDescriptor.Subject.Claims)) && (tokenDescriptor.Claims === null || !$.$sl.System.Linq.Enumerable.Any$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), tokenDescriptor.Claims)))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning("IDX14114: Both '{0}.{1}' and '{0}.{2}' are null or empty."/*LogMessages.IDX14114*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("SecurityTokenDescriptor"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Subject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Claims") ], null, null));
                    }
                }
                if ($.$$.System.Int32.op_GreaterThan$1((tokenDescriptor.AdditionalHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, tokenDescriptor.AdditionalHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("AdditionalHeaderClaims"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.String.Join$5(", ", $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                if ($.$$.System.Int32.op_GreaterThan$1((tokenDescriptor.AdditionalInnerHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, tokenDescriptor.AdditionalInnerHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("AdditionalInnerHeaderClaims"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.String.Join$5(", ", $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$14(tokenDescriptor, this.SetDefaultTimesOnTokenCreation, this.TokenLifetimeInMinutes);
            }
            //--TRIMMABLE-BOUNDARY-END(171799019640)
            
            //--TRIMMABLE-BOUNDARY-START(167504052344)
            static /*string */ CreateToken$14(/*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ setdefaultTimesOnTokenCreation, /*int*/ tokenLifetimeInMinutes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let utf8ByteMemoryStream = null;
                try
                {
                    utf8ByteMemoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    /*char[]*/ let encodedChars = null;
                    /*byte[]*/ let asciiBytes = null;
                    /*byte[]*/ let signatureBytes = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(utf8ByteMemoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJwsHeader($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), tokenDescriptor);
                        /*int*/ let headerLength = $.$cast(utf8ByteMemoryStream.Length, $.$$.System.Int32);
                        writer.Reset();
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJwsPayload($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), tokenDescriptor, setdefaultTimesOnTokenCreation, tokenLifetimeInMinutes);
                        /*int*/ let payloadEnd = $.$cast(utf8ByteMemoryStream.Length, $.$$.System.Int32);
                        /*int*/ let signatureSize = 0;
                        if (tokenDescriptor.SigningCredentials !== null)
                        {
                            signatureSize = $.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.GetMaxByteCount(tokenDescriptor.SigningCredentials.Algorithm);
                        }
                        /*int*/ let encodedBufferSize = (($.trunc((((((payloadEnd + 4) | 0) + signatureSize) | 0)) / 3) * 4) | 0);
                        encodedChars = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(((encodedBufferSize + 4) | 0));
                        /*int*/ let sizeOfEncodedHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, utf8ByteMemoryStream.GetBuffer(), 0, headerLength)), $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(encodedChars));
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, sizeOfEncodedHeader);
                        /*int*/ let sizeOfEncodedPayload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, utf8ByteMemoryStream.GetBuffer(), headerLength, ((payloadEnd - headerLength) | 0))), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, encodedChars, ((sizeOfEncodedHeader + 1) | 0)));
                        asciiBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$$.System.Text.Encoding.ASCII.GetMaxByteCount(encodedBufferSize));
                        /*int*/ let sizeOfEncodedHeaderAndPayloadAsciiBytes = $.$$.System.Text.Encoding.ASCII.GetBytes(encodedChars, 0, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0), asciiBytes, 0);
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0));
                        /*int*/ let sizeOfEncodedSignature = 0;
                        if (tokenDescriptor.SigningCredentials !== null)
                        {
                            signatureBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(signatureSize);
                            /*int*/ let signatureLength;
                            /*bool*/ let signatureSucceeded = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateSignature($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, asciiBytes, 0, sizeOfEncodedHeaderAndPayloadAsciiBytes)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(signatureBytes), tokenDescriptor.SigningCredentials, $.$ref(() => signatureLength, ($v) => signatureLength = $v, $.$$.System.Int32));
                            sizeOfEncodedSignature = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, signatureBytes, 0, signatureLength)), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, encodedChars, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 2) | 0)));
                        }
                        if (tokenDescriptor.EncryptingCredentials !== null)
                        {
                            return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptToken$1($.$$.System.Text.Encoding.UTF8.GetBytes$1(encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)), tokenDescriptor);
                        }
                        else 
                        {
                            return $.$$.System.Span$$($.$$.System.Char).ToString.call($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)));
                        }
                    }
                    finally
                    {
                        {
                            if (!(encodedChars === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(encodedChars, false);
                            }
                            if (!(signatureBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(signatureBytes, false);
                            }
                            if (!(asciiBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(asciiBytes, false);
                            }
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    utf8ByteMemoryStream?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504052344)
            
            //--TRIMMABLE-BOUNDARY-START(120259412088)
            /*string */ CreateToken$3(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(120259412088)
            
            //--TRIMMABLE-BOUNDARY-START(111669477496)
            /*string */ CreateToken$1(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(111669477496)
            
            //--TRIMMABLE-BOUNDARY-START(154619150456)
            /*string */ CreateToken$11(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619150456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619150456)
            
            //--TRIMMABLE-BOUNDARY-START(133144313976)
            /*string */ CreateToken$6(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144313976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(133144313976)
            
            //--TRIMMABLE-BOUNDARY-START(115964444792)
            /*string */ CreateToken$2(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(115964444792)
            
            //--TRIMMABLE-BOUNDARY-START(150324183160)
            /*string */ CreateToken$10(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(payload, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(150324183160)
            
            //--TRIMMABLE-BOUNDARY-START(141734248568)
            /*string */ CreateToken$8(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*IDictionary<string, object>*/ additionalInnerHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(payload, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                _ = $.$firstOf(additionalInnerHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalInnerHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    $i1.AdditionalInnerHeaderClaims = additionalInnerHeaderClaims;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(141734248568)
            
            //--TRIMMABLE-BOUNDARY-START(146029215864)
            /*string */ CreateToken$9(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(payload, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(146029215864)
            
            //--TRIMMABLE-BOUNDARY-START(137439281272)
            static /*string */ CreateToken$7(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*IDictionary<string, object>*/ additionalInnerHeaderClaims, /*string*/ tokenType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439281272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.SigningCredentials = signingCredentials;
                        $i1.EncryptingCredentials = encryptingCredentials;
                        $i1.CompressionAlgorithm = compressionAlgorithm;
                        $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                        $i1.AdditionalInnerHeaderClaims = additionalInnerHeaderClaims;
                        $i1.TokenType = tokenType;
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439281272)
            
            //--TRIMMABLE-BOUNDARY-START(124554379384)
            static /*string */ CreateToken$4(/*string*/ payload, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let utf8ByteMemoryStream = null;
                try
                {
                    utf8ByteMemoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    /*char[]*/ let encodedChars = null;
                    /*byte[]*/ let asciiBytes = null;
                    /*byte[]*/ let signatureBytes = null;
                    /*byte[]*/ let payloadBytes = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(utf8ByteMemoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJwsHeader($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), tokenDescriptor);
                        /*int*/ let headerLength = $.$cast(utf8ByteMemoryStream.Length, $.$$.System.Int32);
                        /*int*/ let signatureSize = 0;
                        /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                        if (signingCredentials !== null)
                        {
                            signatureSize = $.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.GetMaxByteCount(signingCredentials.Algorithm);
                        }
                        payloadBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$$.System.Text.Encoding.UTF8.GetMaxByteCount(payload.length));
                        /*int*/ let payloadSize = $.$$.System.Text.Encoding.UTF8.GetBytes$6(payload, 0, payload.length, payloadBytes, 0);
                        /*int*/ let encodedBufferSize = (($.trunc((((((((headerLength + payloadSize) | 0) + 4) | 0) + signatureSize) | 0)) / 3) * 4) | 0);
                        encodedChars = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(((encodedBufferSize + 4) | 0));
                        /*int*/ let sizeOfEncodedHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, utf8ByteMemoryStream.GetBuffer(), 0, headerLength)), $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(encodedChars));
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, sizeOfEncodedHeader);
                        /*int*/ let sizeOfEncodedPayload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, payloadBytes, 0, payloadSize)), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, encodedChars, ((sizeOfEncodedHeader + 1) | 0)));
                        asciiBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$$.System.Text.Encoding.ASCII.GetMaxByteCount(encodedBufferSize));
                        /*int*/ let sizeOfEncodedHeaderAndPayloadAsciiBytes = $.$$.System.Text.Encoding.ASCII.GetBytes(encodedChars, 0, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0), asciiBytes, 0);
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0));
                        /*int*/ let sizeOfEncodedSignature = 0;
                        if (signingCredentials !== null)
                        {
                            signatureBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(signatureSize);
                            /*int*/ let signatureLength;
                            /*bool*/ let signatureSucceeded = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateSignature($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, asciiBytes, 0, sizeOfEncodedHeaderAndPayloadAsciiBytes)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(signatureBytes), signingCredentials, $.$ref(() => signatureLength, ($v) => signatureLength = $v, $.$$.System.Int32));
                            sizeOfEncodedSignature = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, signatureBytes, 0, signatureLength)), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, encodedChars, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 2) | 0)));
                        }
                        /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                        if (encryptingCredentials !== null)
                        {
                            return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptToken$1($.$$.System.Text.Encoding.UTF8.GetBytes$1(encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)), tokenDescriptor);
                        }
                        else 
                        {
                            return $.$$.System.Span$$($.$$.System.Char).ToString.call($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)));
                        }
                    }
                    finally
                    {
                        {
                            if (!(encodedChars === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(encodedChars, false);
                            }
                            if (!(signatureBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(signatureBytes, false);
                            }
                            if (!(asciiBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(asciiBytes, false);
                            }
                            if (!(payloadBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(payloadBytes, false);
                            }
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    utf8ByteMemoryStream?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554379384)
            
            //--TRIMMABLE-BOUNDARY-START(597000781944)
            static /*void */ WriteJwsPayload(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ setDefaultTimesOnTokenCreation, /*int*/ tokenLifetimeInMinutes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597000781944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let descriptorClaimsAudienceChecked = false;
                /*bool*/ let audienceSet = false;
                /*bool*/ let descriptorClaimsIssuerChecked = false;
                /*bool*/ let issuerSet = false;
                /*bool*/ let descriptorClaimsExpChecked = false;
                /*bool*/ let expSet = false;
                /*bool*/ let descriptorClaimsIatChecked = false;
                /*bool*/ let iatSet = false;
                /*bool*/ let descriptorClaimsNbfChecked = false;
                /*bool*/ let nbfSet = false;
                writer.$v.WriteStartObject();
                if (tokenDescriptor.Audiences.System$Collections$Generic$ICollection$$$Count > 0)
                {
                    if (!$.$$.System.String.IsNullOrEmpty(tokenDescriptor.Audience))
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteStrings$1(writer, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud, tokenDescriptor.Audiences, tokenDescriptor.Audience);
                    }
                    else 
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteStrings$2(writer, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud, tokenDescriptor.Audiences);
                    }
                    audienceSet = true;
                }
                else if (!$.$$.System.String.IsNullOrEmpty(tokenDescriptor.Audience))
                {
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud);
                    writer.$v.WriteStringValue$5(tokenDescriptor.Audience);
                    audienceSet = true;
                }
                if (!$.$$.System.String.IsNullOrEmpty(tokenDescriptor.Issuer))
                {
                    issuerSet = true;
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iss);
                    writer.$v.WriteStringValue$5(tokenDescriptor.Issuer);
                }
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(tokenDescriptor.Expires))
                {
                    expSet = true;
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Exp);
                    writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(tokenDescriptor.Expires)));
                }
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(tokenDescriptor.IssuedAt))
                {
                    iatSet = true;
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iat);
                    writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(tokenDescriptor.IssuedAt)));
                }
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(tokenDescriptor.NotBefore))
                {
                    nbfSet = true;
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Nbf);
                    writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(tokenDescriptor.NotBefore)));
                }
                /*bool*/ let isActorFound = false;
                /*bool*/ let rawActClaimWritten = false;
                if (tokenDescriptor.Claims !== null && tokenDescriptor.Claims.System$Collections$Generic$ICollection$$$Count > 0)
                {
                    var $en3 = tokenDescriptor.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kvp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.Equals$4.call(kvp.Key, "act"/*ActClaimType*/, 4/*StringComparison.Ordinal*/))
                            {
                                if ($.$is(kvp.Value, $.$ssc.System.Security.Claims.ClaimsIdentity))
                                {
                                    isActorFound = true;
                                    continue;
                                }
                                rawActClaimWritten = true;
                            }
                            if (!descriptorClaimsAudienceChecked && $.$$.System.String.Equals$4.call(kvp.Key, "aud"/*JwtRegisteredClaimNames.Aud*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsAudienceChecked = true;
                                if (audienceSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        /*string*/ let descriptorMemberName = null;
                                        if (tokenDescriptor.Audiences.System$Collections$Generic$ICollection$$$Count > 0)
                                        {
                                            descriptorMemberName = "Audiences";
                                        }
                                        else if (!$.$$.System.String.IsNullOrEmpty(tokenDescriptor.Audience))
                                        {
                                            descriptorMemberName = "Audience";
                                        }
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(descriptorMemberName) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                audienceSet = true;
                            }
                            if (!descriptorClaimsIssuerChecked && $.$$.System.String.Equals$4.call(kvp.Key, "iss"/*JwtRegisteredClaimNames.Iss*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsIssuerChecked = true;
                                if (issuerSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Issuer") ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                issuerSet = true;
                            }
                            if (!descriptorClaimsExpChecked && $.$$.System.String.Equals$4.call(kvp.Key, "exp"/*JwtRegisteredClaimNames.Exp*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsExpChecked = true;
                                if (expSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                expSet = true;
                            }
                            if (!descriptorClaimsIatChecked && $.$$.System.String.Equals$4.call(kvp.Key, "iat"/*JwtRegisteredClaimNames.Iat*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsIatChecked = true;
                                if (iatSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                iatSet = true;
                            }
                            if (!descriptorClaimsNbfChecked && $.$$.System.String.Equals$4.call(kvp.Key, "nbf"/*JwtRegisteredClaimNames.Nbf*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsNbfChecked = true;
                                if (nbfSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                nbfSet = true;
                            }
                            $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                        }
                    }
                }
                if (isActorFound || (!((tokenDescriptor.Subject?.Actor ?? null) === null) && !rawActClaimWritten))
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActor(writer, tokenDescriptor);
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.AddSubjectClaims(writer, tokenDescriptor, audienceSet, issuerSet, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => expSet, ($v) => expSet = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => iatSet, ($v) => iatSet = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => nbfSet, ($v) => nbfSet = $v, null));
                if (setDefaultTimesOnTokenCreation && !(expSet && iatSet && nbfSet))
                {
                    /*DateTime*/ let now = $.$$.System.DateTime.UtcNow;
                    if (!expSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Exp);
                        writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.DateTime.op_Addition(now, $.$$.System.TimeSpan.FromMinutes$2(BigInt(tokenLifetimeInMinutes)))));
                    }
                    if (!iatSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iat);
                        writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate(now));
                    }
                    if (!nbfSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Nbf);
                        writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate(now));
                    }
                }
                writer.$v.WriteEndObject();
                writer.$v.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(597000781944)
            
            //--TRIMMABLE-BOUNDARY-START(38655033464)
            static /*void */ AddSubjectClaims(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ audienceSet, /*bool*/ issuerSet, /*ref bool*/ expSet, /*ref bool*/ iatSet, /*ref bool*/ nbfSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenDescriptor.Subject === null)
                {
                    return;
                }
                /*bool*/ let expReset = false;
                /*bool*/ let iatReset = false;
                /*bool*/ let nbfReset = false;
                /*var*/ let payload = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                /*bool*/ let checkClaims = tokenDescriptor.Claims !== null && tokenDescriptor.Claims.System$Collections$Generic$ICollection$$$Count > 0;
                /*bool*/ let subjectHasActor = !(tokenDescriptor.Subject.Actor === null);
                var $en2 = tokenDescriptor.Subject.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if (subjectHasActor && $.$$.System.String.Equals$4.call(claim.Type, "act"/*ActClaimType*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if (checkClaims && tokenDescriptor.Claims.System$Collections$Generic$IDictionary$$$$ContainsKey(claim.Type, [$.$$.System.String, $.$$.System.Object]))
                        {
                            continue;
                        }
                        if (audienceSet && $.$$.System.String.Equals$4.call(claim.Type, "aud"/*JwtRegisteredClaimNames.Aud*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if (issuerSet && $.$$.System.String.Equals$4.call(claim.Type, "iss"/*JwtRegisteredClaimNames.Iss*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if ($.$$.System.String.Equals$4.call(claim.Type, "exp"/*JwtRegisteredClaimNames.Exp*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (expSet.$v)
                            {
                                continue;
                            }
                            expReset = true;
                        }
                        if ($.$$.System.String.Equals$4.call(claim.Type, "iat"/*JwtRegisteredClaimNames.Iat*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (iatSet.$v)
                            {
                                continue;
                            }
                            iatReset = true;
                        }
                        if ($.$$.System.String.Equals$4.call(claim.Type, "nbf"/*JwtRegisteredClaimNames.Nbf*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (nbfSet.$v)
                            {
                                continue;
                            }
                            nbfReset = true;
                        }
                        /*object*/ let jsonClaimValue = $.$$.System.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetClaimValueUsingValueType(claim);
                        /*object*/ let existingValue;
                        if (payload.TryGetValue(claim.Type, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.System.Object)))
                        {
                            let existingList;
                            if ($.$is(existingValue, $.$$.System.Collections.Generic.List$$($.$$.System.Object), { set $v(v){ existingList = v; } }))
                            {
                                existingList.Add(jsonClaimValue);
                            }
                            else 
                            {
                                payload.set_Item(claim.Type, (() =>
                                {
                                    //new $.$$.System.Collections.Generic.List$$($.$$.System.Object)()
                                    const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.Object);
                                    const $i2 = new $t2();
                                    $i2.$ctor$1();
                                    $i2.Add(existingValue);
                                    $i2.Add(jsonClaimValue);
                                    return $i2;
                                })());
                            }
                        }
                        else 
                        {
                            payload.set_Item(claim.Type, jsonClaimValue);
                        }
                    }
                }
                var $en2 = payload.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                    }
                }
                expSet.$v = $.$$.System.Boolean.op_BitwiseOr(expSet.$v, expReset);
                iatSet.$v = $.$$.System.Boolean.op_BitwiseOr(iatSet.$v, iatReset);
                nbfSet.$v = $.$$.System.Boolean.op_BitwiseOr(nbfSet.$v, nbfReset);
            }
            //--TRIMMABLE-BOUNDARY-END(38655033464)
            
            //--TRIMMABLE-BOUNDARY-START(592705814648)
            static /*void */ WriteJwsHeader$1(/*ref Utf8JsonWriter*/ writer, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ jweHeaderClaims, /*IDictionary<string, object>*/ jwsHeaderClaims, /*string*/ tokenType, /*bool*/ includeKeyIdInHeader)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(592705814648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJwsHeader(writer, (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t2 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.SigningCredentials = signingCredentials;
                        $i2.EncryptingCredentials = encryptingCredentials;
                        $i2.AdditionalHeaderClaims = jweHeaderClaims;
                        $i2.AdditionalInnerHeaderClaims = jwsHeaderClaims;
                        $i2.TokenType = tokenType;
                        $i2.IncludeKeyIdInHeader = includeKeyIdInHeader;
                        return $i2;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(592705814648)
            
            //--TRIMMABLE-BOUNDARY-START(588410847352)
            static /*void */ WriteJwsHeader(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588410847352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IDictionary<string, object>*/ let jweHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                if ($.$$.System.Int32.op_GreaterThan$1((jweHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, jweHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("jweHeaderClaims"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.String.Join$5(", ", $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                /*IDictionary<string, object>*/ let jwsHeaderClaims = tokenDescriptor.AdditionalInnerHeaderClaims;
                if ($.$$.System.Int32.op_GreaterThan$1((jwsHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, jwsHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("jwsHeaderClaims"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.String.Join$5(", ", $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                /*bool*/ let addJweHeaderClaims = tokenDescriptor.EncryptingCredentials === null && $.$$.System.Int32.op_GreaterThan$1((jweHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0);
                /*bool*/ let addJwsHeaderClaims = $.$$.System.Int32.op_GreaterThan$1((jwsHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0);
                /*bool*/ let typeWritten = false;
                writer.$v.WriteStartObject();
                /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                if (signingCredentials === null)
                {
                    writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Alg, "none"/*SecurityAlgorithms.None*/);
                }
                else 
                {
                    writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Alg, signingCredentials.Algorithm);
                    if (tokenDescriptor.IncludeKeyIdInHeader)
                    {
                        if ($.$$.System.String.op_Inequality(signingCredentials.Key.KeyId, null))
                        {
                            writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Kid, signingCredentials.Key.KeyId);
                        }
                        let x509SecurityKey;
                        if ($.$is(signingCredentials.Key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey, { set $v(v){ x509SecurityKey = v; } }))
                        {
                            writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.X5t, x509SecurityKey.X5t);
                        }
                    }
                }
                if (addJweHeaderClaims)
                {
                    var $en3 = jweHeaderClaims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kvp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (addJwsHeaderClaims && jwsHeaderClaims.System$Collections$Generic$IDictionary$$$$ContainsKey(kvp.Key, [$.$$.System.String, $.$$.System.Object]))
                            {
                                continue;
                            }
                            $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                            if (!typeWritten && $.$$.System.String.Equals$4.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                            {
                                typeWritten = true;
                            }
                        }
                    }
                }
                if (addJwsHeaderClaims)
                {
                    var $en3 = jwsHeaderClaims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kvp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                            if (!typeWritten && $.$$.System.String.Equals$4.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                            {
                                typeWritten = true;
                            }
                        }
                    }
                }
                if (!typeWritten)
                {
                    /*string*/ let tokenType = tokenDescriptor.TokenType;
                    writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Typ, $.$$.System.String.IsNullOrEmpty(tokenType) ? "JWT"/*JwtConstants.HeaderType*/ : tokenType);
                }
                writer.$v.WriteEndObject();
                writer.$v.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(588410847352)
            
            //--TRIMMABLE-BOUNDARY-START(579820912760)
            static /*byte[] */ WriteJweHeader(/*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*string*/ tokenType, /*IDictionary<string, object>*/ jweHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(579820912760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJweHeader$1((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.EncryptingCredentials = encryptingCredentials;
                        $i1.CompressionAlgorithm = compressionAlgorithm;
                        $i1.TokenType = tokenType;
                        $i1.AdditionalHeaderClaims = jweHeaderClaims;
                        $i1.IncludeKeyIdInHeader = includeKeyIdInHeader;
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(579820912760)
            
            //--TRIMMABLE-BOUNDARY-START(584115880056)
            static /*byte[] */ WriteJweHeader$1(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584115880056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(memoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        writer.WriteStartObject();
                        /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                        writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Alg, encryptingCredentials.Alg);
                        writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Enc, encryptingCredentials.Enc);
                        /*bool*/ let includeKeyIdInHeader = tokenDescriptor.IncludeKeyIdInHeader;
                        if ($.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                        {
                            if (includeKeyIdInHeader && $.$$.System.String.op_Inequality(encryptingCredentials.KeyExchangePublicKey.KeyId, null))
                            {
                                writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Kid, encryptingCredentials.KeyExchangePublicKey.KeyId);
                            }
                            if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(encryptingCredentials.Alg, [$.$$.System.String]))
                            {
                                writer.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Epk);
                                /*string*/ let publicJwk = $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKeyConverter.ConvertFromSecurityKey(encryptingCredentials.Key).RepresentAsAsymmetricPublicJwk();
                                writer.WriteRawValue$2(publicJwk, false);
                            }
                        }
                        else 
                        {
                            if (includeKeyIdInHeader && $.$$.System.String.op_Inequality(encryptingCredentials.Key.KeyId, null))
                            {
                                writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Kid, encryptingCredentials.Key.KeyId);
                            }
                        }
                        /*string*/ let compressionAlgorithm = tokenDescriptor.CompressionAlgorithm;
                        if (!$.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                        {
                            writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Zip, compressionAlgorithm);
                        }
                        /*bool*/ let typeWritten = false;
                        /*bool*/ let ctyWritten = !encryptingCredentials.SetDefaultCtyClaim;
                        /*IDictionary<string, object>*/ let jweHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                        if (jweHeaderClaims !== null && jweHeaderClaims.System$Collections$Generic$ICollection$$$Count > 0)
                        {
                            var $en5 = jweHeaderClaims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kvp = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), kvp.Key, kvp.Value);
                                    if (!typeWritten && $.$$.System.String.Equals$4.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                                    {
                                        typeWritten = true;
                                    }
                                    else if (!ctyWritten && $.$$.System.String.Equals$4.call(kvp.Key, "cty"/*JwtHeaderParameterNames.Cty*/, 4/*StringComparison.Ordinal*/))
                                    {
                                        ctyWritten = true;
                                    }
                                }
                            }
                        }
                        if (!typeWritten)
                        {
                            /*string*/ let tokenType = tokenDescriptor.TokenType;
                            writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Typ, $.$$.System.String.IsNullOrEmpty(tokenType) ? "JWT"/*JwtConstants.HeaderType*/ : tokenType);
                        }
                        if (!ctyWritten)
                        {
                            writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Cty, "JWT"/*JwtConstants.HeaderType*/);
                        }
                        writer.WriteEndObject();
                        writer.Flush();
                        return memoryStream.ToArray();
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(584115880056)
            
            //--TRIMMABLE-BOUNDARY-START(558346076280)
            static /*void */ WriteActor(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558346076280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ClaimsIdentity*/ let actor = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActorIdentity(tokenDescriptor);
                if (actor === null)
                {
                    return;
                }
                /*int*/ let remainingActorLevels = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.MaxActorChainLength;
                writer.$v.WritePropertyName$11("act"/*ActClaimType*/);
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorValue(writer, actor, remainingActorLevels);
            }
            //--TRIMMABLE-BOUNDARY-END(558346076280)
            
            //--TRIMMABLE-BOUNDARY-START(571230978168)
            static /*void */ WriteActorValue(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ actor, /*int*/ remainingActorLevels)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571230978168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (remainingActorLevels > 0)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorObject(writer, actor, remainingActorLevels);
                }
                else 
                {
                    writer.$v.WriteStringValue$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorAsJsonString(actor));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(571230978168)
            
            //--TRIMMABLE-BOUNDARY-START(566936010872)
            static /*void */ WriteActorObject(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ actor, /*int*/ remainingActorLevels)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566936010872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.$v.WriteStartObject();
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteIdentityClaims(writer, actor);
                if (!(actor.Actor === null))
                {
                    writer.$v.WritePropertyName$11("act"/*ActClaimType*/);
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorValue(writer, actor.Actor, ((remainingActorLevels - 1) | 0));
                }
                writer.$v.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(566936010872)
            
            //--TRIMMABLE-BOUNDARY-START(575525945464)
            static /*void */ WriteIdentityClaims(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575525945464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let payload = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                var $en2 = identity.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        /*object*/ let jsonClaimValue = $.$$.System.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetClaimValueUsingValueType(claim);
                        /*object*/ let existingValue;
                        if (payload.TryGetValue(claim.Type, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.System.Object)))
                        {
                            let existingList;
                            if ($.$is(existingValue, $.$$.System.Collections.Generic.List$$($.$$.System.Object), { set $v(v){ existingList = v; } }))
                            {
                                existingList.Add(jsonClaimValue);
                            }
                            else 
                            {
                                payload.set_Item(claim.Type, (() =>
                                {
                                    //new $.$$.System.Collections.Generic.List$$($.$$.System.Object)()
                                    const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.Object);
                                    const $i2 = new $t2();
                                    $i2.$ctor$1();
                                    $i2.Add(existingValue);
                                    $i2.Add(jsonClaimValue);
                                    return $i2;
                                })());
                            }
                        }
                        else 
                        {
                            payload.set_Item(claim.Type, jsonClaimValue);
                        }
                    }
                }
                var $en2 = payload.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(575525945464)
            
            //--TRIMMABLE-BOUNDARY-START(283468169336)
            static /*ClaimsIdentity */ GetActorIdentity(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468169336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let actorValue;
                let actorIdentity;
                if ((tokenDescriptor.Claims?.System$Collections$Generic$IDictionary$$$$TryGetValue("act"/*ActClaimType*/, $.$ref(() => actorValue, ($v) => actorValue = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]) ?? null) === true && $.$is(actorValue, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ actorIdentity = v; } }))
                {
                    return actorIdentity;
                }
                return tokenDescriptor.Subject?.Actor ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(283468169336)
            
            //--TRIMMABLE-BOUNDARY-START(562641043576)
            static /*string */ WriteActorAsJsonString(/*ClaimsIdentity*/ actor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562641043576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let stream = null;
                try
                {
                    stream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let actorWriter = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(stream, new $.$stj.System.Text.Json.JsonWriterOptions());
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorObject($.$ref(() => actorWriter, ($v) => actorWriter = $v, $.$stj.System.Text.Json.Utf8JsonWriter), actor, 2147483647/*int.MaxValue*/);
                    actorWriter.Flush();
                    return $.$$.System.Text.Encoding.UTF8.GetString(stream.GetBuffer(), 0, $.$cast(stream.Length, $.$$.System.Int32));
                }
                finally
                {
                    stream?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(562641043576)
            
            //--TRIMMABLE-BOUNDARY-START(55834902648)
            static /*byte[] */ CompressToken(/*byte[]*/ utf8Bytes, /*string*/ compressionAlgorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834902648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                if (!$.$mit.Microsoft.IdentityModel.Tokens.CompressionProviderFactory.Default.IsSupportedAlgorithm(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.NotSupportedException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10682: Compression algorithm '{0}' is not supported."/*TokenLogMessages.IDX10682*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null))));
                }
                /*var*/ let compressionProvider = $.$mit.Microsoft.IdentityModel.Tokens.CompressionProviderFactory.Default.CreateCompressionProvider$1(compressionAlgorithm);
                return $.$firstOf(compressionProvider.Microsoft$IdentityModel$Tokens$ICompressionProvider$Compress(utf8Bytes), () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10680: Failed to compress using algorithm '{0}'."/*TokenLogMessages.IDX10680*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null)))) });
            }
            //--TRIMMABLE-BOUNDARY-END(55834902648)
            
            //--TRIMMABLE-BOUNDARY-START(223338627192)
            /*string */ EncryptToken$5(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338627192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(223338627192)
            
            //--TRIMMABLE-BOUNDARY-START(210453725304)
            /*string */ EncryptToken$2(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453725304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if (additionalHeaderClaims === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(210453725304)
            
            //--TRIMMABLE-BOUNDARY-START(219043659896)
            /*string */ EncryptToken$4(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ algorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043659896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if ($.$$.System.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("algorithm");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = algorithm;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(219043659896)
            
            //--TRIMMABLE-BOUNDARY-START(214748692600)
            /*string */ EncryptToken$3(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ algorithm, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748692600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if ($.$$.System.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("algorithm");
                }
                if (additionalHeaderClaims === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = algorithm;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(214748692600)
            
            //--TRIMMABLE-BOUNDARY-START(227633594488)
            static /*string */ EncryptTokenPrivate(/*string*/ innerJwt, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633594488);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptToken$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(innerJwt), tokenDescriptor);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633594488)
            
            //--TRIMMABLE-BOUNDARY-START(201863790712)
            static /*string */ EncryptToken(/*byte[]*/ innerTokenUtf8Bytes, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*string*/ tokenType, /*bool*/ includeKeyIdInHeader)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201863790712);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptToken$1(innerTokenUtf8Bytes, (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.EncryptingCredentials = encryptingCredentials;
                        $i1.CompressionAlgorithm = compressionAlgorithm;
                        $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                        $i1.TokenType = tokenType;
                        $i1.IncludeKeyIdInHeader = includeKeyIdInHeader;
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201863790712)
            
            //--TRIMMABLE-BOUNDARY-START(206158758008)
            static /*string */ EncryptToken$1(/*byte[]*/ innerTokenUtf8Bytes, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158758008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                /*CryptoProviderFactory*/ let cryptoProviderFactory = encryptingCredentials.CryptoProviderFactory ?? encryptingCredentials.Key.CryptoProviderFactory;
                if (cryptoProviderFactory === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX10620: Unable to obtain a CryptoProviderFactory, both EncryptingCredentials.CryptoProviderFactory and EncryptingCredentials.Key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10620*/));
                }
                /*IDictionary<string, object>*/ let additionalHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                /*byte[]*/ let wrappedKey;
                /*SecurityKey*/ let securityKey = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetSecurityKey(encryptingCredentials, cryptoProviderFactory, additionalHeaderClaims, $.$ref(() => wrappedKey, ($v) => wrappedKey = $v, $.$typeArray($.$$.System.Byte)));
                let encryptionProvider = null;
                try
                {
                    encryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(securityKey, encryptingCredentials.Enc);
                    if (encryptionProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX14103: Failed to create the token encryption provider."/*LogMessages.IDX14103*/));
                    }
                    /*byte[]*/ let jweHeader = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJweHeader$1(tokenDescriptor);
                    /*byte[]*/ let plainText;
                    /*string*/ let compressionAlgorithm = tokenDescriptor.CompressionAlgorithm;
                    if (!$.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                    {
                        try
                        {
                            plainText = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CompressToken(innerTokenUtf8Bytes, compressionAlgorithm);
                        }
                        catch(ex)
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenCompressionFailedException().$ctor$13($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10680: Failed to compress using algorithm '{0}'."/*TokenLogMessages.IDX10680*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null)), ex));
                        }
                    }
                    else 
                    {
                        plainText = innerTokenUtf8Bytes;
                    }
                    try
                    {
                        /*string*/ let rawHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(jweHeader);
                        /*var*/ let encryptionResult = encryptionProvider.Encrypt$1(plainText, $.$$.System.Text.Encoding.ASCII.GetBytes$8(rawHeader));
                        return $.$$.System.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg) ? $.$$.System.String.Join$8(".", $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ rawHeader, $.$$.System.String.Empty, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag) ])) : $.$$.System.String.Join$8(".", $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ rawHeader, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(wrappedKey), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag) ]));
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$13($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10616: Encryption failed. EncryptionProvider failed for: Algorithm: '{0}', SecurityKey: '{1}'. See inner exception."/*TokenLogMessages.IDX10616*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null)), ex));
                    }
                }
                finally
                {
                    encryptionProvider?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206158758008)
            
            //--TRIMMABLE-BOUNDARY-START(296353071224)
            /*IEnumerable<SecurityKey> */ GetContentEncryptionKeys$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353071224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (validationParameters.TokenDecryptionKeyResolver !== null)
                {
                    keys = validationParameters.TokenDecryptionKeyResolver.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey(jwtToken.EncodedToken, jwtToken, validationParameters);
                    if (key !== null)
                    {
                        if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10904: Token decryption key : '{0}' found in TokenValidationParameters."/*TokenLogMessages.IDX10904*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                        }
                    }
                    else if (configuration !== null)
                    {
                        key = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ResolveTokenDecryptionKeyFromConfig(jwtToken, configuration);
                        if (key !== null && $.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10905: Token decryption key : '{0}' found in Configuration/Metadata."/*TokenLogMessages.IDX10905*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                        }
                    }
                    if (key !== null)
                    {
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (validationParameters.TryAllDecryptionKeys && $.$mit.Microsoft.IdentityModel.Tokens.CollectionUtilities.IsNullOrEmpty($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys))
                {
                    keys = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetAllDecryptionKeys(validationParameters);
                    if (configuration !== null)
                    {
                        keys = keys === null ? configuration.TokenDecryptionKeys : $.$sl.System.Linq.Enumerable.Concat($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys, configuration.TokenDecryptionKeys);
                    }
                }
                if ($.$$.System.String.Equals$4.call(jwtToken.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/, 4/*StringComparison.Ordinal*/) || $.$$.System.String.Equals$4.call(jwtToken.Alg, "ECDH-ES"/*SecurityAlgorithms.EcdhEs*/, 4/*StringComparison.Ordinal*/))
                {
                    return keys;
                }
                /*var*/ let unwrappedKeys = new ($.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey))().$ctor$1();
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                if (keys !== null)
                {
                    var $en3 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(jwtToken.Alg, [$.$$.System.String]))
                                {
                                    /*ECDsaSecurityKey*/ let publicKey;
                                    if ($.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                                    {
                                        /*string*/ let epk;
                                        jwtToken.TryGetHeaderValue($.$$.System.String, "epk"/*JwtHeaderParameterNames.Epk*/, $.$ref(() => epk, ($v) => epk = $v, $.$$.System.String));
                                        publicKey = new $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey().$ctor$5(new $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKey().$ctor$4(epk), false);
                                    }
                                    else 
                                    {
                                        publicKey = $.$as(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey);
                                    }
                                    /*var*/ let ecdhKeyExchangeProvider = new $.$mit.Microsoft.IdentityModel.Tokens.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey), publicKey, jwtToken.Alg, jwtToken.Enc);
                                    /*string*/ let apu;
                                    jwtToken.TryGetHeaderValue($.$$.System.String, "apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => apu, ($v) => apu = $v, $.$$.System.String));
                                    /*string*/ let apv;
                                    jwtToken.TryGetHeaderValue($.$$.System.String, "apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => apv, ($v) => apv = $v, $.$$.System.String));
                                    /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                    /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                    /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.EncryptedKey));
                                    unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                                }
                                else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Alg, key))
                                {
                                    /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Alg);
                                    /*var*/ let unwrappedKey = kwp.UnwrapKey(jwtToken.EncryptedKeyBytes);
                                    unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                            }
                            (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(key.KeyId);
                        }
                    }
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings === null)
                {
                    return unwrappedKeys;
                }
                else 
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenKeyWrapException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(exceptionStrings ?? ""), jwtToken ], null, null))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(296353071224)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590262392)
                this._mapInboundClaims = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.DefaultMapInboundClaims;
                //--TRIMMABLE-BOUNDARY-END(8590262392)
                
                //--TRIMMABLE-BOUNDARY-START(442381959288)
                this.TelemetryClient = new $.$mit.Microsoft.IdentityModel.Telemetry.TelemetryClient().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(442381959288)
                
            }
            //--TRIMMABLE-BOUNDARY-START(25770131576)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229688)
                    this._namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties";
                    //--TRIMMABLE-BOUNDARY-END(12885229688)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180196984)
                    this._shortClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/ShortTypeName";
                    //--TRIMMABLE-BOUNDARY-END(17180196984)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273856120)
                    this.DefaultInboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.InboundClaimTypeMap);
                    //--TRIMMABLE-BOUNDARY-END(193273856120)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950000760)
                    this.Base64UrlEncodedUnsignedJWSHeader = "eyJhbGciOiJub25lIn0";
                    //--TRIMMABLE-BOUNDARY-END(42950000760)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137319032)
                    this.s_emptyTokenDescriptor = new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(395137319032)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360066168)
                    this.ActClaimType = "act";
                    //--TRIMMABLE-BOUNDARY-END(34360066168)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770131576)
            
            static $h = 327800;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 16515191,
  "p": [
//--TRIMMABLE-BOUNDARY-START(446676926584),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173202040,
        "f": 50331649
      },
      "n": "TokenType",
      "d": 327800,
      "h": 446676926584,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(446676926584),
//--TRIMMABLE-BOUNDARY-START(438086991992),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583267448,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 433792024696,
        "f": 83886113
      },
      "n": "ShortClaimTypeProperty",
      "d": 327800,
      "h": 438086991992,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(438086991992),
//--TRIMMABLE-BOUNDARY-START(322122875000),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403398264,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 416612155512,
        "f": 83886081
      },
      "n": "MapInboundClaims",
      "d": 327800,
      "h": 322122875000,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(322122875000),
//--TRIMMABLE-BOUNDARY-START(313532940408),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813463672,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 408022220920,
        "f": 83886081
      },
      "n": "InboundClaimTypeMap",
      "d": 327800,
      "h": 313532940408,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313532940408),
//--TRIMMABLE-BOUNDARY-START(51539935352),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223529080,
        "f": 50331777
      },
      "n": "CanValidateToken",
      "d": 327800,
      "h": 51539935352,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(51539935352),
//--TRIMMABLE-BOUNDARY-START(326417842296),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993332856,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 425202090104,
        "f": 83886113
      },
      "n": "MaxActorChainLength",
      "d": 327800,
      "h": 326417842296,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(326417842296)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64424837240),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        }
      ],
      "n": "CreateClaimsIdentity",
      "o": "@$1",
      "d": 327800,
      "h": 64424837240,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(64424837240),
//--TRIMMABLE-BOUNDARY-START(60129869944),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentity",
      "d": 327800,
      "h": 60129869944,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(60129869944),
//--TRIMMABLE-BOUNDARY-START(77309739128),
    {
      "r": 262213,
      "p": [
        {
          "n": "securityToken",
          "p": 13762679
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityInternal",
      "d": 327800,
      "h": 77309739128,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(77309739128),
//--TRIMMABLE-BOUNDARY-START(94489608312),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityWithMapping",
      "d": 327800,
      "h": 94489608312,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489608312),
//--TRIMMABLE-BOUNDARY-START(85899673720),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityPrivate",
      "d": 327800,
      "h": 85899673720,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899673720),
//--TRIMMABLE-BOUNDARY-START(360777580664),
    {
      "r": $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "ReadToken",
      "o": "@$1",
      "d": 327800,
      "h": 360777580664,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(360777580664),
//--TRIMMABLE-BOUNDARY-START(519691370616),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "callContext",
          "p": 1835127
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateTokenAsync",
      "d": 327800,
      "h": 519691370616,
      "f": 16814088
    },
//--TRIMMABLE-BOUNDARY-END(519691370616),
//--TRIMMABLE-BOUNDARY-START(536871239800),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).$h,
      "p": [
        {
          "n": "token",
          "p": 13762679
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "callContext",
          "p": 1835127
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$3",
      "d": 327800,
      "h": 536871239800,
      "f": 16814088
    },
//--TRIMMABLE-BOUNDARY-END(536871239800),
//--TRIMMABLE-BOUNDARY-START(450971893880),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "callContext",
          "p": 1835127
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateJWEAsync",
      "d": 327800,
      "h": 450971893880,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(450971893880),
//--TRIMMABLE-BOUNDARY-START(463856795768),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "callContext",
          "p": 1835127
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateJWSAsync",
      "d": 327800,
      "h": 463856795768,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(463856795768),
//--TRIMMABLE-BOUNDARY-START(300648038520),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.BaseConfiguration).$h,
      "p": [
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "GetCurrentConfigurationAsync",
      "d": 327800,
      "h": 300648038520,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(300648038520),
//--TRIMMABLE-BOUNDARY-START(47244968056),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "CanReadToken",
      "d": 327800,
      "h": 47244968056,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47244968056),
//--TRIMMABLE-BOUNDARY-START(304943005816),
    {
      "r": 163577857,
      "p": [
        {
          "n": "securityKey",
          "p": 13631607
        }
      ],
      "n": "GetStringComparisonRuleIf509",
      "d": 327800,
      "h": 304943005816,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(304943005816),
//--TRIMMABLE-BOUNDARY-START(309237973112),
    {
      "r": 163577857,
      "p": [
        {
          "n": "securityKey",
          "p": 13631607
        }
      ],
      "n": "GetStringComparisonRuleIf509OrECDsa",
      "d": 327800,
      "h": 309237973112,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(309237973112),
//--TRIMMABLE-BOUNDARY-START(73014771832),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "CreateClaimsIdentity",
      "o": "@$3",
      "d": 327800,
      "h": 73014771832,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(73014771832),
//--TRIMMABLE-BOUNDARY-START(68719804536),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentity",
      "o": "@$2",
      "d": 327800,
      "h": 68719804536,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68719804536),
//--TRIMMABLE-BOUNDARY-START(98784575608),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityWithMapping",
      "o": "@$1",
      "d": 327800,
      "h": 98784575608,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784575608),
//--TRIMMABLE-BOUNDARY-START(81604706424),
    {
      "r": 262213,
      "p": [
        {
          "n": "securityToken",
          "p": 13762679
        },
        {
          "n": "tokenValidationParameters",
          "p": 16777335
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityInternal",
      "o": "@$1",
      "d": 327800,
      "h": 81604706424,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(81604706424),
//--TRIMMABLE-BOUNDARY-START(287763136632),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        }
      ],
      "n": "GetActualIssuer",
      "d": 327800,
      "h": 287763136632,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(287763136632),
//--TRIMMABLE-BOUNDARY-START(90194641016),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "CreateClaimsIdentityPrivate",
      "o": "@$1",
      "d": 327800,
      "h": 90194641016,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90194641016),
//--TRIMMABLE-BOUNDARY-START(188978888824),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "DecryptTokenWithConfigurationAsync",
      "d": 327800,
      "h": 188978888824,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(188978888824),
//--TRIMMABLE-BOUNDARY-START(184683921528),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "DecryptToken",
      "o": "@$2",
      "d": 327800,
      "h": 184683921528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184683921528),
//--TRIMMABLE-BOUNDARY-START(180388954232),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "DecryptToken",
      "o": "@$1",
      "d": 327800,
      "h": 180388954232,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180388954232),
//--TRIMMABLE-BOUNDARY-START(103079542904),
    {
      "r": 786552,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "keys",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h
        }
      ],
      "n": "CreateJwtTokenDecryptionParameters",
      "d": 327800,
      "h": 103079542904,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079542904),
//--TRIMMABLE-BOUNDARY-START(390842351736),
    {
      "r": 13631607,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ResolveTokenDecryptionKeyFromConfig",
      "d": 327800,
      "h": 390842351736,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(390842351736),
//--TRIMMABLE-BOUNDARY-START(382252417144),
    {
      "r": 13631607,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ResolveTokenDecryptionKey",
      "d": 327800,
      "h": 382252417144,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(382252417144),
//--TRIMMABLE-BOUNDARY-START(356482613368),
    {
      "r": 262264,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ReadJsonWebToken",
      "o": "@$1",
      "d": 327800,
      "h": 356482613368,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(356482613368),
//--TRIMMABLE-BOUNDARY-START(352187646072),
    {
      "r": 262264,
      "p": [
        {
          "n": "token",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": "ReadJsonWebToken",
      "d": 327800,
      "h": 352187646072,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(352187646072),
//--TRIMMABLE-BOUNDARY-START(377957449848),
    {
      "r": 262264,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "encodedHeader",
          "p": 1310721
        }
      ],
      "n": "ReplaceTokenHeader",
      "d": 327800,
      "h": 377957449848,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(377957449848),
//--TRIMMABLE-BOUNDARY-START(369367515256),
    {
      "r": 13762679,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ReadToken",
      "d": 327800,
      "h": 369367515256,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(369367515256),
//--TRIMMABLE-BOUNDARY-START(365072547960),
    {
      "r": 16842871,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ReadToken",
      "o": "@$2",
      "d": 327800,
      "h": 365072547960,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(365072547960),
//--TRIMMABLE-BOUNDARY-START(176093986936),
    {
      "r": $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "DecryptToken",
      "d": 327800,
      "h": 176093986936,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(176093986936),
//--TRIMMABLE-BOUNDARY-START(292058103928),
    {
      "r": $.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "GetContentEncryptionKeys",
      "d": 327800,
      "h": 292058103928,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(292058103928),
//--TRIMMABLE-BOUNDARY-START(386547384440),
    {
      "r": 13631607,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "ResolveTokenDecryptionKey",
      "o": "@$1",
      "d": 327800,
      "h": 386547384440,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(386547384440),
//--TRIMMABLE-BOUNDARY-START(481036664952),
    {
      "r": $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "ValidateSignature",
      "o": "@$1",
      "d": 327800,
      "h": 481036664952,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(481036664952),
//--TRIMMABLE-BOUNDARY-START(502511501432),
    {
      "r": $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "ValidateSignatureUsingAllKeys",
      "d": 327800,
      "h": 502511501432,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(502511501432),
//--TRIMMABLE-BOUNDARY-START(511101436024),
    {
      "r": $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 10354807
        },
        {
          "n": "key",
          "p": 13631607
        },
        {
          "n": "callContext",
          "p": 1835127
        }
      ],
      "n": "ValidateSignatureWithKey",
      "d": 327800,
      "h": 511101436024,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(511101436024),
//--TRIMMABLE-BOUNDARY-START(347892678776),
    {
      "r": 65537,
      "p": [
        {
          "n": "failedResult",
          "p": $.$typeNullable($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.KeyMatchFailedResult).$h
        },
        {
          "n": "exceptionStrings",
          "p": 167051265
        },
        {
          "n": "keysAttempted",
          "p": 167051265
        }
      ],
      "n": "PopulateFailedResults",
      "d": 327800,
      "h": 347892678776,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(347892678776),
//--TRIMMABLE-BOUNDARY-START(459561828472),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateJWEAsync",
      "o": "@$2",
      "d": 327800,
      "h": 459561828472,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(459561828472),
//--TRIMMABLE-BOUNDARY-START(455266861176),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateJWEAsync",
      "o": "@$1",
      "d": 327800,
      "h": 455266861176,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(455266861176),
//--TRIMMABLE-BOUNDARY-START(472446730360),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateJWSAsync",
      "o": "@$2",
      "d": 327800,
      "h": 472446730360,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(472446730360),
//--TRIMMABLE-BOUNDARY-START(468151763064),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateJWSAsync",
      "o": "@$1",
      "d": 327800,
      "h": 468151763064,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(468151763064),
//--TRIMMABLE-BOUNDARY-START(498216534136),
    {
      "r": 262264,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateSignatureAndIssuerSecurityKey",
      "d": 327800,
      "h": 498216534136,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(498216534136),
//--TRIMMABLE-BOUNDARY-START(493921566840),
    {
      "r": 262264,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateSignature",
      "o": "@$4",
      "d": 327800,
      "h": 493921566840,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(493921566840),
//--TRIMMABLE-BOUNDARY-START(317827907704),
    {
      "r": 262145,
      "p": [
        {
          "n": "signatureBytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "signatureBytesLength",
          "p": 655361
        },
        {
          "n": "signatureProvider",
          "p": 15663223
        },
        {
          "n": "dataToVerify",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "dataToVerifyLength",
          "p": 655361
        }
      ],
      "n": "IsSignatureValid",
      "d": 327800,
      "h": 317827907704,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(317827907704),
//--TRIMMABLE-BOUNDARY-START(476741697656),
    {
      "r": 262145,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "len",
          "p": 655361
        },
        {
          "n": "stringWithSignature",
          "p": 1310721
        },
        {
          "n": "signatureStartIndex",
          "p": 655361
        },
        {
          "n": "signatureProvider",
          "p": 15663223
        }
      ],
      "n": "ValidateSignature",
      "d": 327800,
      "h": 476741697656,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(476741697656),
//--TRIMMABLE-BOUNDARY-START(489626599544),
    {
      "r": 262145,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "key",
          "p": 13631607
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateSignature",
      "o": "@$3",
      "d": 327800,
      "h": 489626599544,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(489626599544),
//--TRIMMABLE-BOUNDARY-START(373662482552),
    {
      "r": 65537,
      "p": [
        {
          "n": "telemetryClient",
          "p": 196727
        },
        {
          "n": "errorType",
          "p": 1310721
        },
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "key",
          "p": 13631607
        }
      ],
      "n": "RecordSignatureValidationTelemetry",
      "d": 327800,
      "h": 373662482552,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(373662482552),
//--TRIMMABLE-BOUNDARY-START(485331632248),
    {
      "r": 262145,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "key",
          "p": 13631607
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "telemetryClient",
          "p": 196727
        }
      ],
      "n": "ValidateSignature",
      "o": "@$2",
      "d": 327800,
      "h": 485331632248,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(485331632248),
//--TRIMMABLE-BOUNDARY-START(506806468728),
    {
      "r": 262264,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateSignatureUsingDelegates",
      "d": 327800,
      "h": 506806468728,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(506806468728),
//--TRIMMABLE-BOUNDARY-START(515396403320),
    {
      "r": 16842871,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateToken",
      "d": 327800,
      "h": 515396403320,
      "f": 16777345,
      "a": [
        {
          "t": 103743489,
          "c": 25873547265,
          "a": [
            {
              "v": "\u0060JsonWebTokens.ValidateToken(string, TokenValidationParameters)\u0060 has been deprecated and will be removed in a future release. Use \u0060JsonWebTokens.ValidateTokenAsync(string, TokenValidationParameters)\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(515396403320),
//--TRIMMABLE-BOUNDARY-START(528281305208),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$2",
      "d": 327800,
      "h": 528281305208,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(528281305208),
//--TRIMMABLE-BOUNDARY-START(523986337912),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$1",
      "d": 327800,
      "h": 523986337912,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(523986337912),
//--TRIMMABLE-BOUNDARY-START(545461174392),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 13762679
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$5",
      "d": 327800,
      "h": 545461174392,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(545461174392),
//--TRIMMABLE-BOUNDARY-START(541166207096),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 13762679
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$4",
      "d": 327800,
      "h": 541166207096,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(541166207096),
//--TRIMMABLE-BOUNDARY-START(532576272504),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$6",
      "d": 327800,
      "h": 532576272504,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(532576272504),
//--TRIMMABLE-BOUNDARY-START(554051108984),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateTokenPayloadAsync",
      "o": "@$1",
      "d": 327800,
      "h": 554051108984,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(554051108984),
//--TRIMMABLE-BOUNDARY-START(549756141688),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ValidateTokenPayloadAsync",
      "d": 327800,
      "h": 549756141688,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(549756141688),
//--TRIMMABLE-BOUNDARY-START(163209085048),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        }
      ],
      "n": "CreateToken",
      "o": "@$13",
      "d": 327800,
      "h": 163209085048,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(163209085048),
//--TRIMMABLE-BOUNDARY-START(107374510200),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "CreateToken",
      "d": 327800,
      "h": 107374510200,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(107374510200),
//--TRIMMABLE-BOUNDARY-START(158914117752),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        }
      ],
      "n": "CreateToken",
      "o": "@$12",
      "d": 327800,
      "h": 158914117752,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(158914117752),
//--TRIMMABLE-BOUNDARY-START(128849346680),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$5",
      "d": 327800,
      "h": 128849346680,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(128849346680),
//--TRIMMABLE-BOUNDARY-START(171799019640),
    {
      "r": 1310721,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "CreateToken",
      "o": "@$15",
      "d": 327800,
      "h": 171799019640,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(171799019640),
//--TRIMMABLE-BOUNDARY-START(167504052344),
    {
      "r": 1310721,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090359
        },
        {
          "n": "setdefaultTimesOnTokenCreation",
          "p": 262145
        },
        {
          "n": "tokenLifetimeInMinutes",
          "p": 655361
        }
      ],
      "n": "CreateToken",
      "o": "@$14",
      "d": 327800,
      "h": 167504052344,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(167504052344),
//--TRIMMABLE-BOUNDARY-START(120259412088),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        }
      ],
      "n": "CreateToken",
      "o": "@$3",
      "d": 327800,
      "h": 120259412088,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120259412088),
//--TRIMMABLE-BOUNDARY-START(111669477496),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$1",
      "d": 327800,
      "h": 111669477496,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111669477496),
//--TRIMMABLE-BOUNDARY-START(154619150456),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        }
      ],
      "n": "CreateToken",
      "o": "@$11",
      "d": 327800,
      "h": 154619150456,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(154619150456),
//--TRIMMABLE-BOUNDARY-START(133144313976),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$6",
      "d": 327800,
      "h": 133144313976,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(133144313976),
//--TRIMMABLE-BOUNDARY-START(115964444792),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        }
      ],
      "n": "CreateToken",
      "o": "@$2",
      "d": 327800,
      "h": 115964444792,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(115964444792),
//--TRIMMABLE-BOUNDARY-START(150324183160),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        }
      ],
      "n": "CreateToken",
      "o": "@$10",
      "d": 327800,
      "h": 150324183160,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(150324183160),
//--TRIMMABLE-BOUNDARY-START(141734248568),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "additionalInnerHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$8",
      "d": 327800,
      "h": 141734248568,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(141734248568),
//--TRIMMABLE-BOUNDARY-START(146029215864),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "CreateToken",
      "o": "@$9",
      "d": 327800,
      "h": 146029215864,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(146029215864),
//--TRIMMABLE-BOUNDARY-START(137439281272),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "additionalInnerHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        }
      ],
      "n": "CreateToken",
      "o": "@$7",
      "d": 327800,
      "h": 137439281272,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(137439281272),
//--TRIMMABLE-BOUNDARY-START(124554379384),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "CreateToken",
      "o": "@$4",
      "d": 327800,
      "h": 124554379384,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(124554379384),
//--TRIMMABLE-BOUNDARY-START(597000781944),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "tokenDescriptor",
          "p": 14090359
        },
        {
          "n": "setDefaultTimesOnTokenCreation",
          "p": 262145
        },
        {
          "n": "tokenLifetimeInMinutes",
          "p": 655361
        }
      ],
      "n": "WriteJwsPayload",
      "d": 327800,
      "h": 597000781944,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(597000781944),
//--TRIMMABLE-BOUNDARY-START(38655033464),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "tokenDescriptor",
          "p": 14090359
        },
        {
          "n": "audienceSet",
          "p": 262145
        },
        {
          "n": "issuerSet",
          "p": 262145
        },
        {
          "n": "expSet",
          "p": 262145,
          "f": 4
        },
        {
          "n": "iatSet",
          "p": 262145,
          "f": 4
        },
        {
          "n": "nbfSet",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "AddSubjectClaims",
      "d": 327800,
      "h": 38655033464,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38655033464),
//--TRIMMABLE-BOUNDARY-START(592705814648),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "jweHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "jwsHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": "WriteJwsHeader",
      "o": "@$1",
      "d": 327800,
      "h": 592705814648,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(592705814648),
//--TRIMMABLE-BOUNDARY-START(588410847352),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "WriteJwsHeader",
      "d": 327800,
      "h": 588410847352,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(588410847352),
//--TRIMMABLE-BOUNDARY-START(579820912760),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "jweHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": "WriteJweHeader",
      "d": 327800,
      "h": 579820912760,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(579820912760),
//--TRIMMABLE-BOUNDARY-START(584115880056),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "WriteJweHeader",
      "o": "@$1",
      "d": 327800,
      "h": 584115880056,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(584115880056),
//--TRIMMABLE-BOUNDARY-START(558346076280),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "WriteActor",
      "d": 327800,
      "h": 558346076280,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(558346076280),
//--TRIMMABLE-BOUNDARY-START(571230978168),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "actor",
          "p": 262213
        },
        {
          "n": "remainingActorLevels",
          "p": 655361
        }
      ],
      "n": "WriteActorValue",
      "d": 327800,
      "h": 571230978168,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(571230978168),
//--TRIMMABLE-BOUNDARY-START(566936010872),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "actor",
          "p": 262213
        },
        {
          "n": "remainingActorLevels",
          "p": 655361
        }
      ],
      "n": "WriteActorObject",
      "d": 327800,
      "h": 566936010872,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(566936010872),
//--TRIMMABLE-BOUNDARY-START(575525945464),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276,
          "f": 4
        },
        {
          "n": "identity",
          "p": 262213
        }
      ],
      "n": "WriteIdentityClaims",
      "d": 327800,
      "h": 575525945464,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(575525945464),
//--TRIMMABLE-BOUNDARY-START(283468169336),
    {
      "r": 262213,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "GetActorIdentity",
      "d": 327800,
      "h": 283468169336,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(283468169336),
//--TRIMMABLE-BOUNDARY-START(562641043576),
    {
      "r": 1310721,
      "p": [
        {
          "n": "actor",
          "p": 262213
        }
      ],
      "n": "WriteActorAsJsonString",
      "d": 327800,
      "h": 562641043576,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(562641043576),
//--TRIMMABLE-BOUNDARY-START(55834902648),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "utf8Bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        }
      ],
      "n": "CompressToken",
      "d": 327800,
      "h": 55834902648,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55834902648),
//--TRIMMABLE-BOUNDARY-START(223338627192),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        }
      ],
      "n": "EncryptToken",
      "o": "@$5",
      "d": 327800,
      "h": 223338627192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223338627192),
//--TRIMMABLE-BOUNDARY-START(210453725304),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "EncryptToken",
      "o": "@$2",
      "d": 327800,
      "h": 210453725304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210453725304),
//--TRIMMABLE-BOUNDARY-START(219043659896),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "algorithm",
          "p": 1310721
        }
      ],
      "n": "EncryptToken",
      "o": "@$4",
      "d": 327800,
      "h": 219043659896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219043659896),
//--TRIMMABLE-BOUNDARY-START(214748692600),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "algorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "EncryptToken",
      "o": "@$3",
      "d": 327800,
      "h": 214748692600,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214748692600),
//--TRIMMABLE-BOUNDARY-START(227633594488),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerJwt",
          "p": 1310721
        },
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "EncryptTokenPrivate",
      "d": 327800,
      "h": 227633594488,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(227633594488),
//--TRIMMABLE-BOUNDARY-START(201863790712),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerTokenUtf8Bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "compressionAlgorithm",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": "EncryptToken",
      "d": 327800,
      "h": 201863790712,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(201863790712),
//--TRIMMABLE-BOUNDARY-START(206158758008),
    {
      "r": 1310721,
      "p": [
        {
          "n": "innerTokenUtf8Bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "EncryptToken",
      "o": "@$1",
      "d": 327800,
      "h": 206158758008,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(206158758008),
//--TRIMMABLE-BOUNDARY-START(296353071224),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 262264
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "GetContentEncryptionKeys",
      "o": "@$1",
      "d": 327800,
      "h": 296353071224,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(296353071224)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295096),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "_inboundClaimTypeMap",
      "d": 327800,
      "h": 4295295096,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295096),
//--TRIMMABLE-BOUNDARY-START(12885229688),
    {
      "t": 1310721,
      "n": "_namespace",
      "d": 327800,
      "h": 12885229688,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885229688),
//--TRIMMABLE-BOUNDARY-START(17180196984),
    {
      "t": 1310721,
      "n": "_shortClaimType",
      "d": 327800,
      "h": 17180196984,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180196984),
//--TRIMMABLE-BOUNDARY-START(8590262392),
    {
      "t": 262145,
      "n": "_mapInboundClaims",
      "d": 327800,
      "h": 8590262392,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262392),
//--TRIMMABLE-BOUNDARY-START(193273856120),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "DefaultInboundClaimTypeMap",
      "d": 327800,
      "h": 193273856120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193273856120),
//--TRIMMABLE-BOUNDARY-START(197568823416),
    {
      "t": 262145,
      "n": "DefaultMapInboundClaims",
      "d": 327800,
      "h": 197568823416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197568823416),
//--TRIMMABLE-BOUNDARY-START(42950000760),
    {
      "t": 1310721,
      "n": "Base64UrlEncodedUnsignedJWSHeader",
      "d": 327800,
      "h": 42950000760,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950000760),
//--TRIMMABLE-BOUNDARY-START(442381959288),
    {
      "t": 196727,
      "n": "TelemetryClient",
      "d": 327800,
      "h": 442381959288,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(442381959288),
//--TRIMMABLE-BOUNDARY-START(395137319032),
    {
      "t": 14090359,
      "n": "s_emptyTokenDescriptor",
      "d": 327800,
      "h": 395137319032,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(395137319032),
//--TRIMMABLE-BOUNDARY-START(34360066168),
    {
      "t": 1310721,
      "n": "ActClaimType",
      "d": 327800,
      "h": 34360066168,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360066168),
//--TRIMMABLE-BOUNDARY-START(399432286328),
    {
      "t": 655361,
      "n": "s_maxActorChainLength",
      "d": 327800,
      "h": 399432286328,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(399432286328)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065098872),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327800,
      "h": 30065098872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098872)
  ],
  "i": [5963895
  ],
  "j": [393336
  ],
  "h": 327800
}; }
            static get $b() { return $.$mit.Microsoft.IdentityModel.Tokens.TokenHandler; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mit.Microsoft.IdentityModel.Tokens.Experimental.IResultBasedValidation ]; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327800)
        
        
        //--TRIMMABLE-BOUNDARY-START(262264)
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken", ($self) => class JsonWebToken extends $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken
        {
            //--TRIMMABLE-BOUNDARY-START(283468103800)
            /*int*/ static AverageJsonClaimLengthInBytes = 32;
            //--TRIMMABLE-BOUNDARY-END(283468103800)
            
            //--TRIMMABLE-BOUNDARY-START(326417776760)
            /*JsonClaimSet */ CreatePayloadClaimSet(/*byte[]*/ bytes, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417776760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreatePayloadClaimSet$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, 0, length)));
            }
            //--TRIMMABLE-BOUNDARY-END(326417776760)
            
            //--TRIMMABLE-BOUNDARY-START(330712744056)
            /*JsonClaimSet */ CreatePayloadClaimSet$1(/*ReadOnlySpan<byte>*/ byteSpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712744056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (byteSpan.Length === 0)
                {
                    return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet().$ctor$2((() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                        return $t1;
                    })());
                }
                /*Utf8JsonReader*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4(byteSpan, new $.$stj.System.Text.Json.JsonReaderOptions());
                if (!$.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Tokens.LogMessages.IDX11023*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.System.Text.Json.JsonTokenType)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.System.Int64)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.System.Int64)) ], null, null))));
                }
                /*Dictionary<string, object>*/ let claims = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$8($.trunc(byteSpan.Length / 32/*AverageJsonClaimLengthInBytes*/));
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        this.ReadPayloadValue($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), claims);
                    }
                    else if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 2/*JsonTokenType.EndObject*/, false))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet().$ctor$2(claims);
            }
            //--TRIMMABLE-BOUNDARY-END(330712744056)
            
            //--TRIMMABLE-BOUNDARY-START(893353459832)
            /*void */ ReadPayloadValue(/*ref Utf8JsonReader*/ reader, /*IDictionary<string, object>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(893353459832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud))
                {
                    /*List<string>*/ let _audiences = (() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                        return $t1;
                    })();
                    reader.$v.Read();
                    if (reader.$v.TokenType === 3/*JsonTokenType.StartArray*/)
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadStringsSkipNulls(reader, _audiences, "aud"/*JwtRegisteredClaimNames.Aud*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/);
                        claims.System$Collections$Generic$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences, [$.$$.System.String, $.$$.System.Object]);
                    }
                    else 
                    {
                        if (reader.$v.TokenType !== 11/*JsonTokenType.Null*/)
                        {
                            _audiences.Add($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "aud"/*JwtRegisteredClaimNames.Aud*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, false));
                            claims.System$Collections$Generic$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences.get_Item(0), [$.$$.System.String, $.$$.System.Object]);
                        }
                        else 
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences, [$.$$.System.String, $.$$.System.Object]);
                        }
                    }
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Azp))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("azp"/*JwtRegisteredClaimNames.Azp*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "azp"/*JwtRegisteredClaimNames.Azp*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Exp))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong(reader, "exp"/*JwtRegisteredClaimNames.Exp*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.System.Int64), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iat))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong(reader, "iat"/*JwtRegisteredClaimNames.Iat*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.System.Int64), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iss))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "iss"/*JwtRegisteredClaimNames.Iss*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Jti))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("jti"/*JwtRegisteredClaimNames.Jti*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "jti"/*JwtRegisteredClaimNames.Jti*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Nbf))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong(reader, "nbf"/*JwtRegisteredClaimNames.Nbf*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.System.Int64), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Sub))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("sub"/*JwtRegisteredClaimNames.Sub*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadStringOrNumberAsString(reader, "sub"/*JwtRegisteredClaimNames.Sub*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else 
                {
                    /*string*/ let claimName = reader.$v.GetString();
                    if (this.TryReadJwtClaim !== null)
                    {
                        reader.$v.Read();
                        /*object*/ let claimValue;
                        if (this.TryReadJwtClaim.Invoke(reader, 1/*JwtSegmentType.Payload*/, claimName, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.System.Object)))
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, claimValue, [$.$$.System.String, $.$$.System.Object]);
                            reader.$v.Read();
                        }
                        else 
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, false), [$.$$.System.String, $.$$.System.Object]);
                        }
                    }
                    else 
                    {
                        claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(893353459832)
            
            //--TRIMMABLE-BOUNDARY-START(317827842168)
            /*JsonClaimSet */ CreateHeaderClaimSet$1(/*byte[]*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827842168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateHeaderClaimSet$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Byte, bytes)));
            }
            //--TRIMMABLE-BOUNDARY-END(317827842168)
            
            //--TRIMMABLE-BOUNDARY-START(313532874872)
            /*JsonClaimSet */ CreateHeaderClaimSet(/*byte[]*/ bytes, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532874872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateHeaderClaimSet$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, 0, length)));
            }
            //--TRIMMABLE-BOUNDARY-END(313532874872)
            
            //--TRIMMABLE-BOUNDARY-START(322122809464)
            /*JsonClaimSet */ CreateHeaderClaimSet$2(/*ReadOnlySpan<byte>*/ byteSpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122809464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Utf8JsonReader*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4(byteSpan, new $.$stj.System.Text.Json.JsonReaderOptions());
                if (!$.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Tokens.LogMessages.IDX11023*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.System.Text.Json.JsonTokenType)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.System.Int64)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.System.Int64)) ], null, null))));
                }
                /*Dictionary<string, object>*/ let claims = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$8($.trunc(byteSpan.Length / 32/*AverageJsonClaimLengthInBytes*/));
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        this.ReadHeaderValue($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), claims);
                    }
                    else if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 2/*JsonTokenType.EndObject*/, false))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet().$ctor$2(claims);
            }
            //--TRIMMABLE-BOUNDARY-END(322122809464)
            
            //--TRIMMABLE-BOUNDARY-START(889058492536)
            /*void */ ReadHeaderValue(/*ref Utf8JsonReader*/ reader, /*IDictionary<string, object>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(889058492536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Alg))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("alg"/*JwtHeaderParameterNames.Alg*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "alg"/*JwtHeaderParameterNames.Alg*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Cty))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("cty"/*JwtHeaderParameterNames.Cty*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "cty"/*JwtHeaderParameterNames.Cty*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Kid))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("kid"/*JwtHeaderParameterNames.Kid*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "kid"/*JwtHeaderParameterNames.Kid*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Typ))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("typ"/*JwtHeaderParameterNames.Typ*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "typ"/*JwtHeaderParameterNames.Typ*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.X5t))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("x5t"/*JwtHeaderParameterNames.X5t*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "x5t"/*JwtHeaderParameterNames.X5t*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Zip))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("zip"/*JwtHeaderParameterNames.Zip*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "zip"/*JwtHeaderParameterNames.Zip*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else 
                {
                    /*string*/ let claimName = reader.$v.GetString();
                    if (this.TryReadJwtClaim !== null)
                    {
                        reader.$v.Read();
                        /*object*/ let claimValue;
                        if (this.TryReadJwtClaim.Invoke(reader, 0/*JwtSegmentType.Header*/, claimName, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.System.Object)))
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, claimValue, [$.$$.System.String, $.$$.System.Object]);
                            reader.$v.Read();
                        }
                        else 
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, false), [$.$$.System.String, $.$$.System.Object]);
                        }
                    }
                    else 
                    {
                        claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(889058492536)
            
            //--TRIMMABLE-BOUNDARY-START(304942940280)
            /*string*/ static ClassName = null;
            //--TRIMMABLE-BOUNDARY-END(304942940280)
            
            //--TRIMMABLE-BOUNDARY-START(4295229560)
            /*string*/ _act = null;
            //--TRIMMABLE-BOUNDARY-END(4295229560)
            
            //--TRIMMABLE-BOUNDARY-START(17180131448)
            /*string*/ _authenticationTag = null;
            //--TRIMMABLE-BOUNDARY-END(17180131448)
            
            //--TRIMMABLE-BOUNDARY-START(25770066040)
            /*string*/ _ciphertext = null;
            //--TRIMMABLE-BOUNDARY-END(25770066040)
            
            //--TRIMMABLE-BOUNDARY-START(38654967928)
            /*string*/ _encodedHeader = null;
            //--TRIMMABLE-BOUNDARY-END(38654967928)
            
            //--TRIMMABLE-BOUNDARY-START(42949935224)
            /*string*/ _encodedPayload = null;
            //--TRIMMABLE-BOUNDARY-END(42949935224)
            
            //--TRIMMABLE-BOUNDARY-START(47244902520)
            /*string*/ _encodedSignature = null;
            //--TRIMMABLE-BOUNDARY-END(47244902520)
            
            //--TRIMMABLE-BOUNDARY-START(51539869816)
            /*string*/ _encodedToken = null;
            //--TRIMMABLE-BOUNDARY-END(51539869816)
            
            //--TRIMMABLE-BOUNDARY-START(60129804408)
            /*string*/ _encryptedKey = null;
            //--TRIMMABLE-BOUNDARY-END(60129804408)
            
            //--TRIMMABLE-BOUNDARY-START(85899608184)
            /*string*/ _initializationVector = null;
            //--TRIMMABLE-BOUNDARY-END(85899608184)
            
            //--TRIMMABLE-BOUNDARY-START(12885164152)
            /*List<string>*/ _audiences = null;
            //--TRIMMABLE-BOUNDARY-END(12885164152)
            
            //--TRIMMABLE-BOUNDARY-START(55834837112)
            /*ReadOnlyMemory<char>*/ _encodedTokenMemory;
            //--TRIMMABLE-BOUNDARY-END(55834837112)
            
            //--TRIMMABLE-BOUNDARY-START(8590196856)
            /*string*/ _alg = null;
            //--TRIMMABLE-BOUNDARY-END(8590196856)
            
            //--TRIMMABLE-BOUNDARY-START(30065033336)
            /*string*/ _cty = null;
            //--TRIMMABLE-BOUNDARY-END(30065033336)
            
            //--TRIMMABLE-BOUNDARY-START(34360000632)
            /*string*/ _enc = null;
            //--TRIMMABLE-BOUNDARY-END(34360000632)
            
            //--TRIMMABLE-BOUNDARY-START(98784510072)
            /*string*/ _kid = null;
            //--TRIMMABLE-BOUNDARY-END(98784510072)
            
            //--TRIMMABLE-BOUNDARY-START(115964379256)
            /*string*/ _typ = null;
            //--TRIMMABLE-BOUNDARY-END(115964379256)
            
            //--TRIMMABLE-BOUNDARY-START(128849281144)
            /*string*/ _x5t = null;
            //--TRIMMABLE-BOUNDARY-END(128849281144)
            
            //--TRIMMABLE-BOUNDARY-START(133144248440)
            /*string*/ _zip = null;
            //--TRIMMABLE-BOUNDARY-END(133144248440)
            
            //--TRIMMABLE-BOUNDARY-START(21475098744)
            /*string*/ _azp = null;
            //--TRIMMABLE-BOUNDARY-END(21475098744)
            
            //--TRIMMABLE-BOUNDARY-START(64424771704)
            /*long?*/ _exp = null;
            //--TRIMMABLE-BOUNDARY-END(64424771704)
            
            //--TRIMMABLE-BOUNDARY-START(68719739000)
            /*DateTime?*/ _expDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(68719739000)
            
            //--TRIMMABLE-BOUNDARY-START(73014706296)
            /*long?*/ _iat = null;
            //--TRIMMABLE-BOUNDARY-END(73014706296)
            
            //--TRIMMABLE-BOUNDARY-START(77309673592)
            /*DateTime?*/ _iatDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(77309673592)
            
            //--TRIMMABLE-BOUNDARY-START(81604640888)
            /*string*/ _id = null;
            //--TRIMMABLE-BOUNDARY-END(81604640888)
            
            //--TRIMMABLE-BOUNDARY-START(90194575480)
            /*string*/ _iss = null;
            //--TRIMMABLE-BOUNDARY-END(90194575480)
            
            //--TRIMMABLE-BOUNDARY-START(94489542776)
            /*string*/ _jti = null;
            //--TRIMMABLE-BOUNDARY-END(94489542776)
            
            //--TRIMMABLE-BOUNDARY-START(111669411960)
            /*string*/ _sub = null;
            //--TRIMMABLE-BOUNDARY-END(111669411960)
            
            //--TRIMMABLE-BOUNDARY-START(103079477368)
            /*long?*/ _nbf = null;
            //--TRIMMABLE-BOUNDARY-END(103079477368)
            
            //--TRIMMABLE-BOUNDARY-START(107374444664)
            /*DateTime?*/ _nbfDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(107374444664)
            
            //--TRIMMABLE-BOUNDARY-START(120259346552)
            /*DateTime?*/ _validFrom = null;
            //--TRIMMABLE-BOUNDARY-END(120259346552)
            
            //--TRIMMABLE-BOUNDARY-START(124554313848)
            /*DateTime?*/ _validTo = null;
            //--TRIMMABLE-BOUNDARY-END(124554313848)
            
            //--TRIMMABLE-BOUNDARY-START(244813398136)
            $ctor$7(/*string*/ jwtEncodedString)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244813398136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrEmpty(jwtEncodedString))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("jwtEncodedString"));
                    }
                    this.ReadToken($.$$.System.MemoryExtensions.AsMemory$4(jwtEncodedString));
                    this._encodedToken = jwtEncodedString;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(244813398136)
            
            //--TRIMMABLE-BOUNDARY-START(240518430840)
            $ctor$6(/*string*/ jwtEncodedString, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240518430840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrEmpty(jwtEncodedString))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("jwtEncodedString"));
                    }
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken($.$$.System.MemoryExtensions.AsMemory$4(jwtEncodedString));
                    this._encodedToken = jwtEncodedString;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(240518430840)
            
            //--TRIMMABLE-BOUNDARY-START(227633528952)
            $ctor$3(/*ReadOnlyMemory<char>*/ encodedTokenMemory)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633528952);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (encodedTokenMemory.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("encodedTokenMemory"));
                    }
                    this.ReadToken(encodedTokenMemory);
                    this._encodedTokenMemory = encodedTokenMemory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(227633528952)
            
            //--TRIMMABLE-BOUNDARY-START(223338561656)
            $ctor$2(/*ReadOnlyMemory<char>*/ encodedTokenMemory, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(223338561656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (encodedTokenMemory.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("encodedTokenMemory"));
                    }
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken(encodedTokenMemory);
                    this._encodedTokenMemory = encodedTokenMemory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(223338561656)
            
            //--TRIMMABLE-BOUNDARY-START(236223463544)
            $ctor$5(/*string*/ header, /*string*/ payload)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236223463544);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrEmpty(header))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                    /*var*/ let encodedHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(header);
                    /*var*/ let encodedPayload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(payload);
                    /*var*/ let encodedToken = encodedHeader + "." + encodedPayload + ".";
                    this.ReadToken($.$$.System.MemoryExtensions.AsMemory$4(encodedToken));
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(236223463544)
            
            //--TRIMMABLE-BOUNDARY-START(231928496248)
            $ctor$4(/*string*/ header, /*string*/ payload, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231928496248);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrEmpty(header))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                    /*var*/ let encodedHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(header);
                    /*var*/ let encodedPayload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(payload);
                    /*var*/ let encodedToken = encodedHeader + "." + encodedPayload + ".";
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken($.$$.System.MemoryExtensions.AsMemory$4(encodedToken));
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(231928496248)
            
            //--TRIMMABLE-BOUNDARY-START(249108365432)
            $ctor$8(/*JsonWebToken*/ jsonWebToken, /*string*/ encodedHeader)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249108365432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = $.$firstOf(jsonWebToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jsonWebToken") });
                    if ($.$$.System.String.IsNullOrEmpty(encodedHeader))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encodedHeader");
                    }
                    if (jsonWebToken.IsEncrypted)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$13("IDX14117: Cannot create a 'JsonWebToken' with a replaced header from an encrypted (JWE) token. The provided token must be a JWS so that its decoded payload can be reused."/*LogMessages.IDX14117*/, "jsonWebToken"));
                    }
                    /*string*/ let encodedPayload = jsonWebToken.EncodedPayload;
                    /*string*/ let encodedSignature = jsonWebToken.EncodedSignature;
                    /*int*/ let totalLength = ((((((((encodedHeader.length + 1) | 0) + encodedPayload.length) | 0) + 1) | 0) + encodedSignature.length) | 0);
                    /*string*/ let encodedToken = $.$$.System.String.Create$10($.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String), totalLength, new ($.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor$3(encodedHeader, encodedPayload, encodedSignature), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String)))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken, /*static*/ (/**/ span, /*state*/ state) =>
                    {
                        /*var*/ let  [ header, payload, signature ] = $.$destructure(state);
                        $.$$.System.MemoryExtensions.AsSpan$4(header).CopyTo(span);
                        /*int*/ let pos = header.length;
                        span.get_Item(pos++).$v = /*.*/ 46;
                        $.$$.System.MemoryExtensions.AsSpan$4(payload).CopyTo(span.Slice$1(pos));
                        pos += payload.length;
                        span.get_Item(pos++).$v = /*.*/ 46;
                        $.$$.System.MemoryExtensions.AsSpan$4(signature).CopyTo(span.Slice$1(pos));
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "span",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "state",
      "p": $.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String).$h
    }
  ],
  "n": "",
  "d": 262264,
  "h": 0,
  "f": 17825826
}));
                    this.Dot1 = encodedHeader.length;
                    this.Dot2 = ((((this.Dot1 + 1) | 0) + encodedPayload.length) | 0);
                    this.Dot3 = -1;
                    this.IsSigned = encodedSignature.length > 0;
                    this.Header = this.CreateClaimSet($.$$.System.MemoryExtensions.AsSpan$4(encodedToken), 0, this.Dot1, true);
                    this.Payload = jsonWebToken.Payload;
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(249108365432)
            
            //--TRIMMABLE-BOUNDARY-START(1108101824632)
            /*TryReadJwtClaim*/ TryReadJwtClaim = null;
            //--TRIMMABLE-BOUNDARY-END(1108101824632)
            
            //--TRIMMABLE-BOUNDARY-START(261993267320)
            /*string*/ ActualIssuer = null;
            //--TRIMMABLE-BOUNDARY-END(261993267320)
            
            //--TRIMMABLE-BOUNDARY-START(257698300024)
            /*ClaimsIdentity*/ ActorClaimsIdentity = null;
            //--TRIMMABLE-BOUNDARY-END(257698300024)
            
            //--TRIMMABLE-BOUNDARY-START(274878169208)
            /*string */ get AuthenticationTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433791959160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._authenticationTag ??= this.AuthenticationTagBytes === null ? $.$$.System.String.Empty : $.$$.System.Text.Encoding.UTF8.GetString$1(this.AuthenticationTagBytes);
                return this._authenticationTag;
            }
            //--TRIMMABLE-BOUNDARY-END(274878169208)
            
            //--TRIMMABLE-BOUNDARY-START(279173136504)
            /*byte[]*/ AuthenticationTagBytes = null;
            //--TRIMMABLE-BOUNDARY-END(279173136504)
            
            //--TRIMMABLE-BOUNDARY-START(292058038392)
            /*string */ get Ciphertext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459561762936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._ciphertext ??= this.CipherTextBytes === null ? $.$$.System.String.Empty : $.$$.System.Text.Encoding.UTF8.GetString$1(this.CipherTextBytes);
                return this._ciphertext;
            }
            //--TRIMMABLE-BOUNDARY-END(292058038392)
            
            //--TRIMMABLE-BOUNDARY-START(296353005688)
            /*byte[]*/ CipherTextBytes = null;
            //--TRIMMABLE-BOUNDARY-END(296353005688)
            
            //--TRIMMABLE-BOUNDARY-START(339302678648)
            /*int*/ Dot1 = 0;
            //--TRIMMABLE-BOUNDARY-END(339302678648)
            
            //--TRIMMABLE-BOUNDARY-START(343597645944)
            /*int*/ Dot2 = 0;
            //--TRIMMABLE-BOUNDARY-END(343597645944)
            
            //--TRIMMABLE-BOUNDARY-START(347892613240)
            /*int*/ Dot3 = 0;
            //--TRIMMABLE-BOUNDARY-END(347892613240)
            
            //--TRIMMABLE-BOUNDARY-START(352187580536)
            /*int*/ Dot4 = 0;
            //--TRIMMABLE-BOUNDARY-END(352187580536)
            
            //--TRIMMABLE-BOUNDARY-START(360777515128)
            /*string */ get EncodedHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871174264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._encodedHeader, null))
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedHeader = $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(this._encodedTokenMemory.Span.Slice(0, this.Dot1));
                    }
                    else 
                    {
                        this._encodedHeader = (!(this._encodedToken === null)) ? $.$$.System.String.Substring.call(this._encodedToken, 0, this.Dot1) : $.$$.System.String.Empty;
                    }
                }
                return this._encodedHeader;
            }
            //--TRIMMABLE-BOUNDARY-END(360777515128)
            
            //--TRIMMABLE-BOUNDARY-START(377957384312)
            /*string */ get EncryptedKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571230912632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._encryptedKey, null))
                {
                    this._encryptedKey = this.EncryptedKeyBytes === null ? $.$$.System.String.Empty : $.$$.System.Text.Encoding.UTF8.GetString$1(this.EncryptedKeyBytes);
                }
                return this._encryptedKey;
            }
            //--TRIMMABLE-BOUNDARY-END(377957384312)
            
            //--TRIMMABLE-BOUNDARY-START(382252351608)
            /*byte[]*/ EncryptedKeyBytes = null;
            //--TRIMMABLE-BOUNDARY-END(382252351608)
            
            //--TRIMMABLE-BOUNDARY-START(365072482424)
            /*string */ get EncodedPayload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461108856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._encodedPayload, null))
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedPayload = this.IsEncrypted ? $.$$.System.String.Empty : $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(this._encodedTokenMemory.Span.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0)));
                    }
                    else 
                    {
                        if (!(this._encodedToken === null))
                        {
                            this._encodedPayload = this.IsEncrypted ? $.$$.System.String.Empty : $.$$.System.String.Substring.call(this._encodedToken, ((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0));
                        }
                        else 
                        {
                            this._encodedPayload = $.$$.System.String.Empty;
                        }
                    }
                }
                return this._encodedPayload;
            }
            //--TRIMMABLE-BOUNDARY-END(365072482424)
            
            //--TRIMMABLE-BOUNDARY-START(369367449720)
            /*string */ get EncodedSignature()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051043448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._encodedSignature, null))
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedSignature = this.IsEncrypted ? $.$$.System.String.Empty : $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(this._encodedTokenMemory.Span.Slice(((this.Dot2 + 1) | 0), ((((this._encodedTokenMemory.Length - this.Dot2) | 0) - 1) | 0)));
                    }
                    else 
                    {
                        if (!(this._encodedToken === null))
                        {
                            this._encodedSignature = this.IsEncrypted ? $.$$.System.String.Empty : $.$$.System.String.Substring.call(this._encodedToken, ((this.Dot2 + 1) | 0), ((((this._encodedToken.length - this.Dot2) | 0) - 1) | 0));
                        }
                        else 
                        {
                            this._encodedSignature = $.$$.System.String.Empty;
                        }
                    }
                }
                return this._encodedSignature;
            }
            //--TRIMMABLE-BOUNDARY-END(369367449720)
            
            //--TRIMMABLE-BOUNDARY-START(373662417016)
            /*string */ get EncodedToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562640978040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encodedToken === null && !this._encodedTokenMemory.IsEmpty)
                {
                    this._encodedToken = $.$$.System.ReadOnlyMemory$$($.$$.System.Char).ToString.call(this._encodedTokenMemory);
                }
                return this._encodedToken;
            }
            //--TRIMMABLE-BOUNDARY-END(373662417016)
            
            //--TRIMMABLE-BOUNDARY-START(824633983096)
            /*JsonClaimSet*/ Header = null;
            //--TRIMMABLE-BOUNDARY-END(824633983096)
            
            //--TRIMMABLE-BOUNDARY-START(828928950392)
            /*byte[]*/ HeaderAsciiBytes = null;
            //--TRIMMABLE-BOUNDARY-END(828928950392)
            
            //--TRIMMABLE-BOUNDARY-START(841813852280)
            /*byte[]*/ InitializationVectorBytes = null;
            //--TRIMMABLE-BOUNDARY-END(841813852280)
            
            //--TRIMMABLE-BOUNDARY-START(837518884984)
            /*string */ get InitializationVector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614180585592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.InitializationVectorBytes === null)
                {
                    this._initializationVector = this.InitializationVectorBytes === null ? $.$$.System.String.Empty : $.$$.System.Text.Encoding.UTF8.GetString$1(this.InitializationVectorBytes);
                }
                return this._initializationVector;
            }
            //--TRIMMABLE-BOUNDARY-END(837518884984)
            
            //--TRIMMABLE-BOUNDARY-START(846108819576)
            /*JsonWebToken*/ InnerToken = null;
            //--TRIMMABLE-BOUNDARY-END(846108819576)
            
            //--TRIMMABLE-BOUNDARY-START(850403786872)
            /*bool */ get IsEncrypted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639950389368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CipherTextBytes !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(850403786872)
            
            //--TRIMMABLE-BOUNDARY-START(854698754168)
            /*bool*/ IsSigned = false;
            //--TRIMMABLE-BOUNDARY-END(854698754168)
            
            //--TRIMMABLE-BOUNDARY-START(880468557944)
            /*JsonClaimSet*/ Payload = null;
            //--TRIMMABLE-BOUNDARY-END(880468557944)
            
            //--TRIMMABLE-BOUNDARY-START(901943394424)
            /*SecurityKey*/ SecurityKey = null;
            //--TRIMMABLE-BOUNDARY-END(901943394424)
            
            //--TRIMMABLE-BOUNDARY-START(1078037053560)
            /*SecurityKey*/ SigningKey = null;
            //--TRIMMABLE-BOUNDARY-END(1078037053560)
            
            //--TRIMMABLE-BOUNDARY-START(871878623352)
            /*byte[]*/ MessageBytes = null;
            //--TRIMMABLE-BOUNDARY-END(871878623352)
            
            //--TRIMMABLE-BOUNDARY-START(876173590648)
            /*int*/ NumberOfDots = 0;
            //--TRIMMABLE-BOUNDARY-END(876173590648)
            
            //--TRIMMABLE-BOUNDARY-START(897648427128)
            /*void */ ReadToken(/*ReadOnlyMemory<char>*/ encodedTokenMemory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(897648427128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let encodedTokenSpan = encodedTokenMemory.Span;
                this.Dot1 = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan, /*.*/ 46);
                if (this.Dot1 === -1 || this.Dot1 === ((encodedTokenSpan.Length - 1) | 0))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14100: JWT is not well formed, there are no dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14100*/));
                }
                this.Dot2 = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan.Slice$1(((this.Dot1 + 1) | 0)), /*.*/ 46);
                if (this.Dot2 === -1)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14120: JWT is not well formed, there is only one dot (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14120*/));
                }
                this.Dot2 = ((((this.Dot1 + this.Dot2) | 0) + 1) | 0);
                this.Dot3 = (this.Dot2 === ((encodedTokenSpan.Length - 1) | 0)) ? -1 : $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan.Slice$1(((this.Dot2 + 1) | 0)), /*.*/ 46);
                if (this.Dot3 === -1)
                {
                    this.IsSigned = !(((this.Dot2 + 1) | 0) === encodedTokenSpan.Length);
                    try
                    {
                        this.Header = this.CreateClaimSet(encodedTokenSpan, 0, this.Dot1, true);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14102: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX14102*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsUnsafeSecurityArtifact($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(encodedTokenSpan.Slice(0, this.Dot1)), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$$.System.Object.ToString.call(t);
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "t",
      "p": 131073
    }
  ],
  "n": "",
  "d": 262264,
  "h": 0,
  "f": 17825794
})) ], null, null)), ex));
                    }
                    try
                    {
                        this.Payload = this.CreateClaimSet(encodedTokenSpan, ((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0), false);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14101: Unable to decode the payload '{0}' as Base64Url encoded string."/*LogMessages.IDX14101*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsUnsafeSecurityArtifact($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(encodedTokenSpan.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0))), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$$.System.Object.ToString.call(t);
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "t",
      "p": 131073
    }
  ],
  "n": "",
  "d": 262264,
  "h": 0,
  "f": 17825794
})) ], null, null)), ex));
                    }
                }
                else 
                {
                    this.Payload = new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet().$ctor$1();
                    this.Dot3 = ((((this.Dot2 + this.Dot3) | 0) + 1) | 0);
                    if (this.Dot3 === ((encodedTokenSpan.Length - 1) | 0))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14121*/));
                    }
                    this.Dot4 = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan.Slice$1(((this.Dot3 + 1) | 0)), /*.*/ 46);
                    if (this.Dot4 === -1)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14121*/));
                    }
                    this.Dot4 = ((((this.Dot3 + this.Dot4) | 0) + 1) | 0);
                    if (this.Dot4 === ((encodedTokenSpan.Length - 1) | 0))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14310: JWE authentication tag is missing."/*LogMessages.IDX14310*/));
                    }
                    if ($.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan.Slice$1(((this.Dot4 + 1) | 0)), /*.*/ 46) !== -1)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14122: JWT is not a well formed JWE, there are more than four dots (.) a JWE can have at most 4 dots.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14122*/));
                    }
                    /*ReadOnlySpan<char>*/ let headerSpan = encodedTokenSpan.Slice(0, this.Dot1);
                    if (headerSpan.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX14307: JWE header is missing."/*LogMessages.IDX14307*/));
                    }
                    /*byte[]*/ let headerAsciiBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [headerSpan.Length], null);
                    $.$$.System.Text.Encoding.ASCII.GetBytes$5(headerSpan, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(headerAsciiBytes));
                    this.HeaderAsciiBytes = headerAsciiBytes;
                    try
                    {
                        this.Header = this.CreateHeaderClaimSet$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Byte, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(headerSpan))));
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14102: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX14102*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsUnsafeSecurityArtifact($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(headerSpan), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$$.System.Object.ToString.call(t);
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "t",
      "p": 131073
    }
  ],
  "n": "",
  "d": 262264,
  "h": 0,
  "f": 17825794
})) ], null, null)), ex));
                    }
                    /*ReadOnlySpan<char>*/ let encryptedKeyBytes = encodedTokenSpan.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0));
                    if (!encryptedKeyBytes.IsEmpty)
                    {
                        this.EncryptedKeyBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(encryptedKeyBytes);
                        this._encryptedKey = $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(encryptedKeyBytes);
                    }
                    else 
                    {
                        this._encryptedKey = $.$$.System.String.Empty;
                    }
                    /*ReadOnlySpan<char>*/ let initializationVectorSpan = encodedTokenSpan.Slice(((this.Dot2 + 1) | 0), ((((this.Dot3 - this.Dot2) | 0) - 1) | 0));
                    if (initializationVectorSpan.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX14308: JWE initialization vector is missing."/*LogMessages.IDX14308*/));
                    }
                    try
                    {
                        this.InitializationVectorBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(initializationVectorSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11("IDX14309: Unable to decode the initialization vector as Base64Url encoded string."/*LogMessages.IDX14309*/, ex));
                    }
                    /*ReadOnlySpan<char>*/ let authTagSpan = encodedTokenSpan.Slice$1(((this.Dot4 + 1) | 0));
                    if (authTagSpan.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX14310: JWE authentication tag is missing."/*LogMessages.IDX14310*/));
                    }
                    try
                    {
                        this.AuthenticationTagBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(authTagSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11("IDX14311: Unable to decode the authentication tag as a Base64Url encoded string."/*LogMessages.IDX14311*/, ex));
                    }
                    /*ReadOnlySpan<char>*/ let cipherTextSpan = encodedTokenSpan.Slice(((this.Dot3 + 1) | 0), ((((this.Dot4 - this.Dot3) | 0) - 1) | 0));
                    if (cipherTextSpan.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX14306: JWE Ciphertext cannot be an empty string."/*LogMessages.IDX14306*/));
                    }
                    try
                    {
                        this.CipherTextBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(cipherTextSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11("IDX14312: Unable to decode the cipher text as a Base64Url encoded string."/*LogMessages.IDX14312*/, ex));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(897648427128)
            
            //--TRIMMABLE-BOUNDARY-START(309237907576)
            /*JsonClaimSet */ CreateClaimSet(/*ReadOnlySpan<char>*/ strSpan, /*int*/ startIndex, /*int*/ length, /*bool*/ createHeaderClaimSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237907576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let outputSize = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoding.ValidateAndGetOutputSize(strSpan, startIndex, length);
                /*byte[]*/ let rented = null;
                /*int*/ let MaxStackallocThreshold = 256;
                /*Span<byte>*/ let output = outputSize <= MaxStackallocThreshold ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, outputSize, null) : ($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rented = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(outputSize)));
                try
                {
                    $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$1(strSpan.Slice(startIndex, length), output);
                    return createHeaderClaimSet ? this.CreateHeaderClaimSet$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit(output)) : this.CreatePayloadClaimSet$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit(output));
                }
                finally
                {
                    {
                        if (!(rented === null))
                        {
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(rented, true);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309237907576)
            
            //--TRIMMABLE-BOUNDARY-START(1086626988152)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1086626988152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Substring.call(this.EncodedToken, 0, $.$$.System.String.LastIndexOf$2.call(this.EncodedToken, /*.*/ 46));
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(1086626988152)
            
            //--TRIMMABLE-BOUNDARY-START(1116691759224)
            /*string */ UnsafeToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(1116691759224);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.EncodedToken;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1116691759224)
            
            //--TRIMMABLE-BOUNDARY-START(300647972984)
            /*IEnumerable<Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476741632120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payload.Claims(this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/);
            }
            //--TRIMMABLE-BOUNDARY-END(300647972984)
            
            //--TRIMMABLE-BOUNDARY-START(807454113912)
            /*Claim */ GetClaim(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807454113912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payload.GetClaim(key, this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/);
            }
            //--TRIMMABLE-BOUNDARY-END(807454113912)
            
            //--TRIMMABLE-BOUNDARY-START(884763525240)
            /*IReadOnlyCollection<string> */ get PayloadClaimNames()
            {
                return this.Payload._jsonClaims.Keys;
            }
            //--TRIMMABLE-BOUNDARY-END(884763525240)
            
            //--TRIMMABLE-BOUNDARY-START(1090921955448)
            /*bool */ TryGetClaim(/*string*/ key, /*out Claim*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1090921955448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payload.TryGetClaim(key, this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(1090921955448)
            
            //--TRIMMABLE-BOUNDARY-START(820339015800)
            /*bool */ HasPayloadClaim(/*string*/ claimName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(820339015800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payload.HasClaim(claimName);
            }
            //--TRIMMABLE-BOUNDARY-END(820339015800)
            
            //--TRIMMABLE-BOUNDARY-START(811749081208)
            /*T */ GetHeaderValue(T, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811749081208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                }
                return this.Header.GetValue$1(T, key);
            }
            //--TRIMMABLE-BOUNDARY-END(811749081208)
            
            //--TRIMMABLE-BOUNDARY-START(816044048504)
            /*T */ GetPayloadValue(T, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816044048504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                }
                if (T.$type.Equals$2($.$ssc.System.Security.Claims.Claim.$type))
                {
                    return $.$cast(this.GetClaim(key), T);
                }
                return this.Payload.GetValue$1(T, key);
            }
            //--TRIMMABLE-BOUNDARY-END(816044048504)
            
            //--TRIMMABLE-BOUNDARY-START(1103806857336)
            /*bool */ TryGetValue(T, /*string*/ key, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1103806857336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                return this.Payload.TryGetValue(T, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(1103806857336)
            
            //--TRIMMABLE-BOUNDARY-START(1095216922744)
            /*bool */ TryGetHeaderValue(T, /*string*/ key, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1095216922744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                return this.Header.TryGetValue(T, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(1095216922744)
            
            //--TRIMMABLE-BOUNDARY-START(1099511890040)
            /*bool */ TryGetPayloadValue(T, /*string*/ key, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1099511890040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                if (T.$type.Equals$2($.$ssc.System.Security.Claims.Claim.$type))
                {
                    /*var*/ let claim;
                    /*bool*/ let foundClaim = this.TryGetClaim(key, $.$ref(() => claim, ($v) => claim = $v, $.$ssc.System.Security.Claims.Claim));
                    value.$v = $.$cast(claim, T);
                    return foundClaim;
                }
                return this.Payload.TryGetValue(T, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(1099511890040)
            
            //--TRIMMABLE-BOUNDARY-START(266288234616)
            /*string */ get Alg()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612089976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._alg ??= this.Header.GetStringValue("alg"/*JwtHeaderParameterNames.Alg*/);
                return this._alg;
            }
            //--TRIMMABLE-BOUNDARY-END(266288234616)
            
            //--TRIMMABLE-BOUNDARY-START(335007711352)
            /*string */ get Cty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485331566712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._cty ??= this.Header.GetStringValue("cty"/*JwtHeaderParameterNames.Cty*/);
                return this._cty;
            }
            //--TRIMMABLE-BOUNDARY-END(335007711352)
            
            //--TRIMMABLE-BOUNDARY-START(356482547832)
            /*string */ get Enc()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281239672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._enc ??= this.Header.GetStringValue("enc"/*JwtHeaderParameterNames.Enc*/);
                return this._enc;
            }
            //--TRIMMABLE-BOUNDARY-END(356482547832)
            
            //--TRIMMABLE-BOUNDARY-START(867583656056)
            /*string */ get Kid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(674310127736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._kid ??= this.Header.GetStringValue("kid"/*JwtHeaderParameterNames.Kid*/);
                return this._kid;
            }
            //--TRIMMABLE-BOUNDARY-END(867583656056)
            
            //--TRIMMABLE-BOUNDARY-START(1112396791928)
            /*string */ get Typ()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(751619539064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._typ ??= this.Header.GetStringValue("typ"/*JwtHeaderParameterNames.Typ*/);
                return this._typ;
            }
            /*string */ set Typ(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1073742086264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._typ = value;
            }
            //--TRIMMABLE-BOUNDARY-END(1112396791928)
            
            //--TRIMMABLE-BOUNDARY-START(1138166595704)
            /*string */ get X5t()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(794569212024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._x5t ??= this.Header.GetStringValue("x5t"/*JwtHeaderParameterNames.X5t*/);
                return this._x5t;
            }
            //--TRIMMABLE-BOUNDARY-END(1138166595704)
            
            //--TRIMMABLE-BOUNDARY-START(1142461563000)
            /*string */ get Zip()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(803159146616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._zip ??= this.Header.GetStringValue("zip"/*JwtHeaderParameterNames.Zip*/);
                return this._zip;
            }
            //--TRIMMABLE-BOUNDARY-END(1142461563000)
            
            //--TRIMMABLE-BOUNDARY-START(253403332728)
            /*string */ get Actor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842286200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._act ??= this.Payload.GetStringValue("actort"/*JwtRegisteredClaimNames.Actort*/);
                return this._act;
            }
            //--TRIMMABLE-BOUNDARY-END(253403332728)
            
            //--TRIMMABLE-BOUNDARY-START(270583201912)
            /*IEnumerable<string> */ get Audiences()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202024568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._audiences === null)
                {
                    /*List<string>*/ let audiences;
                    /*List<string>*/ let tmp = this.TryGetValue($.$$.System.Collections.Generic.List$$($.$$.System.String), "aud"/*JwtRegisteredClaimNames.Aud*/, $.$ref(() => audiences, ($v) => audiences = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String))) ? audiences : new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Collections.Generic.List$$($.$$.System.String), $.$ref(() => this._audiences, ($v) => this._audiences = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String)), tmp, null);
                }
                return this._audiences;
            }
            //--TRIMMABLE-BOUNDARY-END(270583201912)
            
            //--TRIMMABLE-BOUNDARY-START(287763071096)
            /*string */ get Azp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450971828344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._azp ??= this.Payload.GetStringValue("azp"/*JwtRegisteredClaimNames.Azp*/);
                return this._azp;
            }
            //--TRIMMABLE-BOUNDARY-END(287763071096)
            
            //--TRIMMABLE-BOUNDARY-START(858993721464)
            /*DateTime */ get IssuedAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657130258552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._iatDateTime ??= this.Payload.GetDateTime("iat"/*JwtRegisteredClaimNames.Iat*/);
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._iatDateTime);
            }
            //--TRIMMABLE-BOUNDARY-END(858993721464)
            
            //--TRIMMABLE-BOUNDARY-START(863288688760)
            /*string */ get Issuer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(665720193144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._iss ??= this.Payload.GetStringValue("iss"/*JwtRegisteredClaimNames.Iss*/);
                return this._iss;
            }
            //--TRIMMABLE-BOUNDARY-END(863288688760)
            
            //--TRIMMABLE-BOUNDARY-START(833223917688)
            /*string */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605590651000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._jti ??= this.Payload.GetStringValue("jti"/*JwtRegisteredClaimNames.Jti*/);
                return this._jti;
            }
            //--TRIMMABLE-BOUNDARY-END(833223917688)
            
            //--TRIMMABLE-BOUNDARY-START(1082332020856)
            /*string */ get Subject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(734439669880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._sub ??= this.Payload.GetStringValue("sub"/*JwtRegisteredClaimNames.Sub*/);
                return this._sub;
            }
            //--TRIMMABLE-BOUNDARY-END(1082332020856)
            
            //--TRIMMABLE-BOUNDARY-START(1120986726520)
            /*DateTime */ get ValidFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(760209473656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validFrom ??= this.Payload.GetDateTime("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._validFrom);
            }
            //--TRIMMABLE-BOUNDARY-END(1120986726520)
            
            //--TRIMMABLE-BOUNDARY-START(1125281693816)
            /*DateTime? */ get ValidFromNullable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(768799408248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validFrom ??= this.Payload.GetDateTime("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                return this._validFrom;
            }
            //--TRIMMABLE-BOUNDARY-END(1125281693816)
            
            //--TRIMMABLE-BOUNDARY-START(1129576661112)
            /*DateTime */ get ValidTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(777389342840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validTo ??= this.Payload.GetDateTime("exp"/*JwtRegisteredClaimNames.Exp*/);
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._validTo);
            }
            //--TRIMMABLE-BOUNDARY-END(1129576661112)
            
            //--TRIMMABLE-BOUNDARY-START(1133871628408)
            /*DateTime? */ get ValidToNullable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(785979277432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validTo ??= this.Payload.GetDateTime("exp"/*JwtRegisteredClaimNames.Exp*/);
                return this._validTo;
            }
            //--TRIMMABLE-BOUNDARY-END(1133871628408)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55834837112)
                this._encodedTokenMemory = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                //--TRIMMABLE-BOUNDARY-END(55834837112)
                
                //--TRIMMABLE-BOUNDARY-START(68719739000)
                this._expDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(68719739000)
                
                //--TRIMMABLE-BOUNDARY-START(77309673592)
                this._iatDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(77309673592)
                
                //--TRIMMABLE-BOUNDARY-START(107374444664)
                this._nbfDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(107374444664)
                
                //--TRIMMABLE-BOUNDARY-START(120259346552)
                this._validFrom = null;
                //--TRIMMABLE-BOUNDARY-END(120259346552)
                
                //--TRIMMABLE-BOUNDARY-START(124554313848)
                this._validTo = null;
                //--TRIMMABLE-BOUNDARY-END(124554313848)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(304942940280)
                    this.ClassName = "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken";
                    //--TRIMMABLE-BOUNDARY-END(304942940280)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 262264;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 13762679,
  "p": [
//--TRIMMABLE-BOUNDARY-START(1108101824632),
    {
      "p": 16973943,
      "g": {
        "r": 0,
        "d": 0,
        "h": 743029604472,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1065152151672,
        "f": 83886082
      },
      "n": "TryReadJwtClaim",
      "d": 262264,
      "h": 1108101824632,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(1108101824632),
//--TRIMMABLE-BOUNDARY-START(261993267320),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408022155384,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 919123263608,
        "f": 83886088
      },
      "n": "ActualIssuer",
      "d": 262264,
      "h": 261993267320,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(261993267320),
//--TRIMMABLE-BOUNDARY-START(257698300024),
    {
      "p": 262213,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399432220792,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 910533329016,
        "f": 83886088
      },
      "n": "ActorClaimsIdentity",
      "d": 262264,
      "h": 257698300024,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(257698300024),
//--TRIMMABLE-BOUNDARY-START(274878169208),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433791959160,
        "f": 50331649
      },
      "n": "AuthenticationTag",
      "d": 262264,
      "h": 274878169208,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878169208),
//--TRIMMABLE-BOUNDARY-START(279173136504),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442381893752,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 927713198200,
        "f": 83886088
      },
      "n": "AuthenticationTagBytes",
      "d": 262264,
      "h": 279173136504,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(279173136504),
//--TRIMMABLE-BOUNDARY-START(292058038392),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459561762936,
        "f": 50331649
      },
      "n": "Ciphertext",
      "d": 262264,
      "h": 292058038392,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292058038392),
//--TRIMMABLE-BOUNDARY-START(296353005688),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 468151697528,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 936303132792,
        "f": 83886088
      },
      "n": "CipherTextBytes",
      "d": 262264,
      "h": 296353005688,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(296353005688),
//--TRIMMABLE-BOUNDARY-START(339302678648),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 493921501304,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 944893067384,
        "f": 83886088
      },
      "n": "Dot1",
      "d": 262264,
      "h": 339302678648,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(339302678648),
//--TRIMMABLE-BOUNDARY-START(343597645944),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 502511435896,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 953483001976,
        "f": 83886088
      },
      "n": "Dot2",
      "d": 262264,
      "h": 343597645944,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(343597645944),
//--TRIMMABLE-BOUNDARY-START(347892613240),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 511101370488,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 962072936568,
        "f": 83886088
      },
      "n": "Dot3",
      "d": 262264,
      "h": 347892613240,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(347892613240),
//--TRIMMABLE-BOUNDARY-START(352187580536),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 519691305080,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 970662871160,
        "f": 83886088
      },
      "n": "Dot4",
      "d": 262264,
      "h": 352187580536,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(352187580536),
//--TRIMMABLE-BOUNDARY-START(360777515128),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 536871174264,
        "f": 50331649
      },
      "n": "EncodedHeader",
      "d": 262264,
      "h": 360777515128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(360777515128),
//--TRIMMABLE-BOUNDARY-START(377957384312),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 571230912632,
        "f": 50331649
      },
      "n": "EncryptedKey",
      "d": 262264,
      "h": 377957384312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(377957384312),
//--TRIMMABLE-BOUNDARY-START(382252351608),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 579820847224,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 979252805752,
        "f": 83886088
      },
      "n": "EncryptedKeyBytes",
      "d": 262264,
      "h": 382252351608,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(382252351608),
//--TRIMMABLE-BOUNDARY-START(365072482424),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 545461108856,
        "f": 50331649
      },
      "n": "EncodedPayload",
      "d": 262264,
      "h": 365072482424,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(365072482424),
//--TRIMMABLE-BOUNDARY-START(369367449720),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 554051043448,
        "f": 50331649
      },
      "n": "EncodedSignature",
      "d": 262264,
      "h": 369367449720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(369367449720),
//--TRIMMABLE-BOUNDARY-START(373662417016),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 562640978040,
        "f": 50331649
      },
      "n": "EncodedToken",
      "d": 262264,
      "h": 373662417016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(373662417016),
//--TRIMMABLE-BOUNDARY-START(824633983096),
    {
      "p": 131192,
      "g": {
        "r": 0,
        "d": 0,
        "h": 588410781816,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 987842740344,
        "f": 83886088
      },
      "n": "Header",
      "d": 262264,
      "h": 824633983096,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(824633983096),
//--TRIMMABLE-BOUNDARY-START(828928950392),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 597000716408,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 996432674936,
        "f": 83886088
      },
      "n": "HeaderAsciiBytes",
      "d": 262264,
      "h": 828928950392,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(828928950392),
//--TRIMMABLE-BOUNDARY-START(841813852280),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 622770520184,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1005022609528,
        "f": 83886088
      },
      "n": "InitializationVectorBytes",
      "d": 262264,
      "h": 841813852280,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(841813852280),
//--TRIMMABLE-BOUNDARY-START(837518884984),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 614180585592,
        "f": 50331649
      },
      "n": "InitializationVector",
      "d": 262264,
      "h": 837518884984,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(837518884984),
//--TRIMMABLE-BOUNDARY-START(846108819576),
    {
      "p": 262264,
      "g": {
        "r": 0,
        "d": 0,
        "h": 631360454776,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1013612544120,
        "f": 83886088
      },
      "n": "InnerToken",
      "d": 262264,
      "h": 846108819576,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(846108819576),
//--TRIMMABLE-BOUNDARY-START(850403786872),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 639950389368,
        "f": 50331649
      },
      "n": "IsEncrypted",
      "d": 262264,
      "h": 850403786872,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(850403786872),
//--TRIMMABLE-BOUNDARY-START(854698754168),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 648540323960,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1022202478712,
        "f": 83886088
      },
      "n": "IsSigned",
      "d": 262264,
      "h": 854698754168,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(854698754168),
//--TRIMMABLE-BOUNDARY-START(880468557944),
    {
      "p": 131192,
      "g": {
        "r": 0,
        "d": 0,
        "h": 700079931512,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1047972282488,
        "f": 83886088
      },
      "n": "Payload",
      "d": 262264,
      "h": 880468557944,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(880468557944),
//--TRIMMABLE-BOUNDARY-START(901943394424),
    {
      "p": 13631607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 717259800696,
        "f": 50364417
      },
      "n": "SecurityKey",
      "d": 262264,
      "h": 901943394424,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(901943394424),
//--TRIMMABLE-BOUNDARY-START(1078037053560),
    {
      "p": 13631607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 725849735288,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1056562217080,
        "f": 83918849
      },
      "n": "SigningKey",
      "d": 262264,
      "h": 1078037053560,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(1078037053560),
//--TRIMMABLE-BOUNDARY-START(871878623352),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 682900062328,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1030792413304,
        "f": 83886088
      },
      "n": "MessageBytes",
      "d": 262264,
      "h": 871878623352,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(871878623352),
//--TRIMMABLE-BOUNDARY-START(876173590648),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 691489996920,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1039382347896,
        "f": 83886088
      },
      "n": "NumberOfDots",
      "d": 262264,
      "h": 876173590648,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(876173590648),
//--TRIMMABLE-BOUNDARY-START(300647972984),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 476741632120,
        "f": 50331777
      },
      "n": "Claims",
      "d": 262264,
      "h": 300647972984,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(300647972984),
//--TRIMMABLE-BOUNDARY-START(884763525240),
    {
      "p": $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 708669866104,
        "f": 50331656
      },
      "n": "PayloadClaimNames",
      "d": 262264,
      "h": 884763525240,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(884763525240),
//--TRIMMABLE-BOUNDARY-START(266288234616),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416612089976,
        "f": 50331649
      },
      "n": "Alg",
      "d": 262264,
      "h": 266288234616,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266288234616),
//--TRIMMABLE-BOUNDARY-START(335007711352),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 485331566712,
        "f": 50331649
      },
      "n": "Cty",
      "d": 262264,
      "h": 335007711352,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335007711352),
//--TRIMMABLE-BOUNDARY-START(356482547832),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 528281239672,
        "f": 50331649
      },
      "n": "Enc",
      "d": 262264,
      "h": 356482547832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356482547832),
//--TRIMMABLE-BOUNDARY-START(867583656056),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 674310127736,
        "f": 50331649
      },
      "n": "Kid",
      "d": 262264,
      "h": 867583656056,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(867583656056),
//--TRIMMABLE-BOUNDARY-START(1112396791928),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 751619539064,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1073742086264,
        "f": 83886088
      },
      "n": "Typ",
      "d": 262264,
      "h": 1112396791928,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1112396791928),
//--TRIMMABLE-BOUNDARY-START(1138166595704),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 794569212024,
        "f": 50331649
      },
      "n": "X5t",
      "d": 262264,
      "h": 1138166595704,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1138166595704),
//--TRIMMABLE-BOUNDARY-START(1142461563000),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 803159146616,
        "f": 50331649
      },
      "n": "Zip",
      "d": 262264,
      "h": 1142461563000,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1142461563000),
//--TRIMMABLE-BOUNDARY-START(253403332728),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390842286200,
        "f": 50331649
      },
      "n": "Actor",
      "d": 262264,
      "h": 253403332728,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403332728),
//--TRIMMABLE-BOUNDARY-START(270583201912),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425202024568,
        "f": 50331649
      },
      "n": "Audiences",
      "d": 262264,
      "h": 270583201912,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583201912),
//--TRIMMABLE-BOUNDARY-START(287763071096),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450971828344,
        "f": 50331649
      },
      "n": "Azp",
      "d": 262264,
      "h": 287763071096,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763071096),
//--TRIMMABLE-BOUNDARY-START(858993721464),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 657130258552,
        "f": 50331649
      },
      "n": "IssuedAt",
      "d": 262264,
      "h": 858993721464,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(858993721464),
//--TRIMMABLE-BOUNDARY-START(863288688760),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 665720193144,
        "f": 50364417
      },
      "n": "Issuer",
      "d": 262264,
      "h": 863288688760,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(863288688760),
//--TRIMMABLE-BOUNDARY-START(833223917688),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 605590651000,
        "f": 50364417
      },
      "n": "Id",
      "d": 262264,
      "h": 833223917688,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(833223917688),
//--TRIMMABLE-BOUNDARY-START(1082332020856),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 734439669880,
        "f": 50331649
      },
      "n": "Subject",
      "d": 262264,
      "h": 1082332020856,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1082332020856),
//--TRIMMABLE-BOUNDARY-START(1120986726520),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 760209473656,
        "f": 50364417
      },
      "n": "ValidFrom",
      "d": 262264,
      "h": 1120986726520,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(1120986726520),
//--TRIMMABLE-BOUNDARY-START(1125281693816),
    {
      "p": $.$typeNullable($.$$.System.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 768799408248,
        "f": 50331656
      },
      "n": "ValidFromNullable",
      "d": 262264,
      "h": 1125281693816,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(1125281693816),
//--TRIMMABLE-BOUNDARY-START(1129576661112),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 777389342840,
        "f": 50364417
      },
      "n": "ValidTo",
      "d": 262264,
      "h": 1129576661112,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(1129576661112),
//--TRIMMABLE-BOUNDARY-START(1133871628408),
    {
      "p": $.$typeNullable($.$$.System.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 785979277432,
        "f": 50331656
      },
      "n": "ValidToNullable",
      "d": 262264,
      "h": 1133871628408,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(1133871628408)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(326417776760),
    {
      "r": 131192,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CreatePayloadClaimSet",
      "d": 262264,
      "h": 326417776760,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(326417776760),
//--TRIMMABLE-BOUNDARY-START(330712744056),
    {
      "r": 131192,
      "p": [
        {
          "n": "byteSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "CreatePayloadClaimSet",
      "o": "@$1",
      "d": 262264,
      "h": 330712744056,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(330712744056),
//--TRIMMABLE-BOUNDARY-START(893353459832),
    {
      "r": 65537,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "ReadPayloadValue",
      "d": 262264,
      "h": 893353459832,
      "f": 16777344
    },
//--TRIMMABLE-BOUNDARY-END(893353459832),
//--TRIMMABLE-BOUNDARY-START(317827842168),
    {
      "r": 131192,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "CreateHeaderClaimSet",
      "o": "@$1",
      "d": 262264,
      "h": 317827842168,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(317827842168),
//--TRIMMABLE-BOUNDARY-START(313532874872),
    {
      "r": 131192,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CreateHeaderClaimSet",
      "d": 262264,
      "h": 313532874872,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(313532874872),
//--TRIMMABLE-BOUNDARY-START(322122809464),
    {
      "r": 131192,
      "p": [
        {
          "n": "byteSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "CreateHeaderClaimSet",
      "o": "@$2",
      "d": 262264,
      "h": 322122809464,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(322122809464),
//--TRIMMABLE-BOUNDARY-START(889058492536),
    {
      "r": 65537,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "ReadHeaderValue",
      "d": 262264,
      "h": 889058492536,
      "f": 16777344
    },
//--TRIMMABLE-BOUNDARY-END(889058492536),
//--TRIMMABLE-BOUNDARY-START(897648427128),
    {
      "r": 65537,
      "p": [
        {
          "n": "encodedTokenMemory",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": "ReadToken",
      "d": 262264,
      "h": 897648427128,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(897648427128),
//--TRIMMABLE-BOUNDARY-START(309237907576),
    {
      "r": 131192,
      "p": [
        {
          "n": "strSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "createHeaderClaimSet",
          "p": 262145
        }
      ],
      "n": "CreateClaimSet",
      "d": 262264,
      "h": 309237907576,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(309237907576),
//--TRIMMABLE-BOUNDARY-START(1086626988152),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 262264,
      "h": 1086626988152,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(1086626988152),
//--TRIMMABLE-BOUNDARY-START(1116691759224),
    {
      "r": 1310721,
      "n": "UnsafeToString",
      "d": 262264,
      "h": 1116691759224,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(1116691759224),
//--TRIMMABLE-BOUNDARY-START(807454113912),
    {
      "r": 131141,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetClaim",
      "d": 262264,
      "h": 807454113912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(807454113912),
//--TRIMMABLE-BOUNDARY-START(1090921955448),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131141,
          "f": 2
        }
      ],
      "n": "TryGetClaim",
      "d": 262264,
      "h": 1090921955448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1090921955448),
//--TRIMMABLE-BOUNDARY-START(820339015800),
    {
      "r": 262145,
      "p": [
        {
          "n": "claimName",
          "p": 1310721
        }
      ],
      "n": "HasPayloadClaim",
      "d": 262264,
      "h": 820339015800,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(820339015800),
//--TRIMMABLE-BOUNDARY-START(811749081208),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetHeaderValue",
      "d": 262264,
      "h": 811749081208,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(811749081208),
//--TRIMMABLE-BOUNDARY-START(816044048504),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetPayloadValue",
      "d": 262264,
      "h": 816044048504,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(816044048504),
//--TRIMMABLE-BOUNDARY-START(1103806857336),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetValue",
      "d": 262264,
      "h": 1103806857336,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(1103806857336),
//--TRIMMABLE-BOUNDARY-START(1095216922744),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetHeaderValue",
      "d": 262264,
      "h": 1095216922744,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(1095216922744),
//--TRIMMABLE-BOUNDARY-START(1099511890040),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetPayloadValue",
      "d": 262264,
      "h": 1099511890040,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(1099511890040)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(283468103800),
    {
      "t": 655361,
      "n": "AverageJsonClaimLengthInBytes",
      "d": 262264,
      "h": 283468103800,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283468103800),
//--TRIMMABLE-BOUNDARY-START(304942940280),
    {
      "t": 1310721,
      "n": "ClassName",
      "d": 262264,
      "h": 304942940280,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942940280),
//--TRIMMABLE-BOUNDARY-START(4295229560),
    {
      "t": 1310721,
      "n": "_act",
      "d": 262264,
      "h": 4295229560,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229560),
//--TRIMMABLE-BOUNDARY-START(17180131448),
    {
      "t": 1310721,
      "n": "_authenticationTag",
      "d": 262264,
      "h": 17180131448,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131448),
//--TRIMMABLE-BOUNDARY-START(25770066040),
    {
      "t": 1310721,
      "n": "_ciphertext",
      "d": 262264,
      "h": 25770066040,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770066040),
//--TRIMMABLE-BOUNDARY-START(38654967928),
    {
      "t": 1310721,
      "n": "_encodedHeader",
      "d": 262264,
      "h": 38654967928,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654967928),
//--TRIMMABLE-BOUNDARY-START(42949935224),
    {
      "t": 1310721,
      "n": "_encodedPayload",
      "d": 262264,
      "h": 42949935224,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949935224),
//--TRIMMABLE-BOUNDARY-START(47244902520),
    {
      "t": 1310721,
      "n": "_encodedSignature",
      "d": 262264,
      "h": 47244902520,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47244902520),
//--TRIMMABLE-BOUNDARY-START(51539869816),
    {
      "t": 1310721,
      "n": "_encodedToken",
      "d": 262264,
      "h": 51539869816,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51539869816),
//--TRIMMABLE-BOUNDARY-START(60129804408),
    {
      "t": 1310721,
      "n": "_encryptedKey",
      "d": 262264,
      "h": 60129804408,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60129804408),
//--TRIMMABLE-BOUNDARY-START(85899608184),
    {
      "t": 1310721,
      "n": "_initializationVector",
      "d": 262264,
      "h": 85899608184,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85899608184),
//--TRIMMABLE-BOUNDARY-START(12885164152),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "n": "_audiences",
      "d": 262264,
      "h": 12885164152,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164152),
//--TRIMMABLE-BOUNDARY-START(55834837112),
    {
      "t": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,
      "n": "_encodedTokenMemory",
      "d": 262264,
      "h": 55834837112,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834837112),
//--TRIMMABLE-BOUNDARY-START(8590196856),
    {
      "t": 1310721,
      "n": "_alg",
      "d": 262264,
      "h": 8590196856,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590196856),
//--TRIMMABLE-BOUNDARY-START(30065033336),
    {
      "t": 1310721,
      "n": "_cty",
      "d": 262264,
      "h": 30065033336,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065033336),
//--TRIMMABLE-BOUNDARY-START(34360000632),
    {
      "t": 1310721,
      "n": "_enc",
      "d": 262264,
      "h": 34360000632,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360000632),
//--TRIMMABLE-BOUNDARY-START(98784510072),
    {
      "t": 1310721,
      "n": "_kid",
      "d": 262264,
      "h": 98784510072,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(98784510072),
//--TRIMMABLE-BOUNDARY-START(115964379256),
    {
      "t": 1310721,
      "n": "_typ",
      "d": 262264,
      "h": 115964379256,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(115964379256),
//--TRIMMABLE-BOUNDARY-START(128849281144),
    {
      "t": 1310721,
      "n": "_x5t",
      "d": 262264,
      "h": 128849281144,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(128849281144),
//--TRIMMABLE-BOUNDARY-START(133144248440),
    {
      "t": 1310721,
      "n": "_zip",
      "d": 262264,
      "h": 133144248440,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(133144248440),
//--TRIMMABLE-BOUNDARY-START(21475098744),
    {
      "t": 1310721,
      "n": "_azp",
      "d": 262264,
      "h": 21475098744,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475098744),
//--TRIMMABLE-BOUNDARY-START(64424771704),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_exp",
      "d": 262264,
      "h": 64424771704,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(64424771704),
//--TRIMMABLE-BOUNDARY-START(68719739000),
    {
      "t": $.$typeNullable($.$$.System.DateTime).$h,
      "n": "_expDateTime",
      "d": 262264,
      "h": 68719739000,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(68719739000),
//--TRIMMABLE-BOUNDARY-START(73014706296),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_iat",
      "d": 262264,
      "h": 73014706296,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(73014706296),
//--TRIMMABLE-BOUNDARY-START(77309673592),
    {
      "t": $.$typeNullable($.$$.System.DateTime).$h,
      "n": "_iatDateTime",
      "d": 262264,
      "h": 77309673592,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(77309673592),
//--TRIMMABLE-BOUNDARY-START(81604640888),
    {
      "t": 1310721,
      "n": "_id",
      "d": 262264,
      "h": 81604640888,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(81604640888),
//--TRIMMABLE-BOUNDARY-START(90194575480),
    {
      "t": 1310721,
      "n": "_iss",
      "d": 262264,
      "h": 90194575480,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(90194575480),
//--TRIMMABLE-BOUNDARY-START(94489542776),
    {
      "t": 1310721,
      "n": "_jti",
      "d": 262264,
      "h": 94489542776,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(94489542776),
//--TRIMMABLE-BOUNDARY-START(111669411960),
    {
      "t": 1310721,
      "n": "_sub",
      "d": 262264,
      "h": 111669411960,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(111669411960),
//--TRIMMABLE-BOUNDARY-START(103079477368),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_nbf",
      "d": 262264,
      "h": 103079477368,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(103079477368),
//--TRIMMABLE-BOUNDARY-START(107374444664),
    {
      "t": $.$typeNullable($.$$.System.DateTime).$h,
      "n": "_nbfDateTime",
      "d": 262264,
      "h": 107374444664,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(107374444664),
//--TRIMMABLE-BOUNDARY-START(120259346552),
    {
      "t": $.$typeNullable($.$$.System.DateTime).$h,
      "n": "_validFrom",
      "d": 262264,
      "h": 120259346552,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(120259346552),
//--TRIMMABLE-BOUNDARY-START(124554313848),
    {
      "t": $.$typeNullable($.$$.System.DateTime).$h,
      "n": "_validTo",
      "d": 262264,
      "h": 124554313848,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(124554313848)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(244813398136),
    {
      "p": [
        {
          "n": "jwtEncodedString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 262264,
      "h": 244813398136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813398136),
//--TRIMMABLE-BOUNDARY-START(240518430840),
    {
      "p": [
        {
          "n": "jwtEncodedString",
          "p": 1310721
        },
        {
          "n": "tryReadJwtClaim",
          "p": 16973943
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 262264,
      "h": 240518430840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240518430840),
//--TRIMMABLE-BOUNDARY-START(227633528952),
    {
      "p": [
        {
          "n": "encodedTokenMemory",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262264,
      "h": 227633528952,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227633528952),
//--TRIMMABLE-BOUNDARY-START(223338561656),
    {
      "p": [
        {
          "n": "encodedTokenMemory",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        },
        {
          "n": "tryReadJwtClaim",
          "p": 16973943
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262264,
      "h": 223338561656,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223338561656),
//--TRIMMABLE-BOUNDARY-START(236223463544),
    {
      "p": [
        {
          "n": "header",
          "p": 1310721
        },
        {
          "n": "payload",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 262264,
      "h": 236223463544,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236223463544),
//--TRIMMABLE-BOUNDARY-START(231928496248),
    {
      "p": [
        {
          "n": "header",
          "p": 1310721
        },
        {
          "n": "payload",
          "p": 1310721
        },
        {
          "n": "tryReadJwtClaim",
          "p": 16973943
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 262264,
      "h": 231928496248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231928496248),
//--TRIMMABLE-BOUNDARY-START(249108365432),
    {
      "p": [
        {
          "n": "jsonWebToken",
          "p": 262264
        },
        {
          "n": "encodedHeader",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 262264,
      "h": 249108365432,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(249108365432)
  ],
  "i": [196726
  ],
  "h": 262264
}; }
            static get $b() { return $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact ]; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonWebToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262264)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179768)
        $asm.$cls("$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0", ($self) => class CreateJwsRegex_0 extends $.$str.System.Text.RegularExpressions.Regex
        {
            //--TRIMMABLE-BOUNDARY-START(17181048952)
            /*CreateJwsRegex_0*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(17181048952)
            
            //--TRIMMABLE-BOUNDARY-START(12886081656)
            $ctor$8()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.pattern = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                    this.roptions = 512/*RegexOptions.CultureInvariant*/;
                    this.internalMatchTimeout = $.$$.System.TimeSpan.FromMilliseconds$2(100n);
                    this.factory = new $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory().$ctor$2();
                    this.capsize = 1;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081656)
            
            //--TRIMMABLE-BOUNDARY-START(1245304)
            static $_RunnerFactory;
            static get RunnerFactory()
            {
                let $cls = $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0;
                return $cls.$_RunnerFactory ??= $asm.$ncls("$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory", ($self) => class RunnerFactory extends $.$str.System.Text.RegularExpressions.RegexRunnerFactory
                {
                    //--TRIMMABLE-BOUNDARY-START(12886147192)
                    /*RegexRunner */ CreateInstance()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886147192);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory.Runner().$ctor$2();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886147192)
                    
                    //--TRIMMABLE-BOUNDARY-START(1310840)
                    static $_Runner;
                    static get Runner()
                    {
                        let $cls = $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory;
                        return $cls.$_Runner ??= $asm.$ncls("$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory.Runner", ($self) => class Runner extends $.$str.System.Text.RegularExpressions.RegexRunner
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591245432)
                            /*void */ Scan(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(8591245432);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this.TryFindNextPossibleStartingPosition(inputSpan) && !this.TryMatchAtCurrentPosition(inputSpan))
                                {
                                    this.runtextpos = inputSpan.Length;
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591245432)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886212728)
                            /*bool */ TryFindNextPossibleStartingPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(12886212728);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*int*/ let pos = this.runtextpos;
                                if (pos <= ((inputSpan.Length - 4) | 0))
                                {
                                    if (pos === 0)
                                    {
                                        return true;
                                    }
                                }
                                this.runtextpos = inputSpan.Length;
                                return false;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886212728)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181180024)
                            /*bool */ TryMatchAtCurrentPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17181180024);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*int*/ let pos = this.runtextpos;
                                /*int*/ let matchStart = pos;
                                /*ReadOnlySpan<char>*/ let slice = inputSpan.Slice$1(pos);
                                if (pos !== 0)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice, $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration < 0)
                                    {
                                        iteration = slice.Length;
                                    }
                                    if (iteration === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration);
                                    pos += iteration;
                                }
                                if (slice.IsEmpty || slice.get_Item(0).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration1 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(1), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration1 < 0)
                                    {
                                        iteration1 = ((slice.Length - 1) | 0);
                                    }
                                    if (iteration1 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration1);
                                    pos += iteration1;
                                }
                                if ((slice.Length >>> 0) < 2 || slice.get_Item(1).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration2 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(2), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration2 < 0)
                                    {
                                        iteration2 = ((slice.Length - 2) | 0);
                                    }
                                    slice = slice.Slice$1(iteration2);
                                    pos += iteration2;
                                }
                                if (3 < slice.Length || (2 < slice.Length && slice.get_Item(2).$v !== /*\n*/ 10))
                                {
                                    return false;
                                }
                                pos += 2;
                                this.runtextpos = pos;
                                super.Capture(0, matchStart, pos);
                                return true;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181180024)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296278136)
                            //default reference type constructor overload
                            $ctor$2()
                            {
                                super.$ctor$1();
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296278136)
                            
                            static $h = 1310840;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 3997754,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591245432),
    {
      "r": 65537,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Scan",
      "d": 1310840,
      "h": 8591245432,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591245432),
//--TRIMMABLE-BOUNDARY-START(12886212728),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "TryFindNextPossibleStartingPosition",
      "d": 1310840,
      "h": 12886212728,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886212728),
//--TRIMMABLE-BOUNDARY-START(17181180024),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "TryMatchAtCurrentPosition",
      "d": 1310840,
      "h": 17181180024,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181180024)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278136),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310840,
      "h": 4296278136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278136)
  ],
  "d": 1245304,
  "h": 1310840
}; }
                            static get $b() { return $.$str.System.Text.RegularExpressions.RegexRunner; }
                            static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory.Runner`; }
                        }, $cls, ($v) => $cls.$_Runner = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1310840)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591179896)
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591179896)
                    
                    static $h = 1245304;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 4063290,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886147192),
    {
      "r": 3997754,
      "n": "CreateInstance",
      "d": 1245304,
      "h": 12886147192,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886147192)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179896),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245304,
      "h": 8591179896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179896)
  ],
  "j": [1310840
  ],
  "d": 1179768,
  "h": 1245304
}; }
                    static get $b() { return $.$str.System.Text.RegularExpressions.RegexRunnerFactory; }
                    static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory`; }
                }, $cls, ($v) => $cls.$_RunnerFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245304)
            
            //--TRIMMABLE-BOUNDARY-START(8591114360)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17181048952)
                    this.Instance = new $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0().$ctor$8();
                    //--TRIMMABLE-BOUNDARY-END(17181048952)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591114360)
            
            static $h = 1179768;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1900602,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181048952),
    {
      "t": 1179768,
      "n": "Instance",
      "d": 1179768,
      "h": 17181048952,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181048952)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886081656),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1179768,
      "h": 12886081656,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886081656)
  ],
  "i": [157483009
  ],
  "j": [1245304
  ],
  "h": 1179768,
  "a": [
    {
      "t": 54329345,
      "c": 12939231233,
      "a": [
        {
          "v": "System.Text.RegularExpressions.Generator",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    },
    {
      "t": 132972545,
      "c": 4427939841
    }
  ]
}; }
            static get $b() { return $.$str.System.Text.RegularExpressions.Regex; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJwsRegex_0`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179768)
        
        
        //--TRIMMABLE-BOUNDARY-START(983160)
        $asm.$cls("$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1", ($self) => class CreateJweRegex_1 extends $.$str.System.Text.RegularExpressions.Regex
        {
            //--TRIMMABLE-BOUNDARY-START(17180852344)
            /*CreateJweRegex_1*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(17180852344)
            
            //--TRIMMABLE-BOUNDARY-START(12885885048)
            $ctor$8()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885885048);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.pattern = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                    this.roptions = 512/*RegexOptions.CultureInvariant*/;
                    this.internalMatchTimeout = $.$$.System.TimeSpan.FromMilliseconds$2(100n);
                    this.factory = new $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory().$ctor$2();
                    this.capsize = 1;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885885048)
            
            //--TRIMMABLE-BOUNDARY-START(1048696)
            static $_RunnerFactory;
            static get RunnerFactory()
            {
                let $cls = $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1;
                return $cls.$_RunnerFactory ??= $asm.$ncls("$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory", ($self) => class RunnerFactory extends $.$str.System.Text.RegularExpressions.RegexRunnerFactory
                {
                    //--TRIMMABLE-BOUNDARY-START(12885950584)
                    /*RegexRunner */ CreateInstance()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885950584);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory.Runner().$ctor$2();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885950584)
                    
                    //--TRIMMABLE-BOUNDARY-START(1114232)
                    static $_Runner;
                    static get Runner()
                    {
                        let $cls = $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory;
                        return $cls.$_Runner ??= $asm.$ncls("$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory.Runner", ($self) => class Runner extends $.$str.System.Text.RegularExpressions.RegexRunner
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591048824)
                            /*void */ Scan(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(8591048824);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this.TryFindNextPossibleStartingPosition(inputSpan) && !this.TryMatchAtCurrentPosition(inputSpan))
                                {
                                    this.runtextpos = inputSpan.Length;
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591048824)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886016120)
                            /*bool */ TryFindNextPossibleStartingPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(12886016120);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*int*/ let pos = this.runtextpos;
                                if (pos <= ((inputSpan.Length - 8) | 0))
                                {
                                    if (pos === 0)
                                    {
                                        return true;
                                    }
                                }
                                this.runtextpos = inputSpan.Length;
                                return false;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886016120)
                            
                            //--TRIMMABLE-BOUNDARY-START(17180983416)
                            /*bool */ TryMatchAtCurrentPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17180983416);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*int*/ let pos = this.runtextpos;
                                /*int*/ let matchStart = pos;
                                /*ReadOnlySpan<char>*/ let slice = inputSpan.Slice$1(pos);
                                if (pos !== 0)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice, $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration < 0)
                                    {
                                        iteration = slice.Length;
                                    }
                                    if (iteration === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration);
                                    pos += iteration;
                                }
                                if (slice.IsEmpty || slice.get_Item(0).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration1 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(1), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration1 < 0)
                                    {
                                        iteration1 = ((slice.Length - 1) | 0);
                                    }
                                    slice = slice.Slice$1(iteration1);
                                    pos += iteration1;
                                }
                                if ((slice.Length >>> 0) < 2 || slice.get_Item(1).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration2 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(2), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration2 < 0)
                                    {
                                        iteration2 = ((slice.Length - 2) | 0);
                                    }
                                    if (iteration2 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration2);
                                    pos += iteration2;
                                }
                                if ((slice.Length >>> 0) < 3 || slice.get_Item(2).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration3 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(3), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration3 < 0)
                                    {
                                        iteration3 = ((slice.Length - 3) | 0);
                                    }
                                    if (iteration3 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration3);
                                    pos += iteration3;
                                }
                                if ((slice.Length >>> 0) < 4 || slice.get_Item(3).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration4 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(4), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration4 < 0)
                                    {
                                        iteration4 = ((slice.Length - 4) | 0);
                                    }
                                    if (iteration4 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration4);
                                    pos += iteration4;
                                }
                                if (5 < slice.Length || (4 < slice.Length && slice.get_Item(4).$v !== /*\n*/ 10))
                                {
                                    return false;
                                }
                                pos += 4;
                                this.runtextpos = pos;
                                super.Capture(0, matchStart, pos);
                                return true;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17180983416)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296081528)
                            //default reference type constructor overload
                            $ctor$2()
                            {
                                super.$ctor$1();
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296081528)
                            
                            static $h = 1114232;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 3997754,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591048824),
    {
      "r": 65537,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Scan",
      "d": 1114232,
      "h": 8591048824,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591048824),
//--TRIMMABLE-BOUNDARY-START(12886016120),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "TryFindNextPossibleStartingPosition",
      "d": 1114232,
      "h": 12886016120,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886016120),
//--TRIMMABLE-BOUNDARY-START(17180983416),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "TryMatchAtCurrentPosition",
      "d": 1114232,
      "h": 17180983416,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180983416)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081528),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114232,
      "h": 4296081528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081528)
  ],
  "d": 1048696,
  "h": 1114232
}; }
                            static get $b() { return $.$str.System.Text.RegularExpressions.RegexRunner; }
                            static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory.Runner`; }
                        }, $cls, ($v) => $cls.$_Runner = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1114232)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590983288)
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590983288)
                    
                    static $h = 1048696;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 4063290,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885950584),
    {
      "r": 3997754,
      "n": "CreateInstance",
      "d": 1048696,
      "h": 12885950584,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885950584)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590983288),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048696,
      "h": 8590983288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590983288)
  ],
  "j": [1114232
  ],
  "d": 983160,
  "h": 1048696
}; }
                    static get $b() { return $.$str.System.Text.RegularExpressions.RegexRunnerFactory; }
                    static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory`; }
                }, $cls, ($v) => $cls.$_RunnerFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048696)
            
            //--TRIMMABLE-BOUNDARY-START(8590917752)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180852344)
                    this.Instance = new $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1().$ctor$8();
                    //--TRIMMABLE-BOUNDARY-END(17180852344)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590917752)
            
            static $h = 983160;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1900602,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180852344),
    {
      "t": 983160,
      "n": "Instance",
      "d": 983160,
      "h": 17180852344,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180852344)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885885048),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 983160,
      "h": 12885885048,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885885048)
  ],
  "i": [157483009
  ],
  "j": [1048696
  ],
  "h": 983160,
  "a": [
    {
      "t": 54329345,
      "c": 12939231233,
      "a": [
        {
          "v": "System.Text.RegularExpressions.Generator",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    },
    {
      "t": 132972545,
      "c": 4427939841
    }
  ]
}; }
            static get $b() { return $.$str.System.Text.RegularExpressions.Regex; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJweRegex_1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983160)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Logging", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.IdentityModel.Tokens"))
//--TRIMMABLE-BOUNDARY-END(120)
