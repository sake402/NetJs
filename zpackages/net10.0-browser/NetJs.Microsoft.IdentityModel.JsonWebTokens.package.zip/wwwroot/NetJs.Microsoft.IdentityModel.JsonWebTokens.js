
(function ($global, $, $$, $mia, $sc, $sm, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mil, $scm, $so, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $mela, $mep, $scp, $scs, $sdp, $srw, $srl, $srsf, $str, $sdts, $spx, $spxl, $sxxd, $sct, $sca, $meo, $mel, $sipl, $stew, $stj, $mit) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.JsonWebTokens", 
    {"h":64797,"f":"Microsoft.IdentityModel.JsonWebTokens","v":"1.0.35.0","a":[{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.Validators, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.JsonWebTokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.TestUtils, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsAotCompatible","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"Microsoft Corporation.","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":73793537,"c":4368760833,"a":[{"v":"\u00A9 Microsoft Corporation. All rights reserved.","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Includes types that provide support for creating, serializing and validating JSON Web Tokens. This is a newer, faster version of System.IdentityModel.Tokens.Jwt that has additional functionality.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"9.0.0.26241","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft IdentityModel","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.IdentityModel.JsonWebTokens","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"RepositoryUrl","t":1310721},{"v":"https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"NetJs.System.IdentityModel.Tokens.Jwt","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"Serviceable","t":1310721},{"v":"True","t":1310721}]},{"t":23527425,"c":8613462017,"a":[{"v":true,"t":262145}]},{"t":102432769,"c":4397400065,"a":[{"v":false,"t":262145}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.JsonWebTokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.Protocols.SignedHttpRequest, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"System.IdentityModel.Tokens.Jwt, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"System.IdentityModel.Tokens.Jwt.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.S2S, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.S2S.Tokens, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.S2S.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.S2S.Tokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.Benchmarks, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimValueTypes", ($self) => class JsonClaimValueTypes
        {
            /*string*/ static Json = null;
            /*string*/ static JsonArray = null;
            /*string*/ static JsonNull = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Json = "JSON";
                }
                {
                    this.JsonArray = "JSON_ARRAY";
                }
                {
                    this.JsonNull = "JSON_NULL";
                }
            }
            static $h = 261405;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Json","d":261405,"h":4295228701,"f":4194337},{"t":1310721,"n":"JsonArray","d":261405,"h":8590195997,"f":4194337},{"t":1310721,"n":"JsonNull","d":261405,"h":12885163293,"f":4194337}],"h":261405}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonClaimValueTypes`; }
        });
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtConstants", ($self) => class JwtConstants
        {
            /*string*/ static HeaderType = null;
            /*string*/ static HeaderTypeAlt = null;
            /*string*/ static TokenType = null;
            /*string*/ static TokenTypeAlt = null;
            /*string*/ static JsonCompactSerializationRegex = null;
            /*string*/ static JweCompactSerializationRegex = null;
            /*int*/ static JweSegmentCount = 5;
            /*int*/ static JwsSegmentCount = 3;
            /*int*/ static MaxJwtSegmentCount = 5;
            /*string*/ static DirectKeyUseAlg = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.HeaderType = "JWT";
                }
                {
                    this.HeaderTypeAlt = "http://openid.net/specs/jwt/1.0";
                }
                {
                    this.TokenType = "JWT";
                }
                {
                    this.TokenTypeAlt = "urn:ietf:params:oauth:token-type:jwt";
                }
                {
                    this.JsonCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                }
                {
                    this.JweCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                }
                {
                    this.DirectKeyUseAlg = "dir";
                }
            }
            static $h = 523549;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"HeaderType","d":523549,"h":4295490845,"f":4194337},{"t":1310721,"n":"HeaderTypeAlt","d":523549,"h":8590458141,"f":4194337},{"t":1310721,"n":"TokenType","d":523549,"h":12885425437,"f":4194337},{"t":1310721,"n":"TokenTypeAlt","d":523549,"h":17180392733,"f":4194337},{"t":1310721,"n":"JsonCompactSerializationRegex","d":523549,"h":21475360029,"f":4194337},{"t":1310721,"n":"JweCompactSerializationRegex","d":523549,"h":25770327325,"f":4194337},{"t":655361,"n":"JweSegmentCount","d":523549,"h":30065294621,"f":4194337},{"t":655361,"n":"JwsSegmentCount","d":523549,"h":34360261917,"f":4194337},{"t":655361,"n":"MaxJwtSegmentCount","d":523549,"h":38655229213,"f":4194337},{"t":1310721,"n":"DirectKeyUseAlg","d":523549,"h":42950196509,"f":4194337}],"h":523549}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtConstants`; }
        });
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.LogMessages", ($self) => class LogMessages
        {
            /*string*/ static IDX14000 = null;
            /*string*/ static IDX14100 = null;
            /*string*/ static IDX14101 = null;
            /*string*/ static IDX14102 = null;
            /*string*/ static IDX14103 = null;
            /*string*/ static IDX14107 = null;
            /*string*/ static IDX14112 = null;
            /*string*/ static IDX14113 = null;
            /*string*/ static IDX14114 = null;
            /*string*/ static IDX14116 = null;
            /*string*/ static IDX14117 = null;
            /*string*/ static IDX14120 = null;
            /*string*/ static IDX14121 = null;
            /*string*/ static IDX14122 = null;
            /*string*/ static IDX14200 = null;
            /*string*/ static IDX14201 = null;
            /*string*/ static IDX14304 = null;
            /*string*/ static IDX14305 = null;
            /*string*/ static IDX14306 = null;
            /*string*/ static IDX14307 = null;
            /*string*/ static IDX14308 = null;
            /*string*/ static IDX14309 = null;
            /*string*/ static IDX14310 = null;
            /*string*/ static IDX14311 = null;
            /*string*/ static IDX14312 = null;
            /*string*/ static IDX14317 = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.IDX14000 = "IDX14000: Signature validation of this JWT is not supported for: Algorithm: '{0}', SecurityKey: '{1}'.";
                }
                {
                    this.IDX14100 = "IDX14100: JWT is not well formed, there are no dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                }
                {
                    this.IDX14101 = "IDX14101: Unable to decode the payload '{0}' as Base64Url encoded string.";
                }
                {
                    this.IDX14102 = "IDX14102: Unable to decode the header '{0}' as Base64Url encoded string.";
                }
                {
                    this.IDX14103 = "IDX14103: Failed to create the token encryption provider.";
                }
                {
                    this.IDX14107 = "IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)";
                }
                {
                    this.IDX14112 = "IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'";
                }
                {
                    this.IDX14113 = "IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used.";
                }
                {
                    this.IDX14114 = "IDX14114: Both '{0}.{1}' and '{0}.{2}' are null or empty.";
                }
                {
                    this.IDX14116 = "IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation.";
                }
                {
                    this.IDX14117 = "IDX14117: Cannot create a 'JsonWebToken' with a replaced header from an encrypted (JWE) token. The provided token must be a JWS so that its decoded payload can be reused.";
                }
                {
                    this.IDX14120 = "IDX14120: JWT is not well formed, there is only one dot (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                }
                {
                    this.IDX14121 = "IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                }
                {
                    this.IDX14122 = "IDX14122: JWT is not a well formed JWE, there are more than four dots (.) a JWE can have at most 4 dots.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                }
                {
                    this.IDX14200 = "IDX14200: Creating raw signature using the signature credentials.";
                }
                {
                    this.IDX14201 = "IDX14201: Creating raw signature using the signature credentials. Caching SignatureProvider: '{0}'.";
                }
                {
                    this.IDX14304 = "IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet.";
                }
                {
                    this.IDX14305 = "IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'.";
                }
                {
                    this.IDX14306 = "IDX14306: JWE Ciphertext cannot be an empty string.";
                }
                {
                    this.IDX14307 = "IDX14307: JWE header is missing.";
                }
                {
                    this.IDX14308 = "IDX14308: JWE initialization vector is missing.";
                }
                {
                    this.IDX14309 = "IDX14309: Unable to decode the initialization vector as Base64Url encoded string.";
                }
                {
                    this.IDX14310 = "IDX14310: JWE authentication tag is missing.";
                }
                {
                    this.IDX14311 = "IDX14311: Unable to decode the authentication tag as a Base64Url encoded string.";
                }
                {
                    this.IDX14312 = "IDX14312: Unable to decode the cipher text as a Base64Url encoded string.";
                }
                {
                    this.IDX14317 = "IDX14317: JsonWebTokenHandler.MaxActorChainLength must be greater than or equal to 1. Value provided was: '{0}'.";
                }
            }
            static $h = 982301;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"IDX14000","d":982301,"h":4295949597,"f":4194344},{"t":1310721,"n":"IDX14100","d":982301,"h":8590916893,"f":4194344},{"t":1310721,"n":"IDX14101","d":982301,"h":12885884189,"f":4194344},{"t":1310721,"n":"IDX14102","d":982301,"h":17180851485,"f":4194344},{"t":1310721,"n":"IDX14103","d":982301,"h":21475818781,"f":4194344},{"t":1310721,"n":"IDX14107","d":982301,"h":25770786077,"f":4194344},{"t":1310721,"n":"IDX14112","d":982301,"h":30065753373,"f":4194344},{"t":1310721,"n":"IDX14113","d":982301,"h":34360720669,"f":4194344},{"t":1310721,"n":"IDX14114","d":982301,"h":38655687965,"f":4194344},{"t":1310721,"n":"IDX14116","d":982301,"h":42950655261,"f":4194344},{"t":1310721,"n":"IDX14117","d":982301,"h":47245622557,"f":4194344},{"t":1310721,"n":"IDX14120","d":982301,"h":51540589853,"f":4194344},{"t":1310721,"n":"IDX14121","d":982301,"h":55835557149,"f":4194344},{"t":1310721,"n":"IDX14122","d":982301,"h":60130524445,"f":4194344},{"t":1310721,"n":"IDX14200","d":982301,"h":64425491741,"f":4194344},{"t":1310721,"n":"IDX14201","d":982301,"h":68720459037,"f":4194344},{"t":1310721,"n":"IDX14304","d":982301,"h":73015426333,"f":4194344},{"t":1310721,"n":"IDX14305","d":982301,"h":77310393629,"f":4194344},{"t":1310721,"n":"IDX14306","d":982301,"h":81605360925,"f":4194344},{"t":1310721,"n":"IDX14307","d":982301,"h":85900328221,"f":4194344},{"t":1310721,"n":"IDX14308","d":982301,"h":90195295517,"f":4194344},{"t":1310721,"n":"IDX14309","d":982301,"h":94490262813,"f":4194344},{"t":1310721,"n":"IDX14310","d":982301,"h":98785230109,"f":4194344},{"t":1310721,"n":"IDX14311","d":982301,"h":103080197405,"f":4194344},{"t":1310721,"n":"IDX14312","d":982301,"h":107375164701,"f":4194344},{"t":1310721,"n":"IDX14317","d":982301,"h":111670131997,"f":4194344}],"h":982301}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.LogMessages`; }
        });
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters", ($self) => class JwtTokenDecryptionParameters extends $.$$.System.Object
        {
            /*byte[]*/ CipherTextBytes = null;
            /*byte[]*/ HeaderAsciiBytes = null;
            /*byte[]*/ InitializationVectorBytes = null;
            /*byte[]*/ AuthenticationTagBytes = null;
            /*string*/ Alg = null;
            /*string*/ AuthenticationTag = null;
            /*string*/ Ciphertext = null;
            /*Func<byte[], string, int, string>*/ DecompressionFunction = null;
            /*string*/ Enc = null;
            /*string*/ EncodedHeader = null;
            /*string*/ EncodedToken = null;
            /*string*/ InitializationVector = null;
            /*IEnumerable<SecurityKey>*/ Keys$1 = null;
            /*int*/ MaximumDeflateSize = 0;
            /*string*/ Zip = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MaximumDeflateSize = 256000;
            }
            static $h = 851229;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":12885753117,"f":50331649},"s":{"r":0,"d":0,"h":17180720413,"f":83886081},"n":"CipherTextBytes","d":851229,"h":8590785821,"f":2097153},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":30065622301,"f":50331649},"s":{"r":0,"d":0,"h":34360589597,"f":83886081},"n":"HeaderAsciiBytes","d":851229,"h":25770655005,"f":2097153},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":47245491485,"f":50331649},"s":{"r":0,"d":0,"h":51540458781,"f":83886081},"n":"InitializationVectorBytes","d":851229,"h":42950524189,"f":2097153},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":64425360669,"f":50331649},"s":{"r":0,"d":0,"h":68720327965,"f":83886081},"n":"AuthenticationTagBytes","d":851229,"h":60130393373,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":81605229853,"f":50331649},"s":{"r":0,"d":0,"h":85900197149,"f":83886081},"n":"Alg","d":851229,"h":77310262557,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":98785099037,"f":50331649},"s":{"r":0,"d":0,"h":103080066333,"f":83886081},"n":"AuthenticationTag","d":851229,"h":94490131741,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":115964968221,"f":50331649},"s":{"r":0,"d":0,"h":120259935517,"f":83886081},"n":"Ciphertext","d":851229,"h":111670000925,"f":2097153},{"p":$.$$.System.Func$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.String, $.$$.System.Int32, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":133144837405,"f":50331649},"s":{"r":0,"d":0,"h":137439804701,"f":83886081},"n":"DecompressionFunction","d":851229,"h":128849870109,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":150324706589,"f":50331649},"s":{"r":0,"d":0,"h":154619673885,"f":83886081},"n":"Enc","d":851229,"h":146029739293,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":167504575773,"f":50331649},"s":{"r":0,"d":0,"h":171799543069,"f":83886081},"n":"EncodedHeader","d":851229,"h":163209608477,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":184684444957,"f":50331649},"s":{"r":0,"d":0,"h":188979412253,"f":83886081},"n":"EncodedToken","d":851229,"h":180389477661,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":201864314141,"f":50331649},"s":{"r":0,"d":0,"h":206159281437,"f":83886081},"n":"InitializationVector","d":851229,"h":197569346845,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,"g":{"r":0,"d":0,"h":219044183325,"f":50331649},"s":{"r":0,"d":0,"h":223339150621,"f":83886081},"n":"Keys","o":"@$1","d":851229,"h":214749216029,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":236224052509,"f":50331649},"s":{"r":0,"d":0,"h":240519019805,"f":83886081},"n":"MaximumDeflateSize","d":851229,"h":231929085213,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":253403921693,"f":50331649},"s":{"r":0,"d":0,"h":257698888989,"f":83886081},"n":"Zip","d":851229,"h":249108954397,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":851229,"h":261993856285,"f":16777217}],"h":851229}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters`; }
        });
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping", ($self) => class ClaimTypeMapping
        {
            /*Dictionary<string, string>*/ static shortToLongClaimTypeMapping = null;
            /*Dictionary<string, string>*/ static longToShortClaimTypeMapping = null;
            /*HashSet<string>*/ static inboundClaimFilter = null;
            /*Static constructor*/ static $cctor()
            {
                var $en2 = $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.shortToLongClaimTypeMapping.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kv = $en2.Current;
                    {
                        if ($.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.longToShortClaimTypeMapping.ContainsKey(kv.Value))
                        {
                            continue;
                        }
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.longToShortClaimTypeMapping.Add(kv.Value, kv.Key);
                    }
                }
            }
            static /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.shortToLongClaimTypeMapping;
            }
            static /*IDictionary<string, string> */ get OutboundClaimTypeMap()
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.longToShortClaimTypeMapping;
            }
            static /*ISet<string> */ get InboundClaimFilter()
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.inboundClaimFilter;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.shortToLongClaimTypeMapping = (() =>
                    {
                        //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("actort"/*JwtRegisteredClaimNames.Actort*/, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/);
                        $i1.Add("birthdate"/*JwtRegisteredClaimNames.Birthdate*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth"/*ClaimTypes.DateOfBirth*/);
                        $i1.Add("email"/*JwtRegisteredClaimNames.Email*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"/*ClaimTypes.Email*/);
                        $i1.Add("family_name"/*JwtRegisteredClaimNames.FamilyName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"/*ClaimTypes.Surname*/);
                        $i1.Add("gender"/*JwtRegisteredClaimNames.Gender*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender"/*ClaimTypes.Gender*/);
                        $i1.Add("given_name"/*JwtRegisteredClaimNames.GivenName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"/*ClaimTypes.GivenName*/);
                        $i1.Add("nameid"/*JwtRegisteredClaimNames.NameId*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/);
                        $i1.Add("sub"/*JwtRegisteredClaimNames.Sub*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/);
                        $i1.Add("website"/*JwtRegisteredClaimNames.Website*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage"/*ClaimTypes.Webpage*/);
                        $i1.Add("unique_name"/*JwtRegisteredClaimNames.UniqueName*/, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimTypes.Name*/);
                        $i1.Add("oid", "http://schemas.microsoft.com/identity/claims/objectidentifier");
                        $i1.Add("scp", "http://schemas.microsoft.com/identity/claims/scope");
                        $i1.Add("tid", "http://schemas.microsoft.com/identity/claims/tenantid");
                        $i1.Add("acr", "http://schemas.microsoft.com/claims/authnclassreference");
                        $i1.Add("adfs1email", "http://schemas.xmlsoap.org/claims/EmailAddress");
                        $i1.Add("adfs1upn", "http://schemas.xmlsoap.org/claims/UPN");
                        $i1.Add("amr", "http://schemas.microsoft.com/claims/authnmethodsreferences");
                        $i1.Add("authmethod", "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod"/*ClaimTypes.AuthenticationMethod*/);
                        $i1.Add("certapppolicy", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/applicationpolicy");
                        $i1.Add("certauthoritykeyidentifier", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/authoritykeyidentifier");
                        $i1.Add("certbasicconstraints", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/basicconstraints");
                        $i1.Add("certeku", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/eku");
                        $i1.Add("certissuer", "http://schemas.microsoft.com/2012/12/certificatecontext/field/issuer");
                        $i1.Add("certissuername", "http://schemas.microsoft.com/2012/12/certificatecontext/field/issuername");
                        $i1.Add("certkeyusage", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/keyusage");
                        $i1.Add("certnotafter", "http://schemas.microsoft.com/2012/12/certificatecontext/field/notafter");
                        $i1.Add("certnotbefore", "http://schemas.microsoft.com/2012/12/certificatecontext/field/notbefore");
                        $i1.Add("certpolicy", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatepolicy");
                        $i1.Add("certpublickey", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa"/*ClaimTypes.Rsa*/);
                        $i1.Add("certrawdata", "http://schemas.microsoft.com/2012/12/certificatecontext/field/rawdata");
                        $i1.Add("certserialnumber", "http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber"/*ClaimTypes.SerialNumber*/);
                        $i1.Add("certsignaturealgorithm", "http://schemas.microsoft.com/2012/12/certificatecontext/field/signaturealgorithm");
                        $i1.Add("certsubject", "http://schemas.microsoft.com/2012/12/certificatecontext/field/subject");
                        $i1.Add("certsubjectaltname", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/san");
                        $i1.Add("certsubjectkeyidentifier", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/subjectkeyidentifier");
                        $i1.Add("certsubjectname", "http://schemas.microsoft.com/2012/12/certificatecontext/field/subjectname");
                        $i1.Add("certtemplateinformation", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatetemplateinformation");
                        $i1.Add("certtemplatename", "http://schemas.microsoft.com/2012/12/certificatecontext/extension/certificatetemplatename");
                        $i1.Add("certthumbprint", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint"/*ClaimTypes.Thumbprint*/);
                        $i1.Add("certx509version", "http://schemas.microsoft.com/2012/12/certificatecontext/field/x509version");
                        $i1.Add("clientapplication", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application");
                        $i1.Add("clientip", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-ip");
                        $i1.Add("clientuseragent", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-user-agent");
                        $i1.Add("commonname", "http://schemas.xmlsoap.org/claims/CommonName");
                        $i1.Add("denyonlyprimarygroupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid"/*ClaimTypes.DenyOnlyPrimaryGroupSid*/);
                        $i1.Add("denyonlyprimarysid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid"/*ClaimTypes.DenyOnlyPrimarySid*/);
                        $i1.Add("denyonlysid", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid"/*ClaimTypes.DenyOnlySid*/);
                        $i1.Add("devicedispname", "http://schemas.microsoft.com/2012/01/devicecontext/claims/displayname");
                        $i1.Add("deviceid", "http://schemas.microsoft.com/2012/01/devicecontext/claims/identifier");
                        $i1.Add("deviceismanaged", "http://schemas.microsoft.com/2012/01/devicecontext/claims/ismanaged");
                        $i1.Add("deviceostype", "http://schemas.microsoft.com/2012/01/devicecontext/claims/ostype");
                        $i1.Add("deviceosver", "http://schemas.microsoft.com/2012/01/devicecontext/claims/osversion");
                        $i1.Add("deviceowner", "http://schemas.microsoft.com/2012/01/devicecontext/claims/userowner");
                        $i1.Add("deviceregid", "http://schemas.microsoft.com/2012/01/devicecontext/claims/registrationid");
                        $i1.Add("endpointpath", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path");
                        $i1.Add("forwardedclientip", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip");
                        $i1.Add("group", "http://schemas.xmlsoap.org/claims/Group");
                        $i1.Add("groups", "http://schemas.microsoft.com/ws/2008/06/identity/claims/groups");
                        $i1.Add("groupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid"/*ClaimTypes.GroupSid*/);
                        $i1.Add("idp", "http://schemas.microsoft.com/identity/claims/identityprovider");
                        $i1.Add("insidecorporatenetwork", "http://schemas.microsoft.com/ws/2012/01/insidecorporatenetwork");
                        $i1.Add("isregistereduser", "http://schemas.microsoft.com/2012/01/devicecontext/claims/isregistereduser");
                        $i1.Add("ppid", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/privatepersonalidentifier");
                        $i1.Add("primarygroupsid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid"/*ClaimTypes.PrimaryGroupSid*/);
                        $i1.Add("primarysid", "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid"/*ClaimTypes.PrimarySid*/);
                        $i1.Add("proxy", "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy");
                        $i1.Add("pwdchgurl", "http://schemas.microsoft.com/ws/2012/01/passwordchangeurl");
                        $i1.Add("pwdexpdays", "http://schemas.microsoft.com/ws/2012/01/passwordexpirationdays");
                        $i1.Add("pwdexptime", "http://schemas.microsoft.com/ws/2012/01/passwordexpirationtime");
                        $i1.Add("relyingpartytrustid", "http://schemas.microsoft.com/2012/01/requestcontext/claims/relyingpartytrustid");
                        $i1.Add("role", "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/);
                        $i1.Add("roles", "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/);
                        $i1.Add("upn", "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn"/*ClaimTypes.Upn*/);
                        $i1.Add("winaccountname", "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname"/*ClaimTypes.WindowsAccountName*/);
                        return $i1;
                    })();
                }
                {
                    this.longToShortClaimTypeMapping = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
                }
                {
                    this.inboundClaimFilter = $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.inboundClaimFilter = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$1();
                }
            }
            static $h = 130333;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":25769934109,"f":50331681},"n":"InboundClaimTypeMap","d":130333,"h":21474966813,"f":2097185},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":34359868701,"f":50331681},"n":"OutboundClaimTypeMap","d":130333,"h":30064901405,"f":2097185},{"p":$.$$.System.Collections.Generic.ISet$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":42949803293,"f":50331681},"n":"InboundClaimFilter","d":130333,"h":38654835997,"f":2097185}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"shortToLongClaimTypeMapping","d":130333,"h":4295097629,"f":4194338},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"longToShortClaimTypeMapping","d":130333,"h":8590064925,"f":4194338},{"t":$.$$.System.Collections.Generic.HashSet$$($.$$.System.String).$h,"n":"inboundClaimFilter","d":130333,"h":12885032221,"f":4194338}],"h":130333}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping`; }
        });
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet", ($self) => class JsonClaimSet extends $.$$.System.Object
        {
            /*string*/ static ClassName = null;
            /*Lock*/ _claimsLock = null;
            /*Dictionary<string, object>*/ _jsonClaims = null;
            /*List<Claim>*/ _claims = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._jsonClaims = (() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                        return $t1;
                    })();
                }
                return this;
            }
            $ctor$2(/*Dictionary<string, object>*/ jsonClaims)
            {
                super.$ctor();
                {
                    this._jsonClaims = jsonClaims;
                }
                return this;
            }
            /*List<Claim> */ Claims(/*string*/ issuer)
            {
                if (this._claims === null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._claimsLock)
                        this._claims ??= this.CreateClaims(issuer);
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._claimsLock)
                    }
                }
                return this._claims;
            }
            /*List<Claim> */ CreateClaims(/*string*/ issuer)
            {
                /*var*/ let claims = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$3(this._jsonClaims.Count);
                var $en2 = this._jsonClaims.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromObject(claims, kvp.Key, kvp.Value, issuer);
                    }
                }
                return claims;
            }
            static /*void */ CreateClaimFromObject(/*List<Claim>*/ claims, /*string*/ claimType, /*object*/ value, /*string*/ issuer)
            {
                let str;
                let i;
                let l;
                let b;
                let d;
                let dt;
                let f;
                let m;
                let iList;
                let j;
                if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, str, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetStringClaimValueType(str, claimType), issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Int32, { set $v(v){ i = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Int32.ToString$1.call(i, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Int64, { set $v(v){ l = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Int64.ToString$1.call(l, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Boolean, { set $v(v){ b = v; } }))
                {
                    if (b)
                    {
                        claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                    }
                    else 
                    {
                        claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                    }
                }
                else if ($.$is(value, $.$$.System.Double, { set $v(v){ d = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Double.ToString$1.call(d, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.DateTime, { set $v(v){ dt = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, dt.ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Single, { set $v(v){ f = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Single.ToString$1.call(f, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Decimal, { set $v(v){ m = v; } }))
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, m.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer));
                }
                else if (value === null)
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer));
                }
                else if ($.$is(value, $.$$.System.Collections.IList, { set $v(v){ iList = v; } }))
                {
                    var $en3 = iList.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromObject(claims, claimType, item, issuer);
                        }
                    }
                }
                else if ($.$is(value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ j = v; } }))
                {
                    if (j.ValueKind === 2/*JsonValueKind.Array*/)
                    {
                        var $en4 = j.EnumerateArray().GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var jsonElement = $en4.Current;
                            {
                                /*Claim*/ let claim = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, jsonElement);
                                if (claim !== null)
                                {
                                    claims.Add(claim);
                                }
                            }
                        }
                    }
                    else 
                    {
                        /*Claim*/ let claim = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, j);
                        if (claim !== null)
                        {
                            claims.Add(claim);
                        }
                    }
                }
                else 
                {
                    claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Object.ToString.call(value), "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, issuer, issuer));
                }
            }
            static /*Claim */ CreateClaimFromJsonElement(/*string*/ claimType, /*string*/ issuer, /*JsonElement*/ jsonElement)
            {
                if (jsonElement.ValueKind === 3/*JsonValueKind.String*/)
                {
                    /*string*/ let claimValue = $.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement);
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, claimValue, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetStringClaimValueType(claimValue, claimType), issuer, issuer);
                }
                else if (jsonElement.ValueKind === 7/*JsonValueKind.Null*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 1/*JsonValueKind.Object*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement), "JSON"/*JsonClaimValueTypes.Json*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 6/*JsonValueKind.False*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 5/*JsonValueKind.True*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer);
                }
                else if (jsonElement.ValueKind === 4/*JsonValueKind.Number*/)
                {
                    /*int*/ let i;
                    /*long*/ let l;
                    /*double*/ let d;
                    /*uint*/ let u;
                    /*ulong*/ let ul;
                    /*float*/ let f;
                    /*decimal*/ let m;
                    if (jsonElement.TryGetInt32($.$ref(() => i, ($v) => i = $v, $.$$.System.Int32)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Int32.ToString$1.call(i, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetInt64($.$ref(() => l, ($v) => l = $v, $.$$.System.Int64)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Int64.ToString$1.call(l, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetDouble($.$ref(() => d, ($v) => d = $v, $.$$.System.Double)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Double.ToString$1.call(d, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetUInt32($.$ref(() => u, ($v) => u = $v, $.$$.System.UInt32)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.UInt32.ToString$1.call(u, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#uinteger32"/*ClaimValueTypes.UInteger32*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetUInt64($.$ref(() => ul, ($v) => ul = $v, $.$$.System.UInt64)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.UInt64.ToString$1.call(ul, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#uinteger64"/*ClaimValueTypes.UInteger64*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetSingle($.$ref(() => f, ($v) => f = $v, $.$$.System.Single)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$$.System.Single.ToString$1.call(f, $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                    else if (jsonElement.TryGetDecimal($.$ref(() => m, ($v) => m = $v, $.$$.System.Decimal)))
                    {
                        return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, m.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/, issuer, issuer);
                    }
                }
                else if (jsonElement.ValueKind === 2/*JsonValueKind.Array*/)
                {
                    return new $.$ssc.System.Security.Claims.Claim().$ctor$5(claimType, $.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement), "JSON_ARRAY"/*JsonClaimValueTypes.JsonArray*/, issuer, issuer);
                }
                return null;
            }
            /*Claim */ GetClaim(/*string*/ key, /*string*/ issuer)
            {
                if ($.$$.System.String.op_Equality(key, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                }
                if (this._jsonClaims.TryGetValue(key, $.$discardRef()))
                {
                    var $en3 = this.Claims(issuer).GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var claim = $en3.Current;
                        {
                            if ($.$$.System.String.op_Equality(claim.Type, key))
                            {
                                return claim;
                            }
                        }
                    }
                }
                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet."/*LogMessages.IDX14304*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ key ], null, null))));
            }
            /*string */ GetStringValue(/*string*/ key)
            {
                /*object*/ let obj;
                if (this._jsonClaims.TryGetValue(key, $.$ref(() => obj, ($v) => obj = $v, $.$$.System.Object)))
                {
                    if (obj === null)
                    {
                        return null;
                    }
                    return $.$$.System.Object.ToString.call(obj);
                }
                return $.$$.System.String.Empty;
            }
            /*DateTime */ GetDateTime(/*string*/ key)
            {
                /*bool*/ let found;
                /*long*/ let l = this.GetValue($.$$.System.Int64, key, false, $.$ref(() => found, ($v) => found = $v, $.$$.System.Boolean));
                if (found)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime(l);
                }
                return $.$$.System.DateTime.MinValue;
            }
            /*T */ GetValue$1(T, /*string*/ key)
            {
                return this.GetValue(T, key, true, $.$discardRef());
            }
            /*T */ GetValue(T, /*string*/ key, /*bool*/ throwEx, /*out bool*/ found)
            {
                /*object*/ let obj;
                found.$v = this._jsonClaims.TryGetValue(key, $.$ref(() => obj, ($v) => obj = $v, $.$$.System.Object));
                if (!found.$v)
                {
                    return throwEx ? (() =>
                    {
        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14304: Claim with name '{0}' does not exist in the JsonClaimSet."/*LogMessages.IDX14304*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ key ], null, null))))            })() : $.$default(T);
                }
                if (obj === null)
                {
                    if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Object.$type) || T.$type.IsClass || $.$$.System.Type.op_Inequality$1($.$$.System.Nullable.GetUnderlyingType(T.$type), null))
                    {
                        return $.$cast(null, T);
                    }
                    else 
                    {
                        return $.$default(T);
                    }
                }
                /*Type*/ let objType = $.$$.System.Object.GetType.call(obj);
                if ($.$$.System.Type.op_Equality$1(T.$type, objType))
                {
                    return $.$cast((obj), T);
                }
                if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Object.$type))
                {
                    return $.$cast(obj, T);
                }
                let jsonElement;
                if ($.$is(obj, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonElement = v; } }))
                {
                    /*T*/ let t;
                    if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.TryCreateTypeFromJsonElement(T, jsonElement, $.$ref(() => t, ($v) => t = $v, T)))
                    {
                        return t;
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.String.$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture)), T);
                    }
                    let list;
                    if ($.$is(obj, $.$$.System.Collections.Generic.List$$($.$$.System.String), { set $v(v){ list = v; } }))
                    {
                        if (list.Count === 1)
                        {
                            return $.$cast(((list.get_Item(0))), T);
                        }
                    }
                    else 
                    {
                        return $.$cast(($.$$.System.Object.ToString.call(obj)), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Boolean.$type))
                {
                    /*bool*/ let value;
                    if ($.$$.System.Boolean.TryParse$1($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Boolean)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Boolean), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Int32.$type))
                {
                    /*int*/ let value;
                    if ($.$$.System.Int32.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Int32)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Int32), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Int64.$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int32.$type))
                    {
                        return $.$cast($.$box($.$cast($.$cast(obj, $.$$.System.Int32), $.$$.System.Int64), $.$$.System.Int64), T);
                    }
                    /*long*/ let value;
                    if ($.$$.System.Int64.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Int64)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Int64), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$typeArray($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [$.$cast(obj, $.$$.System.String)], [-1], null), $.$$.System.Object), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture)], [-1], null), $.$$.System.Object), T);
                    }
                    return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [$.$$.System.Object.ToString.call(obj)], [-1], null), $.$$.System.Object), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.Generic.List$$($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add($.$cast(obj, $.$$.System.String));
                            return $i2;
                        })(), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add(($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            return $i2;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add($.$$.System.Object.ToString.call(obj));
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add($.$cast(obj, $.$$.System.String));
                            return $i2;
                        })(), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add(($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            return $i2;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                        const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add($.$$.System.Object.ToString.call(obj));
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.Generic.IList$$($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add($.$cast(obj, $.$$.System.String));
                            return $i2;
                        })(), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add(($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            return $i2;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add($.$$.System.Object.ToString.call(obj));
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.Generic.ICollection$$($.$$.System.String).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.String.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add($.$cast(obj, $.$$.System.String));
                            return $i2;
                        })(), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                    {
                        return $.$cast((() =>
                        {
                            //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                            const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Add(($.$cast(obj, $.$$.System.DateTime)).ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            return $i2;
                        })(), T);
                    }
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String)()
                        const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add($.$$.System.Object.ToString.call(obj));
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$typeArray($.$$.System.Object).$type))
                {
                    return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [obj], [-1], null), $.$$.System.Object), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.Generic.List$$($.$$.System.Object).$type))
                {
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.Object)()
                        const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add(obj);
                        return $i2;
                    })(), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.Object).$type))
                {
                    return $.$cast((() =>
                    {
                        //new $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.Object)()
                        const $t2 = $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add(obj);
                        return $i2;
                    })(), T);
                }
                else if (T.$type.IsEnum)
                {
                    return $.$cast($.$$.System.Enum.Parse$2(T.$type, $.$$.System.Object.ToString.call(obj), true), T);
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.DateTime.$type))
                {
                    /*DateTime*/ let value;
                    if ($.$$.System.DateTime.TryParse$5($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.DateTime)))
                    {
                        return $.$cast($.$cast(value, $.$$.System.Object), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$typeArray($.$$.System.Int32).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int32.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), [$.$cast(obj, $.$$.System.Int32)], [-1], null), $.$$.System.Object), T);
                    }
                    /*int*/ let value;
                    if ($.$$.System.Int32.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Int32)))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), [value], [-1], null), $.$$.System.Object), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$typeArray($.$$.System.Int64).$type))
                {
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int64.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), [$.$cast(obj, $.$$.System.Int64)], [-1], null), $.$$.System.Object), T);
                    }
                    if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int32.$type))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), [BigInt($.$cast(obj, $.$$.System.Int32))], [-1], null), $.$$.System.Object), T);
                    }
                    /*long*/ let value;
                    if ($.$$.System.Int64.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Int64)))
                    {
                        return $.$cast($.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), [value], [-1], null), $.$$.System.Object), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Double.$type))
                {
                    /*double*/ let value;
                    if ($.$$.System.Double.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Double)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Double), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.UInt32.$type))
                {
                    /*uint*/ let value;
                    if ($.$$.System.UInt32.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.UInt32)))
                    {
                        return $.$cast($.$box(value, $.$$.System.UInt32), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.UInt64.$type))
                {
                    /*ulong*/ let value;
                    if ($.$$.System.UInt64.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.UInt64)))
                    {
                        return $.$cast($.$box(value, $.$$.System.UInt64), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Single.$type))
                {
                    /*float*/ let value;
                    if ($.$$.System.Single.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Single)))
                    {
                        return $.$cast($.$box(value, $.$$.System.Single), T);
                    }
                }
                else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Decimal.$type))
                {
                    /*decimal*/ let value;
                    if ($.$$.System.Decimal.TryParse$8($.$$.System.Object.ToString.call(obj), $.$ref(() => value, ($v) => value = $v, $.$$.System.Decimal)))
                    {
                        return $.$cast($.$cast(value, $.$$.System.Object), T);
                    }
                }
                found.$v = false;
                if (throwEx)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'."/*LogMessages.IDX14305*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(T.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(objType), $.$$.System.Object.ToString.call(obj) ], null, null))));
                }
                else 
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14305: Unable to convert the '{0}' json property to the following type: '{1}'. Property type was: '{2}'. Value: '{3}'."/*LogMessages.IDX14305*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(T.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(objType), $.$$.System.Object.ToString.call(obj) ], null, null))));
                }
                return $.$default(T);
            }
            /*bool */ TryGetClaim(/*string*/ key, /*string*/ issuer, /*out Claim*/ claim)
            {
                claim.$v = null;
                /*object*/ let value;
                if (!this._jsonClaims.TryGetValue(key, $.$ref(() => value, ($v) => value = $v, $.$$.System.Object)))
                {
                    return false;
                }
                var $en2 = this.Claims(issuer).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if ($.$$.System.String.op_Equality(c.Type, key))
                        {
                            claim.$v = c;
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ TryGetValue(T, /*string*/ key, /*out T*/ value)
            {
                /*bool*/ let found;
                value.$v = this.GetValue(T, key, false, $.$ref(() => found, ($v) => found = $v, $.$$.System.Boolean));
                return found;
            }
            /*bool */ HasClaim(/*string*/ claimName)
            {
                return this._jsonClaims.TryGetValue(claimName, $.$discardRef());
            }
            //default member initializer
            constructor()
            {
                super();
                this._claimsLock = new $.$$.System.Threading.Lock().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ClassName = "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet";
                }
            }
            static $h = 195869;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"issuer","p":1310721}],"n":"Claims","d":195869,"h":30064966941,"f":16777224},{"r":$.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"issuer","p":1310721}],"n":"CreateClaims","d":195869,"h":34359934237,"f":16777224},{"r":65537,"p":[{"n":"claims","p":$.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"claimType","p":1310721},{"n":"value","p":131073},{"n":"issuer","p":1310721}],"n":"CreateClaimFromObject","d":195869,"h":38654901533,"f":16777256},{"r":164318,"p":[{"n":"claimType","p":1310721},{"n":"issuer","p":1310721},{"n":"jsonElement","p":2143171}],"n":"CreateClaimFromJsonElement","d":195869,"h":42949868829,"f":16777256},{"r":164318,"p":[{"n":"key","p":1310721},{"n":"issuer","p":1310721}],"n":"GetClaim","d":195869,"h":47244836125,"f":16777224},{"r":1310721,"p":[{"n":"key","p":1310721}],"n":"GetStringValue","d":195869,"h":51539803421,"f":16777224},{"r":34275329,"p":[{"n":"key","p":1310721}],"n":"GetDateTime","d":195869,"h":55834770717,"f":16777224},{"r":(T) => T.$h,"p":[{"n":"key","p":1310721}],"g":["T"],"n":"GetValue","o":"@$1","d":195869,"h":60129738013,"f":16908296},{"r":(T) => T.$h,"p":[{"n":"key","p":1310721},{"n":"throwEx","p":262145},{"n":"found","p":262145,"f":2}],"g":["T"],"n":"GetValue","d":195869,"h":64424705309,"f":16908296},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"issuer","p":1310721},{"n":"claim","p":164318,"f":2}],"n":"TryGetClaim","d":195869,"h":68719672605,"f":16777224},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":(T) => T.$h,"f":2}],"g":["T"],"n":"TryGetValue","d":195869,"h":73014639901,"f":16908296},{"r":262145,"p":[{"n":"claimName","p":1310721}],"n":"HasClaim","d":195869,"h":77309607197,"f":16777224}],"l":[{"t":1310721,"n":"ClassName","d":195869,"h":4295163165,"f":4194344},{"t":127533057,"n":"_claimsLock","d":195869,"h":8590130461,"f":4194312},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,"n":"_jsonClaims","d":195869,"h":12885097757,"f":4194312},{"t":$.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,"n":"_claims","d":195869,"h":17180065053,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":195869,"h":21475032349,"f":16777224},{"p":[{"n":"jsonClaims","p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":".ctor","o":"$ctor$2","d":195869,"h":25769999645,"f":16777224}],"h":195869}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet`; }
        });
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities", ($self) => class JwtTokenUtilities extends $.$$.System.Object
        {
            static /*global::System.Text.RegularExpressions.Regex */ CreateJwsRegex()
            {
                return $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.Instance;
            }
            static /*global::System.Text.RegularExpressions.Regex */ CreateJweRegex()
            {
                return $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.Instance;
            }
            static /*ValidationResult<string, ValidationError> */ DecryptJwtToken(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*JwtTokenDecryptionParameters*/ decryptionParameters, /*CallContext*/ callContext)
            {
                if (validationParameters === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 34, 1)));
                }
                if (decryptionParameters === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("decryptionParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 43, 1)));
                }
                /*bool*/ let decryptionSucceeded = false;
                /*bool*/ let algorithmNotSupportedByCryptoProvider = false;
                /*byte[]*/ let decryptedTokenBytes = null;
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*string*/ let zipAlgorithm = null;
                var $en2 = decryptionParameters.Keys$1.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                        if (cryptoProviderFactory === null)
                        {
                            continue;
                        }
                        try
                        {
                            if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Enc, key))
                            {
                                algorithmNotSupportedByCryptoProvider = true;
                                continue;
                            }
                            /*ValidationResult<string, ValidationError>*/ let result = validationParameters.AlgorithmValidator.Microsoft$IdentityModel$Tokens$Experimental$IAlgorithmValidator$ValidateAlgorithm(zipAlgorithm, jsonWebToken, validationParameters, callContext);
                            if (!result.Succeeded)
                            {
                                (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(result.Error.MessageDetail.Message);
                                continue;
                            }
                            decryptedTokenBytes = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptToken(cryptoProviderFactory, key, jsonWebToken.Enc, jsonWebToken.CipherTextBytes, jsonWebToken.HeaderAsciiBytes, jsonWebToken.InitializationVectorBytes, jsonWebToken.AuthenticationTagBytes);
                            zipAlgorithm = jsonWebToken.Zip;
                            decryptionSucceeded = true;
                            break;
                        }
                        catch(ex)
                        {
                            (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                        }
                        if (key !== null)
                        {
                            (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(key.KeyId);
                        }
                    }
                }
                if (!decryptionSucceeded)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetDecryptionError(decryptionParameters, algorithmNotSupportedByCryptoProvider, exceptionStrings, keysAttempted, callContext));
                }
                try
                {
                    /*string*/ let decodedString;
                    if ($.$$.System.String.IsNullOrEmpty(zipAlgorithm))
                    {
                        decodedString = $.$$.System.Text.Encoding.UTF8.GetString$1(decryptedTokenBytes);
                    }
                    else 
                    {
                        decodedString = decryptionParameters.DecompressionFunction.Invoke(decryptedTokenBytes, zipAlgorithm, decryptionParameters.MaximumDeflateSize);
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit$1(decodedString);
                }
                catch(ex)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$1(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$2($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetIDX10679LogMessage(zipAlgorithm)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecompressionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 143, 1), ex));
                }
            }
            static /*ValidationError */ GetDecryptionError(/*JwtTokenDecryptionParameters*/ decryptionParameters, /*bool*/ algorithmNotSupportedByCryptoProvider, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted, /*CallContext*/ callContext)
            {
                if (!(keysAttempted === null))
                {
                    const $t1 = exceptionStrings;
                    return new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10603: Decryption failed. Keys tried: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'"/*TokenLogMessages.IDX10603*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Text.StringBuilder.ToString.call(keysAttempted)), $.$ifnn($t1, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t)) ?? $.$$.System.String.Empty, $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 167, 1));
                }
                else if (algorithmNotSupportedByCryptoProvider)
                {
                    return new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10619: Decryption failed. Algorithm: '{0}'. Either the Encryption Algorithm: '{1}' or none of the Security Keys are supported by the CryptoProviderFactory."/*TokenLogMessages.IDX10619*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Alg), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Enc) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 180, 1));
                }
                else 
                {
                    return new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JwtTokenUtilities.DecryptTokenResult.cs", 192, 1));
                }
            }
            /*int*/ static _regexMatchTimeoutMilliseconds = 100;
            /*string*/ static _unrecognizedEncodedToken = null;
            /*Regex*/ static RegexJws = null;
            /*Regex*/ static RegexJwe = null;
            /*List<string>*/ static DefaultHeaderParameters = null;
            static /*string */ CreateEncodedSignature$2(/*string*/ input, /*SigningCredentials*/ signingCredentials)
            {
                if ($.$$.System.String.op_Equality(input, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials");
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm);
                if (signatureProvider === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null))));
                }
                try
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(signatureProvider.Sign$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(input)));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            static /*string */ CreateEncodedSignature$1(/*string*/ input, /*SigningCredentials*/ signingCredentials, /*bool*/ cacheProvider)
            {
                if ($.$$.System.String.op_Equality(input, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials");
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = cryptoProviderFactory.CreateForSigning(signingCredentials.Key, signingCredentials.Algorithm, cacheProvider);
                if (signatureProvider === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null))));
                }
                try
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14201: Creating raw signature using the signature credentials. Caching SignatureProvider: '{0}'."/*LogMessages.IDX14201*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(cacheProvider, $.$$.System.Boolean)) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(signatureProvider.Sign$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(input)));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            static /*byte[] */ CreateEncodedSignature(/*byte[]*/ input, /*int*/ offset, /*int*/ count, /*SigningCredentials*/ signingCredentials)
            {
                if (input === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("input");
                }
                if (signingCredentials === null)
                {
                    return null;
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = $.$firstOf(cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm), () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null)))) });
                try
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    }
                    return signatureProvider.Sign(input, offset, count);
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            static /*bool */ CreateSignature(/*ReadOnlySpan<byte>*/ data, /*Span<byte>*/ destination, /*SigningCredentials*/ signingCredentials, /*out int*/ bytesWritten)
            {
                bytesWritten.$v = 0;
                if (signingCredentials === null)
                {
                    return false;
                }
                /*var*/ let cryptoProviderFactory = signingCredentials.CryptoProviderFactory ?? signingCredentials.Key.CryptoProviderFactory;
                /*var*/ let signatureProvider = $.$firstOf(cryptoProviderFactory.CreateForSigning$1(signingCredentials.Key, signingCredentials.Algorithm), () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10637: CryptoProviderFactory.CreateForSigning returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10637*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Key === null ? "Null" : signingCredentials.Key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(signingCredentials.Algorithm) ], null, null)))) });
                try
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX14200: Creating raw signature using the signature credentials."/*LogMessages.IDX14200*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    }
                    return signatureProvider.Sign$2(data, destination, bytesWritten);
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            static /*string */ DecompressToken(/*byte[]*/ tokenBytes, /*string*/ algorithm, /*int*/ maximumDeflateSize)
            {
                if (tokenBytes === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenBytes");
                }
                if ($.$$.System.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("algorithm");
                }
                if (!$.$mit.Microsoft.IdentityModel.Tokens.CompressionProviderFactory.Default.IsSupportedAlgorithm(algorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.NotSupportedException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10682: Compression algorithm '{0}' is not supported."/*TokenLogMessages.IDX10682*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(algorithm) ], null, null))));
                }
                /*var*/ let compressionProvider = $.$mit.Microsoft.IdentityModel.Tokens.CompressionProviderFactory.Default.CreateCompressionProvider(algorithm, maximumDeflateSize);
                /*var*/ let decompressedBytes = compressionProvider.Microsoft$IdentityModel$Tokens$ICompressionProvider$Decompress(tokenBytes);
                return decompressedBytes !== null ? $.$$.System.Text.Encoding.UTF8.GetString$1(decompressedBytes) : (() =>
                {
        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecompressionFailedException().$ctor$14($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetIDX10679LogMessage(algorithm)))        })();
            }
            static /*string */ GetIDX10679LogMessage(/*string*/ algorithm)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10679: Failed to decompress using algorithm '{0}'."/*TokenLogMessages.IDX10679*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(algorithm) ], null, null));
            }
            static /*string */ DecryptJwtToken$1(/*SecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters, /*JwtTokenDecryptionParameters*/ decryptionParameters)
            {
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (decryptionParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("decryptionParameters");
                }
                /*bool*/ let decryptionSucceeded = false;
                /*bool*/ let algorithmNotSupportedByCryptoProvider = false;
                /*byte[]*/ let decryptedTokenBytes = null;
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*string*/ let zipAlgorithm = null;
                var $en2 = decryptionParameters.Keys$1.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                        if (cryptoProviderFactory === null)
                        {
                            if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning("IDX10607: Decryption skipping key: '{0}', both validationParameters.CryptoProviderFactory and key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10607*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                            }
                            continue;
                        }
                        try
                        {
                            if (!cryptoProviderFactory.IsSupportedAlgorithm(decryptionParameters.Enc, key))
                            {
                                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                                {
                                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning("IDX10611: Decryption failed. Encryption is not supported for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10611*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Enc), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                                }
                                algorithmNotSupportedByCryptoProvider = true;
                                continue;
                            }
                            $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAlgorithm(decryptionParameters.Enc, key, securityToken, validationParameters);
                            decryptedTokenBytes = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptToken(cryptoProviderFactory, key, decryptionParameters.Enc, decryptionParameters.CipherTextBytes, decryptionParameters.HeaderAsciiBytes, decryptionParameters.InitializationVectorBytes, decryptionParameters.AuthenticationTagBytes);
                            zipAlgorithm = decryptionParameters.Zip;
                            decryptionSucceeded = true;
                            break;
                        }
                        catch(ex)
                        {
                            (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                        }
                        if (key !== null)
                        {
                            (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(key.KeyId);
                        }
                    }
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ValidateDecryption(decryptionParameters, decryptionSucceeded, algorithmNotSupportedByCryptoProvider, exceptionStrings, keysAttempted);
                try
                {
                    if ($.$$.System.String.IsNullOrEmpty(zipAlgorithm))
                    {
                        return $.$$.System.Text.Encoding.UTF8.GetString$1(decryptedTokenBytes);
                    }
                    return decryptionParameters.DecompressionFunction.Invoke(decryptedTokenBytes, zipAlgorithm, decryptionParameters.MaximumDeflateSize);
                }
                catch(ex)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecompressionFailedException().$ctor$13($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetIDX10679LogMessage(zipAlgorithm), ex));
                }
            }
            static /*void */ ValidateDecryption(/*JwtTokenDecryptionParameters*/ decryptionParameters, /*bool*/ decryptionSucceeded, /*bool*/ algorithmNotSupportedByCryptoProvider, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted)
            {
                if (!decryptionSucceeded && !(keysAttempted === null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10603: Decryption failed. Keys tried: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'"/*TokenLogMessages.IDX10603*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Text.StringBuilder.ToString.call(keysAttempted)), exceptionStrings ?? $.$$.System.String.Empty, $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                }
                if (!decryptionSucceeded && algorithmNotSupportedByCryptoProvider)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10619: Decryption failed. Algorithm: '{0}'. Either the Encryption Algorithm: '{1}' or none of the Security Keys are supported by the CryptoProviderFactory."/*TokenLogMessages.IDX10619*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Alg), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(decryptionParameters.Enc) ], null, null))));
                }
                if (!decryptionSucceeded)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDecryptionFailedException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(decryptionParameters.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                }
            }
            static /*byte[] */ DecryptToken(/*CryptoProviderFactory*/ cryptoProviderFactory, /*SecurityKey*/ key, /*string*/ encAlg, /*byte[]*/ ciphertext, /*byte[]*/ headerAscii, /*byte[]*/ initializationVector, /*byte[]*/ authenticationTag)
            {
                let decryptionProvider = null;
                try
                {
                    decryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(key, encAlg);
                    if (decryptionProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10610: Decryption failed. Could not create decryption provider. Key: '{0}', Algorithm: '{1}'."/*TokenLogMessages.IDX10610*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encAlg) ], null, null))));
                    }
                    return decryptionProvider.Decrypt(ciphertext, headerAscii, initializationVector, authenticationTag);
                }
                finally
                {
                    decryptionProvider?.System$IDisposable$Dispose();
                }
            }
            static /*byte[] */ GenerateKeyBytes(/*int*/ sizeInBits)
            {
                /*byte[]*/ let key = null;
                if (sizeInBits !== 256 && sizeInBits !== 384 && sizeInBits !== 512)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$13("IDX10401: Invalid requested key size. Valid key sizes are: 256, 384, and 512."/*TokenLogMessages.IDX10401*/, "sizeInBits"));
                }
                let aes = null;
                try
                {
                    aes = $.$sscr.System.Security.Cryptography.Aes.Create$2();
                    /*int*/ let halfSizeInBytes = sizeInBits >> 4;
                    key = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [halfSizeInBytes << 1], null);
                    aes.KeySize = sizeInBits >> 1;
                    aes.GenerateKey();
                    $.$$.System.Array.Copy(aes.Key, key, halfSizeInBytes);
                    aes.GenerateKey();
                    $.$$.System.Array.Copy$2(aes.Key, 0, key, halfSizeInBytes, halfSizeInBytes);
                }
                finally
                {
                    aes?.System$IDisposable$Dispose();
                }
                return key;
            }
            static /*SecurityKey */ GetSecurityKey(/*EncryptingCredentials*/ encryptingCredentials, /*CryptoProviderFactory*/ cryptoProviderFactory, /*IDictionary<string, object>*/ additionalHeaderClaims, /*out byte[]*/ wrappedKey)
            {
                /*SecurityKey*/ let securityKey = null;
                /*KeyWrapProvider*/ let kwProvider = null;
                wrappedKey.$v = null;
                if ($.$$.System.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg))
                {
                    if (!cryptoProviderFactory.IsSupportedAlgorithm(encryptingCredentials.Enc, encryptingCredentials.Key))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10615: Encryption failed. No support for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10615*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null))));
                    }
                    securityKey = encryptingCredentials.Key;
                }
                else if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(encryptingCredentials.Alg, [$.$$.System.String]))
                {
                    /*string*/ let apu = null, apv = null;
                    if (additionalHeaderClaims !== null && additionalHeaderClaims.System$Collections$Generic$ICollection$$$Count > 0)
                    {
                        /*object*/ let objApu;
                        if (additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$TryGetValue("apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => objApu, ($v) => objApu = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                        {
                            const $t2 = objApu;
                            apu = $.$ifnn($t2, ($t) => $.$$.System.Object.ToString.call($t));
                        }
                        /*object*/ let objApv;
                        if (additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$TryGetValue("apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => objApv, ($v) => objApv = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                        {
                            const $t3 = objApv;
                            apv = $.$ifnn($t3, ($t) => $.$$.System.Object.ToString.call($t));
                        }
                    }
                    /*EcdhKeyExchangeProvider*/ let ecdhKeyExchangeProvider = new $.$mit.Microsoft.IdentityModel.Tokens.EcdhKeyExchangeProvider().$ctor$1($.$as(encryptingCredentials.Key, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey), encryptingCredentials.KeyExchangePublicKey, encryptingCredentials.Alg, encryptingCredentials.Enc);
                    /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                    kwProvider = cryptoProviderFactory.CreateKeyWrapProvider$1(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                    if ($.$$.System.String.Equals$4.call("A128KW"/*SecurityAlgorithms.Aes128KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(256));
                    }
                    else if ($.$$.System.String.Equals$4.call("A192KW"/*SecurityAlgorithms.Aes192KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(384));
                    }
                    else if ($.$$.System.String.Equals$4.call("A256KW"/*SecurityAlgorithms.Aes256KW*/, kwProvider.Algorithm, 4/*StringComparison.Ordinal*/))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(512));
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10617: Encryption failed. Keywrap is only supported for: '{0}', '{1}' and '{2}'. The content encryption specified is: '{3}'."/*TokenLogMessages.IDX10617*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A128KW"/*SecurityAlgorithms.Aes128KW*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A192KW"/*SecurityAlgorithms.Aes192KW*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A256KW"/*SecurityAlgorithms.Aes256KW*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(kwProvider.Algorithm) ], null, null))));
                    }
                    wrappedKey.$v = kwProvider.WrapKey(($.$cast(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey)).Key);
                }
                else 
                {
                    if (!cryptoProviderFactory.IsSupportedAlgorithm(encryptingCredentials.Alg, encryptingCredentials.Key))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10615: Encryption failed. No support for: Algorithm: '{0}', SecurityKey: '{1}'."/*TokenLogMessages.IDX10615*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Alg), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null))));
                    }
                    if ($.$$.System.String.Equals$5.call("A128CBC-HS256"/*SecurityAlgorithms.Aes128CbcHmacSha256*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(256));
                    }
                    else if ($.$$.System.String.Equals$5.call("A192CBC-HS384"/*SecurityAlgorithms.Aes192CbcHmacSha384*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(384));
                    }
                    else if ($.$$.System.String.Equals$5.call("A256CBC-HS512"/*SecurityAlgorithms.Aes256CbcHmacSha512*/, encryptingCredentials.Enc))
                    {
                        securityKey = new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GenerateKeyBytes(512));
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10617: Encryption failed. Keywrap is only supported for: '{0}', '{1}' and '{2}'. The content encryption specified is: '{3}'."/*TokenLogMessages.IDX10617*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A128CBC-HS256"/*SecurityAlgorithms.Aes128CbcHmacSha256*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A192CBC-HS384"/*SecurityAlgorithms.Aes192CbcHmacSha384*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("A256CBC-HS512"/*SecurityAlgorithms.Aes256CbcHmacSha512*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Enc) ], null, null))));
                    }
                    kwProvider = cryptoProviderFactory.CreateKeyWrapProvider$1(encryptingCredentials.Key, encryptingCredentials.Alg);
                    wrappedKey.$v = kwProvider.WrapKey(($.$cast(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey)).Key);
                }
                return securityKey;
            }
            static /*IEnumerable<SecurityKey> */ GetAllDecryptionKeys(/*TokenValidationParameters*/ validationParameters)
            {
                if (validationParameters === null)
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("validationParameters");
                }
                /*var*/ let decryptionKeys = new ($.$$.System.Collections.ObjectModel.Collection$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey))().$ctor$1();
                if (validationParameters.TokenDecryptionKey !== null)
                {
                    decryptionKeys.Add(validationParameters.TokenDecryptionKey);
                }
                if (validationParameters.TokenDecryptionKeys !== null)
                {
                    var $en3 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            decryptionKeys.Add(key);
                        }
                    }
                }
                return decryptionKeys;
            }
            static /*string */ SafeLogJwtToken(/*object*/ obj)
            {
                if (obj === null)
                {
                    return $.$$.System.String.Empty;
                }
                let token;
                if (!($.$is(obj, $.$$.System.String, { set $v(v){ token = v; } })))
                {
                    return $.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(obj));
                }
                /*int*/ let lastDot = $.$$.System.String.LastIndexOf$2.call(token, /*.*/ 46);
                if (lastDot === -1)
                {
                    return "UnrecognizedEncodedToken"/*_unrecognizedEncodedToken*/;
                }
                return $.$$.System.String.Substring.call(token, 0, lastDot);
            }
            static /*SecurityKey */ ResolveTokenSigningKey$1(/*string*/ kid, /*string*/ x5t, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey(kid, x5t, (configuration?.SigningKeys ?? null)) ?? $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey(kid, x5t, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ConcatSigningKeys(validationParameters));
            }
            static /*SecurityKey */ ResolveTokenSigningKey(/*string*/ kid, /*string*/ x5t, /*IEnumerable<SecurityKey>*/ signingKeys)
            {
                if (signingKeys === null)
                {
                    return null;
                }
                var $en2 = signingKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var signingKey = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (signingKey !== null)
                        {
                            let x509Key;
                            if ($.$is(signingKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey, { set $v(v){ x509Key = v; } }))
                            {
                                if ((!$.$$.System.String.IsNullOrEmpty(kid) && $.$$.System.String.Equals$2(signingKey.KeyId, kid, 5/*StringComparison.OrdinalIgnoreCase*/)) || (!$.$$.System.String.IsNullOrEmpty(x5t) && $.$$.System.String.Equals$2(x509Key.X5t, x5t, 5/*StringComparison.OrdinalIgnoreCase*/)))
                                {
                                    return signingKey;
                                }
                            }
                            else if (!$.$$.System.String.IsNullOrEmpty(signingKey.KeyId))
                            {
                                if ($.$$.System.String.Equals$3(signingKey.KeyId, kid) || $.$$.System.String.Equals$3(signingKey.KeyId, x5t))
                                {
                                    return signingKey;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            static /*int */ CountJwtTokenPart(/*string*/ token, /*int*/ maxCount)
            {
                /*var*/ let count = 1;
                /*var*/ let index = 0;
                while(index < token.length)
                {
                    /*var*/ let dotIndex = $.$$.System.String.IndexOf$1.call(token, /*.*/ 46, index);
                    if (dotIndex < 0)
                    {
                        break;
                    }
                    count++;
                    index = ((dotIndex + 1) | 0);
                    if (count === maxCount)
                    {
                        break;
                    }
                }
                return count;
            }
            static /*IEnumerable<SecurityKey> */ ConcatSigningKeys(/*TokenValidationParameters*/ tvp)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (tvp === null)
                    {
                        return;
                    }
                    yield tvp.IssuerSigningKey;
                    if (tvp.IssuerSigningKeys !== null)
                    {
                        var $en4 = tvp.IssuerSigningKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                yield key;
                            }
                        }
                    }
                }.bind(this));
            }
            static /*string */ GetStringClaimValueType$1(/*string*/ str)
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetStringClaimValueType(str, $.$$.System.String.Empty);
            }
            static /*string */ GetStringClaimValueType(/*string*/ str, /*string*/ claimType)
            {
                if (!$.$$.System.String.IsNullOrEmpty(claimType) && !$.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.TryAllStringClaimsAsDateTime && $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsKnownToNotBeDateTime(claimType))
                {
                    return "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
                }
                /*DateTime*/ let dateTimeValue;
                if ($.$$.System.DateTime.TryParse$5(str, $.$ref(() => dateTimeValue, ($v) => dateTimeValue = $v, $.$$.System.DateTime)))
                {
                    /*string*/ let dtUniversal = dateTimeValue.ToUniversalTime().ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    if ($.$$.System.String.Equals$4.call(dtUniversal, str, 4/*StringComparison.Ordinal*/))
                    {
                        return "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/;
                    }
                }
                return "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._unrecognizedEncodedToken = "UnrecognizedEncodedToken";
                }
                {
                    this.RegexJws = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateJwsRegex();
                }
                {
                    this.RegexJwe = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateJweRegex();
                }
                {
                    this.DefaultHeaderParameters = (() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("alg"/*JwtHeaderParameterNames.Alg*/);
                        $i1.Add("kid"/*JwtHeaderParameterNames.Kid*/);
                        $i1.Add("x5t"/*JwtHeaderParameterNames.X5t*/);
                        $i1.Add("enc"/*JwtHeaderParameterNames.Enc*/);
                        $i1.Add("zip"/*JwtHeaderParameterNames.Zip*/);
                        return $i1;
                    })();
                }
            }
            static $h = 916765;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"decryptionParameters","p":851229},{"n":"callContext","p":1874993}],"n":"DecryptJwtToken","d":916765,"h":4295884061,"f":16777256},{"r":9608241,"p":[{"n":"decryptionParameters","p":851229},{"n":"algorithmNotSupportedByCryptoProvider","p":262145},{"n":"exceptionStrings","p":122814465},{"n":"keysAttempted","p":122814465},{"n":"callContext","p":1874993}],"n":"GetDecryptionError","d":916765,"h":8590851357,"f":16777250},{"r":1943692,"n":"CreateJwsRegex","d":916765,"h":30065687837,"f":16777250,"a":[{"t":1288332,"c":17181157516,"a":[{"v":"^[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]*$","t":1310721},{"v":512,"t":3582092},{"v":100,"t":655361}]},{"t":23592961,"c":12908494849,"a":[{"v":"System.Text.RegularExpressions.Generator","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"r":1943692,"n":"CreateJweRegex","d":916765,"h":34360655133,"f":16777250,"a":[{"t":1288332,"c":17181157516,"a":[{"v":"^[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B\\.[A-Za-z0-9-_]\u002B$","t":1310721},{"v":512,"t":3582092},{"v":100,"t":655361}]},{"t":23592961,"c":12908494849,"a":[{"v":"System.Text.RegularExpressions.Generator","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"r":1310721,"p":[{"n":"input","p":1310721},{"n":"signingCredentials","p":15965233}],"n":"CreateEncodedSignature","o":"@$2","d":916765,"h":42950589725,"f":16777249},{"r":1310721,"p":[{"n":"input","p":1310721},{"n":"signingCredentials","p":15965233},{"n":"cacheProvider","p":262145}],"n":"CreateEncodedSignature","o":"@$1","d":916765,"h":47245557021,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"input","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"signingCredentials","p":15965233}],"n":"CreateEncodedSignature","d":916765,"h":51540524317,"f":16777256},{"r":262145,"p":[{"n":"data","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"signingCredentials","p":15965233},{"n":"bytesWritten","p":655361,"f":2}],"n":"CreateSignature","d":916765,"h":55835491613,"f":16777256},{"r":1310721,"p":[{"n":"tokenBytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"algorithm","p":1310721},{"n":"maximumDeflateSize","p":655361}],"n":"DecompressToken","d":916765,"h":60130458909,"f":16777256},{"r":1310721,"p":[{"n":"algorithm","p":1310721}],"n":"GetIDX10679LogMessage","d":916765,"h":64425426205,"f":16777250},{"r":1310721,"p":[{"n":"securityToken","p":13802545},{"n":"validationParameters","p":16817201},{"n":"decryptionParameters","p":851229}],"n":"DecryptJwtToken","o":"@$1","d":916765,"h":68720393501,"f":16777256},{"r":65537,"p":[{"n":"decryptionParameters","p":851229},{"n":"decryptionSucceeded","p":262145},{"n":"algorithmNotSupportedByCryptoProvider","p":262145},{"n":"exceptionStrings","p":122814465},{"n":"keysAttempted","p":122814465}],"n":"ValidateDecryption","d":916765,"h":73015360797,"f":16777250},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"cryptoProviderFactory","p":2989105},{"n":"key","p":13671473},{"n":"encAlg","p":1310721},{"n":"ciphertext","p":$.$typeArray($.$$.System.Byte).$h},{"n":"headerAscii","p":$.$typeArray($.$$.System.Byte).$h},{"n":"initializationVector","p":$.$typeArray($.$$.System.Byte).$h},{"n":"authenticationTag","p":$.$typeArray($.$$.System.Byte).$h}],"n":"DecryptToken","d":916765,"h":77310328093,"f":16777250},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"sizeInBits","p":655361}],"n":"GenerateKeyBytes","d":916765,"h":81605295389,"f":16777249},{"r":13671473,"p":[{"n":"encryptingCredentials","p":3972145},{"n":"cryptoProviderFactory","p":2989105},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"wrappedKey","p":$.$typeArray($.$$.System.Byte).$h,"f":2}],"n":"GetSecurityKey","d":916765,"h":85900262685,"f":16777256},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,"p":[{"n":"validationParameters","p":16817201}],"n":"GetAllDecryptionKeys","d":916765,"h":90195229981,"f":16777249},{"r":1310721,"p":[{"n":"obj","p":131073}],"n":"SafeLogJwtToken","d":916765,"h":94490197277,"f":16777256},{"r":13671473,"p":[{"n":"kid","p":1310721},{"n":"x5t","p":1310721},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ResolveTokenSigningKey","o":"@$1","d":916765,"h":98785164573,"f":16777256},{"r":13671473,"p":[{"n":"kid","p":1310721},{"n":"x5t","p":1310721},{"n":"signingKeys","p":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h}],"n":"ResolveTokenSigningKey","d":916765,"h":103080131869,"f":16777256},{"r":655361,"p":[{"n":"token","p":1310721},{"n":"maxCount","p":655361}],"n":"CountJwtTokenPart","d":916765,"h":107375099165,"f":16777256},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,"p":[{"n":"tvp","p":16817201}],"n":"ConcatSigningKeys","d":916765,"h":111670066461,"f":16777256},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"GetStringClaimValueType","o":"@$1","d":916765,"h":115965033757,"f":16777256},{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"claimType","p":1310721}],"n":"GetStringClaimValueType","d":916765,"h":120260001053,"f":16777256}],"l":[{"t":655361,"n":"_regexMatchTimeoutMilliseconds","d":916765,"h":12885818653,"f":4194338},{"t":1310721,"n":"_unrecognizedEncodedToken","d":916765,"h":17180785949,"f":4194338},{"t":1943692,"n":"RegexJws","d":916765,"h":21475753245,"f":4194337},{"t":1943692,"n":"RegexJwe","d":916765,"h":25770720541,"f":4194337},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h,"n":"DefaultHeaderParameters","d":916765,"h":38655622429,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$1","d":916765,"h":124554968349,"f":16777217}],"h":916765}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities`; }
        });
        
        $asm.$cls("$mij.System.Text.RegularExpressions.Generated.Utilities", ($self) => class Utilities
        {
            /*SearchValues<char>*/ static s_asciiLettersAndDigitsAndDashUnderscore = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_asciiLettersAndDigitsAndDashUnderscore = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz"));
                }
            }
            static $h = 1441053;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_asciiLettersAndDigitsAndDashUnderscore","d":1441053,"h":4296408349,"f":4194344}],"h":1441053,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"System.Text.RegularExpressions.Generator","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.RegularExpressions.Generated.Utilities`; }
        });
        
        $asm.$str("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtRegisteredClaimNames", ($self) => class JwtRegisteredClaimNames extends $.$$.System.ValueType
        {
            /*string*/ static Act = null;
            /*string*/ static Actort = null;
            /*string*/ static Acr = null;
            /*string*/ static Address = null;
            /*string*/ static Alg = null;
            /*string*/ static Amr = null;
            /*string*/ static Aud = null;
            /*string*/ static AuthTime = null;
            /*string*/ static Azp = null;
            /*string*/ static Birthdate = null;
            /*string*/ static CHash = null;
            /*string*/ static AtHash = null;
            /*string*/ static Email = null;
            /*string*/ static EmailVerified = null;
            /*string*/ static Exp = null;
            /*string*/ static Gender = null;
            /*string*/ static FamilyName = null;
            /*string*/ static GivenName = null;
            /*string*/ static Iat = null;
            /*string*/ static Iss = null;
            /*string*/ static Jti = null;
            /*string*/ static Locale = null;
            /*string*/ static MiddleName = null;
            /*string*/ static Name = null;
            /*string*/ static NameId = null;
            /*string*/ static Nickname = null;
            /*string*/ static Nonce = null;
            /*string*/ static Nbf = null;
            /*string*/ static PhoneNumber = null;
            /*string*/ static PhoneNumberVerified = null;
            /*string*/ static Picture = null;
            /*string*/ static Prn = null;
            /*string*/ static PreferredUsername = null;
            /*string*/ static Profile = null;
            /*string*/ static Sid = null;
            /*string*/ static Sub = null;
            /*string*/ static Typ = null;
            /*string*/ static UniqueName = null;
            /*string*/ static UpdatedAt = null;
            /*string*/ static Website = null;
            /*string*/ static ZoneInfo = null;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Act = "act";
                }
                {
                    this.Actort = "actort";
                }
                {
                    this.Acr = "acr";
                }
                {
                    this.Address = "address";
                }
                {
                    this.Alg = "alg";
                }
                {
                    this.Amr = "amr";
                }
                {
                    this.Aud = "aud";
                }
                {
                    this.AuthTime = "auth_time";
                }
                {
                    this.Azp = "azp";
                }
                {
                    this.Birthdate = "birthdate";
                }
                {
                    this.CHash = "c_hash";
                }
                {
                    this.AtHash = "at_hash";
                }
                {
                    this.Email = "email";
                }
                {
                    this.EmailVerified = "email_verified";
                }
                {
                    this.Exp = "exp";
                }
                {
                    this.Gender = "gender";
                }
                {
                    this.FamilyName = "family_name";
                }
                {
                    this.GivenName = "given_name";
                }
                {
                    this.Iat = "iat";
                }
                {
                    this.Iss = "iss";
                }
                {
                    this.Jti = "jti";
                }
                {
                    this.Locale = "locale";
                }
                {
                    this.MiddleName = "middle_name";
                }
                {
                    this.Name = "name";
                }
                {
                    this.NameId = "nameid";
                }
                {
                    this.Nickname = "nickname";
                }
                {
                    this.Nonce = "nonce";
                }
                {
                    this.Nbf = "nbf";
                }
                {
                    this.PhoneNumber = "phone_number";
                }
                {
                    this.PhoneNumberVerified = "phone_number_verified";
                }
                {
                    this.Picture = "picture";
                }
                {
                    this.Prn = "prn";
                }
                {
                    this.PreferredUsername = "preferred_username";
                }
                {
                    this.Profile = "profile";
                }
                {
                    this.Sid = "sid";
                }
                {
                    this.Sub = "sub";
                }
                {
                    this.Typ = "typ";
                }
                {
                    this.UniqueName = "unique_name";
                }
                {
                    this.UpdatedAt = "updated_at";
                }
                {
                    this.Website = "website";
                }
                {
                    this.ZoneInfo = "zoneinfo";
                }
            }
            static $h = 785693;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1310721,"n":"Act","d":785693,"h":4295752989,"f":4194337},{"t":1310721,"n":"Actort","d":785693,"h":8590720285,"f":4194337},{"t":1310721,"n":"Acr","d":785693,"h":12885687581,"f":4194337},{"t":1310721,"n":"Address","d":785693,"h":17180654877,"f":4194337},{"t":1310721,"n":"Alg","d":785693,"h":21475622173,"f":4194337},{"t":1310721,"n":"Amr","d":785693,"h":25770589469,"f":4194337},{"t":1310721,"n":"Aud","d":785693,"h":30065556765,"f":4194337},{"t":1310721,"n":"AuthTime","d":785693,"h":34360524061,"f":4194337},{"t":1310721,"n":"Azp","d":785693,"h":38655491357,"f":4194337},{"t":1310721,"n":"Birthdate","d":785693,"h":42950458653,"f":4194337},{"t":1310721,"n":"CHash","d":785693,"h":47245425949,"f":4194337},{"t":1310721,"n":"AtHash","d":785693,"h":51540393245,"f":4194337},{"t":1310721,"n":"Email","d":785693,"h":55835360541,"f":4194337},{"t":1310721,"n":"EmailVerified","d":785693,"h":60130327837,"f":4194337},{"t":1310721,"n":"Exp","d":785693,"h":64425295133,"f":4194337},{"t":1310721,"n":"Gender","d":785693,"h":68720262429,"f":4194337},{"t":1310721,"n":"FamilyName","d":785693,"h":73015229725,"f":4194337},{"t":1310721,"n":"GivenName","d":785693,"h":77310197021,"f":4194337},{"t":1310721,"n":"Iat","d":785693,"h":81605164317,"f":4194337},{"t":1310721,"n":"Iss","d":785693,"h":85900131613,"f":4194337},{"t":1310721,"n":"Jti","d":785693,"h":90195098909,"f":4194337},{"t":1310721,"n":"Locale","d":785693,"h":94490066205,"f":4194337},{"t":1310721,"n":"MiddleName","d":785693,"h":98785033501,"f":4194337},{"t":1310721,"n":"Name","d":785693,"h":103080000797,"f":4194337},{"t":1310721,"n":"NameId","d":785693,"h":107374968093,"f":4194337},{"t":1310721,"n":"Nickname","d":785693,"h":111669935389,"f":4194337},{"t":1310721,"n":"Nonce","d":785693,"h":115964902685,"f":4194337},{"t":1310721,"n":"Nbf","d":785693,"h":120259869981,"f":4194337},{"t":1310721,"n":"PhoneNumber","d":785693,"h":124554837277,"f":4194337},{"t":1310721,"n":"PhoneNumberVerified","d":785693,"h":128849804573,"f":4194337},{"t":1310721,"n":"Picture","d":785693,"h":133144771869,"f":4194337},{"t":1310721,"n":"Prn","d":785693,"h":137439739165,"f":4194337},{"t":1310721,"n":"PreferredUsername","d":785693,"h":141734706461,"f":4194337},{"t":1310721,"n":"Profile","d":785693,"h":146029673757,"f":4194337},{"t":1310721,"n":"Sid","d":785693,"h":150324641053,"f":4194337},{"t":1310721,"n":"Sub","d":785693,"h":154619608349,"f":4194337},{"t":1310721,"n":"Typ","d":785693,"h":158914575645,"f":4194337},{"t":1310721,"n":"UniqueName","d":785693,"h":163209542941,"f":4194337},{"t":1310721,"n":"UpdatedAt","d":785693,"h":167504510237,"f":4194337},{"t":1310721,"n":"Website","d":785693,"h":171799477533,"f":4194337},{"t":1310721,"n":"ZoneInfo","d":785693,"h":176094444829,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":785693,"h":180389412125,"f":16777217}],"h":785693}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtRegisteredClaimNames`; }
        });
        
        $asm.$str("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderParameterNames", ($self) => class JwtHeaderParameterNames extends $.$$.System.ValueType
        {
            /*string*/ static Alg = null;
            /*string*/ static Apu = null;
            /*string*/ static Apv = null;
            /*string*/ static Epk = null;
            /*string*/ static Cty = null;
            /*string*/ static Enc = null;
            /*string*/ static IV = null;
            /*string*/ static Jku = null;
            /*string*/ static Jwk = null;
            /*string*/ static Kid = null;
            /*string*/ static Typ = null;
            /*string*/ static X5c = null;
            /*string*/ static X5t = null;
            /*string*/ static X5u = null;
            /*string*/ static Zip = null;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Alg = "alg";
                }
                {
                    this.Apu = "apu";
                }
                {
                    this.Apv = "apv";
                }
                {
                    this.Epk = "epk";
                }
                {
                    this.Cty = "cty";
                }
                {
                    this.Enc = "enc";
                }
                {
                    this.IV = "iv";
                }
                {
                    this.Jku = "jku";
                }
                {
                    this.Jwk = "jwk";
                }
                {
                    this.Kid = "kid";
                }
                {
                    this.Typ = "typ";
                }
                {
                    this.X5c = "x5c";
                }
                {
                    this.X5t = "x5t";
                }
                {
                    this.X5u = "x5u";
                }
                {
                    this.Zip = "zip";
                }
            }
            static $h = 589085;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1310721,"n":"Alg","d":589085,"h":4295556381,"f":4194337},{"t":1310721,"n":"Apu","d":589085,"h":8590523677,"f":4194337},{"t":1310721,"n":"Apv","d":589085,"h":12885490973,"f":4194337},{"t":1310721,"n":"Epk","d":589085,"h":17180458269,"f":4194337},{"t":1310721,"n":"Cty","d":589085,"h":21475425565,"f":4194337},{"t":1310721,"n":"Enc","d":589085,"h":25770392861,"f":4194337},{"t":1310721,"n":"IV","d":589085,"h":30065360157,"f":4194337},{"t":1310721,"n":"Jku","d":589085,"h":34360327453,"f":4194337},{"t":1310721,"n":"Jwk","d":589085,"h":38655294749,"f":4194337},{"t":1310721,"n":"Kid","d":589085,"h":42950262045,"f":4194337},{"t":1310721,"n":"Typ","d":589085,"h":47245229341,"f":4194337},{"t":1310721,"n":"X5c","d":589085,"h":51540196637,"f":4194337},{"t":1310721,"n":"X5t","d":589085,"h":55835163933,"f":4194337},{"t":1310721,"n":"X5u","d":589085,"h":60130131229,"f":4194337},{"t":1310721,"n":"Zip","d":589085,"h":64425098525,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":589085,"h":68720065821,"f":16777217}],"h":589085}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtHeaderParameterNames`; }
        });
        
        $asm.$str("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes", ($self) => class JwtHeaderUtf8Bytes extends $.$$.System.ValueType
        {
            static /*ReadOnlySpan<byte> */ get Alg()
            {
                return this.$cacheAlg ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 108, 103]);
            }
            static /*ReadOnlySpan<byte> */ get Apu()
            {
                return this.$cacheApu ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 112, 117]);
            }
            static /*ReadOnlySpan<byte> */ get Apv()
            {
                return this.$cacheApv ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 112, 118]);
            }
            static /*ReadOnlySpan<byte> */ get Cty()
            {
                return this.$cacheCty ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([99, 116, 121]);
            }
            static /*ReadOnlySpan<byte> */ get Enc()
            {
                return this.$cacheEnc ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([101, 110, 99]);
            }
            static /*ReadOnlySpan<byte> */ get Epk()
            {
                return this.$cacheEpk ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([101, 112, 107]);
            }
            static /*ReadOnlySpan<byte> */ get IV()
            {
                return this.$cacheIV ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([105, 118]);
            }
            static /*ReadOnlySpan<byte> */ get Jku()
            {
                return this.$cacheJku ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([106, 107, 117]);
            }
            static /*ReadOnlySpan<byte> */ get Jwk()
            {
                return this.$cacheJwk ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([106, 119, 107]);
            }
            static /*ReadOnlySpan<byte> */ get Kid()
            {
                return this.$cacheKid ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([107, 105, 100]);
            }
            static /*ReadOnlySpan<byte> */ get Typ()
            {
                return this.$cacheTyp ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([116, 121, 112]);
            }
            static /*ReadOnlySpan<byte> */ get X5c()
            {
                return this.$cacheX5c ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([120, 53, 99]);
            }
            static /*ReadOnlySpan<byte> */ get X5t()
            {
                return this.$cacheX5t ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([120, 53, 116]);
            }
            static /*ReadOnlySpan<byte> */ get X5u()
            {
                return this.$cacheX5u ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([120, 53, 117]);
            }
            static /*ReadOnlySpan<byte> */ get Zip()
            {
                return this.$cacheZip ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([122, 105, 112]);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 654621;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":8590589213,"f":50331681},"n":"Alg","d":654621,"h":4295621917,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":17180523805,"f":50331681},"n":"Apu","d":654621,"h":12885556509,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":25770458397,"f":50331681},"n":"Apv","d":654621,"h":21475491101,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":34360392989,"f":50331681},"n":"Cty","d":654621,"h":30065425693,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":42950327581,"f":50331681},"n":"Enc","d":654621,"h":38655360285,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":51540262173,"f":50331681},"n":"Epk","d":654621,"h":47245294877,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":60130196765,"f":50331681},"n":"IV","d":654621,"h":55835229469,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":68720131357,"f":50331681},"n":"Jku","d":654621,"h":64425164061,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":77310065949,"f":50331681},"n":"Jwk","d":654621,"h":73015098653,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":85900000541,"f":50331681},"n":"Kid","d":654621,"h":81605033245,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":94489935133,"f":50331681},"n":"Typ","d":654621,"h":90194967837,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":103079869725,"f":50331681},"n":"X5c","d":654621,"h":98784902429,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":111669804317,"f":50331681},"n":"X5t","d":654621,"h":107374837021,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":120259738909,"f":50331681},"n":"X5u","d":654621,"h":115964771613,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":128849673501,"f":50331681},"n":"Zip","d":654621,"h":124554706205,"f":2097185}],"c":[{"n":".ctor","o":"$ctor$2","d":654621,"h":133144640797,"f":16777217}],"h":654621}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes`; }
        });
        
        $asm.$str("$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes", ($self) => class JwtPayloadUtf8Bytes extends $.$$.System.ValueType
        {
            static /*ReadOnlySpan<byte> */ get Actort()
            {
                return this.$cacheActort ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 99, 116, 111, 114, 116]);
            }
            static /*ReadOnlySpan<byte> */ get Acr()
            {
                return this.$cacheAcr ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 99, 114]);
            }
            static /*ReadOnlySpan<byte> */ get Amr()
            {
                return this.$cacheAmr ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 109, 114]);
            }
            static /*ReadOnlySpan<byte> */ get AtHash()
            {
                return this.$cacheAtHash ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 116, 95, 104, 97, 115, 104]);
            }
            static /*ReadOnlySpan<byte> */ get Aud()
            {
                return this.$cacheAud ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 117, 100]);
            }
            static /*ReadOnlySpan<byte> */ get AuthTime()
            {
                return this.$cacheAuthTime ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 117, 116, 104, 95, 116, 105, 109, 101]);
            }
            static /*ReadOnlySpan<byte> */ get Azp()
            {
                return this.$cacheAzp ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([97, 122, 112]);
            }
            static /*ReadOnlySpan<byte> */ get Birthdate()
            {
                return this.$cacheBirthdate ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([98, 105, 114, 116, 104, 100, 97, 116, 101]);
            }
            static /*ReadOnlySpan<byte> */ get CHash()
            {
                return this.$cacheCHash ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([99, 95, 104, 97, 115, 104]);
            }
            static /*ReadOnlySpan<byte> */ get Email()
            {
                return this.$cacheEmail ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([101, 109, 97, 105, 108]);
            }
            static /*ReadOnlySpan<byte> */ get Exp()
            {
                return this.$cacheExp ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([101, 120, 112]);
            }
            static /*ReadOnlySpan<byte> */ get Gender()
            {
                return this.$cacheGender ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([103, 101, 110, 100, 101, 114]);
            }
            static /*ReadOnlySpan<byte> */ get FamilyName()
            {
                return this.$cacheFamilyName ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([102, 97, 109, 105, 108, 121, 95, 110, 97, 109, 101]);
            }
            static /*ReadOnlySpan<byte> */ get GivenName()
            {
                return this.$cacheGivenName ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([103, 105, 118, 101, 110, 95, 110, 97, 109, 101]);
            }
            static /*ReadOnlySpan<byte> */ get Iat()
            {
                return this.$cacheIat ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([105, 97, 116]);
            }
            static /*ReadOnlySpan<byte> */ get Iss()
            {
                return this.$cacheIss ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([105, 115, 115]);
            }
            static /*ReadOnlySpan<byte> */ get Jti()
            {
                return this.$cacheJti ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([106, 116, 105]);
            }
            static /*ReadOnlySpan<byte> */ get Name()
            {
                return this.$cacheName ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([110, 97, 109, 101]);
            }
            static /*ReadOnlySpan<byte> */ get NameId()
            {
                return this.$cacheNameId ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([110, 97, 109, 101, 105, 100]);
            }
            static /*ReadOnlySpan<byte> */ get Nonce()
            {
                return this.$cacheNonce ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([110, 111, 110, 99, 101]);
            }
            static /*ReadOnlySpan<byte> */ get Nbf()
            {
                return this.$cacheNbf ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([110, 98, 102]);
            }
            static /*ReadOnlySpan<byte> */ get PhoneNumber()
            {
                return this.$cachePhoneNumber ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([112, 104, 111, 110, 101, 95, 110, 117, 109, 98, 101, 114]);
            }
            static /*ReadOnlySpan<byte> */ get PhoneNumberVerified()
            {
                return this.$cachePhoneNumberVerified ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([112, 104, 111, 110, 101, 95, 110, 117, 109, 98, 101, 114, 95, 118, 101, 114, 105, 102, 105, 101, 100]);
            }
            static /*ReadOnlySpan<byte> */ get Prn()
            {
                return this.$cachePrn ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([112, 114, 110]);
            }
            static /*ReadOnlySpan<byte> */ get Sid()
            {
                return this.$cacheSid ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([115, 105, 100]);
            }
            static /*ReadOnlySpan<byte> */ get Sub()
            {
                return this.$cacheSub ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([115, 117, 98]);
            }
            static /*ReadOnlySpan<byte> */ get Typ()
            {
                return this.$cacheTyp ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([116, 121, 112]);
            }
            static /*ReadOnlySpan<byte> */ get UniqueName()
            {
                return this.$cacheUniqueName ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([117, 110, 105, 113, 117, 101, 95, 110, 97, 109, 101]);
            }
            static /*ReadOnlySpan<byte> */ get Website()
            {
                return this.$cacheWebsite ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([119, 101, 98, 115, 105, 116, 101]);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 720157;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":8590654749,"f":50331681},"n":"Actort","d":720157,"h":4295687453,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":17180589341,"f":50331681},"n":"Acr","d":720157,"h":12885622045,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":25770523933,"f":50331681},"n":"Amr","d":720157,"h":21475556637,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":34360458525,"f":50331681},"n":"AtHash","d":720157,"h":30065491229,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":42950393117,"f":50331681},"n":"Aud","d":720157,"h":38655425821,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":51540327709,"f":50331681},"n":"AuthTime","d":720157,"h":47245360413,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":60130262301,"f":50331681},"n":"Azp","d":720157,"h":55835295005,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":68720196893,"f":50331681},"n":"Birthdate","d":720157,"h":64425229597,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":77310131485,"f":50331681},"n":"CHash","d":720157,"h":73015164189,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":85900066077,"f":50331681},"n":"Email","d":720157,"h":81605098781,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":94490000669,"f":50331681},"n":"Exp","d":720157,"h":90195033373,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":103079935261,"f":50331681},"n":"Gender","d":720157,"h":98784967965,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":111669869853,"f":50331681},"n":"FamilyName","d":720157,"h":107374902557,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":120259804445,"f":50331681},"n":"GivenName","d":720157,"h":115964837149,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":128849739037,"f":50331681},"n":"Iat","d":720157,"h":124554771741,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":137439673629,"f":50331681},"n":"Iss","d":720157,"h":133144706333,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":146029608221,"f":50331681},"n":"Jti","d":720157,"h":141734640925,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":154619542813,"f":50331681},"n":"Name","d":720157,"h":150324575517,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":163209477405,"f":50331681},"n":"NameId","d":720157,"h":158914510109,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":171799411997,"f":50331681},"n":"Nonce","d":720157,"h":167504444701,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":180389346589,"f":50331681},"n":"Nbf","d":720157,"h":176094379293,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":188979281181,"f":50331681},"n":"PhoneNumber","d":720157,"h":184684313885,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":197569215773,"f":50331681},"n":"PhoneNumberVerified","d":720157,"h":193274248477,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":206159150365,"f":50331681},"n":"Prn","d":720157,"h":201864183069,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":214749084957,"f":50331681},"n":"Sid","d":720157,"h":210454117661,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":223339019549,"f":50331681},"n":"Sub","d":720157,"h":219044052253,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":231928954141,"f":50331681},"n":"Typ","d":720157,"h":227633986845,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":240518888733,"f":50331681},"n":"UniqueName","d":720157,"h":236223921437,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":249108823325,"f":50331681},"n":"Website","d":720157,"h":244813856029,"f":2097185}],"c":[{"n":".ctor","o":"$ctor$2","d":720157,"h":253403790621,"f":16777217}],"h":720157}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes`; }
        });
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler", ($self) => class JsonWebTokenHandler extends $.$mit.Microsoft.IdentityModel.Tokens.TokenHandler
        {
            /*ClaimsIdentity */ CreateClaimsIdentity$1(/*JsonWebToken?*/ jwtToken, /*ValidationParameters*/ validationParameters)
            {
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken") });
                return this.CreateClaimsIdentityPrivate(jwtToken, validationParameters, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActualIssuer(jwtToken));
            }
            /*ClaimsIdentity */ CreateClaimsIdentity(/*JsonWebToken?*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken") });
                if ($.$$.System.String.IsNullOrWhiteSpace(issuer))
                {
                    issuer = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActualIssuer(jwtToken);
                }
                if (this.MapInboundClaims)
                {
                    return this.CreateClaimsIdentityWithMapping(jwtToken, validationParameters, issuer);
                }
                return this.CreateClaimsIdentityPrivate(jwtToken, validationParameters, issuer);
            }
            /*ClaimsIdentity */ CreateClaimsIdentityInternal(/*SecurityToken*/ securityToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                return this.CreateClaimsIdentity($.$as(securityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken), validationParameters, issuer);
            }
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string?*/ let type;
                        /*bool*/ let wasMapped = this._inboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => type, ($v) => type = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]);
                        /*string*/ let claimType = type ?? jwtClaim.Type;
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken?*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$1(actor, validationParameters);
                            }
                        }
                        if (wasMapped)
                        {
                            /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count > 0)
                            {
                                var $en6 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var kv = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                    }
                                }
                            }
                            claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ShortClaimTypeProperty, jwtClaim.Type, [$.$$.System.String, $.$$.System.String]);
                            identity.AddClaim(claim);
                        }
                        else 
                        {
                            identity.AddClaim(jwtClaim);
                        }
                    }
                }
                return identity;
            }
            /*ClaimsIdentity */ CreateClaimsIdentityPrivate(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType = jwtClaim.Type;
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken?*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, validationParameters, issuer);
                            }
                        }
                        if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count === 0)
                        {
                            identity.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity));
                        }
                        else 
                        {
                            /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            var $en5 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kv = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                }
                            }
                            identity.AddClaim(claim);
                        }
                    }
                }
                return identity;
            }
            static /*ValidationResult<SecurityToken, ValidationError> */ ReadToken$1(/*string*/ token, /*CallContext?*/ callContext)
            {
                if ($.$$.System.String.IsNullOrEmpty(token))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("token", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ReadToken.cs", 30, 1)));
                }
                try
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit$1(new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$7(token));
                }
                catch(ex)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$1(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$2("IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX14107*/), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenReadingFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ReadToken.cs", 44, 1), ex));
                }
            }
            /*IDictionary<string, string>*/ _inboundClaimTypeMap = null;
            /*string*/ static _namespace = null;
            /*string*/ static _shortClaimType = null;
            /*bool*/ _mapInboundClaims = false;
            /*IDictionary<string, string>*/ static DefaultInboundClaimTypeMap = null;
            /*bool*/ static DefaultMapInboundClaims = false;
            /*string*/ static Base64UrlEncodedUnsignedJWSHeader = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    if (this._mapInboundClaims)
                    {
                        this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.DefaultInboundClaimTypeMap);
                    }
                    else 
                    {
                        this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
                    }
                }
                return this;
            }
            /*Type */ get TokenType()
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type;
            }
            static /*string */ get ShortClaimTypeProperty()
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler._shortClaimType;
            }
            static /*string */ set ShortClaimTypeProperty(value)
            {
                if ($.$$.System.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler._shortClaimType = value;
            }
            /*bool */ get MapInboundClaims()
            {
                return this._mapInboundClaims;
            }
            /*bool */ set MapInboundClaims(value)
            {
                if (!this._mapInboundClaims && value && this._inboundClaimTypeMap.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.DefaultInboundClaimTypeMap);
                }
                this._mapInboundClaims = value;
            }
            /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                return this._inboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set InboundClaimTypeMap(value)
            {
                this._inboundClaimTypeMap = $.$firstOf(value, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value") });
            }
            /*bool */ CanReadToken(/*string*/ token)
            {
                if ($.$$.System.String.IsNullOrWhiteSpace(token))
                {
                    return false;
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null));
                    }
                    return false;
                }
                /*int*/ let pos = 0;
                /*int*/ let segmentCount = 1;
                while(segmentCount <= 5/*JwtConstants.MaxJwtSegmentCount*/ && ((pos = $.$$.System.String.IndexOf$1.call(token, /*.*/ 46, pos)) >= 0))
                {
                    pos++;
                    segmentCount++;
                }
                switch(segmentCount)
                {
                    case 3/*JwtConstants.JwsSegmentCount*/:
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJws.IsMatch$9(token);
                    case 5/*JwtConstants.JweSegmentCount*/:
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJwe.IsMatch$9(token);
                    default:
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX14107: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX14107*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    return false;
                }
            }
            static /*StringComparison */ GetStringComparisonRuleIf509(/*SecurityKey*/ securityKey)
            {
                return $.$is(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/;
            }
            static /*StringComparison */ GetStringComparisonRuleIf509OrECDsa(/*SecurityKey*/ securityKey)
            {
                return ($.$is(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) || $.$is(securityKey, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey)) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/;
            }
            /*ClaimsIdentity */ CreateClaimsIdentity$3(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken") });
                return this.CreateClaimsIdentityPrivate$1(jwtToken, validationParameters, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActualIssuer(jwtToken));
            }
            /*ClaimsIdentity */ CreateClaimsIdentity$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                _ = $.$firstOf(jwtToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken") });
                if ($.$$.System.String.IsNullOrWhiteSpace(issuer))
                {
                    issuer = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActualIssuer(jwtToken);
                }
                if (this.MapInboundClaims)
                {
                    return this.CreateClaimsIdentityWithMapping$1(jwtToken, validationParameters, issuer);
                }
                return this.CreateClaimsIdentityPrivate$1(jwtToken, validationParameters, issuer);
            }
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType;
                        /*bool*/ let wasMapped = this._inboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => claimType, ($v) => claimType = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]);
                        if (!wasMapped)
                        {
                            claimType = jwtClaim.Type;
                        }
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$3(actor, validationParameters);
                            }
                        }
                        if (wasMapped)
                        {
                            /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count > 0)
                            {
                                var $en6 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var kv = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                    }
                                }
                            }
                            claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ShortClaimTypeProperty, jwtClaim.Type, [$.$$.System.String, $.$$.System.String]);
                            identity.AddClaim(claim);
                        }
                        else 
                        {
                            identity.AddClaim(jwtClaim);
                        }
                    }
                }
                return identity;
            }
            /*ClaimsIdentity */ CreateClaimsIdentityInternal$1(/*SecurityToken*/ securityToken, /*TokenValidationParameters*/ tokenValidationParameters, /*string*/ issuer)
            {
                return this.CreateClaimsIdentity$2($.$as(securityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken), tokenValidationParameters, issuer);
            }
            static /*string */ GetActualIssuer(/*JsonWebToken*/ jwtToken)
            {
                /*string*/ let actualIssuer = jwtToken.Issuer;
                if ($.$$.System.String.IsNullOrWhiteSpace(actualIssuer))
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX10244: Issuer is null or empty. Using runtime default for creating claims '{0}'."/*TokenLogMessages.IDX10244*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/ ], null, null));
                    }
                    actualIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                }
                return actualIssuer;
            }
            /*ClaimsIdentity */ CreateClaimsIdentityPrivate$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*string*/ issuer)
            {
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, issuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string*/ let claimType = jwtClaim.Type;
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14112: Only a single 'Actor' is supported. Found second claim of type: '{0}'"/*LogMessages.IDX14112*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), jwtClaim.Value ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JsonWebToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                                identity.Actor = this.CreateClaimsIdentity$2(actor, validationParameters, issuer);
                            }
                        }
                        if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count === 0)
                        {
                            identity.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity));
                        }
                        else 
                        {
                            /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, issuer, issuer, identity);
                            var $en5 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kv = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                }
                            }
                            identity.AddClaim(claim);
                        }
                    }
                }
                return identity;
            }
            /*Task<string> *//*async*/  DecryptTokenWithConfigurationAsync(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    if (jwtToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                    }
                    if (validationParameters === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                    }
                    if ($.$$.System.String.IsNullOrEmpty(jwtToken.Enc))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null))));
                    }
                    /*BaseConfiguration*/ let currentConfiguration = null;
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        try
                        {
                            currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false);
                        }
                        catch(ex)
                        {
                            if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10278: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token decryption in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10278*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ validationParameters.ConfigurationManager.MetadataAddress, $.$$.System.Exception.ToString.call(ex) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            }
                        }
                    }
                    return this.DecryptToken$1(jwtToken, validationParameters, currentConfiguration);
                });
            }
            /*string */ DecryptToken$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                return this.DecryptToken$1(jwtToken, validationParameters, null);
            }
            /*string */ DecryptToken$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.Enc))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null))));
                }
                /*var*/ let keys = this.GetContentEncryptionKeys$1(jwtToken, validationParameters, configuration);
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, keys);
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptJwtToken$1(jwtToken, validationParameters, decryptionParameters);
            }
            /*JwtTokenDecryptionParameters */ CreateJwtTokenDecryptionParameters(/*JsonWebToken*/ jwtToken, /*IEnumerable<SecurityKey>*/ keys)
            {
                return (() =>
                {
                    //new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters()
                    const $t1 = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters;
                    const $i1 = new $t1();
                    $i1.Alg = jwtToken.Alg;
                    $i1.AuthenticationTagBytes = jwtToken.AuthenticationTagBytes;
                    $i1.CipherTextBytes = jwtToken.CipherTextBytes;
                    $i1.DecompressionFunction = new ($.$$.System.Func$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.String, $.$$.System.Int32, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecompressToken);
                    $i1.Enc = jwtToken.Enc;
                    $i1.EncodedToken = jwtToken.EncodedToken;
                    $i1.HeaderAsciiBytes = jwtToken.HeaderAsciiBytes;
                    $i1.InitializationVectorBytes = jwtToken.InitializationVectorBytes;
                    $i1.MaximumDeflateSize = this.MaximumTokenSizeInBytes;
                    $i1.Keys$1 = keys;
                    $i1.Zip = jwtToken.Zip;
                    return $i1;
                })();
            }
            static /*SecurityKey */ ResolveTokenDecryptionKeyFromConfig(/*JsonWebToken*/ jwtToken, /*BaseConfiguration*/ configuration)
            {
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Kid) && configuration.TokenDecryptionKeys !== null)
                {
                    var $en3 = configuration.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Kid, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                            {
                                return key;
                            }
                        }
                    }
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.X5t) && configuration.TokenDecryptionKeys !== null)
                {
                    var $en3 = configuration.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.X5t, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                            {
                                return key;
                            }
                            /*var*/ let x509Key = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                            if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                return key;
                            }
                        }
                    }
                }
                return null;
            }
            /*SecurityKey */ ResolveTokenDecryptionKey(/*string*/ token, /*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*StringComparison*/ let stringComparison = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(validationParameters.TokenDecryptionKey);
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Kid))
                {
                    if (validationParameters.TokenDecryptionKey !== null && $.$$.System.String.Equals$2(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Kid, stringComparison))
                    {
                        return validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Kid, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.X5t))
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        if ($.$$.System.String.Equals$2(validationParameters.TokenDecryptionKey.KeyId, jwtToken.X5t, stringComparison))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                        /*var*/ let x509Key = $.$as(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                        if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.X5t, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                                {
                                    return key;
                                }
                                /*var*/ let x509Key = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                                if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            /*JsonWebToken */ ReadJsonWebToken$1(/*string*/ token)
            {
                if ($.$$.System.String.IsNullOrEmpty(token))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                }
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$7(token);
            }
            /*JsonWebToken */ ReadJsonWebToken(/*ReadOnlyMemory<char>*/ token)
            {
                if (token.IsEmpty)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                if (token.Span.Length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.Length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                }
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$3(token);
            }
            /*JsonWebToken */ ReplaceTokenHeader(/*JsonWebToken*/ jsonWebToken, /*string*/ encodedHeader)
            {
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$8(jsonWebToken, encodedHeader);
            }
            /*SecurityToken */ ReadToken(/*string*/ token)
            {
                return this.ReadJsonWebToken$1(token);
            }
            static /*TokenValidationResult */ ReadToken$2(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                /*JsonWebToken*/ let jsonWebToken = null;
                if (validationParameters.TokenReader !== null)
                {
                    /*var*/ let securityToken = validationParameters.TokenReader.Invoke(token, validationParameters);
                    if (securityToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10510: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader returned null when reading token: '{0}'."/*TokenLogMessages.IDX10510*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    jsonWebToken = $.$as(securityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                    if (jsonWebToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10509: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader did not return a '{0}', but returned a '{1}' when reading token: '{2}'."/*TokenLogMessages.IDX10509*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type, $.$$.System.Object.GetType.call(securityToken), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                }
                else 
                {
                    try
                    {
                        jsonWebToken = new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken().$ctor$6(token, validationParameters.TryReadJwtClaim);
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                }
                return (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SecurityToken = jsonWebToken;
                    $i1.IsValid = true;
                    return $i1;
                })();
            }
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateTokenAsync(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    if ($.$$.System.String.IsNullOrEmpty(token))
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("token", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 29, 1)));
                    }
                    if (validationParameters === null)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 36, 1)));
                    }
                    if (token.length > this.MaximumTokenSizeInBytes)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.SecurityTokenTooLarge, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 47, 1)));
                    }
                    /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$1(token, callContext);
                    if (readResult.Succeeded)
                    {
                        /*ValidationResult<ValidatedToken, ValidationError>*/ let validationResult = await this.ValidateTokenAsync$3(readResult.Result, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false);
                        if (validationResult.Succeeded)
                        {
                            return validationResult;
                        }
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(validationResult.Error.AddStackFrame($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 67, 1)));
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 70, 1));
                });
            }
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateTokenAsync$3(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    if (token === null)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("token", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 84, 1)));
                    }
                    if (validationParameters === null)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 91, 1)));
                    }
                    let jsonWebToken;
                    if (!$.$is(token, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken, { set $v(v){ jsonWebToken = v; } }))
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10001: Invalid argument '{0}'. Argument must be of type '{1}'."/*TokenLogMessages.IDX10001*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "token", "JsonWebToken" ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.SecurityTokenNotExpectedType, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 99, 1)));
                    }
                    /*BaseConfiguration?*/ let currentConfiguration = await $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetCurrentConfigurationAsync(validationParameters, cancellationToken).ConfigureAwait$2(false);
                    /*ValidationResult<ValidatedToken, ValidationError>*/ let result = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false);
                    if (validationParameters.ConfigurationManager === null)
                    {
                        if (result.Succeeded)
                        {
                            return result;
                        }
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(result.Error.AddStackFrame($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 118, 1)));
                    }
                    if (result.Succeeded)
                    {
                        if (!(currentConfiguration === null))
                        {
                            validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                        }
                        return result;
                    }
                    if ($.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableFailureType(result.Error.FailureType, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.System$Collections$Generic$ICollection$$$Count > 0)))
                    {
                        if (!(currentConfiguration === null))
                        {
                            validationParameters.ConfigurationManager.RequestRefresh();
                            validationParameters.RefreshBeforeValidation = true;
                            /*BaseConfiguration*/ let lastConfig = currentConfiguration;
                            currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.System.Threading.CancellationToken.None).ConfigureAwait$2(false);
                            if (lastConfig !== currentConfiguration)
                            {
                                result = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync(jsonWebToken, validationParameters, currentConfiguration, callContext, cancellationToken).ConfigureAwait(false);
                                if (result.Succeeded)
                                {
                                    validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                    return result;
                                }
                            }
                        }
                        if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                        {
                            validationParameters.RefreshBeforeValidation = false;
                            validationParameters.ValidateWithLKG = true;
                            /*ValidationFailureType*/ let failureType = result.Error.FailureType;
                            /*BaseConfiguration[]*/ let validConfigurations = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                            for(/*int*/ let i = 0; i < validConfigurations.length; i++)
                            {
                                /*BaseConfiguration*/ let lkgConfiguration = $.$$.System.Array.$ReadT1.call(validConfigurations, i);
                                if ($.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableConfigurationAndExceptionType$1(jsonWebToken.Kid, currentConfiguration, lkgConfiguration, failureType))
                                {
                                    result = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync(jsonWebToken, validationParameters, lkgConfiguration, callContext, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync(jsonWebToken, validationParameters, lkgConfiguration, callContext, cancellationToken).ConfigureAwait(false);
                                    if (result.Succeeded)
                                    {
                                        return result;
                                    }
                                }
                            }
                        }
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(result.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 191, 1));
                });
            }
            /*ValueTask<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateJWEAsync(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    /*ValidationResult<string, ValidationError>*/ let decryptionResult = this.DecryptToken(jwtToken, validationParameters, configuration, callContext);
                    if (!decryptionResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(decryptionResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 205, 1));
                    }
                    /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$1(decryptionResult.Result, callContext);
                    if (!readResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 211, 1));
                    }
                    /*JsonWebToken*/ let decryptedToken = ($.$as(readResult.Result, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken));
                    /*ValidationResult<ValidatedToken, ValidationError>*/ let validationResult = await this.ValidateJWSAsync(decryptedToken, validationParameters, configuration, callContext, cancellationToken).ConfigureAwait(false);
                    if (!validationResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(validationResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 221, 1));
                    }
                    /*JsonWebToken*/ let jsonWebToken = ($.$as(validationResult.Result.SecurityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken));
                    jwtToken.InnerToken = jsonWebToken;
                    jwtToken.Payload = jsonWebToken.Payload;
                    return validationResult;
                });
            }
            /*ValueTask<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  ValidateJWSAsync(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    /*DateTime?*/ let expires = jsonWebToken.HasPayloadClaim("exp"/*JwtRegisteredClaimNames.Exp*/) ? jsonWebToken.ValidTo : null;
                    /*DateTime?*/ let notBefore = jsonWebToken.HasPayloadClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/) ? jsonWebToken.ValidFrom : null;
                    /*ValidationResult<ValidatedLifetime, ValidationError>*/ let lifetimeResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateLifetimeInternal(notBefore?.Clone() ?? null, expires?.Clone() ?? null, jsonWebToken, validationParameters, callContext);
                    if (!lifetimeResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(lifetimeResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 253, 1));
                    }
                    let tokenAudiences;
                    if (!$.$is(jsonWebToken.Audiences, $.$$.System.Collections.Generic.IList$$($.$$.System.String), { set $v(v){ tokenAudiences = v; } }))
                    {
                        tokenAudiences = (() =>
                        {
                            let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                            $t1.AddRange(jsonWebToken.Audiences);
                            return $t1;
                        })();
                    }
                    /*ValidationResult<string, ValidationError>*/ let audienceResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAudienceInternal(tokenAudiences, jsonWebToken, validationParameters, callContext);
                    if (!audienceResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(audienceResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 274, 1));
                    }
                    /*ValidationResult<ValidatedIssuer, ValidationError>*/ let issuerResult = await $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerInternalAsync(jsonWebToken.Issuer, jsonWebToken, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false);
                    if (!issuerResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(issuerResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 289, 1));
                    }
                    /*ValidationResult<DateTime?, ValidationError>?*/ let tokenReplayResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenReplayInternal(expires?.Clone() ?? null, jsonWebToken.EncodedToken, validationParameters, callContext);
                    if (!$.$$.System.Nullable$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.Nullable$$($.$$.System.DateTime), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).Value$get.call(tokenReplayResult).Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$$.System.Nullable$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.Nullable$$($.$$.System.DateTime), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).Value$get.call(tokenReplayResult).Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 303, 1));
                    }
                    /*ValidationResult<ValidatedTokenType, ValidationError>*/ let tokenTypeResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenTypeInternal(jsonWebToken.Typ, jsonWebToken, validationParameters, callContext);
                    if (!tokenTypeResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(tokenTypeResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 317, 1));
                    }
                    /*ValidationResult<string, ValidationError>*/ let algorithmResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAlgorithmInternal(jsonWebToken.Alg, jsonWebToken, validationParameters, callContext);
                    if (!algorithmResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(algorithmResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 331, 1));
                    }
                    /*ValidationResult<SecurityKey, ValidationError>*/ let signatureResult = this.ValidateSignature$1(jsonWebToken, validationParameters, configuration, callContext);
                    if (!signatureResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(signatureResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 346, 1));
                    }
                    /*ValidationResult<ValidatedSignatureKey, ValidationError>*/ let signatureKeyResult = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateSignatureKeyInternal(jsonWebToken.SigningKey, jsonWebToken, validationParameters, callContext);
                    if (!signatureKeyResult.Succeeded)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(signatureKeyResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 360, 1));
                    }
                    /*ValidationResult<ValidatedToken, ValidationError>?*/ let actorResult = null;
                    if (validationParameters.ValidateActor && !$.$$.System.String.IsNullOrWhiteSpace(jsonWebToken.Actor))
                    {
                        /*ValidationResult<SecurityToken, ValidationError>*/ let readResult = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$1(jsonWebToken.Actor, callContext);
                        if (!readResult.Succeeded)
                        {
                            return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(readResult.Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 372, 1));
                        }
                        if (validationParameters.ActorValidationParameters === null)
                        {
                            return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("ActorValidationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 381, 1)));
                        }
                        /*JsonWebToken*/ let actorToken = ($.$as(readResult.Result, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken));
                        actorResult = await this.ValidateJWSAsync(actorToken, validationParameters.ActorValidationParameters, configuration, callContext, cancellationToken).ConfigureAwait(false);
                        if (!$.$$.System.Nullable$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).Value$get.call(actorResult).Succeeded)
                        {
                            return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$$.System.Nullable$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).Value$get.call(actorResult).Error.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateToken.Internal.cs", 397, 1));
                        }
                    }
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit$1((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken;
                        const $i1 = new $t1();
                        $i1.$ctor$1(jsonWebToken, this, validationParameters);
                        $i1.ValidatedLifetime = lifetimeResult.Result;
                        $i1.ValidatedAlgorithm = algorithmResult.Result;
                        $i1.ValidatedAudience = audienceResult.Result;
                        $i1.ValidatedIssuer = issuerResult.Result;
                        $i1.ActorValidationResult = (actorResult?.Result ?? null);
                        $i1.ValidatedTokenType = tokenTypeResult.Result;
                        $i1.ValidatedSignatureKey = signatureResult.Result;
                        return $i1;
                    })());
                });
            }
            static /*Task<BaseConfiguration?> *//*async*/  GetCurrentConfigurationAsync(/*ValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.BaseConfiguration), $.$mit.Microsoft.IdentityModel.Tokens.BaseConfiguration, async () => 
                {
                    /*BaseConfiguration?*/ let currentConfiguration = null;
                    if (!(validationParameters.ConfigurationManager === null))
                    {
                        try
                        {
                            currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false);
                        }
                        catch($e)
                        {
                        }
                    }
                    return currentConfiguration;
                });
            }
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  Microsoft$IdentityModel$Tokens$Experimental$IResultBasedValidation$ValidateTokenAsync$1(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    return await this.ValidateTokenAsync(token, validationParameters, callContext, new $.$$.System.Threading.CancellationToken()).ConfigureAwait$2(false);
                });
            }
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  Microsoft$IdentityModel$Tokens$Experimental$IResultBasedValidation$ValidateTokenAsync(/*string*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    return await this.ValidateTokenAsync(token, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false);
                });
            }
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  Microsoft$IdentityModel$Tokens$Experimental$IResultBasedValidation$ValidateTokenAsync$3(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    return await this.ValidateTokenAsync$3(token, validationParameters, callContext, new $.$$.System.Threading.CancellationToken()).ConfigureAwait$2(false);
                });
            }
            /*Task<ValidationResult<ValidatedToken, ValidationError>> *//*async*/  Microsoft$IdentityModel$Tokens$Experimental$IResultBasedValidation$ValidateTokenAsync$2(/*SecurityToken*/ token, /*ValidationParameters*/ validationParameters, /*CallContext*/ callContext, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError), async () => 
                {
                    return await this.ValidateTokenAsync$3(token, validationParameters, callContext, cancellationToken).ConfigureAwait$2(false);
                });
            }
            /*ValidationResult<string, ValidationError> */ DecryptToken(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext?*/ callContext)
            {
                if (jwtToken === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("jwtToken", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 36, 1)));
                }
                if (validationParameters === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 43, 1)));
                }
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.Enc))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$2("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 51, 1)));
                }
                /*(IList<SecurityKey>? ContentEncryptionKeys, ValidationError? ValidationError)*/ let result = this.GetContentEncryptionKeys(jwtToken, validationParameters, configuration, callContext);
                if (result.Item2 !== null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(result.Item2.AddCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 60, 1));
                }
                if (result.Item1 === null || result.Item1.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10609: Decryption failed. No Keys tried: token: '{0}'."/*TokenLogMessages.IDX10609*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.TokenDecryptionFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 71, 1)));
                }
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, result.Item1);
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptJwtToken(jwtToken, validationParameters, decryptionParameters, callContext);
            }
            /*(IList<SecurityKey>?, ValidationError?) */ GetContentEncryptionKeys(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext?*/ callContext)
            {
                /*IList<SecurityKey>?*/ let keys = null;
                if (validationParameters.DecryptionKeyResolver !== null)
                {
                    keys = validationParameters.DecryptionKeyResolver.Microsoft$IdentityModel$Tokens$Experimental$IDecryptionKeyResolver$ResolveDecryptionKey(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, callContext);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey$1(jwtToken, validationParameters, callContext);
                    if (key === null && !(configuration === null))
                    {
                        key = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ResolveTokenDecryptionKeyFromConfig(jwtToken, configuration);
                    }
                    if (!(key === null))
                    {
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (validationParameters.TryAllDecryptionKeys && $.$mit.Microsoft.IdentityModel.Tokens.CollectionUtilities.IsNullOrEmpty($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys))
                {
                    keys = validationParameters.DecryptionKeys;
                    if (configuration !== null)
                    {
                        let configurationKeys;
                        if (!$.$is(configuration.TokenDecryptionKeys, $.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), { set $v(v){ configurationKeys = v; } }))
                        {
                            configurationKeys = $.$sl.System.Linq.Enumerable.ToList($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, configuration.TokenDecryptionKeys);
                        }
                        if (keys !== null)
                        {
                            let keysList;
                            if ($.$is(keys, $.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), { set $v(v){ keysList = v; } }))
                            {
                                keysList.AddRange(configurationKeys);
                            }
                            else 
                            {
                                keys = $.$sl.System.Linq.Enumerable.ToList($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$sl.System.Linq.Enumerable.Concat($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys, configurationKeys));
                            }
                        }
                        else 
                        {
                            keys = configurationKeys;
                        }
                    }
                }
                if ($.$$.System.String.Equals$4.call(jwtToken.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/, 4/*StringComparison.Ordinal*/) || $.$$.System.String.Equals$4.call(jwtToken.Alg, "ECDH-ES"/*SecurityAlgorithms.EcdhEs*/, 4/*StringComparison.Ordinal*/))
                {
                    return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError))().$ctor$3(keys, null);
                }
                if (keys === null)
                {
                    return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError))().$ctor$3(keys, null);
                }
                /*var*/ let unwrappedKeys = new ($.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey))().$ctor$1();
                /*StringBuilder?*/ let exceptionStrings = null;
                /*StringBuilder?*/ let keysAttempted = null;
                for(/*int*/ let i = 0; i < keys.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*var*/ let key = keys.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.SecurityKey]);
                    try
                    {
                        if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(jwtToken.Alg, [$.$$.System.String]))
                        {
                            /*string*/ let epk;
                            jwtToken.TryGetHeaderValue($.$$.System.String, "epk"/*JwtHeaderParameterNames.Epk*/, $.$ref(() => epk, ($v) => epk = $v, $.$$.System.String));
                            /*ECDsaSecurityKey?*/ let publicKey = new $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey().$ctor$5(new $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKey().$ctor$4(epk), false);
                            if (!(publicKey === null))
                            {
                                /*var*/ let ecdhKeyExchangeProvider = new $.$mit.Microsoft.IdentityModel.Tokens.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey), publicKey, jwtToken.Alg, jwtToken.Enc);
                                /*string*/ let apu;
                                jwtToken.TryGetHeaderValue($.$$.System.String, "apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => apu, ($v) => apu = $v, $.$$.System.String));
                                /*string*/ let apv;
                                jwtToken.TryGetHeaderValue($.$$.System.String, "apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => apv, ($v) => apv = $v, $.$$.System.String));
                                /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.EncryptedKey));
                                unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                            }
                        }
                        else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Alg, key))
                        {
                            /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Alg);
                            /*var*/ let unwrappedKey = kwp.UnwrapKey(jwtToken.EncryptedKeyBytes);
                            unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                        }
                    }
                    catch(ex)
                    {
                        (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                    }
                    (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(key.KeyId);
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings === null)
                {
                    return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError))().$ctor$3(unwrappedKeys, null);
                }
                else 
                {
                    const $t1 = keysAttempted;
                    const $t2 = exceptionStrings;
                    /*ValidationError*/ let validationError = new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError().$ctor$2(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$ifnn($t1, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t)) ?? ""), $.$ifnn($t2, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t)) ?? "", $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.KeyWrapFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.DecryptToken.cs", 241, 1));
                    return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError))().$ctor$3(null, validationError);
                }
            }
            /*SecurityKey? */ ResolveTokenDecryptionKey$1(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*CallContext?*/ callContext)
            {
                if (jwtToken === null || validationParameters === null)
                {
                    return null;
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Kid) && validationParameters.DecryptionKeys !== null)
                {
                    for(/*int*/ let i = 0; i < validationParameters.DecryptionKeys.System$Collections$Generic$ICollection$$$Count; i++)
                    {
                        /*var*/ let key = validationParameters.DecryptionKeys.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.SecurityKey]);
                        if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Kid, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509OrECDsa(key)))
                        {
                            return key;
                        }
                    }
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.X5t) && validationParameters.DecryptionKeys !== null)
                {
                    for(/*int*/ let i = 0; i < validationParameters.DecryptionKeys.System$Collections$Generic$ICollection$$$Count; i++)
                    {
                        /*SecurityKey?*/ let key = validationParameters.DecryptionKeys.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.SecurityKey]);
                        if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.X5t, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetStringComparisonRuleIf509(key)))
                        {
                            return key;
                        }
                        let x509Key;
                        if ($.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey, { set $v(v){ x509Key = v; } }) && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return key;
                        }
                    }
                }
                return null;
            }
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignature$1(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext)
            {
                if (jwtToken === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("jwtToken", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 38, 1)));
                }
                if (validationParameters === null)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.NullParameter("validationParameters", $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 47, 1)));
                }
                if (!(validationParameters.SignatureValidator === null))
                {
                    try
                    {
                        /*ValidationResult<SecurityKey, ValidationError>*/ let signatureValidationResult = validationParameters.SignatureValidator.Microsoft$IdentityModel$Tokens$Experimental$ISignatureValidator$ValidateSignature(jwtToken, validationParameters, configuration, callContext);
                        return signatureValidationResult;
                    }
                    catch(ex)
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$3(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$2("IDX10272: SignatureValidationDelegate threw an exception, see inner exception."/*TokenLogMessages.IDX10272*/), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.ValidatorThrew, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 72, 1), ex));
                    }
                }
                if (!jwtToken.IsSigned)
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.TokenIsNotSigned, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 88, 1)));
                }
                /*SecurityKey?*/ let key = null;
                if (!(validationParameters.SignatureKeyResolver === null))
                {
                    key = validationParameters.SignatureKeyResolver.Microsoft$IdentityModel$Tokens$Experimental$ISignatureKeyResolver$ResolveSignatureKey(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, configuration, callContext);
                }
                else 
                {
                    key = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey(jwtToken.Kid, jwtToken.X5t, (configuration?.SigningKeys ?? null)) ?? $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey(jwtToken.Kid, jwtToken.X5t, validationParameters.SigningKeys);
                }
                if (!(key === null))
                {
                    return this.ValidateSignatureWithKey(jwtToken, validationParameters, key, callContext);
                }
                if (validationParameters.TryAllSigningKeys)
                {
                    return this.ValidateSignatureUsingAllKeys(jwtToken, validationParameters, configuration, callContext);
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, null);
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.Kid))
                {
                    /*Microsoft.IdentityModel.Tokens.BaseConfiguration?*/ let __ca1__;
                    /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca2__;
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10526: Signature validation failed. The token's kid is missing.\nValidationParameters.TryAllIssuerSigningKeys is set to false. All keys will not be tried. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10526*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca1__ = configuration) !== null ? ((__ca2__ = __ca1__.SigningKeys) !== null ? __ca2__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 143, 1)));
                }
                /*Microsoft.IdentityModel.Tokens.BaseConfiguration?*/ let __ca3__;
                /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca4__;
                return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10527: Signature validation failed. The token's kid is: '{0}', but did not match any keys in ValidationParameters or Configuration and TryAllIssuerSigningKeys is false.\nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10527*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca3__ = configuration) !== null ? ((__ca4__ = __ca3__.SigningKeys) !== null ? __ca4__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 157, 1)));
            }
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignatureUsingAllKeys(/*JsonWebToken*/ jwtToken, /*ValidationParameters*/ validationParameters, /*BaseConfiguration?*/ configuration, /*CallContext*/ callContext)
            {
                /*bool*/ let keysTried = false;
                /*bool*/ let kidExists = !$.$$.System.String.IsNullOrEmpty(jwtToken.Kid);
                /*IEnumerable<SecurityKey>?*/ let keys = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys(configuration, validationParameters, callContext);
                /*StringBuilder?*/ let exceptionStrings = null;
                /*StringBuilder?*/ let keysAttempted = null;
                var $en2 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (key === null)
                        {
                            continue;
                        }
                        keysTried = true;
                        /*ValidationResult<SecurityKey, ValidationError>*/ let result = this.ValidateSignatureWithKey(jwtToken, validationParameters, key, callContext);
                        if (result.Succeeded)
                        {
                            return result;
                        }
                        let validationError;
                        if ($.$is(result.Error, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError, { set $v(v){ validationError = v; } }))
                        {
                            exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                            keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                            exceptionStrings.AppendLine$2(validationError.MessageDetail.Message);
                            keysAttempted.AppendLine$2($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key));
                        }
                    }
                }
                if (keysTried)
                {
                    if (kidExists)
                    {
                        /*Microsoft.IdentityModel.Tokens.BaseConfiguration*/ let __ca5__;
                        /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca6__;
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10522: Signature validation failed. The token's kid: '{0}' did not match any keys in ValidationParameters or Configuration.\nAll keys in ValidationParameters and Configuration were tried. \nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10522*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca5__ = configuration) !== null ? ((__ca6__ = __ca5__.SigningKeys) !== null ? __ca6__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 221, 1)));
                    }
                    else 
                    {
                        /*Microsoft.IdentityModel.Tokens.BaseConfiguration*/ let __ca7__;
                        /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca8__;
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10523: Signature validation failed. The token's kid is empty.\nAll keys in ValidationParameters and Configuration were tried. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10523*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca7__ = configuration) !== null ? ((__ca8__ = __ca7__.SigningKeys) !== null ? __ca8__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 234, 1)));
                    }
                }
                if (kidExists)
                {
                    /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca10__;
                    /*Microsoft.IdentityModel.Tokens.BaseConfiguration*/ let __ca9__;
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10524: Signature validation failed. The token's kid: '{0}' did not match any keys in ValidationParameters or Configuration.\nAll keys in ValidationParameters and Configuration were tried. No non-null keys were found. \nNumber of keys in ValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\ntoken: '{3}'."/*TokenLogMessages.IDX10524*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca9__ = configuration) !== null ? ((__ca10__ = __ca9__.SigningKeys) !== null ? __ca10__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 253, 1)));
                }
                /*Microsoft.IdentityModel.Tokens.BaseConfiguration*/ let __ca11__;
                /*System.Collections.Generic.ICollection<Microsoft.IdentityModel.Tokens.SecurityKey>*/ let __ca12__;
                return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10525: Signature validation failed. The token's kid is missing.\nAll keys in ValidationParameters and Configuration were tried. No non-null keys were found. \nNumber of keys in ValidationParameters: '{0}'. \nNumber of keys in Configuration: '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10525*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(validationParameters.SigningKeys.System$Collections$Generic$ICollection$$$Count, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(($.$box((__ca11__ = configuration) !== null ? ((__ca12__ = __ca11__.SigningKeys) !== null ? __ca12__.System$Collections$Generic$ICollection$$$Count : 0) : 0, $.$$.System.Int32)), $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken.EncodedToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SigningKeyNotFound, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 265, 1)));
            }
            /*ValidationResult<SecurityKey, ValidationError> */ ValidateSignatureWithKey(/*JsonWebToken*/ jsonWebToken, /*ValidationParameters*/ validationParameters, /*SecurityKey*/ key, /*CallContext*/ callContext)
            {
                /*CryptoProviderFactory*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Alg, key))
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10652: The algorithm '{0}' is not supported."/*TokenLogMessages.IDX10652*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg), key ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.AlgorithmValidationFailure.AlgorithmIsNotSupported, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 291, 1)));
                }
                /*SignatureProvider*/ let signatureProvider;
                try
                {
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, jsonWebToken.Alg);
                }
                catch(ex)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$3(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX11028: CryptoProviderFactory.CreateForVerifying threw an exception for key: '{0}', signatureAlgorithm: '{1}'. The platform may not support the algorithm or extracting the key material for it (for example, ML-DSA on a platform without post-quantum support). See the inner exception for details."/*TokenLogMessages.IDX11028*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.SignatureProviderCreationFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 315, 1), ex));
                }
                try
                {
                    if (signatureProvider === null)
                    {
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationFailureType.CryptoProviderReturnedNull, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 335, 1)));
                    }
                    /*bool*/ let valid = $.$mit.Microsoft.IdentityModel.Tokens.EncodingUtils.PerformEncodingDependentOperation($.$$.System.Boolean, $.$$.System.String, $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, jsonWebToken.EncodedToken, 0, jsonWebToken.Dot2, $.$$.System.Text.Encoding.UTF8, jsonWebToken.EncodedToken, jsonWebToken.Dot2, signatureProvider, new ($.$$.System.Func$$$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$$.System.String, $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, $.$$.System.Boolean))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignature));
                    if (valid)
                    {
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "None"/*TelemetryConstants.SignatureValidationErrors.None*/, jsonWebToken, key);
                        jsonWebToken.SigningKey = key;
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit$1(key);
                    }
                    else 
                    {
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                        return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$4(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10520: Signature validation failed. The key provided could not validate the signature. Key tried: '{0}'."/*TokenLogMessages.IDX10520*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key)) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.ValidationFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 372, 1)));
                    }
                }
                catch(ex)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    return $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).op_Implicit(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationError().$ctor$3(new $.$mit.Microsoft.IdentityModel.Tokens.Experimental.MessageDetail().$ctor$1("IDX10521: Signature validation failed.An exception was thrown when trying to validate the signature. Key tried: '{0}'. Exception: '{1}'."/*TokenLogMessages.IDX10521*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(ex.Message) ], null, null)), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.SignatureValidationFailure.ValidationFailed, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError.GetCurrentStackFrame("C:\Users\User\AppData\Local\Temp\NetJs\NetJs.Microsoft.IdentityModel.JsonWebTokens\JsonWebTokenHandler.ValidateSignature.cs", 391, 1), ex));
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            static /*void */ PopulateFailedResults(/*KeyMatchFailedResult?*/ failedResult, /*StringBuilder*/ exceptionStrings, /*StringBuilder*/ keysAttempted)
            {
                let result;
                if ($.$is(failedResult, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.KeyMatchFailedResult, { set $v(v){ result = v; } }))
                {
                    for(/*int*/ let i = 0; i < result.KeysAttempted.System$Collections$Generic$ICollection$$$Count; i++)
                    {
                        exceptionStrings.AppendLine$2(result.FailedResults.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError]).MessageDetail.Message);
                        keysAttempted.AppendLine$2($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(result.KeysAttempted.System$Collections$Generic$IList$$$get_Item(i, [$.$mit.Microsoft.IdentityModel.Tokens.SecurityKey])));
                    }
                }
            }
            static $_KeyMatchFailedResult;
            static get KeyMatchFailedResult()
            {
                let $cls = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler;
                return $cls.$_KeyMatchFailedResult ??= $asm.$nstr("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.KeyMatchFailedResult", ($self) => class KeyMatchFailedResult extends $.$$.System.ValueType
                {
                    /*IList<ValidationError>*/  get FailedResults() { return this.$getField(0, 4); }
                    /*IList<ValidationError>*/  set FailedResults(value) { this.$setField(0, 4, value); }
                    /*IList<SecurityKey>*/  get KeysAttempted() { return this.$getField(4, 4); }
                    /*IList<SecurityKey>*/  set KeysAttempted(value) { this.$setField(4, 4, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FailedResults = this.FailedResults;
                        copy.KeysAttempted = this.KeysAttempted;
                        return copy;
                    }
                    //Begin primary constructor
                    /*IList<ValidationError>*/ failedResults = null;
                    /*IList<SecurityKey>*/ keysAttempted = null;
                    $ctor$3(/*IList<ValidationError>*/$failedResults, /*IList<SecurityKey>*/$keysAttempted)
                    {
                        this.failedResults = $failedResults;
                        this.keysAttempted = $keysAttempted;
                        //depends on primary constructor parameter
                        this.FailedResults = this.failedResults;
                        //depends on primary constructor parameter
                        this.KeysAttempted = this.keysAttempted;
                        return this
                    }
                    //End primary constructor
                    static $h = 458013;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,"n":"FailedResults","d":458013,"h":8590392605,"f":4194305},{"t":$.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,"n":"KeysAttempted","d":458013,"h":12885359901,"f":4194305}],"c":[{"p":[{"n":"failedResults","p":$.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h},{"n":"keysAttempted","p":$.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h}],"n":".ctor","o":"$ctor$3","d":458013,"h":4295425309,"f":16777217},{"n":".ctor","o":"$ctor$2","d":458013,"h":17180327197,"f":16777217}],"d":392477,"h":458013}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.KeyMatchFailedResult`; }
                }, $cls, ($v) => $cls.$_KeyMatchFailedResult = $v);
            }
            /*Telemetry.ITelemetryClient*/ TelemetryClient = null;
            /*bool */ get CanValidateToken()
            {
                return true;
            }
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWEAsync$2(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    return await this.ValidateJWEAsync$1(jwtToken, validationParameters, configuration, $.$$.System.Threading.CancellationToken.None).ConfigureAwait(false);
                });
            }
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWEAsync$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    try
                    {
                        /*TokenValidationResult*/ let tokenValidationResult = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$2(this.DecryptToken$1(jwtToken, validationParameters, configuration), validationParameters);
                        if (!tokenValidationResult.IsValid)
                        {
                            return tokenValidationResult;
                        }
                        tokenValidationResult = await this.ValidateJWSAsync$1($.$as(tokenValidationResult.SecurityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken), validationParameters, configuration, cancellationToken).ConfigureAwait(false);
                        if (!tokenValidationResult.IsValid)
                        {
                            return tokenValidationResult;
                        }
                        jwtToken.InnerToken = $.$as(tokenValidationResult.SecurityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                        jwtToken.Payload = ($.$as(tokenValidationResult.SecurityToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken)).Payload;
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.SecurityToken = jwtToken;
                            $i1.ClaimsIdentityNoLocking = tokenValidationResult.ClaimsIdentityNoLocking;
                            $i1.IsValid = true;
                            $i1.TokenType = tokenValidationResult.TokenType;
                            return $i1;
                        })();
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            $i1.TokenOnFailedValidation = validationParameters.IncludeTokenOnFailedValidation ? jwtToken : null;
                            return $i1;
                        })();
                    }
                });
            }
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWSAsync$2(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    return await this.ValidateJWSAsync$1(jsonWebToken, validationParameters, configuration, $.$$.System.Threading.CancellationToken.None).ConfigureAwait(false);
                });
            }
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateJWSAsync$1(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    try
                    {
                        /*TokenValidationResult*/ let tokenValidationResult;
                        if (validationParameters.TransformBeforeSignatureValidation !== null)
                        {
                            jsonWebToken = $.$as(validationParameters.TransformBeforeSignatureValidation.Invoke(jsonWebToken, validationParameters), $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                        }
                        if (validationParameters.SignatureValidator !== null || validationParameters.SignatureValidatorUsingConfiguration !== null)
                        {
                            /*var*/ let validatedToken = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignatureUsingDelegates(jsonWebToken, validationParameters);
                            tokenValidationResult = await this.ValidateTokenPayloadAsync(validatedToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false);
                            $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey$1(validatedToken.SigningKey, validatedToken, validationParameters);
                        }
                        else 
                        {
                            if (validationParameters.ValidateSignatureLast)
                            {
                                tokenValidationResult = await this.ValidateTokenPayloadAsync(jsonWebToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false);
                                if (tokenValidationResult.IsValid)
                                {
                                    tokenValidationResult.SecurityToken = this.ValidateSignatureAndIssuerSecurityKey(jsonWebToken, validationParameters, configuration);
                                }
                            }
                            else 
                            {
                                /*var*/ let validatedToken = this.ValidateSignatureAndIssuerSecurityKey(jsonWebToken, validationParameters, configuration);
                                tokenValidationResult = await this.ValidateTokenPayloadAsync(validatedToken, validationParameters, configuration, cancellationToken).ConfigureAwait(false);
                            }
                        }
                        return tokenValidationResult;
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            $i1.TokenOnFailedValidation = validationParameters.IncludeTokenOnFailedValidation ? jsonWebToken : null;
                            return $i1;
                        })();
                    }
                });
            }
            /*JsonWebToken */ ValidateSignatureAndIssuerSecurityKey(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                /*JsonWebToken*/ let validatedToken = this.ValidateSignature$4(jsonWebToken, validationParameters, configuration);
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey(validatedToken.SigningKey, jsonWebToken, validationParameters, configuration);
                return validatedToken;
            }
            /*JsonWebToken */ ValidateSignature$4(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                /*bool*/ let kidMatched = false;
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (!jwtToken.IsSigned)
                {
                    if (validationParameters.RequireSignedTokens)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtToken, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    else 
                    {
                        return jwtToken;
                    }
                }
                if (validationParameters.IssuerSigningKeyResolverUsingConfiguration !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolverUsingConfiguration.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters, configuration);
                }
                else if (validationParameters.IssuerSigningKeyResolver !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolver.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey$1(jwtToken.Kid, jwtToken.X5t, validationParameters, configuration);
                    if (key !== null)
                    {
                        kidMatched = true;
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (validationParameters.TryAllIssuerSigningKeys && $.$mit.Microsoft.IdentityModel.Tokens.CollectionUtilities.IsNullOrEmpty($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys))
                {
                    keys = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(configuration, validationParameters);
                }
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*var*/ let kidExists = !$.$$.System.String.IsNullOrEmpty(jwtToken.Kid);
                if (keys !== null)
                {
                    var $en3 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignature$2(jwtToken, key, validationParameters, this.TelemetryClient))
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10242: Security token: '{0}' has a valid signature."/*TokenLogMessages.IDX10242*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null));
                                    }
                                    jwtToken.SigningKey = key;
                                    return jwtToken;
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                            }
                            if (key !== null)
                            {
                                (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).Append$19($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key)).Append$19(" , KeyId: ").AppendLine$2(key.KeyId);
                                if (kidExists && !kidMatched && $.$$.System.String.op_Inequality(key.KeyId, null))
                                {
                                    kidMatched = $.$$.System.String.Equals$4.call(jwtToken.Kid, key.KeyId, $.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
                                }
                            }
                        }
                    }
                }
                /*var*/ let keysInTokenValidationParameters = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(null, validationParameters);
                /*var*/ let keysInConfiguration = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(configuration, null);
                /*var*/ let numKeysInTokenValidationParameters = $.$sl.System.Linq.Enumerable.Count$1($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInTokenValidationParameters);
                /*var*/ let numKeysInConfiguration = $.$sl.System.Linq.Enumerable.Count$1($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInConfiguration);
                if (kidExists)
                {
                    if (kidMatched)
                    {
                        /*JsonWebToken*/ let localJwtToken = jwtToken;
                        /*var*/ let isKidInTVP = $.$sl.System.Linq.Enumerable.Any($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInTokenValidationParameters, new ($.$$.System.Func$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$$.System.Boolean))().$ctor(this,  (/*x*/ x) =>
                        {
                            return $.$$.System.String.Equals$5.call(x.KeyId, localJwtToken.Kid);
                        }, {"r":262145,"p":[{"n":"x","p":13671473}],"n":"","d":392477,"h":0,"f":17825794}));
                        /*var*/ let keyLocation = isKidInTVP ? "TokenValidationParameters" : "Configuration";
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10511: Signature validation failed. Keys tried: '{0}'. \nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'. \nMatched key was in '{3}'. \nkid: '{4}'. \nExceptions caught:\n '{5}'.\ntoken: '{6}'. See https://aka.ms/IDX10511 for details."/*TokenLogMessages.IDX10511*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keyLocation), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    if (!validationParameters.ValidateSignatureLast)
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.InternalValidators.ValidateAfterSignatureFailed(jwtToken, jwtToken.ValidFromNullable, jwtToken.ValidToNullable, jwtToken.Audiences, validationParameters, configuration);
                    }
                }
                if (!(keysAttempted === null))
                {
                    if (kidExists)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10503: Signature validation failed. The token's kid is: '{0}', but did not match any keys in TokenValidationParameters or Configuration. Keys tried: '{1}'.\nNumber of keys in TokenValidationParameters: '{2}'. \nNumber of keys in Configuration: '{3}'.\nExceptions caught:\n '{4}'.\ntoken: '{5}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10503*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10517: Signature validation failed. The token's kid is missing. Keys tried: '{0}'.\nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\nExceptions caught:\n '{3}'.\ntoken: '{4}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10517*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, null);
                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28("IDX10500: Signature validation failed. No security keys were provided to validate the signature."/*TokenLogMessages.IDX10500*/));
            }
            static /*bool */ IsSignatureValid(/*byte[]*/ signatureBytes, /*int*/ signatureBytesLength, /*SignatureProvider*/ signatureProvider, /*byte[]*/ dataToVerify, /*int*/ dataToVerifyLength)
            {
                if ($.$is(signatureProvider, $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSignatureProvider))
                {
                    return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, signatureBytes, 0, signatureBytesLength);
                }
                else 
                {
                    if (signatureBytes.length === signatureBytesLength)
                    {
                        return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, signatureBytes, 0, signatureBytesLength);
                    }
                    else 
                    {
                        /*byte[]*/ let sigBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [signatureBytesLength], null);
                        $.$$.System.Array.Copy$2(signatureBytes, 0, sigBytes, 0, signatureBytesLength);
                        return signatureProvider.Verify$1(dataToVerify, 0, dataToVerifyLength, sigBytes, 0, signatureBytesLength);
                    }
                }
            }
            static /*bool */ ValidateSignature(/*byte[]*/ bytes, /*int*/ len, /*string*/ stringWithSignature, /*int*/ signatureStartIndex, /*SignatureProvider*/ signatureProvider)
            {
                return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoding.Decode$3($.$$.System.Boolean, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, $.$typeArray($.$$.System.Byte), $.$$.System.Int32, stringWithSignature, ((signatureStartIndex + 1) | 0), ((((stringWithSignature.length - signatureStartIndex) | 0) - 1) | 0), signatureProvider, bytes, len, new ($.$$.System.Func$$$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, $.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$$.System.Boolean))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.IsSignatureValid));
            }
            static /*bool */ ValidateSignature$3(/*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key, /*TokenValidationParameters*/ validationParameters)
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignature$2(jsonWebToken, key, validationParameters, $.$mit.Microsoft.IdentityModel.Telemetry.NullTelemetryClient.Instance);
            }
            static /*void */ RecordSignatureValidationTelemetry(/*Telemetry.ITelemetryClient*/ telemetryClient, /*string*/ errorType, /*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key)
            {
                if ($.$mit.Microsoft.IdentityModel.Telemetry.CryptoTelemetry.RecordSignatureValidationTelemetry)
                {
                    telemetryClient.Microsoft$IdentityModel$Telemetry$ITelemetryClient$IncrementSignatureValidationCounter(errorType, jsonWebToken.Issuer, jsonWebToken.Alg, key);
                }
            }
            static /*bool */ ValidateSignature$2(/*JsonWebToken*/ jsonWebToken, /*SecurityKey*/ key, /*TokenValidationParameters*/ validationParameters, /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient)
            {
                /*var*/ let cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                if (!cryptoProviderFactory.IsSupportedAlgorithm(jsonWebToken.Alg, key))
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX14000: Signature validation of this JWT is not supported for: Algorithm: '{0}', SecurityKey: '{1}'."/*LogMessages.IDX14000*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                    }
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    return false;
                }
                try
                {
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAlgorithm(jsonWebToken.Alg, key, jsonWebToken, validationParameters);
                }
                catch($e)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, jsonWebToken, key);
                    throw $e;
                }
                /*SignatureProvider*/ let signatureProvider;
                try
                {
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, jsonWebToken.Alg);
                    if (signatureProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII((key?.KeyId ?? null) ?? "Null"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jsonWebToken.Alg) ], null, null))));
                    }
                }
                catch($e)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, jsonWebToken, key);
                    throw $e;
                }
                try
                {
                    /*bool*/ let isValid = $.$mit.Microsoft.IdentityModel.Tokens.EncodingUtils.PerformEncodingDependentOperation($.$$.System.Boolean, $.$$.System.String, $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, jsonWebToken.EncodedToken, 0, jsonWebToken.Dot2, $.$$.System.Text.Encoding.UTF8, jsonWebToken.EncodedToken, jsonWebToken.Dot2, signatureProvider, new ($.$$.System.Func$$$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$$.System.String, $.$$.System.Int32, $.$mit.Microsoft.IdentityModel.Tokens.SignatureProvider, $.$$.System.Boolean))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ValidateSignature));
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, isValid ? "None"/*TelemetryConstants.SignatureValidationErrors.None*/ : "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    return isValid;
                }
                catch($e)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, jsonWebToken, key);
                    throw $e;
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            static /*JsonWebToken */ ValidateSignatureUsingDelegates(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters)
            {
                if (validationParameters.SignatureValidatorUsingConfiguration !== null)
                {
                    /*BaseConfiguration*/ let configuration = null;
                    /*var*/ let validatedToken = validationParameters.SignatureValidatorUsingConfiguration.Invoke(jsonWebToken.EncodedToken, validationParameters, configuration);
                    if (validatedToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jsonWebToken ], null, null))));
                    }
                    let validatedJsonWebToken;
                    if (!($.$is(validatedToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken, { set $v(v){ validatedJsonWebToken = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(validatedToken)), jsonWebToken ], null, null))));
                    }
                    return validatedJsonWebToken;
                }
                else if (validationParameters.SignatureValidator !== null)
                {
                    /*var*/ let validatedToken = validationParameters.SignatureValidator.Invoke(jsonWebToken.EncodedToken, validationParameters);
                    if (validatedToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jsonWebToken ], null, null))));
                    }
                    let validatedJsonWebToken;
                    if (!($.$is(validatedToken, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken, { set $v(v){ validatedJsonWebToken = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(validatedToken)), jsonWebToken ], null, null))));
                    }
                    return validatedJsonWebToken;
                }
                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jsonWebToken ], null, null))));
            }
            /*TokenValidationResult */ ValidateToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                return this.ValidateTokenAsync$2(token, validationParameters).ConfigureAwait$2(false).GetAwaiter().GetResult();
            }
            /*Task<TokenValidationResult> */ ValidateTokenAsync$2(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                return this.ValidateTokenAsync$1(token, validationParameters, $.$$.System.Threading.CancellationToken.None);
            }
            /*Task<TokenValidationResult> *//*async*/  ValidateTokenAsync$1(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    if ($.$$.System.String.IsNullOrEmpty(token))
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    if (validationParameters === null)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    if (token.length > this.MaximumTokenSizeInBytes)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    try
                    {
                        /*TokenValidationResult*/ let result = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ReadToken$2(token, validationParameters);
                        if (result.IsValid)
                        {
                            return await this.ValidateTokenAsync$4(result.SecurityToken, validationParameters, cancellationToken).ConfigureAwait$2(false);
                        }
                        return result;
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                });
            }
            /*Task<TokenValidationResult> */ ValidateTokenAsync$5(/*SecurityToken*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                return this.ValidateTokenAsync$4(token, validationParameters, $.$$.System.Threading.CancellationToken.None);
            }
            /*Task<TokenValidationResult> *//*async*/  ValidateTokenAsync$4(/*SecurityToken*/ token, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    if (token === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                    }
                    if (validationParameters === null)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    /*var*/ let jwt = $.$as(token, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken);
                    if (jwt === null)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException$7($.$$.System.ArgumentException, "token", `${"token"} must be a ${"JsonWebToken"}.`);
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                    try
                    {
                        return await this.ValidateTokenAsync$6(jwt, validationParameters, cancellationToken).ConfigureAwait(false);
                    }
                    catch(ex)
                    {
                        return (() =>
                        {
                            //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                            const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Exception = ex;
                            $i1.IsValid = false;
                            return $i1;
                        })();
                    }
                });
            }
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenAsync$6(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    /*BaseConfiguration*/ let currentConfiguration = null;
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        try
                        {
                            currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false);
                        }
                        catch(ex)
                        {
                            if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                            {
                                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10261: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token validation in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10261*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ validationParameters.ConfigurationManager.MetadataAddress, $.$$.System.Exception.ToString.call(ex) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            }
                        }
                    }
                    /*TokenValidationResult*/ let tokenValidationResult = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false);
                    if (validationParameters.ConfigurationManager !== null)
                    {
                        if (tokenValidationResult.IsValid)
                        {
                            if (currentConfiguration !== null)
                            {
                                validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                            }
                            return tokenValidationResult;
                        }
                        else if ($.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableException(tokenValidationResult.Exception, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.System$Collections$Generic$ICollection$$$Count > 0)))
                        {
                            if (currentConfiguration !== null)
                            {
                                this.TelemetryClient.Microsoft$IdentityModel$Telemetry$ITelemetryClient$IncrementConfigurationRefreshRequestCounter$2(validationParameters.ConfigurationManager.MetadataAddress, "LastKnownGood"/*TelemetryConstants.Protocols.Lkg*/, "Unknown"/*TelemetryConstants.Protocols.ConfigurationSourceUnknown*/);
                                validationParameters.ConfigurationManager.RequestRefresh();
                                validationParameters.RefreshBeforeValidation = true;
                                /*var*/ let lastConfig = currentConfiguration;
                                currentConfiguration = await validationParameters.ConfigurationManager.GetBaseConfigurationAsync(cancellationToken).ConfigureAwait$2(false);
                                if (lastConfig !== currentConfiguration)
                                {
                                    tokenValidationResult = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync$1(jsonWebToken, validationParameters, currentConfiguration, cancellationToken).ConfigureAwait(false);
                                    if (tokenValidationResult.IsValid)
                                    {
                                        validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                        return tokenValidationResult;
                                    }
                                }
                            }
                            if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                            {
                                validationParameters.RefreshBeforeValidation = false;
                                validationParameters.ValidateWithLKG = true;
                                /*var*/ let recoverableException = tokenValidationResult.Exception;
                                let $i1 = 0;
                                let $arr1 = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                                while ($i1 < $arr1.length)
                                {
                                    let lkgConfiguration = $arr1[$i1++];
                                    if (!$.$$.System.Object.Equals$1.call(lkgConfiguration, currentConfiguration) && $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableConfiguration(jsonWebToken.Kid, currentConfiguration, lkgConfiguration, recoverableException))
                                    {
                                        tokenValidationResult = jsonWebToken.IsEncrypted ? await this.ValidateJWEAsync$1(jsonWebToken, validationParameters, lkgConfiguration, cancellationToken).ConfigureAwait(false) : await this.ValidateJWSAsync$1(jsonWebToken, validationParameters, lkgConfiguration, cancellationToken).ConfigureAwait(false);
                                        if (tokenValidationResult.IsValid)
                                        {
                                            return tokenValidationResult;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return tokenValidationResult;
                });
            }
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenPayloadAsync$1(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    return await this.ValidateTokenPayloadAsync(jsonWebToken, validationParameters, configuration, $.$$.System.Threading.CancellationToken.None).ConfigureAwait(false);
                });
            }
            /*ValueTask<TokenValidationResult> *//*async*/  ValidateTokenPayloadAsync(/*JsonWebToken*/ jsonWebToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult), $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, async () => 
                {
                    /*var*/ let expires = jsonWebToken.HasPayloadClaim("exp"/*JwtRegisteredClaimNames.Exp*/) ? $.$cast(jsonWebToken.ValidTo, $.$$.System.Nullable$$($.$$.System.DateTime)) : null;
                    /*var*/ let notBefore = jsonWebToken.HasPayloadClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/) ? $.$cast(jsonWebToken.ValidFrom, $.$$.System.Nullable$$($.$$.System.DateTime)) : null;
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateLifetime$1(notBefore?.Clone() ?? null, expires?.Clone() ?? null, jsonWebToken, validationParameters);
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAudience(jsonWebToken.Audiences, jsonWebToken, validationParameters);
                    /*string*/ let issuer = await $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerAsync$1(jsonWebToken.Issuer, jsonWebToken, validationParameters, configuration).ConfigureAwait(false);
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenReplay$1(expires?.Clone() ?? null, jsonWebToken.EncodedToken, validationParameters);
                    if (validationParameters.ValidateActor && !$.$$.System.String.IsNullOrWhiteSpace(jsonWebToken.Actor))
                    {
                        /*TokenValidationResult*/ let tokenValidationResult = await this.ValidateTokenAsync$1(jsonWebToken.Actor, validationParameters.ActorValidationParameters ?? validationParameters, cancellationToken).ConfigureAwait$2(false);
                        if (!tokenValidationResult.IsValid)
                        {
                            return tokenValidationResult;
                        }
                    }
                    /*string*/ let tokenType = $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenType$1(jsonWebToken.Typ, jsonWebToken, validationParameters);
                    return (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$2(jsonWebToken, this, validationParameters.Clone(), issuer);
                        $i1.IsValid = true;
                        $i1.TokenType = tokenType;
                        return $i1;
                    })();
                });
            }
            /*SecurityTokenDescriptor*/ static s_emptyTokenDescriptor = null;
            /*string*/ static ActClaimType = null;
            /*int*/ static s_maxActorChainLength = 1;
            static /*int */ get MaxActorChainLength()
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.s_maxActorChainLength;
            }
            static /*int */ set MaxActorChainLength(value)
            {
                if (value < 1)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentOutOfRangeException().$ctor$19("value", $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14317: JsonWebTokenHandler.MaxActorChainLength must be greater than or equal to 1. Value provided was: '{0}'."/*LogMessages.IDX14317*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(value, $.$$.System.Int32)) ], null, null))));
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.s_maxActorChainLength = value;
            }
            /*string */ CreateToken$13(/*string*/ payload)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.s_emptyTokenDescriptor);
            }
            /*string */ CreateToken(/*string*/ payload, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            /*string */ CreateToken$12(/*string*/ payload, /*SigningCredentials*/ signingCredentials)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    return $i1;
                })());
            }
            /*string */ CreateToken$5(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            /*string */ CreateToken$15(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                _ = $.$firstOf(tokenDescriptor, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenDescriptor") });
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                {
                    if ((tokenDescriptor.Subject === null || !$.$sl.System.Linq.Enumerable.Any$1($.$ssc.System.Security.Claims.Claim, tokenDescriptor.Subject.Claims)) && (tokenDescriptor.Claims === null || !$.$sl.System.Linq.Enumerable.Any$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), tokenDescriptor.Claims)))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning("IDX14114: Both '{0}.{1}' and '{0}.{2}' are null or empty."/*LogMessages.IDX14114*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("SecurityTokenDescriptor"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Subject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Claims") ], null, null));
                    }
                }
                if ($.$$.System.Int32.op_GreaterThan$1((tokenDescriptor.AdditionalHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, tokenDescriptor.AdditionalHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("AdditionalHeaderClaims"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.String.Join$5(", ", $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                if ($.$$.System.Int32.op_GreaterThan$1((tokenDescriptor.AdditionalInnerHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, tokenDescriptor.AdditionalInnerHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("AdditionalInnerHeaderClaims"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.String.Join$5(", ", $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$14(tokenDescriptor, this.SetDefaultTimesOnTokenCreation, this.TokenLifetimeInMinutes);
            }
            static /*string */ CreateToken$14(/*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ setdefaultTimesOnTokenCreation, /*int*/ tokenLifetimeInMinutes)
            {
                let utf8ByteMemoryStream = null;
                try
                {
                    utf8ByteMemoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    /*char[]*/ let encodedChars = null;
                    /*byte[]*/ let asciiBytes = null;
                    /*byte[]*/ let signatureBytes = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(utf8ByteMemoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJwsHeader($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), tokenDescriptor);
                        /*int*/ let headerLength = $.$cast(utf8ByteMemoryStream.Length, $.$$.System.Int32);
                        writer.Reset();
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJwsPayload($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), tokenDescriptor, setdefaultTimesOnTokenCreation, tokenLifetimeInMinutes);
                        /*int*/ let payloadEnd = $.$cast(utf8ByteMemoryStream.Length, $.$$.System.Int32);
                        /*int*/ let signatureSize = 0;
                        if (tokenDescriptor.SigningCredentials !== null)
                        {
                            signatureSize = $.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.GetMaxByteCount(tokenDescriptor.SigningCredentials.Algorithm);
                        }
                        /*int*/ let encodedBufferSize = (($.trunc((((((payloadEnd + 4) | 0) + signatureSize) | 0)) / 3) * 4) | 0);
                        encodedChars = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(((encodedBufferSize + 4) | 0));
                        /*int*/ let sizeOfEncodedHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, utf8ByteMemoryStream.GetBuffer(), 0, headerLength)), $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(encodedChars));
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, sizeOfEncodedHeader);
                        /*int*/ let sizeOfEncodedPayload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, utf8ByteMemoryStream.GetBuffer(), headerLength, ((payloadEnd - headerLength) | 0))), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, encodedChars, ((sizeOfEncodedHeader + 1) | 0)));
                        asciiBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$$.System.Text.Encoding.ASCII.GetMaxByteCount(encodedBufferSize));
                        /*int*/ let sizeOfEncodedHeaderAndPayloadAsciiBytes = $.$$.System.Text.Encoding.ASCII.GetBytes(encodedChars, 0, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0), asciiBytes, 0);
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0));
                        /*int*/ let sizeOfEncodedSignature = 0;
                        if (tokenDescriptor.SigningCredentials !== null)
                        {
                            signatureBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(signatureSize);
                            /*int*/ let signatureLength;
                            /*bool*/ let signatureSucceeded = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateSignature($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, asciiBytes, 0, sizeOfEncodedHeaderAndPayloadAsciiBytes)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(signatureBytes), tokenDescriptor.SigningCredentials, $.$ref(() => signatureLength, ($v) => signatureLength = $v, $.$$.System.Int32));
                            sizeOfEncodedSignature = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, signatureBytes, 0, signatureLength)), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, encodedChars, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 2) | 0)));
                        }
                        if (tokenDescriptor.EncryptingCredentials !== null)
                        {
                            return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptToken$1($.$$.System.Text.Encoding.UTF8.GetBytes$1(encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)), tokenDescriptor);
                        }
                        else 
                        {
                            return $.$$.System.Span$$($.$$.System.Char).ToString.call($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)));
                        }
                    }
                    finally
                    {
                        {
                            if (!(encodedChars === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(encodedChars, false);
                            }
                            if (!(signatureBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(signatureBytes, false);
                            }
                            if (!(asciiBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(asciiBytes, false);
                            }
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    utf8ByteMemoryStream?.System$IDisposable$Dispose();
                }
            }
            /*string */ CreateToken$3(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    return $i1;
                })());
            }
            /*string */ CreateToken$1(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            /*string */ CreateToken$11(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    return $i1;
                })());
            }
            /*string */ CreateToken$6(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            /*string */ CreateToken$2(/*string*/ payload, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm)
            {
                _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    return $i1;
                })());
            }
            /*string */ CreateToken$10(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm)
            {
                if ($.$$.System.String.op_Equality(payload, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    return $i1;
                })());
            }
            /*string */ CreateToken$8(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*IDictionary<string, object>*/ additionalInnerHeaderClaims)
            {
                if ($.$$.System.String.op_Equality(payload, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                _ = $.$firstOf(additionalInnerHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalInnerHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    $i1.AdditionalInnerHeaderClaims = additionalInnerHeaderClaims;
                    return $i1;
                })());
            }
            /*string */ CreateToken$9(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                if ($.$$.System.String.op_Equality(payload, null))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                }
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                _ = $.$firstOf(signingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("signingCredentials") });
                _ = $.$firstOf(encryptingCredentials, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials") });
                _ = $.$firstOf(additionalHeaderClaims, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims") });
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            static /*string */ CreateToken$7(/*string*/ payload, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*IDictionary<string, object>*/ additionalInnerHeaderClaims, /*string*/ tokenType)
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CreateToken$4(payload, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    $i1.AdditionalInnerHeaderClaims = additionalInnerHeaderClaims;
                    $i1.TokenType = tokenType;
                    return $i1;
                })());
            }
            static /*string */ CreateToken$4(/*string*/ payload, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                let utf8ByteMemoryStream = null;
                try
                {
                    utf8ByteMemoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    /*char[]*/ let encodedChars = null;
                    /*byte[]*/ let asciiBytes = null;
                    /*byte[]*/ let signatureBytes = null;
                    /*byte[]*/ let payloadBytes = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(utf8ByteMemoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJwsHeader($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), tokenDescriptor);
                        /*int*/ let headerLength = $.$cast(utf8ByteMemoryStream.Length, $.$$.System.Int32);
                        /*int*/ let signatureSize = 0;
                        /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                        if (signingCredentials !== null)
                        {
                            signatureSize = $.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.GetMaxByteCount(signingCredentials.Algorithm);
                        }
                        payloadBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$$.System.Text.Encoding.UTF8.GetMaxByteCount(payload.length));
                        /*int*/ let payloadSize = $.$$.System.Text.Encoding.UTF8.GetBytes$6(payload, 0, payload.length, payloadBytes, 0);
                        /*int*/ let encodedBufferSize = (($.trunc((((((((headerLength + payloadSize) | 0) + 4) | 0) + signatureSize) | 0)) / 3) * 4) | 0);
                        encodedChars = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(((encodedBufferSize + 4) | 0));
                        /*int*/ let sizeOfEncodedHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, utf8ByteMemoryStream.GetBuffer(), 0, headerLength)), $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(encodedChars));
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, sizeOfEncodedHeader);
                        /*int*/ let sizeOfEncodedPayload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, payloadBytes, 0, payloadSize)), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, encodedChars, ((sizeOfEncodedHeader + 1) | 0)));
                        asciiBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$$.System.Text.Encoding.ASCII.GetMaxByteCount(encodedBufferSize));
                        /*int*/ let sizeOfEncodedHeaderAndPayloadAsciiBytes = $.$$.System.Text.Encoding.ASCII.GetBytes(encodedChars, 0, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0), asciiBytes, 0);
                        $.$$.System.Array.$WriteT1.call(encodedChars, /*.*/ 46, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 1) | 0));
                        /*int*/ let sizeOfEncodedSignature = 0;
                        if (signingCredentials !== null)
                        {
                            signatureBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(signatureSize);
                            /*int*/ let signatureLength;
                            /*bool*/ let signatureSucceeded = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateSignature($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, asciiBytes, 0, sizeOfEncodedHeaderAndPayloadAsciiBytes)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(signatureBytes), signingCredentials, $.$ref(() => signatureLength, ($v) => signatureLength = $v, $.$$.System.Int32));
                            sizeOfEncodedSignature = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, signatureBytes, 0, signatureLength)), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, encodedChars, ((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + 2) | 0)));
                        }
                        /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                        if (encryptingCredentials !== null)
                        {
                            return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptToken$1($.$$.System.Text.Encoding.UTF8.GetBytes$1(encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)), tokenDescriptor);
                        }
                        else 
                        {
                            return $.$$.System.Span$$($.$$.System.Char).ToString.call($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, encodedChars, 0, ((((((sizeOfEncodedHeader + sizeOfEncodedPayload) | 0) + sizeOfEncodedSignature) | 0) + 2) | 0)));
                        }
                    }
                    finally
                    {
                        {
                            if (!(encodedChars === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(encodedChars, false);
                            }
                            if (!(signatureBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(signatureBytes, false);
                            }
                            if (!(asciiBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(asciiBytes, false);
                            }
                            if (!(payloadBytes === null))
                            {
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(payloadBytes, false);
                            }
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    utf8ByteMemoryStream?.System$IDisposable$Dispose();
                }
            }
            static /*void */ WriteJwsPayload(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ setDefaultTimesOnTokenCreation, /*int*/ tokenLifetimeInMinutes)
            {
                /*bool*/ let descriptorClaimsAudienceChecked = false;
                /*bool*/ let audienceSet = false;
                /*bool*/ let descriptorClaimsIssuerChecked = false;
                /*bool*/ let issuerSet = false;
                /*bool*/ let descriptorClaimsExpChecked = false;
                /*bool*/ let expSet = false;
                /*bool*/ let descriptorClaimsIatChecked = false;
                /*bool*/ let iatSet = false;
                /*bool*/ let descriptorClaimsNbfChecked = false;
                /*bool*/ let nbfSet = false;
                writer.$v.WriteStartObject();
                if (tokenDescriptor.Audiences.System$Collections$Generic$ICollection$$$Count > 0)
                {
                    if (!$.$$.System.String.IsNullOrEmpty(tokenDescriptor.Audience))
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteStrings$1(writer, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud, tokenDescriptor.Audiences, tokenDescriptor.Audience);
                    }
                    else 
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteStrings$2(writer, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud, tokenDescriptor.Audiences);
                    }
                    audienceSet = true;
                }
                else if (!$.$$.System.String.IsNullOrEmpty(tokenDescriptor.Audience))
                {
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud);
                    writer.$v.WriteStringValue$5(tokenDescriptor.Audience);
                    audienceSet = true;
                }
                if (!$.$$.System.String.IsNullOrEmpty(tokenDescriptor.Issuer))
                {
                    issuerSet = true;
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iss);
                    writer.$v.WriteStringValue$5(tokenDescriptor.Issuer);
                }
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(tokenDescriptor.Expires))
                {
                    expSet = true;
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Exp);
                    writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(tokenDescriptor.Expires)));
                }
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(tokenDescriptor.IssuedAt))
                {
                    iatSet = true;
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iat);
                    writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(tokenDescriptor.IssuedAt)));
                }
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(tokenDescriptor.NotBefore))
                {
                    nbfSet = true;
                    writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Nbf);
                    writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(tokenDescriptor.NotBefore)));
                }
                /*bool*/ let isActorFound = false;
                /*bool*/ let rawActClaimWritten = false;
                if (tokenDescriptor.Claims !== null && tokenDescriptor.Claims.System$Collections$Generic$ICollection$$$Count > 0)
                {
                    var $en3 = tokenDescriptor.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kvp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.Equals$4.call(kvp.Key, "act"/*ActClaimType*/, 4/*StringComparison.Ordinal*/))
                            {
                                if ($.$is(kvp.Value, $.$ssc.System.Security.Claims.ClaimsIdentity))
                                {
                                    isActorFound = true;
                                    continue;
                                }
                                rawActClaimWritten = true;
                            }
                            if (!descriptorClaimsAudienceChecked && $.$$.System.String.Equals$4.call(kvp.Key, "aud"/*JwtRegisteredClaimNames.Aud*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsAudienceChecked = true;
                                if (audienceSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        /*string*/ let descriptorMemberName = null;
                                        if (tokenDescriptor.Audiences.System$Collections$Generic$ICollection$$$Count > 0)
                                        {
                                            descriptorMemberName = "Audiences";
                                        }
                                        else if (!$.$$.System.String.IsNullOrEmpty(tokenDescriptor.Audience))
                                        {
                                            descriptorMemberName = "Audience";
                                        }
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(descriptorMemberName) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                audienceSet = true;
                            }
                            if (!descriptorClaimsIssuerChecked && $.$$.System.String.Equals$4.call(kvp.Key, "iss"/*JwtRegisteredClaimNames.Iss*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsIssuerChecked = true;
                                if (issuerSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Issuer") ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                issuerSet = true;
                            }
                            if (!descriptorClaimsExpChecked && $.$$.System.String.Equals$4.call(kvp.Key, "exp"/*JwtRegisteredClaimNames.Exp*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsExpChecked = true;
                                if (expSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                expSet = true;
                            }
                            if (!descriptorClaimsIatChecked && $.$$.System.String.Equals$4.call(kvp.Key, "iat"/*JwtRegisteredClaimNames.Iat*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsIatChecked = true;
                                if (iatSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                iatSet = true;
                            }
                            if (!descriptorClaimsNbfChecked && $.$$.System.String.Equals$4.call(kvp.Key, "nbf"/*JwtRegisteredClaimNames.Nbf*/, 4/*StringComparison.Ordinal*/))
                            {
                                descriptorClaimsNbfChecked = true;
                                if (nbfSet)
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14113: A duplicate value for 'SecurityTokenDescriptor.{0}' exists in 'SecurityTokenDescriptor.Claims'. \nThe value of 'SecurityTokenDescriptor.{0}' is used."/*LogMessages.IDX14113*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Expires") ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                                    }
                                    continue;
                                }
                                nbfSet = true;
                            }
                            $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                        }
                    }
                }
                if (isActorFound || (!((tokenDescriptor.Subject?.Actor ?? null) === null) && !rawActClaimWritten))
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActor(writer, tokenDescriptor);
                }
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.AddSubjectClaims(writer, tokenDescriptor, audienceSet, issuerSet, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => expSet, ($v) => expSet = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => iatSet, ($v) => iatSet = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => nbfSet, ($v) => nbfSet = $v, null));
                if (setDefaultTimesOnTokenCreation && !(expSet && iatSet && nbfSet))
                {
                    /*DateTime*/ let now = $.$$.System.DateTime.UtcNow;
                    if (!expSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Exp);
                        writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.DateTime.op_Addition(now, $.$$.System.TimeSpan.FromMinutes$2(BigInt(tokenLifetimeInMinutes)))));
                    }
                    if (!iatSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iat);
                        writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate(now));
                    }
                    if (!nbfSet)
                    {
                        writer.$v.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Nbf);
                        writer.$v.WriteNumberValue$3($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate(now));
                    }
                }
                writer.$v.WriteEndObject();
                writer.$v.Flush();
            }
            static /*void */ AddSubjectClaims(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor, /*bool*/ audienceSet, /*bool*/ issuerSet, /*ref bool*/ expSet, /*ref bool*/ iatSet, /*ref bool*/ nbfSet)
            {
                if (tokenDescriptor.Subject === null)
                {
                    return;
                }
                /*bool*/ let expReset = false;
                /*bool*/ let iatReset = false;
                /*bool*/ let nbfReset = false;
                /*var*/ let payload = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                /*bool*/ let checkClaims = tokenDescriptor.Claims !== null && tokenDescriptor.Claims.System$Collections$Generic$ICollection$$$Count > 0;
                /*bool*/ let subjectHasActor = !(tokenDescriptor.Subject.Actor === null);
                var $en2 = tokenDescriptor.Subject.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if (subjectHasActor && $.$$.System.String.Equals$4.call(claim.Type, "act"/*ActClaimType*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if (checkClaims && tokenDescriptor.Claims.System$Collections$Generic$IDictionary$$$$ContainsKey(claim.Type, [$.$$.System.String, $.$$.System.Object]))
                        {
                            continue;
                        }
                        if (audienceSet && $.$$.System.String.Equals$4.call(claim.Type, "aud"/*JwtRegisteredClaimNames.Aud*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if (issuerSet && $.$$.System.String.Equals$4.call(claim.Type, "iss"/*JwtRegisteredClaimNames.Iss*/, 4/*StringComparison.Ordinal*/))
                        {
                            continue;
                        }
                        if ($.$$.System.String.Equals$4.call(claim.Type, "exp"/*JwtRegisteredClaimNames.Exp*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (expSet.$v)
                            {
                                continue;
                            }
                            expReset = true;
                        }
                        if ($.$$.System.String.Equals$4.call(claim.Type, "iat"/*JwtRegisteredClaimNames.Iat*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (iatSet.$v)
                            {
                                continue;
                            }
                            iatReset = true;
                        }
                        if ($.$$.System.String.Equals$4.call(claim.Type, "nbf"/*JwtRegisteredClaimNames.Nbf*/, 4/*StringComparison.Ordinal*/))
                        {
                            if (nbfSet.$v)
                            {
                                continue;
                            }
                            nbfReset = true;
                        }
                        /*object*/ let jsonClaimValue = $.$$.System.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetClaimValueUsingValueType(claim);
                        /*object*/ let existingValue;
                        if (payload.TryGetValue(claim.Type, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.System.Object)))
                        {
                            let existingList;
                            if ($.$is(existingValue, $.$$.System.Collections.Generic.List$$($.$$.System.Object), { set $v(v){ existingList = v; } }))
                            {
                                existingList.Add(jsonClaimValue);
                            }
                            else 
                            {
                                payload.set_Item(claim.Type, (() =>
                                {
                                    //new $.$$.System.Collections.Generic.List$$($.$$.System.Object)()
                                    const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.Object);
                                    const $i2 = new $t2();
                                    $i2.$ctor$1();
                                    $i2.Add(existingValue);
                                    $i2.Add(jsonClaimValue);
                                    return $i2;
                                })());
                            }
                        }
                        else 
                        {
                            payload.set_Item(claim.Type, jsonClaimValue);
                        }
                    }
                }
                var $en2 = payload.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                    }
                }
                expSet.$v = $.$$.System.Boolean.op_BitwiseOr(expSet.$v, expReset);
                iatSet.$v = $.$$.System.Boolean.op_BitwiseOr(iatSet.$v, iatReset);
                nbfSet.$v = $.$$.System.Boolean.op_BitwiseOr(nbfSet.$v, nbfReset);
            }
            static /*void */ WriteJwsHeader$1(/*ref Utf8JsonWriter*/ writer, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ jweHeaderClaims, /*IDictionary<string, object>*/ jwsHeaderClaims, /*string*/ tokenType, /*bool*/ includeKeyIdInHeader)
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJwsHeader(writer, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t2 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.SigningCredentials = signingCredentials;
                    $i2.EncryptingCredentials = encryptingCredentials;
                    $i2.AdditionalHeaderClaims = jweHeaderClaims;
                    $i2.AdditionalInnerHeaderClaims = jwsHeaderClaims;
                    $i2.TokenType = tokenType;
                    $i2.IncludeKeyIdInHeader = includeKeyIdInHeader;
                    return $i2;
                })());
            }
            static /*void */ WriteJwsHeader(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                /*IDictionary<string, object>*/ let jweHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                if ($.$$.System.Int32.op_GreaterThan$1((jweHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, jweHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("jweHeaderClaims"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.String.Join$5(", ", $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                /*IDictionary<string, object>*/ let jwsHeaderClaims = tokenDescriptor.AdditionalInnerHeaderClaims;
                if ($.$$.System.Int32.op_GreaterThan$1((jwsHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, jwsHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14116: '{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX14116*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("jwsHeaderClaims"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.String.Join$5(", ", $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DefaultHeaderParameters)) ], null, null))));
                }
                /*bool*/ let addJweHeaderClaims = tokenDescriptor.EncryptingCredentials === null && $.$$.System.Int32.op_GreaterThan$1((jweHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0);
                /*bool*/ let addJwsHeaderClaims = $.$$.System.Int32.op_GreaterThan$1((jwsHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0);
                /*bool*/ let typeWritten = false;
                writer.$v.WriteStartObject();
                /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                if (signingCredentials === null)
                {
                    writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Alg, "none"/*SecurityAlgorithms.None*/);
                }
                else 
                {
                    writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Alg, signingCredentials.Algorithm);
                    if (tokenDescriptor.IncludeKeyIdInHeader)
                    {
                        if ($.$$.System.String.op_Inequality(signingCredentials.Key.KeyId, null))
                        {
                            writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Kid, signingCredentials.Key.KeyId);
                        }
                        let x509SecurityKey;
                        if ($.$is(signingCredentials.Key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey, { set $v(v){ x509SecurityKey = v; } }))
                        {
                            writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.X5t, x509SecurityKey.X5t);
                        }
                    }
                }
                if (addJweHeaderClaims)
                {
                    var $en3 = jweHeaderClaims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kvp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (addJwsHeaderClaims && jwsHeaderClaims.System$Collections$Generic$IDictionary$$$$ContainsKey(kvp.Key, [$.$$.System.String, $.$$.System.Object]))
                            {
                                continue;
                            }
                            $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                            if (!typeWritten && $.$$.System.String.Equals$4.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                            {
                                typeWritten = true;
                            }
                        }
                    }
                }
                if (addJwsHeaderClaims)
                {
                    var $en3 = jwsHeaderClaims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kvp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                            if (!typeWritten && $.$$.System.String.Equals$4.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                            {
                                typeWritten = true;
                            }
                        }
                    }
                }
                if (!typeWritten)
                {
                    /*string*/ let tokenType = tokenDescriptor.TokenType;
                    writer.$v.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Typ, $.$$.System.String.IsNullOrEmpty(tokenType) ? "JWT"/*JwtConstants.HeaderType*/ : tokenType);
                }
                writer.$v.WriteEndObject();
                writer.$v.Flush();
            }
            static /*byte[] */ WriteJweHeader(/*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*string*/ tokenType, /*IDictionary<string, object>*/ jweHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJweHeader$1((() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    $i1.TokenType = tokenType;
                    $i1.AdditionalHeaderClaims = jweHeaderClaims;
                    $i1.IncludeKeyIdInHeader = includeKeyIdInHeader;
                    return $i1;
                })());
            }
            static /*byte[] */ WriteJweHeader$1(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(memoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        writer.WriteStartObject();
                        /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                        writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Alg, encryptingCredentials.Alg);
                        writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Enc, encryptingCredentials.Enc);
                        /*bool*/ let includeKeyIdInHeader = tokenDescriptor.IncludeKeyIdInHeader;
                        if ($.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                        {
                            if (includeKeyIdInHeader && $.$$.System.String.op_Inequality(encryptingCredentials.KeyExchangePublicKey.KeyId, null))
                            {
                                writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Kid, encryptingCredentials.KeyExchangePublicKey.KeyId);
                            }
                            if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(encryptingCredentials.Alg, [$.$$.System.String]))
                            {
                                writer.WritePropertyName$8($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Epk);
                                /*string*/ let publicJwk = $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKeyConverter.ConvertFromSecurityKey(encryptingCredentials.Key).RepresentAsAsymmetricPublicJwk();
                                writer.WriteRawValue$2(publicJwk, false);
                            }
                        }
                        else 
                        {
                            if (includeKeyIdInHeader && $.$$.System.String.op_Inequality(encryptingCredentials.Key.KeyId, null))
                            {
                                writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Kid, encryptingCredentials.Key.KeyId);
                            }
                        }
                        /*string*/ let compressionAlgorithm = tokenDescriptor.CompressionAlgorithm;
                        if (!$.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                        {
                            writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Zip, compressionAlgorithm);
                        }
                        /*bool*/ let typeWritten = false;
                        /*bool*/ let ctyWritten = !encryptingCredentials.SetDefaultCtyClaim;
                        /*IDictionary<string, object>*/ let jweHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                        if (jweHeaderClaims !== null && jweHeaderClaims.System$Collections$Generic$ICollection$$$Count > 0)
                        {
                            var $en5 = jweHeaderClaims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kvp = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), kvp.Key, kvp.Value);
                                    if (!typeWritten && $.$$.System.String.Equals$4.call(kvp.Key, "typ"/*JwtHeaderParameterNames.Typ*/, 4/*StringComparison.Ordinal*/))
                                    {
                                        typeWritten = true;
                                    }
                                    else if (!ctyWritten && $.$$.System.String.Equals$4.call(kvp.Key, "cty"/*JwtHeaderParameterNames.Cty*/, 4/*StringComparison.Ordinal*/))
                                    {
                                        ctyWritten = true;
                                    }
                                }
                            }
                        }
                        if (!typeWritten)
                        {
                            /*string*/ let tokenType = tokenDescriptor.TokenType;
                            writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Typ, $.$$.System.String.IsNullOrEmpty(tokenType) ? "JWT"/*JwtConstants.HeaderType*/ : tokenType);
                        }
                        if (!ctyWritten)
                        {
                            writer.WriteString$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Cty, "JWT"/*JwtConstants.HeaderType*/);
                        }
                        writer.WriteEndObject();
                        writer.Flush();
                        return memoryStream.ToArray();
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.System$IDisposable$Dispose();
                }
            }
            static /*void */ WriteActor(/*ref Utf8JsonWriter*/ writer, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                /*ClaimsIdentity*/ let actor = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.GetActorIdentity(tokenDescriptor);
                if (actor === null)
                {
                    return;
                }
                /*int*/ let remainingActorLevels = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.MaxActorChainLength;
                writer.$v.WritePropertyName$11("act"/*ActClaimType*/);
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorValue(writer, actor, remainingActorLevels);
            }
            static /*void */ WriteActorValue(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ actor, /*int*/ remainingActorLevels)
            {
                if (remainingActorLevels > 0)
                {
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorObject(writer, actor, remainingActorLevels);
                }
                else 
                {
                    writer.$v.WriteStringValue$5($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorAsJsonString(actor));
                }
            }
            static /*void */ WriteActorObject(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ actor, /*int*/ remainingActorLevels)
            {
                writer.$v.WriteStartObject();
                $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteIdentityClaims(writer, actor);
                if (!(actor.Actor === null))
                {
                    writer.$v.WritePropertyName$11("act"/*ActClaimType*/);
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorValue(writer, actor.Actor, ((remainingActorLevels - 1) | 0));
                }
                writer.$v.WriteEndObject();
            }
            static /*void */ WriteIdentityClaims(/*ref Utf8JsonWriter*/ writer, /*ClaimsIdentity*/ identity)
            {
                /*var*/ let payload = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                var $en2 = identity.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        /*object*/ let jsonClaimValue = $.$$.System.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetClaimValueUsingValueType(claim);
                        /*object*/ let existingValue;
                        if (payload.TryGetValue(claim.Type, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.System.Object)))
                        {
                            let existingList;
                            if ($.$is(existingValue, $.$$.System.Collections.Generic.List$$($.$$.System.Object), { set $v(v){ existingList = v; } }))
                            {
                                existingList.Add(jsonClaimValue);
                            }
                            else 
                            {
                                payload.set_Item(claim.Type, (() =>
                                {
                                    //new $.$$.System.Collections.Generic.List$$($.$$.System.Object)()
                                    const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.Object);
                                    const $i2 = new $t2();
                                    $i2.$ctor$1();
                                    $i2.Add(existingValue);
                                    $i2.Add(jsonClaimValue);
                                    return $i2;
                                })());
                            }
                        }
                        else 
                        {
                            payload.set_Item(claim.Type, jsonClaimValue);
                        }
                    }
                }
                var $en2 = payload.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObject(writer, kvp.Key, kvp.Value);
                    }
                }
            }
            static /*ClaimsIdentity */ GetActorIdentity(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                /*object*/ let actorValue;
                let actorIdentity;
                if ((tokenDescriptor.Claims?.System$Collections$Generic$IDictionary$$$$TryGetValue("act"/*ActClaimType*/, $.$ref(() => actorValue, ($v) => actorValue = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]) ?? null) === true && $.$is(actorValue, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ actorIdentity = v; } }))
                {
                    return actorIdentity;
                }
                return tokenDescriptor.Subject?.Actor ?? null;
            }
            static /*string */ WriteActorAsJsonString(/*ClaimsIdentity*/ actor)
            {
                let stream = null;
                try
                {
                    stream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let actorWriter = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(stream, new $.$stj.System.Text.Json.JsonWriterOptions());
                    $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteActorObject($.$ref(() => actorWriter, ($v) => actorWriter = $v, $.$stj.System.Text.Json.Utf8JsonWriter), actor, 2147483647/*int.MaxValue*/);
                    actorWriter.Flush();
                    return $.$$.System.Text.Encoding.UTF8.GetString(stream.GetBuffer(), 0, $.$cast(stream.Length, $.$$.System.Int32));
                }
                finally
                {
                    stream?.System$IDisposable$Dispose();
                }
            }
            static /*byte[] */ CompressToken(/*byte[]*/ utf8Bytes, /*string*/ compressionAlgorithm)
            {
                if ($.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("compressionAlgorithm");
                }
                if (!$.$mit.Microsoft.IdentityModel.Tokens.CompressionProviderFactory.Default.IsSupportedAlgorithm(compressionAlgorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.NotSupportedException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10682: Compression algorithm '{0}' is not supported."/*TokenLogMessages.IDX10682*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null))));
                }
                /*var*/ let compressionProvider = $.$mit.Microsoft.IdentityModel.Tokens.CompressionProviderFactory.Default.CreateCompressionProvider$1(compressionAlgorithm);
                return $.$firstOf(compressionProvider.Microsoft$IdentityModel$Tokens$ICompressionProvider$Compress(utf8Bytes), () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10680: Failed to compress using algorithm '{0}'."/*TokenLogMessages.IDX10680*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null)))) });
            }
            /*string */ EncryptToken$5(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials)
            {
                if ($.$$.System.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    return $i1;
                })());
            }
            /*string */ EncryptToken$2(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                if ($.$$.System.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if (additionalHeaderClaims === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            /*string */ EncryptToken$4(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ algorithm)
            {
                if ($.$$.System.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if ($.$$.System.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("algorithm");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = algorithm;
                    return $i1;
                })());
            }
            /*string */ EncryptToken$3(/*string*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ algorithm, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                if ($.$$.System.String.IsNullOrEmpty(innerJwt))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerJwt");
                }
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                if ($.$$.System.String.IsNullOrEmpty(algorithm))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("algorithm");
                }
                if (additionalHeaderClaims === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("additionalHeaderClaims");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptTokenPrivate(innerJwt, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = algorithm;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    return $i1;
                })());
            }
            static /*string */ EncryptTokenPrivate(/*string*/ innerJwt, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptToken$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(innerJwt), tokenDescriptor);
            }
            static /*string */ EncryptToken(/*byte[]*/ innerTokenUtf8Bytes, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ compressionAlgorithm, /*IDictionary<string, object>*/ additionalHeaderClaims, /*string*/ tokenType, /*bool*/ includeKeyIdInHeader)
            {
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.EncryptToken$1(innerTokenUtf8Bytes, (() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.CompressionAlgorithm = compressionAlgorithm;
                    $i1.AdditionalHeaderClaims = additionalHeaderClaims;
                    $i1.TokenType = tokenType;
                    $i1.IncludeKeyIdInHeader = includeKeyIdInHeader;
                    return $i1;
                })());
            }
            static /*string */ EncryptToken$1(/*byte[]*/ innerTokenUtf8Bytes, /*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                /*CryptoProviderFactory*/ let cryptoProviderFactory = encryptingCredentials.CryptoProviderFactory ?? encryptingCredentials.Key.CryptoProviderFactory;
                if (cryptoProviderFactory === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX10620: Unable to obtain a CryptoProviderFactory, both EncryptingCredentials.CryptoProviderFactory and EncryptingCredentials.Key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10620*/));
                }
                /*IDictionary<string, object>*/ let additionalHeaderClaims = tokenDescriptor.AdditionalHeaderClaims;
                /*byte[]*/ let wrappedKey;
                /*SecurityKey*/ let securityKey = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetSecurityKey(encryptingCredentials, cryptoProviderFactory, additionalHeaderClaims, $.$ref(() => wrappedKey, ($v) => wrappedKey = $v, $.$typeArray($.$$.System.Byte)));
                let encryptionProvider = null;
                try
                {
                    encryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(securityKey, encryptingCredentials.Enc);
                    if (encryptionProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX14103: Failed to create the token encryption provider."/*LogMessages.IDX14103*/));
                    }
                    /*byte[]*/ let jweHeader = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.WriteJweHeader$1(tokenDescriptor);
                    /*byte[]*/ let plainText;
                    /*string*/ let compressionAlgorithm = tokenDescriptor.CompressionAlgorithm;
                    if (!$.$$.System.String.IsNullOrEmpty(compressionAlgorithm))
                    {
                        try
                        {
                            plainText = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.CompressToken(innerTokenUtf8Bytes, compressionAlgorithm);
                        }
                        catch(ex)
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenCompressionFailedException().$ctor$13($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10680: Failed to compress using algorithm '{0}'."/*TokenLogMessages.IDX10680*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(compressionAlgorithm) ], null, null)), ex));
                        }
                    }
                    else 
                    {
                        plainText = innerTokenUtf8Bytes;
                    }
                    try
                    {
                        /*string*/ let rawHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(jweHeader);
                        /*var*/ let encryptionResult = encryptionProvider.Encrypt$1(plainText, $.$$.System.Text.Encoding.ASCII.GetBytes$8(rawHeader));
                        return $.$$.System.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg) ? $.$$.System.String.Join$8(".", $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ rawHeader, $.$$.System.String.Empty, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag) ])) : $.$$.System.String.Join$8(".", $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ rawHeader, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(wrappedKey), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag) ]));
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$13($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10616: Encryption failed. EncryptionProvider failed for: Algorithm: '{0}', SecurityKey: '{1}'. See inner exception."/*TokenLogMessages.IDX10616*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null)), ex));
                    }
                }
                finally
                {
                    encryptionProvider?.System$IDisposable$Dispose();
                }
            }
            /*IEnumerable<SecurityKey> */ GetContentEncryptionKeys$1(/*JsonWebToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (validationParameters.TokenDecryptionKeyResolver !== null)
                {
                    keys = validationParameters.TokenDecryptionKeyResolver.Invoke(jwtToken.EncodedToken, jwtToken, jwtToken.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey(jwtToken.EncodedToken, jwtToken, validationParameters);
                    if (key !== null)
                    {
                        if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10904: Token decryption key : '{0}' found in TokenValidationParameters."/*TokenLogMessages.IDX10904*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                        }
                    }
                    else if (configuration !== null)
                    {
                        key = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.ResolveTokenDecryptionKeyFromConfig(jwtToken, configuration);
                        if (key !== null && $.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10905: Token decryption key : '{0}' found in Configuration/Metadata."/*TokenLogMessages.IDX10905*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key.KeyId) ], null, null));
                        }
                    }
                    if (key !== null)
                    {
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (validationParameters.TryAllDecryptionKeys && $.$mit.Microsoft.IdentityModel.Tokens.CollectionUtilities.IsNullOrEmpty($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys))
                {
                    keys = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetAllDecryptionKeys(validationParameters);
                    if (configuration !== null)
                    {
                        keys = keys === null ? configuration.TokenDecryptionKeys : $.$sl.System.Linq.Enumerable.Concat($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keys, configuration.TokenDecryptionKeys);
                    }
                }
                if ($.$$.System.String.Equals$4.call(jwtToken.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/, 4/*StringComparison.Ordinal*/) || $.$$.System.String.Equals$4.call(jwtToken.Alg, "ECDH-ES"/*SecurityAlgorithms.EcdhEs*/, 4/*StringComparison.Ordinal*/))
                {
                    return keys;
                }
                /*var*/ let unwrappedKeys = new ($.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey))().$ctor$1();
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                if (keys !== null)
                {
                    var $en3 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(jwtToken.Alg, [$.$$.System.String]))
                                {
                                    /*ECDsaSecurityKey*/ let publicKey;
                                    if ($.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                                    {
                                        /*string*/ let epk;
                                        jwtToken.TryGetHeaderValue($.$$.System.String, "epk"/*JwtHeaderParameterNames.Epk*/, $.$ref(() => epk, ($v) => epk = $v, $.$$.System.String));
                                        publicKey = new $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey().$ctor$5(new $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKey().$ctor$4(epk), false);
                                    }
                                    else 
                                    {
                                        publicKey = $.$as(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey);
                                    }
                                    /*var*/ let ecdhKeyExchangeProvider = new $.$mit.Microsoft.IdentityModel.Tokens.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey), publicKey, jwtToken.Alg, jwtToken.Enc);
                                    /*string*/ let apu;
                                    jwtToken.TryGetHeaderValue($.$$.System.String, "apu"/*JwtHeaderParameterNames.Apu*/, $.$ref(() => apu, ($v) => apu = $v, $.$$.System.String));
                                    /*string*/ let apv;
                                    jwtToken.TryGetHeaderValue($.$$.System.String, "apv"/*JwtHeaderParameterNames.Apv*/, $.$ref(() => apv, ($v) => apv = $v, $.$$.System.String));
                                    /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                    /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                    /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.EncryptedKey));
                                    unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                                }
                                else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Alg, key))
                                {
                                    /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Alg);
                                    /*var*/ let unwrappedKey = kwp.UnwrapKey(jwtToken.EncryptedKeyBytes);
                                    unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                            }
                            (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2(key.KeyId);
                        }
                    }
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings === null)
                {
                    return unwrappedKeys;
                }
                else 
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenKeyWrapException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(exceptionStrings ?? ""), jwtToken ], null, null))));
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._mapInboundClaims = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.DefaultMapInboundClaims;
                this.TelemetryClient = new $.$mit.Microsoft.IdentityModel.Telemetry.TelemetryClient().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties";
                }
                {
                    this._shortClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/ShortTypeName";
                }
                {
                    this.DefaultInboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.InboundClaimTypeMap);
                }
                {
                    this.Base64UrlEncodedUnsignedJWSHeader = "eyJhbGciOiJub25lIn0";
                }
                {
                    this.s_emptyTokenDescriptor = new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor().$ctor$1();
                }
                {
                    this.ActClaimType = "act";
                }
            }
            static $h = 392477;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":16555057,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":68719869213,"f":50331649},"n":"TokenType","d":392477,"h":64424901917,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":77309803805,"f":50331681},"s":{"r":0,"d":0,"h":81604771101,"f":83886113},"n":"ShortClaimTypeProperty","d":392477,"h":73014836509,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":90194705693,"f":50331649},"s":{"r":0,"d":0,"h":94489672989,"f":83886081},"n":"MapInboundClaims","d":392477,"h":85899738397,"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":103079607581,"f":50331649},"s":{"r":0,"d":0,"h":107374574877,"f":83886081},"n":"InboundClaimTypeMap","d":392477,"h":98784640285,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":279173266717,"f":50331777},"n":"CanValidateToken","d":392477,"h":274878299421,"f":2097281},{"p":655361,"g":{"r":0,"d":0,"h":386547449117,"f":50331681},"s":{"r":0,"d":0,"h":390842416413,"f":83886113},"n":"MaxActorChainLength","d":392477,"h":382252481821,"f":2097185}],"m":[{"r":295390,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673}],"n":"CreateClaimsIdentity","o":"@$1","d":392477,"h":4295359773,"f":16777352},{"r":295390,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"issuer","p":1310721}],"n":"CreateClaimsIdentity","d":392477,"h":8590327069,"f":16777352},{"r":295390,"p":[{"n":"securityToken","p":13802545},{"n":"validationParameters","p":10394673},{"n":"issuer","p":1310721}],"n":"CreateClaimsIdentityInternal","d":392477,"h":12885294365,"f":16809992},{"r":295390,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"issuer","p":1310721}],"n":"CreateClaimsIdentityWithMapping","d":392477,"h":17180261661,"f":16777218},{"r":295390,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"issuer","p":1310721}],"n":"CreateClaimsIdentityPrivate","d":392477,"h":21475228957,"f":16777218},{"r":$.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,"p":[{"n":"token","p":1310721},{"n":"callContext","p":1874993}],"n":"ReadToken","o":"@$1","d":392477,"h":25770196253,"f":16777256},{"r":262145,"p":[{"n":"token","p":1310721}],"n":"CanReadToken","d":392477,"h":111669542173,"f":16777345},{"r":119341057,"p":[{"n":"securityKey","p":13671473}],"n":"GetStringComparisonRuleIf509","d":392477,"h":115964509469,"f":16777250},{"r":119341057,"p":[{"n":"securityKey","p":13671473}],"n":"GetStringComparisonRuleIf509OrECDsa","d":392477,"h":120259476765,"f":16777250},{"r":295390,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201}],"n":"CreateClaimsIdentity","o":"@$3","d":392477,"h":124554444061,"f":16777348},{"r":295390,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"issuer","p":1310721}],"n":"CreateClaimsIdentity","o":"@$2","d":392477,"h":128849411357,"f":16777348},{"r":295390,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"issuer","p":1310721}],"n":"CreateClaimsIdentityWithMapping","o":"@$1","d":392477,"h":133144378653,"f":16777218},{"r":295390,"p":[{"n":"securityToken","p":13802545},{"n":"tokenValidationParameters","p":16817201},{"n":"issuer","p":1310721}],"n":"CreateClaimsIdentityInternal","o":"@$1","d":392477,"h":137439345949,"f":16809992},{"r":1310721,"p":[{"n":"jwtToken","p":326941}],"n":"GetActualIssuer","d":392477,"h":141734313245,"f":16777250},{"r":295390,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"issuer","p":1310721}],"n":"CreateClaimsIdentityPrivate","o":"@$1","d":392477,"h":146029280541,"f":16777218},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"cancellationToken","p":125829121}],"n":"DecryptTokenWithConfigurationAsync","d":392477,"h":150324247837,"f":16781313},{"r":1310721,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201}],"n":"DecryptToken","o":"@$2","d":392477,"h":154619215133,"f":16777217},{"r":1310721,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"DecryptToken","o":"@$1","d":392477,"h":158914182429,"f":16777218},{"r":851229,"p":[{"n":"jwtToken","p":326941},{"n":"keys","p":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h}],"n":"CreateJwtTokenDecryptionParameters","d":392477,"h":163209149725,"f":16777218},{"r":13671473,"p":[{"n":"jwtToken","p":326941},{"n":"configuration","p":1678385}],"n":"ResolveTokenDecryptionKeyFromConfig","d":392477,"h":167504117021,"f":16777250},{"r":13671473,"p":[{"n":"token","p":1310721},{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201}],"n":"ResolveTokenDecryptionKey","d":392477,"h":171799084317,"f":16777348},{"r":326941,"p":[{"n":"token","p":1310721}],"n":"ReadJsonWebToken","o":"@$1","d":392477,"h":176094051613,"f":16777345},{"r":326941,"p":[{"n":"token","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":"ReadJsonWebToken","d":392477,"h":180389018909,"f":16777345},{"r":326941,"p":[{"n":"jsonWebToken","p":326941},{"n":"encodedHeader","p":1310721}],"n":"ReplaceTokenHeader","d":392477,"h":184683986205,"f":16777345},{"r":13802545,"p":[{"n":"token","p":1310721}],"n":"ReadToken","d":392477,"h":188978953501,"f":16809985},{"r":16882737,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201}],"n":"ReadToken","o":"@$2","d":392477,"h":193273920797,"f":16777250},{"r":$.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).$h,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":10394673},{"n":"callContext","p":1874993},{"n":"cancellationToken","p":125829121}],"n":"ValidateTokenAsync","d":392477,"h":197568888093,"f":16814088},{"r":$.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).$h,"p":[{"n":"token","p":13802545},{"n":"validationParameters","p":10394673},{"n":"callContext","p":1874993},{"n":"cancellationToken","p":125829121}],"n":"ValidateTokenAsync","o":"@$3","d":392477,"h":201863855389,"f":16814088},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"configuration","p":1678385},{"n":"callContext","p":1874993},{"n":"cancellationToken","p":125829121}],"n":"ValidateJWEAsync","d":392477,"h":206158822685,"f":16781314},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidatedToken, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError)).$h,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"configuration","p":1678385},{"n":"callContext","p":1874993},{"n":"cancellationToken","p":125829121}],"n":"ValidateJWSAsync","d":392477,"h":210453789981,"f":16781314},{"r":$.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.BaseConfiguration).$h,"p":[{"n":"validationParameters","p":10394673},{"n":"cancellationToken","p":125829121}],"n":"GetCurrentConfigurationAsync","d":392477,"h":214748757277,"f":16781346},{"r":$.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$$.System.String, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"configuration","p":1678385},{"n":"callContext","p":1874993}],"n":"DecryptToken","d":392477,"h":236223593757,"f":16777224},{"r":$.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey), $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"configuration","p":1678385},{"n":"callContext","p":1874993}],"n":"GetContentEncryptionKeys","d":392477,"h":240518561053,"f":16777224},{"r":13671473,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"callContext","p":1874993}],"n":"ResolveTokenDecryptionKey","o":"@$1","d":392477,"h":244813528349,"f":16777352},{"r":$.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"configuration","p":1678385},{"n":"callContext","p":1874993}],"n":"ValidateSignature","o":"@$1","d":392477,"h":249108495645,"f":16777224},{"r":$.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"configuration","p":1678385},{"n":"callContext","p":1874993}],"n":"ValidateSignatureUsingAllKeys","d":392477,"h":253403462941,"f":16777218},{"r":$.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationResult$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$mit.Microsoft.IdentityModel.Tokens.Experimental.ValidationError).$h,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":10394673},{"n":"key","p":13671473},{"n":"callContext","p":1874993}],"n":"ValidateSignatureWithKey","d":392477,"h":257698430237,"f":16777218},{"r":65537,"p":[{"n":"failedResult","p":$.$typeNullable($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler.KeyMatchFailedResult).$h},{"n":"exceptionStrings","p":122814465},{"n":"keysAttempted","p":122814465}],"n":"PopulateFailedResults","d":392477,"h":261993397533,"f":16777250},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateJWEAsync","o":"@$2","d":392477,"h":283468234013,"f":16781320},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385},{"n":"cancellationToken","p":125829121}],"n":"ValidateJWEAsync","o":"@$1","d":392477,"h":287763201309,"f":16781320},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateJWSAsync","o":"@$2","d":392477,"h":292058168605,"f":16781320},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385},{"n":"cancellationToken","p":125829121}],"n":"ValidateJWSAsync","o":"@$1","d":392477,"h":296353135901,"f":16781320},{"r":326941,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateSignatureAndIssuerSecurityKey","d":392477,"h":300648103197,"f":16777218},{"r":326941,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateSignature","o":"@$4","d":392477,"h":304943070493,"f":16777218},{"r":262145,"p":[{"n":"signatureBytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"signatureBytesLength","p":655361},{"n":"signatureProvider","p":15703089},{"n":"dataToVerify","p":$.$typeArray($.$$.System.Byte).$h},{"n":"dataToVerifyLength","p":655361}],"n":"IsSignatureValid","d":392477,"h":309238037789,"f":16777256},{"r":262145,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"len","p":655361},{"n":"stringWithSignature","p":1310721},{"n":"signatureStartIndex","p":655361},{"n":"signatureProvider","p":15703089}],"n":"ValidateSignature","d":392477,"h":313533005085,"f":16777256},{"r":262145,"p":[{"n":"jsonWebToken","p":326941},{"n":"key","p":13671473},{"n":"validationParameters","p":16817201}],"n":"ValidateSignature","o":"@$3","d":392477,"h":317827972381,"f":16777256},{"r":65537,"p":[{"n":"telemetryClient","p":236593},{"n":"errorType","p":1310721},{"n":"jsonWebToken","p":326941},{"n":"key","p":13671473}],"n":"RecordSignatureValidationTelemetry","d":392477,"h":322122939677,"f":16777250},{"r":262145,"p":[{"n":"jsonWebToken","p":326941},{"n":"key","p":13671473},{"n":"validationParameters","p":16817201},{"n":"telemetryClient","p":236593}],"n":"ValidateSignature","o":"@$2","d":392477,"h":326417906973,"f":16777256},{"r":326941,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":16817201}],"n":"ValidateSignatureUsingDelegates","d":392477,"h":330712874269,"f":16777250},{"r":16882737,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201}],"n":"ValidateToken","d":392477,"h":335007841565,"f":16777345,"a":[{"t":70909953,"c":12955811841,"a":[{"v":"\u0060JsonWebTokens.ValidateToken(string, TokenValidationParameters)\u0060 has been deprecated and will be removed in a future release. Use \u0060JsonWebTokens.ValidateTokenAsync(string, TokenValidationParameters)\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes","t":1310721},{"v":false,"t":262145}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201}],"n":"ValidateTokenAsync","o":"@$2","d":392477,"h":339302808861,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201},{"n":"cancellationToken","p":125829121}],"n":"ValidateTokenAsync","o":"@$1","d":392477,"h":343597776157,"f":16814081},{"r":$.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"token","p":13802545},{"n":"validationParameters","p":16817201}],"n":"ValidateTokenAsync","o":"@$5","d":392477,"h":347892743453,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"token","p":13802545},{"n":"validationParameters","p":16817201},{"n":"cancellationToken","p":125829121}],"n":"ValidateTokenAsync","o":"@$4","d":392477,"h":352187710749,"f":16814081},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"cancellationToken","p":125829121}],"n":"ValidateTokenAsync","o":"@$6","d":392477,"h":356482678045,"f":16781320},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateTokenPayloadAsync","o":"@$1","d":392477,"h":360777645341,"f":16781320},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"jsonWebToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385},{"n":"cancellationToken","p":125829121}],"n":"ValidateTokenPayloadAsync","d":392477,"h":365072612637,"f":16781320},{"r":1310721,"p":[{"n":"payload","p":1310721}],"n":"CreateToken","o":"@$13","d":392477,"h":395137383709,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"CreateToken","d":392477,"h":399432351005,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"signingCredentials","p":15965233}],"n":"CreateToken","o":"@$12","d":392477,"h":403727318301,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"signingCredentials","p":15965233},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"CreateToken","o":"@$5","d":392477,"h":408022285597,"f":16777345},{"r":1310721,"p":[{"n":"tokenDescriptor","p":14130225}],"n":"CreateToken","o":"@$15","d":392477,"h":412317252893,"f":16777345},{"r":1310721,"p":[{"n":"tokenDescriptor","p":14130225},{"n":"setdefaultTimesOnTokenCreation","p":262145},{"n":"tokenLifetimeInMinutes","p":655361}],"n":"CreateToken","o":"@$14","d":392477,"h":416612220189,"f":16777256},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"encryptingCredentials","p":3972145}],"n":"CreateToken","o":"@$3","d":392477,"h":420907187485,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"encryptingCredentials","p":3972145},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"CreateToken","o":"@$1","d":392477,"h":425202154781,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145}],"n":"CreateToken","o":"@$11","d":392477,"h":429497122077,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"CreateToken","o":"@$6","d":392477,"h":433792089373,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"encryptingCredentials","p":3972145},{"n":"compressionAlgorithm","p":1310721}],"n":"CreateToken","o":"@$2","d":392477,"h":438087056669,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145},{"n":"compressionAlgorithm","p":1310721}],"n":"CreateToken","o":"@$10","d":392477,"h":442382023965,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145},{"n":"compressionAlgorithm","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"additionalInnerHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"CreateToken","o":"@$8","d":392477,"h":446676991261,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145},{"n":"compressionAlgorithm","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"CreateToken","o":"@$9","d":392477,"h":450971958557,"f":16777345},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145},{"n":"compressionAlgorithm","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"additionalInnerHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"tokenType","p":1310721}],"n":"CreateToken","o":"@$7","d":392477,"h":455266925853,"f":16777256},{"r":1310721,"p":[{"n":"payload","p":1310721},{"n":"tokenDescriptor","p":14130225}],"n":"CreateToken","o":"@$4","d":392477,"h":459561893149,"f":16777256},{"r":65537,"p":[{"n":"writer","p":19116995,"f":4},{"n":"tokenDescriptor","p":14130225},{"n":"setDefaultTimesOnTokenCreation","p":262145},{"n":"tokenLifetimeInMinutes","p":655361}],"n":"WriteJwsPayload","d":392477,"h":463856860445,"f":16777256},{"r":65537,"p":[{"n":"writer","p":19116995,"f":4},{"n":"tokenDescriptor","p":14130225},{"n":"audienceSet","p":262145},{"n":"issuerSet","p":262145},{"n":"expSet","p":262145,"f":4},{"n":"iatSet","p":262145,"f":4},{"n":"nbfSet","p":262145,"f":4}],"n":"AddSubjectClaims","d":392477,"h":468151827741,"f":16777256},{"r":65537,"p":[{"n":"writer","p":19116995,"f":4},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145},{"n":"jweHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"jwsHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"tokenType","p":1310721},{"n":"includeKeyIdInHeader","p":262145}],"n":"WriteJwsHeader","o":"@$1","d":392477,"h":472446795037,"f":16777256},{"r":65537,"p":[{"n":"writer","p":19116995,"f":4},{"n":"tokenDescriptor","p":14130225}],"n":"WriteJwsHeader","d":392477,"h":476741762333,"f":16777256},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"encryptingCredentials","p":3972145},{"n":"compressionAlgorithm","p":1310721},{"n":"tokenType","p":1310721},{"n":"jweHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"includeKeyIdInHeader","p":262145}],"n":"WriteJweHeader","d":392477,"h":481036729629,"f":16777256},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"tokenDescriptor","p":14130225}],"n":"WriteJweHeader","o":"@$1","d":392477,"h":485331696925,"f":16777256},{"r":65537,"p":[{"n":"writer","p":19116995,"f":4},{"n":"tokenDescriptor","p":14130225}],"n":"WriteActor","d":392477,"h":489626664221,"f":16777256},{"r":65537,"p":[{"n":"writer","p":19116995,"f":4},{"n":"actor","p":295390},{"n":"remainingActorLevels","p":655361}],"n":"WriteActorValue","d":392477,"h":493921631517,"f":16777250},{"r":65537,"p":[{"n":"writer","p":19116995,"f":4},{"n":"actor","p":295390},{"n":"remainingActorLevels","p":655361}],"n":"WriteActorObject","d":392477,"h":498216598813,"f":16777250},{"r":65537,"p":[{"n":"writer","p":19116995,"f":4},{"n":"identity","p":295390}],"n":"WriteIdentityClaims","d":392477,"h":502511566109,"f":16777250},{"r":295390,"p":[{"n":"tokenDescriptor","p":14130225}],"n":"GetActorIdentity","d":392477,"h":506806533405,"f":16777250},{"r":1310721,"p":[{"n":"actor","p":295390}],"n":"WriteActorAsJsonString","d":392477,"h":511101500701,"f":16777250},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"utf8Bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"compressionAlgorithm","p":1310721}],"n":"CompressToken","d":392477,"h":515396467997,"f":16777256},{"r":1310721,"p":[{"n":"innerJwt","p":1310721},{"n":"encryptingCredentials","p":3972145}],"n":"EncryptToken","o":"@$5","d":392477,"h":519691435293,"f":16777217},{"r":1310721,"p":[{"n":"innerJwt","p":1310721},{"n":"encryptingCredentials","p":3972145},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"EncryptToken","o":"@$2","d":392477,"h":523986402589,"f":16777217},{"r":1310721,"p":[{"n":"innerJwt","p":1310721},{"n":"encryptingCredentials","p":3972145},{"n":"algorithm","p":1310721}],"n":"EncryptToken","o":"@$4","d":392477,"h":528281369885,"f":16777217},{"r":1310721,"p":[{"n":"innerJwt","p":1310721},{"n":"encryptingCredentials","p":3972145},{"n":"algorithm","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"EncryptToken","o":"@$3","d":392477,"h":532576337181,"f":16777217},{"r":1310721,"p":[{"n":"innerJwt","p":1310721},{"n":"tokenDescriptor","p":14130225}],"n":"EncryptTokenPrivate","d":392477,"h":536871304477,"f":16777250},{"r":1310721,"p":[{"n":"innerTokenUtf8Bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"encryptingCredentials","p":3972145},{"n":"compressionAlgorithm","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"tokenType","p":1310721},{"n":"includeKeyIdInHeader","p":262145}],"n":"EncryptToken","d":392477,"h":541166271773,"f":16777256},{"r":1310721,"p":[{"n":"innerTokenUtf8Bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"tokenDescriptor","p":14130225}],"n":"EncryptToken","o":"@$1","d":392477,"h":545461239069,"f":16777256},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,"p":[{"n":"jwtToken","p":326941},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"GetContentEncryptionKeys","o":"@$1","d":392477,"h":549756206365,"f":16777224}],"l":[{"t":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"_inboundClaimTypeMap","d":392477,"h":30065163549,"f":4194306},{"t":1310721,"n":"_namespace","d":392477,"h":34360130845,"f":4194338},{"t":1310721,"n":"_shortClaimType","d":392477,"h":38655098141,"f":4194338},{"t":262145,"n":"_mapInboundClaims","d":392477,"h":42950065437,"f":4194306},{"t":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"DefaultInboundClaimTypeMap","d":392477,"h":47245032733,"f":4194337},{"t":262145,"n":"DefaultMapInboundClaims","d":392477,"h":51540000029,"f":4194337},{"t":1310721,"n":"Base64UrlEncodedUnsignedJWSHeader","d":392477,"h":55834967325,"f":4194337},{"t":236593,"n":"TelemetryClient","d":392477,"h":270583332125,"f":4194312},{"t":14130225,"n":"s_emptyTokenDescriptor","d":392477,"h":369367579933,"f":4194338},{"t":1310721,"n":"ActClaimType","d":392477,"h":373662547229,"f":4194344},{"t":655361,"n":"s_maxActorChainLength","d":392477,"h":377957514525,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$2","d":392477,"h":60129934621,"f":16777217}],"i":[6003761],"j":[458013],"h":392477}; }
            static get $b() { return $.$mit.Microsoft.IdentityModel.Tokens.TokenHandler; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mit.Microsoft.IdentityModel.Tokens.Experimental.IResultBasedValidation ]; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler`; }
        });
        
        $asm.$cls("$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken", ($self) => class JsonWebToken extends $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken
        {
            /*JsonClaimSet */ CreateHeaderClaimSet$1(/*byte[]*/ bytes)
            {
                return this.CreateHeaderClaimSet$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Byte, bytes)));
            }
            /*JsonClaimSet */ CreateHeaderClaimSet(/*byte[]*/ bytes, /*int*/ length)
            {
                return this.CreateHeaderClaimSet$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, 0, length)));
            }
            /*JsonClaimSet */ CreateHeaderClaimSet$2(/*ReadOnlySpan<byte>*/ byteSpan)
            {
                /*Utf8JsonReader*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4(byteSpan, new $.$stj.System.Text.Json.JsonReaderOptions());
                if (!$.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Tokens.LogMessages.IDX11023*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.System.Text.Json.JsonTokenType)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.System.Int64)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.System.Int64)) ], null, null))));
                }
                /*Dictionary<string, object>*/ let claims = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$8($.trunc(byteSpan.Length / 32/*AverageJsonClaimLengthInBytes*/));
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        this.ReadHeaderValue($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), claims);
                    }
                    else if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 2/*JsonTokenType.EndObject*/, false))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet().$ctor$2(claims);
            }
            /*void */ ReadHeaderValue(/*ref Utf8JsonReader*/ reader, /*IDictionary<string, object>*/ claims)
            {
                if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Alg))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("alg"/*JwtHeaderParameterNames.Alg*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "alg"/*JwtHeaderParameterNames.Alg*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Cty))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("cty"/*JwtHeaderParameterNames.Cty*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "cty"/*JwtHeaderParameterNames.Cty*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Kid))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("kid"/*JwtHeaderParameterNames.Kid*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "kid"/*JwtHeaderParameterNames.Kid*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Typ))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("typ"/*JwtHeaderParameterNames.Typ*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "typ"/*JwtHeaderParameterNames.Typ*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.X5t))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("x5t"/*JwtHeaderParameterNames.X5t*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "x5t"/*JwtHeaderParameterNames.X5t*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtHeaderUtf8Bytes.Zip))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("zip"/*JwtHeaderParameterNames.Zip*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "zip"/*JwtHeaderParameterNames.Zip*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else 
                {
                    /*string*/ let claimName = reader.$v.GetString();
                    if (this.TryReadJwtClaim !== null)
                    {
                        reader.$v.Read();
                        /*object*/ let claimValue;
                        if (this.TryReadJwtClaim.Invoke(reader, 0/*JwtSegmentType.Header*/, claimName, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.System.Object)))
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, claimValue, [$.$$.System.String, $.$$.System.Object]);
                            reader.$v.Read();
                        }
                        else 
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, false), [$.$$.System.String, $.$$.System.Object]);
                        }
                    }
                    else 
                    {
                        claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                    }
                }
            }
            /*int*/ static AverageJsonClaimLengthInBytes = 32;
            /*JsonClaimSet */ CreatePayloadClaimSet(/*byte[]*/ bytes, /*int*/ length)
            {
                return this.CreatePayloadClaimSet$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, 0, length)));
            }
            /*JsonClaimSet */ CreatePayloadClaimSet$1(/*ReadOnlySpan<byte>*/ byteSpan)
            {
                if (byteSpan.Length === 0)
                {
                    return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet().$ctor$2((() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                        return $t1;
                    })());
                }
                /*Utf8JsonReader*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4(byteSpan, new $.$stj.System.Text.Json.JsonReaderOptions());
                if (!$.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Tokens.LogMessages.IDX11023*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.System.Text.Json.JsonTokenType)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.System.Int64)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.System.Int64)) ], null, null))));
                }
                /*Dictionary<string, object>*/ let claims = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$8($.trunc(byteSpan.Length / 32/*AverageJsonClaimLengthInBytes*/));
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        this.ReadPayloadValue($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), claims);
                    }
                    else if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 2/*JsonTokenType.EndObject*/, false))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet().$ctor$2(claims);
            }
            /*void */ ReadPayloadValue(/*ref Utf8JsonReader*/ reader, /*IDictionary<string, object>*/ claims)
            {
                if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud))
                {
                    /*List<string>*/ let _audiences = (() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                        return $t1;
                    })();
                    reader.$v.Read();
                    if (reader.$v.TokenType === 3/*JsonTokenType.StartArray*/)
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadStringsSkipNulls(reader, _audiences, "aud"/*JwtRegisteredClaimNames.Aud*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/);
                        claims.System$Collections$Generic$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences, [$.$$.System.String, $.$$.System.Object]);
                    }
                    else 
                    {
                        if (reader.$v.TokenType !== 11/*JsonTokenType.Null*/)
                        {
                            _audiences.Add($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "aud"/*JwtRegisteredClaimNames.Aud*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, false));
                            claims.System$Collections$Generic$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences.get_Item(0), [$.$$.System.String, $.$$.System.Object]);
                        }
                        else 
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, _audiences, [$.$$.System.String, $.$$.System.Object]);
                        }
                    }
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Azp))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("azp"/*JwtRegisteredClaimNames.Azp*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "azp"/*JwtRegisteredClaimNames.Azp*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Exp))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong(reader, "exp"/*JwtRegisteredClaimNames.Exp*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.System.Int64), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iat))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong(reader, "iat"/*JwtRegisteredClaimNames.Iat*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.System.Int64), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iss))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "iss"/*JwtRegisteredClaimNames.Iss*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Jti))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("jti"/*JwtRegisteredClaimNames.Jti*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString(reader, "jti"/*JwtRegisteredClaimNames.Jti*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Nbf))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong(reader, "nbf"/*JwtRegisteredClaimNames.Nbf*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), $.$$.System.Int64), [$.$$.System.String, $.$$.System.Object]);
                }
                else if (reader.$v.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Sub))
                {
                    claims.System$Collections$Generic$IDictionary$$$$set_Item("sub"/*JwtRegisteredClaimNames.Sub*/, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadStringOrNumberAsString(reader, "sub"/*JwtRegisteredClaimNames.Sub*/, "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken"/*ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                }
                else 
                {
                    /*string*/ let claimName = reader.$v.GetString();
                    if (this.TryReadJwtClaim !== null)
                    {
                        reader.$v.Read();
                        /*object*/ let claimValue;
                        if (this.TryReadJwtClaim.Invoke(reader, 1/*JwtSegmentType.Payload*/, claimName, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.System.Object)))
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, claimValue, [$.$$.System.String, $.$$.System.Object]);
                            reader.$v.Read();
                        }
                        else 
                        {
                            claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, false), [$.$$.System.String, $.$$.System.Object]);
                        }
                    }
                    else 
                    {
                        claims.System$Collections$Generic$IDictionary$$$$set_Item(claimName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject(reader, claimName, "Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet"/*JsonClaimSet.ClassName*/, true), [$.$$.System.String, $.$$.System.Object]);
                    }
                }
            }
            /*string*/ static ClassName = null;
            /*string*/ _act = null;
            /*string*/ _authenticationTag = null;
            /*string*/ _ciphertext = null;
            /*string*/ _encodedHeader = null;
            /*string*/ _encodedPayload = null;
            /*string*/ _encodedSignature = null;
            /*string*/ _encodedToken = null;
            /*string*/ _encryptedKey = null;
            /*string*/ _initializationVector = null;
            /*List<string>*/ _audiences = null;
            /*ReadOnlyMemory<char>*/ _encodedTokenMemory;
            /*string*/ _alg = null;
            /*string*/ _cty = null;
            /*string*/ _enc = null;
            /*string*/ _kid = null;
            /*string*/ _typ = null;
            /*string*/ _x5t = null;
            /*string*/ _zip = null;
            /*string*/ _azp = null;
            /*long?*/ _exp = null;
            /*DateTime?*/ _expDateTime = null;
            /*long?*/ _iat = null;
            /*DateTime?*/ _iatDateTime = null;
            /*string*/ _id = null;
            /*string*/ _iss = null;
            /*string*/ _jti = null;
            /*string*/ _sub = null;
            /*long?*/ _nbf = null;
            /*DateTime?*/ _nbfDateTime = null;
            /*DateTime?*/ _validFrom = null;
            /*DateTime?*/ _validTo = null;
            $ctor$7(/*string*/ jwtEncodedString)
            {
                super.$ctor$1();
                {
                    if ($.$$.System.String.IsNullOrEmpty(jwtEncodedString))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("jwtEncodedString"));
                    }
                    this.ReadToken($.$$.System.MemoryExtensions.AsMemory$4(jwtEncodedString));
                    this._encodedToken = jwtEncodedString;
                }
                return this;
            }
            $ctor$6(/*string*/ jwtEncodedString, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    if ($.$$.System.String.IsNullOrEmpty(jwtEncodedString))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("jwtEncodedString"));
                    }
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken($.$$.System.MemoryExtensions.AsMemory$4(jwtEncodedString));
                    this._encodedToken = jwtEncodedString;
                }
                return this;
            }
            $ctor$3(/*ReadOnlyMemory<char>*/ encodedTokenMemory)
            {
                super.$ctor$1();
                {
                    if (encodedTokenMemory.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("encodedTokenMemory"));
                    }
                    this.ReadToken(encodedTokenMemory);
                    this._encodedTokenMemory = encodedTokenMemory;
                }
                return this;
            }
            $ctor$2(/*ReadOnlyMemory<char>*/ encodedTokenMemory, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    if (encodedTokenMemory.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("encodedTokenMemory"));
                    }
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken(encodedTokenMemory);
                    this._encodedTokenMemory = encodedTokenMemory;
                }
                return this;
            }
            $ctor$5(/*string*/ header, /*string*/ payload)
            {
                super.$ctor$1();
                {
                    if ($.$$.System.String.IsNullOrEmpty(header))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                    /*var*/ let encodedHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(header);
                    /*var*/ let encodedPayload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(payload);
                    /*var*/ let encodedToken = encodedHeader + "." + encodedPayload + ".";
                    this.ReadToken($.$$.System.MemoryExtensions.AsMemory$4(encodedToken));
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            $ctor$4(/*string*/ header, /*string*/ payload, /*TryReadJwtClaim*/ tryReadJwtClaim)
            {
                super.$ctor$1();
                {
                    if ($.$$.System.String.IsNullOrEmpty(header))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    _ = $.$firstOf(payload, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload") });
                    /*var*/ let encodedHeader = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(header);
                    /*var*/ let encodedPayload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(payload);
                    /*var*/ let encodedToken = encodedHeader + "." + encodedPayload + ".";
                    this.TryReadJwtClaim = tryReadJwtClaim;
                    this.ReadToken($.$$.System.MemoryExtensions.AsMemory$4(encodedToken));
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            $ctor$8(/*JsonWebToken*/ jsonWebToken, /*string*/ encodedHeader)
            {
                super.$ctor$1();
                {
                    _ = $.$firstOf(jsonWebToken, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jsonWebToken") });
                    if ($.$$.System.String.IsNullOrEmpty(encodedHeader))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encodedHeader");
                    }
                    if (jsonWebToken.IsEncrypted)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$13("IDX14117: Cannot create a 'JsonWebToken' with a replaced header from an encrypted (JWE) token. The provided token must be a JWS so that its decoded payload can be reused."/*LogMessages.IDX14117*/, "jsonWebToken"));
                    }
                    /*string*/ let encodedPayload = jsonWebToken.EncodedPayload;
                    /*string*/ let encodedSignature = jsonWebToken.EncodedSignature;
                    /*int*/ let totalLength = ((((((((encodedHeader.length + 1) | 0) + encodedPayload.length) | 0) + 1) | 0) + encodedSignature.length) | 0);
                    /*string*/ let encodedToken = $.$$.System.String.Create$10($.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String), totalLength, new ($.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor$3(encodedHeader, encodedPayload, encodedSignature), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String)))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken, /*static*/ (/**/ span, /*state*/ state) =>
                    {
                        /*var*/ let  [ header, payload, signature ] = $.$destructure(state);
                        $.$$.System.MemoryExtensions.AsSpan$4(header).CopyTo(span);
                        /*int*/ let pos = header.length;
                        span.get_Item(pos++).$v = /*.*/ 46;
                        $.$$.System.MemoryExtensions.AsSpan$4(payload).CopyTo(span.Slice$1(pos));
                        pos += payload.length;
                        span.get_Item(pos++).$v = /*.*/ 46;
                        $.$$.System.MemoryExtensions.AsSpan$4(signature).CopyTo(span.Slice$1(pos));
                    }, {"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"state","p":$.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String).$h}],"n":"","d":326941,"h":0,"f":17825826}));
                    this.Dot1 = encodedHeader.length;
                    this.Dot2 = ((((this.Dot1 + 1) | 0) + encodedPayload.length) | 0);
                    this.Dot3 = -1;
                    this.IsSigned = encodedSignature.length > 0;
                    this.Header = this.CreateClaimSet($.$$.System.MemoryExtensions.AsSpan$4(encodedToken), 0, this.Dot1, true);
                    this.Payload = jsonWebToken.Payload;
                    this._encodedToken = encodedToken;
                }
                return this;
            }
            /*TryReadJwtClaim*/ TryReadJwtClaim = null;
            /*string*/ ActualIssuer = null;
            /*ClaimsIdentity*/ ActorClaimsIdentity = null;
            /*string */ get AuthenticationTag()
            {
                this._authenticationTag ??= this.AuthenticationTagBytes === null ? $.$$.System.String.Empty : $.$$.System.Text.Encoding.UTF8.GetString$1(this.AuthenticationTagBytes);
                return this._authenticationTag;
            }
            /*byte[]*/ AuthenticationTagBytes = null;
            /*string */ get Ciphertext()
            {
                this._ciphertext ??= this.CipherTextBytes === null ? $.$$.System.String.Empty : $.$$.System.Text.Encoding.UTF8.GetString$1(this.CipherTextBytes);
                return this._ciphertext;
            }
            /*byte[]*/ CipherTextBytes = null;
            /*int*/ Dot1 = 0;
            /*int*/ Dot2 = 0;
            /*int*/ Dot3 = 0;
            /*int*/ Dot4 = 0;
            /*string */ get EncodedHeader()
            {
                if ($.$$.System.String.op_Equality(this._encodedHeader, null))
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedHeader = $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(this._encodedTokenMemory.Span.Slice(0, this.Dot1));
                    }
                    else 
                    {
                        this._encodedHeader = (!(this._encodedToken === null)) ? $.$$.System.String.Substring.call(this._encodedToken, 0, this.Dot1) : $.$$.System.String.Empty;
                    }
                }
                return this._encodedHeader;
            }
            /*string */ get EncryptedKey()
            {
                if ($.$$.System.String.op_Equality(this._encryptedKey, null))
                {
                    this._encryptedKey = this.EncryptedKeyBytes === null ? $.$$.System.String.Empty : $.$$.System.Text.Encoding.UTF8.GetString$1(this.EncryptedKeyBytes);
                }
                return this._encryptedKey;
            }
            /*byte[]*/ EncryptedKeyBytes = null;
            /*string */ get EncodedPayload()
            {
                if ($.$$.System.String.op_Equality(this._encodedPayload, null))
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedPayload = this.IsEncrypted ? $.$$.System.String.Empty : $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(this._encodedTokenMemory.Span.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0)));
                    }
                    else 
                    {
                        if (!(this._encodedToken === null))
                        {
                            this._encodedPayload = this.IsEncrypted ? $.$$.System.String.Empty : $.$$.System.String.Substring.call(this._encodedToken, ((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0));
                        }
                        else 
                        {
                            this._encodedPayload = $.$$.System.String.Empty;
                        }
                    }
                }
                return this._encodedPayload;
            }
            /*string */ get EncodedSignature()
            {
                if ($.$$.System.String.op_Equality(this._encodedSignature, null))
                {
                    if (!this._encodedTokenMemory.IsEmpty)
                    {
                        this._encodedSignature = this.IsEncrypted ? $.$$.System.String.Empty : $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(this._encodedTokenMemory.Span.Slice(((this.Dot2 + 1) | 0), ((((this._encodedTokenMemory.Length - this.Dot2) | 0) - 1) | 0)));
                    }
                    else 
                    {
                        if (!(this._encodedToken === null))
                        {
                            this._encodedSignature = this.IsEncrypted ? $.$$.System.String.Empty : $.$$.System.String.Substring.call(this._encodedToken, ((this.Dot2 + 1) | 0), ((((this._encodedToken.length - this.Dot2) | 0) - 1) | 0));
                        }
                        else 
                        {
                            this._encodedSignature = $.$$.System.String.Empty;
                        }
                    }
                }
                return this._encodedSignature;
            }
            /*string */ get EncodedToken()
            {
                if (this._encodedToken === null && !this._encodedTokenMemory.IsEmpty)
                {
                    this._encodedToken = $.$$.System.ReadOnlyMemory$$($.$$.System.Char).ToString.call(this._encodedTokenMemory);
                }
                return this._encodedToken;
            }
            /*JsonClaimSet*/ Header = null;
            /*byte[]*/ HeaderAsciiBytes = null;
            /*byte[]*/ InitializationVectorBytes = null;
            /*string */ get InitializationVector()
            {
                if (this.InitializationVectorBytes === null)
                {
                    this._initializationVector = this.InitializationVectorBytes === null ? $.$$.System.String.Empty : $.$$.System.Text.Encoding.UTF8.GetString$1(this.InitializationVectorBytes);
                }
                return this._initializationVector;
            }
            /*JsonWebToken*/ InnerToken = null;
            /*bool */ get IsEncrypted()
            {
                return this.CipherTextBytes !== null;
            }
            /*bool*/ IsSigned = false;
            /*JsonClaimSet*/ Payload = null;
            /*SecurityKey*/ SecurityKey = null;
            /*SecurityKey*/ SigningKey = null;
            /*byte[]*/ MessageBytes = null;
            /*int*/ NumberOfDots = 0;
            /*void */ ReadToken(/*ReadOnlyMemory<char>*/ encodedTokenMemory)
            {
                /*ReadOnlySpan<char>*/ let encodedTokenSpan = encodedTokenMemory.Span;
                this.Dot1 = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan, /*.*/ 46);
                if (this.Dot1 === -1 || this.Dot1 === ((encodedTokenSpan.Length - 1) | 0))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14100: JWT is not well formed, there are no dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14100*/));
                }
                this.Dot2 = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan.Slice$1(((this.Dot1 + 1) | 0)), /*.*/ 46);
                if (this.Dot2 === -1)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14120: JWT is not well formed, there is only one dot (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14120*/));
                }
                this.Dot2 = ((((this.Dot1 + this.Dot2) | 0) + 1) | 0);
                this.Dot3 = (this.Dot2 === ((encodedTokenSpan.Length - 1) | 0)) ? -1 : $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan.Slice$1(((this.Dot2 + 1) | 0)), /*.*/ 46);
                if (this.Dot3 === -1)
                {
                    this.IsSigned = !(((this.Dot2 + 1) | 0) === encodedTokenSpan.Length);
                    try
                    {
                        this.Header = this.CreateClaimSet(encodedTokenSpan, 0, this.Dot1, true);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14102: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX14102*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsUnsafeSecurityArtifact($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(encodedTokenSpan.Slice(0, this.Dot1)), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor(this,  (/**/ t) =>
                        {
                            return $.$$.System.Object.ToString.call(t);
                        }, {"r":1310721,"p":[{"n":"t","p":131073}],"n":"","d":326941,"h":0,"f":17825794})) ], null, null)), ex));
                    }
                    try
                    {
                        this.Payload = this.CreateClaimSet(encodedTokenSpan, ((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0), false);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14101: Unable to decode the payload '{0}' as Base64Url encoded string."/*LogMessages.IDX14101*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsUnsafeSecurityArtifact($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(encodedTokenSpan.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0))), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$$.System.Object.ToString.call(t);
                        }, {"r":1310721,"p":[{"n":"t","p":131073}],"n":"","d":326941,"h":0,"f":17825794})) ], null, null)), ex));
                    }
                }
                else 
                {
                    this.Payload = new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet().$ctor$1();
                    this.Dot3 = ((((this.Dot2 + this.Dot3) | 0) + 1) | 0);
                    if (this.Dot3 === ((encodedTokenSpan.Length - 1) | 0))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14121*/));
                    }
                    this.Dot4 = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan.Slice$1(((this.Dot3 + 1) | 0)), /*.*/ 46);
                    if (this.Dot4 === -1)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14121: JWT is not a well formed JWE, there must be four dots (.).\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14121*/));
                    }
                    this.Dot4 = ((((this.Dot3 + this.Dot4) | 0) + 1) | 0);
                    if (this.Dot4 === ((encodedTokenSpan.Length - 1) | 0))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14310: JWE authentication tag is missing."/*LogMessages.IDX14310*/));
                    }
                    if ($.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, encodedTokenSpan.Slice$1(((this.Dot4 + 1) | 0)), /*.*/ 46) !== -1)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX14122: JWT is not a well formed JWE, there are more than four dots (.) a JWE can have at most 4 dots.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX14122*/));
                    }
                    /*ReadOnlySpan<char>*/ let headerSpan = encodedTokenSpan.Slice(0, this.Dot1);
                    if (headerSpan.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX14307: JWE header is missing."/*LogMessages.IDX14307*/));
                    }
                    /*byte[]*/ let headerAsciiBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [headerSpan.Length], null);
                    $.$$.System.Text.Encoding.ASCII.GetBytes$5(headerSpan, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(headerAsciiBytes));
                    this.HeaderAsciiBytes = headerAsciiBytes;
                    try
                    {
                        this.Header = this.CreateHeaderClaimSet$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Byte, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(headerSpan))));
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX14102: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX14102*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsUnsafeSecurityArtifact($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(headerSpan), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor(this,  (/**/ t) =>
                        {
                            return $.$$.System.Object.ToString.call(t);
                        }, {"r":1310721,"p":[{"n":"t","p":131073}],"n":"","d":326941,"h":0,"f":17825794})) ], null, null)), ex));
                    }
                    /*ReadOnlySpan<char>*/ let encryptedKeyBytes = encodedTokenSpan.Slice(((this.Dot1 + 1) | 0), ((((this.Dot2 - this.Dot1) | 0) - 1) | 0));
                    if (!encryptedKeyBytes.IsEmpty)
                    {
                        this.EncryptedKeyBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(encryptedKeyBytes);
                        this._encryptedKey = $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(encryptedKeyBytes);
                    }
                    else 
                    {
                        this._encryptedKey = $.$$.System.String.Empty;
                    }
                    /*ReadOnlySpan<char>*/ let initializationVectorSpan = encodedTokenSpan.Slice(((this.Dot2 + 1) | 0), ((((this.Dot3 - this.Dot2) | 0) - 1) | 0));
                    if (initializationVectorSpan.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX14308: JWE initialization vector is missing."/*LogMessages.IDX14308*/));
                    }
                    try
                    {
                        this.InitializationVectorBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(initializationVectorSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11("IDX14309: Unable to decode the initialization vector as Base64Url encoded string."/*LogMessages.IDX14309*/, ex));
                    }
                    /*ReadOnlySpan<char>*/ let authTagSpan = encodedTokenSpan.Slice$1(((this.Dot4 + 1) | 0));
                    if (authTagSpan.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX14310: JWE authentication tag is missing."/*LogMessages.IDX14310*/));
                    }
                    try
                    {
                        this.AuthenticationTagBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(authTagSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11("IDX14311: Unable to decode the authentication tag as a Base64Url encoded string."/*LogMessages.IDX14311*/, ex));
                    }
                    /*ReadOnlySpan<char>*/ let cipherTextSpan = encodedTokenSpan.Slice(((this.Dot3 + 1) | 0), ((((this.Dot4 - this.Dot3) | 0) - 1) | 0));
                    if (cipherTextSpan.IsEmpty)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX14306: JWE Ciphertext cannot be an empty string."/*LogMessages.IDX14306*/));
                    }
                    try
                    {
                        this.CipherTextBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$2(cipherTextSpan);
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11("IDX14312: Unable to decode the cipher text as a Base64Url encoded string."/*LogMessages.IDX14312*/, ex));
                    }
                }
            }
            /*JsonClaimSet */ CreateClaimSet(/*ReadOnlySpan<char>*/ strSpan, /*int*/ startIndex, /*int*/ length, /*bool*/ createHeaderClaimSet)
            {
                /*int*/ let outputSize = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoding.ValidateAndGetOutputSize(strSpan, startIndex, length);
                /*byte[]*/ let rented = null;
                /*int*/ let MaxStackallocThreshold = 256;
                /*Span<byte>*/ let output = outputSize <= MaxStackallocThreshold ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, outputSize, null) : ($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rented = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(outputSize)));
                try
                {
                    $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$1(strSpan.Slice(startIndex, length), output);
                    return createHeaderClaimSet ? this.CreateHeaderClaimSet$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit(output)) : this.CreatePayloadClaimSet$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit(output));
                }
                finally
                {
                    {
                        if (!(rented === null))
                        {
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(rented, true);
                        }
                    }
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$$.System.String.Substring.call(this.EncodedToken, 0, $.$$.System.String.LastIndexOf$2.call(this.EncodedToken, /*.*/ 46));
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.ToString.apply(this, arguments); }
            /*string */ UnsafeToString()
            {
                return this.EncodedToken;
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                return this.Payload.Claims(this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/);
            }
            /*Claim */ GetClaim(/*string*/ key)
            {
                return this.Payload.GetClaim(key, this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/);
            }
            /*IReadOnlyCollection<string> */ get PayloadClaimNames()
            {
                return this.Payload._jsonClaims.Keys;
            }
            /*bool */ TryGetClaim(/*string*/ key, /*out Claim*/ value)
            {
                return this.Payload.TryGetClaim(key, this.Issuer ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, value);
            }
            /*bool */ HasPayloadClaim(/*string*/ claimName)
            {
                return this.Payload.HasClaim(claimName);
            }
            /*T */ GetHeaderValue(T, /*string*/ key)
            {
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                }
                return this.Header.GetValue$1(T, key);
            }
            /*T */ GetPayloadValue(T, /*string*/ key)
            {
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                }
                if (T.$type.Equals$2($.$ssc.System.Security.Claims.Claim.$type))
                {
                    return $.$cast(this.GetClaim(key), T);
                }
                return this.Payload.GetValue$1(T, key);
            }
            /*bool */ TryGetValue(T, /*string*/ key, /*out T*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                return this.Payload.TryGetValue(T, key, value);
            }
            /*bool */ TryGetHeaderValue(T, /*string*/ key, /*out T*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                return this.Header.TryGetValue(T, key, value);
            }
            /*bool */ TryGetPayloadValue(T, /*string*/ key, /*out T*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                if (T.$type.Equals$2($.$ssc.System.Security.Claims.Claim.$type))
                {
                    /*var*/ let claim;
                    /*bool*/ let foundClaim = this.TryGetClaim(key, $.$ref(() => claim, ($v) => claim = $v, $.$ssc.System.Security.Claims.Claim));
                    value.$v = $.$cast(claim, T);
                    return foundClaim;
                }
                return this.Payload.TryGetValue(T, key, value);
            }
            /*string */ get Alg()
            {
                this._alg ??= this.Header.GetStringValue("alg"/*JwtHeaderParameterNames.Alg*/);
                return this._alg;
            }
            /*string */ get Cty()
            {
                this._cty ??= this.Header.GetStringValue("cty"/*JwtHeaderParameterNames.Cty*/);
                return this._cty;
            }
            /*string */ get Enc()
            {
                this._enc ??= this.Header.GetStringValue("enc"/*JwtHeaderParameterNames.Enc*/);
                return this._enc;
            }
            /*string */ get Kid()
            {
                this._kid ??= this.Header.GetStringValue("kid"/*JwtHeaderParameterNames.Kid*/);
                return this._kid;
            }
            /*string */ get Typ()
            {
                this._typ ??= this.Header.GetStringValue("typ"/*JwtHeaderParameterNames.Typ*/);
                return this._typ;
            }
            /*string */ set Typ(value)
            {
                this._typ = value;
            }
            /*string */ get X5t()
            {
                this._x5t ??= this.Header.GetStringValue("x5t"/*JwtHeaderParameterNames.X5t*/);
                return this._x5t;
            }
            /*string */ get Zip()
            {
                this._zip ??= this.Header.GetStringValue("zip"/*JwtHeaderParameterNames.Zip*/);
                return this._zip;
            }
            /*string */ get Actor()
            {
                this._act ??= this.Payload.GetStringValue("actort"/*JwtRegisteredClaimNames.Actort*/);
                return this._act;
            }
            /*IEnumerable<string> */ get Audiences()
            {
                if (this._audiences === null)
                {
                    /*List<string>*/ let audiences;
                    /*List<string>*/ let tmp = this.TryGetValue($.$$.System.Collections.Generic.List$$($.$$.System.String), "aud"/*JwtRegisteredClaimNames.Aud*/, $.$ref(() => audiences, ($v) => audiences = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String))) ? audiences : new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Collections.Generic.List$$($.$$.System.String), $.$ref(() => this._audiences, ($v) => this._audiences = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String)), tmp, null);
                }
                return this._audiences;
            }
            /*string */ get Azp()
            {
                this._azp ??= this.Payload.GetStringValue("azp"/*JwtRegisteredClaimNames.Azp*/);
                return this._azp;
            }
            /*DateTime */ get IssuedAt()
            {
                this._iatDateTime ??= this.Payload.GetDateTime("iat"/*JwtRegisteredClaimNames.Iat*/);
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._iatDateTime);
            }
            /*string */ get Issuer()
            {
                this._iss ??= this.Payload.GetStringValue("iss"/*JwtRegisteredClaimNames.Iss*/);
                return this._iss;
            }
            /*string */ get Id()
            {
                this._jti ??= this.Payload.GetStringValue("jti"/*JwtRegisteredClaimNames.Jti*/);
                return this._jti;
            }
            /*string */ get Subject()
            {
                this._sub ??= this.Payload.GetStringValue("sub"/*JwtRegisteredClaimNames.Sub*/);
                return this._sub;
            }
            /*DateTime */ get ValidFrom()
            {
                this._validFrom ??= this.Payload.GetDateTime("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._validFrom);
            }
            /*DateTime? */ get ValidFromNullable()
            {
                this._validFrom ??= this.Payload.GetDateTime("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                return this._validFrom;
            }
            /*DateTime */ get ValidTo()
            {
                this._validTo ??= this.Payload.GetDateTime("exp"/*JwtRegisteredClaimNames.Exp*/);
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._validTo);
            }
            /*DateTime? */ get ValidToNullable()
            {
                this._validTo ??= this.Payload.GetDateTime("exp"/*JwtRegisteredClaimNames.Exp*/);
                return this._validTo;
            }
            //default member initializer
            constructor()
            {
                super();
                this._encodedTokenMemory = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                this._expDateTime = null;
                this._iatDateTime = null;
                this._nbfDateTime = null;
                this._validFrom = null;
                this._validTo = null;
                this.IsSigned = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ClassName = "Microsoft.IdentityModel.JsonWebTokens.JsonWebToken";
                }
            }
            static $h = 326941;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":13802545,"p":[{"p":17013809,"g":{"r":0,"d":0,"h":214748691741,"f":50331650},"s":{"r":0,"d":0,"h":219043659037,"f":83886082},"n":"TryReadJwtClaim","d":326941,"h":210453724445,"f":2097154},{"p":1310721,"g":{"r":0,"d":0,"h":231928560925,"f":50331656},"s":{"r":0,"d":0,"h":236223528221,"f":83886088},"n":"ActualIssuer","d":326941,"h":227633593629,"f":2097160},{"p":295390,"g":{"r":0,"d":0,"h":249108430109,"f":50331656},"s":{"r":0,"d":0,"h":253403397405,"f":83886088},"n":"ActorClaimsIdentity","d":326941,"h":244813462813,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":261993331997,"f":50331649},"n":"AuthenticationTag","d":326941,"h":257698364701,"f":2097153},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":274878233885,"f":50331656},"s":{"r":0,"d":0,"h":279173201181,"f":83886088},"n":"AuthenticationTagBytes","d":326941,"h":270583266589,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":287763135773,"f":50331649},"n":"Ciphertext","d":326941,"h":283468168477,"f":2097153},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":300648037661,"f":50331656},"s":{"r":0,"d":0,"h":304943004957,"f":83886088},"n":"CipherTextBytes","d":326941,"h":296353070365,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":317827906845,"f":50331656},"s":{"r":0,"d":0,"h":322122874141,"f":83886088},"n":"Dot1","d":326941,"h":313532939549,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":335007776029,"f":50331656},"s":{"r":0,"d":0,"h":339302743325,"f":83886088},"n":"Dot2","d":326941,"h":330712808733,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":352187645213,"f":50331656},"s":{"r":0,"d":0,"h":356482612509,"f":83886088},"n":"Dot3","d":326941,"h":347892677917,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":369367514397,"f":50331656},"s":{"r":0,"d":0,"h":373662481693,"f":83886088},"n":"Dot4","d":326941,"h":365072547101,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":382252416285,"f":50331649},"n":"EncodedHeader","d":326941,"h":377957448989,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":390842350877,"f":50331649},"n":"EncryptedKey","d":326941,"h":386547383581,"f":2097153},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":403727252765,"f":50331656},"s":{"r":0,"d":0,"h":408022220061,"f":83886088},"n":"EncryptedKeyBytes","d":326941,"h":399432285469,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":416612154653,"f":50331649},"n":"EncodedPayload","d":326941,"h":412317187357,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":425202089245,"f":50331649},"n":"EncodedSignature","d":326941,"h":420907121949,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":433792023837,"f":50331649},"n":"EncodedToken","d":326941,"h":429497056541,"f":2097153},{"p":195869,"g":{"r":0,"d":0,"h":446676925725,"f":50331656},"s":{"r":0,"d":0,"h":450971893021,"f":83886088},"n":"Header","d":326941,"h":442381958429,"f":2097160},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":463856794909,"f":50331656},"s":{"r":0,"d":0,"h":468151762205,"f":83886088},"n":"HeaderAsciiBytes","d":326941,"h":459561827613,"f":2097160},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":481036664093,"f":50331656},"s":{"r":0,"d":0,"h":485331631389,"f":83886088},"n":"InitializationVectorBytes","d":326941,"h":476741696797,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":493921565981,"f":50331649},"n":"InitializationVector","d":326941,"h":489626598685,"f":2097153},{"p":326941,"g":{"r":0,"d":0,"h":506806467869,"f":50331649},"s":{"r":0,"d":0,"h":511101435165,"f":83886088},"n":"InnerToken","d":326941,"h":502511500573,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":519691369757,"f":50331649},"n":"IsEncrypted","d":326941,"h":515396402461,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":532576271645,"f":50331649},"s":{"r":0,"d":0,"h":536871238941,"f":83886088},"n":"IsSigned","d":326941,"h":528281304349,"f":2097153},{"p":195869,"g":{"r":0,"d":0,"h":549756140829,"f":50331656},"s":{"r":0,"d":0,"h":554051108125,"f":83886088},"n":"Payload","d":326941,"h":545461173533,"f":2097160},{"p":13671473,"g":{"r":0,"d":0,"h":566936010013,"f":50364417},"n":"SecurityKey","d":326941,"h":562641042717,"f":2129921},{"p":13671473,"g":{"r":0,"d":0,"h":579820911901,"f":50364417},"s":{"r":0,"d":0,"h":584115879197,"f":83918849},"n":"SigningKey","d":326941,"h":575525944605,"f":2129921},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":597000781085,"f":50331656},"s":{"r":0,"d":0,"h":601295748381,"f":83886088},"n":"MessageBytes","d":326941,"h":592705813789,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":614180650269,"f":50331656},"s":{"r":0,"d":0,"h":618475617565,"f":83886088},"n":"NumberOfDots","d":326941,"h":609885682973,"f":2097160},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":644245421341,"f":50331777},"n":"Claims","d":326941,"h":639950454045,"f":2097281},{"p":$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":657130323229,"f":50331656},"n":"PayloadClaimNames","d":326941,"h":652835355933,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":695785028893,"f":50331649},"n":"Alg","d":326941,"h":691490061597,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":704374963485,"f":50331649},"n":"Cty","d":326941,"h":700079996189,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":712964898077,"f":50331649},"n":"Enc","d":326941,"h":708669930781,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":721554832669,"f":50331649},"n":"Kid","d":326941,"h":717259865373,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":730144767261,"f":50331649},"s":{"r":0,"d":0,"h":734439734557,"f":83886088},"n":"Typ","d":326941,"h":725849799965,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":743029669149,"f":50331649},"n":"X5t","d":326941,"h":738734701853,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":751619603741,"f":50331649},"n":"Zip","d":326941,"h":747324636445,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":760209538333,"f":50331649},"n":"Actor","d":326941,"h":755914571037,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":768799472925,"f":50331649},"n":"Audiences","d":326941,"h":764504505629,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":777389407517,"f":50331649},"n":"Azp","d":326941,"h":773094440221,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":785979342109,"f":50331649},"n":"IssuedAt","d":326941,"h":781684374813,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":794569276701,"f":50364417},"n":"Issuer","d":326941,"h":790274309405,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":803159211293,"f":50364417},"n":"Id","d":326941,"h":798864243997,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":811749145885,"f":50331649},"n":"Subject","d":326941,"h":807454178589,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":820339080477,"f":50364417},"n":"ValidFrom","d":326941,"h":816044113181,"f":2129921},{"p":$.$typeNullable($.$$.System.DateTime).$h,"g":{"r":0,"d":0,"h":828929015069,"f":50331656},"n":"ValidFromNullable","d":326941,"h":824634047773,"f":2097160},{"p":34275329,"g":{"r":0,"d":0,"h":837518949661,"f":50364417},"n":"ValidTo","d":326941,"h":833223982365,"f":2129921},{"p":$.$typeNullable($.$$.System.DateTime).$h,"g":{"r":0,"d":0,"h":846108884253,"f":50331656},"n":"ValidToNullable","d":326941,"h":841813916957,"f":2097160}],"m":[{"r":195869,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h}],"n":"CreateHeaderClaimSet","o":"@$1","d":326941,"h":4295294237,"f":16777224},{"r":195869,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"length","p":655361}],"n":"CreateHeaderClaimSet","d":326941,"h":8590261533,"f":16777224},{"r":195869,"p":[{"n":"byteSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"CreateHeaderClaimSet","o":"@$2","d":326941,"h":12885228829,"f":16777224},{"r":65537,"p":[{"n":"reader","p":18985923,"f":4},{"n":"claims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"ReadHeaderValue","d":326941,"h":17180196125,"f":16777344},{"r":195869,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"length","p":655361}],"n":"CreatePayloadClaimSet","d":326941,"h":25770130717,"f":16777224},{"r":195869,"p":[{"n":"byteSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"CreatePayloadClaimSet","o":"@$1","d":326941,"h":30065098013,"f":16777224},{"r":65537,"p":[{"n":"reader","p":18985923,"f":4},{"n":"claims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"ReadPayloadValue","d":326941,"h":34360065309,"f":16777344},{"r":65537,"p":[{"n":"encodedTokenMemory","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":"ReadToken","d":326941,"h":622770584861,"f":16777224},{"r":195869,"p":[{"n":"strSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"startIndex","p":655361},{"n":"length","p":655361},{"n":"createHeaderClaimSet","p":262145}],"n":"CreateClaimSet","d":326941,"h":627065552157,"f":16777224},{"r":1310721,"n":"ToString","d":326941,"h":631360519453,"f":16809985},{"r":1310721,"n":"UnsafeToString","d":326941,"h":635655486749,"f":16809985},{"r":164318,"p":[{"n":"key","p":1310721}],"n":"GetClaim","d":326941,"h":648540388637,"f":16777217},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":164318,"f":2}],"n":"TryGetClaim","d":326941,"h":661425290525,"f":16777217},{"r":262145,"p":[{"n":"claimName","p":1310721}],"n":"HasPayloadClaim","d":326941,"h":665720257821,"f":16777224},{"r":(T) => T.$h,"p":[{"n":"key","p":1310721}],"g":["T"],"n":"GetHeaderValue","d":326941,"h":670015225117,"f":16908289},{"r":(T) => T.$h,"p":[{"n":"key","p":1310721}],"g":["T"],"n":"GetPayloadValue","d":326941,"h":674310192413,"f":16908289},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":(T) => T.$h,"f":2}],"g":["T"],"n":"TryGetValue","d":326941,"h":678605159709,"f":16908289},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":(T) => T.$h,"f":2}],"g":["T"],"n":"TryGetHeaderValue","d":326941,"h":682900127005,"f":16908289},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":(T) => T.$h,"f":2}],"g":["T"],"n":"TryGetPayloadValue","d":326941,"h":687195094301,"f":16908289}],"l":[{"t":655361,"n":"AverageJsonClaimLengthInBytes","d":326941,"h":21475163421,"f":4194344},{"t":1310721,"n":"ClassName","d":326941,"h":38655032605,"f":4194344},{"t":1310721,"n":"_act","d":326941,"h":42949999901,"f":4194306},{"t":1310721,"n":"_authenticationTag","d":326941,"h":47244967197,"f":4194306},{"t":1310721,"n":"_ciphertext","d":326941,"h":51539934493,"f":4194306},{"t":1310721,"n":"_encodedHeader","d":326941,"h":55834901789,"f":4194306},{"t":1310721,"n":"_encodedPayload","d":326941,"h":60129869085,"f":4194306},{"t":1310721,"n":"_encodedSignature","d":326941,"h":64424836381,"f":4194306},{"t":1310721,"n":"_encodedToken","d":326941,"h":68719803677,"f":4194306},{"t":1310721,"n":"_encryptedKey","d":326941,"h":73014770973,"f":4194306},{"t":1310721,"n":"_initializationVector","d":326941,"h":77309738269,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h,"n":"_audiences","d":326941,"h":81604705565,"f":4194306},{"t":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,"n":"_encodedTokenMemory","d":326941,"h":85899672861,"f":4194306},{"t":1310721,"n":"_alg","d":326941,"h":90194640157,"f":4194312},{"t":1310721,"n":"_cty","d":326941,"h":94489607453,"f":4194312},{"t":1310721,"n":"_enc","d":326941,"h":98784574749,"f":4194312},{"t":1310721,"n":"_kid","d":326941,"h":103079542045,"f":4194312},{"t":1310721,"n":"_typ","d":326941,"h":107374509341,"f":4194312},{"t":1310721,"n":"_x5t","d":326941,"h":111669476637,"f":4194312},{"t":1310721,"n":"_zip","d":326941,"h":115964443933,"f":4194312},{"t":1310721,"n":"_azp","d":326941,"h":120259411229,"f":4194312},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_exp","d":326941,"h":124554378525,"f":4194312},{"t":$.$typeNullable($.$$.System.DateTime).$h,"n":"_expDateTime","d":326941,"h":128849345821,"f":4194312},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_iat","d":326941,"h":133144313117,"f":4194312},{"t":$.$typeNullable($.$$.System.DateTime).$h,"n":"_iatDateTime","d":326941,"h":137439280413,"f":4194312},{"t":1310721,"n":"_id","d":326941,"h":141734247709,"f":4194312},{"t":1310721,"n":"_iss","d":326941,"h":146029215005,"f":4194312},{"t":1310721,"n":"_jti","d":326941,"h":150324182301,"f":4194312},{"t":1310721,"n":"_sub","d":326941,"h":154619149597,"f":4194312},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_nbf","d":326941,"h":158914116893,"f":4194312},{"t":$.$typeNullable($.$$.System.DateTime).$h,"n":"_nbfDateTime","d":326941,"h":163209084189,"f":4194312},{"t":$.$typeNullable($.$$.System.DateTime).$h,"n":"_validFrom","d":326941,"h":167504051485,"f":4194312},{"t":$.$typeNullable($.$$.System.DateTime).$h,"n":"_validTo","d":326941,"h":171799018781,"f":4194312}],"c":[{"p":[{"n":"jwtEncodedString","p":1310721}],"n":".ctor","o":"$ctor$7","d":326941,"h":176093986077,"f":16777217},{"p":[{"n":"jwtEncodedString","p":1310721},{"n":"tryReadJwtClaim","p":17013809}],"n":".ctor","o":"$ctor$6","d":326941,"h":180388953373,"f":16777217},{"p":[{"n":"encodedTokenMemory","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$3","d":326941,"h":184683920669,"f":16777217},{"p":[{"n":"encodedTokenMemory","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h},{"n":"tryReadJwtClaim","p":17013809}],"n":".ctor","o":"$ctor$2","d":326941,"h":188978887965,"f":16777217},{"p":[{"n":"header","p":1310721},{"n":"payload","p":1310721}],"n":".ctor","o":"$ctor$5","d":326941,"h":193273855261,"f":16777217},{"p":[{"n":"header","p":1310721},{"n":"payload","p":1310721},{"n":"tryReadJwtClaim","p":17013809}],"n":".ctor","o":"$ctor$4","d":326941,"h":197568822557,"f":16777217},{"p":[{"n":"jsonWebToken","p":326941},{"n":"encodedHeader","p":1310721}],"n":".ctor","o":"$ctor$8","d":326941,"h":201863789853,"f":16777224}],"i":[241048],"h":326941}; }
            static get $b() { return $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact ]; }
            static get $fullName() { return `Microsoft.IdentityModel.JsonWebTokens.JsonWebToken`; }
        });
        
        $asm.$cls("$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0", ($self) => class CreateJwsRegex_0 extends $.$str.System.Text.RegularExpressions.Regex
        {
            /*CreateJwsRegex_0*/ static Instance = null;
            $ctor$8()
            {
                super.$ctor$1();
                {
                    super.pattern = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                    super.roptions = 512/*RegexOptions.CultureInvariant*/;
                    super.internalMatchTimeout = $.$$.System.TimeSpan.FromMilliseconds$2(100n);
                    super.factory = new $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory().$ctor$2();
                    super.capsize = 1;
                }
                return this;
            }
            static $_RunnerFactory;
            static get RunnerFactory()
            {
                let $cls = $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0;
                return $cls.$_RunnerFactory ??= $asm.$ncls("$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory", ($self) => class RunnerFactory extends $.$str.System.Text.RegularExpressions.RegexRunnerFactory
                {
                    /*RegexRunner */ CreateInstance()
                    {
                        return new $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory.Runner().$ctor$2();
                    }
                    static $_Runner;
                    static get Runner()
                    {
                        let $cls = $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory;
                        return $cls.$_Runner ??= $asm.$ncls("$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory.Runner", ($self) => class Runner extends $.$str.System.Text.RegularExpressions.RegexRunner
                        {
                            /*void */ Scan(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                if (this.TryFindNextPossibleStartingPosition(inputSpan) && !this.TryMatchAtCurrentPosition(inputSpan))
                                {
                                    super.runtextpos = inputSpan.Length;
                                }
                            }
                            /*bool */ TryFindNextPossibleStartingPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                /*int*/ let pos = super.runtextpos;
                                if (pos <= ((inputSpan.Length - 4) | 0))
                                {
                                    if (pos === 0)
                                    {
                                        return true;
                                    }
                                }
                                super.runtextpos = inputSpan.Length;
                                return false;
                            }
                            /*bool */ TryMatchAtCurrentPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                /*int*/ let pos = super.runtextpos;
                                /*int*/ let matchStart = pos;
                                /*ReadOnlySpan<char>*/ let slice = inputSpan.Slice$1(pos);
                                if (pos !== 0)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice, $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration < 0)
                                    {
                                        iteration = slice.Length;
                                    }
                                    if (iteration === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration);
                                    pos += iteration;
                                }
                                if (slice.IsEmpty || slice.get_Item(0).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration1 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(1), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration1 < 0)
                                    {
                                        iteration1 = ((slice.Length - 1) | 0);
                                    }
                                    if (iteration1 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration1);
                                    pos += iteration1;
                                }
                                if ((slice.Length >>> 0) < 2 || slice.get_Item(1).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration2 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(2), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration2 < 0)
                                    {
                                        iteration2 = ((slice.Length - 2) | 0);
                                    }
                                    slice = slice.Slice$1(iteration2);
                                    pos += iteration2;
                                }
                                if (3 < slice.Length || (2 < slice.Length && slice.get_Item(2).$v !== /*\n*/ 10))
                                {
                                    return false;
                                }
                                pos += 2;
                                super.runtextpos = pos;
                                super.Capture(0, matchStart, pos);
                                return true;
                            }
                            //default reference type constructor overload
                            $ctor$2()
                            {
                                super.$ctor$1();
                                return this;
                            }
                            static $h = 1375517;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":4040844,"m":[{"r":65537,"p":[{"n":"inputSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Scan","d":1375517,"h":4296342813,"f":16809988},{"r":262145,"p":[{"n":"inputSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"TryFindNextPossibleStartingPosition","d":1375517,"h":8591310109,"f":16777218},{"r":262145,"p":[{"n":"inputSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"TryMatchAtCurrentPosition","d":1375517,"h":12886277405,"f":16777218}],"c":[{"n":".ctor","o":"$ctor$2","d":1375517,"h":17181244701,"f":16777217}],"d":1309981,"h":1375517}; }
                            static get $b() { return $.$str.System.Text.RegularExpressions.RegexRunner; }
                            static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory.Runner`; }
                        }, $cls, ($v) => $cls.$_Runner = $v);
                    }
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    static $h = 1309981;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":4106380,"m":[{"r":4040844,"n":"CreateInstance","d":1309981,"h":4296277277,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":1309981,"h":12886211869,"f":16777217}],"j":[1375517],"d":1244445,"h":1309981}; }
                    static get $b() { return $.$str.System.Text.RegularExpressions.RegexRunnerFactory; }
                    static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJwsRegex_0.RunnerFactory`; }
                }, $cls, ($v) => $cls.$_RunnerFactory = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mij.System.Text.RegularExpressions.Generated.CreateJwsRegex_0().$ctor$8();
                }
            }
            static $h = 1244445;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1943692,"l":[{"t":1244445,"n":"Instance","d":1244445,"h":4296211741,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$8","d":1244445,"h":8591179037,"f":16777218}],"i":[113246209],"j":[1309981],"h":1244445,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"System.Text.RegularExpressions.Generator","t":1310721},{"v":"42.42.42.42","t":1310721}]},{"t":95354881,"c":4390322177}]}; }
            static get $b() { return $.$str.System.Text.RegularExpressions.Regex; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJwsRegex_0`; }
        });
        
        $asm.$cls("$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1", ($self) => class CreateJweRegex_1 extends $.$str.System.Text.RegularExpressions.Regex
        {
            /*CreateJweRegex_1*/ static Instance = null;
            $ctor$8()
            {
                super.$ctor$1();
                {
                    super.pattern = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                    super.roptions = 512/*RegexOptions.CultureInvariant*/;
                    super.internalMatchTimeout = $.$$.System.TimeSpan.FromMilliseconds$2(100n);
                    super.factory = new $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory().$ctor$2();
                    super.capsize = 1;
                }
                return this;
            }
            static $_RunnerFactory;
            static get RunnerFactory()
            {
                let $cls = $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1;
                return $cls.$_RunnerFactory ??= $asm.$ncls("$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory", ($self) => class RunnerFactory extends $.$str.System.Text.RegularExpressions.RegexRunnerFactory
                {
                    /*RegexRunner */ CreateInstance()
                    {
                        return new $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory.Runner().$ctor$2();
                    }
                    static $_Runner;
                    static get Runner()
                    {
                        let $cls = $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory;
                        return $cls.$_Runner ??= $asm.$ncls("$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory.Runner", ($self) => class Runner extends $.$str.System.Text.RegularExpressions.RegexRunner
                        {
                            /*void */ Scan(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                if (this.TryFindNextPossibleStartingPosition(inputSpan) && !this.TryMatchAtCurrentPosition(inputSpan))
                                {
                                    super.runtextpos = inputSpan.Length;
                                }
                            }
                            /*bool */ TryFindNextPossibleStartingPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                /*int*/ let pos = super.runtextpos;
                                if (pos <= ((inputSpan.Length - 8) | 0))
                                {
                                    if (pos === 0)
                                    {
                                        return true;
                                    }
                                }
                                super.runtextpos = inputSpan.Length;
                                return false;
                            }
                            /*bool */ TryMatchAtCurrentPosition(/*ReadOnlySpan<char>*/ inputSpan)
                            {
                                /*int*/ let pos = super.runtextpos;
                                /*int*/ let matchStart = pos;
                                /*ReadOnlySpan<char>*/ let slice = inputSpan.Slice$1(pos);
                                if (pos !== 0)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice, $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration < 0)
                                    {
                                        iteration = slice.Length;
                                    }
                                    if (iteration === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration);
                                    pos += iteration;
                                }
                                if (slice.IsEmpty || slice.get_Item(0).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration1 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(1), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration1 < 0)
                                    {
                                        iteration1 = ((slice.Length - 1) | 0);
                                    }
                                    slice = slice.Slice$1(iteration1);
                                    pos += iteration1;
                                }
                                if ((slice.Length >>> 0) < 2 || slice.get_Item(1).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration2 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(2), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration2 < 0)
                                    {
                                        iteration2 = ((slice.Length - 2) | 0);
                                    }
                                    if (iteration2 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration2);
                                    pos += iteration2;
                                }
                                if ((slice.Length >>> 0) < 3 || slice.get_Item(2).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration3 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(3), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration3 < 0)
                                    {
                                        iteration3 = ((slice.Length - 3) | 0);
                                    }
                                    if (iteration3 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration3);
                                    pos += iteration3;
                                }
                                if ((slice.Length >>> 0) < 4 || slice.get_Item(3).$v !== /*.*/ 46)
                                {
                                    return false;
                                }
                                {
                                    /*int*/ let iteration4 = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, slice.Slice$1(4), $.$mij.System.Text.RegularExpressions.Generated.Utilities.s_asciiLettersAndDigitsAndDashUnderscore);
                                    if (iteration4 < 0)
                                    {
                                        iteration4 = ((slice.Length - 4) | 0);
                                    }
                                    if (iteration4 === 0)
                                    {
                                        return false;
                                    }
                                    slice = slice.Slice$1(iteration4);
                                    pos += iteration4;
                                }
                                if (5 < slice.Length || (4 < slice.Length && slice.get_Item(4).$v !== /*\n*/ 10))
                                {
                                    return false;
                                }
                                pos += 4;
                                super.runtextpos = pos;
                                super.Capture(0, matchStart, pos);
                                return true;
                            }
                            //default reference type constructor overload
                            $ctor$2()
                            {
                                super.$ctor$1();
                                return this;
                            }
                            static $h = 1178909;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":4040844,"m":[{"r":65537,"p":[{"n":"inputSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Scan","d":1178909,"h":4296146205,"f":16809988},{"r":262145,"p":[{"n":"inputSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"TryFindNextPossibleStartingPosition","d":1178909,"h":8591113501,"f":16777218},{"r":262145,"p":[{"n":"inputSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"TryMatchAtCurrentPosition","d":1178909,"h":12886080797,"f":16777218}],"c":[{"n":".ctor","o":"$ctor$2","d":1178909,"h":17181048093,"f":16777217}],"d":1113373,"h":1178909}; }
                            static get $b() { return $.$str.System.Text.RegularExpressions.RegexRunner; }
                            static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory.Runner`; }
                        }, $cls, ($v) => $cls.$_Runner = $v);
                    }
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    static $h = 1113373;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":4106380,"m":[{"r":4040844,"n":"CreateInstance","d":1113373,"h":4296080669,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":1113373,"h":12886015261,"f":16777217}],"j":[1178909],"d":1047837,"h":1113373}; }
                    static get $b() { return $.$str.System.Text.RegularExpressions.RegexRunnerFactory; }
                    static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJweRegex_1.RunnerFactory`; }
                }, $cls, ($v) => $cls.$_RunnerFactory = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mij.System.Text.RegularExpressions.Generated.CreateJweRegex_1().$ctor$8();
                }
            }
            static $h = 1047837;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1943692,"l":[{"t":1047837,"n":"Instance","d":1047837,"h":4296015133,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$8","d":1047837,"h":8590982429,"f":16777218}],"i":[113246209],"j":[1113373],"h":1047837,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"System.Text.RegularExpressions.Generator","t":1310721},{"v":"42.42.42.42","t":1310721}]},{"t":95354881,"c":4390322177}]}; }
            static get $b() { return $.$str.System.Text.RegularExpressions.Regex; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Text.RegularExpressions.Generated.CreateJweRegex_1`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Logging", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.IdentityModel.Tokens"))