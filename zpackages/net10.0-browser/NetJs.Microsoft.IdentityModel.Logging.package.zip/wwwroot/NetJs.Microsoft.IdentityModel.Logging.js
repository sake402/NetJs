
//--TRIMMABLE-BOUNDARY-START(118)
(function ($global, $, $$, $mia, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.Logging", 
    {
  "h": 118,
  "f": "Microsoft.IdentityModel.Logging",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tokens, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "Serviceable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 139919361,
      "c": 4434886657,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Protocols, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Logging.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsAotCompatible",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "Microsoft Corporation.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 4401463297,
      "a": [
        {
          "v": "\u00A9 Microsoft Corporation. All rights reserved.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "Includes Event Source based logging support.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "9.0.0.26247",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "Microsoft IdentityModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.IdentityModel.Logging",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196726)
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact", ($self) => class ISafeLogSecurityArtifact
        {
            static $h = 196726;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295164022),
    {
      "r": 1310721,
      "n": "UnsafeToString",
      "o": "Microsoft$IdentityModel$Logging$ISafeLogSecurityArtifact$UnsafeToString",
      "d": 196726,
      "h": 4295164022,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295164022)
  ],
  "h": 196726
}; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196726)
        
        
        //--TRIMMABLE-BOUNDARY-START(262262)
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.LoggerContext", ($self) => class LoggerContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295229558)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229558);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229558)
            
            //--TRIMMABLE-BOUNDARY-START(8590196854)
            $ctor$2(/*Guid*/ activityId)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196854);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ActivityId = activityId;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196854)
            
            //--TRIMMABLE-BOUNDARY-START(34360000630)
            /*Guid*/ ActivityId;
            //--TRIMMABLE-BOUNDARY-END(34360000630)
            
            //--TRIMMABLE-BOUNDARY-START(38654967926)
            /*bool*/ CaptureLogs = false;
            //--TRIMMABLE-BOUNDARY-END(38654967926)
            
            //--TRIMMABLE-BOUNDARY-START(42949935222)
            /*string*/ DebugId = null;
            //--TRIMMABLE-BOUNDARY-END(42949935222)
            
            //--TRIMMABLE-BOUNDARY-START(90194575478)
            /*ICollection<string>*/ Logs = null;
            //--TRIMMABLE-BOUNDARY-END(90194575478)
            
            //--TRIMMABLE-BOUNDARY-START(94489542774)
            /*IDictionary<string, object>*/ PropertyBag = null;
            //--TRIMMABLE-BOUNDARY-END(94489542774)
            
            //default member initializer
            constructor()
            {
                super();
                this.ActivityId = $.$$.System.Guid.Empty;
                this.DebugId = $.$$.System.String.Empty;
                this.Logs = new ($.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String))().$ctor$1();
            }
            static $h = 262262;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360000630),
    {
      "p": 88866817,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539869814,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079477366,
        "f": 83886081
      },
      "n": "ActivityId",
      "d": 262262,
      "h": 34360000630,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000630),
//--TRIMMABLE-BOUNDARY-START(38654967926),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129804406,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669411958,
        "f": 83886081
      },
      "n": "CaptureLogs",
      "d": 262262,
      "h": 38654967926,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654967926),
//--TRIMMABLE-BOUNDARY-START(42949935222),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719738998,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259346550,
        "f": 83886209
      },
      "n": "DebugId",
      "d": 262262,
      "h": 42949935222,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(42949935222),
//--TRIMMABLE-BOUNDARY-START(90194575478),
    {
      "p": $.$$.System.Collections.Generic.ICollection$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309673590,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849281142,
        "f": 83886082
      },
      "n": "Logs",
      "d": 262262,
      "h": 90194575478,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194575478),
//--TRIMMABLE-BOUNDARY-START(94489542774),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899608182,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439215734,
        "f": 83886081
      },
      "n": "PropertyBag",
      "d": 262262,
      "h": 94489542774,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489542774)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229558),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262262,
      "h": 4295229558,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229558),
//--TRIMMABLE-BOUNDARY-START(8590196854),
    {
      "p": [
        {
          "n": "activityId",
          "p": 88866817
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262262,
      "h": 8590196854,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196854)
  ],
  "h": 262262
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.LoggerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262262)
        
        
        //--TRIMMABLE-BOUNDARY-START(393334)
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.LogMessages", ($self) => class LogMessages
        {
            //--TRIMMABLE-BOUNDARY-START(4295360630)
            /*string*/ static MIML10000 = null;
            //--TRIMMABLE-BOUNDARY-END(4295360630)
            
            //--TRIMMABLE-BOUNDARY-START(8590327926)
            /*string*/ static MIML10001 = null;
            //--TRIMMABLE-BOUNDARY-END(8590327926)
            
            //--TRIMMABLE-BOUNDARY-START(12885295222)
            /*string*/ static MIML10002 = null;
            //--TRIMMABLE-BOUNDARY-END(12885295222)
            
            //--TRIMMABLE-BOUNDARY-START(17180262518)
            /*string*/ static MIML10003 = null;
            //--TRIMMABLE-BOUNDARY-END(17180262518)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295360630)
                    this.MIML10000 = "MIML10000: eventData.Payload is null or empty. Not logging any messages.";
                    //--TRIMMABLE-BOUNDARY-END(4295360630)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590327926)
                    this.MIML10001 = "MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception.";
                    //--TRIMMABLE-BOUNDARY-END(8590327926)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295222)
                    this.MIML10002 = "MIML10002: Unknown log level: {0}.";
                    //--TRIMMABLE-BOUNDARY-END(12885295222)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180262518)
                    this.MIML10003 = "MIML10003: Sku and version telemetry cannot be manipulated. They are added by default.";
                    //--TRIMMABLE-BOUNDARY-END(17180262518)
                    
                }
            }
            static $h = 393334;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360630),
    {
      "t": 1310721,
      "n": "MIML10000",
      "d": 393334,
      "h": 4295360630,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295360630),
//--TRIMMABLE-BOUNDARY-START(8590327926),
    {
      "t": 1310721,
      "n": "MIML10001",
      "d": 393334,
      "h": 8590327926,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590327926),
//--TRIMMABLE-BOUNDARY-START(12885295222),
    {
      "t": 1310721,
      "n": "MIML10002",
      "d": 393334,
      "h": 12885295222,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885295222),
//--TRIMMABLE-BOUNDARY-START(17180262518),
    {
      "t": 1310721,
      "n": "MIML10003",
      "d": 393334,
      "h": 17180262518,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180262518)
  ],
  "h": 393334
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.LogMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393334)
        
        
        //--TRIMMABLE-BOUNDARY-START(131190)
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil", ($self) => class IdentityModelTelemetryUtil
        {
            //--TRIMMABLE-BOUNDARY-START(51539738742)
            /*string*/ static skuTelemetry = null;
            //--TRIMMABLE-BOUNDARY-END(51539738742)
            
            //--TRIMMABLE-BOUNDARY-START(64424640630)
            /*string*/ static versionTelemetry = null;
            //--TRIMMABLE-BOUNDARY-END(64424640630)
            
            //--TRIMMABLE-BOUNDARY-START(21474967670)
            /*List<string>*/ static defaultTelemetryValues = null;
            //--TRIMMABLE-BOUNDARY-END(21474967670)
            
            //--TRIMMABLE-BOUNDARY-START(55834706038)
            /*ConcurrentDictionary<string, string>*/ static telemetryData = null;
            //--TRIMMABLE-BOUNDARY-END(55834706038)
            
            //--TRIMMABLE-BOUNDARY-START(12885033078)
            static /*string */ get ClientSku()
            {
                return "ID_NET10_0";
            }
            //--TRIMMABLE-BOUNDARY-END(12885033078)
            
            //--TRIMMABLE-BOUNDARY-START(17180000374)
            static /*string */ get ClientVer()
            {
                return $.$$.System.Version.ToString.call($.$$.System.Reflection.IntrospectionExtensions.GetTypeInfo($.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.$type).Assembly.GetName().Version);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000374)
            
            //--TRIMMABLE-BOUNDARY-START(8590065782)
            static /*bool */ AddTelemetryData(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                    return false;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.defaultTelemetryValues.Contains(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("MIML10003: Sku and version telemetry cannot be manipulated. They are added by default."/*LogMessages.MIML10003*/));
                    return false;
                }
                $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.telemetryData.set_Item(key, value);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065782)
            
            //--TRIMMABLE-BOUNDARY-START(42949804150)
            static /*bool */ RemoveTelemetryData(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.defaultTelemetryValues.Contains(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("MIML10003: Sku and version telemetry cannot be manipulated. They are added by default."/*LogMessages.MIML10003*/));
                    return false;
                }
                return $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.telemetryData.TryRemove$1(key, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(42949804150)
            
            //--TRIMMABLE-BOUNDARY-START(47244771446)
            static /*void */ SetTelemetryData(/*HttpRequestMessage*/ request, /*IDictionary<string, string>*/ additionalHeaders)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (request === null)
                {
                    return;
                }
                var $en2 = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.telemetryData.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var parameter = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        request.Headers.Remove(parameter.Key);
                        request.Headers.Add$1(parameter.Key, parameter.Value);
                    }
                }
                if (additionalHeaders !== null)
                {
                    var $en3 = additionalHeaders.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var header = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            request.Headers.Add$1(header.Key, header.Value);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244771446)
            
            //--TRIMMABLE-BOUNDARY-START(60129673334)
            static /*bool */ UpdateDefaultTelemetryData(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                    return false;
                }
                $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.telemetryData.set_Item(key, value);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673334)
            
            //--TRIMMABLE-BOUNDARY-START(4295098486)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51539738742)
                    this.skuTelemetry = "x-client-SKU";
                    //--TRIMMABLE-BOUNDARY-END(51539738742)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424640630)
                    this.versionTelemetry = "x-client-Ver";
                    //--TRIMMABLE-BOUNDARY-END(64424640630)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967670)
                    this.defaultTelemetryValues = (() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("x-client-SKU"/*skuTelemetry*/);
                        $i1.Add("x-client-Ver"/*versionTelemetry*/);
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(21474967670)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834706038)
                    this.telemetryData = (() =>
                    {
                        //new $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.String)()
                        const $t1 = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.set_Item("x-client-SKU"/*skuTelemetry*/, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.ClientSku);
                        $i1.set_Item("x-client-Ver"/*versionTelemetry*/, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.ClientVer);
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(55834706038)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098486)
            
            static $h = 131190;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885033078),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902262,
        "f": 50331681
      },
      "n": "ClientSku",
      "d": 131190,
      "h": 12885033078,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885033078),
//--TRIMMABLE-BOUNDARY-START(17180000374),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836854,
        "f": 50331681
      },
      "n": "ClientVer",
      "d": 131190,
      "h": 17180000374,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180000374)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590065782),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddTelemetryData",
      "d": 131190,
      "h": 8590065782,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065782),
//--TRIMMABLE-BOUNDARY-START(42949804150),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "RemoveTelemetryData",
      "d": 131190,
      "h": 42949804150,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949804150),
//--TRIMMABLE-BOUNDARY-START(47244771446),
    {
      "r": 65537,
      "p": [
        {
          "n": "request",
          "p": 7602229
        },
        {
          "n": "additionalHeaders",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        }
      ],
      "n": "SetTelemetryData",
      "d": 131190,
      "h": 47244771446,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47244771446),
//--TRIMMABLE-BOUNDARY-START(60129673334),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "UpdateDefaultTelemetryData",
      "d": 131190,
      "h": 60129673334,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(60129673334)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539738742),
    {
      "t": 1310721,
      "n": "skuTelemetry",
      "d": 131190,
      "h": 51539738742,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539738742),
//--TRIMMABLE-BOUNDARY-START(64424640630),
    {
      "t": 1310721,
      "n": "versionTelemetry",
      "d": 131190,
      "h": 64424640630,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424640630),
//--TRIMMABLE-BOUNDARY-START(21474967670),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "n": "defaultTelemetryValues",
      "d": 131190,
      "h": 21474967670,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474967670),
//--TRIMMABLE-BOUNDARY-START(55834706038),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "telemetryData",
      "d": 131190,
      "h": 55834706038,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834706038)
  ],
  "h": 131190
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131190)
        
        
        //--TRIMMABLE-BOUNDARY-START(327798)
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.LogHelper", ($self) => class LogHelper extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(158914117750)
            /*IIdentityLogger*/ static Logger = null;
            //--TRIMMABLE-BOUNDARY-END(158914117750)
            
            //--TRIMMABLE-BOUNDARY-START(4295295094)
            /*bool*/ static _isHeaderWritten = false;
            //--TRIMMABLE-BOUNDARY-END(4295295094)
            
            //--TRIMMABLE-BOUNDARY-START(197568823414)
            /*SearchValues<char>*/ static s_charsToSanitize = null;
            //--TRIMMABLE-BOUNDARY-END(197568823414)
            
            //--TRIMMABLE-BOUNDARY-START(8590262390)
            /*string*/ static _piiOffLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590262390)
            
            //--TRIMMABLE-BOUNDARY-START(12885229686)
            /*string*/ static _piiOnLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(12885229686)
            
            //--TRIMMABLE-BOUNDARY-START(60129869942)
            static /*bool */ get HeaderWritten()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244968054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper._isHeaderWritten;
            }
            static /*bool */ set HeaderWritten(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748692598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mil.Microsoft.IdentityModel.Logging.LogHelper._isHeaderWritten = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60129869942)
            
            //--TRIMMABLE-BOUNDARY-START(68719804534)
            static /*bool */ IsEnabled(/*EventLogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719804534);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(level) || $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2($.$mil.Microsoft.IdentityModel.Logging.LogHelper.EventLogLevelToEventLevel(level), -1n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719804534)
            
            //--TRIMMABLE-BOUNDARY-START(107374510198)
            static /*ArgumentNullException */ LogArgumentNullException(/*string*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException$2($.$$.System.ArgumentNullException, 2/*EventLevel.Error*/, argument, "IDX10000: The parameter '{0}' cannot be a 'null' or an empty object. ", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ argument ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(107374510198)
            
            //--TRIMMABLE-BOUNDARY-START(111669477494)
            static /*T */ LogException$7(T, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, 2/*EventLevel.Error*/, null, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(111669477494)
            
            //--TRIMMABLE-BOUNDARY-START(73014771830)
            static /*T */ LogArgumentException$7(T, /*string*/ argumentName, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, null, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(73014771830)
            
            //--TRIMMABLE-BOUNDARY-START(115964444790)
            static /*T */ LogException$6(T, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, 2/*EventLevel.Error*/, null, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(115964444790)
            
            //--TRIMMABLE-BOUNDARY-START(77309739126)
            static /*T */ LogArgumentException$6(T, /*string*/ argumentName, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, null, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(77309739126)
            
            //--TRIMMABLE-BOUNDARY-START(120259412086)
            static /*T */ LogException$5(T, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, 2/*EventLevel.Error*/, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(120259412086)
            
            //--TRIMMABLE-BOUNDARY-START(81604706422)
            static /*T */ LogArgumentException$5(T, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(81604706422)
            
            //--TRIMMABLE-BOUNDARY-START(124554379382)
            static /*T */ LogException$4(T, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, 2/*EventLevel.Error*/, innerException, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(124554379382)
            
            //--TRIMMABLE-BOUNDARY-START(85899673718)
            static /*T */ LogArgumentException$4(T, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, innerException, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(85899673718)
            
            //--TRIMMABLE-BOUNDARY-START(128849346678)
            static /*T */ LogException$3(T, /*EventLevel*/ eventLevel, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849346678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, eventLevel, null, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849346678)
            
            //--TRIMMABLE-BOUNDARY-START(90194641014)
            static /*T */ LogArgumentException$3(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194641014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, eventLevel, argumentName, null, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(90194641014)
            
            //--TRIMMABLE-BOUNDARY-START(133144313974)
            static /*T */ LogException$2(T, /*EventLevel*/ eventLevel, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144313974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, eventLevel, null, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(133144313974)
            
            //--TRIMMABLE-BOUNDARY-START(94489608310)
            static /*T */ LogArgumentException$2(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, eventLevel, argumentName, null, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(94489608310)
            
            //--TRIMMABLE-BOUNDARY-START(137439281270)
            static /*T */ LogException$1(T, /*EventLevel*/ eventLevel, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439281270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, eventLevel, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(137439281270)
            
            //--TRIMMABLE-BOUNDARY-START(98784575606)
            static /*T */ LogArgumentException$1(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, eventLevel, argumentName, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(98784575606)
            
            //--TRIMMABLE-BOUNDARY-START(141734248566)
            static /*T */ LogException(T, /*EventLevel*/ eventLevel, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionImpl(T, eventLevel, null, innerException, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(141734248566)
            
            //--TRIMMABLE-BOUNDARY-START(103079542902)
            static /*T */ LogArgumentException(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionImpl(T, eventLevel, argumentName, innerException, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(103079542902)
            
            //--TRIMMABLE-BOUNDARY-START(150324183158)
            static /*Exception */ LogExceptionMessage$1(/*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage(2/*EventLevel.Error*/, exception);
            }
            //--TRIMMABLE-BOUNDARY-END(150324183158)
            
            //--TRIMMABLE-BOUNDARY-START(154619150454)
            static /*Exception */ LogExceptionMessage(/*EventLevel*/ eventLevel, /*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619150454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (exception === null)
                {
                    return null;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(eventLevel, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.Write$7(eventLevel, exception.InnerException, exception.Message);
                }
                /*EventLogLevel*/ let eventLogLevel = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.EventLevelToEventLogLevel(eventLevel);
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(eventLogLevel))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(eventLogLevel, exception.InnerException, exception.Message, null));
                }
                return exception;
            }
            //--TRIMMABLE-BOUNDARY-END(154619150454)
            
            //--TRIMMABLE-BOUNDARY-START(163209085046)
            static /*void */ LogInformation(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209085046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.WriteInformation(message, args);
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(4/*EventLogLevel.Informational*/, null, message, args));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209085046)
            
            //--TRIMMABLE-BOUNDARY-START(167504052342)
            static /*void */ LogVerbose(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.WriteVerbose(message, args);
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(5/*EventLogLevel.Verbose*/, null, message, args));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504052342)
            
            //--TRIMMABLE-BOUNDARY-START(171799019638)
            static /*void */ LogWarning(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.WriteWarning(message, args);
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(3/*EventLogLevel.Warning*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(3/*EventLogLevel.Warning*/, null, message, args));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799019638)
            
            //--TRIMMABLE-BOUNDARY-START(146029215862)
            static /*T */ LogExceptionImpl(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let message;
                if (args !== null)
                {
                    message = $.$$.System.String.Format$3($.$$.System.Globalization.CultureInfo.InvariantCulture, format, args);
                }
                else 
                {
                    message = format;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(eventLevel, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.Write$7(eventLevel, innerException, message);
                }
                /*EventLogLevel*/ let eventLogLevel = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.EventLevelToEventLogLevel(eventLevel);
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(eventLogLevel))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(eventLogLevel, innerException, message, null));
                }
                if (innerException !== null)
                {
                    if ($.$$.System.String.IsNullOrEmpty(argumentName))
                    {
                        return $.$cast($.$$.System.Activator.CreateInstance$6(T.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ message, innerException ], null, null)), T);
                    }
                    else 
                    {
                        return $.$cast($.$$.System.Activator.CreateInstance$6(T.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ argumentName, message, innerException ], null, null)), T);
                    }
                }
                else 
                {
                    if ($.$$.System.String.IsNullOrEmpty(argumentName))
                    {
                        return $.$cast($.$$.System.Activator.CreateInstance$6(T.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ message ], null, null)), T);
                    }
                    else 
                    {
                        return $.$cast($.$$.System.Activator.CreateInstance$6(T.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ argumentName, message ], null, null)), T);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029215862)
            
            //--TRIMMABLE-BOUNDARY-START(30065098870)
            static /*EventLogLevel */ EventLevelToEventLogLevel(/*EventLevel*/ eventLevel)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098870);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (eventLevel >>> 0) <= 5 ? $.$cast(eventLevel, $.$mia.Microsoft.IdentityModel.Abstractions.EventLogLevel) : 2/*EventLogLevel.Error*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065098870)
            
            //--TRIMMABLE-BOUNDARY-START(34360066166)
            static /*EventLevel */ EventLogLevelToEventLevel(/*EventLogLevel*/ eventLevel)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360066166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (eventLevel >>> 0) <= 5 ? $.$cast(eventLevel, $.$$.System.Diagnostics.Tracing.EventLevel) : 2/*EventLevel.Error*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360066166)
            
            //--TRIMMABLE-BOUNDARY-START(38655033462)
            static /*string */ FormatInvariant(/*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(format, null))
                {
                    return $.$$.System.String.Empty;
                }
                if (args === null)
                {
                    return format;
                }
                if (!$.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII)
                {
                    return $.$$.System.String.Format$4($.$$.System.Globalization.CultureInfo.InvariantCulture, format, $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1($.$sl.System.Linq.Enumerable.ToArray($.$$.System.String, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Object, $.$$.System.String, args, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mil.Microsoft.IdentityModel.Logging.LogHelper, $.$mil.Microsoft.IdentityModel.Logging.LogHelper.RemovePII)))));
                }
                else 
                {
                    return $.$$.System.String.Format$3($.$$.System.Globalization.CultureInfo.InvariantCulture, format, $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Object, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Object, $.$$.System.Object, args, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object))().$ctor($.$mil.Microsoft.IdentityModel.Logging.LogHelper, $.$mil.Microsoft.IdentityModel.Logging.LogHelper.SanitizeSecurityArtifact))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655033462)
            
            //--TRIMMABLE-BOUNDARY-START(206158758006)
            static /*object */ SanitizeSecurityArtifact(/*object*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158758006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (arg === null)
                {
                    return "null";
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.LogCompleteSecurityArtifact && $.$is(arg, $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact))
                {
                    return ($.$as(arg, $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact)).Microsoft$IdentityModel$Logging$ISafeLogSecurityArtifact$UnsafeToString();
                }
                else if ($.$is(arg, $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact))
                {
                    const $t1 = arg;
                    return $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.HiddenSecurityArtifactString, $.$ifnn($t1, ($t) => $.$$.System.Type.ToString.call($t)) ?? "Null");
                }
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Sanitize($.$$.System.Object.ToString.call(arg));
            }
            //--TRIMMABLE-BOUNDARY-END(206158758006)
            
            //--TRIMMABLE-BOUNDARY-START(193273856118)
            static /*string */ RemovePII(/*object*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273856118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let ex;
                if ($.$is(arg, $.$$.System.Exception, { set $v(v){ ex = v; } }) && $.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsCustomException(ex))
                {
                    return $.$$.System.Exception.ToString.call(ex);
                }
                if ($.$is(arg, $.$mil.Microsoft.IdentityModel.Logging.NonPII))
                {
                    return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Sanitize($.$$.System.Object.ToString.call(arg));
                }
                const $t1 = arg;
                return $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.HiddenPIIString, $.$ifnn($t1, ($t) => $.$$.System.Type.ToString.call($t)) ?? "Null");
            }
            //--TRIMMABLE-BOUNDARY-END(193273856118)
            
            //--TRIMMABLE-BOUNDARY-START(64424837238)
            static /*bool */ IsCustomException(/*Exception*/ ex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.StartsWith$2.call(ex.GetType$1().FullName, "Microsoft.IdentityModel.", 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(64424837238)
            
            //--TRIMMABLE-BOUNDARY-START(176093986934)
            static /*object */ MarkAsNonPII(/*object*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093986934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mil.Microsoft.IdentityModel.Logging.NonPII().$ctor$3(arg);
            }
            //--TRIMMABLE-BOUNDARY-END(176093986934)
            
            //--TRIMMABLE-BOUNDARY-START(180388954230)
            static /*object */ MarkAsSecurityArtifact$1(/*object*/ arg, /*Func<object, string>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388954230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact().$ctor$4(arg, callback);
            }
            //--TRIMMABLE-BOUNDARY-END(180388954230)
            
            //--TRIMMABLE-BOUNDARY-START(184683921526)
            static /*object */ MarkAsSecurityArtifact(/*object*/ arg, /*Func<object, string>*/ callback, /*Func<object, string>*/ callbackUnsafe)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683921526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact().$ctor$3(arg, callback, callbackUnsafe);
            }
            //--TRIMMABLE-BOUNDARY-END(184683921526)
            
            //--TRIMMABLE-BOUNDARY-START(188978888822)
            static /*object */ MarkAsUnsafeSecurityArtifact(/*object*/ arg, /*Func<object, string>*/ callbackUnsafe)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978888822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact().$ctor$3(arg, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact, $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact.UnknownSafeTokenCallback), callbackUnsafe);
            }
            //--TRIMMABLE-BOUNDARY-END(188978888822)
            
            //--TRIMMABLE-BOUNDARY-START(227633594486)
            static /*LogEntry */ WriteEntry(/*EventLogLevel*/ eventLogLevel, /*Exception*/ innerException, /*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633594486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(message))
                {
                    return null;
                }
                if (innerException !== null)
                {
                    if (!$.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII && !$.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsCustomException(innerException))
                    {
                        message = $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}. ", message, innerException.GetType$1());
                    }
                    else 
                    {
                        message = $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}. ", message, innerException.Message);
                    }
                }
                message = args === null ? message : $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args);
                /*LogEntry*/ let entry = new $.$mia.Microsoft.IdentityModel.Abstractions.LogEntry().$ctor$1();
                entry.EventLogLevel = eventLogLevel;
                if (!$.$mil.Microsoft.IdentityModel.Logging.LogHelper._isHeaderWritten)
                {
                    /*string*/ let headerMessage = $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.InvariantCulture, "Microsoft.IdentityModel Version: {0}. Date {1}. {2}", $.$$.System.Version.ToString.call($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.$type.Assembly.GetName().Version), $.$$.System.DateTime.UtcNow, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII ? $.$mil.Microsoft.IdentityModel.Logging.LogHelper._piiOnLogMessage : $.$mil.Microsoft.IdentityModel.Logging.LogHelper._piiOffLogMessage);
                    entry.Message = headerMessage + $.$$.System.Environment.NewLine + message;
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper._isHeaderWritten = true;
                }
                else 
                {
                    entry.Message = message;
                }
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(227633594486)
            
            //--TRIMMABLE-BOUNDARY-START(201863790710)
            static /*string */ Sanitize(/*string*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863790710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(input))
                {
                    return input;
                }
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(input), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.s_charsToSanitize);
                if (index < 0)
                {
                    return input;
                }
                /*var*/ let sanitized = new $.$$.System.Text.StringBuilder().$ctor$4(input.length);
                /*int*/ let lastIndex = 0;
                while(index >= 0)
                {
                    sanitized.Append$15($.$$.System.MemoryExtensions.AsSpan$1(input, lastIndex, ((index - lastIndex) | 0)));
                    /*char*/ let c = $.$$.System.String.get_Chars.call(input, index);
                    if (c === /*\r*/ 13)
                    {
                        sanitized.Append$19("\\r");
                    }
                    else if (c === /*\n*/ 10)
                    {
                        sanitized.Append$19("\\n");
                    }
                    else if (c === /*\t*/ 9)
                    {
                        sanitized.Append$19("\\t");
                    }
                    else 
                    {
                        sanitized.Append$26((() =>
                        {
                            var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                            $handler.AppendLiteral("\\u");
                            $handler.AppendFormatted($.$box($.$cast(c, $.$$.System.Int32), $.$$.System.Int32), null, "X4");
                            return $handler.ToStringAndClear                    ();
                        })());
                    }
                    lastIndex = ((index + 1) | 0);
                    if (lastIndex < input.length)
                    {
                        index = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$2(input, lastIndex), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.s_charsToSanitize);
                    }
                    else 
                    {
                        index = -1;
                    }
                    if (index >= 0)
                    {
                        index += lastIndex;
                    }
                }
                if (lastIndex < input.length)
                {
                    sanitized.Append$15($.$$.System.MemoryExtensions.AsSpan$2(input, lastIndex));
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sanitized);
            }
            //--TRIMMABLE-BOUNDARY-END(201863790710)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(17180196982)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Logger = $.$mia.Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger.Instance;
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568823414)
                    this.s_charsToSanitize = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*\u0000*/ 0, /*\u0001*/ 1, /*\u0002*/ 2, /*\u0003*/ 3, /*\u0004*/ 4, /*\u0005*/ 5, /*\u0006*/ 6, /*\u0007*/ 7, /*\u0008*/ 8, /*\t*/ 9, /*\n*/ 10, /*\u000B*/ 11, /*\u000C*/ 12, /*\r*/ 13, /*\u000E*/ 14, /*\u000F*/ 15, /*\u0010*/ 16, /*\u0011*/ 17, /*\u0012*/ 18, /*\u0013*/ 19, /*\u0014*/ 20, /*\u0015*/ 21, /*\u0016*/ 22, /*\u0017*/ 23, /*\u0018*/ 24, /*\u0019*/ 25, /*\u001A*/ 26, /*\u001B*/ 27, /*\u001C*/ 28, /*\u001D*/ 29, /*\u001E*/ 30, /*\u001F*/ 31, /*\u007F*/ 127, /*\u0080*/ 128, /*\u0081*/ 129, /*\u0082*/ 130, /*\u0083*/ 131, /*\u0084*/ 132, /*\u0085*/ 133, /*\u0086*/ 134, /*\u0087*/ 135, /*\u0088*/ 136, /*\u0089*/ 137, /*\u008A*/ 138, /*\u008B*/ 139, /*\u008C*/ 140, /*\u008D*/ 141, /*\u008E*/ 142, /*\u008F*/ 143, /*\u0090*/ 144, /*\u0091*/ 145, /*\u0092*/ 146, /*\u0093*/ 147, /*\u0094*/ 148, /*\u0095*/ 149, /*\u0096*/ 150, /*\u0097*/ 151, /*\u0098*/ 152, /*\u0099*/ 153, /*\u009A*/ 154, /*\u009B*/ 155, /*\u009C*/ 156, /*\u009D*/ 157, /*\u009E*/ 158, /*\u009F*/ 159, /*\u00AD*/ 173, /*\u0600*/ 1536, /*\u0601*/ 1537, /*\u0602*/ 1538, /*\u0603*/ 1539, /*\u0604*/ 1540, /*\u0605*/ 1541, /*\u061C*/ 1564, /*\u06DD*/ 1757, /*\u070F*/ 1807, /*\u0890*/ 2192, /*\u0891*/ 2193, /*\u08E2*/ 2274, /*\u180E*/ 6158, /*\u200B*/ 8203, /*\u200C*/ 8204, /*\u200D*/ 8205, /*\u200E*/ 8206, /*\u200F*/ 8207, /*\u202A*/ 8234, /*\u202B*/ 8235, /*\u202C*/ 8236, /*\u202D*/ 8237, /*\u202E*/ 8238, /*\u2060*/ 8288, /*\u2061*/ 8289, /*\u2062*/ 8290, /*\u2063*/ 8291, /*\u2064*/ 8292, /*\u2066*/ 8294, /*\u2067*/ 8295, /*\u2068*/ 8296, /*\u2069*/ 8297, /*\u206A*/ 8298, /*\u206B*/ 8299, /*\u206C*/ 8300, /*\u206D*/ 8301, /*\u206E*/ 8302, /*\u206F*/ 8303, /*\uFEFF*/ 65279, /*\uFFF9*/ 65529, /*\uFFFA*/ 65530, /*\uFFFB*/ 65531], [-1], null)));
                    //--TRIMMABLE-BOUNDARY-END(197568823414)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590262390)
                    this._piiOffLogMessage = "PII logging is OFF. See https://aka.ms/IdentityModel/PII for details. ";
                    //--TRIMMABLE-BOUNDARY-END(8590262390)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229686)
                    this._piiOnLogMessage = "PII logging is ON, do not use in production. See https://aka.ms/IdentityModel/PII for details. ";
                    //--TRIMMABLE-BOUNDARY-END(12885229686)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180196982)
            
            static $h = 327798;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914117750),
    {
      "p": 131189,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902646,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338627190,
        "f": 83886113
      },
      "n": "Logger",
      "d": 327798,
      "h": 158914117750,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(158914117750),
//--TRIMMABLE-BOUNDARY-START(60129869942),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244968054,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748692598,
        "f": 83886120
      },
      "n": "HeaderWritten",
      "d": 327798,
      "h": 60129869942,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60129869942)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719804534),
    {
      "r": 262145,
      "p": [
        {
          "n": "level",
          "p": 65653
        }
      ],
      "n": "IsEnabled",
      "d": 327798,
      "h": 68719804534,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719804534),
//--TRIMMABLE-BOUNDARY-START(107374510198),
    {
      "r": 44171265,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        }
      ],
      "n": "LogArgumentNullException",
      "d": 327798,
      "h": 107374510198,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107374510198),
//--TRIMMABLE-BOUNDARY-START(111669477494),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$7",
      "d": 327798,
      "h": 111669477494,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(111669477494),
//--TRIMMABLE-BOUNDARY-START(73014771830),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$7",
      "d": 327798,
      "h": 73014771830,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73014771830),
//--TRIMMABLE-BOUNDARY-START(115964444790),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$6",
      "d": 327798,
      "h": 115964444790,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(115964444790),
//--TRIMMABLE-BOUNDARY-START(77309739126),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$6",
      "d": 327798,
      "h": 77309739126,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77309739126),
//--TRIMMABLE-BOUNDARY-START(120259412086),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$5",
      "d": 327798,
      "h": 120259412086,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(120259412086),
//--TRIMMABLE-BOUNDARY-START(81604706422),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$5",
      "d": 327798,
      "h": 81604706422,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(81604706422),
//--TRIMMABLE-BOUNDARY-START(124554379382),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$4",
      "d": 327798,
      "h": 124554379382,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124554379382),
//--TRIMMABLE-BOUNDARY-START(85899673718),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$4",
      "d": 327798,
      "h": 85899673718,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(85899673718),
//--TRIMMABLE-BOUNDARY-START(128849346678),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$3",
      "d": 327798,
      "h": 128849346678,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(128849346678),
//--TRIMMABLE-BOUNDARY-START(90194641014),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$3",
      "d": 327798,
      "h": 90194641014,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(90194641014),
//--TRIMMABLE-BOUNDARY-START(133144313974),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$2",
      "d": 327798,
      "h": 133144313974,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(133144313974),
//--TRIMMABLE-BOUNDARY-START(94489608310),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$2",
      "d": 327798,
      "h": 94489608310,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489608310),
//--TRIMMABLE-BOUNDARY-START(137439281270),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$1",
      "d": 327798,
      "h": 137439281270,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(137439281270),
//--TRIMMABLE-BOUNDARY-START(98784575606),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$1",
      "d": 327798,
      "h": 98784575606,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784575606),
//--TRIMMABLE-BOUNDARY-START(141734248566),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "d": 327798,
      "h": 141734248566,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(141734248566),
//--TRIMMABLE-BOUNDARY-START(103079542902),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "d": 327798,
      "h": 103079542902,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103079542902),
//--TRIMMABLE-BOUNDARY-START(150324183158),
    {
      "r": 79888385,
      "p": [
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "LogExceptionMessage",
      "o": "@$1",
      "d": 327798,
      "h": 150324183158,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150324183158),
//--TRIMMABLE-BOUNDARY-START(154619150454),
    {
      "r": 79888385,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "LogExceptionMessage",
      "d": 327798,
      "h": 154619150454,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154619150454),
//--TRIMMABLE-BOUNDARY-START(163209085046),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogInformation",
      "d": 327798,
      "h": 163209085046,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163209085046),
//--TRIMMABLE-BOUNDARY-START(167504052342),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogVerbose",
      "d": 327798,
      "h": 167504052342,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167504052342),
//--TRIMMABLE-BOUNDARY-START(171799019638),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogWarning",
      "d": 327798,
      "h": 171799019638,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171799019638),
//--TRIMMABLE-BOUNDARY-START(146029215862),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogExceptionImpl",
      "d": 327798,
      "h": 146029215862,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(146029215862),
//--TRIMMABLE-BOUNDARY-START(30065098870),
    {
      "r": 65653,
      "p": [
        {
          "n": "eventLevel",
          "p": 73596929
        }
      ],
      "n": "EventLevelToEventLogLevel",
      "d": 327798,
      "h": 30065098870,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065098870),
//--TRIMMABLE-BOUNDARY-START(34360066166),
    {
      "r": 73596929,
      "p": [
        {
          "n": "eventLevel",
          "p": 65653
        }
      ],
      "n": "EventLogLevelToEventLevel",
      "d": 327798,
      "h": 34360066166,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360066166),
//--TRIMMABLE-BOUNDARY-START(38655033462),
    {
      "r": 1310721,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "FormatInvariant",
      "d": 327798,
      "h": 38655033462,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655033462),
//--TRIMMABLE-BOUNDARY-START(206158758006),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "SanitizeSecurityArtifact",
      "d": 327798,
      "h": 206158758006,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206158758006),
//--TRIMMABLE-BOUNDARY-START(193273856118),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "RemovePII",
      "d": 327798,
      "h": 193273856118,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(193273856118),
//--TRIMMABLE-BOUNDARY-START(64424837238),
    {
      "r": 262145,
      "p": [
        {
          "n": "ex",
          "p": 79888385
        }
      ],
      "n": "IsCustomException",
      "d": 327798,
      "h": 64424837238,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64424837238),
//--TRIMMABLE-BOUNDARY-START(176093986934),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "MarkAsNonPII",
      "d": 327798,
      "h": 176093986934,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(176093986934),
//--TRIMMABLE-BOUNDARY-START(180388954230),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        },
        {
          "n": "callback",
          "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h
        }
      ],
      "n": "MarkAsSecurityArtifact",
      "o": "@$1",
      "d": 327798,
      "h": 180388954230,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(180388954230),
//--TRIMMABLE-BOUNDARY-START(184683921526),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        },
        {
          "n": "callback",
          "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h
        },
        {
          "n": "callbackUnsafe",
          "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h
        }
      ],
      "n": "MarkAsSecurityArtifact",
      "d": 327798,
      "h": 184683921526,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(184683921526),
//--TRIMMABLE-BOUNDARY-START(188978888822),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        },
        {
          "n": "callbackUnsafe",
          "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h
        }
      ],
      "n": "MarkAsUnsafeSecurityArtifact",
      "d": 327798,
      "h": 188978888822,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188978888822),
//--TRIMMABLE-BOUNDARY-START(227633594486),
    {
      "r": 262261,
      "p": [
        {
          "n": "eventLogLevel",
          "p": 65653
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteEntry",
      "d": 327798,
      "h": 227633594486,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(227633594486),
//--TRIMMABLE-BOUNDARY-START(201863790710),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        }
      ],
      "n": "Sanitize",
      "d": 327798,
      "h": 201863790710,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201863790710)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295094),
    {
      "t": 262145,
      "n": "_isHeaderWritten",
      "d": 327798,
      "h": 4295295094,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295295094),
//--TRIMMABLE-BOUNDARY-START(197568823414),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_charsToSanitize",
      "d": 327798,
      "h": 197568823414,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(197568823414),
//--TRIMMABLE-BOUNDARY-START(8590262390),
    {
      "t": 1310721,
      "n": "_piiOffLogMessage",
      "d": 327798,
      "h": 8590262390,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590262390),
//--TRIMMABLE-BOUNDARY-START(12885229686),
    {
      "t": 1310721,
      "n": "_piiOnLogMessage",
      "d": 327798,
      "h": 12885229686,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885229686)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475164278),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327798,
      "h": 21475164278,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164278)
  ],
  "h": 327798
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.LogHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327798)
        
        
        //--TRIMMABLE-BOUNDARY-START(458870)
        $asm.$str("$mil.Microsoft.IdentityModel.Logging.NonPII", ($self) => class NonPII extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180328054)
            /*object*/ Argument = null;
            //--TRIMMABLE-BOUNDARY-END(17180328054)
            
            //--TRIMMABLE-BOUNDARY-START(4295426166)
            $ctor$3(/*object*/ argument)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Argument = argument;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426166)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38655164534, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                const $t1 = this.Argument;
                return $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t)) ?? "Null";
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mil.Microsoft.IdentityModel.Logging.NonPII.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38655164534, 330712612865)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Argument = this.Argument;
                return copy;
            }
            static $h = 458870;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180328054),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262646,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360197238,
        "f": 83886081
      },
      "n": "Argument",
      "d": 458870,
      "h": 17180328054,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180328054)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 38655164534, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 458870,
      "h": 38655164534,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38655164534, 330712612865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426166),
    {
      "p": [
        {
          "n": "argument",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458870,
      "h": 4295426166,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426166),
//--TRIMMABLE-BOUNDARY-START(8590393462),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458870,
      "h": 8590393462,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393462)
  ],
  "h": 458870
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.NonPII`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458870)
        
        
        //--TRIMMABLE-BOUNDARY-START(524406)
        $asm.$str("$mil.Microsoft.IdentityModel.Logging.SecurityArtifact", ($self) => class SecurityArtifact extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885426294)
            /*string*/ static _scrubbedArtifact = null;
            //--TRIMMABLE-BOUNDARY-END(12885426294)
            
            //--TRIMMABLE-BOUNDARY-START(34360262774)
            /*object*/ Argument = null;
            //--TRIMMABLE-BOUNDARY-END(34360262774)
            
            //--TRIMMABLE-BOUNDARY-START(8590458998)
            /*Func<object, string>*/  get _disarmCallback() { return this.$getField(0, 4); }
            /*Func<object, string>*/  set _disarmCallback(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590458998)
            
            //--TRIMMABLE-BOUNDARY-START(4295491702)
            /*Func<object, string>*/  get _callbackUnsafe() { return this.$getField(4, 4); }
            /*Func<object, string>*/  set _callbackUnsafe(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295491702)
            
            //--TRIMMABLE-BOUNDARY-START(17180393590)
            $ctor$4(/*object*/ argument, /*Func<object, string>*/ toStringCallback)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393590);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Argument = argument;
                    this._disarmCallback = toStringCallback;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393590)
            
            //--TRIMMABLE-BOUNDARY-START(21475360886)
            $ctor$3(/*object*/ argument, /*Func<object, string>*/ toStringCallback, /*Func<object, string>*/ toStringCallbackUnsafe)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360886);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Argument = argument;
                    this._disarmCallback = toStringCallback;
                    this._callbackUnsafe = toStringCallbackUnsafe;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360886)
            
            //--TRIMMABLE-BOUNDARY-START(60130066550)
            static /*string */ UnknownSafeTokenCallback(/*object*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "#ScrubbedArtifact#"/*_scrubbedArtifact*/;
            }
            //--TRIMMABLE-BOUNDARY-END(60130066550)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55835099254, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disarmCallback === null)
                {
                    return "#ScrubbedArtifact#"/*_scrubbedArtifact*/;
                }
                if (this.Argument === null)
                {
                    return "null";
                }
                else 
                {
                    return this._disarmCallback.Invoke(this.Argument);
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55835099254, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(64425033846)
            /*string */ UnsafeToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._callbackUnsafe === null || this.Argument === null)
                {
                    return $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact.ToString.call(this);
                }
                else 
                {
                    return this._callbackUnsafe.Invoke(this.Argument);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425033846)
            
            //--TRIMMABLE-BOUNDARY-START(4295164022)
            //Generated interface implemetation for Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact.UnsafeToString()
            Microsoft$IdentityModel$Logging$ISafeLogSecurityArtifact$UnsafeToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnsafeToString(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164022)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Argument = this.Argument;
                copy._disarmCallback = this._disarmCallback;
                copy._callbackUnsafe = this._callbackUnsafe;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590458998)
                this._disarmCallback = null;
                //--TRIMMABLE-BOUNDARY-END(8590458998)
                
                //--TRIMMABLE-BOUNDARY-START(4295491702)
                this._callbackUnsafe = null;
                //--TRIMMABLE-BOUNDARY-END(4295491702)
                
            }
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426294)
                    this._scrubbedArtifact = "#ScrubbedArtifact#";
                    //--TRIMMABLE-BOUNDARY-END(12885426294)
                    
                }
            }
            static $h = 524406;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360262774),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197366,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540131958,
        "f": 83886082
      },
      "n": "Argument",
      "d": 524406,
      "h": 34360262774,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34360262774)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130066550),
    {
      "r": 1310721,
      "p": [
        {
          "n": "_",
          "p": 131073
        }
      ],
      "n": "UnknownSafeTokenCallback",
      "d": 524406,
      "h": 60130066550,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130066550),
//--TRIMMABLE-BOUNDARY-START(ALL, 55835099254, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 524406,
      "h": 55835099254,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55835099254, 330712612865),
//--TRIMMABLE-BOUNDARY-START(64425033846),
    {
      "r": 1310721,
      "n": "UnsafeToString",
      "d": 524406,
      "h": 64425033846,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425033846)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885426294),
    {
      "t": 1310721,
      "n": "_scrubbedArtifact",
      "d": 524406,
      "h": 12885426294,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885426294),
//--TRIMMABLE-BOUNDARY-START(8590458998),
    {
      "t": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h,
      "n": "_disarmCallback",
      "d": 524406,
      "h": 8590458998,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458998),
//--TRIMMABLE-BOUNDARY-START(4295491702),
    {
      "t": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h,
      "n": "_callbackUnsafe",
      "d": 524406,
      "h": 4295491702,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491702)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180393590),
    {
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "toStringCallback",
          "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 524406,
      "h": 17180393590,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393590),
//--TRIMMABLE-BOUNDARY-START(21475360886),
    {
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "toStringCallback",
          "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h
        },
        {
          "n": "toStringCallbackUnsafe",
          "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524406,
      "h": 21475360886,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360886),
//--TRIMMABLE-BOUNDARY-START(25770328182),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524406,
      "h": 25770328182,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328182)
  ],
  "i": [196726
  ],
  "h": 524406
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.SecurityArtifact`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524406)
        
        
        //--TRIMMABLE-BOUNDARY-START(589942)
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.TextWriterEventListener", ($self) => class TextWriterEventListener extends $.$$.System.Diagnostics.Tracing.EventListener
        {
            //--TRIMMABLE-BOUNDARY-START(8590524534)
            /*StreamWriter*/ _streamWriter = null;
            //--TRIMMABLE-BOUNDARY-END(8590524534)
            
            //--TRIMMABLE-BOUNDARY-START(4295557238)
            /*bool*/ _disposeStreamWriter = true;
            //--TRIMMABLE-BOUNDARY-END(4295557238)
            
            //--TRIMMABLE-BOUNDARY-START(30065361014)
            /*string*/ static DefaultLogFileName = null;
            //--TRIMMABLE-BOUNDARY-END(30065361014)
            
            //--TRIMMABLE-BOUNDARY-START(17180459126)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459126);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        /*Stream*/ let fileStream = new $.$$.System.IO.FileStream().$ctor$15($.$mil.Microsoft.IdentityModel.Logging.TextWriterEventListener.DefaultLogFileName, 4/*FileMode.OpenOrCreate*/, 2/*FileAccess.Write*/);
                        this._streamWriter = new $.$$.System.IO.StreamWriter().$ctor$8(fileStream);
                        this._streamWriter.AutoFlush = true;
                    }
                    catch(ex)
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$11("MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception."/*LogMessages.MIML10001*/, ex));
                        throw ex;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459126)
            
            //--TRIMMABLE-BOUNDARY-START(21475426422)
            $ctor$4(/*string*/ filePath)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426422);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrEmpty(filePath))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("filePath");
                    }
                    try
                    {
                        /*Stream*/ let fileStream = new $.$$.System.IO.FileStream().$ctor$15(filePath, 4/*FileMode.OpenOrCreate*/, 2/*FileAccess.Write*/);
                        this._streamWriter = new $.$$.System.IO.StreamWriter().$ctor$8(fileStream);
                        this._streamWriter.AutoFlush = true;
                    }
                    catch(ex)
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$11("MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception."/*LogMessages.MIML10001*/, ex));
                        throw ex;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426422)
            
            //--TRIMMABLE-BOUNDARY-START(25770393718)
            $ctor$3(/*StreamWriter*/ streamWriter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393718);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (streamWriter === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("streamWriter");
                    }
                    this._streamWriter = streamWriter;
                    this._disposeStreamWriter = false;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393718)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38655295606, 111742812161)
            /*void */ OnEventWritten(/*EventWrittenEventArgs*/ eventData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (eventData === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("eventData");
                }
                if (eventData.Payload === null || eventData.Payload.Count <= 0)
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("MIML10000: eventData.Payload is null or empty. Not logging any messages."/*LogMessages.MIML10000*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    return;
                }
                for(/*int*/ let i = 0; i < eventData.Payload.Count; i++)
                {
                    this._streamWriter.WriteLine$17($.$$.System.Object.ToString.call(eventData.Payload.get_Item(i)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38655295606, 111742812161)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34360328310, 55908237313)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposeStreamWriter && this._streamWriter !== null)
                {
                    this._streamWriter.Flush();
                    this._streamWriter.Dispose();
                }
                $.$$.System.GC.SuppressFinalize(this);
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34360328310, 55908237313)
            
            //--TRIMMABLE-BOUNDARY-START(12885491830)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(30065361014)
                    this.DefaultLogFileName = "IdentityModelLogs.txt";
                    //--TRIMMABLE-BOUNDARY-END(30065361014)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885491830)
            
            static $h = 589942;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 73662465,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 38655295606, 111742812161),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventData",
          "p": 75300865
        }
      ],
      "n": "OnEventWritten",
      "d": 589942,
      "h": 38655295606,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38655295606, 111742812161),
//--TRIMMABLE-BOUNDARY-START(ALL, 34360328310, 55908237313),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 589942,
      "h": 34360328310,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34360328310, 55908237313)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524534),
    {
      "t": 95289345,
      "n": "_streamWriter",
      "d": 589942,
      "h": 8590524534,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524534),
//--TRIMMABLE-BOUNDARY-START(4295557238),
    {
      "t": 262145,
      "n": "_disposeStreamWriter",
      "d": 589942,
      "h": 4295557238,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557238),
//--TRIMMABLE-BOUNDARY-START(30065361014),
    {
      "t": 1310721,
      "n": "DefaultLogFileName",
      "d": 589942,
      "h": 30065361014,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065361014)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180459126),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589942,
      "h": 17180459126,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459126),
//--TRIMMABLE-BOUNDARY-START(21475426422),
    {
      "p": [
        {
          "n": "filePath",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 589942,
      "h": 21475426422,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426422),
//--TRIMMABLE-BOUNDARY-START(25770393718),
    {
      "p": [
        {
          "n": "streamWriter",
          "p": 95289345
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589942,
      "h": 25770393718,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393718)
  ],
  "i": [90177537
  ],
  "h": 589942
}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventListener; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.TextWriterEventListener`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589942)
        
        
        //--TRIMMABLE-BOUNDARY-START(65654)
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource", ($self) => class IdentityModelEventSource extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            //--TRIMMABLE-BOUNDARY-START(21474902134)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger = new $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource().$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(21474902134)
            
            //--TRIMMABLE-BOUNDARY-START(25769869430)
            $ctor$10()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869430);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.LogLevel = 3/*EventLevel.Warning*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869430)
            
            //--TRIMMABLE-BOUNDARY-START(137439019126)
            /*IdentityModelEventSource*/ static Logger = null;
            //--TRIMMABLE-BOUNDARY-END(137439019126)
            
            //--TRIMMABLE-BOUNDARY-START(184683659382)
            /*bool*/ static ShowPII = false;
            //--TRIMMABLE-BOUNDARY-END(184683659382)
            
            //--TRIMMABLE-BOUNDARY-START(133144051830)
            /*bool*/ static LogCompleteSecurityArtifact = false;
            //--TRIMMABLE-BOUNDARY-END(133144051830)
            
            //--TRIMMABLE-BOUNDARY-START(124554117238)
            /*string*/ static HiddenPIIString = null;
            //--TRIMMABLE-BOUNDARY-END(124554117238)
            
            //--TRIMMABLE-BOUNDARY-START(128849084534)
            /*string*/ static HiddenSecurityArtifactString = null;
            //--TRIMMABLE-BOUNDARY-END(128849084534)
            
            //--TRIMMABLE-BOUNDARY-START(120259149942)
            /*bool*/ static HeaderWritten = false;
            //--TRIMMABLE-BOUNDARY-END(120259149942)
            
            //--TRIMMABLE-BOUNDARY-START(17179934838)
            /*string*/ static _versionLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17179934838)
            
            //--TRIMMABLE-BOUNDARY-START(4295032950)
            /*string*/ static _dateLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(4295032950)
            
            //--TRIMMABLE-BOUNDARY-START(8590000246)
            /*string*/ static _piiOffLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590000246)
            
            //--TRIMMABLE-BOUNDARY-START(12884967542)
            /*string*/ static _piiOnLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(12884967542)
            
            //--TRIMMABLE-BOUNDARY-START(197568561270)
            /*void */ WriteAlways$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568561270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled())
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(0/*EventLevel.LogAlways*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(6, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568561270)
            
            //--TRIMMABLE-BOUNDARY-START(201863528566)
            /*void */ WriteAlways(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863528566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled())
                {
                    if (args !== null)
                    {
                        this.WriteAlways$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteAlways$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201863528566)
            
            //--TRIMMABLE-BOUNDARY-START(231928299638)
            /*void */ WriteVerbose$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928299638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 5/*EventLevel.Verbose*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(5/*EventLevel.Verbose*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(1, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231928299638)
            
            //--TRIMMABLE-BOUNDARY-START(236223266934)
            /*void */ WriteVerbose(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223266934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 5/*EventLevel.Verbose*/)
                {
                    if (args !== null)
                    {
                        this.WriteVerbose$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteVerbose$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236223266934)
            
            //--TRIMMABLE-BOUNDARY-START(223338365046)
            /*void */ WriteInformation$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338365046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 4/*EventLevel.Informational*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(4/*EventLevel.Informational*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(2, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338365046)
            
            //--TRIMMABLE-BOUNDARY-START(227633332342)
            /*void */ WriteInformation(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633332342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 4/*EventLevel.Informational*/)
                {
                    if (args !== null)
                    {
                        this.WriteInformation$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteInformation$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633332342)
            
            //--TRIMMABLE-BOUNDARY-START(240518234230)
            /*void */ WriteWarning$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518234230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 3/*EventLevel.Warning*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(3/*EventLevel.Warning*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(3, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240518234230)
            
            //--TRIMMABLE-BOUNDARY-START(244813201526)
            /*void */ WriteWarning(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813201526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    this.WriteWarning$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                }
                else 
                {
                    this.WriteWarning$1(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244813201526)
            
            //--TRIMMABLE-BOUNDARY-START(214748430454)
            /*void */ WriteError$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748430454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 2/*EventLevel.Error*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(2/*EventLevel.Error*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(4, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748430454)
            
            //--TRIMMABLE-BOUNDARY-START(219043397750)
            /*void */ WriteError(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043397750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 2/*EventLevel.Error*/)
                {
                    if (args !== null)
                    {
                        this.WriteError$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteError$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043397750)
            
            //--TRIMMABLE-BOUNDARY-START(206158495862)
            /*void */ WriteCritical$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158495862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 1/*EventLevel.Critical*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(1/*EventLevel.Critical*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(5, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206158495862)
            
            //--TRIMMABLE-BOUNDARY-START(210453463158)
            /*void */ WriteCritical(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453463158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 1/*EventLevel.Critical*/)
                {
                    if (args !== null)
                    {
                        this.WriteCritical$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteCritical$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210453463158)
            
            //--TRIMMABLE-BOUNDARY-START(188978626678)
            /*void */ Write$7(/*EventLevel*/ level, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978626678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Write$6(level, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(188978626678)
            
            //--TRIMMABLE-BOUNDARY-START(193273593974)
            /*void */ Write$6(/*EventLevel*/ level, /*Exception*/ innerException, /*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273593974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (innerException !== null)
                {
                    if (!$.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII && !$.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsCustomException(innerException))
                    {
                        message = $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}", message, innerException.GetType$1());
                    }
                    else 
                    {
                        message = $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}", message, innerException.Message);
                    }
                }
                if (!$.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.HeaderWritten)
                {
                    this.WriteAlways$1($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource._versionLogMessage, $.$$.System.Version.ToString.call($.$$.System.Reflection.IntrospectionExtensions.GetTypeInfo($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.$type).Assembly.GetName().Version)));
                    this.WriteAlways$1($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource._dateLogMessage, $.$$.System.DateTime.UtcNow));
                    if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII)
                    {
                        this.WriteAlways$1($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource._piiOnLogMessage);
                    }
                    else 
                    {
                        this.WriteAlways$1($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource._piiOffLogMessage);
                    }
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.HeaderWritten = true;
                }
                switch(level)
                {
                    case 0/*EventLevel.LogAlways*/:
                    this.WriteAlways(message, args);
                    break;
                    case 1/*EventLevel.Critical*/:
                    this.WriteCritical(message, args);
                    break;
                    case 2/*EventLevel.Error*/:
                    this.WriteError(message, args);
                    break;
                    case 3/*EventLevel.Warning*/:
                    this.WriteWarning(message, args);
                    break;
                    case 4/*EventLevel.Informational*/:
                    this.WriteInformation(message, args);
                    break;
                    case 5/*EventLevel.Verbose*/:
                    this.WriteVerbose(message, args);
                    break;
                    default:
                    this.WriteError$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("MIML10002: Unknown log level: {0}."/*LogMessages.MIML10002*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(level, $.$$.System.Diagnostics.Tracing.EventLevel) ], null, null)));
                    this.WriteError(message, args);
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193273593974)
            
            //--TRIMMABLE-BOUNDARY-START(141733986422)
            /*EventLevel*/ LogLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(141733986422)
            
            //--TRIMMABLE-BOUNDARY-START(146028953718)
            static /*string */ PrepareMessage(/*EventLevel*/ level, /*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028953718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(message, null))
                {
                    return $.$$.System.String.Empty;
                }
                try
                {
                    if (args !== null && args.length > 0)
                    {
                        return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.InvariantCulture, "[{0}]{1} {2}", $.$$.System.Enum.ToStringT($.$$.System.Diagnostics.Tracing.EventLevel, $.$$.System.UInt32, level), $.$$.System.DateTime.UtcNow.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.InvariantCulture, "[{0}]{1} {2}", $.$$.System.Enum.ToStringT($.$$.System.Diagnostics.Tracing.EventLevel, $.$$.System.UInt32, level), $.$$.System.DateTime.UtcNow.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), message);
                }
                catch($e)
                {
                }
                try
                {
                    return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("[{0}]{1} {2}", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$$.System.Enum.ToStringT($.$$.System.Diagnostics.Tracing.EventLevel, $.$$.System.UInt32, level), $.$$.System.DateTime.UtcNow.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), message ], null, null));
                }
                catch($e)
                {
                    return $.$$.System.Enum.ToString.call(level) + $.$$.System.DateTime.UtcNow.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture) + message;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146028953718)
            
            //--TRIMMABLE-BOUNDARY-START(21474902134)
            //Static Initializer
            static $sinit()
            {
                {
                    this.HiddenPIIString = "[PII of type '{0}' is hidden. For more details, see https://aka.ms/IdentityModel/PII.]";
                }
                {
                    this.HiddenSecurityArtifactString = "[Security Artifact of type '{0}' is hidden. For more details, see https://aka.ms/IdentityModel/SecurityArtifactLogging.]";
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934838)
                    this._versionLogMessage = "Library version: {0}.";
                    //--TRIMMABLE-BOUNDARY-END(17179934838)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032950)
                    this._dateLogMessage = "Date: {0}.";
                    //--TRIMMABLE-BOUNDARY-END(4295032950)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000246)
                    this._piiOffLogMessage = "PII (personally identifiable information) logging is currently turned off. Set IdentityModelEventSource.ShowPII to 'true' to view the full details of exceptions.";
                    //--TRIMMABLE-BOUNDARY-END(8590000246)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967542)
                    this._piiOnLogMessage = "PII (personally identifiable information) logging is currently turned on. Set IdentityModelEventSource.ShowPII to 'false' to hide PII from log messages.";
                    //--TRIMMABLE-BOUNDARY-END(12884967542)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474902134)
            
            static $h = 65654;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 74383361,
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439019126),
    {
      "p": 65654,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784313462,
        "f": 50331681
      },
      "n": "Logger",
      "d": 65654,
      "h": 137439019126,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(137439019126),
//--TRIMMABLE-BOUNDARY-START(184683659382),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964182646,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388692086,
        "f": 83886113
      },
      "n": "ShowPII",
      "d": 65654,
      "h": 184683659382,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(184683659382),
//--TRIMMABLE-BOUNDARY-START(133144051830),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194378870,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163208822902,
        "f": 83886113
      },
      "n": "LogCompleteSecurityArtifact",
      "d": 65654,
      "h": 133144051830,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(133144051830),
//--TRIMMABLE-BOUNDARY-START(124554117238),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014509686,
        "f": 50331681
      },
      "n": "HiddenPIIString",
      "d": 65654,
      "h": 124554117238,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(124554117238),
//--TRIMMABLE-BOUNDARY-START(128849084534),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604444278,
        "f": 50331681
      },
      "n": "HiddenSecurityArtifactString",
      "d": 65654,
      "h": 128849084534,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(128849084534),
//--TRIMMABLE-BOUNDARY-START(120259149942),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424575094,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154618888310,
        "f": 83886113
      },
      "n": "HeaderWritten",
      "d": 65654,
      "h": 120259149942,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(120259149942),
//--TRIMMABLE-BOUNDARY-START(141733986422),
    {
      "p": 73596929,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374248054,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171798757494,
        "f": 83886081
      },
      "n": "LogLevel",
      "d": 65654,
      "h": 141733986422,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141733986422)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(197568561270),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteAlways",
      "o": "@$1",
      "d": 65654,
      "h": 197568561270,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 6,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 0,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197568561270),
//--TRIMMABLE-BOUNDARY-START(201863528566),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteAlways",
      "d": 65654,
      "h": 201863528566,
      "f": 16777217,
      "a": [
        {
          "t": 76939265,
          "c": 4371906561
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201863528566),
//--TRIMMABLE-BOUNDARY-START(231928299638),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteVerbose",
      "o": "@$1",
      "d": 65654,
      "h": 231928299638,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 1,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231928299638),
//--TRIMMABLE-BOUNDARY-START(236223266934),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteVerbose",
      "d": 65654,
      "h": 236223266934,
      "f": 16777217,
      "a": [
        {
          "t": 76939265,
          "c": 4371906561
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236223266934),
//--TRIMMABLE-BOUNDARY-START(223338365046),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteInformation",
      "o": "@$1",
      "d": 65654,
      "h": 223338365046,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 2,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 4,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223338365046),
//--TRIMMABLE-BOUNDARY-START(227633332342),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteInformation",
      "d": 65654,
      "h": 227633332342,
      "f": 16777217,
      "a": [
        {
          "t": 76939265,
          "c": 4371906561
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227633332342),
//--TRIMMABLE-BOUNDARY-START(240518234230),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteWarning",
      "o": "@$1",
      "d": 65654,
      "h": 240518234230,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 3,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 3,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240518234230),
//--TRIMMABLE-BOUNDARY-START(244813201526),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteWarning",
      "d": 65654,
      "h": 244813201526,
      "f": 16777217,
      "a": [
        {
          "t": 76939265,
          "c": 4371906561
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244813201526),
//--TRIMMABLE-BOUNDARY-START(214748430454),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteError",
      "o": "@$1",
      "d": 65654,
      "h": 214748430454,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 2,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214748430454),
//--TRIMMABLE-BOUNDARY-START(219043397750),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteError",
      "d": 65654,
      "h": 219043397750,
      "f": 16777217,
      "a": [
        {
          "t": 76939265,
          "c": 4371906561
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219043397750),
//--TRIMMABLE-BOUNDARY-START(206158495862),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteCritical",
      "o": "@$1",
      "d": 65654,
      "h": 206158495862,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 5,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 1,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206158495862),
//--TRIMMABLE-BOUNDARY-START(210453463158),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteCritical",
      "d": 65654,
      "h": 210453463158,
      "f": 16777217,
      "a": [
        {
          "t": 76939265,
          "c": 4371906561
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210453463158),
//--TRIMMABLE-BOUNDARY-START(188978626678),
    {
      "r": 65537,
      "p": [
        {
          "n": "level",
          "p": 73596929
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$7",
      "d": 65654,
      "h": 188978626678,
      "f": 16777217,
      "a": [
        {
          "t": 76939265,
          "c": 4371906561
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188978626678),
//--TRIMMABLE-BOUNDARY-START(193273593974),
    {
      "r": 65537,
      "p": [
        {
          "n": "level",
          "p": 73596929
        },
        {
          "n": "innerException",
          "p": 79888385
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Write",
      "o": "@$6",
      "d": 65654,
      "h": 193273593974,
      "f": 16777217,
      "a": [
        {
          "t": 76939265,
          "c": 4371906561
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193273593974),
//--TRIMMABLE-BOUNDARY-START(146028953718),
    {
      "r": 1310721,
      "p": [
        {
          "n": "level",
          "p": 73596929
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "PrepareMessage",
      "d": 65654,
      "h": 146028953718,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146028953718)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934838),
    {
      "t": 1310721,
      "n": "_versionLogMessage",
      "d": 65654,
      "h": 17179934838,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17179934838),
//--TRIMMABLE-BOUNDARY-START(4295032950),
    {
      "t": 1310721,
      "n": "_dateLogMessage",
      "d": 65654,
      "h": 4295032950,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032950),
//--TRIMMABLE-BOUNDARY-START(8590000246),
    {
      "t": 1310721,
      "n": "_piiOffLogMessage",
      "d": 65654,
      "h": 8590000246,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590000246),
//--TRIMMABLE-BOUNDARY-START(12884967542),
    {
      "t": 1310721,
      "n": "_piiOnLogMessage",
      "d": 65654,
      "h": 12884967542,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12884967542)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769869430),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 65654,
      "h": 25769869430,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25769869430)
  ],
  "i": [90177537
  ],
  "h": 65654,
  "a": [
    {
      "t": 74711041,
      "c": 4369678337,
      "n": [
        {
          "n": "Name",
          "v": "Microsoft.IdentityModel.EventSource",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.IdentityModelEventSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65654)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http"))
//--TRIMMABLE-BOUNDARY-END(118)
