
(function ($global, $, $$, $mia, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.Logging", 
    {"h":44440,"f":"Microsoft.IdentityModel.Logging","v":"1.0.35.0","a":[{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.S2S, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.S2S.Tokens, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.S2S.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.S2S.Tokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"Serviceable","t":1310721},{"v":"True","t":1310721}]},{"t":23527425,"c":8613462017,"a":[{"v":true,"t":262145}]},{"t":102432769,"c":4397400065,"a":[{"v":false,"t":262145}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.Protocols, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.IdentityModel.Logging.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsAotCompatible","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"Microsoft Corporation.","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":73793537,"c":4368760833,"a":[{"v":"\u00A9 Microsoft Corporation. All rights reserved.","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Includes Event Source based logging support.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"9.0.0.26241","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft IdentityModel","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.IdentityModel.Logging","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"RepositoryUrl","t":1310721},{"v":"https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact", ($self) => class ISafeLogSecurityArtifact
        {
            static $h = 241048;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":1310721,"n":"UnsafeToString","o":"Microsoft$IdentityModel$Logging$ISafeLogSecurityArtifact$UnsafeToString","d":241048,"h":4295208344,"f":16777473}],"h":241048}; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact`; }
        });
        
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil", ($self) => class IdentityModelTelemetryUtil
        {
            /*string*/ static skuTelemetry = null;
            /*string*/ static versionTelemetry = null;
            /*List<string>*/ static defaultTelemetryValues = null;
            /*ConcurrentDictionary<string, string>*/ static telemetryData = null;
            static /*string */ get ClientSku()
            {
                return "ID_NET10_0";
            }
            static /*string */ get ClientVer()
            {
                return $.$$.System.Version.ToString.call($.$$.System.Reflection.IntrospectionExtensions.GetTypeInfo($.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.$type).Assembly.GetName().Version);
            }
            static /*bool */ AddTelemetryData(/*string*/ key, /*string*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                    return false;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.defaultTelemetryValues.Contains(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("MIML10003: Sku and version telemetry cannot be manipulated. They are added by default."/*LogMessages.MIML10003*/));
                    return false;
                }
                $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.telemetryData.set_Item(key, value);
                return true;
            }
            static /*bool */ RemoveTelemetryData(/*string*/ key)
            {
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.defaultTelemetryValues.Contains(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("MIML10003: Sku and version telemetry cannot be manipulated. They are added by default."/*LogMessages.MIML10003*/));
                    return false;
                }
                return $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.telemetryData.TryRemove$1(key, $.$discardRef());
            }
            static /*void */ SetTelemetryData(/*HttpRequestMessage*/ request, /*IDictionary<string, string>*/ additionalHeaders)
            {
                if (request === null)
                {
                    return;
                }
                var $en2 = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.telemetryData.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var parameter = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        request.Headers.Remove(parameter.Key);
                        request.Headers.Add$1(parameter.Key, parameter.Value);
                    }
                }
                if (additionalHeaders !== null)
                {
                    var $en3 = additionalHeaders.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var header = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            request.Headers.Add$1(header.Key, header.Value);
                        }
                    }
                }
            }
            static /*bool */ UpdateDefaultTelemetryData(/*string*/ key, /*string*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(key))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                    return false;
                }
                $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.telemetryData.set_Item(key, value);
                return true;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.skuTelemetry = "x-client-SKU";
                }
                {
                    this.versionTelemetry = "x-client-Ver";
                }
                {
                    this.defaultTelemetryValues = (() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("x-client-SKU"/*skuTelemetry*/);
                        $i1.Add("x-client-Ver"/*versionTelemetry*/);
                        return $i1;
                    })();
                }
                {
                    this.telemetryData = (() =>
                    {
                        //new $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.String)()
                        const $t1 = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.set_Item("x-client-SKU"/*skuTelemetry*/, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.ClientSku);
                        $i1.set_Item("x-client-Ver"/*versionTelemetry*/, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil.ClientVer);
                        return $i1;
                    })();
                }
            }
            static $h = 175512;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25769979288,"f":50331681},"n":"ClientSku","d":175512,"h":21475011992,"f":2097185},{"p":1310721,"g":{"r":0,"d":0,"h":34359913880,"f":50331681},"n":"ClientVer","d":175512,"h":30064946584,"f":2097185}],"m":[{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"AddTelemetryData","d":175512,"h":38654881176,"f":16777249},{"r":262145,"p":[{"n":"key","p":1310721}],"n":"RemoveTelemetryData","d":175512,"h":42949848472,"f":16777249},{"r":65537,"p":[{"n":"request","p":7536685},{"n":"additionalHeaders","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h}],"n":"SetTelemetryData","d":175512,"h":47244815768,"f":16777256},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"UpdateDefaultTelemetryData","d":175512,"h":51539783064,"f":16777256}],"l":[{"t":1310721,"n":"skuTelemetry","d":175512,"h":4295142808,"f":4194344},{"t":1310721,"n":"versionTelemetry","d":175512,"h":8590110104,"f":4194344},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h,"n":"defaultTelemetryValues","d":175512,"h":12885077400,"f":4194344},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"telemetryData","d":175512,"h":17180044696,"f":4194344}],"h":175512}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil`; }
        });
        
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.LogMessages", ($self) => class LogMessages
        {
            /*string*/ static MIML10000 = null;
            /*string*/ static MIML10001 = null;
            /*string*/ static MIML10002 = null;
            /*string*/ static MIML10003 = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.MIML10000 = "MIML10000: eventData.Payload is null or empty. Not logging any messages.";
                }
                {
                    this.MIML10001 = "MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception.";
                }
                {
                    this.MIML10002 = "MIML10002: Unknown log level: {0}.";
                }
                {
                    this.MIML10003 = "MIML10003: Sku and version telemetry cannot be manipulated. They are added by default.";
                }
            }
            static $h = 437656;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"MIML10000","d":437656,"h":4295404952,"f":4194344},{"t":1310721,"n":"MIML10001","d":437656,"h":8590372248,"f":4194344},{"t":1310721,"n":"MIML10002","d":437656,"h":12885339544,"f":4194344},{"t":1310721,"n":"MIML10003","d":437656,"h":17180306840,"f":4194344}],"h":437656}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.LogMessages`; }
        });
        
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.LoggerContext", ($self) => class LoggerContext extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*Guid*/ activityId)
            {
                super.$ctor();
                {
                    this.ActivityId = activityId;
                }
                return this;
            }
            /*Guid*/ ActivityId;
            /*bool*/ CaptureLogs = false;
            /*string*/ DebugId = null;
            /*ICollection<string>*/ Logs = null;
            /*IDictionary<string, object>*/ PropertyBag = null;
            //default member initializer
            constructor()
            {
                super();
                this.ActivityId = $.$$.System.Guid.Empty;
                this.CaptureLogs = false;
                this.DebugId = $.$$.System.String.Empty;
                this.Logs = new ($.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String))().$ctor$1();
            }
            static $h = 306584;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":21475143064,"f":50331649},"s":{"r":0,"d":0,"h":25770110360,"f":83886081},"n":"ActivityId","d":306584,"h":17180175768,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655012248,"f":50331649},"s":{"r":0,"d":0,"h":42949979544,"f":83886081},"n":"CaptureLogs","d":306584,"h":34360044952,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55834881432,"f":50331777},"s":{"r":0,"d":0,"h":60129848728,"f":83886209},"n":"DebugId","d":306584,"h":51539914136,"f":2097281},{"p":$.$$.System.Collections.Generic.ICollection$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":73014750616,"f":50331649},"s":{"r":0,"d":0,"h":77309717912,"f":83886082},"n":"Logs","d":306584,"h":68719783320,"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":90194619800,"f":50331649},"s":{"r":0,"d":0,"h":94489587096,"f":83886081},"n":"PropertyBag","d":306584,"h":85899652504,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":306584,"h":4295273880,"f":16777217},{"p":[{"n":"activityId","p":56229889}],"n":".ctor","o":"$ctor$2","d":306584,"h":8590241176,"f":16777217}],"h":306584}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.LoggerContext`; }
        });
        
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.LogHelper", ($self) => class LogHelper extends $.$$.System.Object
        {
            /*IIdentityLogger*/ static Logger = null;
            /*bool*/ static _isHeaderWritten = false;
            /*SearchValues<char>*/ static s_charsToSanitize = null;
            /*string*/ static _piiOffLogMessage = null;
            /*string*/ static _piiOnLogMessage = null;
            static /*bool */ get HeaderWritten()
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper._isHeaderWritten;
            }
            static /*bool */ set HeaderWritten(value)
            {
                $.$mil.Microsoft.IdentityModel.Logging.LogHelper._isHeaderWritten = value;
            }
            static /*bool */ IsEnabled(/*EventLogLevel*/ level)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(level) || $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2($.$mil.Microsoft.IdentityModel.Logging.LogHelper.EventLogLevelToEventLevel(level), -1n);
            }
            static /*ArgumentNullException */ LogArgumentNullException(/*string*/ argument)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException$2($.$$.System.ArgumentNullException, 2/*EventLevel.Error*/, argument, "IDX10000: The parameter '{0}' cannot be a 'null' or an empty object. ", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ argument ], null, null));
            }
            static /*T */ LogException$7(T, /*string*/ message)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, 2/*EventLevel.Error*/, null, message, null);
            }
            static /*T */ LogArgumentException$7(T, /*string*/ argumentName, /*string*/ message)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, null, message, null);
            }
            static /*T */ LogException$6(T, /*string*/ format, /*params object[]*/ args)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, 2/*EventLevel.Error*/, null, format, args);
            }
            static /*T */ LogArgumentException$6(T, /*string*/ argumentName, /*string*/ format, /*params object[]*/ args)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, null, format, args);
            }
            static /*T */ LogException$5(T, /*Exception*/ innerException, /*string*/ message)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, 2/*EventLevel.Error*/, innerException, message, null);
            }
            static /*T */ LogArgumentException$5(T, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ message)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, innerException, message, null);
            }
            static /*T */ LogException$4(T, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, 2/*EventLevel.Error*/, innerException, format, args);
            }
            static /*T */ LogArgumentException$4(T, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, innerException, format, args);
            }
            static /*T */ LogException$3(T, /*EventLevel*/ eventLevel, /*string*/ message)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, eventLevel, null, message, null);
            }
            static /*T */ LogArgumentException$3(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*string*/ message)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, eventLevel, argumentName, null, message, null);
            }
            static /*T */ LogException$2(T, /*EventLevel*/ eventLevel, /*string*/ format, /*params object[]*/ args)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, eventLevel, null, format, args);
            }
            static /*T */ LogArgumentException$2(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*string*/ format, /*params object[]*/ args)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, eventLevel, argumentName, null, format, args);
            }
            static /*T */ LogException$1(T, /*EventLevel*/ eventLevel, /*Exception*/ innerException, /*string*/ message)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogException(T, eventLevel, innerException, message, null);
            }
            static /*T */ LogArgumentException$1(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ message)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentException(T, eventLevel, argumentName, innerException, message, null);
            }
            static /*T */ LogException(T, /*EventLevel*/ eventLevel, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionImpl(T, eventLevel, null, innerException, format, args);
            }
            static /*T */ LogArgumentException(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionImpl(T, eventLevel, argumentName, innerException, format, args);
            }
            static /*Exception */ LogExceptionMessage$1(/*Exception*/ exception)
            {
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage(2/*EventLevel.Error*/, exception);
            }
            static /*Exception */ LogExceptionMessage(/*EventLevel*/ eventLevel, /*Exception*/ exception)
            {
                if (exception === null)
                {
                    return null;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(eventLevel, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.Write$7(eventLevel, exception.InnerException, exception.Message);
                }
                /*EventLogLevel*/ let eventLogLevel = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.EventLevelToEventLogLevel(eventLevel);
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(eventLogLevel))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(eventLogLevel, exception.InnerException, exception.Message, null));
                }
                return exception;
            }
            static /*void */ LogInformation(/*string*/ message, /*params object[]*/ args)
            {
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.WriteInformation(message, args);
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(4/*EventLogLevel.Informational*/, null, message, args));
                }
            }
            static /*void */ LogVerbose(/*string*/ message, /*params object[]*/ args)
            {
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.WriteVerbose(message, args);
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(5/*EventLogLevel.Verbose*/, null, message, args));
                }
            }
            static /*void */ LogWarning(/*string*/ message, /*params object[]*/ args)
            {
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.WriteWarning(message, args);
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(3/*EventLogLevel.Warning*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(3/*EventLogLevel.Warning*/, null, message, args));
                }
            }
            static /*T */ LogExceptionImpl(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                /*string*/ let message;
                if (args !== null)
                {
                    message = $.$$.System.String.Format$3($.$$.System.Globalization.CultureInfo.InvariantCulture, format, args);
                }
                else 
                {
                    message = format;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.IsEnabled$2(eventLevel, -1n))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.Write$7(eventLevel, innerException, message);
                }
                /*EventLogLevel*/ let eventLogLevel = $.$mil.Microsoft.IdentityModel.Logging.LogHelper.EventLevelToEventLogLevel(eventLevel);
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$IsEnabled(eventLogLevel))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Logger.Microsoft$IdentityModel$Abstractions$IIdentityLogger$Log($.$mil.Microsoft.IdentityModel.Logging.LogHelper.WriteEntry(eventLogLevel, innerException, message, null));
                }
                if (innerException !== null)
                {
                    if ($.$$.System.String.IsNullOrEmpty(argumentName))
                    {
                        return $.$cast($.$$.System.Activator.CreateInstance$6(T.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ message, innerException ], null, null)), T);
                    }
                    else 
                    {
                        return $.$cast($.$$.System.Activator.CreateInstance$6(T.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ argumentName, message, innerException ], null, null)), T);
                    }
                }
                else 
                {
                    if ($.$$.System.String.IsNullOrEmpty(argumentName))
                    {
                        return $.$cast($.$$.System.Activator.CreateInstance$6(T.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ message ], null, null)), T);
                    }
                    else 
                    {
                        return $.$cast($.$$.System.Activator.CreateInstance$6(T.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ argumentName, message ], null, null)), T);
                    }
                }
            }
            static /*EventLogLevel */ EventLevelToEventLogLevel(/*EventLevel*/ eventLevel)
            {
                return (eventLevel >>> 0) <= 5 ? $.$cast(eventLevel, $.$mia.Microsoft.IdentityModel.Abstractions.EventLogLevel) : 2/*EventLogLevel.Error*/;
            }
            static /*EventLevel */ EventLogLevelToEventLevel(/*EventLogLevel*/ eventLevel)
            {
                return (eventLevel >>> 0) <= 5 ? $.$cast(eventLevel, $.$$.System.Diagnostics.Tracing.EventLevel) : 2/*EventLevel.Error*/;
            }
            static /*string */ FormatInvariant(/*string*/ format, /*params object[]*/ args)
            {
                if ($.$$.System.String.op_Equality(format, null))
                {
                    return $.$$.System.String.Empty;
                }
                if (args === null)
                {
                    return format;
                }
                if (!$.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII)
                {
                    return $.$$.System.String.Format$4($.$$.System.Globalization.CultureInfo.InvariantCulture, format, $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1($.$sl.System.Linq.Enumerable.ToArray($.$$.System.String, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Object, $.$$.System.String, args, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mil.Microsoft.IdentityModel.Logging.LogHelper, $.$mil.Microsoft.IdentityModel.Logging.LogHelper.RemovePII)))));
                }
                else 
                {
                    return $.$$.System.String.Format$3($.$$.System.Globalization.CultureInfo.InvariantCulture, format, $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Object, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Object, $.$$.System.Object, args, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object))().$ctor($.$mil.Microsoft.IdentityModel.Logging.LogHelper, $.$mil.Microsoft.IdentityModel.Logging.LogHelper.SanitizeSecurityArtifact))));
                }
            }
            static /*object */ SanitizeSecurityArtifact(/*object*/ arg)
            {
                if (arg === null)
                {
                    return "null";
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.LogCompleteSecurityArtifact && $.$is(arg, $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact))
                {
                    return ($.$as(arg, $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact)).Microsoft$IdentityModel$Logging$ISafeLogSecurityArtifact$UnsafeToString();
                }
                else if ($.$is(arg, $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact))
                {
                    const $t1 = arg;
                    return $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.HiddenSecurityArtifactString, $.$ifnn($t1, ($t) => $.$$.System.Type.ToString.call($t)) ?? "Null");
                }
                return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Sanitize($.$$.System.Object.ToString.call(arg));
            }
            static /*string */ RemovePII(/*object*/ arg)
            {
                let ex;
                if ($.$is(arg, $.$$.System.Exception, { set $v(v){ ex = v; } }) && $.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsCustomException(ex))
                {
                    return $.$$.System.Exception.ToString.call(ex);
                }
                if ($.$is(arg, $.$mil.Microsoft.IdentityModel.Logging.NonPII))
                {
                    return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.Sanitize($.$$.System.Object.ToString.call(arg));
                }
                const $t1 = arg;
                return $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.HiddenPIIString, $.$ifnn($t1, ($t) => $.$$.System.Type.ToString.call($t)) ?? "Null");
            }
            static /*bool */ IsCustomException(/*Exception*/ ex)
            {
                return $.$$.System.String.StartsWith$2.call(ex.GetType$1().FullName, "Microsoft.IdentityModel.", 4/*StringComparison.Ordinal*/);
            }
            static /*object */ MarkAsNonPII(/*object*/ arg)
            {
                return new $.$mil.Microsoft.IdentityModel.Logging.NonPII().$ctor$3(arg);
            }
            static /*object */ MarkAsSecurityArtifact$1(/*object*/ arg, /*Func<object, string>*/ callback)
            {
                return new $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact().$ctor$4(arg, callback);
            }
            static /*object */ MarkAsSecurityArtifact(/*object*/ arg, /*Func<object, string>*/ callback, /*Func<object, string>*/ callbackUnsafe)
            {
                return new $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact().$ctor$3(arg, callback, callbackUnsafe);
            }
            static /*object */ MarkAsUnsafeSecurityArtifact(/*object*/ arg, /*Func<object, string>*/ callbackUnsafe)
            {
                return new $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact().$ctor$3(arg, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact, $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact.UnknownSafeTokenCallback), callbackUnsafe);
            }
            static /*LogEntry */ WriteEntry(/*EventLogLevel*/ eventLogLevel, /*Exception*/ innerException, /*string*/ message, /*params object[]*/ args)
            {
                if ($.$$.System.String.IsNullOrEmpty(message))
                {
                    return null;
                }
                if (innerException !== null)
                {
                    if (!$.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII && !$.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsCustomException(innerException))
                    {
                        message = $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}. ", message, innerException.GetType$1());
                    }
                    else 
                    {
                        message = $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}. ", message, innerException.Message);
                    }
                }
                message = args === null ? message : $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args);
                /*LogEntry*/ let entry = new $.$mia.Microsoft.IdentityModel.Abstractions.LogEntry().$ctor$1();
                entry.EventLogLevel = eventLogLevel;
                if (!$.$mil.Microsoft.IdentityModel.Logging.LogHelper._isHeaderWritten)
                {
                    /*string*/ let headerMessage = $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.InvariantCulture, "Microsoft.IdentityModel Version: {0}. Date {1}. {2}", $.$$.System.Version.ToString.call($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.$type.Assembly.GetName().Version), $.$$.System.DateTime.UtcNow, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII ? $.$mil.Microsoft.IdentityModel.Logging.LogHelper._piiOnLogMessage : $.$mil.Microsoft.IdentityModel.Logging.LogHelper._piiOffLogMessage);
                    entry.Message = headerMessage + $.$$.System.Environment.NewLine + message;
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper._isHeaderWritten = true;
                }
                else 
                {
                    entry.Message = message;
                }
                return entry;
            }
            static /*string */ Sanitize(/*string*/ input)
            {
                if ($.$$.System.String.IsNullOrEmpty(input))
                {
                    return input;
                }
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(input), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.s_charsToSanitize);
                if (index < 0)
                {
                    return input;
                }
                /*var*/ let sanitized = new $.$$.System.Text.StringBuilder().$ctor$4(input.length);
                /*int*/ let lastIndex = 0;
                while(index >= 0)
                {
                    sanitized.Append$15($.$$.System.MemoryExtensions.AsSpan$1(input, lastIndex, ((index - lastIndex) | 0)));
                    /*char*/ let c = $.$$.System.String.get_Chars.call(input, index);
                    if (c === /*\r*/ 13)
                    {
                        sanitized.Append$19("\\r");
                    }
                    else if (c === /*\n*/ 10)
                    {
                        sanitized.Append$19("\\n");
                    }
                    else if (c === /*\t*/ 9)
                    {
                        sanitized.Append$19("\\t");
                    }
                    else 
                    {
                        sanitized.Append$26((() =>
                        {
                            var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                            $handler.AppendLiteral("\\u");
                            $handler.AppendFormatted($.$box($.$cast(c, $.$$.System.Int32), $.$$.System.Int32), null, "X4");
                            return $handler.ToStringAndClear                    ();
                        })());
                    }
                    lastIndex = ((index + 1) | 0);
                    if (lastIndex < input.length)
                    {
                        index = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$2(input, lastIndex), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.s_charsToSanitize);
                    }
                    else 
                    {
                        index = -1;
                    }
                    if (index >= 0)
                    {
                        index += lastIndex;
                    }
                }
                if (lastIndex < input.length)
                {
                    sanitized.Append$15($.$$.System.MemoryExtensions.AsSpan$2(input, lastIndex));
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sanitized);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Logger = $.$mia.Microsoft.IdentityModel.Abstractions.NullIdentityModelLogger.Instance;
                }
                {
                    this.s_charsToSanitize = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*\u0000*/ 0, /*\u0001*/ 1, /*\u0002*/ 2, /*\u0003*/ 3, /*\u0004*/ 4, /*\u0005*/ 5, /*\u0006*/ 6, /*\u0007*/ 7, /*\u0008*/ 8, /*\t*/ 9, /*\n*/ 10, /*\u000B*/ 11, /*\u000C*/ 12, /*\r*/ 13, /*\u000E*/ 14, /*\u000F*/ 15, /*\u0010*/ 16, /*\u0011*/ 17, /*\u0012*/ 18, /*\u0013*/ 19, /*\u0014*/ 20, /*\u0015*/ 21, /*\u0016*/ 22, /*\u0017*/ 23, /*\u0018*/ 24, /*\u0019*/ 25, /*\u001A*/ 26, /*\u001B*/ 27, /*\u001C*/ 28, /*\u001D*/ 29, /*\u001E*/ 30, /*\u001F*/ 31, /*\u007F*/ 127, /*\u0080*/ 128, /*\u0081*/ 129, /*\u0082*/ 130, /*\u0083*/ 131, /*\u0084*/ 132, /*\u0085*/ 133, /*\u0086*/ 134, /*\u0087*/ 135, /*\u0088*/ 136, /*\u0089*/ 137, /*\u008A*/ 138, /*\u008B*/ 139, /*\u008C*/ 140, /*\u008D*/ 141, /*\u008E*/ 142, /*\u008F*/ 143, /*\u0090*/ 144, /*\u0091*/ 145, /*\u0092*/ 146, /*\u0093*/ 147, /*\u0094*/ 148, /*\u0095*/ 149, /*\u0096*/ 150, /*\u0097*/ 151, /*\u0098*/ 152, /*\u0099*/ 153, /*\u009A*/ 154, /*\u009B*/ 155, /*\u009C*/ 156, /*\u009D*/ 157, /*\u009E*/ 158, /*\u009F*/ 159, /*\u00AD*/ 173, /*\u0600*/ 1536, /*\u0601*/ 1537, /*\u0602*/ 1538, /*\u0603*/ 1539, /*\u0604*/ 1540, /*\u0605*/ 1541, /*\u061C*/ 1564, /*\u06DD*/ 1757, /*\u070F*/ 1807, /*\u0890*/ 2192, /*\u0891*/ 2193, /*\u08E2*/ 2274, /*\u180E*/ 6158, /*\u200B*/ 8203, /*\u200C*/ 8204, /*\u200D*/ 8205, /*\u200E*/ 8206, /*\u200F*/ 8207, /*\u202A*/ 8234, /*\u202B*/ 8235, /*\u202C*/ 8236, /*\u202D*/ 8237, /*\u202E*/ 8238, /*\u2060*/ 8288, /*\u2061*/ 8289, /*\u2062*/ 8290, /*\u2063*/ 8291, /*\u2064*/ 8292, /*\u2066*/ 8294, /*\u2067*/ 8295, /*\u2068*/ 8296, /*\u2069*/ 8297, /*\u206A*/ 8298, /*\u206B*/ 8299, /*\u206C*/ 8300, /*\u206D*/ 8301, /*\u206E*/ 8302, /*\u206F*/ 8303, /*\uFEFF*/ 65279, /*\uFFF9*/ 65529, /*\uFFFA*/ 65530, /*\uFFFB*/ 65531], [-1], null)));
                }
                {
                    this._piiOffLogMessage = "PII logging is OFF. See https://aka.ms/IdentityModel/PII for details. ";
                }
                {
                    this._piiOnLogMessage = "PII logging is ON, do not use in production. See https://aka.ms/IdentityModel/PII for details. ";
                }
            }
            static $h = 372120;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":194948,"g":{"r":0,"d":0,"h":12885274008,"f":50331681},"s":{"r":0,"d":0,"h":17180241304,"f":83886113},"n":"Logger","d":372120,"h":8590306712,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":42950045080,"f":50331688},"s":{"r":0,"d":0,"h":47245012376,"f":83886120},"n":"HeaderWritten","d":372120,"h":38655077784,"f":2097192}],"m":[{"r":262145,"p":[{"n":"level","p":129412}],"n":"IsEnabled","d":372120,"h":51539979672,"f":16777249},{"r":13565953,"p":[{"n":"argument","p":1310721}],"n":"LogArgumentNullException","d":372120,"h":55834946968,"f":16777249},{"r":(T) => T.$h,"p":[{"n":"message","p":1310721}],"g":["T"],"n":"LogException","o":"@$7","d":372120,"h":60129914264,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"argumentName","p":1310721},{"n":"message","p":1310721}],"g":["T"],"n":"LogArgumentException","o":"@$7","d":372120,"h":64424881560,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogException","o":"@$6","d":372120,"h":68719848856,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"argumentName","p":1310721},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogArgumentException","o":"@$6","d":372120,"h":73014816152,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"innerException","p":47251457},{"n":"message","p":1310721}],"g":["T"],"n":"LogException","o":"@$5","d":372120,"h":77309783448,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"argumentName","p":1310721},{"n":"innerException","p":47251457},{"n":"message","p":1310721}],"g":["T"],"n":"LogArgumentException","o":"@$5","d":372120,"h":81604750744,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"innerException","p":47251457},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogException","o":"@$4","d":372120,"h":85899718040,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"argumentName","p":1310721},{"n":"innerException","p":47251457},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogArgumentException","o":"@$4","d":372120,"h":90194685336,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"message","p":1310721}],"g":["T"],"n":"LogException","o":"@$3","d":372120,"h":94489652632,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"argumentName","p":1310721},{"n":"message","p":1310721}],"g":["T"],"n":"LogArgumentException","o":"@$3","d":372120,"h":98784619928,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogException","o":"@$2","d":372120,"h":103079587224,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"argumentName","p":1310721},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogArgumentException","o":"@$2","d":372120,"h":107374554520,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"innerException","p":47251457},{"n":"message","p":1310721}],"g":["T"],"n":"LogException","o":"@$1","d":372120,"h":111669521816,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"argumentName","p":1310721},{"n":"innerException","p":47251457},{"n":"message","p":1310721}],"g":["T"],"n":"LogArgumentException","o":"@$1","d":372120,"h":115964489112,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"innerException","p":47251457},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogException","d":372120,"h":120259456408,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"argumentName","p":1310721},{"n":"innerException","p":47251457},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogArgumentException","d":372120,"h":124554423704,"f":16908321},{"r":47251457,"p":[{"n":"exception","p":47251457}],"n":"LogExceptionMessage","o":"@$1","d":372120,"h":128849391000,"f":16777249},{"r":47251457,"p":[{"n":"eventLevel","p":40960001},{"n":"exception","p":47251457}],"n":"LogExceptionMessage","d":372120,"h":133144358296,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"LogInformation","d":372120,"h":137439325592,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"LogVerbose","d":372120,"h":141734292888,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"LogWarning","d":372120,"h":146029260184,"f":16777249},{"r":(T) => T.$h,"p":[{"n":"eventLevel","p":40960001},{"n":"argumentName","p":1310721},{"n":"innerException","p":47251457},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":["T"],"n":"LogExceptionImpl","d":372120,"h":150324227480,"f":16908322},{"r":129412,"p":[{"n":"eventLevel","p":40960001}],"n":"EventLevelToEventLogLevel","d":372120,"h":154619194776,"f":16777250},{"r":40960001,"p":[{"n":"eventLevel","p":129412}],"n":"EventLogLevelToEventLevel","d":372120,"h":158914162072,"f":16777250},{"r":1310721,"p":[{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"FormatInvariant","d":372120,"h":163209129368,"f":16777249},{"r":131073,"p":[{"n":"arg","p":131073}],"n":"SanitizeSecurityArtifact","d":372120,"h":167504096664,"f":16777250},{"r":1310721,"p":[{"n":"arg","p":131073}],"n":"RemovePII","d":372120,"h":171799063960,"f":16777250},{"r":262145,"p":[{"n":"ex","p":47251457}],"n":"IsCustomException","d":372120,"h":176094031256,"f":16777256},{"r":131073,"p":[{"n":"arg","p":131073}],"n":"MarkAsNonPII","d":372120,"h":180388998552,"f":16777249},{"r":131073,"p":[{"n":"arg","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h}],"n":"MarkAsSecurityArtifact","o":"@$1","d":372120,"h":184683965848,"f":16777249},{"r":131073,"p":[{"n":"arg","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h},{"n":"callbackUnsafe","p":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h}],"n":"MarkAsSecurityArtifact","d":372120,"h":188978933144,"f":16777249},{"r":131073,"p":[{"n":"arg","p":131073},{"n":"callbackUnsafe","p":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h}],"n":"MarkAsUnsafeSecurityArtifact","d":372120,"h":193273900440,"f":16777249},{"r":326020,"p":[{"n":"eventLogLevel","p":129412},{"n":"innerException","p":47251457},{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"WriteEntry","d":372120,"h":197568867736,"f":16777250},{"r":1310721,"p":[{"n":"input","p":1310721}],"n":"Sanitize","d":372120,"h":201863835032,"f":16777250}],"l":[{"t":262145,"n":"_isHeaderWritten","d":372120,"h":21475208600,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_charsToSanitize","d":372120,"h":25770175896,"f":4194338},{"t":1310721,"n":"_piiOffLogMessage","d":372120,"h":30065143192,"f":4194338},{"t":1310721,"n":"_piiOnLogMessage","d":372120,"h":34360110488,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":372120,"h":206158802328,"f":16777217}],"h":372120}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.LogHelper`; }
        });
        
        $asm.$str("$mil.Microsoft.IdentityModel.Logging.NonPII", ($self) => class NonPII extends $.$$.System.ValueType
        {
            /*object*/ Argument = null;
            $ctor$3(/*object*/ argument)
            {
                super.$ctor$1();
                {
                    this.Argument = argument;
                }
                return this;
            }
            static/*conventional*/ /*string */ ToString()
            {
                const $t1 = this.Argument;
                return $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t)) ?? "Null";
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mil.Microsoft.IdentityModel.Logging.NonPII.ToString.apply(this, arguments); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Argument = this.Argument;
                return copy;
            }
            static $h = 503192;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885405080,"f":50331649},"s":{"r":0,"d":0,"h":17180372376,"f":83886081},"n":"Argument","d":503192,"h":8590437784,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":503192,"h":25770306968,"f":16809985}],"c":[{"p":[{"n":"argument","p":131073}],"n":".ctor","o":"$ctor$3","d":503192,"h":21475339672,"f":16777217},{"n":".ctor","o":"$ctor$2","d":503192,"h":30065274264,"f":16777217}],"h":503192}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.NonPII`; }
        });
        
        $asm.$str("$mil.Microsoft.IdentityModel.Logging.SecurityArtifact", ($self) => class SecurityArtifact extends $.$$.System.ValueType
        {
            /*string*/ static _scrubbedArtifact = null;
            /*object*/ Argument = null;
            /*Func<object, string>*/  get _disarmCallback() { return this.$getField(0, 4); }
            /*Func<object, string>*/  set _disarmCallback(value) { this.$setField(0, 4, value); }
            /*Func<object, string>*/  get _callbackUnsafe() { return this.$getField(4, 4); }
            /*Func<object, string>*/  set _callbackUnsafe(value) { this.$setField(4, 4, value); }
            $ctor$4(/*object*/ argument, /*Func<object, string>*/ toStringCallback)
            {
                super.$ctor$1();
                {
                    this.Argument = argument;
                    this._disarmCallback = toStringCallback;
                }
                return this;
            }
            $ctor$3(/*object*/ argument, /*Func<object, string>*/ toStringCallback, /*Func<object, string>*/ toStringCallbackUnsafe)
            {
                super.$ctor$1();
                {
                    this.Argument = argument;
                    this._disarmCallback = toStringCallback;
                    this._callbackUnsafe = toStringCallbackUnsafe;
                }
                return this;
            }
            static /*string */ UnknownSafeTokenCallback(/*object*/ _)
            {
                return "#ScrubbedArtifact#"/*_scrubbedArtifact*/;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this._disarmCallback === null)
                {
                    return "#ScrubbedArtifact#"/*_scrubbedArtifact*/;
                }
                if (this.Argument === null)
                {
                    return "null";
                }
                else 
                {
                    return this._disarmCallback.Invoke(this.Argument);
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact.ToString.apply(this, arguments); }
            /*string */ UnsafeToString()
            {
                if (this._callbackUnsafe === null || this.Argument === null)
                {
                    return $.$mil.Microsoft.IdentityModel.Logging.SecurityArtifact.ToString.call(this);
                }
                else 
                {
                    return this._callbackUnsafe.Invoke(this.Argument);
                }
            }
            //Generated interface implemetation for Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact.UnsafeToString()
            Microsoft$IdentityModel$Logging$ISafeLogSecurityArtifact$UnsafeToString()
            {
                return this.UnsafeToString(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Argument = this.Argument;
                copy._disarmCallback = this._disarmCallback;
                copy._callbackUnsafe = this._callbackUnsafe;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._disarmCallback = null;
                this._callbackUnsafe = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._scrubbedArtifact = "#ScrubbedArtifact#";
                }
            }
            static $h = 568728;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":131073,"g":{"r":0,"d":0,"h":17180437912,"f":50331650},"s":{"r":0,"d":0,"h":21475405208,"f":83886082},"n":"Argument","d":568728,"h":12885470616,"f":2097154}],"m":[{"r":1310721,"p":[{"n":"_","p":131073}],"n":"UnknownSafeTokenCallback","d":568728,"h":42950241688,"f":16777249},{"r":1310721,"n":"ToString","d":568728,"h":47245208984,"f":16809985},{"r":1310721,"n":"UnsafeToString","d":568728,"h":51540176280,"f":16777217}],"l":[{"t":1310721,"n":"_scrubbedArtifact","d":568728,"h":4295536024,"f":4194338},{"t":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h,"n":"_disarmCallback","d":568728,"h":25770372504,"f":4194306},{"t":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h,"n":"_callbackUnsafe","d":568728,"h":30065339800,"f":4194306}],"c":[{"p":[{"n":"argument","p":131073},{"n":"toStringCallback","p":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h}],"n":".ctor","o":"$ctor$4","d":568728,"h":34360307096,"f":16777217},{"p":[{"n":"argument","p":131073},{"n":"toStringCallback","p":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h},{"n":"toStringCallbackUnsafe","p":$.$$.System.Func$$$($.$$.System.Object, $.$$.System.String).$h}],"n":".ctor","o":"$ctor$3","d":568728,"h":38655274392,"f":16777217},{"n":".ctor","o":"$ctor$2","d":568728,"h":55835143576,"f":16777217}],"i":[241048],"h":568728}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.SecurityArtifact`; }
        });
        
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.TextWriterEventListener", ($self) => class TextWriterEventListener extends $.$$.System.Diagnostics.Tracing.EventListener
        {
            /*StreamWriter*/ _streamWriter = null;
            /*bool*/ _disposeStreamWriter = true;
            /*string*/ static DefaultLogFileName = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    try
                    {
                        /*Stream*/ let fileStream = new $.$$.System.IO.FileStream().$ctor$15($.$mil.Microsoft.IdentityModel.Logging.TextWriterEventListener.DefaultLogFileName, 4/*FileMode.OpenOrCreate*/, 2/*FileAccess.Write*/);
                        this._streamWriter = new $.$$.System.IO.StreamWriter().$ctor$8(fileStream);
                        this._streamWriter.AutoFlush = true;
                    }
                    catch(ex)
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$11("MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception."/*LogMessages.MIML10001*/, ex));
                        throw ex;
                    }
                }
                return this;
            }
            $ctor$4(/*string*/ filePath)
            {
                super.$ctor$1();
                {
                    if ($.$$.System.String.IsNullOrEmpty(filePath))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("filePath");
                    }
                    try
                    {
                        /*Stream*/ let fileStream = new $.$$.System.IO.FileStream().$ctor$15(filePath, 4/*FileMode.OpenOrCreate*/, 2/*FileAccess.Write*/);
                        this._streamWriter = new $.$$.System.IO.StreamWriter().$ctor$8(fileStream);
                        this._streamWriter.AutoFlush = true;
                    }
                    catch(ex)
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$11("MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception."/*LogMessages.MIML10001*/, ex));
                        throw ex;
                    }
                }
                return this;
            }
            $ctor$3(/*StreamWriter*/ streamWriter)
            {
                super.$ctor$1();
                {
                    if (streamWriter === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("streamWriter");
                    }
                    this._streamWriter = streamWriter;
                    this._disposeStreamWriter = false;
                }
                return this;
            }
            /*void */ OnEventWritten(/*EventWrittenEventArgs*/ eventData)
            {
                if (eventData === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("eventData");
                }
                if (eventData.Payload === null || eventData.Payload.Count <= 0)
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("MIML10000: eventData.Payload is null or empty. Not logging any messages."/*LogMessages.MIML10000*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    return;
                }
                for(/*int*/ let i = 0; i < eventData.Payload.Count; i++)
                {
                    this._streamWriter.WriteLine$17($.$$.System.Object.ToString.call(eventData.Payload.get_Item(i)));
                }
            }
            /*void */ Dispose()
            {
                if (this._disposeStreamWriter && this._streamWriter !== null)
                {
                    this._streamWriter.Flush();
                    this._streamWriter.Dispose();
                }
                $.$$.System.GC.SuppressFinalize(this);
                super.Dispose();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultLogFileName = "IdentityModelLogs.txt";
                }
            }
            static $h = 634264;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41025537,"m":[{"r":65537,"p":[{"n":"eventData","p":42663937}],"n":"OnEventWritten","d":634264,"h":30065405336,"f":16809988},{"r":65537,"n":"Dispose","d":634264,"h":34360372632,"f":16809985}],"l":[{"t":62652417,"n":"_streamWriter","d":634264,"h":4295601560,"f":4194306},{"t":262145,"n":"_disposeStreamWriter","d":634264,"h":8590568856,"f":4194306},{"t":1310721,"n":"DefaultLogFileName","d":634264,"h":12885536152,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":634264,"h":17180503448,"f":16777217},{"p":[{"n":"filePath","p":1310721}],"n":".ctor","o":"$ctor$4","d":634264,"h":21475470744,"f":16777217},{"p":[{"n":"streamWriter","p":62652417}],"n":".ctor","o":"$ctor$3","d":634264,"h":25770438040,"f":16777217}],"i":[57540609],"h":634264}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventListener; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.TextWriterEventListener`; }
        });
        
        $asm.$cls("$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource", ($self) => class IdentityModelEventSource extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            /*Static constructor*/ static $cctor()
            {
                $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger = new $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource().$ctor$10();
            }
            $ctor$10()
            {
                super.$ctor$1();
                {
                    this.LogLevel = 3/*EventLevel.Warning*/;
                }
                return this;
            }
            /*IdentityModelEventSource*/ static Logger = null;
            /*bool*/ static ShowPII = false;
            /*bool*/ static LogCompleteSecurityArtifact = false;
            /*string*/ static HiddenPIIString = null;
            /*string*/ static HiddenSecurityArtifactString = null;
            /*bool*/ static HeaderWritten = false;
            /*string*/ static _versionLogMessage = null;
            /*string*/ static _dateLogMessage = null;
            /*string*/ static _piiOffLogMessage = null;
            /*string*/ static _piiOnLogMessage = null;
            /*void */ WriteAlways$1(/*string*/ message)
            {
                if (this.IsEnabled())
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(0/*EventLevel.LogAlways*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(6, message);
                }
            }
            /*void */ WriteAlways(/*string*/ message, /*params object[]*/ args)
            {
                if (this.IsEnabled())
                {
                    if (args !== null)
                    {
                        this.WriteAlways$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteAlways$1(message);
                    }
                }
            }
            /*void */ WriteVerbose$1(/*string*/ message)
            {
                if (this.IsEnabled() && this.LogLevel >= 5/*EventLevel.Verbose*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(5/*EventLevel.Verbose*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(1, message);
                }
            }
            /*void */ WriteVerbose(/*string*/ message, /*params object[]*/ args)
            {
                if (this.IsEnabled() && this.LogLevel >= 5/*EventLevel.Verbose*/)
                {
                    if (args !== null)
                    {
                        this.WriteVerbose$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteVerbose$1(message);
                    }
                }
            }
            /*void */ WriteInformation$1(/*string*/ message)
            {
                if (this.IsEnabled() && this.LogLevel >= 4/*EventLevel.Informational*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(4/*EventLevel.Informational*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(2, message);
                }
            }
            /*void */ WriteInformation(/*string*/ message, /*params object[]*/ args)
            {
                if (this.IsEnabled() && this.LogLevel >= 4/*EventLevel.Informational*/)
                {
                    if (args !== null)
                    {
                        this.WriteInformation$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteInformation$1(message);
                    }
                }
            }
            /*void */ WriteWarning$1(/*string*/ message)
            {
                if (this.IsEnabled() && this.LogLevel >= 3/*EventLevel.Warning*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(3/*EventLevel.Warning*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(3, message);
                }
            }
            /*void */ WriteWarning(/*string*/ message, /*params object[]*/ args)
            {
                if (args !== null)
                {
                    this.WriteWarning$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                }
                else 
                {
                    this.WriteWarning$1(message);
                }
            }
            /*void */ WriteError$1(/*string*/ message)
            {
                if (this.IsEnabled() && this.LogLevel >= 2/*EventLevel.Error*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(2/*EventLevel.Error*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(4, message);
                }
            }
            /*void */ WriteError(/*string*/ message, /*params object[]*/ args)
            {
                if (this.IsEnabled() && this.LogLevel >= 2/*EventLevel.Error*/)
                {
                    if (args !== null)
                    {
                        this.WriteError$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteError$1(message);
                    }
                }
            }
            /*void */ WriteCritical$1(/*string*/ message)
            {
                if (this.IsEnabled() && this.LogLevel >= 1/*EventLevel.Critical*/)
                {
                    message = $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.PrepareMessage(1/*EventLevel.Critical*/, message, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    this.WriteEvent$17(5, message);
                }
            }
            /*void */ WriteCritical(/*string*/ message, /*params object[]*/ args)
            {
                if (this.IsEnabled() && this.LogLevel >= 1/*EventLevel.Critical*/)
                {
                    if (args !== null)
                    {
                        this.WriteCritical$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteCritical$1(message);
                    }
                }
            }
            /*void */ Write$7(/*EventLevel*/ level, /*Exception*/ innerException, /*string*/ message)
            {
                this.Write$6(level, innerException, message, null);
            }
            /*void */ Write$6(/*EventLevel*/ level, /*Exception*/ innerException, /*string*/ message, /*params object[]*/ args)
            {
                if (innerException !== null)
                {
                    if (!$.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII && !$.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsCustomException(innerException))
                    {
                        message = $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}", message, innerException.GetType$1());
                    }
                    else 
                    {
                        message = $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}", message, innerException.Message);
                    }
                }
                if (!$.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.HeaderWritten)
                {
                    this.WriteAlways$1($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource._versionLogMessage, $.$$.System.Version.ToString.call($.$$.System.Reflection.IntrospectionExtensions.GetTypeInfo($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.$type).Assembly.GetName().Version)));
                    this.WriteAlways$1($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource._dateLogMessage, $.$$.System.DateTime.UtcNow));
                    if ($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII)
                    {
                        this.WriteAlways$1($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource._piiOnLogMessage);
                    }
                    else 
                    {
                        this.WriteAlways$1($.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource._piiOffLogMessage);
                    }
                    $.$mil.Microsoft.IdentityModel.Logging.IdentityModelEventSource.HeaderWritten = true;
                }
                switch(level)
                {
                    case 0/*EventLevel.LogAlways*/:
                    this.WriteAlways(message, args);
                    break;
                    case 1/*EventLevel.Critical*/:
                    this.WriteCritical(message, args);
                    break;
                    case 2/*EventLevel.Error*/:
                    this.WriteError(message, args);
                    break;
                    case 3/*EventLevel.Warning*/:
                    this.WriteWarning(message, args);
                    break;
                    case 4/*EventLevel.Informational*/:
                    this.WriteInformation(message, args);
                    break;
                    case 5/*EventLevel.Verbose*/:
                    this.WriteVerbose(message, args);
                    break;
                    default:
                    this.WriteError$1($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("MIML10002: Unknown log level: {0}."/*LogMessages.MIML10002*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(level, $.$$.System.Diagnostics.Tracing.EventLevel) ], null, null)));
                    this.WriteError(message, args);
                    break;
                }
            }
            /*EventLevel*/ LogLevel = 0;
            static /*string */ PrepareMessage(/*EventLevel*/ level, /*string*/ message, /*params object[]*/ args)
            {
                if ($.$$.System.String.op_Equality(message, null))
                {
                    return $.$$.System.String.Empty;
                }
                try
                {
                    if (args !== null && args.length > 0)
                    {
                        return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.InvariantCulture, "[{0}]{1} {2}", $.$$.System.Enum.ToStringT($.$$.System.Diagnostics.Tracing.EventLevel, $.$$.System.UInt32, level), $.$$.System.DateTime.UtcNow.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant(message, args));
                    }
                    return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.InvariantCulture, "[{0}]{1} {2}", $.$$.System.Enum.ToStringT($.$$.System.Diagnostics.Tracing.EventLevel, $.$$.System.UInt32, level), $.$$.System.DateTime.UtcNow.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), message);
                }
                catch($e)
                {
                }
                try
                {
                    return $.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("[{0}]{1} {2}", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$$.System.Enum.ToStringT($.$$.System.Diagnostics.Tracing.EventLevel, $.$$.System.UInt32, level), $.$$.System.DateTime.UtcNow.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture), message ], null, null));
                }
                catch($e)
                {
                    return $.$$.System.Enum.ToString.call(level) + $.$$.System.DateTime.UtcNow.ToString$1($.$$.System.Globalization.CultureInfo.InvariantCulture) + message;
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.LogLevel = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ShowPII = false;
                }
                {
                    this.LogCompleteSecurityArtifact = false;
                }
                {
                    this.HiddenPIIString = "[PII of type '{0}' is hidden. For more details, see https://aka.ms/IdentityModel/PII.]";
                }
                {
                    this.HiddenSecurityArtifactString = "[Security Artifact of type '{0}' is hidden. For more details, see https://aka.ms/IdentityModel/SecurityArtifactLogging.]";
                }
                {
                    this.HeaderWritten = false;
                }
                {
                    this._versionLogMessage = "Library version: {0}.";
                }
                {
                    this._dateLogMessage = "Date: {0}.";
                }
                {
                    this._piiOffLogMessage = "PII (personally identifiable information) logging is currently turned off. Set IdentityModelEventSource.ShowPII to 'true' to view the full details of exceptions.";
                }
                {
                    this._piiOnLogMessage = "PII (personally identifiable information) logging is currently turned on. Set IdentityModelEventSource.ShowPII to 'false' to hide PII from log messages.";
                }
            }
            static $h = 109976;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"p":[{"p":109976,"g":{"r":0,"d":0,"h":21474946456,"f":50331681},"n":"Logger","d":109976,"h":17179979160,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":34359848344,"f":50331681},"s":{"r":0,"d":0,"h":38654815640,"f":83886113},"n":"ShowPII","d":109976,"h":30064881048,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":51539717528,"f":50331681},"s":{"r":0,"d":0,"h":55834684824,"f":83886113},"n":"LogCompleteSecurityArtifact","d":109976,"h":47244750232,"f":2097185},{"p":1310721,"g":{"r":0,"d":0,"h":68719586712,"f":50331681},"n":"HiddenPIIString","d":109976,"h":64424619416,"f":2097185},{"p":1310721,"g":{"r":0,"d":0,"h":81604488600,"f":50331681},"n":"HiddenSecurityArtifactString","d":109976,"h":77309521304,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":94489390488,"f":50331681},"s":{"r":0,"d":0,"h":98784357784,"f":83886113},"n":"HeaderWritten","d":109976,"h":90194423192,"f":2097185},{"p":40960001,"g":{"r":0,"d":0,"h":188978671000,"f":50331649},"s":{"r":0,"d":0,"h":193273638296,"f":83886081},"n":"LogLevel","d":109976,"h":184683703704,"f":2097153}],"m":[{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteAlways","o":"@$1","d":109976,"h":120259194264,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":6,"t":655361}],"n":[{"n":"Level","v":0,"t":40960001}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"WriteAlways","d":109976,"h":124554161560,"f":16777217,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteVerbose","o":"@$1","d":109976,"h":128849128856,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":1,"t":655361}],"n":[{"n":"Level","v":5,"t":40960001}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"WriteVerbose","d":109976,"h":133144096152,"f":16777217,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteInformation","o":"@$1","d":109976,"h":137439063448,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":2,"t":655361}],"n":[{"n":"Level","v":4,"t":40960001}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"WriteInformation","d":109976,"h":141734030744,"f":16777217,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteWarning","o":"@$1","d":109976,"h":146028998040,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":3,"t":655361}],"n":[{"n":"Level","v":3,"t":40960001}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"WriteWarning","d":109976,"h":150323965336,"f":16777217,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteError","o":"@$1","d":109976,"h":154618932632,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":4,"t":655361}],"n":[{"n":"Level","v":2,"t":40960001}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"WriteError","d":109976,"h":158913899928,"f":16777217,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteCritical","o":"@$1","d":109976,"h":163208867224,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":5,"t":655361}],"n":[{"n":"Level","v":1,"t":40960001}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"WriteCritical","d":109976,"h":167503834520,"f":16777217,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"level","p":40960001},{"n":"innerException","p":47251457},{"n":"message","p":1310721}],"n":"Write","o":"@$7","d":109976,"h":171798801816,"f":16777217,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"level","p":40960001},{"n":"innerException","p":47251457},{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"Write","o":"@$6","d":109976,"h":176093769112,"f":16777217,"a":[{"t":44302337,"c":4339269633}]},{"r":1310721,"p":[{"n":"level","p":40960001},{"n":"message","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"PrepareMessage","d":109976,"h":197568605592,"f":16777250}],"l":[{"t":1310721,"n":"_versionLogMessage","d":109976,"h":103079325080,"f":4194338},{"t":1310721,"n":"_dateLogMessage","d":109976,"h":107374292376,"f":4194338},{"t":1310721,"n":"_piiOffLogMessage","d":109976,"h":111669259672,"f":4194338},{"t":1310721,"n":"_piiOnLogMessage","d":109976,"h":115964226968,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$10","d":109976,"h":8590044568,"f":16777218}],"i":[57540609],"h":109976,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"Microsoft.IdentityModel.EventSource","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.IdentityModel.Logging.IdentityModelEventSource`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http"))