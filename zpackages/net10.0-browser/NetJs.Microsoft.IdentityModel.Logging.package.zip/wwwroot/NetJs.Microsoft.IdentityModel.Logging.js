
//--TRIMMABLE-BOUNDARY-START(125)
(async function () {
(function ($global, $, $$, $mia, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.Microsoft.IdentityModel.Logging", 
    {
  "h": 125,
  "f": "Microsoft.IdentityModel.Logging",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tokens, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.S2S.Tokens.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "Serviceable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 140836865,
      "c": 8730771457,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Protocols, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.IdentityModel.Logging.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsAotCompatible",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "Microsoft Corporation.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107347969,
      "c": 8697282561,
      "a": [
        {
          "v": "\u00A9 Microsoft Corporation. All rights reserved.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Includes Event Source based logging support.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "9.0.0.26315",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "Microsoft IdentityModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.IdentityModel.Logging",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196733)
        $asm.$cls(`$mil.MIL.ISafeLogSecurityArtifact`, ($self) => class ISafeLogSecurityArtifact
        {
            static $h = 196733;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295164029),
    {
      "r": 1310721,
      "n": "UnsafeToString",
      "o": "MIL$ISafeLogSecurityArtifact$UnsafeToString",
      "d": 196733,
      "h": 4295164029,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295164029)
  ],
  "h": 196733
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}ISafeLogSecurityArtifact`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196733)
        
        

        //--TRIMMABLE-BOUNDARY-START(262269)
        $asm.$cls(`$mil.MIL.LoggerContext`, ($self) => class LoggerContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770066045)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770066045);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770066045)
            
            //--TRIMMABLE-BOUNDARY-START(30065033341)
            $ctor$2(/*Guid*/ activityId)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065033341);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ActivityId = activityId;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065033341)
            
            //--TRIMMABLE-BOUNDARY-START(34360000637)
            /*Guid*/ ActivityId;
            //--TRIMMABLE-BOUNDARY-END(34360000637)
            
            //--TRIMMABLE-BOUNDARY-START(38654967933)
            /*bool*/ CaptureLogs = false;
            //--TRIMMABLE-BOUNDARY-END(38654967933)
            
            //--TRIMMABLE-BOUNDARY-START(42949935229)
            /*string*/ $DebugId = null;
            /*string */ get DebugId()
            {
                return this.$DebugId;
            }
            /*string */ set DebugId(value)
            {
                this.$DebugId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42949935229)
            
            //--TRIMMABLE-BOUNDARY-START(90194575485)
            /*ICollection<string>*/ Logs = null;
            //--TRIMMABLE-BOUNDARY-END(90194575485)
            
            //--TRIMMABLE-BOUNDARY-START(94489542781)
            /*IDictionary<string, object>*/ PropertyBag = null;
            //--TRIMMABLE-BOUNDARY-END(94489542781)
            
            //--TRIMMABLE-BOUNDARY-START(25770066045)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770066045)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360000637)
                this.ActivityId = $.$$.S.Guid.Empty;
                //--TRIMMABLE-BOUNDARY-END(34360000637)
                
                //--TRIMMABLE-BOUNDARY-START(42949935229)
                this.$DebugId = $.$$.S.String.Empty;
                //--TRIMMABLE-BOUNDARY-END(42949935229)
                
                //--TRIMMABLE-BOUNDARY-START(90194575485)
                this.Logs = new ($.$$.SCO.Collection$$($.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(90194575485)
                
            }
            static $h = 262269;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360000637),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539869821,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079477373,
        "f": 83886081
      },
      "n": "ActivityId",
      "d": 262269,
      "h": 34360000637,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000637),
//--TRIMMABLE-BOUNDARY-START(38654967933),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129804413,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669411965,
        "f": 83886081
      },
      "n": "CaptureLogs",
      "d": 262269,
      "h": 38654967933,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654967933),
//--TRIMMABLE-BOUNDARY-START(42949935229),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719739005,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259346557,
        "f": 83886209
      },
      "n": "DebugId",
      "d": 262269,
      "h": 42949935229,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(42949935229),
//--TRIMMABLE-BOUNDARY-START(90194575485),
    {
      "p": $.$$.SCG.ICollection$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309673597,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849281149,
        "f": 83886082
      },
      "n": "Logs",
      "d": 262269,
      "h": 90194575485,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194575485),
//--TRIMMABLE-BOUNDARY-START(94489542781),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899608189,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439215741,
        "f": 83886081
      },
      "n": "PropertyBag",
      "d": 262269,
      "h": 94489542781,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489542781)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770066045),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262269,
      "h": 25770066045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770066045),
//--TRIMMABLE-BOUNDARY-START(30065033341),
    {
      "p": [
        {
          "n": "activityId",
          "p": 89784321
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262269,
      "h": 30065033341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033341)
  ],
  "h": 262269
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.LoggerContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}LoggerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262269)
        
        

        //--TRIMMABLE-BOUNDARY-START(131197)
        $asm.$cls(`$mil.MIL.IdentityModelTelemetryUtil`, ($self) => class IdentityModelTelemetryUtil
        {
            //--TRIMMABLE-BOUNDARY-START(51539738749)
            /*string*/ static skuTelemetry = null;
            //--TRIMMABLE-BOUNDARY-END(51539738749)
            
            //--TRIMMABLE-BOUNDARY-START(64424640637)
            /*string*/ static versionTelemetry = null;
            //--TRIMMABLE-BOUNDARY-END(64424640637)
            
            //--TRIMMABLE-BOUNDARY-START(21474967677)
            /*List<string>*/ static defaultTelemetryValues = null;
            //--TRIMMABLE-BOUNDARY-END(21474967677)
            
            //--TRIMMABLE-BOUNDARY-START(55834706045)
            /*ConcurrentDictionary<string, string>*/ static telemetryData = null;
            //--TRIMMABLE-BOUNDARY-END(55834706045)
            
            //--TRIMMABLE-BOUNDARY-START(12885033085)
            static /*string */ get ClientSku()
            {
                return "ID_NET10_0";
            }
            //--TRIMMABLE-BOUNDARY-END(12885033085)
            
            //--TRIMMABLE-BOUNDARY-START(17180000381)
            static /*string */ get ClientVer()
            {
                return $.$$.SR.IntrospectionExtensions.GetTypeInfo($.$mil.MIL.IdentityModelTelemetryUtil.$type).Assembly.GetName().Version.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(17180000381)
            
            //--TRIMMABLE-BOUNDARY-START(8590065789)
            static /*bool */ AddTelemetryData(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    $.$mil.MIL.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$$.S.String.IsNullOrEmpty(value))
                {
                    $.$mil.MIL.LogHelper.LogArgumentNullException("value");
                    return false;
                }
                if ($.$mil.MIL.IdentityModelTelemetryUtil.defaultTelemetryValues.Contains(key))
                {
                    $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14("MIML10003: Sku and version telemetry cannot be manipulated. They are added by default."/*LogMessages.MIML10003*/));
                    return false;
                }
                $.$mil.MIL.IdentityModelTelemetryUtil.telemetryData.set_Item$1(key, value);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065789)
            
            //--TRIMMABLE-BOUNDARY-START(42949804157)
            static /*bool */ RemoveTelemetryData(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    $.$mil.MIL.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$mil.MIL.IdentityModelTelemetryUtil.defaultTelemetryValues.Contains(key))
                {
                    $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14("MIML10003: Sku and version telemetry cannot be manipulated. They are added by default."/*LogMessages.MIML10003*/));
                    return false;
                }
                return $.$mil.MIL.IdentityModelTelemetryUtil.telemetryData.TryRemove$1(key, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(42949804157)
            
            //--TRIMMABLE-BOUNDARY-START(47244771453)
            static /*void */ SetTelemetryData(/*HttpRequestMessage*/ request, /*IDictionary<string, string>*/ additionalHeaders)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (request === null)
                {
                    return;
                }
                let $en1 = $.$mil.MIL.IdentityModelTelemetryUtil.telemetryData.GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let parameter = $en1.SCG$IEnumerator$$$Current;
                    {
                        request.Headers.Remove$1(parameter.Key);
                        request.Headers.Add$3(parameter.Key, parameter.Value);
                    }
                }
                if (additionalHeaders !== null)
                {
                    let $en2 = additionalHeaders.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let header = $en2.SCG$IEnumerator$$$Current;
                        {
                            request.Headers.Add$3(header.Key, header.Value);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244771453)
            
            //--TRIMMABLE-BOUNDARY-START(60129673341)
            static /*bool */ UpdateDefaultTelemetryData(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    $.$mil.MIL.LogHelper.LogArgumentNullException("key");
                    return false;
                }
                if ($.$$.S.String.IsNullOrEmpty(value))
                {
                    $.$mil.MIL.LogHelper.LogArgumentNullException("value");
                    return false;
                }
                $.$mil.MIL.IdentityModelTelemetryUtil.telemetryData.set_Item$1(key, value);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673341)
            
            //--TRIMMABLE-BOUNDARY-START(4295098493)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(51539738749)
                    this.skuTelemetry = "x-client-SKU";
                    //--TRIMMABLE-BOUNDARY-END(51539738749)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424640637)
                    this.versionTelemetry = "x-client-Ver";
                    //--TRIMMABLE-BOUNDARY-END(64424640637)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967677)
                    this.defaultTelemetryValues = (() =>
                    {
                        //new $.$$.SCG.List$$($.$$.S.String)()
                        const $t3 = $.$$.SCG.List$$($.$$.S.String);
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        $i3.Add("x-client-SKU"/*skuTelemetry*/);
                        $i3.Add("x-client-Ver"/*versionTelemetry*/);
                        return $i3;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(21474967677)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834706045)
                    this.telemetryData = (() =>
                    {
                        //new $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.String)()
                        const $t4 = $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.String);
                        const $i4 = new $t4();
                        $i4.$ctor$1();
                        $i4.set_Item$1("x-client-SKU"/*skuTelemetry*/, $.$mil.MIL.IdentityModelTelemetryUtil.ClientSku);
                        $i4.set_Item$1("x-client-Ver"/*versionTelemetry*/, $.$mil.MIL.IdentityModelTelemetryUtil.ClientVer);
                        return $i4;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(55834706045)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098493)
            
            static $h = 131197;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885033085),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902269,
        "f": 50331681
      },
      "n": "ClientSku",
      "d": 131197,
      "h": 12885033085,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885033085),
//--TRIMMABLE-BOUNDARY-START(17180000381),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836861,
        "f": 50331681
      },
      "n": "ClientVer",
      "d": 131197,
      "h": 17180000381,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180000381)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590065789),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddTelemetryData",
      "d": 131197,
      "h": 8590065789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065789),
//--TRIMMABLE-BOUNDARY-START(42949804157),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "RemoveTelemetryData",
      "d": 131197,
      "h": 42949804157,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949804157),
//--TRIMMABLE-BOUNDARY-START(47244771453),
    {
      "r": 65537,
      "p": [
        {
          "n": "request",
          "p": 7602229
        },
        {
          "n": "additionalHeaders",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        }
      ],
      "n": "SetTelemetryData",
      "d": 131197,
      "h": 47244771453,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47244771453),
//--TRIMMABLE-BOUNDARY-START(60129673341),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "UpdateDefaultTelemetryData",
      "d": 131197,
      "h": 60129673341,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(60129673341)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539738749),
    {
      "t": 1310721,
      "n": "skuTelemetry",
      "d": 131197,
      "h": 51539738749,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539738749),
//--TRIMMABLE-BOUNDARY-START(64424640637),
    {
      "t": 1310721,
      "n": "versionTelemetry",
      "d": 131197,
      "h": 64424640637,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424640637),
//--TRIMMABLE-BOUNDARY-START(21474967677),
    {
      "t": $.$$.SCG.List$$($.$$.S.String).$h,
      "n": "defaultTelemetryValues",
      "d": 131197,
      "h": 21474967677,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474967677),
//--TRIMMABLE-BOUNDARY-START(55834706045),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "telemetryData",
      "d": 131197,
      "h": 55834706045,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834706045)
  ],
  "h": 131197
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.IdentityModelTelemetryUtil`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}IdentityModelTelemetryUtil`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131197)
        
        

        //--TRIMMABLE-BOUNDARY-START(393341)
        $asm.$cls(`$mil.MIL.LogMessages`, ($self) => class LogMessages
        {
            //--TRIMMABLE-BOUNDARY-START(4295360637)
            /*string*/ static MIML10000 = null;
            //--TRIMMABLE-BOUNDARY-END(4295360637)
            
            //--TRIMMABLE-BOUNDARY-START(8590327933)
            /*string*/ static MIML10001 = null;
            //--TRIMMABLE-BOUNDARY-END(8590327933)
            
            //--TRIMMABLE-BOUNDARY-START(12885295229)
            /*string*/ static MIML10002 = null;
            //--TRIMMABLE-BOUNDARY-END(12885295229)
            
            //--TRIMMABLE-BOUNDARY-START(17180262525)
            /*string*/ static MIML10003 = null;
            //--TRIMMABLE-BOUNDARY-END(17180262525)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295360637)
                    this.MIML10000 = "MIML10000: eventData.Payload is null or empty. Not logging any messages.";
                    //--TRIMMABLE-BOUNDARY-END(4295360637)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590327933)
                    this.MIML10001 = "MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception.";
                    //--TRIMMABLE-BOUNDARY-END(8590327933)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295229)
                    this.MIML10002 = "MIML10002: Unknown log level: {0}.";
                    //--TRIMMABLE-BOUNDARY-END(12885295229)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180262525)
                    this.MIML10003 = "MIML10003: Sku and version telemetry cannot be manipulated. They are added by default.";
                    //--TRIMMABLE-BOUNDARY-END(17180262525)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 393341;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360637),
    {
      "t": 1310721,
      "n": "MIML10000",
      "d": 393341,
      "h": 4295360637,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295360637),
//--TRIMMABLE-BOUNDARY-START(8590327933),
    {
      "t": 1310721,
      "n": "MIML10001",
      "d": 393341,
      "h": 8590327933,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590327933),
//--TRIMMABLE-BOUNDARY-START(12885295229),
    {
      "t": 1310721,
      "n": "MIML10002",
      "d": 393341,
      "h": 12885295229,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885295229),
//--TRIMMABLE-BOUNDARY-START(17180262525),
    {
      "t": 1310721,
      "n": "MIML10003",
      "d": 393341,
      "h": 17180262525,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180262525)
  ],
  "h": 393341
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.LogMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}LogMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393341)
        
        

        //--TRIMMABLE-BOUNDARY-START(327805)
        $asm.$cls(`$mil.MIL.LogHelper`, ($self) => class LogHelper extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(158914117757)
            /*IIdentityLogger*/ static Logger = null;
            //--TRIMMABLE-BOUNDARY-END(158914117757)
            
            //--TRIMMABLE-BOUNDARY-START(4295295101)
            /*bool*/ static _isHeaderWritten = false;
            //--TRIMMABLE-BOUNDARY-END(4295295101)
            
            //--TRIMMABLE-BOUNDARY-START(197568823421)
            /*SearchValues<char>*/ static s_charsToSanitize = null;
            //--TRIMMABLE-BOUNDARY-END(197568823421)
            
            //--TRIMMABLE-BOUNDARY-START(8590262397)
            /*string*/ static _piiOffLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590262397)
            
            //--TRIMMABLE-BOUNDARY-START(12885229693)
            /*string*/ static _piiOnLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(12885229693)
            
            //--TRIMMABLE-BOUNDARY-START(60129869949)
            static /*bool */ get HeaderWritten()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244968061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper._isHeaderWritten;
            }
            static /*bool */ set HeaderWritten(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748692605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mil.MIL.LogHelper._isHeaderWritten = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60129869949)
            
            //--TRIMMABLE-BOUNDARY-START(68719804541)
            static /*bool */ IsEnabled(/*EventLogLevel*/ level)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719804541);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$IsEnabled(level) || $.$mil.MIL.IdentityModelEventSource.Logger.IsEnabled$2($.$mil.MIL.LogHelper.EventLogLevelToEventLevel(level), -1n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719804541)
            
            //--TRIMMABLE-BOUNDARY-START(107374510205)
            static /*ArgumentNullException */ LogArgumentNullException(/*string*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogArgumentException$2($.$$.S.ArgumentNullException, 2/*EventLevel.Error*/, argument, "IDX10000: The parameter '{0}' cannot be a 'null' or an empty object. ", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ argument ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(107374510205)
            
            //--TRIMMABLE-BOUNDARY-START(141734248573)
            static /*T */ LogException$7(T, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogException(T, 2/*EventLevel.Error*/, null, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(141734248573)
            
            //--TRIMMABLE-BOUNDARY-START(103079542909)
            static /*T */ LogArgumentException$7(T, /*string*/ argumentName, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, null, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(103079542909)
            
            //--TRIMMABLE-BOUNDARY-START(137439281277)
            static /*T */ LogException$6(T, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439281277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogException(T, 2/*EventLevel.Error*/, null, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(137439281277)
            
            //--TRIMMABLE-BOUNDARY-START(98784575613)
            static /*T */ LogArgumentException$6(T, /*string*/ argumentName, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, null, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(98784575613)
            
            //--TRIMMABLE-BOUNDARY-START(133144313981)
            static /*T */ LogException$5(T, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144313981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogException(T, 2/*EventLevel.Error*/, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(133144313981)
            
            //--TRIMMABLE-BOUNDARY-START(94489608317)
            static /*T */ LogArgumentException$5(T, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(94489608317)
            
            //--TRIMMABLE-BOUNDARY-START(128849346685)
            static /*T */ LogException$4(T, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849346685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogException(T, 2/*EventLevel.Error*/, innerException, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(128849346685)
            
            //--TRIMMABLE-BOUNDARY-START(90194641021)
            static /*T */ LogArgumentException$4(T, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194641021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogArgumentException(T, 2/*EventLevel.Error*/, argumentName, innerException, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(90194641021)
            
            //--TRIMMABLE-BOUNDARY-START(124554379389)
            static /*T */ LogException$3(T, /*EventLevel*/ eventLevel, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogException(T, eventLevel, null, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(124554379389)
            
            //--TRIMMABLE-BOUNDARY-START(85899673725)
            static /*T */ LogArgumentException$3(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogArgumentException(T, eventLevel, argumentName, null, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(85899673725)
            
            //--TRIMMABLE-BOUNDARY-START(120259412093)
            static /*T */ LogException$2(T, /*EventLevel*/ eventLevel, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogException(T, eventLevel, null, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(120259412093)
            
            //--TRIMMABLE-BOUNDARY-START(81604706429)
            static /*T */ LogArgumentException$2(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogArgumentException(T, eventLevel, argumentName, null, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(81604706429)
            
            //--TRIMMABLE-BOUNDARY-START(115964444797)
            static /*T */ LogException$1(T, /*EventLevel*/ eventLevel, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogException(T, eventLevel, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(115964444797)
            
            //--TRIMMABLE-BOUNDARY-START(77309739133)
            static /*T */ LogArgumentException$1(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogArgumentException(T, eventLevel, argumentName, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(77309739133)
            
            //--TRIMMABLE-BOUNDARY-START(111669477501)
            static /*T */ LogException(T, /*EventLevel*/ eventLevel, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogExceptionImpl(T, eventLevel, null, innerException, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(111669477501)
            
            //--TRIMMABLE-BOUNDARY-START(73014771837)
            static /*T */ LogArgumentException(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogExceptionImpl(T, eventLevel, argumentName, innerException, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(73014771837)
            
            //--TRIMMABLE-BOUNDARY-START(154619150461)
            static /*Exception */ LogExceptionMessage$1(/*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619150461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mil.MIL.LogHelper.LogExceptionMessage(2/*EventLevel.Error*/, exception);
            }
            //--TRIMMABLE-BOUNDARY-END(154619150461)
            
            //--TRIMMABLE-BOUNDARY-START(150324183165)
            static /*Exception */ LogExceptionMessage(/*EventLevel*/ eventLevel, /*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (exception === null)
                {
                    return null;
                }
                if ($.$mil.MIL.IdentityModelEventSource.Logger.IsEnabled$2(eventLevel, -1n))
                {
                    $.$mil.MIL.IdentityModelEventSource.Logger.Write$7(eventLevel, exception.InnerException, exception.Message);
                }
                /*EventLogLevel*/ let eventLogLevel = $.$mil.MIL.LogHelper.EventLevelToEventLogLevel(eventLevel);
                if ($.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$IsEnabled(eventLogLevel))
                {
                    $.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$Log($.$mil.MIL.LogHelper.WriteEntry(eventLogLevel, exception.InnerException, exception.Message, null));
                }
                return exception;
            }
            //--TRIMMABLE-BOUNDARY-END(150324183165)
            
            //--TRIMMABLE-BOUNDARY-START(163209085053)
            static /*void */ LogInformation(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209085053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mil.MIL.IdentityModelEventSource.Logger.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    $.$mil.MIL.IdentityModelEventSource.Logger.WriteInformation(message, args);
                }
                if ($.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$Log($.$mil.MIL.LogHelper.WriteEntry(4/*EventLogLevel.Informational*/, null, message, args));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209085053)
            
            //--TRIMMABLE-BOUNDARY-START(167504052349)
            static /*void */ LogVerbose(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mil.MIL.IdentityModelEventSource.Logger.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    $.$mil.MIL.IdentityModelEventSource.Logger.WriteVerbose(message, args);
                }
                if ($.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$Log($.$mil.MIL.LogHelper.WriteEntry(5/*EventLogLevel.Verbose*/, null, message, args));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504052349)
            
            //--TRIMMABLE-BOUNDARY-START(171799019645)
            static /*void */ LogWarning(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mil.MIL.IdentityModelEventSource.Logger.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    $.$mil.MIL.IdentityModelEventSource.Logger.WriteWarning(message, args);
                }
                if ($.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$IsEnabled(3/*EventLogLevel.Warning*/))
                {
                    $.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$Log($.$mil.MIL.LogHelper.WriteEntry(3/*EventLogLevel.Warning*/, null, message, args));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799019645)
            
            //--TRIMMABLE-BOUNDARY-START(146029215869)
            static /*T */ LogExceptionImpl(T, /*EventLevel*/ eventLevel, /*string*/ argumentName, /*Exception*/ innerException, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let message;
                if (args !== null)
                {
                    message = $.$$.S.String.Format$5($.$$.SG.CultureInfo.InvariantCulture, format, args);
                }
                else 
                {
                    message = format;
                }
                if ($.$mil.MIL.IdentityModelEventSource.Logger.IsEnabled$2(eventLevel, -1n))
                {
                    $.$mil.MIL.IdentityModelEventSource.Logger.Write$7(eventLevel, innerException, message);
                }
                /*EventLogLevel*/ let eventLogLevel = $.$mil.MIL.LogHelper.EventLevelToEventLogLevel(eventLevel);
                if ($.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$IsEnabled(eventLogLevel))
                {
                    $.$mil.MIL.LogHelper.Logger.MIA$IIdentityLogger$Log($.$mil.MIL.LogHelper.WriteEntry(eventLogLevel, innerException, message, null));
                }
                if (innerException !== null)
                {
                    if ($.$$.S.String.IsNullOrEmpty(argumentName))
                    {
                        return $.$cast($.$$.S.Activator.CreateInstance$6(T.$type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ message, innerException ], null, null)), T);
                    }
                    else 
                    {
                        return $.$cast($.$$.S.Activator.CreateInstance$6(T.$type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ argumentName, message, innerException ], null, null)), T);
                    }
                }
                else 
                {
                    if ($.$$.S.String.IsNullOrEmpty(argumentName))
                    {
                        return $.$cast($.$$.S.Activator.CreateInstance$6(T.$type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ message ], null, null)), T);
                    }
                    else 
                    {
                        return $.$cast($.$$.S.Activator.CreateInstance$6(T.$type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ argumentName, message ], null, null)), T);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029215869)
            
            //--TRIMMABLE-BOUNDARY-START(30065098877)
            static /*EventLogLevel */ EventLevelToEventLogLevel(/*EventLevel*/ eventLevel)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098877);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (eventLevel >>> 0) <= 5 ? $.$cast(eventLevel, $.$mia.MIA.EventLogLevel) : 2/*EventLogLevel.Error*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065098877)
            
            //--TRIMMABLE-BOUNDARY-START(34360066173)
            static /*EventLevel */ EventLogLevelToEventLevel(/*EventLogLevel*/ eventLevel)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360066173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (eventLevel >>> 0) <= 5 ? $.$cast(eventLevel, $.$$.SDT.EventLevel) : 2/*EventLevel.Error*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360066173)
            
            //--TRIMMABLE-BOUNDARY-START(38655033469)
            static /*string */ FormatInvariant(/*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (format === null)
                {
                    return $.$$.S.String.Empty;
                }
                if (args === null)
                {
                    return format;
                }
                if (!$.$mil.MIL.IdentityModelEventSource.ShowPII)
                {
                    return $.$$.S.String.Format$6($.$$.SG.CultureInfo.InvariantCulture, format, $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1($.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$$.S.Object, $.$$.S.String, args, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mil.MIL.LogHelper, $.$mil.MIL.LogHelper.RemovePII)))));
                }
                else 
                {
                    return $.$$.S.String.Format$5($.$$.SG.CultureInfo.InvariantCulture, format, $.$sl.SL.Enumerable.ToArray($.$$.S.Object, $.$sl.SL.Enumerable.Select$1($.$$.S.Object, $.$$.S.Object, args, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Object))().$ctor($.$mil.MIL.LogHelper, $.$mil.MIL.LogHelper.SanitizeSecurityArtifact))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655033469)
            
            //--TRIMMABLE-BOUNDARY-START(206158758013)
            static /*object */ SanitizeSecurityArtifact(/*object*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158758013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (arg === null)
                {
                    return "null";
                }
                if ($.$mil.MIL.IdentityModelEventSource.LogCompleteSecurityArtifact && $.$is(arg, $.$mil.MIL.ISafeLogSecurityArtifact))
                {
                    return ($.$as(arg, $.$mil.MIL.ISafeLogSecurityArtifact)).MIL$ISafeLogSecurityArtifact$UnsafeToString();
                }
                else if ($.$is(arg, $.$mil.MIL.ISafeLogSecurityArtifact))
                {
                    /*object*/ let __ca1__;
                    return $.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, $.$mil.MIL.IdentityModelEventSource.HiddenSecurityArtifactString, ((__ca1__ = arg) !== null ? ($.$$.S.Object.GetType.call(__ca1__).ToString() ?? "Null") : "Null"));
                }
                return $.$mil.MIL.LogHelper.Sanitize($.$dsp(arg, $.$$.S.Object, ($t) => $t.ToString));
            }
            //--TRIMMABLE-BOUNDARY-END(206158758013)
            
            //--TRIMMABLE-BOUNDARY-START(193273856125)
            static /*string */ RemovePII(/*object*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273856125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let ex;
                if ($.$is(arg, $.$$.S.Exception, { set $v($v){ ex = $v; } }) && $.$mil.MIL.LogHelper.IsCustomException(ex))
                {
                    return ex.ToString();
                }
                if ($.$is(arg, $.$mil.MIL.NonPII))
                {
                    return $.$mil.MIL.LogHelper.Sanitize($.$dsp(arg, $.$$.S.Object, ($t) => $t.ToString));
                }
                /*object*/ let __ca2__;
                return $.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, $.$mil.MIL.IdentityModelEventSource.HiddenPIIString, ((__ca2__ = arg) !== null ? ($.$$.S.Object.GetType.call(__ca2__).ToString() ?? "Null") : "Null"));
            }
            //--TRIMMABLE-BOUNDARY-END(193273856125)
            
            //--TRIMMABLE-BOUNDARY-START(64424837245)
            static /*bool */ IsCustomException(/*Exception*/ ex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.StartsWith$2.call(ex.GetType$1().FullName, "Microsoft.IdentityModel.", 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(64424837245)
            
            //--TRIMMABLE-BOUNDARY-START(176093986941)
            static /*object */ MarkAsNonPII(/*object*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093986941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mil.MIL.NonPII().$ctor$3(arg);
            }
            //--TRIMMABLE-BOUNDARY-END(176093986941)
            
            //--TRIMMABLE-BOUNDARY-START(184683921533)
            static /*object */ MarkAsSecurityArtifact$1(/*object*/ arg, /*Func<object, string>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683921533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mil.MIL.SecurityArtifact().$ctor$4(arg, callback);
            }
            //--TRIMMABLE-BOUNDARY-END(184683921533)
            
            //--TRIMMABLE-BOUNDARY-START(180388954237)
            static /*object */ MarkAsSecurityArtifact(/*object*/ arg, /*Func<object, string>*/ callback, /*Func<object, string>*/ callbackUnsafe)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388954237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mil.MIL.SecurityArtifact().$ctor$3(arg, callback, callbackUnsafe);
            }
            //--TRIMMABLE-BOUNDARY-END(180388954237)
            
            //--TRIMMABLE-BOUNDARY-START(188978888829)
            static /*object */ MarkAsUnsafeSecurityArtifact(/*object*/ arg, /*Func<object, string>*/ callbackUnsafe)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978888829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mil.MIL.SecurityArtifact().$ctor$3(arg, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mil.MIL.SecurityArtifact, $.$mil.MIL.SecurityArtifact.UnknownSafeTokenCallback), callbackUnsafe);
            }
            //--TRIMMABLE-BOUNDARY-END(188978888829)
            
            //--TRIMMABLE-BOUNDARY-START(227633594493)
            static /*LogEntry */ WriteEntry(/*EventLogLevel*/ eventLogLevel, /*Exception*/ innerException, /*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633594493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(message))
                {
                    return null;
                }
                if (innerException !== null)
                {
                    if (!$.$mil.MIL.IdentityModelEventSource.ShowPII && !$.$mil.MIL.LogHelper.IsCustomException(innerException))
                    {
                        message = $.$$.S.String.Format$3($.$$.SG.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}. ", message, innerException.GetType$1());
                    }
                    else 
                    {
                        message = $.$$.S.String.Format$3($.$$.SG.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}. ", message, innerException.Message);
                    }
                }
                message = args === null ? message : $.$mil.MIL.LogHelper.FormatInvariant(message, args);
                /*LogEntry*/ let entry = new $.$mia.MIA.LogEntry().$ctor$1();
                entry.EventLogLevel = eventLogLevel;
                if (!$.$mil.MIL.LogHelper._isHeaderWritten)
                {
                    /*string*/ let headerMessage = $.$$.S.String.Format$2($.$$.SG.CultureInfo.InvariantCulture, "Microsoft.IdentityModel Version: {0}. Date {1}. {2}", $.$mil.MIL.IdentityModelEventSource.$type.Assembly.GetName().Version.ToString(), $.$$.S.DateTime.UtcNow, $.$mil.MIL.IdentityModelEventSource.ShowPII ? $.$mil.MIL.LogHelper._piiOnLogMessage : $.$mil.MIL.LogHelper._piiOffLogMessage);
                    entry.Message = $.$strNN($.$strNN(headerMessage) + $.$strNN($.$$.S.Environment.NewLine)) + $.$strNN(message);
                    $.$mil.MIL.LogHelper._isHeaderWritten = true;
                }
                else 
                {
                    entry.Message = message;
                }
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(227633594493)
            
            //--TRIMMABLE-BOUNDARY-START(201863790717)
            static /*string */ Sanitize(/*string*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863790717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(input))
                {
                    return input;
                }
                /*int*/ let index = $.$$.S.MemoryExtensions.IndexOfAny$2($.$$.S.Char, $.$$.S.MemoryExtensions.AsSpan$4(input), $.$mil.MIL.LogHelper.s_charsToSanitize);
                if (index < 0)
                {
                    return input;
                }
                /*var*/ let sanitized = new $.$$.ST.StringBuilder().$ctor$4(input.length);
                /*int*/ let lastIndex = 0;
                while(index >= 0)
                {
                    sanitized.Append$17($.$$.S.MemoryExtensions.AsSpan$1(input, lastIndex, ((index - lastIndex) | 0)));
                    /*char*/ let c = $.$$.S.String.get_Chars.call(input, index);
                    if (c === /*\r*/ 13)
                    {
                        sanitized.Append$21("\\r");
                    }
                    else if (c === /*\n*/ 10)
                    {
                        sanitized.Append$21("\\n");
                    }
                    else if (c === /*\t*/ 9)
                    {
                        sanitized.Append$21("\\t");
                    }
                    else 
                    {
                        sanitized.Append$1((() =>
                        {
                            var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                            $handler.AppendLiteral("\\u");
                            $handler.AppendFormatted($.$box($.$cast(c, $.$$.S.Int32), $.$$.S.Int32), null, "X4");
                            return $handler.ToStringAndClear                    ();
                        })());
                    }
                    lastIndex = ((index + 1) | 0);
                    if (lastIndex < input.length)
                    {
                        index = $.$$.S.MemoryExtensions.IndexOfAny$2($.$$.S.Char, $.$$.S.MemoryExtensions.AsSpan$2(input, lastIndex), $.$mil.MIL.LogHelper.s_charsToSanitize);
                    }
                    else 
                    {
                        index = -1;
                    }
                    if (index >= 0)
                    {
                        index += lastIndex;
                    }
                }
                if (lastIndex < input.length)
                {
                    sanitized.Append$17($.$$.S.MemoryExtensions.AsSpan$2(input, lastIndex));
                }
                return sanitized.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(201863790717)
            
            //--TRIMMABLE-BOUNDARY-START(25770131581)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131581)
            
            //--TRIMMABLE-BOUNDARY-START(25770131581)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770131581)
            
            //--TRIMMABLE-BOUNDARY-START(21475164285)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(158914117757)
                    this.Logger = $.$mia.MIA.NullIdentityModelLogger.Instance;
                    //--TRIMMABLE-BOUNDARY-END(158914117757)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568823421)
                    this.s_charsToSanitize = $.$$.SB.SearchValues.Create$1($.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*\u0000*/ 0, /*\u0001*/ 1, /*\u0002*/ 2, /*\u0003*/ 3, /*\u0004*/ 4, /*\u0005*/ 5, /*\u0006*/ 6, /*\u0007*/ 7, /*\u0008*/ 8, /*\t*/ 9, /*\n*/ 10, /*\u000B*/ 11, /*\u000C*/ 12, /*\r*/ 13, /*\u000E*/ 14, /*\u000F*/ 15, /*\u0010*/ 16, /*\u0011*/ 17, /*\u0012*/ 18, /*\u0013*/ 19, /*\u0014*/ 20, /*\u0015*/ 21, /*\u0016*/ 22, /*\u0017*/ 23, /*\u0018*/ 24, /*\u0019*/ 25, /*\u001A*/ 26, /*\u001B*/ 27, /*\u001C*/ 28, /*\u001D*/ 29, /*\u001E*/ 30, /*\u001F*/ 31, /*\u007F*/ 127, /*\u0080*/ 128, /*\u0081*/ 129, /*\u0082*/ 130, /*\u0083*/ 131, /*\u0084*/ 132, /*\u0085*/ 133, /*\u0086*/ 134, /*\u0087*/ 135, /*\u0088*/ 136, /*\u0089*/ 137, /*\u008A*/ 138, /*\u008B*/ 139, /*\u008C*/ 140, /*\u008D*/ 141, /*\u008E*/ 142, /*\u008F*/ 143, /*\u0090*/ 144, /*\u0091*/ 145, /*\u0092*/ 146, /*\u0093*/ 147, /*\u0094*/ 148, /*\u0095*/ 149, /*\u0096*/ 150, /*\u0097*/ 151, /*\u0098*/ 152, /*\u0099*/ 153, /*\u009A*/ 154, /*\u009B*/ 155, /*\u009C*/ 156, /*\u009D*/ 157, /*\u009E*/ 158, /*\u009F*/ 159, /*\u00AD*/ 173, /*\u0600*/ 1536, /*\u0601*/ 1537, /*\u0602*/ 1538, /*\u0603*/ 1539, /*\u0604*/ 1540, /*\u0605*/ 1541, /*\u061C*/ 1564, /*\u06DD*/ 1757, /*\u070F*/ 1807, /*\u0890*/ 2192, /*\u0891*/ 2193, /*\u08E2*/ 2274, /*\u180E*/ 6158, /*\u200B*/ 8203, /*\u200C*/ 8204, /*\u200D*/ 8205, /*\u200E*/ 8206, /*\u200F*/ 8207, /*\u202A*/ 8234, /*\u202B*/ 8235, /*\u202C*/ 8236, /*\u202D*/ 8237, /*\u202E*/ 8238, /*\u2060*/ 8288, /*\u2061*/ 8289, /*\u2062*/ 8290, /*\u2063*/ 8291, /*\u2064*/ 8292, /*\u2066*/ 8294, /*\u2067*/ 8295, /*\u2068*/ 8296, /*\u2069*/ 8297, /*\u206A*/ 8298, /*\u206B*/ 8299, /*\u206C*/ 8300, /*\u206D*/ 8301, /*\u206E*/ 8302, /*\u206F*/ 8303, /*\uFEFF*/ 65279, /*\uFFF9*/ 65529, /*\uFFFA*/ 65530, /*\uFFFB*/ 65531], [-1], null)));
                    //--TRIMMABLE-BOUNDARY-END(197568823421)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590262397)
                    this._piiOffLogMessage = "PII logging is OFF. See https://aka.ms/IdentityModel/PII for details. ";
                    //--TRIMMABLE-BOUNDARY-END(8590262397)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229693)
                    this._piiOnLogMessage = "PII logging is ON, do not use in production. See https://aka.ms/IdentityModel/PII for details. ";
                    //--TRIMMABLE-BOUNDARY-END(12885229693)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475164285)
            
            static $h = 327805;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914117757),
    {
      "p": 131196,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902653,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338627197,
        "f": 83886113
      },
      "n": "Logger",
      "d": 327805,
      "h": 158914117757,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(158914117757),
//--TRIMMABLE-BOUNDARY-START(60129869949),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244968061,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748692605,
        "f": 83886120
      },
      "n": "HeaderWritten",
      "d": 327805,
      "h": 60129869949,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60129869949)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719804541),
    {
      "r": 262145,
      "p": [
        {
          "n": "level",
          "p": 65660
        }
      ],
      "n": "IsEnabled",
      "d": 327805,
      "h": 68719804541,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719804541),
//--TRIMMABLE-BOUNDARY-START(107374510205),
    {
      "r": 45023233,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        }
      ],
      "n": "LogArgumentNullException",
      "d": 327805,
      "h": 107374510205,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107374510205),
//--TRIMMABLE-BOUNDARY-START(141734248573),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$7",
      "d": 327805,
      "h": 141734248573,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(141734248573),
//--TRIMMABLE-BOUNDARY-START(103079542909),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$7",
      "d": 327805,
      "h": 103079542909,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103079542909),
//--TRIMMABLE-BOUNDARY-START(137439281277),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$6",
      "d": 327805,
      "h": 137439281277,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(137439281277),
//--TRIMMABLE-BOUNDARY-START(98784575613),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$6",
      "d": 327805,
      "h": 98784575613,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784575613),
//--TRIMMABLE-BOUNDARY-START(133144313981),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$5",
      "d": 327805,
      "h": 133144313981,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(133144313981),
//--TRIMMABLE-BOUNDARY-START(94489608317),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$5",
      "d": 327805,
      "h": 94489608317,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489608317),
//--TRIMMABLE-BOUNDARY-START(128849346685),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$4",
      "d": 327805,
      "h": 128849346685,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(128849346685),
//--TRIMMABLE-BOUNDARY-START(90194641021),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$4",
      "d": 327805,
      "h": 90194641021,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(90194641021),
//--TRIMMABLE-BOUNDARY-START(124554379389),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$3",
      "d": 327805,
      "h": 124554379389,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124554379389),
//--TRIMMABLE-BOUNDARY-START(85899673725),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$3",
      "d": 327805,
      "h": 85899673725,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(85899673725),
//--TRIMMABLE-BOUNDARY-START(120259412093),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$2",
      "d": 327805,
      "h": 120259412093,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(120259412093),
//--TRIMMABLE-BOUNDARY-START(81604706429),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$2",
      "d": 327805,
      "h": 81604706429,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(81604706429),
//--TRIMMABLE-BOUNDARY-START(115964444797),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "o": "@$1",
      "d": 327805,
      "h": 115964444797,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(115964444797),
//--TRIMMABLE-BOUNDARY-START(77309739133),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "o": "@$1",
      "d": 327805,
      "h": 77309739133,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77309739133),
//--TRIMMABLE-BOUNDARY-START(111669477501),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogException",
      "d": 327805,
      "h": 111669477501,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(111669477501),
//--TRIMMABLE-BOUNDARY-START(73014771837),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogArgumentException",
      "d": 327805,
      "h": 73014771837,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73014771837),
//--TRIMMABLE-BOUNDARY-START(154619150461),
    {
      "r": 80805889,
      "p": [
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "LogExceptionMessage",
      "o": "@$1",
      "d": 327805,
      "h": 154619150461,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154619150461),
//--TRIMMABLE-BOUNDARY-START(150324183165),
    {
      "r": 80805889,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "LogExceptionMessage",
      "d": 327805,
      "h": 150324183165,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150324183165),
//--TRIMMABLE-BOUNDARY-START(163209085053),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "LogInformation",
      "d": 327805,
      "h": 163209085053,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163209085053),
//--TRIMMABLE-BOUNDARY-START(167504052349),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "LogVerbose",
      "d": 327805,
      "h": 167504052349,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167504052349),
//--TRIMMABLE-BOUNDARY-START(171799019645),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "LogWarning",
      "d": 327805,
      "h": 171799019645,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171799019645),
//--TRIMMABLE-BOUNDARY-START(146029215869),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        },
        {
          "n": "argumentName",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "LogExceptionImpl",
      "d": 327805,
      "h": 146029215869,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(146029215869),
//--TRIMMABLE-BOUNDARY-START(30065098877),
    {
      "r": 65660,
      "p": [
        {
          "n": "eventLevel",
          "p": 74448897
        }
      ],
      "n": "EventLevelToEventLogLevel",
      "d": 327805,
      "h": 30065098877,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065098877),
//--TRIMMABLE-BOUNDARY-START(34360066173),
    {
      "r": 74448897,
      "p": [
        {
          "n": "eventLevel",
          "p": 65660
        }
      ],
      "n": "EventLogLevelToEventLevel",
      "d": 327805,
      "h": 34360066173,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360066173),
//--TRIMMABLE-BOUNDARY-START(38655033469),
    {
      "r": 1310721,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "FormatInvariant",
      "d": 327805,
      "h": 38655033469,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655033469),
//--TRIMMABLE-BOUNDARY-START(206158758013),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "SanitizeSecurityArtifact",
      "d": 327805,
      "h": 206158758013,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206158758013),
//--TRIMMABLE-BOUNDARY-START(193273856125),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "RemovePII",
      "d": 327805,
      "h": 193273856125,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(193273856125),
//--TRIMMABLE-BOUNDARY-START(64424837245),
    {
      "r": 262145,
      "p": [
        {
          "n": "ex",
          "p": 80805889
        }
      ],
      "n": "IsCustomException",
      "d": 327805,
      "h": 64424837245,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64424837245),
//--TRIMMABLE-BOUNDARY-START(176093986941),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "MarkAsNonPII",
      "d": 327805,
      "h": 176093986941,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(176093986941),
//--TRIMMABLE-BOUNDARY-START(184683921533),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        },
        {
          "n": "callback",
          "p": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h
        }
      ],
      "n": "MarkAsSecurityArtifact",
      "o": "@$1",
      "d": 327805,
      "h": 184683921533,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(184683921533),
//--TRIMMABLE-BOUNDARY-START(180388954237),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        },
        {
          "n": "callback",
          "p": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h
        },
        {
          "n": "callbackUnsafe",
          "p": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h
        }
      ],
      "n": "MarkAsSecurityArtifact",
      "d": 327805,
      "h": 180388954237,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(180388954237),
//--TRIMMABLE-BOUNDARY-START(188978888829),
    {
      "r": 131073,
      "p": [
        {
          "n": "arg",
          "p": 131073
        },
        {
          "n": "callbackUnsafe",
          "p": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h
        }
      ],
      "n": "MarkAsUnsafeSecurityArtifact",
      "d": 327805,
      "h": 188978888829,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188978888829),
//--TRIMMABLE-BOUNDARY-START(227633594493),
    {
      "r": 262268,
      "p": [
        {
          "n": "eventLogLevel",
          "p": 65660
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteEntry",
      "d": 327805,
      "h": 227633594493,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(227633594493),
//--TRIMMABLE-BOUNDARY-START(201863790717),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        }
      ],
      "n": "Sanitize",
      "d": 327805,
      "h": 201863790717,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201863790717)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295101),
    {
      "t": 262145,
      "n": "_isHeaderWritten",
      "d": 327805,
      "h": 4295295101,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295295101),
//--TRIMMABLE-BOUNDARY-START(197568823421),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "s_charsToSanitize",
      "d": 327805,
      "h": 197568823421,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(197568823421),
//--TRIMMABLE-BOUNDARY-START(8590262397),
    {
      "t": 1310721,
      "n": "_piiOffLogMessage",
      "d": 327805,
      "h": 8590262397,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590262397),
//--TRIMMABLE-BOUNDARY-START(12885229693),
    {
      "t": 1310721,
      "n": "_piiOnLogMessage",
      "d": 327805,
      "h": 12885229693,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885229693)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770131581),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327805,
      "h": 25770131581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131581)
  ],
  "h": 327805
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.LogHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}LogHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327805)
        
        

        //--TRIMMABLE-BOUNDARY-START(458877)
        $asm.$str(`$mil.MIL.NonPII`, ($self) => class NonPII extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180328061)
            /*object*/ Argument = null;
            //--TRIMMABLE-BOUNDARY-END(17180328061)
            
            //--TRIMMABLE-BOUNDARY-START(12885360765)
            $ctor$3(/*object*/ argument)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885360765);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Argument = argument;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360765)
            
            //--TRIMMABLE-BOUNDARY-START(38655164541)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let __ca1__;
                return ((__ca1__ = this.Argument) !== null ? ($.$dsp(__ca1__, $.$$.S.Object, ($t) => $t.ToString) ?? "Null") : "Null");
            }
            //--TRIMMABLE-BOUNDARY-END(38655164541)
            
            //--TRIMMABLE-BOUNDARY-START(8590393469)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393469)
            
            //--TRIMMABLE-BOUNDARY-START(8590393469)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590393469)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Argument = this.Argument;
                return copy;
            }
            static $h = 458877;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180328061),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262653,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360197245,
        "f": 83886081
      },
      "n": "Argument",
      "d": 458877,
      "h": 17180328061,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180328061)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655164541),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 458877,
      "h": 38655164541,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655164541)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360765),
    {
      "p": [
        {
          "n": "argument",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458877,
      "h": 12885360765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360765),
//--TRIMMABLE-BOUNDARY-START(8590393469),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458877,
      "h": 8590393469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393469)
  ],
  "h": 458877
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.NonPII`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}NonPII`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458877)
        
        

        //--TRIMMABLE-BOUNDARY-START(589949)
        $asm.$cls(`$mil.MIL.TextWriterEventListener`, ($self) => class TextWriterEventListener extends $.$$.SDT.EventListener
        {
            //--TRIMMABLE-BOUNDARY-START(8590524541)
            /*StreamWriter*/ _streamWriter = null;
            //--TRIMMABLE-BOUNDARY-END(8590524541)
            
            //--TRIMMABLE-BOUNDARY-START(4295557245)
            /*bool*/ _disposeStreamWriter = true;
            //--TRIMMABLE-BOUNDARY-END(4295557245)
            
            //--TRIMMABLE-BOUNDARY-START(30065361021)
            /*string*/ static DefaultLogFileName = null;
            //--TRIMMABLE-BOUNDARY-END(30065361021)
            
            //--TRIMMABLE-BOUNDARY-START(17180459133)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        /*Stream*/ let fileStream = new $.$$.SI.FileStream().$ctor$15($.$mil.MIL.TextWriterEventListener.DefaultLogFileName, 4/*FileMode.OpenOrCreate*/, 2/*FileAccess.Write*/);
                        this._streamWriter = new $.$$.SI.StreamWriter().$ctor$8(fileStream);
                        this._streamWriter.AutoFlush = true;
                    }
                    catch(ex)
                    {
                        $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$11("MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception."/*LogMessages.MIML10001*/, ex));
                        throw ex;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459133)
            
            //--TRIMMABLE-BOUNDARY-START(25770393725)
            $ctor$4(/*string*/ filePath)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrEmpty(filePath))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("filePath");
                    }
                    try
                    {
                        /*Stream*/ let fileStream = new $.$$.SI.FileStream().$ctor$15(filePath, 4/*FileMode.OpenOrCreate*/, 2/*FileAccess.Write*/);
                        this._streamWriter = new $.$$.SI.StreamWriter().$ctor$8(fileStream);
                        this._streamWriter.AutoFlush = true;
                    }
                    catch(ex)
                    {
                        $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$11("MIML10001: Cannot create the fileStream or StreamWriter to write logs. See inner exception."/*LogMessages.MIML10001*/, ex));
                        throw ex;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393725)
            
            //--TRIMMABLE-BOUNDARY-START(21475426429)
            $ctor$3(/*StreamWriter*/ streamWriter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426429);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (streamWriter === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("streamWriter");
                    }
                    this._streamWriter = streamWriter;
                    this._disposeStreamWriter = false;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426429)
            
            //--TRIMMABLE-BOUNDARY-START(38655295613)
            /*void */ OnEventWritten(/*EventWrittenEventArgs*/ eventData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (eventData === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("eventData");
                }
                if (eventData.Payload === null || eventData.Payload.Count <= 0)
                {
                    $.$mil.MIL.LogHelper.LogInformation("MIML10000: eventData.Payload is null or empty. Not logging any messages."/*LogMessages.MIML10000*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    return;
                }
                for(/*int*/ let i = 0; i < eventData.Payload.Count; i++)
                {
                    this._streamWriter.WriteLine$17($.$dspc(eventData.Payload.get_Item(i), $.$$.S.Object, ($t) => $t.ToString));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655295613)
            
            //--TRIMMABLE-BOUNDARY-START(34360328317)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposeStreamWriter && this._streamWriter !== null)
                {
                    this._streamWriter.Flush();
                    this._streamWriter.Dispose();
                }
                $.$$.S.GC.SuppressFinalize(this);
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(34360328317)
            
            //--TRIMMABLE-BOUNDARY-START(17180459133)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180459133)
            
            //--TRIMMABLE-BOUNDARY-START(12885491837)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30065361021)
                    this.DefaultLogFileName = "IdentityModelLogs.txt";
                    //--TRIMMABLE-BOUNDARY-END(30065361021)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885491837)
            
            static $h = 589949;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SDT.EventListener; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655295613),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventData",
          "p": 76152833
        }
      ],
      "n": "OnEventWritten",
      "d": 589949,
      "h": 38655295613,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655295613),
//--TRIMMABLE-BOUNDARY-START(34360328317),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 589949,
      "h": 34360328317,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360328317)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524541),
    {
      "t": 96206849,
      "n": "_streamWriter",
      "d": 589949,
      "h": 8590524541,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524541),
//--TRIMMABLE-BOUNDARY-START(4295557245),
    {
      "t": 262145,
      "n": "_disposeStreamWriter",
      "d": 589949,
      "h": 4295557245,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557245),
//--TRIMMABLE-BOUNDARY-START(30065361021),
    {
      "t": 1310721,
      "n": "DefaultLogFileName",
      "d": 589949,
      "h": 30065361021,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065361021)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180459133),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589949,
      "h": 17180459133,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459133),
//--TRIMMABLE-BOUNDARY-START(25770393725),
    {
      "p": [
        {
          "n": "filePath",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 589949,
      "h": 25770393725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393725),
//--TRIMMABLE-BOUNDARY-START(21475426429),
    {
      "p": [
        {
          "n": "streamWriter",
          "p": 96206849
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589949,
      "h": 21475426429,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426429)
  ],
  "h": 589949
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.TextWriterEventListener`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}TextWriterEventListener`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589949)
        
        

        //--TRIMMABLE-BOUNDARY-START(524413)
        $asm.$str(`$mil.MIL.SecurityArtifact`, ($self) => class SecurityArtifact extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885426301)
            /*string*/ static _scrubbedArtifact = null;
            //--TRIMMABLE-BOUNDARY-END(12885426301)
            
            //--TRIMMABLE-BOUNDARY-START(34360262781)
            /*object*/ Argument = null;
            //--TRIMMABLE-BOUNDARY-END(34360262781)
            
            //--TRIMMABLE-BOUNDARY-START(8590459005)
            /*Func<object, string>*/ _disarmCallback = null;
            //--TRIMMABLE-BOUNDARY-END(8590459005)
            
            //--TRIMMABLE-BOUNDARY-START(4295491709)
            /*Func<object, string>*/ _callbackUnsafe = null;
            //--TRIMMABLE-BOUNDARY-END(4295491709)
            
            //--TRIMMABLE-BOUNDARY-START(30065295485)
            $ctor$4(/*object*/ argument, /*Func<object, string>*/ toStringCallback)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295485);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Argument = argument;
                    this._disarmCallback = toStringCallback;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295485)
            
            //--TRIMMABLE-BOUNDARY-START(25770328189)
            $ctor$3(/*object*/ argument, /*Func<object, string>*/ toStringCallback, /*Func<object, string>*/ toStringCallbackUnsafe)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328189);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Argument = argument;
                    this._disarmCallback = toStringCallback;
                    this._callbackUnsafe = toStringCallbackUnsafe;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770328189)
            
            //--TRIMMABLE-BOUNDARY-START(60130066557)
            static /*string */ UnknownSafeTokenCallback(/*object*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "#ScrubbedArtifact#"/*_scrubbedArtifact*/;
            }
            //--TRIMMABLE-BOUNDARY-END(60130066557)
            
            //--TRIMMABLE-BOUNDARY-START(55835099261)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disarmCallback === null)
                {
                    return "#ScrubbedArtifact#"/*_scrubbedArtifact*/;
                }
                if (this.Argument === null)
                {
                    return "null";
                }
                else 
                {
                    return this._disarmCallback.Invoke(this.Argument);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835099261)
            
            //--TRIMMABLE-BOUNDARY-START(64425033853)
            /*string */ UnsafeToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._callbackUnsafe === null || this.Argument === null)
                {
                    return this.ToString();
                }
                else 
                {
                    return this._callbackUnsafe.Invoke(this.Argument);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425033853)
            
            //--TRIMMABLE-BOUNDARY-START(4295164029)
            //Generated interface implemetation for Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact.UnsafeToString()
            MIL$ISafeLogSecurityArtifact$UnsafeToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnsafeToString(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164029)
            
            //--TRIMMABLE-BOUNDARY-START(21475360893)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360893)
            
            //--TRIMMABLE-BOUNDARY-START(21475360893)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475360893)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Argument = this.Argument;
                copy._disarmCallback = this._disarmCallback;
                copy._callbackUnsafe = this._callbackUnsafe;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426301)
                    this._scrubbedArtifact = "#ScrubbedArtifact#";
                    //--TRIMMABLE-BOUNDARY-END(12885426301)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 524413;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360262781),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197373,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540131965,
        "f": 83886082
      },
      "n": "Argument",
      "d": 524413,
      "h": 34360262781,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34360262781)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130066557),
    {
      "r": 1310721,
      "p": [
        {
          "n": "_",
          "p": 131073
        }
      ],
      "n": "UnknownSafeTokenCallback",
      "d": 524413,
      "h": 60130066557,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130066557),
//--TRIMMABLE-BOUNDARY-START(55835099261),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 524413,
      "h": 55835099261,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835099261),
//--TRIMMABLE-BOUNDARY-START(64425033853),
    {
      "r": 1310721,
      "n": "UnsafeToString",
      "d": 524413,
      "h": 64425033853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425033853)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885426301),
    {
      "t": 1310721,
      "n": "_scrubbedArtifact",
      "d": 524413,
      "h": 12885426301,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885426301),
//--TRIMMABLE-BOUNDARY-START(8590459005),
    {
      "t": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h,
      "n": "_disarmCallback",
      "d": 524413,
      "h": 8590459005,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590459005),
//--TRIMMABLE-BOUNDARY-START(4295491709),
    {
      "t": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h,
      "n": "_callbackUnsafe",
      "d": 524413,
      "h": 4295491709,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491709)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065295485),
    {
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "toStringCallback",
          "p": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 524413,
      "h": 30065295485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065295485),
//--TRIMMABLE-BOUNDARY-START(25770328189),
    {
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "toStringCallback",
          "p": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h
        },
        {
          "n": "toStringCallbackUnsafe",
          "p": $.$$.S.Func$$$($.$$.S.Object, $.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524413,
      "h": 25770328189,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328189),
//--TRIMMABLE-BOUNDARY-START(21475360893),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524413,
      "h": 21475360893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360893)
  ],
  "h": 524413
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.MIL.ISafeLogSecurityArtifact ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.SecurityArtifact`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}SecurityArtifact`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524413)
        
        

        //--TRIMMABLE-BOUNDARY-START(65661)
        $asm.$cls(`$mil.MIL.IdentityModelEventSource`, ($self) => class IdentityModelEventSource extends $.$$.SDT.EventSource
        {
            //--TRIMMABLE-BOUNDARY-START(51539673213)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mil.MIL.IdentityModelEventSource.Logger = new $.$mil.MIL.IdentityModelEventSource().$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(51539673213)
            
            //--TRIMMABLE-BOUNDARY-START(55834640509)
            $ctor$10()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834640509);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.LogLevel = 3/*EventLevel.Warning*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834640509)
            
            //--TRIMMABLE-BOUNDARY-START(137439019133)
            /*IdentityModelEventSource*/ static Logger = null;
            //--TRIMMABLE-BOUNDARY-END(137439019133)
            
            //--TRIMMABLE-BOUNDARY-START(184683659389)
            /*bool*/ static ShowPII = false;
            //--TRIMMABLE-BOUNDARY-END(184683659389)
            
            //--TRIMMABLE-BOUNDARY-START(133144051837)
            /*bool*/ static LogCompleteSecurityArtifact = false;
            //--TRIMMABLE-BOUNDARY-END(133144051837)
            
            //--TRIMMABLE-BOUNDARY-START(124554117245)
            /*string*/ static HiddenPIIString = null;
            //--TRIMMABLE-BOUNDARY-END(124554117245)
            
            //--TRIMMABLE-BOUNDARY-START(128849084541)
            /*string*/ static HiddenSecurityArtifactString = null;
            //--TRIMMABLE-BOUNDARY-END(128849084541)
            
            //--TRIMMABLE-BOUNDARY-START(120259149949)
            /*bool*/ static HeaderWritten = false;
            //--TRIMMABLE-BOUNDARY-END(120259149949)
            
            //--TRIMMABLE-BOUNDARY-START(17179934845)
            /*string*/ static _versionLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17179934845)
            
            //--TRIMMABLE-BOUNDARY-START(4295032957)
            /*string*/ static _dateLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(4295032957)
            
            //--TRIMMABLE-BOUNDARY-START(8590000253)
            /*string*/ static _piiOffLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590000253)
            
            //--TRIMMABLE-BOUNDARY-START(12884967549)
            /*string*/ static _piiOnLogMessage = null;
            //--TRIMMABLE-BOUNDARY-END(12884967549)
            
            //--TRIMMABLE-BOUNDARY-START(201863528573)
            /*void */ WriteAlways$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863528573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled())
                {
                    message = $.$mil.MIL.IdentityModelEventSource.PrepareMessage(0/*EventLevel.LogAlways*/, message, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    this.WriteEvent$17(6, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201863528573)
            
            //--TRIMMABLE-BOUNDARY-START(197568561277)
            /*void */ WriteAlways(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568561277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled())
                {
                    if (args !== null)
                    {
                        this.WriteAlways$1($.$mil.MIL.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteAlways$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568561277)
            
            //--TRIMMABLE-BOUNDARY-START(236223266941)
            /*void */ WriteVerbose$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223266941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 5/*EventLevel.Verbose*/)
                {
                    message = $.$mil.MIL.IdentityModelEventSource.PrepareMessage(5/*EventLevel.Verbose*/, message, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    this.WriteEvent$17(1, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236223266941)
            
            //--TRIMMABLE-BOUNDARY-START(231928299645)
            /*void */ WriteVerbose(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928299645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 5/*EventLevel.Verbose*/)
                {
                    if (args !== null)
                    {
                        this.WriteVerbose$1($.$mil.MIL.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteVerbose$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231928299645)
            
            //--TRIMMABLE-BOUNDARY-START(227633332349)
            /*void */ WriteInformation$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633332349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 4/*EventLevel.Informational*/)
                {
                    message = $.$mil.MIL.IdentityModelEventSource.PrepareMessage(4/*EventLevel.Informational*/, message, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    this.WriteEvent$17(2, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633332349)
            
            //--TRIMMABLE-BOUNDARY-START(223338365053)
            /*void */ WriteInformation(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338365053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 4/*EventLevel.Informational*/)
                {
                    if (args !== null)
                    {
                        this.WriteInformation$1($.$mil.MIL.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteInformation$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338365053)
            
            //--TRIMMABLE-BOUNDARY-START(244813201533)
            /*void */ WriteWarning$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813201533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 3/*EventLevel.Warning*/)
                {
                    message = $.$mil.MIL.IdentityModelEventSource.PrepareMessage(3/*EventLevel.Warning*/, message, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    this.WriteEvent$17(3, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244813201533)
            
            //--TRIMMABLE-BOUNDARY-START(240518234237)
            /*void */ WriteWarning(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518234237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    this.WriteWarning$1($.$mil.MIL.LogHelper.FormatInvariant(message, args));
                }
                else 
                {
                    this.WriteWarning$1(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240518234237)
            
            //--TRIMMABLE-BOUNDARY-START(219043397757)
            /*void */ WriteError$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043397757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 2/*EventLevel.Error*/)
                {
                    message = $.$mil.MIL.IdentityModelEventSource.PrepareMessage(2/*EventLevel.Error*/, message, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    this.WriteEvent$17(4, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043397757)
            
            //--TRIMMABLE-BOUNDARY-START(214748430461)
            /*void */ WriteError(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748430461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 2/*EventLevel.Error*/)
                {
                    if (args !== null)
                    {
                        this.WriteError$1($.$mil.MIL.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteError$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748430461)
            
            //--TRIMMABLE-BOUNDARY-START(210453463165)
            /*void */ WriteCritical$1(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453463165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 1/*EventLevel.Critical*/)
                {
                    message = $.$mil.MIL.IdentityModelEventSource.PrepareMessage(1/*EventLevel.Critical*/, message, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    this.WriteEvent$17(5, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210453463165)
            
            //--TRIMMABLE-BOUNDARY-START(206158495869)
            /*void */ WriteCritical(/*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158495869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled() && this.LogLevel >= 1/*EventLevel.Critical*/)
                {
                    if (args !== null)
                    {
                        this.WriteCritical$1($.$mil.MIL.LogHelper.FormatInvariant(message, args));
                    }
                    else 
                    {
                        this.WriteCritical$1(message);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206158495869)
            
            //--TRIMMABLE-BOUNDARY-START(193273593981)
            /*void */ Write$7(/*EventLevel*/ level, /*Exception*/ innerException, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273593981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Write$6(level, innerException, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(193273593981)
            
            //--TRIMMABLE-BOUNDARY-START(188978626685)
            /*void */ Write$6(/*EventLevel*/ level, /*Exception*/ innerException, /*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978626685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (innerException !== null)
                {
                    if (!$.$mil.MIL.IdentityModelEventSource.ShowPII && !$.$mil.MIL.LogHelper.IsCustomException(innerException))
                    {
                        message = $.$$.S.String.Format$3($.$$.SG.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}", message, innerException.GetType$1());
                    }
                    else 
                    {
                        message = $.$$.S.String.Format$3($.$$.SG.CultureInfo.InvariantCulture, "Message: {0}, InnerException: {1}", message, innerException.Message);
                    }
                }
                if (!$.$mil.MIL.IdentityModelEventSource.HeaderWritten)
                {
                    this.WriteAlways$1($.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, $.$mil.MIL.IdentityModelEventSource._versionLogMessage, $.$$.SR.IntrospectionExtensions.GetTypeInfo($.$mil.MIL.IdentityModelEventSource.$type).Assembly.GetName().Version.ToString()));
                    this.WriteAlways$1($.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, $.$mil.MIL.IdentityModelEventSource._dateLogMessage, $.$$.S.DateTime.UtcNow));
                    if ($.$mil.MIL.IdentityModelEventSource.ShowPII)
                    {
                        this.WriteAlways$1($.$mil.MIL.IdentityModelEventSource._piiOnLogMessage);
                    }
                    else 
                    {
                        this.WriteAlways$1($.$mil.MIL.IdentityModelEventSource._piiOffLogMessage);
                    }
                    $.$mil.MIL.IdentityModelEventSource.HeaderWritten = true;
                }
                switch(level)
                {
                    case 0/*EventLevel.LogAlways*/:
                    this.WriteAlways(message, args);
                    break;
                    case 1/*EventLevel.Critical*/:
                    this.WriteCritical(message, args);
                    break;
                    case 2/*EventLevel.Error*/:
                    this.WriteError(message, args);
                    break;
                    case 3/*EventLevel.Warning*/:
                    this.WriteWarning(message, args);
                    break;
                    case 4/*EventLevel.Informational*/:
                    this.WriteInformation(message, args);
                    break;
                    case 5/*EventLevel.Verbose*/:
                    this.WriteVerbose(message, args);
                    break;
                    default:
                    this.WriteError$1($.$mil.MIL.LogHelper.FormatInvariant("MIML10002: Unknown log level: {0}."/*LogMessages.MIML10002*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(level, $.$$.SDT.EventLevel) ], null, null)));
                    this.WriteError(message, args);
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188978626685)
            
            //--TRIMMABLE-BOUNDARY-START(141733986429)
            /*EventLevel*/ LogLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(141733986429)
            
            //--TRIMMABLE-BOUNDARY-START(146028953725)
            static /*string */ PrepareMessage(/*EventLevel*/ level, /*string*/ message, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028953725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (message === null)
                {
                    return $.$$.S.String.Empty;
                }
                try
                {
                    if (args !== null && args.length > 0)
                    {
                        return $.$$.S.String.Format$2($.$$.SG.CultureInfo.InvariantCulture, "[{0}]{1} {2}", $.$$.S.Enum.ToStringT($.$$.SDT.EventLevel, $.$$.S.UInt32, level), $.$$.S.DateTime.UtcNow.ToString$1($.$$.SG.CultureInfo.InvariantCulture), $.$mil.MIL.LogHelper.FormatInvariant(message, args));
                    }
                    return $.$$.S.String.Format$2($.$$.SG.CultureInfo.InvariantCulture, "[{0}]{1} {2}", $.$$.S.Enum.ToStringT($.$$.SDT.EventLevel, $.$$.S.UInt32, level), $.$$.S.DateTime.UtcNow.ToString$1($.$$.SG.CultureInfo.InvariantCulture), message);
                }
                catch($e)
                {
                }
                try
                {
                    return $.$mil.MIL.LogHelper.FormatInvariant("[{0}]{1} {2}", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$$.S.Enum.ToStringT($.$$.SDT.EventLevel, $.$$.S.UInt32, level), $.$$.S.DateTime.UtcNow.ToString$1($.$$.SG.CultureInfo.InvariantCulture), message ], null, null));
                }
                catch($e)
                {
                    return $.$strNN($.$$.S.Enum.ToStringT($.$$.SDT.EventLevel, $.$$.S.UInt32, level) + $.$$.S.DateTime.UtcNow.ToString$1($.$$.SG.CultureInfo.InvariantCulture)) + $.$strNN(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146028953725)
            
            //--TRIMMABLE-BOUNDARY-START(55834640509)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(55834640509)
            
            //--TRIMMABLE-BOUNDARY-START(51539673213)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(124554117245)
                    this.HiddenPIIString = "[PII of type '{0}' is hidden. For more details, see https://aka.ms/IdentityModel/PII.]";
                    //--TRIMMABLE-BOUNDARY-END(124554117245)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849084541)
                    this.HiddenSecurityArtifactString = "[Security Artifact of type '{0}' is hidden. For more details, see https://aka.ms/IdentityModel/SecurityArtifactLogging.]";
                    //--TRIMMABLE-BOUNDARY-END(128849084541)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934845)
                    this._versionLogMessage = "Library version: {0}.";
                    //--TRIMMABLE-BOUNDARY-END(17179934845)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032957)
                    this._dateLogMessage = "Date: {0}.";
                    //--TRIMMABLE-BOUNDARY-END(4295032957)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000253)
                    this._piiOffLogMessage = "PII (personally identifiable information) logging is currently turned off. Set IdentityModelEventSource.ShowPII to 'true' to view the full details of exceptions.";
                    //--TRIMMABLE-BOUNDARY-END(8590000253)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967549)
                    this._piiOnLogMessage = "PII (personally identifiable information) logging is currently turned on. Set IdentityModelEventSource.ShowPII to 'false' to hide PII from log messages.";
                    //--TRIMMABLE-BOUNDARY-END(12884967549)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539673213)
            
            static $h = 65661;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SDT.EventSource; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439019133),
    {
      "p": 65661,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784313469,
        "f": 50331681
      },
      "n": "Logger",
      "d": 65661,
      "h": 137439019133,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(137439019133),
//--TRIMMABLE-BOUNDARY-START(184683659389),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964182653,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388692093,
        "f": 83886113
      },
      "n": "ShowPII",
      "d": 65661,
      "h": 184683659389,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(184683659389),
//--TRIMMABLE-BOUNDARY-START(133144051837),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194378877,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163208822909,
        "f": 83886113
      },
      "n": "LogCompleteSecurityArtifact",
      "d": 65661,
      "h": 133144051837,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(133144051837),
//--TRIMMABLE-BOUNDARY-START(124554117245),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014509693,
        "f": 50331681
      },
      "n": "HiddenPIIString",
      "d": 65661,
      "h": 124554117245,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(124554117245),
//--TRIMMABLE-BOUNDARY-START(128849084541),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604444285,
        "f": 50331681
      },
      "n": "HiddenSecurityArtifactString",
      "d": 65661,
      "h": 128849084541,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(128849084541),
//--TRIMMABLE-BOUNDARY-START(120259149949),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424575101,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154618888317,
        "f": 83886113
      },
      "n": "HeaderWritten",
      "d": 65661,
      "h": 120259149949,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(120259149949),
//--TRIMMABLE-BOUNDARY-START(141733986429),
    {
      "p": 74448897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374248061,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171798757501,
        "f": 83886081
      },
      "n": "LogLevel",
      "d": 65661,
      "h": 141733986429,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141733986429)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(201863528573),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteAlways",
      "o": "@$1",
      "d": 65661,
      "h": 201863528573,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 6,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 0,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201863528573),
//--TRIMMABLE-BOUNDARY-START(197568561277),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteAlways",
      "d": 65661,
      "h": 197568561277,
      "f": 16777217,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197568561277),
//--TRIMMABLE-BOUNDARY-START(236223266941),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteVerbose",
      "o": "@$1",
      "d": 65661,
      "h": 236223266941,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 1,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236223266941),
//--TRIMMABLE-BOUNDARY-START(231928299645),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteVerbose",
      "d": 65661,
      "h": 231928299645,
      "f": 16777217,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231928299645),
//--TRIMMABLE-BOUNDARY-START(227633332349),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteInformation",
      "o": "@$1",
      "d": 65661,
      "h": 227633332349,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 2,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 4,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227633332349),
//--TRIMMABLE-BOUNDARY-START(223338365053),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteInformation",
      "d": 65661,
      "h": 223338365053,
      "f": 16777217,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223338365053),
//--TRIMMABLE-BOUNDARY-START(244813201533),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteWarning",
      "o": "@$1",
      "d": 65661,
      "h": 244813201533,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 3,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 3,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244813201533),
//--TRIMMABLE-BOUNDARY-START(240518234237),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteWarning",
      "d": 65661,
      "h": 240518234237,
      "f": 16777217,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240518234237),
//--TRIMMABLE-BOUNDARY-START(219043397757),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteError",
      "o": "@$1",
      "d": 65661,
      "h": 219043397757,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 2,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219043397757),
//--TRIMMABLE-BOUNDARY-START(214748430461),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteError",
      "d": 65661,
      "h": 214748430461,
      "f": 16777217,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214748430461),
//--TRIMMABLE-BOUNDARY-START(210453463165),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteCritical",
      "o": "@$1",
      "d": 65661,
      "h": 210453463165,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 5,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 1,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210453463165),
//--TRIMMABLE-BOUNDARY-START(206158495869),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteCritical",
      "d": 65661,
      "h": 206158495869,
      "f": 16777217,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206158495869),
//--TRIMMABLE-BOUNDARY-START(193273593981),
    {
      "r": 65537,
      "p": [
        {
          "n": "level",
          "p": 74448897
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$7",
      "d": 65661,
      "h": 193273593981,
      "f": 16777217,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193273593981),
//--TRIMMABLE-BOUNDARY-START(188978626685),
    {
      "r": 65537,
      "p": [
        {
          "n": "level",
          "p": 74448897
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "Write",
      "o": "@$6",
      "d": 65661,
      "h": 188978626685,
      "f": 16777217,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188978626685),
//--TRIMMABLE-BOUNDARY-START(146028953725),
    {
      "r": 1310721,
      "p": [
        {
          "n": "level",
          "p": 74448897
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "PrepareMessage",
      "d": 65661,
      "h": 146028953725,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146028953725)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934845),
    {
      "t": 1310721,
      "n": "_versionLogMessage",
      "d": 65661,
      "h": 17179934845,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17179934845),
//--TRIMMABLE-BOUNDARY-START(4295032957),
    {
      "t": 1310721,
      "n": "_dateLogMessage",
      "d": 65661,
      "h": 4295032957,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032957),
//--TRIMMABLE-BOUNDARY-START(8590000253),
    {
      "t": 1310721,
      "n": "_piiOffLogMessage",
      "d": 65661,
      "h": 8590000253,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590000253),
//--TRIMMABLE-BOUNDARY-START(12884967549),
    {
      "t": 1310721,
      "n": "_piiOnLogMessage",
      "d": 65661,
      "h": 12884967549,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12884967549)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55834640509),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 65661,
      "h": 55834640509,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55834640509)
  ],
  "h": 65661,
  "a": [
    {
      "t": 75563009,
      "c": 17255432193,
      "n": [
        {
          "n": "Name",
          "v": "Microsoft.IdentityModel.EventSource",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.IdentityModel.Logging.IdentityModelEventSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}IdentityModel${separator}Logging${separator}IdentityModelEventSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65661)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http"));
})();
//--TRIMMABLE-BOUNDARY-END(125)
