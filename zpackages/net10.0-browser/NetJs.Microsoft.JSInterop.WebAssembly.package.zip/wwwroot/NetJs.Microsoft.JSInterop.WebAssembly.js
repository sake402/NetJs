
//--TRIMMABLE-BOUNDARY-START(112)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $mwp, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $sipl, $srei, $srel, $srp, $srl, $stew, $sre, $str, $stj, $mj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.JSInterop.WebAssembly", 
    {
  "h": 112,
  "f": "Microsoft.JSInterop.WebAssembly",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "Abstractions and features for interop between .NET WebAssembly and JavaScript code.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.JSInterop.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.JSInterop.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.WebAssembly.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(262256)
        $asm.$cls("$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime", ($self) => class WebAssemblyJSRuntime extends $.$mj.Microsoft.JSInterop.JSInProcessRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(4295229552)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229552);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JsonSerializerOptions.Converters.System$Collections$Generic$IList$$$Insert(0, new $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReferenceJsonConverter().$ctor$3(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229552)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21475098736, 30067458155)
            /*string */ InvokeJS(/*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return Blazor._internal.invokeJSJson(identifier, targetInstanceId, resultType, argsJson ?? "[]", 0n, 1/*JSCallType.FunctionCall*/);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21475098736, 30067458155)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25770066032, 34362425451)
            /*string */ InvokeJS$2(/*in JSInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770066032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return Blazor._internal.invokeJSJson(invocationInfo.$v.Identifier, invocationInfo.$v.TargetInstanceId, invocationInfo.$v.ResultType, invocationInfo.$v.ArgsJson, invocationInfo.$v.AsyncHandle, invocationInfo.$v.CallType);
                }
                catch(ex)
                {
                    throw new $.$mj.Microsoft.JSInterop.JSException().$ctor$5(ex.Message, ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25770066032, 34362425451)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590196848, 42952622187)
            /*void */ BeginInvokeJS(/*long*/ asyncHandle, /*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                Blazor._internal.invokeJSJson(identifier, targetInstanceId, resultType, argsJson ?? "[]", asyncHandle, 1/*JSCallType.FunctionCall*/);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590196848, 42952622187)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12885164144, 47247589483)
            /*void */ BeginInvokeJS$2(/*in JSInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                Blazor._internal.invokeJSJson(invocationInfo.$v.Identifier, invocationInfo.$v.TargetInstanceId, invocationInfo.$v.ResultType, invocationInfo.$v.ArgsJson, invocationInfo.$v.AsyncHandle, invocationInfo.$v.CallType);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12885164144, 47247589483)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17180131440, 73017393259)
            /*void */ EndInvokeDotNet(/*DotNetInvocationInfo*/ callInfo, /*in DotNetInvocationResult*/ dispatchResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resultJsonOrErrorMessage = dispatchResult.$v.Success ? dispatchResult.$v.ResultJson : $.$$.System.Exception.ToString.call(dispatchResult.$v.Exception);
                Blazor._internal.endInvokeDotNetFromJS(callInfo.CallId, dispatchResult.$v.Success, resultJsonOrErrorMessage);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17180131440, 73017393259)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30065033328, 154621771883)
            /*void */ SendByteArray(/*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                Blazor._internal.receiveByteArray(id, data);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30065033328, 154621771883)
            
            static $h = 262256;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2687083,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 21475098736, 30067458155),
    {
      "r": 1310721,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        },
        {
          "n": "resultType",
          "p": 2359403
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        }
      ],
      "n": "InvokeJS",
      "d": 262256,
      "h": 21475098736,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475098736, 30067458155),
//--TRIMMABLE-BOUNDARY-START(ALL, 25770066032, 34362425451),
    {
      "r": 1310721,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1769579,
          "f": 8
        }
      ],
      "n": "InvokeJS",
      "o": "@$2",
      "d": 262256,
      "h": 25770066032,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770066032, 34362425451),
//--TRIMMABLE-BOUNDARY-START(ALL, 8590196848, 42952622187),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncHandle",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        },
        {
          "n": "resultType",
          "p": 2359403
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        }
      ],
      "n": "BeginInvokeJS",
      "d": 262256,
      "h": 8590196848,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590196848, 42952622187),
//--TRIMMABLE-BOUNDARY-START(ALL, 12885164144, 47247589483),
    {
      "r": 65537,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1769579,
          "f": 8
        }
      ],
      "n": "BeginInvokeJS",
      "o": "@$2",
      "d": 262256,
      "h": 12885164144,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12885164144, 47247589483),
//--TRIMMABLE-BOUNDARY-START(ALL, 17180131440, 73017393259),
    {
      "r": 65537,
      "p": [
        {
          "n": "callInfo",
          "p": 1245291
        },
        {
          "n": "dispatchResult",
          "p": 1310827,
          "f": 8
        }
      ],
      "n": "EndInvokeDotNet",
      "d": 262256,
      "h": 17180131440,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17180131440, 73017393259),
//--TRIMMABLE-BOUNDARY-START(ALL, 30065033328, 154621771883),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "SendByteArray",
      "d": 262256,
      "h": 30065033328,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30065033328, 154621771883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229552),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262256,
      "h": 4295229552,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295229552)
  ],
  "i": [90177537,393323,524395
  ],
  "h": 262256
}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.JSInProcessRuntime; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$mj.Microsoft.JSInterop.IJSInProcessRuntime, $.$mj.Microsoft.JSInterop.IJSRuntime ]; }
            static get $fullName() { return `WebAssemblyJSRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262256)
        
        
        //--TRIMMABLE-BOUNDARY-START(327792)
        $asm.$cls("$mjw.WebAssembly.JSInterop.InternalCalls", ($self) => class InternalCalls
        {
            static $h = 327792;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 327792
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InternalCalls`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327792)
        
        
        //--TRIMMABLE-BOUNDARY-START(65648)
        $asm.$cls("$mjw.Microsoft.JSInterop.JSCallResultTypeHelper", ($self) => class JSCallResultTypeHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295032944)
            /*Assembly*/ static _currentAssembly = null;
            //--TRIMMABLE-BOUNDARY-END(4295032944)
            
            //--TRIMMABLE-BOUNDARY-START(12884967536)
            static /*JSCallResultType */ FromGeneric(TResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Reflection.Assembly.op_Equality(TResult.$type.Assembly, $.$mjw.Microsoft.JSInterop.JSCallResultTypeHelper._currentAssembly))
                {
                    if ($.$$.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSObjectReference.$type) || $.$$.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference.$type))
                    {
                        return 1/*JSCallResultType.JSObjectReference*/;
                    }
                    else if ($.$$.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSStreamReference.$type))
                    {
                        return 2/*JSCallResultType.JSStreamReference*/;
                    }
                    else if ($.$$.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult.$type))
                    {
                        return 3/*JSCallResultType.JSVoidResult*/;
                    }
                }
                return 0/*JSCallResultType.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967536)
            
            //--TRIMMABLE-BOUNDARY-START(8590000240)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032944)
                    this._currentAssembly = $.$mj.Microsoft.JSInterop.JSCallResultType.$type.Assembly;
                    //--TRIMMABLE-BOUNDARY-END(4295032944)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000240)
            
            static $h = 65648;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12884967536),
    {
      "r": 2359403,
      "g": [
        "TResult"
      ],
      "n": "FromGeneric",
      "d": 65648,
      "h": 12884967536,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12884967536)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032944),
    {
      "t": 106168321,
      "n": "_currentAssembly",
      "d": 65648,
      "h": 4295032944,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032944)
  ],
  "h": 65648
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSCallResultTypeHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65648)
        
        
        //--TRIMMABLE-BOUNDARY-START(393328)
        $asm.$str("$mjw.WebAssembly.JSInterop.JSCallInfo", ($self) => class JSCallInfo extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590327920)
            /*string*/  get FunctionIdentifier() { return this.$getField(0, 4); }
            /*string*/  set FunctionIdentifier(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590327920)
            
            //--TRIMMABLE-BOUNDARY-START(21475229808)
            /*JSCallResultType*/  get ResultType() { return this.$getField(4, 4); }
            /*JSCallResultType*/  set ResultType(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(21475229808)
            
            //--TRIMMABLE-BOUNDARY-START(12885295216)
            /*string*/  get MarshalledCallArgsJson() { return this.$getField(8, 4); }
            /*string*/  set MarshalledCallArgsJson(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12885295216)
            
            //--TRIMMABLE-BOUNDARY-START(17180262512)
            /*long*/  get MarshalledCallAsyncHandle() { return this.$getField(12, 8); }
            /*long*/  set MarshalledCallAsyncHandle(value) { this.$setField(12, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(17180262512)
            
            //--TRIMMABLE-BOUNDARY-START(25770197104)
            /*long*/  get TargetInstanceId() { return this.$getField(20, 8); }
            /*long*/  set TargetInstanceId(value) { this.$setField(20, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(25770197104)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.FunctionIdentifier = this.FunctionIdentifier;
                copy.ResultType = this.ResultType;
                copy.MarshalledCallArgsJson = this.MarshalledCallArgsJson;
                copy.MarshalledCallAsyncHandle = this.MarshalledCallAsyncHandle;
                copy.TargetInstanceId = this.TargetInstanceId;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590327920)
                this.FunctionIdentifier = null;
                //--TRIMMABLE-BOUNDARY-END(8590327920)
                
                //--TRIMMABLE-BOUNDARY-START(21475229808)
                this.ResultType = 0;
                //--TRIMMABLE-BOUNDARY-END(21475229808)
                
                //--TRIMMABLE-BOUNDARY-START(12885295216)
                this.MarshalledCallArgsJson = null;
                //--TRIMMABLE-BOUNDARY-END(12885295216)
                
                //--TRIMMABLE-BOUNDARY-START(17180262512)
                this.MarshalledCallAsyncHandle = 0n;
                //--TRIMMABLE-BOUNDARY-END(17180262512)
                
                //--TRIMMABLE-BOUNDARY-START(25770197104)
                this.TargetInstanceId = 0n;
                //--TRIMMABLE-BOUNDARY-END(25770197104)
                
            }
            static $h = 393328;
            static $z = 28;
            static $f = 0b100000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590327920),
    {
      "t": 1310721,
      "n": "FunctionIdentifier",
      "d": 393328,
      "h": 8590327920,
      "f": 4194305,
      "a": [
        {
          "t": 141426689,
          "c": 4436393985,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590327920),
//--TRIMMABLE-BOUNDARY-START(21475229808),
    {
      "t": 2359403,
      "n": "ResultType",
      "d": 393328,
      "h": 21475229808,
      "f": 4194305,
      "a": [
        {
          "t": 141426689,
          "c": 4436393985,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475229808),
//--TRIMMABLE-BOUNDARY-START(12885295216),
    {
      "t": 1310721,
      "n": "MarshalledCallArgsJson",
      "d": 393328,
      "h": 12885295216,
      "f": 4194305,
      "a": [
        {
          "t": 141426689,
          "c": 4436393985,
          "a": [
            {
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885295216),
//--TRIMMABLE-BOUNDARY-START(17180262512),
    {
      "t": 917505,
      "n": "MarshalledCallAsyncHandle",
      "d": 393328,
      "h": 17180262512,
      "f": 4194305,
      "a": [
        {
          "t": 141426689,
          "c": 4436393985,
          "a": [
            {
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180262512),
//--TRIMMABLE-BOUNDARY-START(25770197104),
    {
      "t": 917505,
      "n": "TargetInstanceId",
      "d": 393328,
      "h": 25770197104,
      "f": 4194305,
      "a": [
        {
          "t": 141426689,
          "c": 4436393985,
          "a": [
            {
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770197104)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360624),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393328,
      "h": 4295360624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360624)
  ],
  "h": 393328,
  "a": [
    {
      "t": 147259393,
      "c": 4442226689,
      "a": [
        {
          "v": 2,
          "t": 142737409
        }
      ],
      "n": [
        {
          "n": "Pack",
          "v": 4,
          "t": 655361
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `JSCallInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393328)
        
        
        //--TRIMMABLE-BOUNDARY-START(196720)
        $asm.$cls("$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReferenceJsonConverter", ($self) => class WebAssemblyJSObjectReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSObjectReference)
        {
            //--TRIMMABLE-BOUNDARY-START(4295164016)
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4295164016)
            
            //--TRIMMABLE-BOUNDARY-START(8590131312)
            $ctor$3(/*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131312);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131312)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12885098608, 68732977236)
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Type.op_Equality$1(typeToConvert, $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReference.$type) || $.$$.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.IJSObjectReference.$type) || $.$$.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12885098608, 68732977236)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17180065904, 77322977364)
            /*IJSObjectReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.ReadJSObjectReferenceIdentifier(reader);
                if (id === BigInt(-1))
                {
                    return null;
                }
                return new $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReference().$ctor$3(this._jsRuntime, id);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17180065904, 77322977364)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21475033200, 150337421396)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSObjectReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21475033200, 150337421396)
            
            static $h = 196720;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12885098608, 68732977236),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeToConvert",
          "p": 187629569
        }
      ],
      "n": "CanConvert",
      "d": 196720,
      "h": 12885098608,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12885098608, 68732977236),
//--TRIMMABLE-BOUNDARY-START(ALL, 17180065904, 77322977364),
    {
      "r": 458859,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 196720,
      "h": 17180065904,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17180065904, 77322977364),
//--TRIMMABLE-BOUNDARY-START(ALL, 21475033200, 150337421396),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 458859
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 196720,
      "h": 21475033200,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475033200, 150337421396)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295164016),
    {
      "t": 262256,
      "n": "_jsRuntime",
      "d": 196720,
      "h": 4295164016,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295164016)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131312),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 262256
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196720,
      "h": 8590131312,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131312)
  ],
  "h": 196720
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSObjectReference); }
            static get $fullName() { return `WebAssemblyJSObjectReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196720)
        
        
        //--TRIMMABLE-BOUNDARY-START(131184)
        $asm.$cls("$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReference", ($self) => class WebAssemblyJSObjectReference extends $.$mj.Microsoft.JSInterop.Implementation.JSInProcessObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(4295098480)
            /*WebAssemblyJSRuntime*/ _jsRuntime$2 = null;
            //--TRIMMABLE-BOUNDARY-END(4295098480)
            
            //--TRIMMABLE-BOUNDARY-START(8590065776)
            $ctor$3(/*WebAssemblyJSRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor$2(jsRuntime, id);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065776);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime$2 = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065776)
            
            static $h = 131184;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 655467,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098480),
    {
      "t": 262256,
      "n": "_jsRuntime",
      "o": "@$2",
      "d": 131184,
      "h": 4295098480,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098480)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065776),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 262256
        },
        {
          "n": "id",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131184,
      "h": 8590065776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065776)
  ],
  "i": [327787,458859,89587713,90177537
  ],
  "h": 131184
}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.Implementation.JSInProcessObjectReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference, $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$$.System.IAsyncDisposable, $.$$.System.IDisposable ]; }
            static get $fullName() { return `WebAssemblyJSObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131184)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.IO.Pipelines", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encodings.Web", "NetJs.System.Reflection.Emit", "NetJs.System.Text.RegularExpressions", "NetJs.System.Text.Json", "NetJs.Microsoft.JSInterop"))
//--TRIMMABLE-BOUNDARY-END(112)
