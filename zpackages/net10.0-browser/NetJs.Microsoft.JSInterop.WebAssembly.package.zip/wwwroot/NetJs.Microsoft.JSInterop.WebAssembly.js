
//--TRIMMABLE-BOUNDARY-START(119)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc, $mwp, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $sipl, $srei, $srel, $srp, $srl, $stew, $sre, $str, $stj, $mj) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.Microsoft.JSInterop.WebAssembly", 
    {
  "h": 119,
  "f": "Microsoft.JSInterop.WebAssembly",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Abstractions and features for interop between .NET WebAssembly and JavaScript code.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.JSInterop.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.JSInterop.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.WebAssembly.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(262263)
        $asm.$cls(`$mjw.MJW.WebAssemblyJSRuntime`, ($self) => class WebAssemblyJSRuntime extends $.$mj.MJ.JSInProcessRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(4295229559)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JsonSerializerOptions.Converters.SCG$IList$$$Insert(0, new $.$mjw.MJW.WebAssemblyJSObjectReferenceJsonConverter().$ctor$3(this));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229559)
            
            //--TRIMMABLE-BOUNDARY-START(25770066039)
            /*string */ InvokeJS$1(/*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770066039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return Blazor._internal.invokeJSJson(identifier, targetInstanceId, resultType, argsJson ?? "[]", 0n, 1/*JSCallType.FunctionCall*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25770066039)
            
            //--TRIMMABLE-BOUNDARY-START(21475098743)
            /*string */ InvokeJS(/*in JSInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return Blazor._internal.invokeJSJson(invocationInfo.$v.Identifier, invocationInfo.$v.TargetInstanceId, invocationInfo.$v.ResultType, invocationInfo.$v.ArgsJson, invocationInfo.$v.AsyncHandle, invocationInfo.$v.CallType);
                }
                catch(ex)
                {
                    throw new $.$mj.MJ.JSException().$ctor$5(ex.Message, ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475098743)
            
            //--TRIMMABLE-BOUNDARY-START(12885164151)
            /*void */ BeginInvokeJS$1(/*long*/ asyncHandle, /*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                Blazor._internal.invokeJSJson(identifier, targetInstanceId, resultType, argsJson ?? "[]", asyncHandle, 1/*JSCallType.FunctionCall*/);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164151)
            
            //--TRIMMABLE-BOUNDARY-START(8590196855)
            /*void */ BeginInvokeJS(/*in JSInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                Blazor._internal.invokeJSJson(invocationInfo.$v.Identifier, invocationInfo.$v.TargetInstanceId, invocationInfo.$v.ResultType, invocationInfo.$v.ArgsJson, invocationInfo.$v.AsyncHandle, invocationInfo.$v.CallType);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196855)
            
            //--TRIMMABLE-BOUNDARY-START(17180131447)
            /*void */ EndInvokeDotNet(/*DotNetInvocationInfo*/ callInfo, /*in DotNetInvocationResult*/ dispatchResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resultJsonOrErrorMessage = dispatchResult.$v.Success ? dispatchResult.$v.ResultJson : dispatchResult.$v.Exception.ToString();
                Blazor._internal.endInvokeDotNetFromJS(callInfo.CallId, dispatchResult.$v.Success, resultJsonOrErrorMessage);
            }
            //--TRIMMABLE-BOUNDARY-END(17180131447)
            
            //--TRIMMABLE-BOUNDARY-START(30065033335)
            /*void */ SendByteArray(/*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                Blazor._internal.receiveByteArray(id, data);
            }
            //--TRIMMABLE-BOUNDARY-END(30065033335)
            
            //--TRIMMABLE-BOUNDARY-START(4295229559)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229559)
            
            static $h = 262263;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mj.MJ.JSInProcessRuntime; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770066039),
    {
      "r": 1310721,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        },
        {
          "n": "resultType",
          "p": 2359410
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        }
      ],
      "n": "InvokeJS",
      "o": "@$1",
      "d": 262263,
      "h": 25770066039,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770066039),
//--TRIMMABLE-BOUNDARY-START(21475098743),
    {
      "r": 1310721,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1769586,
          "f": 8
        }
      ],
      "n": "InvokeJS",
      "d": 262263,
      "h": 21475098743,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475098743),
//--TRIMMABLE-BOUNDARY-START(12885164151),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncHandle",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        },
        {
          "n": "resultType",
          "p": 2359410
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        }
      ],
      "n": "BeginInvokeJS",
      "o": "@$1",
      "d": 262263,
      "h": 12885164151,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885164151),
//--TRIMMABLE-BOUNDARY-START(8590196855),
    {
      "r": 65537,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1769586,
          "f": 8
        }
      ],
      "n": "BeginInvokeJS",
      "d": 262263,
      "h": 8590196855,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590196855),
//--TRIMMABLE-BOUNDARY-START(17180131447),
    {
      "r": 65537,
      "p": [
        {
          "n": "callInfo",
          "p": 1245298
        },
        {
          "n": "dispatchResult",
          "p": 1310834,
          "f": 8
        }
      ],
      "n": "EndInvokeDotNet",
      "d": 262263,
      "h": 17180131447,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180131447),
//--TRIMMABLE-BOUNDARY-START(30065033335),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SendByteArray",
      "d": 262263,
      "h": 30065033335,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065033335)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229559),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262263,
      "h": 4295229559,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295229559)
  ],
  "h": 262263
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$mj.MJ.IJSInProcessRuntime, $.$mj.MJ.IJSRuntime ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}WebAssembly${separator}WebAssemblyJSRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262263)
        
        

        //--TRIMMABLE-BOUNDARY-START(65655)
        $asm.$cls(`$mjw.MJ.JSCallResultTypeHelper`, ($self) => class JSCallResultTypeHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295032951)
            /*Assembly*/ static _currentAssembly = null;
            //--TRIMMABLE-BOUNDARY-END(4295032951)
            
            //--TRIMMABLE-BOUNDARY-START(12884967543)
            static /*JSCallResultType */ FromGeneric(TResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.SR.Assembly.op_Equality(TResult.$type.Assembly, $.$mjw.MJ.JSCallResultTypeHelper._currentAssembly))
                {
                    if (TResult.$type === $.$mj.MJ.IJSObjectReference.$type || TResult.$type === $.$mj.MJ.IJSInProcessObjectReference.$type)
                    {
                        return 1/*JSCallResultType.JSObjectReference*/;
                    }
                    else if (TResult.$type === $.$mj.MJ.IJSStreamReference.$type)
                    {
                        return 2/*JSCallResultType.JSStreamReference*/;
                    }
                    else if (TResult.$type === $.$mj.MJI$1.IJSVoidResult.$type)
                    {
                        return 3/*JSCallResultType.JSVoidResult*/;
                    }
                }
                return 0/*JSCallResultType.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967543)
            
            //--TRIMMABLE-BOUNDARY-START(8590000247)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032951)
                    this._currentAssembly = $.$mj.MJ.JSCallResultType.$type.Assembly;
                    //--TRIMMABLE-BOUNDARY-END(4295032951)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000247)
            
            static $h = 65655;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12884967543),
    {
      "r": 2359410,
      "g": [
        "TResult"
      ],
      "n": "FromGeneric",
      "d": 65655,
      "h": 12884967543,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12884967543)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032951),
    {
      "t": 107020289,
      "n": "_currentAssembly",
      "d": 65655,
      "h": 4295032951,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032951)
  ],
  "h": 65655
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSCallResultTypeHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSCallResultTypeHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65655)
        
        

        //--TRIMMABLE-BOUNDARY-START(327799)
        $asm.$cls(`$mjw.WJ.InternalCalls`, ($self) => class InternalCalls
        {
            static $h = 327799;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 327799
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `WebAssembly.JSInterop.InternalCalls`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `WebAssembly${separator}JSInterop${separator}InternalCalls`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327799)
        
        

        //--TRIMMABLE-BOUNDARY-START(393335)
        $asm.$str(`$mjw.WJ.JSCallInfo`, ($self) => class JSCallInfo extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590327927)
            /*string*/  get FunctionIdentifier() { return this.$getField(0, $.$$.S.String); }
            /*string*/  set FunctionIdentifier(value) { this.$setField(0, $.$$.S.String, value); }
            //--TRIMMABLE-BOUNDARY-END(8590327927)
            
            //--TRIMMABLE-BOUNDARY-START(21475229815)
            /*JSCallResultType*/  get ResultType() { return this.$getField(4, $.$mj.MJ.JSCallResultType); }
            /*JSCallResultType*/  set ResultType(value) { this.$setField(4, $.$mj.MJ.JSCallResultType, value); }
            //--TRIMMABLE-BOUNDARY-END(21475229815)
            
            //--TRIMMABLE-BOUNDARY-START(12885295223)
            /*string*/  get MarshalledCallArgsJson() { return this.$getField(8, $.$$.S.String); }
            /*string*/  set MarshalledCallArgsJson(value) { this.$setField(8, $.$$.S.String, value); }
            //--TRIMMABLE-BOUNDARY-END(12885295223)
            
            //--TRIMMABLE-BOUNDARY-START(17180262519)
            /*long*/  get MarshalledCallAsyncHandle() { return this.$getField(12, $.$$.S.Int64); }
            /*long*/  set MarshalledCallAsyncHandle(value) { this.$setField(12, $.$$.S.Int64, value); }
            //--TRIMMABLE-BOUNDARY-END(17180262519)
            
            //--TRIMMABLE-BOUNDARY-START(25770197111)
            /*long*/  get TargetInstanceId() { return this.$getField(20, $.$$.S.Int64); }
            /*long*/  set TargetInstanceId(value) { this.$setField(20, $.$$.S.Int64, value); }
            //--TRIMMABLE-BOUNDARY-END(25770197111)
            
            //--TRIMMABLE-BOUNDARY-START(4295360631)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360631)
            
            //--TRIMMABLE-BOUNDARY-START(4295360631)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360631)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.FunctionIdentifier = this.FunctionIdentifier;
                copy.ResultType = this.ResultType;
                copy.MarshalledCallArgsJson = this.MarshalledCallArgsJson;
                copy.MarshalledCallAsyncHandle = this.MarshalledCallAsyncHandle;
                copy.TargetInstanceId = this.TargetInstanceId;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590327927)
                this.FunctionIdentifier = null;
                //--TRIMMABLE-BOUNDARY-END(8590327927)
                
                //--TRIMMABLE-BOUNDARY-START(21475229815)
                this.ResultType = 0;
                //--TRIMMABLE-BOUNDARY-END(21475229815)
                
                //--TRIMMABLE-BOUNDARY-START(12885295223)
                this.MarshalledCallArgsJson = null;
                //--TRIMMABLE-BOUNDARY-END(12885295223)
                
                //--TRIMMABLE-BOUNDARY-START(17180262519)
                this.MarshalledCallAsyncHandle = 0n;
                //--TRIMMABLE-BOUNDARY-END(17180262519)
                
                //--TRIMMABLE-BOUNDARY-START(25770197111)
                this.TargetInstanceId = 0n;
                //--TRIMMABLE-BOUNDARY-END(25770197111)
                
            }
            static $h = 393335;
            static $z = 28;
            static $f = 0b100000000001010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590327927),
    {
      "t": 1310721,
      "n": "FunctionIdentifier",
      "d": 393335,
      "h": 8590327927,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590327927),
//--TRIMMABLE-BOUNDARY-START(21475229815),
    {
      "t": 2359410,
      "n": "ResultType",
      "d": 393335,
      "h": 21475229815,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475229815),
//--TRIMMABLE-BOUNDARY-START(12885295223),
    {
      "t": 1310721,
      "n": "MarshalledCallArgsJson",
      "d": 393335,
      "h": 12885295223,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885295223),
//--TRIMMABLE-BOUNDARY-START(17180262519),
    {
      "t": 917505,
      "n": "MarshalledCallAsyncHandle",
      "d": 393335,
      "h": 17180262519,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180262519),
//--TRIMMABLE-BOUNDARY-START(25770197111),
    {
      "t": 917505,
      "n": "TargetInstanceId",
      "d": 393335,
      "h": 25770197111,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770197111)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360631),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393335,
      "h": 4295360631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360631)
  ],
  "h": 393335,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 2,
          "t": 143654913
        }
      ],
      "n": [
        {
          "n": "Pack",
          "v": 4,
          "t": 655361
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `WebAssembly.JSInterop.JSCallInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `WebAssembly${separator}JSInterop${separator}JSCallInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393335)
        
        

        //--TRIMMABLE-BOUNDARY-START(196727)
        $asm.$cls(`$mjw.MJW.WebAssemblyJSObjectReferenceJsonConverter`, ($self) => class WebAssemblyJSObjectReferenceJsonConverter extends $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.IJSObjectReference)
        {
            //--TRIMMABLE-BOUNDARY-START(4295164023)
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4295164023)
            
            //--TRIMMABLE-BOUNDARY-START(8590131319)
            $ctor$3(/*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131319);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131319)
            
            //--TRIMMABLE-BOUNDARY-START(12885098615)
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return typeToConvert === $.$mjw.MJW.WebAssemblyJSObjectReference.$type || typeToConvert === $.$mj.MJ.IJSObjectReference.$type || typeToConvert === $.$mj.MJ.IJSInProcessObjectReference.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098615)
            
            //--TRIMMABLE-BOUNDARY-START(17180065911)
            /*IJSObjectReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = $.$mj.MJI.JSObjectReferenceJsonWorker.ReadJSObjectReferenceIdentifier(reader);
                if (id === BigInt(-1))
                {
                    return null;
                }
                return new $.$mjw.MJW.WebAssemblyJSObjectReference().$ctor$3(this._jsRuntime, id);
            }
            //--TRIMMABLE-BOUNDARY-END(17180065911)
            
            //--TRIMMABLE-BOUNDARY-START(21475033207)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSObjectReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.MJI.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.MJI.JSObjectReference));
            }
            //--TRIMMABLE-BOUNDARY-END(21475033207)
            
            static $h = 196727;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.IJSObjectReference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885098615),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeToConvert",
          "p": 188547073
        }
      ],
      "n": "CanConvert",
      "d": 196727,
      "h": 12885098615,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885098615),
//--TRIMMABLE-BOUNDARY-START(17180065911),
    {
      "r": 458866,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 196727,
      "h": 17180065911,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180065911),
//--TRIMMABLE-BOUNDARY-START(21475033207),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 458866
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 196727,
      "h": 21475033207,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475033207)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295164023),
    {
      "t": 262263,
      "n": "_jsRuntime",
      "d": 196727,
      "h": 4295164023,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295164023)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131319),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 262263
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196727,
      "h": 8590131319,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131319)
  ],
  "h": 196727
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReferenceJsonConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}WebAssembly${separator}WebAssemblyJSObjectReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196727)
        
        

        //--TRIMMABLE-BOUNDARY-START(131191)
        $asm.$cls(`$mjw.MJW.WebAssemblyJSObjectReference`, ($self) => class WebAssemblyJSObjectReference extends $.$mj.MJI.JSInProcessObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(4295098487)
            /*WebAssemblyJSRuntime*/ _jsRuntime$2 = null;
            //--TRIMMABLE-BOUNDARY-END(4295098487)
            
            //--TRIMMABLE-BOUNDARY-START(8590065783)
            $ctor$3(/*WebAssemblyJSRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor$2(jsRuntime, id);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime$2 = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065783)
            
            static $h = 131191;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mj.MJI.JSInProcessObjectReference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098487),
    {
      "t": 262263,
      "n": "_jsRuntime",
      "o": "@$2",
      "d": 131191,
      "h": 4295098487,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098487)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065783),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 262263
        },
        {
          "n": "id",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131191,
      "h": 8590065783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065783)
  ],
  "h": 131191
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.MJ.IJSInProcessObjectReference, $.$mj.MJ.IJSObjectReference, $.$$.S.IAsyncDisposable, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}WebAssembly${separator}WebAssemblyJSObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131191)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.IO.Pipelines", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encodings.Web", "NetJs.System.Reflection.Emit", "NetJs.System.Text.RegularExpressions", "NetJs.System.Text.Json", "NetJs.Microsoft.JSInterop"));
})();
//--TRIMMABLE-BOUNDARY-END(119)
