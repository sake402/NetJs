
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $sipl, $srn, $ssc, $stew, $sris, $stc, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $srij, $sicb, $sci, $sdd, $srm, $snnr, $sds, $sre, $sns, $sscr, $str, $snn, $snsc, $stj, $snq, $snh, $mj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.JSInterop.WebAssembly", 
    {"h":31,"f":"Microsoft.JSInterop.WebAssembly","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Abstractions and features for interop between .NET WebAssembly and JavaScript code.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.JSInterop.WebAssembly","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.JSInterop.WebAssembly","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.AspNetCore.Components.WebAssembly.Tests","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime", ($self) => class WebAssemblyJSRuntime extends $.$mj.Microsoft.JSInterop.JSInProcessRuntime
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                    this.JsonSerializerOptions.Converters.System$Collections$Generic$IList$$$Insert(0, new $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReferenceJsonConverter().$ctor$1(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                }
                return this;
            }
            /*string */ InvokeJS$1(/*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                return Blazor._internal.invokeJSJson(identifier, targetInstanceId, resultType, argsJson ?? "[]", 0n, 1/*JSCallType.FunctionCall*/);
            }
            /*string */ InvokeJS$2(/*in JSInvocationInfo*/ invocationInfo)
            {
                try
                {
                    return Blazor._internal.invokeJSJson(invocationInfo.$v.Identifier, invocationInfo.$v.TargetInstanceId, invocationInfo.$v.ResultType, invocationInfo.$v.ArgsJson, invocationInfo.$v.AsyncHandle, invocationInfo.$v.CallType);
                }
                catch(ex)
                {
                    throw new $.$mj.Microsoft.JSInterop.JSException().$ctor$6(ex.Message, ex);
                }
            }
            /*void */ BeginInvokeJS$1(/*long*/ asyncHandle, /*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                Blazor._internal.invokeJSJson(identifier, targetInstanceId, resultType, argsJson ?? "[]", asyncHandle, 1/*JSCallType.FunctionCall*/);
            }
            /*void */ BeginInvokeJS$2(/*in JSInvocationInfo*/ invocationInfo)
            {
                Blazor._internal.invokeJSJson(invocationInfo.$v.Identifier, invocationInfo.$v.TargetInstanceId, invocationInfo.$v.ResultType, invocationInfo.$v.ArgsJson, invocationInfo.$v.AsyncHandle, invocationInfo.$v.CallType);
            }
            /*void */ EndInvokeDotNet(/*DotNetInvocationInfo*/ callInfo, /*in DotNetInvocationResult*/ dispatchResult)
            {
                /*var*/ let resultJsonOrErrorMessage = dispatchResult.$v.Success ? dispatchResult.$v.ResultJson : $.$spc.System.Exception.ToString.call(dispatchResult.$v.Exception);
                Blazor._internal.endInvokeDotNetFromJS(callInfo.CallId, dispatchResult.$v.Success, resultJsonOrErrorMessage);
            }
            /*void */ SendByteArray(/*int*/ id, /*byte[]*/ data)
            {
                Blazor._internal.receiveByteArray(id, data);
            }
            static $h = 262175;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2687006,"m":[{"r":1310721,"p":[{"n":"identifier","p":1310721},{"n":"argsJson","p":1310721},{"n":"resultType","p":2359326},{"n":"targetInstanceId","p":917505}],"n":"InvokeJS","o":"@$1","d":262175,"h":8590196767,"f":32772},{"r":1310721,"p":[{"n":"invocationInfo","p":1769502,"f":8}],"n":"InvokeJS","o":"@$2","d":262175,"h":12885164063,"f":32772},{"r":65537,"p":[{"n":"asyncHandle","p":917505},{"n":"identifier","p":1310721},{"n":"argsJson","p":1310721},{"n":"resultType","p":2359326},{"n":"targetInstanceId","p":917505}],"n":"BeginInvokeJS","o":"@$1","d":262175,"h":17180131359,"f":32772},{"r":65537,"p":[{"n":"invocationInfo","p":1769502,"f":8}],"n":"BeginInvokeJS","o":"@$2","d":262175,"h":21475098655,"f":32772},{"r":65537,"p":[{"n":"callInfo","p":1245214},{"n":"dispatchResult","p":1310750,"f":8}],"n":"EndInvokeDotNet","d":262175,"h":25770065951,"f":32772},{"r":65537,"p":[{"n":"id","p":655361},{"n":"data","p":0}],"n":"SendByteArray","d":262175,"h":30065033247,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":262175,"h":4295229471,"f":4}],"i":[57475073,393246,524318],"h":262175}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.JSInProcessRuntime; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$mj.Microsoft.JSInterop.IJSInProcessRuntime, $.$mj.Microsoft.JSInterop.IJSRuntime ]; }
            static get $fullName() { return `WebAssemblyJSRuntime`; }
        });
        
        $asm.$cls("$mjw.Microsoft.JSInterop.JSCallResultTypeHelper", ($self) => class JSCallResultTypeHelper
        {
            /*Assembly*/ static _currentAssembly = null;
            static /*JSCallResultType */ FromGeneric(TResult, )
            {
                if ($.$spc.System.Reflection.Assembly.op_Equality(TResult.$type.Assembly, $.$mjw.Microsoft.JSInterop.JSCallResultTypeHelper._currentAssembly))
                {
                    if ($.$spc.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSObjectReference.$type) || $.$spc.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference.$type))
                    {
                        return 1/*JSCallResultType.JSObjectReference*/;
                    }
                    else if ($.$spc.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSStreamReference.$type))
                    {
                        return 2/*JSCallResultType.JSStreamReference*/;
                    }
                    else if ($.$spc.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult.$type))
                    {
                        return 3/*JSCallResultType.JSVoidResult*/;
                    }
                }
                return 0/*JSCallResultType.Default*/;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._currentAssembly = $.$mj.Microsoft.JSInterop.JSCallResultType.$type.Assembly;
                }
            }
            static $h = 65567;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":2359326,"g":["TResult"],"n":"FromGeneric","d":65567,"h":8590000159,"f":131105}],"l":[{"t":73465857,"n":"_currentAssembly","d":65567,"h":4295032863,"f":34}],"h":65567}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JSCallResultTypeHelper`; }
        });
        
        $asm.$cls("$mjw.WebAssembly.JSInterop.InternalCalls", ($self) => class InternalCalls
        {
            static $h = 327711;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":327711}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `InternalCalls`; }
        });
        
        $asm.$str("$mjw.WebAssembly.JSInterop.JSCallInfo", ($self) => class JSCallInfo extends $.$spc.System.ValueType
        {
            /*string*/  get FunctionIdentifier() { return this.$getField(0, 4); }
            /*string*/  set FunctionIdentifier(value) { this.$setField(0, 4, value); }
            /*JSCallResultType*/  get ResultType() { return this.$getField(4, 4); }
            /*JSCallResultType*/  set ResultType(value) { this.$setField(4, 4, value); }
            /*string*/  get MarshalledCallArgsJson() { return this.$getField(8, 4); }
            /*string*/  set MarshalledCallArgsJson(value) { this.$setField(8, 4, value); }
            /*long*/  get MarshalledCallAsyncHandle() { return this.$getField(12, 8); }
            /*long*/  set MarshalledCallAsyncHandle(value) { this.$setField(12, 8, value); }
            /*long*/  get TargetInstanceId() { return this.$getField(20, 8); }
            /*long*/  set TargetInstanceId(value) { this.$setField(20, 8, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.FunctionIdentifier = this.FunctionIdentifier;
                copy.ResultType = this.ResultType;
                copy.MarshalledCallArgsJson = this.MarshalledCallArgsJson;
                copy.MarshalledCallAsyncHandle = this.MarshalledCallAsyncHandle;
                copy.TargetInstanceId = this.TargetInstanceId;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.FunctionIdentifier = null;
                this.ResultType = 0;
                this.MarshalledCallArgsJson = null;
                this.MarshalledCallAsyncHandle = 0n;
                this.TargetInstanceId = 0n;
            }
            static $h = 393247;
            static $z = 28;
            static $f = 0b100000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1310721,"n":"FunctionIdentifier","d":393247,"h":4295360543,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":2359326,"n":"ResultType","d":393247,"h":8590327839,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":1310721,"n":"MarshalledCallArgsJson","d":393247,"h":12885295135,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":8,"t":655361}]}]},{"t":917505,"n":"MarshalledCallAsyncHandle","d":393247,"h":17180262431,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":12,"t":655361}]}]},{"t":917505,"n":"TargetInstanceId","d":393247,"h":21475229727,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":20,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":393247,"h":25770197023,"f":1}],"h":393247,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":4,"t":655361}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `JSCallInfo`; }
        });
        
        $asm.$cls("$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReferenceJsonConverter", ($self) => class WebAssemblyJSObjectReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSObjectReference)
        {
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            $ctor$1(/*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                return $.$spc.System.Type.op_Equality$1(typeToConvert, $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReference.$type) || $.$spc.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.IJSObjectReference.$type) || $.$spc.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference.$type);
            }
            /*IJSObjectReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                /*var*/ let id = $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.ReadJSObjectReferenceIdentifier(reader);
                if (id === BigInt(-1))
                {
                    return null;
                }
                return new $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReference().$ctor$3(this._jsRuntime, id);
            }
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSObjectReference*/ value, /*JsonSerializerOptions*/ options)
            {
                $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference));
            }
            static $h = 196639;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"typeToConvert","p":142606337}],"n":"CanConvert","d":196639,"h":12885098527,"f":32769},{"r":458782,"p":[{"n":"reader","p":18990031,"f":4},{"n":"typeToConvert","p":142606337},{"n":"options","p":3392463}],"n":"Read","d":196639,"h":17180065823,"f":32769},{"r":65537,"p":[{"n":"writer","p":19121103},{"n":"value","p":458782},{"n":"options","p":3392463}],"n":"Write","d":196639,"h":21475033119,"f":32769}],"l":[{"t":262175,"n":"_jsRuntime","d":196639,"h":4295163935,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":262175}],"n":".ctor","o":"$ctor$1","d":196639,"h":8590131231,"f":1}],"h":196639}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSObjectReference); }
            static get $fullName() { return `WebAssemblyJSObjectReferenceJsonConverter`; }
        });
        
        $asm.$cls("$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSObjectReference", ($self) => class WebAssemblyJSObjectReference extends $.$mj.Microsoft.JSInterop.Implementation.JSInProcessObjectReference
        {
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            $ctor$3(/*WebAssemblyJSRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor$2(jsRuntime, id);
                {
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            static $h = 131103;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":655390,"l":[{"t":262175,"n":"_jsRuntime","d":131103,"h":4295098399,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":262175},{"n":"id","p":917505}],"n":".ctor","o":"$ctor$3","d":131103,"h":8590065695,"f":1}],"i":[327710,458782,56885249,57475073],"h":131103}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.Implementation.JSInProcessObjectReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference, $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$spc.System.IAsyncDisposable, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `WebAssemblyJSObjectReference`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.IO.Pipelines", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Text.Encodings.Web", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.System.Text.Json", "NetJs.System.Net.Quic", "NetJs.System.Net.Http", "NetJs.Microsoft.JSInterop"))