
//--TRIMMABLE-BOUNDARY-START(114)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $sipl, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $sre, $srei, $srel, $srp, $srl, $stew, $str, $stj) {
    "use strict";
    let _;
    let $nrpRha;
    let $ovjPgj;
    let $iiWJCg;
    let $CoDrda;
    let $plbJPe;
    let $WlpHik;
    let $QEvxKh;
    let $LgoHOh;
    
    
    
	$.$asm(
    "NetJs.Microsoft.JSInterop", 
    {
  "h": 114,
  "f": "Microsoft.JSInterop",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Abstractions and features for interop between .NET and JavaScript code.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.JSInterop",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.JSInterop",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.JSInterop.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.WebAssembly.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 116457473,
      "c": 8706392065,
      "a": [
        {
          "v": 1179762,
          "t": 188547073
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1638514)
        $asm.$cls(`$mj.MJI$1.IJSVoidResult`, ($self) => class IJSVoidResult
        {
            static $h = 1638514;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1638514,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.IJSVoidResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}IJSVoidResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638514)
        
        

        //--TRIMMABLE-BOUNDARY-START(524402)
        $asm.$cls(`$mj.MJ.IJSRuntime`, ($self) => class IJSRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(21475360882)
            /*ValueTask<IJSObjectReference> */ MJ$IJSRuntime$InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360882);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360882)
            
            //--TRIMMABLE-BOUNDARY-START(25770328178)
            /*ValueTask<IJSObjectReference> */ MJ$IJSRuntime$InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328178);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770328178)
            
            //--TRIMMABLE-BOUNDARY-START(8590458994)
            /*ValueTask<TValue> */ MJ$IJSRuntime$GetValueAsync$1(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458994);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590458994)
            
            //--TRIMMABLE-BOUNDARY-START(4295491698)
            /*ValueTask<TValue> */ MJ$IJSRuntime$GetValueAsync(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491698);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295491698)
            
            //--TRIMMABLE-BOUNDARY-START(34360262770)
            /*ValueTask */ MJ$IJSRuntime$SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262770);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262770)
            
            //--TRIMMABLE-BOUNDARY-START(30065295474)
            /*ValueTask */ MJ$IJSRuntime$SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295474);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065295474)
            
            static $h = 524402;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885426290),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "MJ$IJSRuntime$InvokeAsync",
      "d": 524402,
      "h": 12885426290,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(12885426290),
//--TRIMMABLE-BOUNDARY-START(17180393586),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "MJ$IJSRuntime$InvokeAsync$1",
      "d": 524402,
      "h": 17180393586,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(17180393586),
//--TRIMMABLE-BOUNDARY-START(21475360882),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "MJ$IJSRuntime$InvokeConstructorAsync",
      "d": 524402,
      "h": 21475360882,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475360882),
//--TRIMMABLE-BOUNDARY-START(25770328178),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "MJ$IJSRuntime$InvokeConstructorAsync$1",
      "d": 524402,
      "h": 25770328178,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770328178),
//--TRIMMABLE-BOUNDARY-START(8590458994),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "MJ$IJSRuntime$GetValueAsync$1",
      "d": 524402,
      "h": 8590458994,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(8590458994),
//--TRIMMABLE-BOUNDARY-START(4295491698),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "MJ$IJSRuntime$GetValueAsync",
      "d": 524402,
      "h": 4295491698,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(4295491698),
//--TRIMMABLE-BOUNDARY-START(34360262770),
    {
      "r": 181338113,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "MJ$IJSRuntime$SetValueAsync$1",
      "d": 524402,
      "h": 34360262770,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(34360262770),
//--TRIMMABLE-BOUNDARY-START(30065295474),
    {
      "r": 181338113,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "MJ$IJSRuntime$SetValueAsync",
      "d": 524402,
      "h": 30065295474,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(30065295474)
  ],
  "h": 524402
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.IJSRuntime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}IJSRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524402)
        
        

        //--TRIMMABLE-BOUNDARY-START(589938)
        $asm.$cls(`$mj.MJ.IJSStreamReference`, ($self) => class IJSStreamReference
        {
            static $h = 589938;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885491826),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590524530,
        "f": 50331905
      },
      "n": "Length",
      "o": "MJ$IJSStreamReference$Length",
      "d": 589938,
      "h": 12885491826,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885491826)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459122),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SI.Stream).$h,
      "p": [
        {
          "n": "maxAllowedSize",
          "p": 917505,
          "f": 65,
          "v": 512000
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "OpenReadStreamAsync",
      "o": "MJ$IJSStreamReference$OpenReadStreamAsync",
      "d": 589938,
      "h": 17180459122,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180459122)
  ],
  "h": 589938
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.IJSStreamReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}IJSStreamReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589938)
        
        

        //--TRIMMABLE-BOUNDARY-START(458866)
        $asm.$cls(`$mj.MJ.IJSObjectReference`, ($self) => class IJSObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(21475295346)
            /*ValueTask<IJSObjectReference> */ MJ$IJSObjectReference$InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475295346);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475295346)
            
            //--TRIMMABLE-BOUNDARY-START(25770262642)
            /*ValueTask<IJSObjectReference> */ MJ$IJSObjectReference$InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770262642);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770262642)
            
            //--TRIMMABLE-BOUNDARY-START(8590393458)
            /*ValueTask<TValue> */ MJ$IJSObjectReference$GetValueAsync$1(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393458);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590393458)
            
            //--TRIMMABLE-BOUNDARY-START(4295426162)
            /*ValueTask<TValue> */ MJ$IJSObjectReference$GetValueAsync(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426162);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426162)
            
            //--TRIMMABLE-BOUNDARY-START(34360197234)
            /*ValueTask */ MJ$IJSObjectReference$SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360197234);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360197234)
            
            //--TRIMMABLE-BOUNDARY-START(30065229938)
            /*ValueTask */ MJ$IJSObjectReference$SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065229938);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065229938)
            
            static $h = 458866;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360754),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "MJ$IJSObjectReference$InvokeAsync",
      "d": 458866,
      "h": 12885360754,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(12885360754),
//--TRIMMABLE-BOUNDARY-START(17180328050),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "MJ$IJSObjectReference$InvokeAsync$1",
      "d": 458866,
      "h": 17180328050,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(17180328050),
//--TRIMMABLE-BOUNDARY-START(21475295346),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "MJ$IJSObjectReference$InvokeConstructorAsync",
      "d": 458866,
      "h": 21475295346,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475295346),
//--TRIMMABLE-BOUNDARY-START(25770262642),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "MJ$IJSObjectReference$InvokeConstructorAsync$1",
      "d": 458866,
      "h": 25770262642,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770262642),
//--TRIMMABLE-BOUNDARY-START(8590393458),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "MJ$IJSObjectReference$GetValueAsync$1",
      "d": 458866,
      "h": 8590393458,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(8590393458),
//--TRIMMABLE-BOUNDARY-START(4295426162),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "MJ$IJSObjectReference$GetValueAsync",
      "d": 458866,
      "h": 4295426162,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(4295426162),
//--TRIMMABLE-BOUNDARY-START(34360197234),
    {
      "r": 181338113,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "MJ$IJSObjectReference$SetValueAsync$1",
      "d": 458866,
      "h": 34360197234,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(34360197234),
//--TRIMMABLE-BOUNDARY-START(30065229938),
    {
      "r": 181338113,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "MJ$IJSObjectReference$SetValueAsync",
      "d": 458866,
      "h": 30065229938,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(30065229938)
  ],
  "h": 458866
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.IJSObjectReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}IJSObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458866)
        
        

        //--TRIMMABLE-BOUNDARY-START(393330)
        $asm.$cls(`$mj.MJ.IJSInProcessRuntime`, ($self) => class IJSInProcessRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(12885295218)
            /*IJSInProcessObjectReference */ MJ$IJSInProcessRuntime$InvokeConstructor(/*string*/ identifier, /*params object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295218);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885295218)
            
            //--TRIMMABLE-BOUNDARY-START(4295360626)
            /*TValue */ MJ$IJSInProcessRuntime$GetValue(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360626);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360626)
            
            //--TRIMMABLE-BOUNDARY-START(17180262514)
            /*void */ MJ$IJSInProcessRuntime$SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262514);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262514)
            
            static $h = 393330;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327922),
    {
      "r": (TResult) => TResult.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "Invoke",
      "o": "MJ$IJSInProcessRuntime$Invoke",
      "d": 393330,
      "h": 8590327922,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590327922),
//--TRIMMABLE-BOUNDARY-START(12885295218),
    {
      "r": 327794,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeConstructor",
      "o": "MJ$IJSInProcessRuntime$InvokeConstructor",
      "d": 393330,
      "h": 12885295218,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885295218),
//--TRIMMABLE-BOUNDARY-START(4295360626),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValue",
      "o": "MJ$IJSInProcessRuntime$GetValue",
      "d": 393330,
      "h": 4295360626,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(4295360626),
//--TRIMMABLE-BOUNDARY-START(17180262514),
    {
      "r": 65537,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValue",
      "o": "MJ$IJSInProcessRuntime$SetValue",
      "d": 393330,
      "h": 17180262514,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(17180262514)
  ],
  "h": 393330
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.MJ.IJSRuntime ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.IJSInProcessRuntime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}IJSInProcessRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393330)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572978)
        $asm.$cls(`$mj.MJI$1.IDotNetObjectReference`, ($self) => class IDotNetObjectReference
        {
            static $h = 1572978;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886474866),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591507570,
        "f": 50331905
      },
      "n": "Value",
      "o": "MJI$1$IDotNetObjectReference$Value",
      "d": 1572978,
      "h": 12886474866,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886474866)
  ],
  "h": 1572978
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.IDotNetObjectReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}IDotNetObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572978)
        
        

        //--TRIMMABLE-BOUNDARY-START(327794)
        $asm.$cls(`$mj.MJ.IJSInProcessObjectReference`, ($self) => class IJSInProcessObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(12885229682)
            /*IJSInProcessObjectReference */ MJ$IJSInProcessObjectReference$InvokeConstructor(/*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229682);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885229682)
            
            //--TRIMMABLE-BOUNDARY-START(4295295090)
            /*TValue */ MJ$IJSInProcessObjectReference$GetValue(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295090);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295295090)
            
            //--TRIMMABLE-BOUNDARY-START(17180196978)
            /*void */ MJ$IJSInProcessObjectReference$SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196978);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180196978)
            
            static $h = 327794;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590262386),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Invoke",
      "o": "MJ$IJSInProcessObjectReference$Invoke",
      "d": 327794,
      "h": 8590262386,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590262386),
//--TRIMMABLE-BOUNDARY-START(12885229682),
    {
      "r": 327794,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructor",
      "o": "MJ$IJSInProcessObjectReference$InvokeConstructor",
      "d": 327794,
      "h": 12885229682,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885229682),
//--TRIMMABLE-BOUNDARY-START(4295295090),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValue",
      "o": "MJ$IJSInProcessObjectReference$GetValue",
      "d": 327794,
      "h": 4295295090,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(4295295090),
//--TRIMMABLE-BOUNDARY-START(17180196978),
    {
      "r": 65537,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValue",
      "o": "MJ$IJSInProcessObjectReference$SetValue",
      "d": 327794,
      "h": 17180196978,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(17180196978)
  ],
  "h": 327794
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.MJ.IJSObjectReference, $.$$.S.IAsyncDisposable, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.IJSInProcessObjectReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}IJSInProcessObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327794)
        
        

        //--TRIMMABLE-BOUNDARY-START(2949234)
        $asm.$cls(`$mj.MJ.JSRuntime`, ($self) => class JSRuntime extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(184686542962)
            /*long*/ static WindowObjectId = 0n;
            //--TRIMMABLE-BOUNDARY-END(184686542962)
            
            //--TRIMMABLE-BOUNDARY-START(8592883826)
            /*long*/ _nextObjectReferenceId = 0n;
            //--TRIMMABLE-BOUNDARY-END(8592883826)
            
            //--TRIMMABLE-BOUNDARY-START(12887851122)
            /*long*/ _nextPendingTaskId = 1n;
            //--TRIMMABLE-BOUNDARY-END(12887851122)
            
            //--TRIMMABLE-BOUNDARY-START(17182818418)
            /*ConcurrentDictionary<long, object>*/ _pendingTasks = null;
            //--TRIMMABLE-BOUNDARY-END(17182818418)
            
            //--TRIMMABLE-BOUNDARY-START(21477785714)
            /*ConcurrentDictionary<long, IDotNetObjectReference>*/ _trackedRefsById = null;
            //--TRIMMABLE-BOUNDARY-END(21477785714)
            
            //--TRIMMABLE-BOUNDARY-START(4297916530)
            /*ConcurrentDictionary<long, CancellationTokenRegistration>*/ _cancellationRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(4297916530)
            
            //--TRIMMABLE-BOUNDARY-START(55837524082)
            /*ArrayBuilder<byte[]>*/ ByteArraysToBeRevived = null;
            //--TRIMMABLE-BOUNDARY-END(55837524082)
            
            //--TRIMMABLE-BOUNDARY-START(34362687602)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362687602);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JsonSerializerOptions = (() =>
                    {
                        //new $.$stj.STJ.JsonSerializerOptions()
                        const $t1 = $.$stj.STJ.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.MaxDepth = 32;
                        $i1.PropertyNamingPolicy = $.$stj.STJ.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.Converters.SCG$ICollection$$$Add(new $.$mj.MJI$1.DotNetObjectReferenceJsonConverterFactory().$ctor$3(this));
                        $i1.Converters.SCG$ICollection$$$Add(new $.$mj.MJI$1.JSObjectReferenceJsonConverter().$ctor$3(this));
                        $i1.Converters.SCG$ICollection$$$Add(new $.$mj.MJI$1.JSStreamReferenceJsonConverter().$ctor$3(this));
                        $i1.Converters.SCG$ICollection$$$Add(new $.$mj.MJI$1.DotNetStreamReferenceJsonConverter().$ctor$3(this));
                        $i1.Converters.SCG$ICollection$$$Add(new $.$mj.MJI$1.ByteArrayJsonConverter().$ctor$3(this));
                        return $i1;
                    })();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362687602)
            
            //--TRIMMABLE-BOUNDARY-START(137441902706)
            /*JsonSerializerOptions*/ JsonSerializerOptions = null;
            //--TRIMMABLE-BOUNDARY-END(137441902706)
            
            //--TRIMMABLE-BOUNDARY-START(64427458674)
            /*TimeSpan?*/ DefaultAsyncTimeout = null;
            //--TRIMMABLE-BOUNDARY-END(64427458674)
            
            //--TRIMMABLE-BOUNDARY-START(120262033522)
            /*ValueTask<TValue> */ InvokeAsync$2(TValue, /*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120262033522);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync(TValue, 0n, identifier, 1/*JSCallType.FunctionCall*/, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120262033522)
            
            //--TRIMMABLE-BOUNDARY-START(124557000818)
            /*ValueTask<TValue> */ InvokeAsync$3(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124557000818);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync$1(TValue, 0n, identifier, 1/*JSCallType.FunctionCall*/, cancellationToken, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124557000818)
            
            //--TRIMMABLE-BOUNDARY-START(128851968114)
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128851968114);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync($.$mj.MJ.IJSObjectReference, 0n, identifier, 2/*JSCallType.ConstructorCall*/, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851968114)
            
            //--TRIMMABLE-BOUNDARY-START(133146935410)
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146935410);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync$1($.$mj.MJ.IJSObjectReference, 0n, identifier, 2/*JSCallType.ConstructorCall*/, cancellationToken, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146935410)
            
            //--TRIMMABLE-BOUNDARY-START(107377131634)
            /*ValueTask<TValue> */ GetValueAsync$1(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107377131634);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync(TValue, 0n, identifier, 3/*JSCallType.GetValue*/, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107377131634)
            
            //--TRIMMABLE-BOUNDARY-START(103082164338)
            /*ValueTask<TValue> */ GetValueAsync(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103082164338);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync$1(TValue, 0n, identifier, 3/*JSCallType.GetValue*/, cancellationToken, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103082164338)
            
            //--TRIMMABLE-BOUNDARY-START(171801641074)
            /*ValueTask *//*async*/  SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t2 = this.InvokeAsync($.$mj.MJI$1.IJSVoidResult, 0n, identifier, 4/*JSCallType.SetValue*/, $.$$.SRC.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171801641074)
            
            //--TRIMMABLE-BOUNDARY-START(167506673778)
            /*ValueTask *//*async*/  SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = this.InvokeAsync$1($.$mj.MJI$1.IJSVoidResult, 0n, identifier, 4/*JSCallType.SetValue*/, cancellationToken, $.$$.SRC.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167506673778)
            
            //--TRIMMABLE-BOUNDARY-START(111672098930)
            /*ValueTask<TValue> *//*async*/  InvokeAsync(TValue, /*long*/ targetInstanceId, /*string*/ identifier, /*JSCallType*/ callType, /*object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TValue), TValue, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111672098930);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this.DefaultAsyncTimeout))
                    {
                        /*var*/ let cts = new $.$$.ST$1.CancellationTokenSource().$ctor$4($.$$.S.Nullable$$($.$$.S.TimeSpan).Value$get.call(this.DefaultAsyncTimeout));
                        try
                        {
                            let $t4, $r4;
                            return $.$$.N.AsyncResolver.Result($asnycContext, ($t4 = this.InvokeAsync$1(TValue, targetInstanceId, identifier, callType, cts.Token, args), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4))));
                        }
                        finally
                        {
                            cts?.S$IDisposable$Dispose();
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t5 = this.InvokeAsync$1(TValue, targetInstanceId, identifier, callType, $.$$.ST$1.CancellationToken.None, args), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111672098930)
            
            //--TRIMMABLE-BOUNDARY-START(115967066226)
            /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*long*/ targetInstanceId, /*string*/ identifier, /*JSCallType*/ callType, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967066226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let taskId = $.$$.ST$1.Interlocked.Increment$1($.$ref(() => this._nextPendingTaskId, ($v) => this._nextPendingTaskId = $v, $.$$.S.Int64));
                /*var*/ let tcs = new ($.$$.STT.TaskCompletionSource$$(TValue))().$ctor$1();
                if (cancellationToken.CanBeCanceled)
                {
                    this._cancellationRegistrations.set_Item$1(taskId, cancellationToken.Register$1(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        tcs.TrySetCanceled$1(cancellationToken);
                        this.CleanupTasksAndRegistrations(taskId);
                    }, $iiWJCg ??= {"r":65537,"n":"","d":2949234,"h":0,"f":17825794})));
                }
                this._pendingTasks.set_Item$1(taskId, tcs);
                try
                {
                    if (cancellationToken.IsCancellationRequested)
                    {
                        tcs.TrySetCanceled$1(cancellationToken);
                        this.CleanupTasksAndRegistrations(taskId);
                        return new ($.$$.STT.ValueTask$$(TValue))().$ctor$5(tcs.Task);
                    }
                    /*var*/ let argsJson = !(args === null) && args.length !== 0 ? $.$stj.STJ.JsonSerializer.Serialize$13($.$typeArray($.$$.S.Object), args, this.JsonSerializerOptions) : "[]";
                    /*var*/ let resultType = $.$mj.MJ.JSCallResultTypeHelper.FromGeneric(TValue);
                    /*var*/ let invocationInfo = (() =>
                    {
                        //new $.$mj.MJI$1.JSInvocationInfo()
                        const $t7 = $.$mj.MJI$1.JSInvocationInfo;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.AsyncHandle = taskId;
                        $i7.TargetInstanceId = targetInstanceId;
                        $i7.Identifier = identifier;
                        $i7.CallType = callType;
                        $i7.ResultType = resultType;
                        $i7.ArgsJson = argsJson;
                        return $i7;
                    })();
                    this.BeginInvokeJS($.$ref(() => invocationInfo, ));
                    return new ($.$$.STT.ValueTask$$(TValue))().$ctor$5(tcs.Task);
                }
                catch($e)
                {
                    this.CleanupTasksAndRegistrations(taskId);
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115967066226)
            
            //--TRIMMABLE-BOUNDARY-START(60132491378)
            /*void */ CleanupTasksAndRegistrations(/*long*/ taskId)
            {
                /*var*/ let registration;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132491378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._pendingTasks.TryRemove$1(taskId, $.$discardRef());
                if (this._cancellationRegistrations.TryRemove$1(taskId, $.$ref(() => registration, ($v) => registration = $v, $.$$.ST$1.CancellationTokenRegistration)))
                {
                    registration.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132491378)
            
            //--TRIMMABLE-BOUNDARY-START(47247589490)
            /*void */ BeginInvokeJS$2(/*long*/ taskId, /*string*/ identifier, /*string?*/ argsJson)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47247589490);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.BeginInvokeJS$1(taskId, identifier, argsJson, 0/*JSCallResultType.Default*/, 0n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247589490)
            
            //--TRIMMABLE-BOUNDARY-START(38657654898)
            /*void */ BeginInvokeJS(/*in JSInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657654898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.BeginInvokeJS$1(invocationInfo.$v.AsyncHandle, invocationInfo.$v.Identifier, invocationInfo.$v.ArgsJson, invocationInfo.$v.ResultType, invocationInfo.$v.TargetInstanceId);
            }
            //--TRIMMABLE-BOUNDARY-END(38657654898)
            
            //--TRIMMABLE-BOUNDARY-START(154621771890)
            /*void */ SendByteArray(/*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621771890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12("JSRuntime subclasses are responsible for implementing byte array transfer to JS.");
            }
            //--TRIMMABLE-BOUNDARY-END(154621771890)
            
            //--TRIMMABLE-BOUNDARY-START(146031837298)
            /*void */ ReceiveByteArray(/*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031837298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (id === 0)
                {
                    this.ByteArraysToBeRevived.Clear();
                }
                if (id !== this.ByteArraysToBeRevived.Count)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$17(`Element id '${$.$strNN(id)}' cannot be added to the byte arrays to be revived with length '${$.$strNN(this.ByteArraysToBeRevived.Count)}'.`, null);
                }
                this.ByteArraysToBeRevived.Append($.$ref(() => data, ));
            }
            //--TRIMMABLE-BOUNDARY-END(146031837298)
            
            //--TRIMMABLE-BOUNDARY-START(141736870002)
            /*Task<Stream> */ ReadJSDataAsStreamAsync(/*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736870002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12("The current JavaScript runtime does not support reading data streams.");
            }
            //--TRIMMABLE-BOUNDARY-END(141736870002)
            
            //--TRIMMABLE-BOUNDARY-START(77312360562)
            /*bool */ EndInvokeJS(/*long*/ taskId, /*bool*/ succeeded, /*ref Utf8JsonReader*/ jsonReader)
            {
                /*var*/ let tcs;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312360562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._pendingTasks.TryRemove$1(taskId, $.$ref(() => tcs, ($v) => tcs = $v, $.$$.S.Object)))
                {
                    return false;
                }
                this.CleanupTasksAndRegistrations(taskId);
                try
                {
                    if (succeeded)
                    {
                        /*var*/ let resultType = $.$mj.MJI$1.TaskGenericsUtil.GetTaskCompletionSourceResultType(tcs);
                        /*var*/ let result = $.$stj.STJ.JsonSerializer.Deserialize$1(jsonReader, resultType, this.JsonSerializerOptions);
                        this.ByteArraysToBeRevived.Clear();
                        $.$mj.MJI$1.TaskGenericsUtil.SetTaskCompletionSourceResult(tcs, result);
                    }
                    else 
                    {
                        /*var*/ let exceptionText = jsonReader.$v.GetString() ?? $.$$.S.String.Empty;
                        $.$mj.MJI$1.TaskGenericsUtil.SetTaskCompletionSourceException(tcs, new $.$mj.MJ.JSException().$ctor$6(exceptionText));
                    }
                    return true;
                }
                catch(exception)
                {
                    /*var*/ let message = `An exception occurred executing JS interop: ${$.$strNN(exception.Message)}. See InnerException for more details.`;
                    $.$mj.MJI$1.TaskGenericsUtil.SetTaskCompletionSourceException(tcs, new $.$mj.MJ.JSException().$ctor$5(message, exception));
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77312360562)
            
            //--TRIMMABLE-BOUNDARY-START(180391575666)
            /*Task */ TransmitStreamAsync(/*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391575666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!dotNetStreamReference.LeaveOpen)
                {
                    dotNetStreamReference.Stream.Dispose();
                }
                throw new $.$$.S.NotSupportedException().$ctor$12("The current JS runtime does not support sending streams from .NET to JS.");
            }
            //--TRIMMABLE-BOUNDARY-END(180391575666)
            
            //--TRIMMABLE-BOUNDARY-START(51542556786)
            /*long */ BeginTransmittingStream(/*DotNetStreamReference*/ dotNetStreamReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542556786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let streamId = $.$$.ST$1.Interlocked.Increment$1($.$ref(() => this._nextObjectReferenceId, ($v) => this._nextObjectReferenceId = $v, $.$$.S.Int64));
                _ = this.TransmitStreamAsync(streamId, dotNetStreamReference);
                return streamId;
            }
            //--TRIMMABLE-BOUNDARY-END(51542556786)
            
            //--TRIMMABLE-BOUNDARY-START(176096608370)
            /*long */ TrackObjectReference(TValue, /*DotNetObjectReference<TValue>*/ dotNetObjectReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096608370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(dotNetObjectReference, "dotNetObjectReference");
                dotNetObjectReference.ThrowIfDisposed();
                /*var*/ let jsRuntime = dotNetObjectReference.JSRuntime;
                if (jsRuntime === null)
                {
                    /*var*/ let dotNetObjectId = $.$$.ST$1.Interlocked.Increment$1($.$ref(() => this._nextObjectReferenceId, ($v) => this._nextObjectReferenceId = $v, $.$$.S.Int64));
                    dotNetObjectReference.JSRuntime = this;
                    dotNetObjectReference.ObjectId = dotNetObjectId;
                    this._trackedRefsById.set_Item$1(dotNetObjectId, dotNetObjectReference);
                }
                else if (!$.$$.S.Object.ReferenceEquals(this, jsRuntime))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$strNN(`${$.$strNN($.$$.S.Object.GetType.call(dotNetObjectReference).Name)} is already being tracked by a different instance of ${$.$strNN("JSRuntime")}.`) + $.$strNN(` A common cause is caching an instance of ${$.$strNN("DotNetObjectReference")} globally. Consider creating instances of ${$.$strNN("DotNetObjectReference")} at the JSInterop callsite.`));
                }
                $.$$.SD.Debug.Assert$4(dotNetObjectReference.ObjectId !== 0n, "dotNetObjectReference.ObjectId != 0");
                return dotNetObjectReference.ObjectId;
            }
            //--TRIMMABLE-BOUNDARY-END(176096608370)
            
            //--TRIMMABLE-BOUNDARY-START(98787197042)
            /*IDotNetObjectReference */ GetObjectReference(/*long*/ dotNetObjectId)
            {
                /*var*/ let dotNetObjectRef;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787197042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._trackedRefsById.TryGetValue(dotNetObjectId, $.$ref(() => dotNetObjectRef, ($v) => dotNetObjectRef = $v, $.$mj.MJI$1.IDotNetObjectReference)) ? dotNetObjectRef : (() =>
                {
        throw new $.$$.S.ArgumentException().$ctor$13(`There is no tracked object with id '${$.$strNN(dotNetObjectId)}'. Perhaps the DotNetObjectReference instance was already disposed.`, "dotNetObjectId")        })();
            }
            //--TRIMMABLE-BOUNDARY-END(98787197042)
            
            //--TRIMMABLE-BOUNDARY-START(150326804594)
            /*void */ ReleaseObjectReference(/*long*/ dotNetObjectId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150326804594);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._trackedRefsById.TryRemove$1(dotNetObjectId, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150326804594)
            
            //--TRIMMABLE-BOUNDARY-START(68722425970)
            /*void */ Dispose()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68722425970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ByteArraysToBeRevived.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722425970)
            
            //--TRIMMABLE-BOUNDARY-START(12885426290)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeAsync<TValue>(string, object?[]?)
            MJ$IJSRuntime$InvokeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885426290)
            
            //--TRIMMABLE-BOUNDARY-START(17180393586)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeAsync<TValue>(string, System.Threading.CancellationToken, object?[]?)
            MJ$IJSRuntime$InvokeAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180393586)
            
            //--TRIMMABLE-BOUNDARY-START(21475360882)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeConstructorAsync(string, object?[]?)
            MJ$IJSRuntime$InvokeConstructorAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructorAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475360882)
            
            //--TRIMMABLE-BOUNDARY-START(25770328178)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeConstructorAsync(string, System.Threading.CancellationToken, object?[]?)
            MJ$IJSRuntime$InvokeConstructorAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructorAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770328178)
            
            //--TRIMMABLE-BOUNDARY-START(8590458994)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.GetValueAsync<TValue>(string)
            MJ$IJSRuntime$GetValueAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590458994)
            
            //--TRIMMABLE-BOUNDARY-START(4295491698)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.GetValueAsync<TValue>(string, System.Threading.CancellationToken)
            MJ$IJSRuntime$GetValueAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295491698)
            
            //--TRIMMABLE-BOUNDARY-START(34360262770)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.SetValueAsync<TValue>(string, TValue)
            MJ$IJSRuntime$SetValueAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValueAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360262770)
            
            //--TRIMMABLE-BOUNDARY-START(30065295474)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.SetValueAsync<TValue>(string, TValue, System.Threading.CancellationToken)
            MJ$IJSRuntime$SetValueAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValueAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065295474)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(34362687602)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34362687602)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17182818418)
                this._pendingTasks = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int64, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17182818418)
                
                //--TRIMMABLE-BOUNDARY-START(21477785714)
                this._trackedRefsById = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int64, $.$mj.MJI$1.IDotNetObjectReference))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(21477785714)
                
                //--TRIMMABLE-BOUNDARY-START(4297916530)
                this._cancellationRegistrations = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int64, $.$$.ST$1.CancellationTokenRegistration))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4297916530)
                
                //--TRIMMABLE-BOUNDARY-START(55837524082)
                this.ByteArraysToBeRevived = new ($.$mj.MJI$1.ArrayBuilder$$($.$typeArray($.$$.S.Byte)))().$ctor$1(32, null);
                //--TRIMMABLE-BOUNDARY-END(55837524082)
                
                //--TRIMMABLE-BOUNDARY-START(64427458674)
                this.DefaultAsyncTimeout = null;
                //--TRIMMABLE-BOUNDARY-END(64427458674)
                
            }
            static $h = 2949234;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137441902706),
    {
      "p": 3342420,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492229746,
        "f": 50331664
      },
      "n": "JsonSerializerOptions",
      "d": 2949234,
      "h": 137441902706,
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(137441902706),
//--TRIMMABLE-BOUNDARY-START(64427458674),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902295154,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163211706482,
        "f": 83886084
      },
      "n": "DefaultAsyncTimeout",
      "d": 2949234,
      "h": 64427458674,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(64427458674)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120262033522),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 2949234,
      "h": 120262033522,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(120262033522),
//--TRIMMABLE-BOUNDARY-START(124557000818),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$3",
      "d": 2949234,
      "h": 124557000818,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(124557000818),
//--TRIMMABLE-BOUNDARY-START(128851968114),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "d": 2949234,
      "h": 128851968114,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128851968114),
//--TRIMMABLE-BOUNDARY-START(133146935410),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$1",
      "d": 2949234,
      "h": 133146935410,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133146935410),
//--TRIMMABLE-BOUNDARY-START(107377131634),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "@$1",
      "d": 2949234,
      "h": 107377131634,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(107377131634),
//--TRIMMABLE-BOUNDARY-START(103082164338),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "d": 2949234,
      "h": 103082164338,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(103082164338),
//--TRIMMABLE-BOUNDARY-START(171801641074),
    {
      "r": 181338113,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "@$1",
      "d": 2949234,
      "h": 171801641074,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(171801641074),
//--TRIMMABLE-BOUNDARY-START(167506673778),
    {
      "r": 181338113,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "d": 2949234,
      "h": 167506673778,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(167506673778),
//--TRIMMABLE-BOUNDARY-START(111672098930),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "targetInstanceId",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "callType",
          "p": 1704050
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "d": 2949234,
      "h": 111672098930,
      "f": 16912392
    },
//--TRIMMABLE-BOUNDARY-END(111672098930),
//--TRIMMABLE-BOUNDARY-START(115967066226),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "targetInstanceId",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "callType",
          "p": 1704050
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 2949234,
      "h": 115967066226,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(115967066226),
//--TRIMMABLE-BOUNDARY-START(60132491378),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskId",
          "p": 917505
        }
      ],
      "n": "CleanupTasksAndRegistrations",
      "d": 2949234,
      "h": 60132491378,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60132491378),
//--TRIMMABLE-BOUNDARY-START(47247589490),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskId",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "BeginInvokeJS",
      "o": "@$2",
      "d": 2949234,
      "h": 47247589490,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(47247589490),
//--TRIMMABLE-BOUNDARY-START(42952622194),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskId",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        },
        {
          "n": "resultType",
          "p": 2359410
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        }
      ],
      "n": "BeginInvokeJS",
      "o": "@$1",
      "d": 2949234,
      "h": 42952622194,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(42952622194),
//--TRIMMABLE-BOUNDARY-START(38657654898),
    {
      "r": 65537,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1769586,
          "f": 8
        }
      ],
      "n": "BeginInvokeJS",
      "d": 2949234,
      "h": 38657654898,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(38657654898),
//--TRIMMABLE-BOUNDARY-START(73017393266),
    {
      "r": 65537,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1245298
        },
        {
          "n": "invocationResult",
          "p": 1310834,
          "f": 8
        }
      ],
      "n": "EndInvokeDotNet",
      "d": 2949234,
      "h": 73017393266,
      "f": 16777488
    },
//--TRIMMABLE-BOUNDARY-END(73017393266),
//--TRIMMABLE-BOUNDARY-START(154621771890),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SendByteArray",
      "d": 2949234,
      "h": 154621771890,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(154621771890),
//--TRIMMABLE-BOUNDARY-START(146031837298),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "ReceiveByteArray",
      "d": 2949234,
      "h": 146031837298,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(146031837298),
//--TRIMMABLE-BOUNDARY-START(141736870002),
    {
      "r": $.$$.STT.Task$$($.$$.SI.Stream).$h,
      "p": [
        {
          "n": "jsStreamReference",
          "p": 589938
        },
        {
          "n": "totalLength",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadJSDataAsStreamAsync",
      "d": 2949234,
      "h": 141736870002,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(141736870002),
//--TRIMMABLE-BOUNDARY-START(77312360562),
    {
      "r": 262145,
      "p": [
        {
          "n": "taskId",
          "p": 917505
        },
        {
          "n": "succeeded",
          "p": 262145
        },
        {
          "n": "jsonReader",
          "p": 19333204,
          "f": 4
        }
      ],
      "n": "EndInvokeJS",
      "d": 2949234,
      "h": 77312360562,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77312360562),
//--TRIMMABLE-BOUNDARY-START(180391575666),
    {
      "r": 178454529,
      "p": [
        {
          "n": "streamId",
          "p": 917505
        },
        {
          "n": "dotNetStreamReference",
          "p": 262258
        }
      ],
      "n": "TransmitStreamAsync",
      "d": 2949234,
      "h": 180391575666,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(180391575666),
//--TRIMMABLE-BOUNDARY-START(51542556786),
    {
      "r": 917505,
      "p": [
        {
          "n": "dotNetStreamReference",
          "p": 262258
        }
      ],
      "n": "BeginTransmittingStream",
      "d": 2949234,
      "h": 51542556786,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51542556786),
//--TRIMMABLE-BOUNDARY-START(176096608370),
    {
      "r": 917505,
      "p": [
        {
          "n": "dotNetObjectReference",
          "p": (TValue) => $.$mj.MJ.DotNetObjectReference$$(TValue).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "TrackObjectReference",
      "d": 2949234,
      "h": 176096608370,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(176096608370),
//--TRIMMABLE-BOUNDARY-START(98787197042),
    {
      "r": 1572978,
      "p": [
        {
          "n": "dotNetObjectId",
          "p": 917505
        }
      ],
      "n": "GetObjectReference",
      "d": 2949234,
      "h": 98787197042,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98787197042),
//--TRIMMABLE-BOUNDARY-START(150326804594),
    {
      "r": 65537,
      "p": [
        {
          "n": "dotNetObjectId",
          "p": 917505
        }
      ],
      "n": "ReleaseObjectReference",
      "d": 2949234,
      "h": 150326804594,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150326804594),
//--TRIMMABLE-BOUNDARY-START(68722425970),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2949234,
      "h": 68722425970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68722425970)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(184686542962),
    {
      "t": 917505,
      "n": "WindowObjectId",
      "d": 2949234,
      "h": 184686542962,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184686542962),
//--TRIMMABLE-BOUNDARY-START(8592883826),
    {
      "t": 917505,
      "n": "_nextObjectReferenceId",
      "d": 2949234,
      "h": 8592883826,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592883826),
//--TRIMMABLE-BOUNDARY-START(12887851122),
    {
      "t": 917505,
      "n": "_nextPendingTaskId",
      "d": 2949234,
      "h": 12887851122,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887851122),
//--TRIMMABLE-BOUNDARY-START(17182818418),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int64, $.$$.S.Object).$h,
      "n": "_pendingTasks",
      "d": 2949234,
      "h": 17182818418,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182818418),
//--TRIMMABLE-BOUNDARY-START(21477785714),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int64, $.$mj.MJI$1.IDotNetObjectReference).$h,
      "n": "_trackedRefsById",
      "d": 2949234,
      "h": 21477785714,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477785714),
//--TRIMMABLE-BOUNDARY-START(4297916530),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int64, $.$$.ST$1.CancellationTokenRegistration).$h,
      "n": "_cancellationRegistrations",
      "d": 2949234,
      "h": 4297916530,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297916530),
//--TRIMMABLE-BOUNDARY-START(55837524082),
    {
      "t": $.$mj.MJI$1.ArrayBuilder$$($.$typeArray($.$$.S.Byte)).$h,
      "n": "ByteArraysToBeRevived",
      "d": 2949234,
      "h": 55837524082,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(55837524082)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34362687602),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2949234,
      "h": 34362687602,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(34362687602)
  ],
  "h": 2949234
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.MJ.IJSRuntime, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSRuntime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949234)
        
        

        //--TRIMMABLE-BOUNDARY-START(2687090)
        $asm.$cls(`$mj.MJ.JSInProcessRuntime`, ($self) => class JSInProcessRuntime extends $.$mj.MJ.JSRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(42952360050)
            /*long*/ static SyncCallIndicator = 0n;
            //--TRIMMABLE-BOUNDARY-END(42952360050)
            
            //--TRIMMABLE-BOUNDARY-START(17182556274)
            /*TValue */ Invoke$1(TValue, /*string*/ identifier, /*params object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182556274);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Invoke(TValue, identifier, 0n, 1/*JSCallType.FunctionCall*/, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182556274)
            
            //--TRIMMABLE-BOUNDARY-START(21477523570)
            /*IJSInProcessObjectReference */ InvokeConstructor(/*string*/ identifier, /*params object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477523570);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Invoke($.$mj.MJ.IJSInProcessObjectReference, identifier, 0n, 2/*JSCallType.ConstructorCall*/, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477523570)
            
            //--TRIMMABLE-BOUNDARY-START(8592621682)
            /*TValue */ GetValue(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592621682);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Invoke(TValue, identifier, 0n, 3/*JSCallType.GetValue*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592621682)
            
            //--TRIMMABLE-BOUNDARY-START(38657392754)
            /*void */ SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657392754);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Invoke($.$mj.MJI$1.IJSVoidResult, identifier, 0n, 4/*JSCallType.SetValue*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(value, TValue) ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657392754)
            
            //--TRIMMABLE-BOUNDARY-START(12887588978)
            /*TValue */ Invoke(TValue, /*string*/ identifier, /*long*/ targetInstanceId, /*JSCallType*/ callType, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887588978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let argsJson = !(args === null) && args.length !== 0 ? $.$stj.STJ.JsonSerializer.Serialize$13($.$typeArray($.$$.S.Object), args, this.JsonSerializerOptions) : "[]";
                /*var*/ let resultType = $.$mj.MJ.JSCallResultTypeHelper.FromGeneric(TValue);
                /*var*/ let invocationInfo = (() =>
                {
                    //new $.$mj.MJI$1.JSInvocationInfo()
                    const $t1 = $.$mj.MJI$1.JSInvocationInfo;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.AsyncHandle = 0n;
                    $i1.TargetInstanceId = targetInstanceId;
                    $i1.Identifier = identifier;
                    $i1.CallType = callType;
                    $i1.ResultType = resultType;
                    $i1.ArgsJson = argsJson;
                    return $i1;
                })();
                /*var*/ let resultJson = this.InvokeJS($.$ref(() => invocationInfo, ));
                if (resultJson === null)
                {
                    return $.$default(TValue);
                }
                /*var*/ let result = $.$stj.STJ.JsonSerializer.Deserialize$32(TValue, resultJson, this.JsonSerializerOptions);
                this.ByteArraysToBeRevived.Clear();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(12887588978)
            
            //--TRIMMABLE-BOUNDARY-START(34362425458)
            /*string? */ InvokeJS$2(/*string*/ identifier, /*string?*/ argsJson)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362425458);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeJS$1(identifier, argsJson, 0/*JSCallResultType.Default*/, 0n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362425458)
            
            //--TRIMMABLE-BOUNDARY-START(25772490866)
            /*string? */ InvokeJS(/*in JSInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772490866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeJS$1(invocationInfo.$v.Identifier, invocationInfo.$v.ArgsJson, invocationInfo.$v.ResultType, invocationInfo.$v.TargetInstanceId);
            }
            //--TRIMMABLE-BOUNDARY-END(25772490866)
            
            //--TRIMMABLE-BOUNDARY-START(8590327922)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.Invoke<TResult>(string, params object?[]?)
            MJ$IJSInProcessRuntime$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327922)
            
            //--TRIMMABLE-BOUNDARY-START(12885295218)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.InvokeConstructor(string, params object?[]?)
            MJ$IJSInProcessRuntime$InvokeConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295218)
            
            //--TRIMMABLE-BOUNDARY-START(4295360626)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.GetValue<TValue>(string)
            MJ$IJSInProcessRuntime$GetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295360626)
            
            //--TRIMMABLE-BOUNDARY-START(17180262514)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.SetValue<TValue>(string, TValue)
            MJ$IJSInProcessRuntime$SetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262514)
            
            //--TRIMMABLE-BOUNDARY-START(4297654386)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297654386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297654386)
            
            //--TRIMMABLE-BOUNDARY-START(4297654386)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297654386)
            
            static $h = 2687090;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mj.MJ.JSRuntime; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182556274),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Invoke",
      "o": "@$1",
      "d": 2687090,
      "h": 17182556274,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(17182556274),
//--TRIMMABLE-BOUNDARY-START(21477523570),
    {
      "r": 327794,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeConstructor",
      "d": 2687090,
      "h": 21477523570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477523570),
//--TRIMMABLE-BOUNDARY-START(8592621682),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValue",
      "d": 2687090,
      "h": 8592621682,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(8592621682),
//--TRIMMABLE-BOUNDARY-START(38657392754),
    {
      "r": 65537,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValue",
      "d": 2687090,
      "h": 38657392754,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(38657392754),
//--TRIMMABLE-BOUNDARY-START(12887588978),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        },
        {
          "n": "callType",
          "p": 1704050
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Invoke",
      "d": 2687090,
      "h": 12887588978,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(12887588978),
//--TRIMMABLE-BOUNDARY-START(34362425458),
    {
      "r": 1310721,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "InvokeJS",
      "o": "@$2",
      "d": 2687090,
      "h": 34362425458,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(34362425458),
//--TRIMMABLE-BOUNDARY-START(30067458162),
    {
      "r": 1310721,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        },
        {
          "n": "resultType",
          "p": 2359410
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        }
      ],
      "n": "InvokeJS",
      "o": "@$1",
      "d": 2687090,
      "h": 30067458162,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(30067458162),
//--TRIMMABLE-BOUNDARY-START(25772490866),
    {
      "r": 1310721,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1769586,
          "f": 8
        }
      ],
      "n": "InvokeJS",
      "d": 2687090,
      "h": 25772490866,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(25772490866)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42952360050),
    {
      "t": 917505,
      "n": "SyncCallIndicator",
      "d": 2687090,
      "h": 42952360050,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42952360050)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297654386),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687090,
      "h": 4297654386,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297654386)
  ],
  "h": 2687090
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$mj.MJ.IJSInProcessRuntime, $.$mj.MJ.IJSRuntime ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSInProcessRuntime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSInProcessRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687090)
        
        

        //--TRIMMABLE-BOUNDARY-START(65650)
        $asm.$cls(`$mj.MAI.LinkerFlags`, ($self) => class LinkerFlags
        {
            //--TRIMMABLE-BOUNDARY-START(12884967538)
            /*DynamicallyAccessedMemberTypes*/ static JsonSerialized = 547;
            //--TRIMMABLE-BOUNDARY-END(12884967538)
            
            //--TRIMMABLE-BOUNDARY-START(4295032946)
            /*DynamicallyAccessedMemberTypes*/ static Component = -1;
            //--TRIMMABLE-BOUNDARY-END(4295032946)
            
            //--TRIMMABLE-BOUNDARY-START(8590000242)
            /*DynamicallyAccessedMemberTypes*/ static JSInvokable = 8;
            //--TRIMMABLE-BOUNDARY-END(8590000242)
            
            static $h = 65650;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12884967538),
    {
      "n": "JsonSerialized",
      "d": 65650,
      "h": 12884967538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967538),
//--TRIMMABLE-BOUNDARY-START(4295032946),
    {
      "n": "Component",
      "d": 65650,
      "h": 4295032946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295032946),
//--TRIMMABLE-BOUNDARY-START(8590000242),
    {
      "n": "JSInvokable",
      "d": 65650,
      "h": 8590000242,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000242)
  ],
  "h": 65650
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Internal.LinkerFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Internal${separator}LinkerFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65650)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424946)
        $asm.$cls(`$mj.MJ.JSCallResultTypeHelper`, ($self) => class JSCallResultTypeHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4297392242)
            /*Assembly*/ static _currentAssembly = null;
            //--TRIMMABLE-BOUNDARY-END(4297392242)
            
            //--TRIMMABLE-BOUNDARY-START(12887326834)
            static /*JSCallResultType */ FromGeneric(TResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887326834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.SR.Assembly.op_Equality(TResult.$type.Assembly, $.$mj.MJ.JSCallResultTypeHelper._currentAssembly))
                {
                    if (TResult.$type === $.$mj.MJ.IJSObjectReference.$type || TResult.$type === $.$mj.MJ.IJSInProcessObjectReference.$type)
                    {
                        return 1/*JSCallResultType.JSObjectReference*/;
                    }
                    else if (TResult.$type === $.$mj.MJ.IJSStreamReference.$type)
                    {
                        return 2/*JSCallResultType.JSStreamReference*/;
                    }
                    else if (TResult.$type === $.$mj.MJI$1.IJSVoidResult.$type)
                    {
                        return 3/*JSCallResultType.JSVoidResult*/;
                    }
                }
                return 0/*JSCallResultType.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326834)
            
            //--TRIMMABLE-BOUNDARY-START(8592359538)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592359538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297392242)
                    this._currentAssembly = $.$mj.MJ.JSCallResultType.$type.Assembly;
                    //--TRIMMABLE-BOUNDARY-END(4297392242)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592359538)
            
            static $h = 2424946;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887326834),
    {
      "r": 2359410,
      "g": [
        "TResult"
      ],
      "n": "FromGeneric",
      "d": 2424946,
      "h": 12887326834,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887326834)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297392242),
    {
      "t": 107020289,
      "n": "_currentAssembly",
      "d": 2424946,
      "h": 4297392242,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297392242)
  ],
  "h": 2424946
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSCallResultTypeHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSCallResultTypeHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424946)
        
        

        //--TRIMMABLE-BOUNDARY-START(131186)
        $asm.$cls(`$mj.MJ.DotNetObjectReference`, ($self) => class DotNetObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(4295098482)
            static /*DotNetObjectReference<TValue> */ Create(TValue, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(value, TValue), "value");
                return new ($.$mj.MJ.DotNetObjectReference$$(TValue))().$ctor$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098482)
            
            static $h = 131186;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098482),
    {
      "r": (TValue) => $.$mj.MJ.DotNetObjectReference$$(TValue).$h,
      "p": [
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Create",
      "d": 131186,
      "h": 4295098482,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295098482)
  ],
  "h": 131186
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.DotNetObjectReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}DotNetObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131186)
        
        

        //--TRIMMABLE-BOUNDARY-START(2752626)
        $asm.$cls(`$mj.MJ.JSInProcessRuntimeExtensions`, ($self) => class JSInProcessRuntimeExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297719922)
            static /*void */ InvokeVoid(/*this IJSInProcessRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297719922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                jsRuntime.MJ$IJSInProcessRuntime$Invoke($.$mj.MJI$1.IJSVoidResult, identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(4297719922)
            
            static $h = 2752626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297719922),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsRuntime",
          "p": 393330
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoid",
      "d": 2752626,
      "h": 4297719922,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297719922)
  ],
  "h": 2752626
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSInProcessRuntimeExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSInProcessRuntimeExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752626)
        
        

        //--TRIMMABLE-BOUNDARY-START(2621554)
        $asm.$cls(`$mj.MJ.JSInProcessObjectReferenceExtensions`, ($self) => class JSInProcessObjectReferenceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297588850)
            static /*void */ InvokeVoid(/*this IJSInProcessObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297588850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                jsObjectReference.MJ$IJSInProcessObjectReference$Invoke($.$mj.MJI$1.IJSVoidResult, identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(4297588850)
            
            static $h = 2621554;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297588850),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 327794
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoid",
      "d": 2621554,
      "h": 4297588850,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297588850)
  ],
  "h": 2621554
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSInProcessObjectReferenceExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSInProcessObjectReferenceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621554)
        
        

        //--TRIMMABLE-BOUNDARY-START(786546)
        $asm.$cls(`$mj.MJI.JSObjectReferenceJsonWorker`, ($self) => class JSObjectReferenceJsonWorker
        {
            //--TRIMMABLE-BOUNDARY-START(8590721138)
            /*JsonEncodedText*/ static JSObjectIdKey;
            //--TRIMMABLE-BOUNDARY-END(8590721138)
            
            //--TRIMMABLE-BOUNDARY-START(12885688434)
            static /*long */ ReadJSObjectReferenceIdentifier(/*ref Utf8JsonReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long?*/ let id = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (id === null && reader.$v.ValueTextEquals($.$mj.MJI.JSObjectReferenceJsonWorker.JSObjectIdKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON property ${$.$strNN(reader.$v.GetString())}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.$v.TokenType))}`);
                    }
                }
                if (!$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(id))
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10(`Required property ${$.$strNN($.$mj.MJI.JSObjectReferenceJsonWorker.JSObjectIdKey.ToString())} not found.`);
                }
                return $.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(id);
            }
            //--TRIMMABLE-BOUNDARY-END(12885688434)
            
            //--TRIMMABLE-BOUNDARY-START(17180655730)
            static /*void */ WriteJSObjectReference(/*Utf8JsonWriter*/ writer, /*JSObjectReference*/ objectReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                writer.WriteNumber$26($.$mj.MJI.JSObjectReferenceJsonWorker.JSObjectIdKey, objectReference.Id);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(17180655730)
            
            //--TRIMMABLE-BOUNDARY-START(4295753842)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590721138)
                    this.JSObjectIdKey = $.$stj.STJ.JsonEncodedText.Encode$2("__jsObjectId", null);
                    //--TRIMMABLE-BOUNDARY-END(8590721138)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753842)
            
            static $h = 786546;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885688434),
    {
      "r": 917505,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        }
      ],
      "n": "ReadJSObjectReferenceIdentifier",
      "d": 786546,
      "h": 12885688434,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885688434),
//--TRIMMABLE-BOUNDARY-START(17180655730),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "objectReference",
          "p": 721010
        }
      ],
      "n": "WriteJSObjectReference",
      "d": 786546,
      "h": 17180655730,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180655730)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721138),
    {
      "t": 2293844,
      "n": "JSObjectIdKey",
      "d": 786546,
      "h": 8590721138,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590721138)
  ],
  "h": 786546
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Implementation${separator}JSObjectReferenceJsonWorker`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786546)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966194)
        $asm.$cls(`$mj.MJI$1.TaskGenericsUtil`, ($self) => class TaskGenericsUtil
        {
            //--TRIMMABLE-BOUNDARY-START(4296933490)
            /*ConcurrentDictionary<Type, ITaskResultGetter>*/ static _cachedResultGetters = null;
            //--TRIMMABLE-BOUNDARY-END(4296933490)
            
            //--TRIMMABLE-BOUNDARY-START(8591900786)
            /*ConcurrentDictionary<Type, ITcsResultSetter>*/ static _cachedResultSetters = null;
            //--TRIMMABLE-BOUNDARY-END(8591900786)
            
            //--TRIMMABLE-BOUNDARY-START(38656671858)
            static /*void */ SetTaskCompletionSourceResult(/*object*/ taskCompletionSource, /*object?*/ result)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656671858);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mj.MJI$1.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).MJI$1$TaskGenericsUtil$ITcsResultSetter$SetResult(taskCompletionSource, result);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656671858)
            
            //--TRIMMABLE-BOUNDARY-START(34361704562)
            static /*void */ SetTaskCompletionSourceException(/*object*/ taskCompletionSource, /*Exception*/ exception)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361704562);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mj.MJI$1.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).MJI$1$TaskGenericsUtil$ITcsResultSetter$SetException(taskCompletionSource, exception);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361704562)
            
            //--TRIMMABLE-BOUNDARY-START(21476802674)
            static /*Type */ GetTaskCompletionSourceResultType(/*object*/ taskCompletionSource)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476802674);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mj.MJI$1.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).MJI$1$TaskGenericsUtil$ITcsResultSetter$ResultType;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476802674)
            
            //--TRIMMABLE-BOUNDARY-START(25771769970)
            static /*object? */ GetTaskResult(/*Task*/ task)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let getter = $.$mj.MJI$1.TaskGenericsUtil._cachedResultGetters.GetOrAdd($.$$.S.Object.GetType.call(task), new ($.$$.S.Func$$$($.$$.S.Type, $.$mj.MJI$1.TaskGenericsUtil.ITaskResultGetter))().$ctor(this,  (/*taskInstanceType*/ taskInstanceType) =>
                {
                    /*var*/ let resultType = $.$mj.MJI$1.TaskGenericsUtil.GetTaskResultType(taskInstanceType);
                    return resultType === null ? new $.$mj.MJI$1.TaskGenericsUtil.VoidTaskResultGetter().$ctor$1() : $.$cast($.$$.S.Activator.CreateInstance$9($.$mj.MJI$1.TaskGenericsUtil.TaskResultGetter$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ resultType ], null, null))), $.$mj.MJI$1.TaskGenericsUtil.ITaskResultGetter);
                }, $nrpRha ??= {"r":2031730,"p":[{"n":"taskInstanceType","p":188547073}],"n":"","d":1966194,"h":0,"f":17825794}));
                return getter.MJI$1$TaskGenericsUtil$ITaskResultGetter$GetResult(task);
            }
            //--TRIMMABLE-BOUNDARY-END(25771769970)
            
            //--TRIMMABLE-BOUNDARY-START(30066737266)
            static /*Type? */ GetTaskResultType(/*Type*/ taskType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(taskType !== $.$$.STT.Task.$type && (!taskType.IsGenericType || taskType.GetGenericTypeDefinition() !== $.$$.STT.Task$$().$type))
                {
                    taskType = $.$firstOf(taskType.BaseType, () => { throw new $.$$.S.ArgumentException().$ctor$14(`The type '${$.$strNN(taskType.FullName)}' is not inherited from '${$.$strNN($.$$.STT.Task.$type.FullName)}'.`) });
                }
                return taskType.IsGenericType ? $.$$.System.Array.$ReadT1.call(taskType.GetGenericArguments(), 0) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(30066737266)
            
            //--TRIMMABLE-BOUNDARY-START(2097266)
            static $_ITcsResultSetter;
            static get ITcsResultSetter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2097266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mj.MJI$1.TaskGenericsUtil;
                return $cls.$_ITcsResultSetter ??= $asm.$ncls(`$mj.MJI$1.TaskGenericsUtil.ITcsResultSetter`, ($self) => class ITcsResultSetter
                {
                    static $h = 2097266;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886999154),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592031858,
        "f": 50331905
      },
      "n": "ResultType",
      "o": "MJI$1$TaskGenericsUtil$ITcsResultSetter$ResultType",
      "d": 2097266,
      "h": 12886999154,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886999154)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476933746),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        },
        {
          "n": "result",
          "p": 131073
        }
      ],
      "n": "SetResult",
      "o": "MJI$1$TaskGenericsUtil$ITcsResultSetter$SetResult",
      "d": 2097266,
      "h": 21476933746,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476933746),
//--TRIMMABLE-BOUNDARY-START(17181966450),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "SetException",
      "o": "MJI$1$TaskGenericsUtil$ITcsResultSetter$SetException",
      "d": 2097266,
      "h": 17181966450,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181966450)
  ],
  "d": 1966194,
  "h": 2097266
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.TaskGenericsUtil+ITcsResultSetter`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}TaskGenericsUtil${separator}ITcsResultSetter`; }
                }, $cls, ($v) => $cls.$_ITcsResultSetter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2097266)
            
            //--TRIMMABLE-BOUNDARY-START(2031730)
            static $_ITaskResultGetter;
            static get ITaskResultGetter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2031730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mj.MJI$1.TaskGenericsUtil;
                return $cls.$_ITaskResultGetter ??= $asm.$ncls(`$mj.MJI$1.TaskGenericsUtil.ITaskResultGetter`, ($self) => class ITaskResultGetter
                {
                    static $h = 2031730;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296999026),
    {
      "r": 131073,
      "p": [
        {
          "n": "task",
          "p": 178454529
        }
      ],
      "n": "GetResult",
      "o": "MJI$1$TaskGenericsUtil$ITaskResultGetter$GetResult",
      "d": 2031730,
      "h": 4296999026,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296999026)
  ],
  "d": 1966194,
  "h": 2031730
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.TaskGenericsUtil+ITaskResultGetter`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}TaskGenericsUtil${separator}ITaskResultGetter`; }
                }, $cls, ($v) => $cls.$_ITaskResultGetter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2031730)
            
            //--TRIMMABLE-BOUNDARY-START(2162802)
            static $_TaskResultGetter$$;
            static TaskResultGetter$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2162802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mj.MJI$1.TaskGenericsUtil;
                return ($cls.$_TaskResultGetter$$ ??= $asm.$ncls(`$mj.MJI$1.TaskGenericsUtil.TaskResultGetter<>`, (T) => $asm.$gt(`$mj.MJI$1.TaskGenericsUtil.TaskResultGetter<>`, [T], ($self) => class TaskResultGetter$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592097394)
                    /*object? */ GetResult(/*Task*/ task)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592097394);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$box($.$box(($.$cast(task, $.$$.STT.Task$$(T))).Result, T), T);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592097394)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296999026)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter.GetResult(System.Threading.Tasks.Task)
                    MJI$1$TaskGenericsUtil$ITaskResultGetter$GetResult()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296999026);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetResult(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296999026)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297130098)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297130098);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297130098)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297130098)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297130098)
                    
                    static $H = 2162802;
                    static $h = 2162802;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592097394),
    {
      "r": 131073,
      "p": [
        {
          "n": "task",
          "p": 178454529
        }
      ],
      "n": "GetResult",
      "d": this.$h,
      "H": 8592097394,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592097394)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297130098),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297130098,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297130098)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "d": 1966194,
  "H": 2162802,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.MJI$1.TaskGenericsUtil.ITaskResultGetter ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.TaskGenericsUtil+TaskResultGetter<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}TaskGenericsUtil${separator}TaskResultGetter$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_TaskResultGetter$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(2162802)
            
            //--TRIMMABLE-BOUNDARY-START(2293874)
            static $_VoidTaskResultGetter;
            static get VoidTaskResultGetter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2293874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mj.MJI$1.TaskGenericsUtil;
                return $cls.$_VoidTaskResultGetter ??= $asm.$ncls(`$mj.MJI$1.TaskGenericsUtil.VoidTaskResultGetter`, ($self) => class VoidTaskResultGetter extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592228466)
                    /*object? */ GetResult(/*Task*/ task)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592228466);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        task.Wait();
                        return null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592228466)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296999026)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter.GetResult(System.Threading.Tasks.Task)
                    MJI$1$TaskGenericsUtil$ITaskResultGetter$GetResult()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296999026);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetResult(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296999026)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297261170)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297261170);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297261170)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297261170)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297261170)
                    
                    static $h = 2293874;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592228466),
    {
      "r": 131073,
      "p": [
        {
          "n": "task",
          "p": 178454529
        }
      ],
      "n": "GetResult",
      "d": 2293874,
      "h": 8592228466,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592228466)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297261170),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2293874,
      "h": 4297261170,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297261170)
  ],
  "d": 1966194,
  "h": 2293874
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.MJI$1.TaskGenericsUtil.ITaskResultGetter ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.TaskGenericsUtil+VoidTaskResultGetter`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}TaskGenericsUtil${separator}VoidTaskResultGetter`; }
                }, $cls, ($v) => $cls.$_VoidTaskResultGetter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2293874)
            
            //--TRIMMABLE-BOUNDARY-START(2228338)
            static $_TcsResultSetter$$;
            static TcsResultSetter$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2228338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mj.MJI$1.TaskGenericsUtil;
                return ($cls.$_TcsResultSetter$$ ??= $asm.$ncls(`$mj.MJI$1.TaskGenericsUtil.TcsResultSetter<>`, (T) => $asm.$gt(`$mj.MJI$1.TaskGenericsUtil.TcsResultSetter<>`, [T], ($self) => class TcsResultSetter$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17182097522)
                    /*Type */ get ResultType()
                    {
                        return T.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182097522)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772032114)
                    /*void */ SetResult(/*object*/ tcs, /*object?*/ result)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772032114);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let typedTcs = $.$cast(tcs, $.$$.STT.TaskCompletionSource$$(T));
                        let resultT;
                        /*var*/ let typedResult = $.$is(result, T, { set $v($v){ resultT = $v; } }) ? resultT : result === null && T.$type.IsGenericType && T.$type.GetGenericTypeDefinition() === $.$$.S.Nullable$$().$type ? $.$default(T) : $.$cast($.$$.S.Convert.ChangeType(result, T.$type, $.$$.SG.CultureInfo.InvariantCulture), T);
                        typedTcs.SetResult(typedResult);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772032114)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477064818)
                    /*void */ SetException(/*object*/ tcs, /*Exception*/ exception)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477064818);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let typedTcs = $.$cast(tcs, $.$$.STT.TaskCompletionSource$$(T));
                        typedTcs.SetException$1(exception);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477064818)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592031858)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.ResultType.get
                    get MJI$1$TaskGenericsUtil$ITcsResultSetter$ResultType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886999154);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ResultType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592031858)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476933746)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.SetResult(object, object?)
                    MJI$1$TaskGenericsUtil$ITcsResultSetter$SetResult()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476933746);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.SetResult(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476933746)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181966450)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.SetException(object, System.Exception)
                    MJI$1$TaskGenericsUtil$ITcsResultSetter$SetException()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181966450);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.SetException(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181966450)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297195634)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297195634);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297195634)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297195634)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297195634)
                    
                    static $H = 2228338;
                    static $h = 2228338;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182097522),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12887130226,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331649
      },
      "n": "ResultType",
      "d": this.$h,
      "H": 17182097522,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182097522)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772032114),
    {
      "r": 65537,
      "p": [
        {
          "n": "tcs",
          "p": 131073
        },
        {
          "n": "result",
          "p": 131073
        }
      ],
      "n": "SetResult",
      "d": this.$h,
      "H": 25772032114,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772032114),
//--TRIMMABLE-BOUNDARY-START(21477064818),
    {
      "r": 65537,
      "p": [
        {
          "n": "tcs",
          "p": 131073
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "SetException",
      "d": this.$h,
      "H": 21477064818,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477064818)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195634),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297195634,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297195634)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "d": 1966194,
  "H": 2228338,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.MJI$1.TaskGenericsUtil.ITcsResultSetter ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.TaskGenericsUtil+TcsResultSetter<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}TaskGenericsUtil${separator}TcsResultSetter$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_TcsResultSetter$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(2228338)
            
            //--TRIMMABLE-BOUNDARY-START(17181835378)
            static /*ITcsResultSetter */ CreateResultSetter(/*object*/ taskCompletionSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181835378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mj.MJI$1.TaskGenericsUtil._cachedResultSetters.GetOrAdd($.$$.S.Object.GetType.call(taskCompletionSource), new ($.$$.S.Func$$$($.$$.S.Type, $.$mj.MJI$1.TaskGenericsUtil.ITcsResultSetter))().$ctor(this,  (/*tcsType*/ tcsType) =>
                {
                    /*var*/ let resultType = $.$$.System.Array.$ReadT1.call(tcsType.GetGenericArguments(), 0);
                    return $.$cast($.$$.S.Activator.CreateInstance$9($.$mj.MJI$1.TaskGenericsUtil.TcsResultSetter$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ resultType ], null, null))), $.$mj.MJI$1.TaskGenericsUtil.ITcsResultSetter);
                }, $ovjPgj ??= {"r":2097266,"p":[{"n":"tcsType","p":188547073}],"n":"","d":1966194,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(17181835378)
            
            //--TRIMMABLE-BOUNDARY-START(12886868082)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886868082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4296933490)
                    this._cachedResultGetters = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$mj.MJI$1.TaskGenericsUtil.ITaskResultGetter))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4296933490)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591900786)
                    this._cachedResultSetters = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$mj.MJI$1.TaskGenericsUtil.ITcsResultSetter))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8591900786)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886868082)
            
            static $h = 1966194;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656671858),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        },
        {
          "n": "result",
          "p": 131073
        }
      ],
      "n": "SetTaskCompletionSourceResult",
      "d": 1966194,
      "h": 38656671858,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656671858),
//--TRIMMABLE-BOUNDARY-START(34361704562),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "SetTaskCompletionSourceException",
      "d": 1966194,
      "h": 34361704562,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361704562),
//--TRIMMABLE-BOUNDARY-START(21476802674),
    {
      "r": 188547073,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        }
      ],
      "n": "GetTaskCompletionSourceResultType",
      "d": 1966194,
      "h": 21476802674,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476802674),
//--TRIMMABLE-BOUNDARY-START(25771769970),
    {
      "r": 131073,
      "p": [
        {
          "n": "task",
          "p": 178454529
        }
      ],
      "n": "GetTaskResult",
      "d": 1966194,
      "h": 25771769970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771769970),
//--TRIMMABLE-BOUNDARY-START(30066737266),
    {
      "r": 188547073,
      "p": [
        {
          "n": "taskType",
          "p": 188547073
        }
      ],
      "n": "GetTaskResultType",
      "d": 1966194,
      "h": 30066737266,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066737266),
//--TRIMMABLE-BOUNDARY-START(17181835378),
    {
      "r": 2097266,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        }
      ],
      "n": "CreateResultSetter",
      "d": 1966194,
      "h": 17181835378,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181835378)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296933490),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$mj.MJI$1.TaskGenericsUtil.ITaskResultGetter).$h,
      "n": "_cachedResultGetters",
      "d": 1966194,
      "h": 4296933490,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296933490),
//--TRIMMABLE-BOUNDARY-START(8591900786),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$mj.MJI$1.TaskGenericsUtil.ITcsResultSetter).$h,
      "n": "_cachedResultSetters",
      "d": 1966194,
      "h": 8591900786,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591900786)
  ],
  "h": 1966194
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mj.MJI$1.TaskGenericsUtil.ITcsResultSetter, $.$mj.MJI$1.TaskGenericsUtil.ITaskResultGetter, $.$mj.MJI$1.TaskGenericsUtil.TaskResultGetter$$(T), $.$mj.MJI$1.TaskGenericsUtil.VoidTaskResultGetter, $.$mj.MJI$1.TaskGenericsUtil.TcsResultSetter$$(T) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.TaskGenericsUtil`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}TaskGenericsUtil`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966194)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048690)
        $asm.$cls(`$mj.MJI$1.DotNetDispatcher`, ($self) => class DotNetDispatcher
        {
            //--TRIMMABLE-BOUNDARY-START(34360787058)
            /*string*/ static DisposeDotNetObjectReferenceMethodName = null;
            //--TRIMMABLE-BOUNDARY-END(34360787058)
            
            //--TRIMMABLE-BOUNDARY-START(38655754354)
            /*JsonEncodedText*/ static DotNetObjectRefKey;
            //--TRIMMABLE-BOUNDARY-END(38655754354)
            
            //--TRIMMABLE-BOUNDARY-START(8590983282)
            /*ConcurrentDictionary<AssemblyKey, IReadOnlyDictionary<string, (MethodInfo, Type[])>>*/ static _cachedMethodsByAssembly = null;
            //--TRIMMABLE-BOUNDARY-END(8590983282)
            
            //--TRIMMABLE-BOUNDARY-START(12885950578)
            /*ConcurrentDictionary<Type, IReadOnlyDictionary<string, (MethodInfo, Type[])>>*/ static _cachedMethodsByType = null;
            //--TRIMMABLE-BOUNDARY-END(12885950578)
            
            //--TRIMMABLE-BOUNDARY-START(4296015986)
            /*ConcurrentDictionary<Type, Func<object, Task>>*/ static _cachedConvertToTaskByType = null;
            //--TRIMMABLE-BOUNDARY-END(4296015986)
            
            //--TRIMMABLE-BOUNDARY-START(17180917874)
            /*MethodInfo*/ static _taskConverterMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(17180917874)
            
            //--TRIMMABLE-BOUNDARY-START(73015492722)
            static /*string? */ Invoke(/*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ invocationInfo, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015492722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IDotNetObjectReference?*/ let targetInstance = null;
                if (invocationInfo.$v.DotNetObjectId !== 0n)
                {
                    targetInstance = jsRuntime.GetObjectReference(invocationInfo.$v.DotNetObjectId);
                }
                /*var*/ let syncResult = $.$mj.MJI$1.DotNetDispatcher.InvokeSynchronously(jsRuntime, invocationInfo, targetInstance, argsJson);
                if (syncResult === null)
                {
                    return null;
                }
                return $.$stj.STJ.JsonSerializer.Serialize$13($.$$.S.Object, syncResult, jsRuntime.JsonSerializerOptions);
            }
            //--TRIMMABLE-BOUNDARY-END(73015492722)
            
            //--TRIMMABLE-BOUNDARY-START(25770852466)
            static /*void */ BeginInvokeDotNet(/*JSRuntime*/ jsRuntime, /*DotNetInvocationInfo*/ invocationInfo, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770852466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca1__;
                /*var*/ let callId = invocationInfo.CallId;
                /*object?*/ let syncResult = null;
                /*ExceptionDispatchInfo?*/ let syncException = null;
                /*IDotNetObjectReference?*/ let targetInstance = null;
                try
                {
                    if (invocationInfo.DotNetObjectId !== 0n)
                    {
                        targetInstance = jsRuntime.GetObjectReference(invocationInfo.DotNetObjectId);
                    }
                    syncResult = $.$mj.MJI$1.DotNetDispatcher.InvokeSynchronously(jsRuntime, $.$ref(() => invocationInfo, ), targetInstance, argsJson);
                }
                catch(ex)
                {
                    syncException = $.$$.SRE$1.ExceptionDispatchInfo.Capture(ex);
                }
                let task;
                let valueTaskResult;
                let syncResultType;
                if (callId === null)
                {
                    return;
                }
                else if (syncException !== null)
                {
                    jsRuntime.EndInvokeDotNet(invocationInfo, $.$ref(() => new $.$mj.MJI$1.DotNetInvocationResult().$ctor$3(syncException.SourceException, "InvocationFailure"), ));
                }
                else if ($.$is(syncResult, $.$$.STT.Task, { set $v($v){ task = $v; } }))
                {
                    task.ContinueWith$10(new ($.$$.S.Action$$($.$$.STT.Task))().$ctor(this,  (/**/ t) =>
                    {
                        return $.$mj.MJI$1.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }, $CoDrda ??= {"r":65537,"p":[{"n":"t","p":178454529}],"n":"","d":1048690,"h":0,"f":17825794}), $.$$.STT.TaskScheduler.Current);
                }
                else if ($.$is(syncResult, $.$$.STT.ValueTask, { set $v($v){ valueTaskResult = $v; } }))
                {
                    valueTaskResult.AsTask().ContinueWith$10(new ($.$$.S.Action$$($.$$.STT.Task))().$ctor(this,  (/**/ t) =>
                    {
                        return $.$mj.MJI$1.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }, $plbJPe ??= {"r":65537,"p":[{"n":"t","p":178454529}],"n":"","d":1048690,"h":0,"f":17825794}), $.$$.STT.TaskScheduler.Current);
                }
                else if (((__ca1__ = syncResult) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null) !== null && ((syncResultType = ((__ca1__ = syncResult) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null), syncResultType != null && ((__ca1__ = syncResult) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null).IsGenericType === true)) && syncResultType.GetGenericTypeDefinition() === $.$$.STT.ValueTask$$().$type)
                {
                    /*var*/ let innerTask = $.$mj.MJI$1.DotNetDispatcher.GetTaskByType($.$$.System.Array.$ReadT1.call(syncResultType.GenericTypeArguments, 0), syncResult);
                    innerTask.ContinueWith$10(new ($.$$.S.Action$$($.$$.STT.Task))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$mj.MJI$1.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }, $WlpHik ??= {"r":65537,"p":[{"n":"t","p":178454529}],"n":"","d":1048690,"h":0,"f":17825794}), $.$$.STT.TaskScheduler.Current);
                }
                else 
                {
                    /*var*/ let syncResultJson = $.$stj.STJ.JsonSerializer.Serialize$13($.$$.S.Object, syncResult, jsRuntime.JsonSerializerOptions);
                    /*var*/ let dispatchResult = new $.$mj.MJI$1.DotNetInvocationResult().$ctor$4(syncResultJson);
                    jsRuntime.EndInvokeDotNet(invocationInfo, $.$ref(() => dispatchResult, ));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770852466)
            
            //--TRIMMABLE-BOUNDARY-START(42950721650)
            static /*void */ EndInvokeDotNetAfterTask(/*Task*/ task, /*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950721650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (task.Exception !== null)
                {
                    /*var*/ let exceptionDispatchInfo = $.$$.SRE$1.ExceptionDispatchInfo.Capture(task.Exception.GetBaseException());
                    /*var*/ let dispatchResult = new $.$mj.MJI$1.DotNetInvocationResult().$ctor$3(exceptionDispatchInfo.SourceException, "InvocationFailure");
                    jsRuntime.EndInvokeDotNet(invocationInfo.$v, $.$ref(() => dispatchResult, ));
                }
                /*var*/ let result = $.$mj.MJI$1.TaskGenericsUtil.GetTaskResult(task);
                /*var*/ let resultJson = $.$stj.STJ.JsonSerializer.Serialize$13($.$$.S.Object, result, jsRuntime.JsonSerializerOptions);
                jsRuntime.EndInvokeDotNet(invocationInfo.$v, $.$ref(() => new $.$mj.MJI$1.DotNetInvocationResult().$ctor$4(resultJson), ));
            }
            //--TRIMMABLE-BOUNDARY-END(42950721650)
            
            //--TRIMMABLE-BOUNDARY-START(77310460018)
            static /*object? */ InvokeSynchronously(/*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ callInfo, /*IDotNetObjectReference?*/ objectReference, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310460018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let assemblyName = callInfo.$v.AssemblyName;
                /*var*/ let methodIdentifier = callInfo.$v.MethodIdentifier;
                /*AssemblyKey*/ let assemblyKey;
                /*MethodInfo*/ let methodInfo;
                /*Type[]*/ let parameterTypes;
                if (objectReference === null)
                {
                    assemblyKey = new $.$mj.MJI$1.DotNetDispatcher.AssemblyKey().$ctor$4(assemblyName);
                    $.$tupleUnpack(($tp) =>
                    {
                        methodInfo = $tp.Item1;
                        parameterTypes = $tp.Item2;
                    }).$v = $.$mj.MJI$1.DotNetDispatcher.GetCachedMethodInfo(assemblyKey, methodIdentifier);
                }
                else 
                {
                    if (assemblyName !== null)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14(`For instance method calls, '${$.$strNN("assemblyName")}' should be null. Value received: '${$.$strNN(assemblyName)}'.`);
                    }
                    if ($.$$.S.String.Equals$3("__Dispose"/*DisposeDotNetObjectReferenceMethodName*/, methodIdentifier, 4/*StringComparison.Ordinal*/))
                    {
                        objectReference.S$IDisposable$Dispose();
                        return null;
                    }
                    $.$tupleUnpack(($tp) =>
                    {
                        methodInfo = $tp.Item1;
                        parameterTypes = $tp.Item2;
                    }).$v = $.$mj.MJI$1.DotNetDispatcher.GetCachedMethodInfo$1(objectReference, methodIdentifier);
                }
                /*var*/ let suppliedArgs = $.$mj.MJI$1.DotNetDispatcher.ParseArguments(jsRuntime, methodIdentifier, argsJson, parameterTypes);
                try
                {
                    return methodInfo.Invoke((objectReference?.MJI$1$IDotNetObjectReference$Value ?? null), suppliedArgs);
                }
                catch(tie)
                {
                    if (tie.InnerException !== null)
                    {
                        $.$$.SRE$1.ExceptionDispatchInfo.Capture(tie.InnerException).Throw();
                        throw tie.InnerException;
                    }
                    throw tie;
                }
                finally
                {
                    {
                        jsRuntime.ByteArraysToBeRevived.Clear();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310460018)
            
            //--TRIMMABLE-BOUNDARY-START(81605427314)
            static /*object?[] */ ParseArguments(/*JSRuntime*/ jsRuntime, /*string*/ methodIdentifier, /*string*/ $arguments, /*Type[]*/ parameterTypes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605427314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (parameterTypes.length === 0)
                {
                    return $.$$.S.Array.Empty($.$$.S.Object);
                }
                /*var*/ let count = $.$$.ST.Encoding.UTF8.GetByteCount$6($arguments);
                /*var*/ let buffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(count);
                try
                {
                    /*var*/ let receivedBytes = $.$$.ST.Encoding.UTF8.GetBytes$5($.$$.S.String.op_Implicit($arguments), $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(buffer));
                    $.$$.SD.Debug.Assert$4(count === receivedBytes, "count == receivedBytes");
                    /*var*/ let reader = new $.$stj.STJ.Utf8JsonReader().$ctor$6($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, buffer, 0, count)), new $.$stj.STJ.JsonReaderOptions());
                    if (!reader.Read() || reader.TokenType !== 3/*JsonTokenType.StartArray*/)
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10("Invalid JSON");
                    }
                    /*var*/ let suppliedArgs = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [parameterTypes.length], null);
                    /*var*/ let index = 0;
                    while(index < parameterTypes.length && reader.Read() && reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                    {
                        /*var*/ let parameterType = $.$$.System.Array.$ReadT1.call(parameterTypes, index);
                        if (reader.TokenType === 1/*JsonTokenType.StartObject*/ && IsIncorrectDotNetObjectRefUse(parameterType, $.$clone(reader)))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`In call to '${$.$strNN(methodIdentifier)}', parameter of type '${$.$strNN(parameterType.Name)}' at index ${$.$strNN((((index + 1) | 0)))} must be declared as type 'DotNetObjectRef<${$.$strNN(parameterType.Name)}>' to receive the incoming value.`);
                        }
                        $.$$.System.Array.$WriteT1.call(suppliedArgs, $.$stj.STJ.JsonSerializer.Deserialize$1($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), parameterType, jsRuntime.JsonSerializerOptions), index);
                        index++;
                    }
                    if (index < parameterTypes.length)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14(`The call to '${$.$strNN(methodIdentifier)}' expects '${$.$strNN(parameterTypes.length)}' parameters, but received '${$.$strNN(index)}'.`);
                    }
                    if (!reader.Read() || reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.TokenType))}. Ensure that the call to \`${$.$strNN(methodIdentifier)}' is supplied with exactly '${$.$strNN(parameterTypes.length)}' parameters.`);
                    }
                    return suppliedArgs;
                    /*static bool*/  function IsIncorrectDotNetObjectRefUse(/*Type*/ parameterType, /*Utf8JsonReader*/ jsonReader)
                    {
                        if (jsonReader.Read() && jsonReader.TokenType === 5/*JsonTokenType.PropertyName*/ && jsonReader.ValueTextEquals($.$mj.MJI$1.DotNetDispatcher.DotNetObjectRefKey.EncodedUtf8Bytes))
                        {
                            return !parameterType.IsGenericType || parameterType.GetGenericTypeDefinition() !== $.$mj.MJ.DotNetObjectReference$$().$type;
                        }
                        return false;
                    }
                }
                finally
                {
                    {
                        $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(buffer, false);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605427314)
            
            //--TRIMMABLE-BOUNDARY-START(47245688946)
            static /*void */ EndInvokeJS(/*JSRuntime*/ jsRuntime, /*string*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245688946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let utf8JsonBytes = $.$$.ST.Encoding.UTF8.GetBytes$8($arguments);
                /*var*/ let reader = new $.$stj.STJ.Utf8JsonReader().$ctor$6($.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(utf8JsonBytes), new $.$stj.STJ.JsonReaderOptions());
                if (!reader.Read() || reader.TokenType !== 3/*JsonTokenType.StartArray*/)
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10("Invalid JSON");
                }
                reader.Read();
                /*var*/ let taskId = reader.GetInt64();
                reader.Read();
                /*var*/ let success = reader.GetBoolean();
                reader.Read();
                if (!jsRuntime.EndInvokeJS(taskId, success, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true)))
                {
                    return;
                }
                if (!reader.Read() || reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10("Invalid JSON");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245688946)
            
            //--TRIMMABLE-BOUNDARY-START(85900394610)
            static /*void */ ReceiveByteArray(/*JSRuntime*/ jsRuntime, /*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900394610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                jsRuntime.ReceiveByteArray(id, data);
            }
            //--TRIMMABLE-BOUNDARY-END(85900394610)
            
            //--TRIMMABLE-BOUNDARY-START(51540656242)
            static /*(MethodInfo, Type[]) */ GetCachedMethodInfo(/*AssemblyKey*/ assemblyKey, /*string*/ methodIdentifier)
            {
                /*var*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrWhiteSpace(assemblyKey.AssemblyName, "assemblyKey.AssemblyName");
                $.$$.S.ArgumentException.ThrowIfNullOrWhiteSpace(methodIdentifier, "methodIdentifier");
                /*var*/ let assemblyMethods = $.$mj.MJI$1.DotNetDispatcher._cachedMethodsByAssembly.GetOrAdd(assemblyKey, new ($.$$.S.Func$$$($.$mj.MJI$1.DotNetDispatcher.AssemblyKey, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))))().$ctor($.$mj.MJI$1.DotNetDispatcher, $.$mj.MJI$1.DotNetDispatcher.ScanAssemblyForCallableMethods));
                if (assemblyMethods.SCG$IReadOnlyDictionary$$$$TryGetValue(methodIdentifier, $.$ref(() => result, ($v) => result = $v, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))))
                {
                    return result;
                }
                else 
                {
                    throw new $.$$.S.ArgumentException().$ctor$14(`The assembly '${$.$strNN(assemblyKey.AssemblyName)}' does not contain a public invokable method with [${$.$strNN("JSInvokableAttribute")}(\"${$.$strNN(methodIdentifier)}\")].`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540656242)
            
            //--TRIMMABLE-BOUNDARY-START(68720525426)
            static /*Task */ GetTaskByType(/*Type*/ type, /*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720525426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let converterDelegate = $.$mj.MJI$1.DotNetDispatcher._cachedConvertToTaskByType.GetOrAdd$2($.$$.SR.MethodInfo, type, new ($.$$.S.Func$$$$($.$$.S.Type, $.$$.SR.MethodInfo, $.$$.S.Func$$$($.$$.S.Object, $.$$.STT.Task)))().$ctor(this,  (/*Type*/ t, /*MethodInfo*/ taskConverterMethodInfo) =>
                {
                    return taskConverterMethodInfo.MakeGenericMethod($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ t ], null, null)).CreateDelegate$2($.$$.S.Func$$$($.$$.S.Object, $.$$.STT.Task));
                }, $QEvxKh ??= {"r":$.$$.S.Func$$$($.$$.S.Object, $.$$.STT.Task).$h,"p":[{"n":"t","p":188547073},{"n":"taskConverterMethodInfo","p":117571585}],"n":"","d":1048690,"h":0,"f":17825794}), $.$mj.MJI$1.DotNetDispatcher._taskConverterMethodInfo);
                return converterDelegate.Invoke(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(68720525426)
            
            //--TRIMMABLE-BOUNDARY-START(30065819762)
            static /*Task */ CreateValueTaskConverter(T, /*object*/ result)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065819762);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$cast(result, $.$$.STT.ValueTask$$(T))).AsTask();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065819762)
            
            //--TRIMMABLE-BOUNDARY-START(55835623538)
            static /*(MethodInfo methodInfo, Type[] parameterTypes) */ GetCachedMethodInfo$1(/*IDotNetObjectReference*/ objectReference, /*string*/ methodIdentifier)
            {
                /*var*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835623538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$$.S.Object.GetType.call(objectReference.MJI$1$IDotNetObjectReference$Value);
                /*var*/ let assemblyMethods = $.$mj.MJI$1.DotNetDispatcher._cachedMethodsByType.GetOrAdd(type, new ($.$$.S.Func$$$($.$$.S.Type, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))))().$ctor($.$mj.MJI$1.DotNetDispatcher, ScanTypeForCallableMethods, $LgoHOh ??= {"r":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type))).$h,"p":[{"n":"type","p":188547073}],"n":"ScanTypeForCallableMethods","d":1048690,"h":0,"f":16777250}));
                if (assemblyMethods.SCG$IReadOnlyDictionary$$$$TryGetValue(methodIdentifier, $.$ref(() => result, ($v) => result = $v, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))))
                {
                    return result;
                }
                else 
                {
                    throw new $.$$.S.ArgumentException().$ctor$14(`The type '${$.$strNN(type.Name)}' does not contain a public invokable method with [${$.$strNN("JSInvokableAttribute")}(\"${$.$strNN(methodIdentifier)}\")].`);
                }
                /*static Dictionary<string, (MethodInfo, Type[])>*/  function ScanTypeForCallableMethods(/*Type*/ type)
                {
                    /*var*/ let result = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type))))().$ctor$6($.$$.S.StringComparer.Ordinal);
                    let $i8 = 0;
                    let $arr8 = type.GetMethods$1(4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/);
                    while ($i8 < $arr8.length)
                    {
                        let method = $arr8[$i8++];
                        if (method.ContainsGenericParameters$1 || !method.IsDefined($.$mj.MJ.JSInvokableAttribute.$type, false))
                        {
                            continue;
                        }
                        let $en9 = $.$$.SR.CustomAttributeExtensions.GetCustomAttributes$13($.$mj.MJ.JSInvokableAttribute, method, false).SCG$IEnumerable$$$GetEnumerator();
                        while ($en9.SC$1$IEnumerator$MoveNext())
                        {
                            let attr = $en9.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let identifier = attr.Identifier ?? method.Name;
                                /*var*/ let parameterTypes = $.$mj.MJI$1.DotNetDispatcher.GetParameterTypes(method);
                                if (result.ContainsKey(identifier))
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$strNN($.$strNN(`The type ${$.$strNN(type.Name)} contains more than one `) + $.$strNN(`[JSInvokable] method with identifier '${$.$strNN(identifier)}'. All [JSInvokable] methods within the same `)) + "type must have different identifiers. You can pass a custom identifier as a parameter to " + $.$strNN(`the [JSInvokable] attribute.`));
                                }
                                result.Add(identifier, new ($.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))().$ctor$3(method, parameterTypes));
                            }
                        }
                    }
                    return result;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835623538)
            
            //--TRIMMABLE-BOUNDARY-START(90195361906)
            static /*Dictionary<string, (MethodInfo, Type[])> */ ScanAssemblyForCallableMethods(/*AssemblyKey*/ assemblyKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195361906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type))))().$ctor$6($.$$.S.StringComparer.Ordinal);
                /*var*/ let exportedTypes = $.$mj.MJI$1.DotNetDispatcher.GetRequiredLoadedAssembly(assemblyKey).GetExportedTypes();
                let $i10 = 0;
                let $arr10 = exportedTypes;
                while ($i10 < $arr10.length)
                {
                    let type = $arr10[$i10++];
                    let $i11 = 0;
                    let $arr11 = type.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                    while ($i11 < $arr11.length)
                    {
                        let method = $arr11[$i11++];
                        if (method.ContainsGenericParameters$1 || !method.IsDefined($.$mj.MJ.JSInvokableAttribute.$type, false))
                        {
                            continue;
                        }
                        let $en12 = $.$$.SR.CustomAttributeExtensions.GetCustomAttributes$13($.$mj.MJ.JSInvokableAttribute, method, false).SCG$IEnumerable$$$GetEnumerator();
                        while ($en12.SC$1$IEnumerator$MoveNext())
                        {
                            let attr = $en12.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let identifier = attr.Identifier ?? method.Name;
                                /*var*/ let parameterTypes = $.$mj.MJI$1.DotNetDispatcher.GetParameterTypes(method);
                                if (result.ContainsKey(identifier))
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$strNN($.$strNN($.$strNN(`The assembly '${$.$strNN(assemblyKey.AssemblyName)}' contains more than one `) + $.$strNN(`[JSInvokable] method with identifier '${$.$strNN(identifier)}'. All [JSInvokable] methods within the same `)) + $.$strNN(`assembly must have different identifiers. You can pass a custom identifier as a parameter to `)) + $.$strNN(`the [JSInvokable] attribute.`));
                                }
                                result.Add(identifier, new ($.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))().$ctor$3(method, parameterTypes));
                            }
                        }
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(90195361906)
            
            //--TRIMMABLE-BOUNDARY-START(60130590834)
            static /*Type[] */ GetParameterTypes(/*MethodInfo*/ method)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130590834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = method.GetParameters();
                if (parameters.length === 0)
                {
                    return $.$$.S.Type.EmptyTypes;
                }
                /*var*/ let parameterTypes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), null, [parameters.length], null);
                for(/*var*/ let i = 0; i < parameters.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(parameterTypes, $.$$.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                }
                return parameterTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(60130590834)
            
            //--TRIMMABLE-BOUNDARY-START(64425558130)
            static /*Assembly */ GetRequiredLoadedAssembly(/*AssemblyKey*/ assemblyKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425558130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Assembly?*/ let assembly = null;
                let $i13 = 0;
                let $arr13 = $.$$.S.AppDomain.CurrentDomain.GetAssemblies();
                while ($i13 < $arr13.length)
                {
                    let a = $arr13[$i13++];
                    if (new $.$mj.MJI$1.DotNetDispatcher.AssemblyKey().$ctor$3(a).Equals$2(assemblyKey))
                    {
                        assembly = a;
                    }
                }
                return $.$firstOf(assembly, () => { throw new $.$$.S.ArgumentException().$ctor$14(`There is no loaded assembly with the name '${$.$strNN(assemblyKey.AssemblyName)}'.`) });
            }
            //--TRIMMABLE-BOUNDARY-END(64425558130)
            
            //--TRIMMABLE-BOUNDARY-START(1179762)
            static $_MetadataUpdateHandler;
            static get MetadataUpdateHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1179762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mj.MJI$1.DotNetDispatcher;
                return $cls.$_MetadataUpdateHandler ??= $asm.$ncls(`$mj.MJI$1.DotNetDispatcher.MetadataUpdateHandler`, ($self) => class MetadataUpdateHandler
                {
                    //--TRIMMABLE-BOUNDARY-START(4296147058)
                    static /*void */ ClearCache(/*Type[]?*/ _)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296147058);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$mj.MJI$1.DotNetDispatcher._cachedMethodsByAssembly.Clear();
                        $.$mj.MJI$1.DotNetDispatcher._cachedMethodsByType.Clear();
                        $.$mj.MJI$1.DotNetDispatcher._cachedConvertToTaskByType.Clear();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296147058)
                    
                    static $h = 1179762;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296147058),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "ClearCache",
      "d": 1179762,
      "h": 4296147058,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296147058)
  ],
  "d": 1048690,
  "h": 1179762
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.DotNetDispatcher+MetadataUpdateHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}DotNetDispatcher${separator}MetadataUpdateHandler`; }
                }, $cls, ($v) => $cls.$_MetadataUpdateHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1179762)
            
            //--TRIMMABLE-BOUNDARY-START(1114226)
            static $_AssemblyKey;
            static get AssemblyKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mj.MJI$1.DotNetDispatcher;
                return $cls.$_AssemblyKey ??= $asm.$nstr(`$mj.MJI$1.DotNetDispatcher.AssemblyKey`, ($self) => class AssemblyKey extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17180983410)
                    $ctor$3(/*Assembly*/ assembly)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180983410);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Assembly = assembly;
                            this.AssemblyName = assembly.GetName().Name;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180983410)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475950706)
                    $ctor$4(/*string*/ assemblyName)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475950706);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Assembly = null;
                            this.AssemblyName = assemblyName;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475950706)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770918002)
                    /*Assembly?*/ Assembly = null;
                    //--TRIMMABLE-BOUNDARY-END(25770918002)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065885298)
                    /*string*/ AssemblyName = null;
                    //--TRIMMABLE-BOUNDARY-END(30065885298)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360852594)
                    /*bool */ Equals$2(/*AssemblyKey*/ other)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360852594);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if ($.$$.SR.Assembly.op_Inequality(this.Assembly, null) && $.$$.SR.Assembly.op_Inequality(other.Assembly, null))
                        {
                            return $.$$.SR.Assembly.op_Equality(this.Assembly, other.Assembly);
                        }
                        return $.$$.S.String.Equals$2.call(this.AssemblyName, other.AssemblyName, 4/*StringComparison.Ordinal*/);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360852594)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835689074)
                    /*int */ GetHashCode()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(55835689074);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.S.StringComparer.Ordinal.GetHashCode$2(this.AssemblyName);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835689074)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386127873)
                    //Generated interface implemetation for System.IEquatable<Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey>.Equals(Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey)
                    S$IEquatable$Microsoft$JSInterop$Infrastructure$DotNetDispatcher$AssemblyKey$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386127873);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386127873)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886016114)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886016114);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886016114)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886016114)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886016114)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.AssemblyName = this.AssemblyName;
                        return copy;
                    }
                    static $h = 1114226;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770918002),
    {
      "p": 107020289,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787186,
        "f": 50331649
      },
      "n": "Assembly",
      "d": 1114226,
      "h": 25770918002,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770918002),
//--TRIMMABLE-BOUNDARY-START(30065885298),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721778,
        "f": 50331649
      },
      "n": "AssemblyName",
      "d": 1114226,
      "h": 30065885298,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065885298)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360852594),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1114226
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1114226,
      "h": 34360852594,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360852594),
//--TRIMMABLE-BOUNDARY-START(55835689074),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1114226,
      "h": 55835689074,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835689074)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180983410),
    {
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114226,
      "h": 17180983410,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983410),
//--TRIMMABLE-BOUNDARY-START(21475950706),
    {
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1114226,
      "h": 21475950706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475950706),
//--TRIMMABLE-BOUNDARY-START(12886016114),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114226,
      "h": 12886016114,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016114)
  ],
  "d": 1048690,
  "h": 1114226
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$mj.MJI$1.DotNetDispatcher.AssemblyKey) ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.DotNetDispatcher+AssemblyKey`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}DotNetDispatcher${separator}AssemblyKey`; }
                }, $cls, ($v) => $cls.$_AssemblyKey = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114226)
            
            //--TRIMMABLE-BOUNDARY-START(21475885170)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(34360787058)
                    this.DisposeDotNetObjectReferenceMethodName = "__Dispose";
                    //--TRIMMABLE-BOUNDARY-END(34360787058)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655754354)
                    this.DotNetObjectRefKey = $.$stj.STJ.JsonEncodedText.Encode$2("__dotNetObject", null);
                    //--TRIMMABLE-BOUNDARY-END(38655754354)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590983282)
                    this._cachedMethodsByAssembly = new ($.$scc.SCC.ConcurrentDictionary$$$($.$mj.MJI$1.DotNetDispatcher.AssemblyKey, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8590983282)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885950578)
                    this._cachedMethodsByType = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(12885950578)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296015986)
                    this._cachedConvertToTaskByType = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.S.Func$$$($.$$.S.Object, $.$$.STT.Task)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4296015986)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180917874)
                    this._taskConverterMethodInfo = $.$mj.MJI$1.DotNetDispatcher.$type.GetMethod$9("CreateValueTaskConverter", 32/*BindingFlags.NonPublic*/ | 8/*BindingFlags.Static*/);
                    //--TRIMMABLE-BOUNDARY-END(17180917874)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475885170)
            
            static $h = 1048690;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015492722),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "invocationInfo",
          "p": 1245298,
          "f": 8
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "Invoke",
      "d": 1048690,
      "h": 73015492722,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015492722),
//--TRIMMABLE-BOUNDARY-START(25770852466),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "invocationInfo",
          "p": 1245298
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "BeginInvokeDotNet",
      "d": 1048690,
      "h": 25770852466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770852466),
//--TRIMMABLE-BOUNDARY-START(42950721650),
    {
      "r": 65537,
      "p": [
        {
          "n": "task",
          "p": 178454529
        },
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "invocationInfo",
          "p": 1245298,
          "f": 8
        }
      ],
      "n": "EndInvokeDotNetAfterTask",
      "d": 1048690,
      "h": 42950721650,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950721650),
//--TRIMMABLE-BOUNDARY-START(77310460018),
    {
      "r": 131073,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "callInfo",
          "p": 1245298,
          "f": 8
        },
        {
          "n": "objectReference",
          "p": 1572978
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "InvokeSynchronously",
      "d": 1048690,
      "h": 77310460018,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77310460018),
//--TRIMMABLE-BOUNDARY-START(81605427314),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": 1310721
        },
        {
          "n": "parameterTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "ParseArguments",
      "d": 1048690,
      "h": 81605427314,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(81605427314),
//--TRIMMABLE-BOUNDARY-START(47245688946),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "arguments",
          "p": 1310721
        }
      ],
      "n": "EndInvokeJS",
      "d": 1048690,
      "h": 47245688946,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245688946),
//--TRIMMABLE-BOUNDARY-START(85900394610),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "ReceiveByteArray",
      "d": 1048690,
      "h": 85900394610,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85900394610),
//--TRIMMABLE-BOUNDARY-START(51540656242),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)).$h,
      "p": [
        {
          "n": "assemblyKey",
          "p": 1114226
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        }
      ],
      "n": "GetCachedMethodInfo",
      "d": 1048690,
      "h": 51540656242,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51540656242),
//--TRIMMABLE-BOUNDARY-START(68720525426),
    {
      "r": 178454529,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "GetTaskByType",
      "d": 1048690,
      "h": 68720525426,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720525426),
//--TRIMMABLE-BOUNDARY-START(30065819762),
    {
      "r": 178454529,
      "p": [
        {
          "n": "result",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateValueTaskConverter",
      "d": 1048690,
      "h": 30065819762,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(30065819762),
//--TRIMMABLE-BOUNDARY-START(55835623538),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)).$h,
      "p": [
        {
          "n": "objectReference",
          "p": 1572978
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        }
      ],
      "n": "GetCachedMethodInfo",
      "o": "@$1",
      "d": 1048690,
      "h": 55835623538,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835623538),
//--TRIMMABLE-BOUNDARY-START(90195361906),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type))).$h,
      "p": [
        {
          "n": "assemblyKey",
          "p": 1114226
        }
      ],
      "n": "ScanAssemblyForCallableMethods",
      "d": 1048690,
      "h": 90195361906,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90195361906),
//--TRIMMABLE-BOUNDARY-START(60130590834),
    {
      "r": $.$typeArray($.$$.S.Type).$h,
      "p": [
        {
          "n": "method",
          "p": 117571585
        }
      ],
      "n": "GetParameterTypes",
      "d": 1048690,
      "h": 60130590834,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60130590834),
//--TRIMMABLE-BOUNDARY-START(64425558130),
    {
      "r": 107020289,
      "p": [
        {
          "n": "assemblyKey",
          "p": 1114226
        }
      ],
      "n": "GetRequiredLoadedAssembly",
      "d": 1048690,
      "h": 64425558130,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425558130)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360787058),
    {
      "t": 1310721,
      "n": "DisposeDotNetObjectReferenceMethodName",
      "d": 1048690,
      "h": 34360787058,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34360787058),
//--TRIMMABLE-BOUNDARY-START(38655754354),
    {
      "t": 2293844,
      "n": "DotNetObjectRefKey",
      "d": 1048690,
      "h": 38655754354,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655754354),
//--TRIMMABLE-BOUNDARY-START(8590983282),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$mj.MJI$1.DotNetDispatcher.AssemblyKey, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))).$h,
      "n": "_cachedMethodsByAssembly",
      "d": 1048690,
      "h": 8590983282,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590983282),
//--TRIMMABLE-BOUNDARY-START(12885950578),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.SR.MethodInfo, $.$typeArray($.$$.S.Type)))).$h,
      "n": "_cachedMethodsByType",
      "d": 1048690,
      "h": 12885950578,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885950578),
//--TRIMMABLE-BOUNDARY-START(4296015986),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.S.Func$$$($.$$.S.Object, $.$$.STT.Task)).$h,
      "n": "_cachedConvertToTaskByType",
      "d": 1048690,
      "h": 4296015986,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296015986),
//--TRIMMABLE-BOUNDARY-START(17180917874),
    {
      "t": 117571585,
      "n": "_taskConverterMethodInfo",
      "d": 1048690,
      "h": 17180917874,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180917874)
  ],
  "h": 1048690
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mj.MJI$1.DotNetDispatcher.MetadataUpdateHandler, $.$mj.MJI$1.DotNetDispatcher.AssemblyKey ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.DotNetDispatcher`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}DotNetDispatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048690)
        
        

        //--TRIMMABLE-BOUNDARY-START(3014770)
        $asm.$cls(`$mj.MJ.JSRuntimeExtensions`, ($self) => class JSRuntimeExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(34362753138)
            static /*ValueTask *//*async*/  InvokeVoidAsync(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362753138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                    ($t1 = jsRuntime.MJ$IJSRuntime$InvokeAsync($.$mj.MJI$1.IJSVoidResult, identifier, args), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34362753138)
            
            //--TRIMMABLE-BOUNDARY-START(8592949362)
            static /*ValueTask<TValue> */ InvokeAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592949362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                return jsRuntime.MJ$IJSRuntime$InvokeAsync(TValue, identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(8592949362)
            
            //--TRIMMABLE-BOUNDARY-START(12887916658)
            static /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887916658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                return jsRuntime.MJ$IJSRuntime$InvokeAsync$1(TValue, identifier, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(12887916658)
            
            //--TRIMMABLE-BOUNDARY-START(38657720434)
            static /*ValueTask *//*async*/  InvokeVoidAsync$1(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657720434);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                    ($t2 = jsRuntime.MJ$IJSRuntime$InvokeAsync$1($.$mj.MJI$1.IJSVoidResult, identifier, cancellationToken, args), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38657720434)
            
            //--TRIMMABLE-BOUNDARY-START(17182883954)
            static /*ValueTask<TValue> *//*async*/  InvokeAsync$2(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TValue), TValue, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182883954);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                    /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                    try
                    {
                        let $t3, $r3;
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = jsRuntime.MJ$IJSRuntime$InvokeAsync$1(TValue, identifier, cancellationToken, args), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                    }
                    finally
                    {
                        cancellationTokenSource?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182883954)
            
            //--TRIMMABLE-BOUNDARY-START(42952687730)
            static /*ValueTask *//*async*/  InvokeVoidAsync$2(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952687730);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                    /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                    try
                    {
                        let $t4, $r4;
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                        ($t4 = jsRuntime.MJ$IJSRuntime$InvokeAsync$1($.$mj.MJI$1.IJSVoidResult, identifier, cancellationToken, args), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    finally
                    {
                        cancellationTokenSource?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42952687730)
            
            //--TRIMMABLE-BOUNDARY-START(21477851250)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477851250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                return jsRuntime.MJ$IJSRuntime$InvokeConstructorAsync(identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(21477851250)
            
            //--TRIMMABLE-BOUNDARY-START(25772818546)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772818546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                return jsRuntime.MJ$IJSRuntime$InvokeConstructorAsync$1(identifier, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(25772818546)
            
            //--TRIMMABLE-BOUNDARY-START(30067785842)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$2(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067785842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                    return jsRuntime.MJ$IJSRuntime$InvokeConstructorAsync$1(identifier, cancellationToken, args);
                }
                finally
                {
                    cancellationTokenSource?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067785842)
            
            //--TRIMMABLE-BOUNDARY-START(4297982066)
            static /*ValueTask<TValue> */ GetValueAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297982066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                    return jsRuntime.MJ$IJSRuntime$GetValueAsync(TValue, identifier, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297982066)
            
            //--TRIMMABLE-BOUNDARY-START(47247655026)
            static /*ValueTask */ SetValueAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TValue*/ value, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247655026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                    return jsRuntime.MJ$IJSRuntime$SetValueAsync(TValue, identifier, value, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247655026)
            
            static $h = 3014770;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362753138),
    {
      "r": 181338113,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "d": 3014770,
      "h": 34362753138,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(34362753138),
//--TRIMMABLE-BOUNDARY-START(8592949362),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "d": 3014770,
      "h": 8592949362,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8592949362),
//--TRIMMABLE-BOUNDARY-START(12887916658),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 3014770,
      "h": 12887916658,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887916658),
//--TRIMMABLE-BOUNDARY-START(38657720434),
    {
      "r": 181338113,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "o": "@$1",
      "d": 3014770,
      "h": 38657720434,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(38657720434),
//--TRIMMABLE-BOUNDARY-START(17182883954),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 186646529
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 3014770,
      "h": 17182883954,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(17182883954),
//--TRIMMABLE-BOUNDARY-START(42952687730),
    {
      "r": 181338113,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 186646529
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "o": "@$2",
      "d": 3014770,
      "h": 42952687730,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(42952687730),
//--TRIMMABLE-BOUNDARY-START(21477851250),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeConstructorAsync",
      "d": 3014770,
      "h": 21477851250,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477851250),
//--TRIMMABLE-BOUNDARY-START(25772818546),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$1",
      "d": 3014770,
      "h": 25772818546,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772818546),
//--TRIMMABLE-BOUNDARY-START(30067785842),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 186646529
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$2",
      "d": 3014770,
      "h": 30067785842,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067785842),
//--TRIMMABLE-BOUNDARY-START(4297982066),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "d": 3014770,
      "h": 4297982066,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4297982066),
//--TRIMMABLE-BOUNDARY-START(47247655026),
    {
      "r": 181338113,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "d": 3014770,
      "h": 47247655026,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47247655026)
  ],
  "h": 3014770
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSRuntimeExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSRuntimeExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014770)
        
        

        //--TRIMMABLE-BOUNDARY-START(2883698)
        $asm.$cls(`$mj.MJ.JSObjectReferenceExtensions`, ($self) => class JSObjectReferenceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(34362622066)
            static /*ValueTask *//*async*/  InvokeVoidAsync(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362622066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                    ($t1 = jsObjectReference.MJ$IJSObjectReference$InvokeAsync($.$mj.MJI$1.IJSVoidResult, identifier, args), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34362622066)
            
            //--TRIMMABLE-BOUNDARY-START(8592818290)
            static /*ValueTask<TValue> */ InvokeAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592818290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                return jsObjectReference.MJ$IJSObjectReference$InvokeAsync(TValue, identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(8592818290)
            
            //--TRIMMABLE-BOUNDARY-START(12887785586)
            static /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887785586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                return jsObjectReference.MJ$IJSObjectReference$InvokeAsync$1(TValue, identifier, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(12887785586)
            
            //--TRIMMABLE-BOUNDARY-START(38657589362)
            static /*ValueTask *//*async*/  InvokeVoidAsync$1(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657589362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                    ($t2 = jsObjectReference.MJ$IJSObjectReference$InvokeAsync$1($.$mj.MJI$1.IJSVoidResult, identifier, cancellationToken, args), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38657589362)
            
            //--TRIMMABLE-BOUNDARY-START(17182752882)
            static /*ValueTask<TValue> *//*async*/  InvokeAsync$2(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TValue), TValue, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182752882);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                    /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                    try
                    {
                        let $t3, $r3;
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = jsObjectReference.MJ$IJSObjectReference$InvokeAsync$1(TValue, identifier, cancellationToken, args), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                    }
                    finally
                    {
                        cancellationTokenSource?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182752882)
            
            //--TRIMMABLE-BOUNDARY-START(42952556658)
            static /*ValueTask *//*async*/  InvokeVoidAsync$2(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952556658);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                    /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                    try
                    {
                        let $t4, $r4;
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                        ($t4 = jsObjectReference.MJ$IJSObjectReference$InvokeAsync$1($.$mj.MJI$1.IJSVoidResult, identifier, cancellationToken, args), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    finally
                    {
                        cancellationTokenSource?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42952556658)
            
            //--TRIMMABLE-BOUNDARY-START(21477720178)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477720178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                return jsObjectReference.MJ$IJSObjectReference$InvokeConstructorAsync(identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(21477720178)
            
            //--TRIMMABLE-BOUNDARY-START(25772687474)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772687474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                return jsObjectReference.MJ$IJSObjectReference$InvokeConstructorAsync$1(identifier, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(25772687474)
            
            //--TRIMMABLE-BOUNDARY-START(30067654770)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$2(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067654770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                    return jsObjectReference.MJ$IJSObjectReference$InvokeConstructorAsync$1(identifier, cancellationToken, args);
                }
                finally
                {
                    cancellationTokenSource?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067654770)
            
            //--TRIMMABLE-BOUNDARY-START(4297850994)
            static /*ValueTask<TValue> */ GetValueAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297850994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                    return jsObjectReference.MJ$IJSObjectReference$GetValueAsync(TValue, identifier, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297850994)
            
            //--TRIMMABLE-BOUNDARY-START(47247523954)
            static /*ValueTask */ SetValueAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TValue*/ value, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247523954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) ? null : new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.ST$1.CancellationToken.None;
                    return jsObjectReference.MJ$IJSObjectReference$SetValueAsync(TValue, identifier, value, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247523954)
            
            static $h = 2883698;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362622066),
    {
      "r": 181338113,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "d": 2883698,
      "h": 34362622066,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(34362622066),
//--TRIMMABLE-BOUNDARY-START(8592818290),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "d": 2883698,
      "h": 8592818290,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8592818290),
//--TRIMMABLE-BOUNDARY-START(12887785586),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 2883698,
      "h": 12887785586,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887785586),
//--TRIMMABLE-BOUNDARY-START(38657589362),
    {
      "r": 181338113,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "o": "@$1",
      "d": 2883698,
      "h": 38657589362,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(38657589362),
//--TRIMMABLE-BOUNDARY-START(17182752882),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 186646529
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 2883698,
      "h": 17182752882,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(17182752882),
//--TRIMMABLE-BOUNDARY-START(42952556658),
    {
      "r": 181338113,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 186646529
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "o": "@$2",
      "d": 2883698,
      "h": 42952556658,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(42952556658),
//--TRIMMABLE-BOUNDARY-START(21477720178),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeConstructorAsync",
      "d": 2883698,
      "h": 21477720178,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477720178),
//--TRIMMABLE-BOUNDARY-START(25772687474),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$1",
      "d": 2883698,
      "h": 25772687474,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772687474),
//--TRIMMABLE-BOUNDARY-START(30067654770),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 186646529
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$2",
      "d": 2883698,
      "h": 30067654770,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067654770),
//--TRIMMABLE-BOUNDARY-START(4297850994),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "d": 2883698,
      "h": 4297850994,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4297850994),
//--TRIMMABLE-BOUNDARY-START(47247523954),
    {
      "r": 181338113,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458866
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "d": 2883698,
      "h": 47247523954,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47247523954)
  ],
  "h": 2883698
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSObjectReferenceExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSObjectReferenceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883698)
        
        

        //--TRIMMABLE-BOUNDARY-START(262258)
        $asm.$cls(`$mj.MJ.DotNetStreamReference`, ($self) => class DotNetStreamReference extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885164146)
            $ctor$1(/*Stream*/ stream, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885164146);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Stream = $.$firstOf(stream, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("stream") });
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164146)
            
            //--TRIMMABLE-BOUNDARY-START(42949935218)
            /*Stream*/ Stream = null;
            //--TRIMMABLE-BOUNDARY-END(42949935218)
            
            //--TRIMMABLE-BOUNDARY-START(38654967922)
            /*bool*/ LeaveOpen = false;
            //--TRIMMABLE-BOUNDARY-END(38654967922)
            
            //--TRIMMABLE-BOUNDARY-START(17180131442)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.LeaveOpen)
                {
                    this.Stream.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180131442)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $h = 262258;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949935218),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000626,
        "f": 50331649
      },
      "n": "Stream",
      "d": 262258,
      "h": 42949935218,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949935218),
//--TRIMMABLE-BOUNDARY-START(38654967922),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770066034,
        "f": 50331649
      },
      "n": "LeaveOpen",
      "d": 262258,
      "h": 38654967922,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654967922)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131442),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262258,
      "h": 17180131442,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131442)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885164146),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "leaveOpen",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262258,
      "h": 12885164146,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164146)
  ],
  "h": 262258
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.DotNetStreamReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}DotNetStreamReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262258)
        
        

        //--TRIMMABLE-BOUNDARY-START(917618)
        $asm.$cls(`$mj.MJI$1.ArrayBuilder<>`, (T) => $asm.$gt(`$mj.MJI$1.ArrayBuilder<>`, [T], ($self) => class ArrayBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885819506)
            /*T[]*/ _items = null;
            //--TRIMMABLE-BOUNDARY-END(12885819506)
            
            //--TRIMMABLE-BOUNDARY-START(17180786802)
            /*int*/ _itemsInUse = 0;
            //--TRIMMABLE-BOUNDARY-END(17180786802)
            
            //--TRIMMABLE-BOUNDARY-START(64425427058)
            /*T[]*/ static Empty = null;
            //--TRIMMABLE-BOUNDARY-END(64425427058)
            
            //--TRIMMABLE-BOUNDARY-START(4295884914)
            /*ArrayPool<T>*/ _arrayPool = null;
            //--TRIMMABLE-BOUNDARY-END(4295884914)
            
            //--TRIMMABLE-BOUNDARY-START(21475754098)
            /*int*/ _minCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(21475754098)
            
            //--TRIMMABLE-BOUNDARY-START(8590852210)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590852210)
            
            //--TRIMMABLE-BOUNDARY-START(30065688690)
            $ctor$1(/*int*/ minCapacity, /*ArrayPool<T>*/ arrayPool)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065688690);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayPool = arrayPool ?? $.$$.SB.ArrayPool$$(T).Shared;
                    this._minCapacity = minCapacity;
                    this._items = $.$mj.MJI$1.ArrayBuilder$$(T).Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065688690)
            
            //--TRIMMABLE-BOUNDARY-START(55835492466)
            /*int */ get Count()
            {
                return this._itemsInUse;
            }
            //--TRIMMABLE-BOUNDARY-END(55835492466)
            
            //--TRIMMABLE-BOUNDARY-START(47245557874)
            /*T[] */ get Buffer()
            {
                return this._items;
            }
            //--TRIMMABLE-BOUNDARY-END(47245557874)
            
            //--TRIMMABLE-BOUNDARY-START(34360655986)
            /*int */ Append(/*in T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360655986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._itemsInUse === this._items.length)
                {
                    this.GrowBuffer(((this._items.length * 2) | 0));
                }
                /*var*/ let indexOfAppendedItem = this._itemsInUse++;
                $.$$.System.Array.$WriteT1.call(this._items, item.$v, indexOfAppendedItem);
                return indexOfAppendedItem;
            }
            //--TRIMMABLE-BOUNDARY-END(34360655986)
            
            //--TRIMMABLE-BOUNDARY-START(42950590578)
            /*int */ Append$2(/*T[]*/ source, /*int*/ startIndex, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950590578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Append$1($.$$.S.Span$$(T).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11(T, source, startIndex, length)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950590578)
            
            //--TRIMMABLE-BOUNDARY-START(38655623282)
            /*int */ Append$1(/*ReadOnlySpan<T>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let requiredCapacity = ((this._itemsInUse + source.Length) | 0);
                if (this._items.length < requiredCapacity)
                {
                    /*var*/ let candidateCapacity = $.$$.S.Math.Max$4(((this._items.length * 2) | 0), this._minCapacity);
                    while(candidateCapacity < requiredCapacity)
                    {
                        candidateCapacity *= 2;
                    }
                    this.GrowBuffer(candidateCapacity);
                }
                source.CopyTo($.$$.S.MemoryExtensions.AsSpan$12(T, this._items, this._itemsInUse));
                /*var*/ let startIndexOfAppendedItems = this._itemsInUse;
                this._itemsInUse += source.Length;
                return startIndexOfAppendedItems;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623282)
            
            //--TRIMMABLE-BOUNDARY-START(94490198130)
            /*void */ Overwrite(/*int*/ index, /*in T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490198130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index > this._itemsInUse)
                {
                    $.$mj.MJI$1.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                $.$$.System.Array.$WriteT1.call(this._items, value.$v, index);
            }
            //--TRIMMABLE-BOUNDARY-END(94490198130)
            
            //--TRIMMABLE-BOUNDARY-START(98785165426)
            /*void */ RemoveLast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785165426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._itemsInUse === 0)
                {
                    $.$mj.MJI$1.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                this._itemsInUse--;
                $.$$.System.Array.$WriteT1.call(this._items, $.$default(T), this._itemsInUse);
            }
            //--TRIMMABLE-BOUNDARY-END(98785165426)
            
            //--TRIMMABLE-BOUNDARY-START(90195230834)
            /*void */ InsertExpensive(/*int*/ index, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195230834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index > this._itemsInUse)
                {
                    $.$mj.MJI$1.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                if (this._itemsInUse === this._items.length)
                {
                    this.GrowBuffer(((this._items.length * 2) | 0));
                }
                $.$$.S.Array.Copy(this._items, index, this._items, ((index + 1) | 0), ((this._itemsInUse - index) | 0));
                this._itemsInUse++;
                $.$$.System.Array.$WriteT1.call(this._items, value, index);
            }
            //--TRIMMABLE-BOUNDARY-END(90195230834)
            
            //--TRIMMABLE-BOUNDARY-START(51540525170)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReturnBuffer();
                this._items = $.$mj.MJI$1.ArrayBuilder$$(T).Empty;
                this._itemsInUse = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525170)
            
            //--TRIMMABLE-BOUNDARY-START(85900263538)
            /*void */ GrowBuffer(/*int*/ desiredCapacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900263538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf$1(this._disposed, null);
                /*var*/ let newCapacity = $.$$.S.Math.Max$4(desiredCapacity, this._minCapacity);
                $.$$.SD.Debug.Assert$4(newCapacity > this._items.length, "newCapacity > _items.Length");
                /*var*/ let newItems = this._arrayPool.Rent(newCapacity);
                $.$$.S.Array.Copy$2(this._items, newItems, this._itemsInUse);
                this.ReturnBuffer();
                this._items = newItems;
            }
            //--TRIMMABLE-BOUNDARY-END(85900263538)
            
            //--TRIMMABLE-BOUNDARY-START(103080132722)
            /*void */ ReturnBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080132722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.Object.ReferenceEquals(this._items, $.$mj.MJI$1.ArrayBuilder$$(T).Empty))
                {
                    $.$$.S.Array.Clear(this._items, 0, this._itemsInUse);
                    this._arrayPool.Return(this._items, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080132722)
            
            //--TRIMMABLE-BOUNDARY-START(60130459762)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130459762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    this.ReturnBuffer();
                    this._items = $.$mj.MJI$1.ArrayBuilder$$(T).Empty;
                    this._itemsInUse = 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130459762)
            
            //--TRIMMABLE-BOUNDARY-START(107375100018)
            static /*void */ ThrowIndexOutOfBoundsException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375100018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("index");
            }
            //--TRIMMABLE-BOUNDARY-END(107375100018)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(25770721394)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(64425427058)
                    this.Empty = $.$$.S.Array.Empty(T);
                    //--TRIMMABLE-BOUNDARY-END(64425427058)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721394)
            
            static $H = 917618;
            static $h = 917618;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835492466),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81605296242,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "H": 55835492466,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835492466),
//--TRIMMABLE-BOUNDARY-START(47245557874),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73015361650,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Buffer",
      "d": this.$h,
      "H": 47245557874,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245557874)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360655986),
    {
      "r": 655361,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 8
        }
      ],
      "n": "Append",
      "d": this.$h,
      "H": 34360655986,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360655986),
//--TRIMMABLE-BOUNDARY-START(42950590578),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": this.$h,
      "H": 42950590578,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42950590578),
//--TRIMMABLE-BOUNDARY-START(38655623282),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": this.$h,
      "H": 38655623282,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38655623282),
//--TRIMMABLE-BOUNDARY-START(94490198130),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": T?.$h??1572864,
          "f": 8
        }
      ],
      "n": "Overwrite",
      "d": this.$h,
      "H": 94490198130,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490198130),
//--TRIMMABLE-BOUNDARY-START(98785165426),
    {
      "r": 65537,
      "n": "RemoveLast",
      "d": this.$h,
      "H": 98785165426,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785165426),
//--TRIMMABLE-BOUNDARY-START(90195230834),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": T?.$h??1572864
        }
      ],
      "n": "InsertExpensive",
      "d": this.$h,
      "H": 90195230834,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195230834),
//--TRIMMABLE-BOUNDARY-START(51540525170),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "H": 51540525170,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540525170),
//--TRIMMABLE-BOUNDARY-START(85900263538),
    {
      "r": 65537,
      "p": [
        {
          "n": "desiredCapacity",
          "p": 655361
        }
      ],
      "n": "GrowBuffer",
      "d": this.$h,
      "H": 85900263538,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(85900263538),
//--TRIMMABLE-BOUNDARY-START(103080132722),
    {
      "r": 65537,
      "n": "ReturnBuffer",
      "d": this.$h,
      "H": 103080132722,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080132722),
//--TRIMMABLE-BOUNDARY-START(60130459762),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 60130459762,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130459762),
//--TRIMMABLE-BOUNDARY-START(107375100018),
    {
      "r": 65537,
      "n": "ThrowIndexOutOfBoundsException",
      "d": this.$h,
      "H": 107375100018,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375100018)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819506),
    {
      "t": $.$typeArray(T).$h,
      "n": "_items",
      "d": this.$h,
      "H": 12885819506,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(12885819506),
//--TRIMMABLE-BOUNDARY-START(17180786802),
    {
      "t": 655361,
      "n": "_itemsInUse",
      "d": this.$h,
      "H": 17180786802,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(17180786802),
//--TRIMMABLE-BOUNDARY-START(64425427058),
    {
      "t": $.$typeArray(T).$h,
      "n": "Empty",
      "d": this.$h,
      "H": 64425427058,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425427058),
//--TRIMMABLE-BOUNDARY-START(4295884914),
    {
      "t": $.$$.SB.ArrayPool$$(T).$h,
      "n": "_arrayPool",
      "d": this.$h,
      "H": 4295884914,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884914),
//--TRIMMABLE-BOUNDARY-START(21475754098),
    {
      "t": 655361,
      "n": "_minCapacity",
      "d": this.$h,
      "H": 21475754098,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475754098),
//--TRIMMABLE-BOUNDARY-START(8590852210),
    {
      "t": 262145,
      "n": "_disposed",
      "d": this.$h,
      "H": 8590852210,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852210)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065688690),
    {
      "p": [
        {
          "n": "minCapacity",
          "p": 655361,
          "f": 65,
          "v": 32
        },
        {
          "n": "arrayPool",
          "p": $.$$.SB.ArrayPool$$(T).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 30065688690,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688690)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 917618,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.ArrayBuilder<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}ArrayBuilder$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917618)
        
        

        //--TRIMMABLE-BOUNDARY-START(196722)
        $asm.$cls(`$mj.MJ.DotNetObjectReference<>`, (TValue) => $asm.$gt(`$mj.MJ.DotNetObjectReference<>`, [TValue], ($self) => class DotNetObjectReference$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885098610)
            /*TValue*/ _value = $.$default(TValue);
            //--TRIMMABLE-BOUNDARY-END(12885098610)
            
            //--TRIMMABLE-BOUNDARY-START(8590131314)
            /*long*/ _objectId = 0n;
            //--TRIMMABLE-BOUNDARY-END(8590131314)
            
            //--TRIMMABLE-BOUNDARY-START(4295164018)
            /*JSRuntime?*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4295164018)
            
            //--TRIMMABLE-BOUNDARY-START(21475033202)
            $ctor$1(/*TValue*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475033202);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475033202)
            
            //--TRIMMABLE-BOUNDARY-START(120259281010)
            /*TValue */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._value;
            }
            //--TRIMMABLE-BOUNDARY-END(120259281010)
            
            //--TRIMMABLE-BOUNDARY-START(85899542642)
            /*long */ get ObjectId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                $.$$.SD.Debug.Assert$4(this._objectId !== 0n, "Accessing ObjectId without tracking is always incorrect.");
                return this._objectId;
            }
            /*long */ set ObjectId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this._objectId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(85899542642)
            
            //--TRIMMABLE-BOUNDARY-START(68719673458)
            /*JSRuntime? */ get JSRuntime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime;
            }
            /*JSRuntime? */ set JSRuntime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079411826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this._jsRuntime = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68719673458)
            
            //--TRIMMABLE-BOUNDARY-START(81604575346)
            /*object */ get MJI$1$IDotNetObjectReference$Value()
            {
                return $.$box(this.Value, TValue);
            }
            //--TRIMMABLE-BOUNDARY-END(81604575346)
            
            //--TRIMMABLE-BOUNDARY-START(30064967794)
            /*bool*/ Disposed = false;
            //--TRIMMABLE-BOUNDARY-END(30064967794)
            
            //--TRIMMABLE-BOUNDARY-START(25770000498)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this._jsRuntime?.ReleaseObjectReference(this._objectId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770000498)
            
            //--TRIMMABLE-BOUNDARY-START(115964313714)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(115964313714)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $H = 196722;
            static $h = 196722;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120259281010),
    {
      "p": TValue?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64424706162,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "H": 120259281010,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259281010),
//--TRIMMABLE-BOUNDARY-START(85899542642),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55834771570,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 111669346418,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 83886088
      },
      "n": "ObjectId",
      "d": this.$h,
      "H": 85899542642,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(85899542642),
//--TRIMMABLE-BOUNDARY-START(68719673458),
    {
      "p": 2949234,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47244836978,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 103079411826,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 83886088
      },
      "n": "JSRuntime",
      "d": this.$h,
      "H": 68719673458,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68719673458),
//--TRIMMABLE-BOUNDARY-START(81604575346),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77309608050,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331650
      },
      "n": "{1572978}.Value",
      "o": "MJI$1$IDotNetObjectReference$Value",
      "d": this.$h,
      "H": 81604575346,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(81604575346),
//--TRIMMABLE-BOUNDARY-START(30064967794),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38654902386,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 94489477234,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83886082
      },
      "n": "Disposed",
      "d": this.$h,
      "H": 30064967794,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(30064967794)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770000498),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 25770000498,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000498),
//--TRIMMABLE-BOUNDARY-START(115964313714),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": this.$h,
      "H": 115964313714,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115964313714)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885098610),
    {
      "t": TValue?.$h??1572864,
      "n": "_value",
      "d": this.$h,
      "H": 12885098610,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885098610),
//--TRIMMABLE-BOUNDARY-START(8590131314),
    {
      "t": 917505,
      "n": "_objectId",
      "d": this.$h,
      "H": 8590131314,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131314),
//--TRIMMABLE-BOUNDARY-START(4295164018),
    {
      "t": 2949234,
      "n": "_jsRuntime",
      "d": this.$h,
      "H": 4295164018,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295164018)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475033202),
    {
      "p": [
        {
          "n": "value",
          "p": TValue?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 21475033202,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475033202)
  ],
  "s": [
    {
      "h": TValue?.$h??1572864,
      "n": "TValue",
      "f": 1
    }
  ],
  "r": 1,
  "H": 196722,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.MJI$1.IDotNetObjectReference, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.DotNetObjectReference<${TValue?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}DotNetObjectReference$${TValue?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196722)
        
        

        //--TRIMMABLE-BOUNDARY-START(721010)
        $asm.$cls(`$mj.MJI.JSObjectReference`, ($self) => class JSObjectReference extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688306)
            /*JSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4295688306)
            
            //--TRIMMABLE-BOUNDARY-START(25770524786)
            /*bool*/ Disposed = false;
            //--TRIMMABLE-BOUNDARY-END(25770524786)
            
            //--TRIMMABLE-BOUNDARY-START(55835295858)
            /*long*/ Id = 0n;
            //--TRIMMABLE-BOUNDARY-END(55835295858)
            
            //--TRIMMABLE-BOUNDARY-START(17180590194)
            $ctor$1(/*JSRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180590194);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                    this.Id = id;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590194)
            
            //--TRIMMABLE-BOUNDARY-START(60130263154)
            /*ValueTask<TValue> */ InvokeAsync(TValue, /*string*/ identifier, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync(TValue, this.Id, identifier, 1/*JSCallType.FunctionCall*/, args);
            }
            //--TRIMMABLE-BOUNDARY-END(60130263154)
            
            //--TRIMMABLE-BOUNDARY-START(64425230450)
            /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$1(TValue, this.Id, identifier, 1/*JSCallType.FunctionCall*/, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(64425230450)
            
            //--TRIMMABLE-BOUNDARY-START(68720197746)
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync($.$mj.MJ.IJSObjectReference, this.Id, identifier, 2/*JSCallType.ConstructorCall*/, args);
            }
            //--TRIMMABLE-BOUNDARY-END(68720197746)
            
            //--TRIMMABLE-BOUNDARY-START(73015165042)
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$1($.$mj.MJ.IJSObjectReference, this.Id, identifier, 2/*JSCallType.ConstructorCall*/, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(73015165042)
            
            //--TRIMMABLE-BOUNDARY-START(51540328562)
            /*ValueTask<TValue> */ GetValueAsync$1(TValue, /*string*/ identifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync(TValue, this.Id, identifier, 3/*JSCallType.GetValue*/, null);
            }
            //--TRIMMABLE-BOUNDARY-END(51540328562)
            
            //--TRIMMABLE-BOUNDARY-START(47245361266)
            /*ValueTask<TValue> */ GetValueAsync(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$1(TValue, this.Id, identifier, 3/*JSCallType.GetValue*/, cancellationToken, null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245361266)
            
            //--TRIMMABLE-BOUNDARY-START(90195034226)
            /*ValueTask *//*async*/  SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195034226);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    ($t1 = this._jsRuntime.InvokeAsync(TValue, this.Id, identifier, 4/*JSCallType.SetValue*/, $.$$.SRC.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90195034226)
            
            //--TRIMMABLE-BOUNDARY-START(85900066930)
            /*ValueTask *//*async*/  SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900066930);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    ($t2 = this._jsRuntime.InvokeAsync$1(TValue, this.Id, identifier, 4/*JSCallType.SetValue*/, cancellationToken, $.$$.SRC.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900066930)
            
            //--TRIMMABLE-BOUNDARY-START(21475557490)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557490);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.Disposed)
                    {
                        let $t3, $r3;
                        this.Disposed = true;
                        ($t3 = $.$mj.MJ.JSRuntimeExtensions.InvokeVoidAsync(this._jsRuntime, "DotNet.disposeJSObjectReferenceById", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(this.Id, $.$$.S.Int64) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475557490)
            
            //--TRIMMABLE-BOUNDARY-START(94490001522)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(94490001522)
            
            //--TRIMMABLE-BOUNDARY-START(12885360754)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeAsync<TValue>(string, object?[]?)
            MJ$IJSObjectReference$InvokeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885360754)
            
            //--TRIMMABLE-BOUNDARY-START(17180328050)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeAsync<TValue>(string, System.Threading.CancellationToken, object?[]?)
            MJ$IJSObjectReference$InvokeAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180328050)
            
            //--TRIMMABLE-BOUNDARY-START(21475295346)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeConstructorAsync(string, object?[]?)
            MJ$IJSObjectReference$InvokeConstructorAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructorAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475295346)
            
            //--TRIMMABLE-BOUNDARY-START(25770262642)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeConstructorAsync(string, System.Threading.CancellationToken, object?[]?)
            MJ$IJSObjectReference$InvokeConstructorAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructorAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770262642)
            
            //--TRIMMABLE-BOUNDARY-START(8590393458)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.GetValueAsync<TValue>(string)
            MJ$IJSObjectReference$GetValueAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393458)
            
            //--TRIMMABLE-BOUNDARY-START(4295426162)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.GetValueAsync<TValue>(string, System.Threading.CancellationToken)
            MJ$IJSObjectReference$GetValueAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426162)
            
            //--TRIMMABLE-BOUNDARY-START(34360197234)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.SetValueAsync<TValue>(string, TValue)
            MJ$IJSObjectReference$SetValueAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValueAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360197234)
            
            //--TRIMMABLE-BOUNDARY-START(30065229938)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.SetValueAsync<TValue>(string, TValue, System.Threading.CancellationToken)
            MJ$IJSObjectReference$SetValueAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValueAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229938)
            
            //--TRIMMABLE-BOUNDARY-START(4385472513)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            S$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385472513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385472513)
            
            static $h = 721010;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770524786),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360459378,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605099634,
        "f": 83886088
      },
      "n": "Disposed",
      "d": 721010,
      "h": 25770524786,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25770524786),
//--TRIMMABLE-BOUNDARY-START(55835295858),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950393970,
        "f": 50331664
      },
      "n": "Id",
      "d": 721010,
      "h": 55835295858,
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(55835295858)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130263154),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "d": 721010,
      "h": 60130263154,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(60130263154),
//--TRIMMABLE-BOUNDARY-START(64425230450),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 721010,
      "h": 64425230450,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(64425230450),
//--TRIMMABLE-BOUNDARY-START(68720197746),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "d": 721010,
      "h": 68720197746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720197746),
//--TRIMMABLE-BOUNDARY-START(73015165042),
    {
      "r": $.$$.STT.ValueTask$$($.$mj.MJ.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$1",
      "d": 721010,
      "h": 73015165042,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015165042),
//--TRIMMABLE-BOUNDARY-START(51540328562),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "@$1",
      "d": 721010,
      "h": 51540328562,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(51540328562),
//--TRIMMABLE-BOUNDARY-START(47245361266),
    {
      "r": (TValue) => $.$$.STT.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "d": 721010,
      "h": 47245361266,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(47245361266),
//--TRIMMABLE-BOUNDARY-START(90195034226),
    {
      "r": 181338113,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "@$1",
      "d": 721010,
      "h": 90195034226,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(90195034226),
//--TRIMMABLE-BOUNDARY-START(85900066930),
    {
      "r": 181338113,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "d": 721010,
      "h": 85900066930,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(85900066930),
//--TRIMMABLE-BOUNDARY-START(21475557490),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 721010,
      "h": 21475557490,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475557490),
//--TRIMMABLE-BOUNDARY-START(94490001522),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 721010,
      "h": 94490001522,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(94490001522)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688306),
    {
      "t": 2949234,
      "n": "_jsRuntime",
      "d": 721010,
      "h": 4295688306,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688306)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180590194),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "id",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721010,
      "h": 17180590194,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(17180590194)
  ],
  "h": 721010
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.MJ.IJSObjectReference, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Implementation.JSObjectReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Implementation${separator}JSObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721010)
        
        

        //--TRIMMABLE-BOUNDARY-START(2818162)
        $asm.$cls(`$mj.MJ.JSInvokableAttribute`, ($self) => class JSInvokableAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(25772621938)
            /*string?*/ Identifier = null;
            //--TRIMMABLE-BOUNDARY-END(25772621938)
            
            //--TRIMMABLE-BOUNDARY-START(8592752754)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592752754);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592752754)
            
            //--TRIMMABLE-BOUNDARY-START(12887720050)
            $ctor$3(/*string*/ identifier)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887720050);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentException.ThrowIfNullOrEmpty(identifier, "identifier");
                    this.Identifier = identifier;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887720050)
            
            //--TRIMMABLE-BOUNDARY-START(8592752754)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592752754)
            
            static $h = 2818162;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772621938),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477654642,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 2818162,
      "h": 25772621938,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772621938)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592752754),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818162,
      "h": 8592752754,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592752754),
//--TRIMMABLE-BOUNDARY-START(12887720050),
    {
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2818162,
      "h": 12887720050,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887720050)
  ],
  "h": 2818162,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 64,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSInvokableAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSInvokableAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818162)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310834)
        $asm.$str(`$mj.MJI$1.DotNetInvocationResult`, ($self) => class DotNetInvocationResult extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25771114610)
            $ctor$3(/*Exception*/ exception, /*string?*/ errorKind)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771114610);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ResultJson = null;
                    this.Exception = $.$firstOf(exception, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("exception") });
                    this.ErrorKind = errorKind;
                    this.Success = false;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771114610)
            
            //--TRIMMABLE-BOUNDARY-START(30066081906)
            $ctor$4(/*string?*/ resultJson)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066081906);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ResultJson = resultJson;
                    this.Exception = null;
                    this.ErrorKind = null;
                    this.Success = true;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066081906)
            
            //--TRIMMABLE-BOUNDARY-START(38656016498)
            /*Exception?*/ Exception = null;
            //--TRIMMABLE-BOUNDARY-END(38656016498)
            
            //--TRIMMABLE-BOUNDARY-START(34361049202)
            /*string?*/ ErrorKind = null;
            //--TRIMMABLE-BOUNDARY-END(34361049202)
            
            //--TRIMMABLE-BOUNDARY-START(77310722162)
            /*string?*/ ResultJson = null;
            //--TRIMMABLE-BOUNDARY-END(77310722162)
            
            //--TRIMMABLE-BOUNDARY-START(81605689458)
            /*bool*/ Success = false;
            //--TRIMMABLE-BOUNDARY-END(81605689458)
            
            //--TRIMMABLE-BOUNDARY-START(21476147314)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476147314)
            
            //--TRIMMABLE-BOUNDARY-START(21476147314)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21476147314)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Exception = this.Exception;
                copy.ErrorKind = this.ErrorKind;
                copy.ResultJson = this.ResultJson;
                copy.Success = this.Success;
                return copy;
            }
            static $h = 1310834;
            static $z = 13;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656016498),
    {
      "p": 80805889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835885682,
        "f": 50331649
      },
      "n": "Exception",
      "d": 1310834,
      "h": 38656016498,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656016498),
//--TRIMMABLE-BOUNDARY-START(34361049202),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245951090,
        "f": 50331649
      },
      "n": "ErrorKind",
      "d": 1310834,
      "h": 34361049202,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361049202),
//--TRIMMABLE-BOUNDARY-START(77310722162),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425820274,
        "f": 50331649
      },
      "n": "ResultJson",
      "d": 1310834,
      "h": 77310722162,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310722162),
//--TRIMMABLE-BOUNDARY-START(81605689458),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015754866,
        "f": 50331649
      },
      "n": "Success",
      "d": 1310834,
      "h": 81605689458,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605689458)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771114610),
    {
      "p": [
        {
          "n": "exception",
          "p": 80805889
        },
        {
          "n": "errorKind",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310834,
      "h": 25771114610,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25771114610),
//--TRIMMABLE-BOUNDARY-START(30066081906),
    {
      "p": [
        {
          "n": "resultJson",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1310834,
      "h": 30066081906,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30066081906),
//--TRIMMABLE-BOUNDARY-START(21476147314),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310834,
      "h": 21476147314,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476147314)
  ],
  "h": 1310834
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.DotNetInvocationResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}DotNetInvocationResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310834)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245298)
        $asm.$str(`$mj.MJI$1.DotNetInvocationInfo`, ($self) => class DotNetInvocationInfo extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25771049074)
            $ctor$3(/*string?*/ assemblyName, /*string*/ methodIdentifier, /*long*/ dotNetObjectId, /*string?*/ callId)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771049074);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CallId = callId;
                    this.AssemblyName = assemblyName;
                    this.MethodIdentifier = methodIdentifier;
                    this.DotNetObjectId = dotNetObjectId;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771049074)
            
            //--TRIMMABLE-BOUNDARY-START(30066016370)
            /*string?*/ AssemblyName = null;
            //--TRIMMABLE-BOUNDARY-END(30066016370)
            
            //--TRIMMABLE-BOUNDARY-START(77310656626)
            /*string*/ MethodIdentifier = null;
            //--TRIMMABLE-BOUNDARY-END(77310656626)
            
            //--TRIMMABLE-BOUNDARY-START(38655950962)
            /*long*/ DotNetObjectId = 0n;
            //--TRIMMABLE-BOUNDARY-END(38655950962)
            
            //--TRIMMABLE-BOUNDARY-START(34360983666)
            /*string?*/ CallId = null;
            //--TRIMMABLE-BOUNDARY-END(34360983666)
            
            //--TRIMMABLE-BOUNDARY-START(21476081778)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476081778)
            
            //--TRIMMABLE-BOUNDARY-START(21476081778)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21476081778)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.AssemblyName = this.AssemblyName;
                copy.MethodIdentifier = this.MethodIdentifier;
                copy.DotNetObjectId = this.DotNetObjectId;
                copy.CallId = this.CallId;
                return copy;
            }
            static $h = 1245298;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066016370),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245885554,
        "f": 50331649
      },
      "n": "AssemblyName",
      "d": 1245298,
      "h": 30066016370,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066016370),
//--TRIMMABLE-BOUNDARY-START(77310656626),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015689330,
        "f": 50331649
      },
      "n": "MethodIdentifier",
      "d": 1245298,
      "h": 77310656626,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310656626),
//--TRIMMABLE-BOUNDARY-START(38655950962),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425754738,
        "f": 50331649
      },
      "n": "DotNetObjectId",
      "d": 1245298,
      "h": 38655950962,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655950962),
//--TRIMMABLE-BOUNDARY-START(34360983666),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835820146,
        "f": 50331649
      },
      "n": "CallId",
      "d": 1245298,
      "h": 34360983666,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360983666)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771049074),
    {
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "dotNetObjectId",
          "p": 917505
        },
        {
          "n": "callId",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245298,
      "h": 25771049074,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771049074),
//--TRIMMABLE-BOUNDARY-START(21476081778),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245298,
      "h": 21476081778,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476081778)
  ],
  "h": 1245298
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}DotNetInvocationInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245298)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769586)
        $asm.$str(`$mj.MJI$1.JSInvocationInfo`, ($self) => class JSInvocationInfo extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296736882)
            /*string?*/ _argsJson = null;
            //--TRIMMABLE-BOUNDARY-END(4296736882)
            
            //--TRIMMABLE-BOUNDARY-START(38656475250)
            /*long*/ AsyncHandle = 0n;
            //--TRIMMABLE-BOUNDARY-END(38656475250)
            
            //--TRIMMABLE-BOUNDARY-START(158915559538)
            /*long*/ TargetInstanceId = 0n;
            //--TRIMMABLE-BOUNDARY-END(158915559538)
            
            //--TRIMMABLE-BOUNDARY-START(98786017394)
            /*string*/ Identifier = null;
            //--TRIMMABLE-BOUNDARY-END(98786017394)
            
            //--TRIMMABLE-BOUNDARY-START(42951442546)
            /*JSCallType*/ CallType = 0;
            //--TRIMMABLE-BOUNDARY-END(42951442546)
            
            //--TRIMMABLE-BOUNDARY-START(103080984690)
            /*JSCallResultType*/ ResultType = 0;
            //--TRIMMABLE-BOUNDARY-END(103080984690)
            
            //--TRIMMABLE-BOUNDARY-START(34361507954)
            /*string */ get ArgsJson()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541377138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._argsJson ?? "[]";
            }
            /*string */ set ArgsJson(value)
            {
                return this._argsJson = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34361507954)
            
            //--TRIMMABLE-BOUNDARY-START(30066540658)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066540658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066540658)
            
            //--TRIMMABLE-BOUNDARY-START(30066540658)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30066540658)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._argsJson = this._argsJson;
                copy.AsyncHandle = this.AsyncHandle;
                copy.TargetInstanceId = this.TargetInstanceId;
                copy.Identifier = this.Identifier;
                copy.CallType = this.CallType;
                copy.ResultType = this.ResultType;
                return copy;
            }
            static $h = 1769586;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656475250),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131311730,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260853874,
        "f": 83886081
      },
      "n": "AsyncHandle",
      "d": 1769586,
      "h": 38656475250,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656475250),
//--TRIMMABLE-BOUNDARY-START(158915559538),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491050098,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620592242,
        "f": 83886081
      },
      "n": "TargetInstanceId",
      "d": 1769586,
      "h": 158915559538,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158915559538),
//--TRIMMABLE-BOUNDARY-START(98786017394),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311180914,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440723058,
        "f": 83886081
      },
      "n": "Identifier",
      "d": 1769586,
      "h": 98786017394,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786017394),
//--TRIMMABLE-BOUNDARY-START(42951442546),
    {
      "p": 1704050,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721246322,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850788466,
        "f": 83886081
      },
      "n": "CallType",
      "d": 1769586,
      "h": 42951442546,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951442546),
//--TRIMMABLE-BOUNDARY-START(103080984690),
    {
      "p": 2359410,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901115506,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030657650,
        "f": 83886081
      },
      "n": "ResultType",
      "d": 1769586,
      "h": 103080984690,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080984690),
//--TRIMMABLE-BOUNDARY-START(34361507954),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541377138,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670919282,
        "f": 83886081
      },
      "n": "ArgsJson",
      "d": 1769586,
      "h": 34361507954,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361507954)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736882),
    {
      "t": 1310721,
      "n": "_argsJson",
      "d": 1769586,
      "h": 4296736882,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736882)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066540658),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769586,
      "h": 30066540658,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066540658)
  ],
  "h": 1769586
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.JSInvocationInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}JSInvocationInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769586)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441906)
        $asm.$cls(`$mj.MJI$1.DotNetObjectReferenceJsonConverterFactory`, ($self) => class DotNetObjectReferenceJsonConverterFactory extends $.$stj.STJS$1.JsonConverterFactory
        {
            //--TRIMMABLE-BOUNDARY-START(8591376498)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376498);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591376498)
            
            //--TRIMMABLE-BOUNDARY-START(30066212978)
            /*JSRuntime*/ JSRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(30066212978)
            
            //--TRIMMABLE-BOUNDARY-START(12886343794)
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return typeToConvert.IsGenericType && typeToConvert.GetGenericTypeDefinition() === $.$mj.MJ.DotNetObjectReference$$().$type;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343794)
            
            //--TRIMMABLE-BOUNDARY-START(17181311090)
            /*JsonConverter */ CreateConverter(/*Type*/ typeToConvert, /*JsonSerializerOptions*/ jsonSerializerOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181311090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let instanceType = $.$$.System.Array.$ReadT1.call(typeToConvert.GetGenericArguments(), 0);
                /*var*/ let converterType = $.$mj.MJI$1.DotNetObjectReferenceJsonConverter$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ instanceType ], null, null));
                return $.$cast($.$$.S.Activator.CreateInstance$6(converterType, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ this.JSRuntime ], null, null)), $.$stj.STJS$1.JsonConverter);
            }
            //--TRIMMABLE-BOUNDARY-END(17181311090)
            
            static $h = 1441906;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverterFactory; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066212978),
    {
      "p": 2949234,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771245682,
        "f": 50331649
      },
      "n": "JSRuntime",
      "d": 1441906,
      "h": 30066212978,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066212978)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886343794),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeToConvert",
          "p": 188547073
        }
      ],
      "n": "CanConvert",
      "d": 1441906,
      "h": 12886343794,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886343794),
//--TRIMMABLE-BOUNDARY-START(17181311090),
    {
      "r": 13500500,
      "p": [
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "jsonSerializerOptions",
          "p": 3342420
        }
      ],
      "n": "CreateConverter",
      "d": 1441906,
      "h": 17181311090,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181311090)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591376498),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441906,
      "h": 8591376498,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591376498)
  ],
  "h": 1441906
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverterFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}DotNetObjectReferenceJsonConverterFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441906)
        
        

        //--TRIMMABLE-BOUNDARY-START(983154)
        $asm.$cls(`$mj.MJI$1.ByteArrayJsonConverter`, ($self) => class ByteArrayJsonConverter extends $.$stj.STJS$1.JsonConverter$$($.$typeArray($.$$.S.Byte))
        {
            //--TRIMMABLE-BOUNDARY-START(4295950450)
            /*int*/ _byteArrayId = 0;
            //--TRIMMABLE-BOUNDARY-END(4295950450)
            
            //--TRIMMABLE-BOUNDARY-START(21475819634)
            /*JsonEncodedText*/ static ByteArrayRefKey;
            //--TRIMMABLE-BOUNDARY-END(21475819634)
            
            //--TRIMMABLE-BOUNDARY-START(17180852338)
            $ctor$3(/*JSRuntime*/ jSRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180852338);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JSRuntime = jSRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180852338)
            
            //--TRIMMABLE-BOUNDARY-START(34360721522)
            /*JSRuntime*/ JSRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(34360721522)
            
            //--TRIMMABLE-BOUNDARY-START(38655688818)
            /*byte[]? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                /*var*/ let bytes;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (reader.$v.TokenType === 7/*JsonTokenType.String*/ && reader.$v.TryGetBytesFromBase64($.$ref(() => bytes, ($v) => bytes = $v, $.$typeArray($.$$.S.Byte))))
                {
                    return bytes;
                }
                if (this.JSRuntime.ByteArraysToBeRevived.Count === 0)
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10("JSON serialization is attempting to deserialize an unexpected byte array.");
                }
                /*int*/ let byteArrayRef;
                if (reader.$v.TokenType !== 1/*JsonTokenType.StartObject*/)
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON Token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.$v.TokenType))}, expected 'StartObject'.`);
                }
                if (reader.$v.Read() && reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                {
                    if (!reader.$v.ValueTextEquals($.$mj.MJI$1.ByteArrayJsonConverter.ByteArrayRefKey.EncodedUtf8Bytes))
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON Property ${$.$strNN(reader.$v.GetString())}.`);
                    }
                    else if (!reader.$v.Read() || reader.$v.TokenType !== 8/*JsonTokenType.Number*/)
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON Token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.$v.TokenType))}, expected 'Number'.`);
                    }
                    else if (!reader.$v.TryGetInt32($.$ref(() => byteArrayRef, ($v) => byteArrayRef = $v, $.$$.S.Int32)))
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected number, expected 32-bit integer.`);
                    }
                }
                else 
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON Token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.$v.TokenType))}, expected 'PropertyName'.`);
                }
                if (reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON Token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.$v.TokenType))}, expected 'EndObject'.`);
                }
                if (byteArrayRef >= this.JSRuntime.ByteArraysToBeRevived.Count || byteArrayRef < 0)
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10(`Byte array ${$.$strNN(byteArrayRef)} not found.`);
                }
                /*var*/ let byteArray = $.$$.System.Array.$ReadT1.call(this.JSRuntime.ByteArraysToBeRevived.Buffer, byteArrayRef);
                return byteArray;
            }
            //--TRIMMABLE-BOUNDARY-END(38655688818)
            
            //--TRIMMABLE-BOUNDARY-START(42950656114)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*byte[]*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = ++this._byteArrayId;
                this.JSRuntime.SendByteArray(id, value);
                writer.WriteStartObject();
                writer.WriteNumber$25($.$mj.MJI$1.ByteArrayJsonConverter.ByteArrayRefKey, id);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(42950656114)
            
            //--TRIMMABLE-BOUNDARY-START(12885885042)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885885042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(21475819634)
                    this.ByteArrayRefKey = $.$stj.STJ.JsonEncodedText.Encode$2("__byte[]", null);
                    //--TRIMMABLE-BOUNDARY-END(21475819634)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885885042)
            
            static $h = 983154;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverter$$($.$typeArray($.$$.S.Byte)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360721522),
    {
      "p": 2949234,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065754226,
        "f": 50331649
      },
      "n": "JSRuntime",
      "d": 983154,
      "h": 34360721522,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360721522)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655688818),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 983154,
      "h": 38655688818,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655688818),
//--TRIMMABLE-BOUNDARY-START(42950656114),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 983154,
      "h": 42950656114,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950656114)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950450),
    {
      "t": 655361,
      "n": "_byteArrayId",
      "d": 983154,
      "h": 4295950450,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950450),
//--TRIMMABLE-BOUNDARY-START(21475819634),
    {
      "t": 2293844,
      "n": "ByteArrayRefKey",
      "d": 983154,
      "h": 21475819634,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475819634)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180852338),
    {
      "p": [
        {
          "n": "jSRuntime",
          "p": 2949234
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 983154,
      "h": 17180852338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180852338)
  ],
  "h": 983154
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}ByteArrayJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983154)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835122)
        $asm.$cls(`$mj.MJI$1.JSObjectReferenceJsonConverter`, ($self) => class JSObjectReferenceJsonConverter extends $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.IJSObjectReference)
        {
            //--TRIMMABLE-BOUNDARY-START(4296802418)
            /*JSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4296802418)
            
            //--TRIMMABLE-BOUNDARY-START(8591769714)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591769714);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591769714)
            
            //--TRIMMABLE-BOUNDARY-START(12886737010)
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886737010);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return typeToConvert === $.$mj.MJ.IJSObjectReference.$type || typeToConvert === $.$mj.MJI.JSObjectReference.$type;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886737010)
            
            //--TRIMMABLE-BOUNDARY-START(17181704306)
            /*IJSObjectReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181704306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = $.$mj.MJI.JSObjectReferenceJsonWorker.ReadJSObjectReferenceIdentifier(reader);
                if (id === BigInt(-1))
                {
                    return null;
                }
                return new $.$mj.MJI.JSObjectReference().$ctor$1(this._jsRuntime, id);
            }
            //--TRIMMABLE-BOUNDARY-END(17181704306)
            
            //--TRIMMABLE-BOUNDARY-START(21476671602)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSObjectReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476671602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.MJI.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.MJI.JSObjectReference));
            }
            //--TRIMMABLE-BOUNDARY-END(21476671602)
            
            static $h = 1835122;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.IJSObjectReference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886737010),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeToConvert",
          "p": 188547073
        }
      ],
      "n": "CanConvert",
      "d": 1835122,
      "h": 12886737010,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886737010),
//--TRIMMABLE-BOUNDARY-START(17181704306),
    {
      "r": 458866,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 1835122,
      "h": 17181704306,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181704306),
//--TRIMMABLE-BOUNDARY-START(21476671602),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 458866
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 1835122,
      "h": 21476671602,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476671602)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296802418),
    {
      "t": 2949234,
      "n": "_jsRuntime",
      "d": 1835122,
      "h": 4296802418,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296802418)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591769714),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835122,
      "h": 8591769714,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591769714)
  ],
  "h": 1835122
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.JSObjectReferenceJsonConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}JSObjectReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835122)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900658)
        $asm.$cls(`$mj.MJI$1.JSStreamReferenceJsonConverter`, ($self) => class JSStreamReferenceJsonConverter extends $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.IJSStreamReference)
        {
            //--TRIMMABLE-BOUNDARY-START(8591835250)
            /*JsonEncodedText*/ static _jsStreamReferenceLengthKey;
            //--TRIMMABLE-BOUNDARY-END(8591835250)
            
            //--TRIMMABLE-BOUNDARY-START(4296867954)
            /*JSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4296867954)
            
            //--TRIMMABLE-BOUNDARY-START(17181769842)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181769842);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181769842)
            
            //--TRIMMABLE-BOUNDARY-START(21476737138)
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476737138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return typeToConvert === $.$mj.MJ.IJSStreamReference.$type || typeToConvert === $.$mj.MJI.JSStreamReference.$type;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476737138)
            
            //--TRIMMABLE-BOUNDARY-START(25771704434)
            /*IJSStreamReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771704434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long?*/ let id = null;
                /*long?*/ let length = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (id === null && reader.$v.ValueTextEquals($.$mj.MJI.JSObjectReferenceJsonWorker.JSObjectIdKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetInt64();
                        }
                        else if (length === null && reader.$v.ValueTextEquals($.$mj.MJI$1.JSStreamReferenceJsonConverter._jsStreamReferenceLengthKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            length = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON property ${$.$strNN(reader.$v.GetString())}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.$v.TokenType))}`);
                    }
                }
                if (!$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(id))
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10(`Required property ${$.$strNN($.$mj.MJI.JSObjectReferenceJsonWorker.JSObjectIdKey.ToString())} not found.`);
                }
                if (!$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(length))
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10(`Required property ${$.$strNN($.$mj.MJI$1.JSStreamReferenceJsonConverter._jsStreamReferenceLengthKey.ToString())} not found.`);
                }
                return new $.$mj.MJI.JSStreamReference().$ctor$2(this._jsRuntime, $.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(id), $.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(length));
            }
            //--TRIMMABLE-BOUNDARY-END(25771704434)
            
            //--TRIMMABLE-BOUNDARY-START(30066671730)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSStreamReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066671730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.MJI.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.MJI.JSStreamReference));
            }
            //--TRIMMABLE-BOUNDARY-END(30066671730)
            
            //--TRIMMABLE-BOUNDARY-START(12886802546)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886802546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8591835250)
                    this._jsStreamReferenceLengthKey = $.$stj.STJ.JsonEncodedText.Encode$2("__jsStreamReferenceLength", null);
                    //--TRIMMABLE-BOUNDARY-END(8591835250)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886802546)
            
            static $h = 1900658;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.IJSStreamReference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476737138),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeToConvert",
          "p": 188547073
        }
      ],
      "n": "CanConvert",
      "d": 1900658,
      "h": 21476737138,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476737138),
//--TRIMMABLE-BOUNDARY-START(25771704434),
    {
      "r": 589938,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 1900658,
      "h": 25771704434,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771704434),
//--TRIMMABLE-BOUNDARY-START(30066671730),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 589938
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 1900658,
      "h": 30066671730,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066671730)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591835250),
    {
      "t": 2293844,
      "n": "_jsStreamReferenceLengthKey",
      "d": 1900658,
      "h": 8591835250,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591835250),
//--TRIMMABLE-BOUNDARY-START(4296867954),
    {
      "t": 2949234,
      "n": "_jsRuntime",
      "d": 1900658,
      "h": 4296867954,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867954)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181769842),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1900658,
      "h": 17181769842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769842)
  ],
  "h": 1900658
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}JSStreamReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900658)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359410)
        $asm.$str(`$mj.MJ.JSCallResultType`, ($self) => class JSCallResultType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Default = 0;
            static JSObjectReference = 1;
            static JSStreamReference = 2;
            static JSVoidResult = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2359410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "JSObjectReference": 1n,
                    "JSStreamReference": 2n,
                    "JSVoidResult": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297326706)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297326706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297326706)
            
            //--TRIMMABLE-BOUNDARY-START(4297326706)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297326706)
            
            static $h = 2359410;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592294002),
    {
      "t": 2359410,
      "n": "Default",
      "d": 2359410,
      "h": 8592294002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592294002),
//--TRIMMABLE-BOUNDARY-START(12887261298),
    {
      "t": 2359410,
      "n": "JSObjectReference",
      "d": 2359410,
      "h": 12887261298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887261298),
//--TRIMMABLE-BOUNDARY-START(17182228594),
    {
      "t": 2359410,
      "n": "JSStreamReference",
      "d": 2359410,
      "h": 17182228594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182228594),
//--TRIMMABLE-BOUNDARY-START(21477195890),
    {
      "t": 2359410,
      "n": "JSVoidResult",
      "d": 2359410,
      "h": 21477195890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477195890)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326706),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2359410,
      "h": 4297326706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297326706)
  ],
  "h": 2359410
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSCallResultType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSCallResultType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359410)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704050)
        $asm.$str(`$mj.MJI$1.JSCallType`, ($self) => class JSCallType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static FunctionCall = 1;
            static ConstructorCall = 2;
            static GetValue = 3;
            static SetValue = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1704050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FunctionCall": 1n,
                    "ConstructorCall": 2n,
                    "GetValue": 3n,
                    "SetValue": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296671346)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296671346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671346)
            
            //--TRIMMABLE-BOUNDARY-START(4296671346)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296671346)
            
            static $h = 1704050;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886605938),
    {
      "t": 1704050,
      "n": "FunctionCall",
      "d": 1704050,
      "h": 12886605938,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886605938),
//--TRIMMABLE-BOUNDARY-START(8591638642),
    {
      "t": 1704050,
      "n": "ConstructorCall",
      "d": 1704050,
      "h": 8591638642,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591638642),
//--TRIMMABLE-BOUNDARY-START(17181573234),
    {
      "t": 1704050,
      "n": "GetValue",
      "o": "@$1",
      "d": 1704050,
      "h": 17181573234,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181573234),
//--TRIMMABLE-BOUNDARY-START(21476540530),
    {
      "t": 1704050,
      "n": "SetValue",
      "d": 1704050,
      "h": 21476540530,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476540530)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671346),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704050,
      "h": 4296671346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671346)
  ],
  "h": 1704050
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.JSCallType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}JSCallType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704050)
        
        

        //--TRIMMABLE-BOUNDARY-START(852082)
        $asm.$cls(`$mj.MJI.JSStreamReference`, ($self) => class JSStreamReference extends $.$mj.MJI.JSObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(4295819378)
            /*JSRuntime*/ _jsRuntime$1 = null;
            //--TRIMMABLE-BOUNDARY-END(4295819378)
            
            //--TRIMMABLE-BOUNDARY-START(25770655858)
            /*long*/ Length = 0n;
            //--TRIMMABLE-BOUNDARY-END(25770655858)
            
            //--TRIMMABLE-BOUNDARY-START(12885753970)
            $ctor$2(/*JSRuntime*/ jsRuntime, /*long*/ id, /*long*/ totalLength)
            {
                super.$ctor$1(jsRuntime, id);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885753970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (totalLength <= 0n)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("totalLength", $.$box(totalLength, $.$$.S.Int64), "Length must be a positive value.");
                    }
                    this._jsRuntime$1 = jsRuntime;
                    this.Length = totalLength;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885753970)
            
            //--TRIMMABLE-BOUNDARY-START(30065623154)
            /*ValueTask<Stream> *//*async*/  MJ$IJSStreamReference$OpenReadStreamAsync(/*long*/ maxAllowedSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SI.Stream), $.$$.SI.Stream, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065623154);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Length > maxAllowedSize)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("maxAllowedSize", `The incoming data stream of length ${$.$strNN(this.Length)} exceeds the maximum allowed length ${$.$strNN(maxAllowedSize)}.`);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this._jsRuntime$1.ReadJSDataAsStreamAsync(this, this.Length, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065623154)
            
            //--TRIMMABLE-BOUNDARY-START(8590524530)
            //Generated interface implemetation for Microsoft.JSInterop.IJSStreamReference.Length.get
            get MJ$IJSStreamReference$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524530)
            
            static $h = 852082;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mj.MJI.JSObjectReference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770655858),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475688562,
        "f": 50331649
      },
      "n": "Length",
      "d": 852082,
      "h": 25770655858,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770655858)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819378),
    {
      "t": 2949234,
      "n": "_jsRuntime",
      "o": "@$1",
      "d": 852082,
      "h": 4295819378,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819378)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885753970),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        },
        {
          "n": "id",
          "p": 917505
        },
        {
          "n": "totalLength",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852082,
      "h": 12885753970,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885753970)
  ],
  "h": 852082
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.MJ.IJSObjectReference, $.$mj.MJ.IJSStreamReference, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Implementation.JSStreamReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Implementation${separator}JSStreamReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852082)
        
        

        //--TRIMMABLE-BOUNDARY-START(655474)
        $asm.$cls(`$mj.MJI.JSInProcessObjectReference`, ($self) => class JSInProcessObjectReference extends $.$mj.MJI.JSObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(4295622770)
            /*JSInProcessRuntime*/ _jsRuntime$1 = null;
            //--TRIMMABLE-BOUNDARY-END(4295622770)
            
            //--TRIMMABLE-BOUNDARY-START(8590590066)
            $ctor$2(/*JSInProcessRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor$1(jsRuntime, id);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime$1 = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590066)
            
            //--TRIMMABLE-BOUNDARY-START(25770459250)
            /*TValue */ Invoke(TValue, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime$1.Invoke(TValue, identifier, this.Id, 1/*JSCallType.FunctionCall*/, args);
            }
            //--TRIMMABLE-BOUNDARY-END(25770459250)
            
            //--TRIMMABLE-BOUNDARY-START(30065426546)
            /*IJSInProcessObjectReference */ InvokeConstructor(/*string*/ identifier, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime$1.Invoke($.$mj.MJ.IJSInProcessObjectReference, identifier, this.Id, 2/*JSCallType.ConstructorCall*/, args);
            }
            //--TRIMMABLE-BOUNDARY-END(30065426546)
            
            //--TRIMMABLE-BOUNDARY-START(21475491954)
            /*TValue */ GetValue(TValue, /*string*/ identifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime$1.Invoke(TValue, identifier, this.Id, 3/*JSCallType.GetValue*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475491954)
            
            //--TRIMMABLE-BOUNDARY-START(34360393842)
            /*void */ SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this._jsRuntime$1.Invoke(TValue, identifier, this.Id, 4/*JSCallType.SetValue*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(value, TValue) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34360393842)
            
            //--TRIMMABLE-BOUNDARY-START(12885557362)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    globalThis.DotNet.disposeJSObjectReferenceById(this.Id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885557362)
            
            //--TRIMMABLE-BOUNDARY-START(8590262386)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.Invoke<TValue>(string, params object?[]?)
            MJ$IJSInProcessObjectReference$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262386)
            
            //--TRIMMABLE-BOUNDARY-START(12885229682)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.InvokeConstructor(string, object?[]?)
            MJ$IJSInProcessObjectReference$InvokeConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229682)
            
            //--TRIMMABLE-BOUNDARY-START(4295295090)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.GetValue<TValue>(string)
            MJ$IJSInProcessObjectReference$GetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295090)
            
            //--TRIMMABLE-BOUNDARY-START(17180196978)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.SetValue<TValue>(string, TValue)
            MJ$IJSInProcessObjectReference$SetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180196978)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $h = 655474;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mj.MJI.JSObjectReference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770459250),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Invoke",
      "d": 655474,
      "h": 25770459250,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(25770459250),
//--TRIMMABLE-BOUNDARY-START(30065426546),
    {
      "r": 327794,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeConstructor",
      "d": 655474,
      "h": 30065426546,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065426546),
//--TRIMMABLE-BOUNDARY-START(21475491954),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValue",
      "d": 655474,
      "h": 21475491954,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(21475491954),
//--TRIMMABLE-BOUNDARY-START(34360393842),
    {
      "r": 65537,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValue",
      "d": 655474,
      "h": 34360393842,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(34360393842),
//--TRIMMABLE-BOUNDARY-START(12885557362),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 655474,
      "h": 12885557362,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557362)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622770),
    {
      "t": 2687090,
      "n": "_jsRuntime",
      "o": "@$1",
      "d": 655474,
      "h": 4295622770,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622770)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590066),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2687090
        },
        {
          "n": "id",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655474,
      "h": 8590590066,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(8590590066)
  ],
  "h": 655474
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.MJ.IJSInProcessObjectReference, $.$mj.MJ.IJSObjectReference, $.$$.S.IAsyncDisposable, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Implementation.JSInProcessObjectReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Implementation${separator}JSInProcessObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655474)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507442)
        $asm.$cls(`$mj.MJI$1.DotNetStreamReferenceJsonConverter`, ($self) => class DotNetStreamReferenceJsonConverter extends $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.DotNetStreamReference)
        {
            //--TRIMMABLE-BOUNDARY-START(17181376626)
            /*JsonEncodedText*/ static DotNetStreamRefKey;
            //--TRIMMABLE-BOUNDARY-END(17181376626)
            
            //--TRIMMABLE-BOUNDARY-START(12886409330)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409330);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409330)
            
            //--TRIMMABLE-BOUNDARY-START(30066278514)
            /*JSRuntime*/ JSRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(30066278514)
            
            //--TRIMMABLE-BOUNDARY-START(34361245810)
            /*DotNetStreamReference */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361245810);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12(`${$.$strNN("DotNetStreamReference")} cannot be supplied from JavaScript to .NET because the stream contents have already been transferred.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245810)
            
            //--TRIMMABLE-BOUNDARY-START(38656213106)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*DotNetStreamReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = this.JSRuntime.BeginTransmittingStream(value);
                writer.WriteStartObject();
                writer.WriteNumber$26($.$mj.MJI$1.DotNetStreamReferenceJsonConverter.DotNetStreamRefKey, id);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(38656213106)
            
            //--TRIMMABLE-BOUNDARY-START(8591442034)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591442034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17181376626)
                    this.DotNetStreamRefKey = $.$stj.STJ.JsonEncodedText.Encode$2("__dotNetStream", null);
                    //--TRIMMABLE-BOUNDARY-END(17181376626)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591442034)
            
            static $h = 1507442;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.DotNetStreamReference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066278514),
    {
      "p": 2949234,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771311218,
        "f": 50331649
      },
      "n": "JSRuntime",
      "d": 1507442,
      "h": 30066278514,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066278514)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361245810),
    {
      "r": 262258,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 1507442,
      "h": 34361245810,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361245810),
//--TRIMMABLE-BOUNDARY-START(38656213106),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 262258
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 1507442,
      "h": 38656213106,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656213106)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181376626),
    {
      "t": 2293844,
      "n": "DotNetStreamRefKey",
      "d": 1507442,
      "h": 17181376626,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181376626)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886409330),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507442,
      "h": 12886409330,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409330)
  ],
  "h": 1507442
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.DotNetStreamReferenceJsonConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}DotNetStreamReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507442)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376370)
        $asm.$cls(`$mj.MJI$1.DotNetObjectReferenceJsonConverter<>`, (TValue) => $asm.$gt(`$mj.MJI$1.DotNetObjectReferenceJsonConverter<>`, [TValue], ($self) => class DotNetObjectReferenceJsonConverter$$ extends $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.DotNetObjectReference$$(TValue))
        {
            //--TRIMMABLE-BOUNDARY-START(8591310962)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591310962);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591310962)
            
            //--TRIMMABLE-BOUNDARY-START(12886278258)
            static /*JsonEncodedText */ get DotNetObjectRefKey()
            {
                return $.$mj.MJI$1.DotNetDispatcher.DotNetObjectRefKey;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278258)
            
            //--TRIMMABLE-BOUNDARY-START(34361114738)
            /*JSRuntime*/ JSRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(34361114738)
            
            //--TRIMMABLE-BOUNDARY-START(38656082034)
            /*DotNetObjectReference<TValue> */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656082034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let dotNetObjectId = 0n;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (dotNetObjectId === 0n && reader.$v.ValueTextEquals($.$mj.MJI$1.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            dotNetObjectId = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON property ${$.$strNN(reader.$v.GetString())}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON Token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.$v.TokenType))}.`);
                    }
                }
                if (dotNetObjectId === 0n)
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10(`Required property ${$.$strNN($.$mj.MJI$1.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey.ToString())} not found.`);
                }
                /*var*/ let value = $.$cast(this.JSRuntime.GetObjectReference(dotNetObjectId), $.$mj.MJ.DotNetObjectReference$$(TValue));
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(38656082034)
            
            //--TRIMMABLE-BOUNDARY-START(42951049330)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*DotNetObjectReference<TValue>*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951049330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let objectId = this.JSRuntime.TrackObjectReference(TValue, value);
                writer.WriteStartObject();
                writer.WriteNumber$26($.$mj.MJI$1.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey, objectId);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(42951049330)
            
            static $H = 1376370;
            static $h = 1376370;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverter$$($.$mj.MJ.DotNetObjectReference$$(TValue)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886278258),
    {
      "p": 2293844,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21476212850,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331682
      },
      "n": "DotNetObjectRefKey",
      "d": this.$h,
      "H": 12886278258,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(12886278258),
//--TRIMMABLE-BOUNDARY-START(34361114738),
    {
      "p": 2949234,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30066147442,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "JSRuntime",
      "d": this.$h,
      "H": 34361114738,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361114738)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656082034),
    {
      "r": $.$mj.MJ.DotNetObjectReference$$(TValue).$h,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": this.$h,
      "H": 38656082034,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656082034),
//--TRIMMABLE-BOUNDARY-START(42951049330),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$mj.MJ.DotNetObjectReference$$(TValue).$h
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": this.$h,
      "H": 42951049330,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951049330)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591310962),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949234
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 8591310962,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591310962)
  ],
  "s": [
    {
      "h": TValue?.$h??1572864,
      "n": "TValue",
      "f": 1
    }
  ],
  "r": 1,
  "H": 1376370,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter<${TValue?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}Infrastructure${separator}DotNetObjectReferenceJsonConverter$${TValue?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1376370)
        
        

        //--TRIMMABLE-BOUNDARY-START(2490482)
        $asm.$cls(`$mj.MJ.JSDisconnectedException`, ($self) => class JSDisconnectedException extends $.$$.S.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4297457778)
            $ctor$5(/*string*/ message)
            {
                super.$ctor$4(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297457778);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297457778)
            
            static $h = 2490482;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Exception; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457778),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2490482,
      "h": 4297457778,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297457778)
  ],
  "h": 2490482
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSDisconnectedException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSDisconnectedException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490482)
        
        

        //--TRIMMABLE-BOUNDARY-START(2556018)
        $asm.$cls(`$mj.MJ.JSException`, ($self) => class JSException extends $.$$.S.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(8592490610)
            $ctor$6(/*string*/ message)
            {
                super.$ctor$4(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592490610);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592490610)
            
            //--TRIMMABLE-BOUNDARY-START(4297523314)
            $ctor$5(/*string*/ message, /*Exception*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297523314);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297523314)
            
            static $h = 2556018;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Exception; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592490610),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2556018,
      "h": 8592490610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592490610),
//--TRIMMABLE-BOUNDARY-START(4297523314),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 80805889
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2556018,
      "h": 4297523314,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297523314)
  ],
  "h": 2556018
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.JSInterop.JSException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}JSInterop${separator}JSException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2556018)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.IO.Pipelines", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.RegularExpressions", "NetJs.System.Text.Json"));
})();
//--TRIMMABLE-BOUNDARY-END(114)
