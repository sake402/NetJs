
//--TRIMMABLE-BOUNDARY-START(107)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $sipl, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $sre, $srei, $srel, $srp, $srl, $stew, $str, $stj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.JSInterop", 
    {
  "h": 107,
  "f": "Microsoft.JSInterop",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "Abstractions and features for interop between .NET and JavaScript code.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.JSInterop",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.JSInterop",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.JSInterop.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.WebAssembly.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 115605505,
      "c": 4410572801,
      "a": [
        {
          "v": 1179755,
          "t": 187629569
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(524395)
        $asm.$cls("$mj.Microsoft.JSInterop.IJSRuntime", ($self) => class IJSRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(21475360875)
            /*ValueTask<IJSObjectReference> */ Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360875);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360875)
            
            //--TRIMMABLE-BOUNDARY-START(25770328171)
            /*ValueTask<IJSObjectReference> */ Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328171);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770328171)
            
            //--TRIMMABLE-BOUNDARY-START(4295491691)
            /*ValueTask<TValue> */ Microsoft$JSInterop$IJSRuntime$GetValueAsync$1(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295491691)
            
            //--TRIMMABLE-BOUNDARY-START(8590458987)
            /*ValueTask<TValue> */ Microsoft$JSInterop$IJSRuntime$GetValueAsync(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458987);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590458987)
            
            //--TRIMMABLE-BOUNDARY-START(30065295467)
            /*ValueTask */ Microsoft$JSInterop$IJSRuntime$SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295467);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065295467)
            
            //--TRIMMABLE-BOUNDARY-START(34360262763)
            /*ValueTask */ Microsoft$JSInterop$IJSRuntime$SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262763);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262763)
            
            static $h = 524395;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885426283),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "Microsoft$JSInterop$IJSRuntime$InvokeAsync",
      "d": 524395,
      "h": 12885426283,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(12885426283),
//--TRIMMABLE-BOUNDARY-START(17180393579),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "Microsoft$JSInterop$IJSRuntime$InvokeAsync$1",
      "d": 524395,
      "h": 17180393579,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(17180393579),
//--TRIMMABLE-BOUNDARY-START(21475360875),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync",
      "d": 524395,
      "h": 21475360875,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475360875),
//--TRIMMABLE-BOUNDARY-START(25770328171),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1",
      "d": 524395,
      "h": 25770328171,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770328171),
//--TRIMMABLE-BOUNDARY-START(4295491691),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "Microsoft$JSInterop$IJSRuntime$GetValueAsync$1",
      "d": 524395,
      "h": 4295491691,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(4295491691),
//--TRIMMABLE-BOUNDARY-START(8590458987),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "Microsoft$JSInterop$IJSRuntime$GetValueAsync",
      "d": 524395,
      "h": 8590458987,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(8590458987),
//--TRIMMABLE-BOUNDARY-START(30065295467),
    {
      "r": 180420609,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "Microsoft$JSInterop$IJSRuntime$SetValueAsync$1",
      "d": 524395,
      "h": 30065295467,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(30065295467),
//--TRIMMABLE-BOUNDARY-START(34360262763),
    {
      "r": 180420609,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "Microsoft$JSInterop$IJSRuntime$SetValueAsync",
      "d": 524395,
      "h": 34360262763,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(34360262763)
  ],
  "h": 524395
}; }
            static get $fullName() { return `IJSRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524395)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638507)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult", ($self) => class IJSVoidResult
        {
            static $h = 1638507;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1638507,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `IJSVoidResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638507)
        
        
        //--TRIMMABLE-BOUNDARY-START(589931)
        $asm.$cls("$mj.Microsoft.JSInterop.IJSStreamReference", ($self) => class IJSStreamReference
        {
            static $h = 589931;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885491819),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590524523,
        "f": 50331905
      },
      "n": "Length",
      "o": "Microsoft$JSInterop$IJSStreamReference$Length",
      "d": 589931,
      "h": 12885491819,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885491819)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459115),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,
      "p": [
        {
          "n": "maxAllowedSize",
          "p": 917505,
          "f": 65,
          "v": 512000
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "OpenReadStreamAsync",
      "o": "Microsoft$JSInterop$IJSStreamReference$OpenReadStreamAsync",
      "d": 589931,
      "h": 17180459115,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180459115)
  ],
  "i": [89587713
  ],
  "h": 589931
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `IJSStreamReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589931)
        
        
        //--TRIMMABLE-BOUNDARY-START(458859)
        $asm.$cls("$mj.Microsoft.JSInterop.IJSObjectReference", ($self) => class IJSObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(21475295339)
            /*ValueTask<IJSObjectReference> */ Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475295339);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475295339)
            
            //--TRIMMABLE-BOUNDARY-START(25770262635)
            /*ValueTask<IJSObjectReference> */ Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770262635);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770262635)
            
            //--TRIMMABLE-BOUNDARY-START(4295426155)
            /*ValueTask<TValue> */ Microsoft$JSInterop$IJSObjectReference$GetValueAsync$1(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426155)
            
            //--TRIMMABLE-BOUNDARY-START(8590393451)
            /*ValueTask<TValue> */ Microsoft$JSInterop$IJSObjectReference$GetValueAsync(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393451);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590393451)
            
            //--TRIMMABLE-BOUNDARY-START(30065229931)
            /*ValueTask */ Microsoft$JSInterop$IJSObjectReference$SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065229931);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065229931)
            
            //--TRIMMABLE-BOUNDARY-START(34360197227)
            /*ValueTask */ Microsoft$JSInterop$IJSObjectReference$SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360197227);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360197227)
            
            static $h = 458859;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360747),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "Microsoft$JSInterop$IJSObjectReference$InvokeAsync",
      "d": 458859,
      "h": 12885360747,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(12885360747),
//--TRIMMABLE-BOUNDARY-START(17180328043),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1",
      "d": 458859,
      "h": 17180328043,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(17180328043),
//--TRIMMABLE-BOUNDARY-START(21475295339),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync",
      "d": 458859,
      "h": 21475295339,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475295339),
//--TRIMMABLE-BOUNDARY-START(25770262635),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1",
      "d": 458859,
      "h": 25770262635,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770262635),
//--TRIMMABLE-BOUNDARY-START(4295426155),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "Microsoft$JSInterop$IJSObjectReference$GetValueAsync$1",
      "d": 458859,
      "h": 4295426155,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(4295426155),
//--TRIMMABLE-BOUNDARY-START(8590393451),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "Microsoft$JSInterop$IJSObjectReference$GetValueAsync",
      "d": 458859,
      "h": 8590393451,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(8590393451),
//--TRIMMABLE-BOUNDARY-START(30065229931),
    {
      "r": 180420609,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "Microsoft$JSInterop$IJSObjectReference$SetValueAsync$1",
      "d": 458859,
      "h": 30065229931,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(30065229931),
//--TRIMMABLE-BOUNDARY-START(34360197227),
    {
      "r": 180420609,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "Microsoft$JSInterop$IJSObjectReference$SetValueAsync",
      "d": 458859,
      "h": 34360197227,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(34360197227)
  ],
  "i": [89587713
  ],
  "h": 458859
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `IJSObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458859)
        
        
        //--TRIMMABLE-BOUNDARY-START(393323)
        $asm.$cls("$mj.Microsoft.JSInterop.IJSInProcessRuntime", ($self) => class IJSInProcessRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(12885295211)
            /*IJSInProcessObjectReference */ Microsoft$JSInterop$IJSInProcessRuntime$InvokeConstructor(/*string*/ identifier, /*params object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885295211)
            
            //--TRIMMABLE-BOUNDARY-START(4295360619)
            /*TValue */ Microsoft$JSInterop$IJSInProcessRuntime$GetValue(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360619)
            
            //--TRIMMABLE-BOUNDARY-START(17180262507)
            /*void */ Microsoft$JSInterop$IJSInProcessRuntime$SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262507)
            
            static $h = 393323;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327915),
    {
      "r": (TResult) => TResult.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "Invoke",
      "o": "Microsoft$JSInterop$IJSInProcessRuntime$Invoke",
      "d": 393323,
      "h": 8590327915,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590327915),
//--TRIMMABLE-BOUNDARY-START(12885295211),
    {
      "r": 327787,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeConstructor",
      "o": "Microsoft$JSInterop$IJSInProcessRuntime$InvokeConstructor",
      "d": 393323,
      "h": 12885295211,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885295211),
//--TRIMMABLE-BOUNDARY-START(4295360619),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValue",
      "o": "Microsoft$JSInterop$IJSInProcessRuntime$GetValue",
      "d": 393323,
      "h": 4295360619,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(4295360619),
//--TRIMMABLE-BOUNDARY-START(17180262507),
    {
      "r": 65537,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValue",
      "o": "Microsoft$JSInterop$IJSInProcessRuntime$SetValue",
      "d": 393323,
      "h": 17180262507,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(17180262507)
  ],
  "i": [524395
  ],
  "h": 393323
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSRuntime ]; }
            static get $fullName() { return `IJSInProcessRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393323)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572971)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference", ($self) => class IDotNetObjectReference
        {
            static $h = 1572971;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886474859),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591507563,
        "f": 50331905
      },
      "n": "Value",
      "o": "Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value",
      "d": 1572971,
      "h": 12886474859,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886474859)
  ],
  "i": [90177537
  ],
  "h": 1572971
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `IDotNetObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572971)
        
        
        //--TRIMMABLE-BOUNDARY-START(327787)
        $asm.$cls("$mj.Microsoft.JSInterop.IJSInProcessObjectReference", ($self) => class IJSInProcessObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(12885229675)
            /*IJSInProcessObjectReference */ Microsoft$JSInterop$IJSInProcessObjectReference$InvokeConstructor(/*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229675);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885229675)
            
            //--TRIMMABLE-BOUNDARY-START(4295295083)
            /*TValue */ Microsoft$JSInterop$IJSInProcessObjectReference$GetValue(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295083);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295295083)
            
            //--TRIMMABLE-BOUNDARY-START(17180196971)
            /*void */ Microsoft$JSInterop$IJSInProcessObjectReference$SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196971);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotImplementedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180196971)
            
            static $h = 327787;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590262379),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Invoke",
      "o": "Microsoft$JSInterop$IJSInProcessObjectReference$Invoke",
      "d": 327787,
      "h": 8590262379,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590262379),
//--TRIMMABLE-BOUNDARY-START(12885229675),
    {
      "r": 327787,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructor",
      "o": "Microsoft$JSInterop$IJSInProcessObjectReference$InvokeConstructor",
      "d": 327787,
      "h": 12885229675,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885229675),
//--TRIMMABLE-BOUNDARY-START(4295295083),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValue",
      "o": "Microsoft$JSInterop$IJSInProcessObjectReference$GetValue",
      "d": 327787,
      "h": 4295295083,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(4295295083),
//--TRIMMABLE-BOUNDARY-START(17180196971),
    {
      "r": 65537,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValue",
      "o": "Microsoft$JSInterop$IJSInProcessObjectReference$SetValue",
      "d": 327787,
      "h": 17180196971,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(17180196971)
  ],
  "i": [458859,89587713,90177537
  ],
  "h": 327787
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$$.System.IAsyncDisposable, $.$$.System.IDisposable ]; }
            static get $fullName() { return `IJSInProcessObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327787)
        
        
        //--TRIMMABLE-BOUNDARY-START(2949227)
        $asm.$cls("$mj.Microsoft.JSInterop.JSRuntime", ($self) => class JSRuntime extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(184686542955)
            /*long*/ static WindowObjectId = 0n;
            //--TRIMMABLE-BOUNDARY-END(184686542955)
            
            //--TRIMMABLE-BOUNDARY-START(8592883819)
            /*long*/ _nextObjectReferenceId = 0n;
            //--TRIMMABLE-BOUNDARY-END(8592883819)
            
            //--TRIMMABLE-BOUNDARY-START(12887851115)
            /*long*/ _nextPendingTaskId = 1n;
            //--TRIMMABLE-BOUNDARY-END(12887851115)
            
            //--TRIMMABLE-BOUNDARY-START(17182818411)
            /*ConcurrentDictionary<long, object>*/ _pendingTasks = null;
            //--TRIMMABLE-BOUNDARY-END(17182818411)
            
            //--TRIMMABLE-BOUNDARY-START(21477785707)
            /*ConcurrentDictionary<long, IDotNetObjectReference>*/ _trackedRefsById = null;
            //--TRIMMABLE-BOUNDARY-END(21477785707)
            
            //--TRIMMABLE-BOUNDARY-START(4297916523)
            /*ConcurrentDictionary<long, CancellationTokenRegistration>*/ _cancellationRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(4297916523)
            
            //--TRIMMABLE-BOUNDARY-START(55837524075)
            /*ArrayBuilder<byte[]>*/ ByteArraysToBeRevived = null;
            //--TRIMMABLE-BOUNDARY-END(55837524075)
            
            //--TRIMMABLE-BOUNDARY-START(25772753003)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772753003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JsonSerializerOptions = (() =>
                    {
                        //new $.$stj.System.Text.Json.JsonSerializerOptions()
                        const $t1 = $.$stj.System.Text.Json.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.MaxDepth = 32;
                        $i1.PropertyNamingPolicy = $.$stj.System.Text.Json.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverterFactory().$ctor$3(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.JSObjectReferenceJsonConverter().$ctor$3(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter().$ctor$3(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetStreamReferenceJsonConverter().$ctor$3(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter().$ctor$3(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        return $i1;
                    })();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772753003)
            
            //--TRIMMABLE-BOUNDARY-START(137441902699)
            /*JsonSerializerOptions*/ JsonSerializerOptions = null;
            //--TRIMMABLE-BOUNDARY-END(137441902699)
            
            //--TRIMMABLE-BOUNDARY-START(64427458667)
            /*TimeSpan?*/ DefaultAsyncTimeout = null;
            //--TRIMMABLE-BOUNDARY-END(64427458667)
            
            //--TRIMMABLE-BOUNDARY-START(111672098923)
            /*ValueTask<TValue> */ InvokeAsync$2(TValue, /*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111672098923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync(TValue, 0n, identifier, 1/*JSCallType.FunctionCall*/, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111672098923)
            
            //--TRIMMABLE-BOUNDARY-START(115967066219)
            /*ValueTask<TValue> */ InvokeAsync$3(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115967066219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync$1(TValue, 0n, identifier, 1/*JSCallType.FunctionCall*/, cancellationToken, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115967066219)
            
            //--TRIMMABLE-BOUNDARY-START(128851968107)
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128851968107);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync($.$mj.Microsoft.JSInterop.IJSObjectReference, 0n, identifier, 2/*JSCallType.ConstructorCall*/, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851968107)
            
            //--TRIMMABLE-BOUNDARY-START(133146935403)
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146935403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync$1($.$mj.Microsoft.JSInterop.IJSObjectReference, 0n, identifier, 2/*JSCallType.ConstructorCall*/, cancellationToken, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146935403)
            
            //--TRIMMABLE-BOUNDARY-START(103082164331)
            /*ValueTask<TValue> */ GetValueAsync$1(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103082164331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync(TValue, 0n, identifier, 3/*JSCallType.GetValue*/, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103082164331)
            
            //--TRIMMABLE-BOUNDARY-START(107377131627)
            /*ValueTask<TValue> */ GetValueAsync(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107377131627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeAsync$1(TValue, 0n, identifier, 3/*JSCallType.GetValue*/, cancellationToken, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107377131627)
            
            //--TRIMMABLE-BOUNDARY-START(167506673771)
            /*ValueTask *//*async*/  SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(167506673771);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return await this.InvokeAsync($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, 0n, identifier, 4/*JSCallType.SetValue*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167506673771)
            
            //--TRIMMABLE-BOUNDARY-START(171801641067)
            /*ValueTask *//*async*/  SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(171801641067);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return await this.InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, 0n, identifier, 4/*JSCallType.SetValue*/, cancellationToken, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171801641067)
            
            //--TRIMMABLE-BOUNDARY-START(120262033515)
            /*ValueTask<TValue> *//*async*/  InvokeAsync(TValue, /*long*/ targetInstanceId, /*string*/ identifier, /*JSCallType*/ callType, /*object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$(TValue), TValue, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120262033515);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this.DefaultAsyncTimeout))
                    {
                        /*var*/ let cts = new $.$$.System.Threading.CancellationTokenSource().$ctor$4($.$$.System.Nullable$$($.$$.System.TimeSpan).Value$get.call(this.DefaultAsyncTimeout));
                        try
                        {
                            return await this.InvokeAsync$1(TValue, targetInstanceId, identifier, callType, cts.Token, args);
                        }
                        finally
                        {
                            cts?.System$IDisposable$Dispose();
                        }
                    }
                    return await this.InvokeAsync$1(TValue, targetInstanceId, identifier, callType, $.$$.System.Threading.CancellationToken.None, args);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120262033515)
            
            //--TRIMMABLE-BOUNDARY-START(124557000811)
            /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*long*/ targetInstanceId, /*string*/ identifier, /*JSCallType*/ callType, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124557000811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let taskId = $.$$.System.Threading.Interlocked.Increment$1($.$ref(() => this._nextPendingTaskId, ($v) => this._nextPendingTaskId = $v, $.$$.System.Int64));
                /*var*/ let tcs = new ($.$$.System.Threading.Tasks.TaskCompletionSource$$(TValue))().$ctor$1();
                if (cancellationToken.CanBeCanceled)
                {
                    this._cancellationRegistrations.set_Item(taskId, cancellationToken.Register$1(new $.$$.System.Action().$ctor(this,  () =>
                    {
                        tcs.TrySetCanceled$1(cancellationToken);
                        this.CleanupTasksAndRegistrations(taskId);
                    }, {
  "r": 65537,
  "n": "",
  "d": 2949227,
  "h": 0,
  "f": 17825794
})));
                }
                this._pendingTasks.set_Item(taskId, tcs);
                try
                {
                    if (cancellationToken.IsCancellationRequested)
                    {
                        tcs.TrySetCanceled$1(cancellationToken);
                        this.CleanupTasksAndRegistrations(taskId);
                        return new ($.$$.System.Threading.Tasks.ValueTask$$(TValue))().$ctor$5(tcs.Task);
                    }
                    /*var*/ let argsJson = !(args === null) && args.length !== 0 ? $.$stj.System.Text.Json.JsonSerializer.Serialize$13($.$typeArray($.$$.System.Object), args, this.JsonSerializerOptions) : "[]";
                    /*var*/ let resultType = $.$mj.Microsoft.JSInterop.JSCallResultTypeHelper.FromGeneric(TValue);
                    /*var*/ let invocationInfo = (() =>
                    {
                        //new $.$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo()
                        const $t2 = $.$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo;
                        const $i2 = new $t2();
                        $i2.AsyncHandle = taskId;
                        $i2.TargetInstanceId = targetInstanceId;
                        $i2.Identifier = identifier;
                        $i2.CallType = callType;
                        $i2.ResultType = resultType;
                        $i2.ArgsJson = argsJson;
                        return $i2;
                    })();
                    this.BeginInvokeJS$2($.$ref(() => invocationInfo, ));
                    return new ($.$$.System.Threading.Tasks.ValueTask$$(TValue))().$ctor$5(tcs.Task);
                }
                catch($e)
                {
                    this.CleanupTasksAndRegistrations(taskId);
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124557000811)
            
            //--TRIMMABLE-BOUNDARY-START(60132491371)
            /*void */ CleanupTasksAndRegistrations(/*long*/ taskId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132491371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._pendingTasks.TryRemove$1(taskId, $.$discardRef());
                /*var*/ let registration;
                if (this._cancellationRegistrations.TryRemove$1(taskId, $.$ref(() => registration, ($v) => registration = $v, $.$$.System.Threading.CancellationTokenRegistration)))
                {
                    registration.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132491371)
            
            //--TRIMMABLE-BOUNDARY-START(38657654891)
            /*void */ BeginInvokeJS$1(/*long*/ taskId, /*string*/ identifier, /*string?*/ argsJson)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657654891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.BeginInvokeJS(taskId, identifier, argsJson, 0/*JSCallResultType.Default*/, 0n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657654891)
            
            //--TRIMMABLE-BOUNDARY-START(47247589483)
            /*void */ BeginInvokeJS$2(/*in JSInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247589483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.BeginInvokeJS(invocationInfo.$v.AsyncHandle, invocationInfo.$v.Identifier, invocationInfo.$v.ArgsJson, invocationInfo.$v.ResultType, invocationInfo.$v.TargetInstanceId);
            }
            //--TRIMMABLE-BOUNDARY-END(47247589483)
            
            //--TRIMMABLE-BOUNDARY-START(154621771883)
            /*void */ SendByteArray(/*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621771883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12("JSRuntime subclasses are responsible for implementing byte array transfer to JS.");
            }
            //--TRIMMABLE-BOUNDARY-END(154621771883)
            
            //--TRIMMABLE-BOUNDARY-START(146031837291)
            /*void */ ReceiveByteArray(/*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031837291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (id === 0)
                {
                    this.ByteArraysToBeRevived.Clear();
                }
                if (id !== this.ByteArraysToBeRevived.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$17(`Element id '${id}' cannot be added to the byte arrays to be revived with length '${this.ByteArraysToBeRevived.Count}'.`, null);
                }
                this.ByteArraysToBeRevived.Append$2($.$ref(() => data, ));
            }
            //--TRIMMABLE-BOUNDARY-END(146031837291)
            
            //--TRIMMABLE-BOUNDARY-START(141736869995)
            /*Task<Stream> */ ReadJSDataAsStreamAsync(/*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736869995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12("The current JavaScript runtime does not support reading data streams.");
            }
            //--TRIMMABLE-BOUNDARY-END(141736869995)
            
            //--TRIMMABLE-BOUNDARY-START(77312360555)
            /*bool */ EndInvokeJS(/*long*/ taskId, /*bool*/ succeeded, /*ref Utf8JsonReader*/ jsonReader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312360555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tcs;
                if (!this._pendingTasks.TryRemove$1(taskId, $.$ref(() => tcs, ($v) => tcs = $v, $.$$.System.Object)))
                {
                    return false;
                }
                this.CleanupTasksAndRegistrations(taskId);
                try
                {
                    if (succeeded)
                    {
                        /*var*/ let resultType = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.GetTaskCompletionSourceResultType(tcs);
                        /*var*/ let result = $.$stj.System.Text.Json.JsonSerializer.Deserialize$21(jsonReader, resultType, this.JsonSerializerOptions);
                        this.ByteArraysToBeRevived.Clear();
                        $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.SetTaskCompletionSourceResult(tcs, result);
                    }
                    else 
                    {
                        /*var*/ let exceptionText = jsonReader.$v.GetString() ?? $.$$.System.String.Empty;
                        $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.SetTaskCompletionSourceException(tcs, new $.$mj.Microsoft.JSInterop.JSException().$ctor$6(exceptionText));
                    }
                    return true;
                }
                catch(exception)
                {
                    /*var*/ let message = `An exception occurred executing JS interop: ${exception.Message}. See InnerException for more details.`;
                    $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.SetTaskCompletionSourceException(tcs, new $.$mj.Microsoft.JSInterop.JSException().$ctor$5(message, exception));
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77312360555)
            
            //--TRIMMABLE-BOUNDARY-START(180391575659)
            /*Task */ TransmitStreamAsync(/*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391575659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!dotNetStreamReference.LeaveOpen)
                {
                    dotNetStreamReference.Stream.Dispose();
                }
                throw new $.$$.System.NotSupportedException().$ctor$12("The current JS runtime does not support sending streams from .NET to JS.");
            }
            //--TRIMMABLE-BOUNDARY-END(180391575659)
            
            //--TRIMMABLE-BOUNDARY-START(51542556779)
            /*long */ BeginTransmittingStream(/*DotNetStreamReference*/ dotNetStreamReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542556779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let streamId = $.$$.System.Threading.Interlocked.Increment$1($.$ref(() => this._nextObjectReferenceId, ($v) => this._nextObjectReferenceId = $v, $.$$.System.Int64));
                _ = this.TransmitStreamAsync(streamId, dotNetStreamReference);
                return streamId;
            }
            //--TRIMMABLE-BOUNDARY-END(51542556779)
            
            //--TRIMMABLE-BOUNDARY-START(176096608363)
            /*long */ TrackObjectReference(TValue, /*DotNetObjectReference<TValue>*/ dotNetObjectReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096608363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(dotNetObjectReference, "dotNetObjectReference");
                dotNetObjectReference.ThrowIfDisposed();
                /*var*/ let jsRuntime = dotNetObjectReference.JSRuntime;
                if (jsRuntime === null)
                {
                    /*var*/ let dotNetObjectId = $.$$.System.Threading.Interlocked.Increment$1($.$ref(() => this._nextObjectReferenceId, ($v) => this._nextObjectReferenceId = $v, $.$$.System.Int64));
                    dotNetObjectReference.JSRuntime = this;
                    dotNetObjectReference.ObjectId = dotNetObjectId;
                    this._trackedRefsById.set_Item(dotNetObjectId, dotNetObjectReference);
                }
                else if (!$.$$.System.Object.ReferenceEquals(this, jsRuntime))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Object.GetType.call(dotNetObjectReference).Name} is already being tracked by a different instance of ${"JSRuntime"}.` + ` A common cause is caching an instance of ${"DotNetObjectReference"} globally. Consider creating instances of ${"DotNetObjectReference"} at the JSInterop callsite.`);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(dotNetObjectReference.ObjectId !== 0n, "dotNetObjectReference.ObjectId != 0");
                return dotNetObjectReference.ObjectId;
            }
            //--TRIMMABLE-BOUNDARY-END(176096608363)
            
            //--TRIMMABLE-BOUNDARY-START(98787197035)
            /*IDotNetObjectReference */ GetObjectReference(/*long*/ dotNetObjectId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787197035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dotNetObjectRef;
                return this._trackedRefsById.TryGetValue(dotNetObjectId, $.$ref(() => dotNetObjectRef, ($v) => dotNetObjectRef = $v, $.$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference)) ? dotNetObjectRef : (() =>
                {
        throw new $.$$.System.ArgumentException().$ctor$13(`There is no tracked object with id '${dotNetObjectId}'. Perhaps the DotNetObjectReference instance was already disposed.`, "dotNetObjectId")        })();
            }
            //--TRIMMABLE-BOUNDARY-END(98787197035)
            
            //--TRIMMABLE-BOUNDARY-START(150326804587)
            /*void */ ReleaseObjectReference(/*long*/ dotNetObjectId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150326804587);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._trackedRefsById.TryRemove$1(dotNetObjectId, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150326804587)
            
            //--TRIMMABLE-BOUNDARY-START(68722425963)
            /*void */ Dispose()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68722425963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ByteArraysToBeRevived.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722425963)
            
            //--TRIMMABLE-BOUNDARY-START(12885426283)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeAsync<TValue>(string, object?[]?)
            Microsoft$JSInterop$IJSRuntime$InvokeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885426283)
            
            //--TRIMMABLE-BOUNDARY-START(17180393579)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeAsync<TValue>(string, System.Threading.CancellationToken, object?[]?)
            Microsoft$JSInterop$IJSRuntime$InvokeAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180393579)
            
            //--TRIMMABLE-BOUNDARY-START(21475360875)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeConstructorAsync(string, object?[]?)
            Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructorAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475360875)
            
            //--TRIMMABLE-BOUNDARY-START(25770328171)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeConstructorAsync(string, System.Threading.CancellationToken, object?[]?)
            Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructorAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770328171)
            
            //--TRIMMABLE-BOUNDARY-START(4295491691)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.GetValueAsync<TValue>(string)
            Microsoft$JSInterop$IJSRuntime$GetValueAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295491691)
            
            //--TRIMMABLE-BOUNDARY-START(8590458987)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.GetValueAsync<TValue>(string, System.Threading.CancellationToken)
            Microsoft$JSInterop$IJSRuntime$GetValueAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590458987)
            
            //--TRIMMABLE-BOUNDARY-START(30065295467)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.SetValueAsync<TValue>(string, TValue)
            Microsoft$JSInterop$IJSRuntime$SetValueAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValueAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065295467)
            
            //--TRIMMABLE-BOUNDARY-START(34360262763)
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.SetValueAsync<TValue>(string, TValue, System.Threading.CancellationToken)
            Microsoft$JSInterop$IJSRuntime$SetValueAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValueAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360262763)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17182818411)
                this._pendingTasks = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Int64, $.$$.System.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17182818411)
                
                //--TRIMMABLE-BOUNDARY-START(21477785707)
                this._trackedRefsById = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Int64, $.$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(21477785707)
                
                //--TRIMMABLE-BOUNDARY-START(4297916523)
                this._cancellationRegistrations = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Int64, $.$$.System.Threading.CancellationTokenRegistration))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4297916523)
                
                //--TRIMMABLE-BOUNDARY-START(55837524075)
                this.ByteArraysToBeRevived = new ($.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$($.$typeArray($.$$.System.Byte)))().$ctor$1(32, null);
                //--TRIMMABLE-BOUNDARY-END(55837524075)
                
                this.DefaultAsyncTimeout = null;
            }
            static $h = 2949227;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(137441902699),
    {
      "p": 3342420,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492229739,
        "f": 50331664
      },
      "n": "JsonSerializerOptions",
      "d": 2949227,
      "h": 137441902699,
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(137441902699),
//--TRIMMABLE-BOUNDARY-START(64427458667),
    {
      "p": $.$typeNullable($.$$.System.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902295147,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163211706475,
        "f": 83886084
      },
      "n": "DefaultAsyncTimeout",
      "d": 2949227,
      "h": 64427458667,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(64427458667)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111672098923),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 2949227,
      "h": 111672098923,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(111672098923),
//--TRIMMABLE-BOUNDARY-START(115967066219),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$3",
      "d": 2949227,
      "h": 115967066219,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(115967066219),
//--TRIMMABLE-BOUNDARY-START(128851968107),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "d": 2949227,
      "h": 128851968107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128851968107),
//--TRIMMABLE-BOUNDARY-START(133146935403),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$1",
      "d": 2949227,
      "h": 133146935403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133146935403),
//--TRIMMABLE-BOUNDARY-START(103082164331),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "@$1",
      "d": 2949227,
      "h": 103082164331,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(103082164331),
//--TRIMMABLE-BOUNDARY-START(107377131627),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "d": 2949227,
      "h": 107377131627,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(107377131627),
//--TRIMMABLE-BOUNDARY-START(167506673771),
    {
      "r": 180420609,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "@$1",
      "d": 2949227,
      "h": 167506673771,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(167506673771),
//--TRIMMABLE-BOUNDARY-START(171801641067),
    {
      "r": 180420609,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "d": 2949227,
      "h": 171801641067,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(171801641067),
//--TRIMMABLE-BOUNDARY-START(120262033515),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "targetInstanceId",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "callType",
          "p": 1704043
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "d": 2949227,
      "h": 120262033515,
      "f": 16912392
    },
//--TRIMMABLE-BOUNDARY-END(120262033515),
//--TRIMMABLE-BOUNDARY-START(124557000811),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "targetInstanceId",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "callType",
          "p": 1704043
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 2949227,
      "h": 124557000811,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(124557000811),
//--TRIMMABLE-BOUNDARY-START(60132491371),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskId",
          "p": 917505
        }
      ],
      "n": "CleanupTasksAndRegistrations",
      "d": 2949227,
      "h": 60132491371,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60132491371),
//--TRIMMABLE-BOUNDARY-START(38657654891),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskId",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "BeginInvokeJS",
      "o": "@$1",
      "d": 2949227,
      "h": 38657654891,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(38657654891),
//--TRIMMABLE-BOUNDARY-START(42952622187),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskId",
          "p": 917505
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        },
        {
          "n": "resultType",
          "p": 2359403
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        }
      ],
      "n": "BeginInvokeJS",
      "d": 2949227,
      "h": 42952622187,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(42952622187),
//--TRIMMABLE-BOUNDARY-START(47247589483),
    {
      "r": 65537,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1769579,
          "f": 8
        }
      ],
      "n": "BeginInvokeJS",
      "o": "@$2",
      "d": 2949227,
      "h": 47247589483,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(47247589483),
//--TRIMMABLE-BOUNDARY-START(73017393259),
    {
      "r": 65537,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1245291
        },
        {
          "n": "invocationResult",
          "p": 1310827,
          "f": 8
        }
      ],
      "n": "EndInvokeDotNet",
      "d": 2949227,
      "h": 73017393259,
      "f": 16777488
    },
//--TRIMMABLE-BOUNDARY-END(73017393259),
//--TRIMMABLE-BOUNDARY-START(154621771883),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "SendByteArray",
      "d": 2949227,
      "h": 154621771883,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(154621771883),
//--TRIMMABLE-BOUNDARY-START(146031837291),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "ReceiveByteArray",
      "d": 2949227,
      "h": 146031837291,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(146031837291),
//--TRIMMABLE-BOUNDARY-START(141736869995),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream).$h,
      "p": [
        {
          "n": "jsStreamReference",
          "p": 589931
        },
        {
          "n": "totalLength",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "ReadJSDataAsStreamAsync",
      "d": 2949227,
      "h": 141736869995,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(141736869995),
//--TRIMMABLE-BOUNDARY-START(77312360555),
    {
      "r": 262145,
      "p": [
        {
          "n": "taskId",
          "p": 917505
        },
        {
          "n": "succeeded",
          "p": 262145
        },
        {
          "n": "jsonReader",
          "p": 19333204,
          "f": 4
        }
      ],
      "n": "EndInvokeJS",
      "d": 2949227,
      "h": 77312360555,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77312360555),
//--TRIMMABLE-BOUNDARY-START(180391575659),
    {
      "r": 177537025,
      "p": [
        {
          "n": "streamId",
          "p": 917505
        },
        {
          "n": "dotNetStreamReference",
          "p": 262251
        }
      ],
      "n": "TransmitStreamAsync",
      "d": 2949227,
      "h": 180391575659,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(180391575659),
//--TRIMMABLE-BOUNDARY-START(51542556779),
    {
      "r": 917505,
      "p": [
        {
          "n": "dotNetStreamReference",
          "p": 262251
        }
      ],
      "n": "BeginTransmittingStream",
      "d": 2949227,
      "h": 51542556779,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51542556779),
//--TRIMMABLE-BOUNDARY-START(176096608363),
    {
      "r": 917505,
      "p": [
        {
          "n": "dotNetObjectReference",
          "p": (TValue) => $.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "TrackObjectReference",
      "d": 2949227,
      "h": 176096608363,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(176096608363),
//--TRIMMABLE-BOUNDARY-START(98787197035),
    {
      "r": 1572971,
      "p": [
        {
          "n": "dotNetObjectId",
          "p": 917505
        }
      ],
      "n": "GetObjectReference",
      "d": 2949227,
      "h": 98787197035,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98787197035),
//--TRIMMABLE-BOUNDARY-START(150326804587),
    {
      "r": 65537,
      "p": [
        {
          "n": "dotNetObjectId",
          "p": 917505
        }
      ],
      "n": "ReleaseObjectReference",
      "d": 2949227,
      "h": 150326804587,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150326804587),
//--TRIMMABLE-BOUNDARY-START(68722425963),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2949227,
      "h": 68722425963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68722425963)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(184686542955),
    {
      "t": 917505,
      "n": "WindowObjectId",
      "d": 2949227,
      "h": 184686542955,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184686542955),
//--TRIMMABLE-BOUNDARY-START(8592883819),
    {
      "t": 917505,
      "n": "_nextObjectReferenceId",
      "d": 2949227,
      "h": 8592883819,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592883819),
//--TRIMMABLE-BOUNDARY-START(12887851115),
    {
      "t": 917505,
      "n": "_nextPendingTaskId",
      "d": 2949227,
      "h": 12887851115,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887851115),
//--TRIMMABLE-BOUNDARY-START(17182818411),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Int64, $.$$.System.Object).$h,
      "n": "_pendingTasks",
      "d": 2949227,
      "h": 17182818411,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182818411),
//--TRIMMABLE-BOUNDARY-START(21477785707),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Int64, $.$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference).$h,
      "n": "_trackedRefsById",
      "d": 2949227,
      "h": 21477785707,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477785707),
//--TRIMMABLE-BOUNDARY-START(4297916523),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Int64, $.$$.System.Threading.CancellationTokenRegistration).$h,
      "n": "_cancellationRegistrations",
      "d": 2949227,
      "h": 4297916523,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297916523),
//--TRIMMABLE-BOUNDARY-START(55837524075),
    {
      "t": $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$($.$typeArray($.$$.System.Byte)).$h,
      "n": "ByteArraysToBeRevived",
      "d": 2949227,
      "h": 55837524075,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(55837524075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772753003),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2949227,
      "h": 25772753003,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25772753003)
  ],
  "i": [524395,90177537
  ],
  "h": 2949227
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSRuntime, $.$$.System.IDisposable ]; }
            static get $fullName() { return `JSRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949227)
        
        
        //--TRIMMABLE-BOUNDARY-START(2687083)
        $asm.$cls("$mj.Microsoft.JSInterop.JSInProcessRuntime", ($self) => class JSInProcessRuntime extends $.$mj.Microsoft.JSInterop.JSRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(42952360043)
            /*long*/ static SyncCallIndicator = 0n;
            //--TRIMMABLE-BOUNDARY-END(42952360043)
            
            //--TRIMMABLE-BOUNDARY-START(12887588971)
            /*TValue */ Invoke$1(TValue, /*string*/ identifier, /*params object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887588971);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Invoke(TValue, identifier, 0n, 1/*JSCallType.FunctionCall*/, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887588971)
            
            //--TRIMMABLE-BOUNDARY-START(21477523563)
            /*IJSInProcessObjectReference */ InvokeConstructor(/*string*/ identifier, /*params object?[]?*/ args)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477523563);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Invoke($.$mj.Microsoft.JSInterop.IJSInProcessObjectReference, identifier, 0n, 2/*JSCallType.ConstructorCall*/, args);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477523563)
            
            //--TRIMMABLE-BOUNDARY-START(8592621675)
            /*TValue */ GetValue(TValue, /*string*/ identifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592621675);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Invoke(TValue, identifier, 0n, 3/*JSCallType.GetValue*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592621675)
            
            //--TRIMMABLE-BOUNDARY-START(38657392747)
            /*void */ SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657392747);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Invoke($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, 0n, 4/*JSCallType.SetValue*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(value, TValue) ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657392747)
            
            //--TRIMMABLE-BOUNDARY-START(17182556267)
            /*TValue */ Invoke(TValue, /*string*/ identifier, /*long*/ targetInstanceId, /*JSCallType*/ callType, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182556267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let argsJson = !(args === null) && args.length !== 0 ? $.$stj.System.Text.Json.JsonSerializer.Serialize$13($.$typeArray($.$$.System.Object), args, this.JsonSerializerOptions) : "[]";
                /*var*/ let resultType = $.$mj.Microsoft.JSInterop.JSCallResultTypeHelper.FromGeneric(TValue);
                /*var*/ let invocationInfo = (() =>
                {
                    //new $.$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo()
                    const $t1 = $.$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo;
                    const $i1 = new $t1();
                    $i1.AsyncHandle = 0n;
                    $i1.TargetInstanceId = targetInstanceId;
                    $i1.Identifier = identifier;
                    $i1.CallType = callType;
                    $i1.ResultType = resultType;
                    $i1.ArgsJson = argsJson;
                    return $i1;
                })();
                /*var*/ let resultJson = this.InvokeJS$2($.$ref(() => invocationInfo, ));
                if (resultJson === null)
                {
                    return $.$default(TValue);
                }
                /*var*/ let result = $.$stj.System.Text.Json.JsonSerializer.Deserialize$30(TValue, resultJson, this.JsonSerializerOptions);
                this.ByteArraysToBeRevived.Clear();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(17182556267)
            
            //--TRIMMABLE-BOUNDARY-START(25772490859)
            /*string? */ InvokeJS$1(/*string*/ identifier, /*string?*/ argsJson)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772490859);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeJS(identifier, argsJson, 0/*JSCallResultType.Default*/, 0n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772490859)
            
            //--TRIMMABLE-BOUNDARY-START(34362425451)
            /*string? */ InvokeJS$2(/*in JSInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362425451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeJS(invocationInfo.$v.Identifier, invocationInfo.$v.ArgsJson, invocationInfo.$v.ResultType, invocationInfo.$v.TargetInstanceId);
            }
            //--TRIMMABLE-BOUNDARY-END(34362425451)
            
            //--TRIMMABLE-BOUNDARY-START(8590327915)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.Invoke<TResult>(string, params object?[]?)
            Microsoft$JSInterop$IJSInProcessRuntime$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327915)
            
            //--TRIMMABLE-BOUNDARY-START(12885295211)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.InvokeConstructor(string, params object?[]?)
            Microsoft$JSInterop$IJSInProcessRuntime$InvokeConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295211)
            
            //--TRIMMABLE-BOUNDARY-START(4295360619)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.GetValue<TValue>(string)
            Microsoft$JSInterop$IJSInProcessRuntime$GetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295360619)
            
            //--TRIMMABLE-BOUNDARY-START(17180262507)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.SetValue<TValue>(string, TValue)
            Microsoft$JSInterop$IJSInProcessRuntime$SetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262507)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2687083;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2949227,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887588971),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Invoke",
      "o": "@$1",
      "d": 2687083,
      "h": 12887588971,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(12887588971),
//--TRIMMABLE-BOUNDARY-START(21477523563),
    {
      "r": 327787,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeConstructor",
      "d": 2687083,
      "h": 21477523563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477523563),
//--TRIMMABLE-BOUNDARY-START(8592621675),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValue",
      "d": 2687083,
      "h": 8592621675,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(8592621675),
//--TRIMMABLE-BOUNDARY-START(38657392747),
    {
      "r": 65537,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValue",
      "d": 2687083,
      "h": 38657392747,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(38657392747),
//--TRIMMABLE-BOUNDARY-START(17182556267),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        },
        {
          "n": "callType",
          "p": 1704043
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Invoke",
      "d": 2687083,
      "h": 17182556267,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(17182556267),
//--TRIMMABLE-BOUNDARY-START(25772490859),
    {
      "r": 1310721,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "InvokeJS",
      "o": "@$1",
      "d": 2687083,
      "h": 25772490859,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(25772490859),
//--TRIMMABLE-BOUNDARY-START(30067458155),
    {
      "r": 1310721,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        },
        {
          "n": "resultType",
          "p": 2359403
        },
        {
          "n": "targetInstanceId",
          "p": 917505
        }
      ],
      "n": "InvokeJS",
      "d": 2687083,
      "h": 30067458155,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(30067458155),
//--TRIMMABLE-BOUNDARY-START(34362425451),
    {
      "r": 1310721,
      "p": [
        {
          "n": "invocationInfo",
          "p": 1769579,
          "f": 8
        }
      ],
      "n": "InvokeJS",
      "o": "@$2",
      "d": 2687083,
      "h": 34362425451,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(34362425451)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42952360043),
    {
      "t": 917505,
      "n": "SyncCallIndicator",
      "d": 2687083,
      "h": 42952360043,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42952360043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297654379),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687083,
      "h": 4297654379,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297654379)
  ],
  "i": [90177537,393323,524395
  ],
  "h": 2687083
}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.JSRuntime; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$mj.Microsoft.JSInterop.IJSInProcessRuntime, $.$mj.Microsoft.JSInterop.IJSRuntime ]; }
            static get $fullName() { return `JSInProcessRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687083)
        
        
        //--TRIMMABLE-BOUNDARY-START(65643)
        $asm.$cls("$mj.Microsoft.AspNetCore.Internal.LinkerFlags", ($self) => class LinkerFlags
        {
            //--TRIMMABLE-BOUNDARY-START(12884967531)
            /*DynamicallyAccessedMemberTypes*/ static JsonSerialized = 547;
            //--TRIMMABLE-BOUNDARY-END(12884967531)
            
            //--TRIMMABLE-BOUNDARY-START(4295032939)
            /*DynamicallyAccessedMemberTypes*/ static Component = -1;
            //--TRIMMABLE-BOUNDARY-END(4295032939)
            
            //--TRIMMABLE-BOUNDARY-START(8590000235)
            /*DynamicallyAccessedMemberTypes*/ static JSInvokable = 8;
            //--TRIMMABLE-BOUNDARY-END(8590000235)
            
            static $h = 65643;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12884967531),
    {
      "n": "JsonSerialized",
      "d": 65643,
      "h": 12884967531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967531),
//--TRIMMABLE-BOUNDARY-START(4295032939),
    {
      "n": "Component",
      "d": 65643,
      "h": 4295032939,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295032939),
//--TRIMMABLE-BOUNDARY-START(8590000235),
    {
      "n": "JSInvokable",
      "d": 65643,
      "h": 8590000235,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000235)
  ],
  "h": 65643
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LinkerFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65643)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424939)
        $asm.$cls("$mj.Microsoft.JSInterop.JSCallResultTypeHelper", ($self) => class JSCallResultTypeHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4297392235)
            /*Assembly*/ static _currentAssembly = null;
            //--TRIMMABLE-BOUNDARY-END(4297392235)
            
            //--TRIMMABLE-BOUNDARY-START(12887326827)
            static /*JSCallResultType */ FromGeneric(TResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887326827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Reflection.Assembly.op_Equality(TResult.$type.Assembly, $.$mj.Microsoft.JSInterop.JSCallResultTypeHelper._currentAssembly))
                {
                    if ($.$$.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSObjectReference.$type) || $.$$.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference.$type))
                    {
                        return 1/*JSCallResultType.JSObjectReference*/;
                    }
                    else if ($.$$.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSStreamReference.$type))
                    {
                        return 2/*JSCallResultType.JSStreamReference*/;
                    }
                    else if ($.$$.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult.$type))
                    {
                        return 3/*JSCallResultType.JSVoidResult*/;
                    }
                }
                return 0/*JSCallResultType.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326827)
            
            //--TRIMMABLE-BOUNDARY-START(8592359531)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4297392235)
                    this._currentAssembly = $.$mj.Microsoft.JSInterop.JSCallResultType.$type.Assembly;
                    //--TRIMMABLE-BOUNDARY-END(4297392235)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592359531)
            
            static $h = 2424939;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887326827),
    {
      "r": 2359403,
      "g": [
        "TResult"
      ],
      "n": "FromGeneric",
      "d": 2424939,
      "h": 12887326827,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887326827)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297392235),
    {
      "t": 106168321,
      "n": "_currentAssembly",
      "d": 2424939,
      "h": 4297392235,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297392235)
  ],
  "h": 2424939
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSCallResultTypeHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424939)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752619)
        $asm.$cls("$mj.Microsoft.JSInterop.JSInProcessRuntimeExtensions", ($self) => class JSInProcessRuntimeExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297719915)
            static /*void */ InvokeVoid(/*this IJSInProcessRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297719915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                jsRuntime.Microsoft$JSInterop$IJSInProcessRuntime$Invoke($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(4297719915)
            
            static $h = 2752619;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297719915),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsRuntime",
          "p": 393323
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoid",
      "d": 2752619,
      "h": 4297719915,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297719915)
  ],
  "h": 2752619
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSInProcessRuntimeExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752619)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621547)
        $asm.$cls("$mj.Microsoft.JSInterop.JSInProcessObjectReferenceExtensions", ($self) => class JSInProcessObjectReferenceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297588843)
            static /*void */ InvokeVoid(/*this IJSInProcessObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297588843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                jsObjectReference.Microsoft$JSInterop$IJSInProcessObjectReference$Invoke($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(4297588843)
            
            static $h = 2621547;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297588843),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 327787
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoid",
      "d": 2621547,
      "h": 4297588843,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297588843)
  ],
  "h": 2621547
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSInProcessObjectReferenceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621547)
        
        
        //--TRIMMABLE-BOUNDARY-START(131179)
        $asm.$cls("$mj.Microsoft.JSInterop.DotNetObjectReference", ($self) => class DotNetObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(4295098475)
            static /*DotNetObjectReference<TValue> */ Create(TValue, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(value, TValue), "value");
                return new ($.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue))().$ctor$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098475)
            
            static $h = 131179;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098475),
    {
      "r": (TValue) => $.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue).$h,
      "p": [
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Create",
      "d": 131179,
      "h": 4295098475,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295098475)
  ],
  "h": 131179
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `DotNetObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131179)
        
        
        //--TRIMMABLE-BOUNDARY-START(786539)
        $asm.$cls("$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker", ($self) => class JSObjectReferenceJsonWorker
        {
            //--TRIMMABLE-BOUNDARY-START(8590721131)
            /*JsonEncodedText*/ static JSObjectIdKey;
            //--TRIMMABLE-BOUNDARY-END(8590721131)
            
            //--TRIMMABLE-BOUNDARY-START(12885688427)
            static /*long */ ReadJSObjectReferenceIdentifier(/*ref Utf8JsonReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long?*/ let id = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (id === null && reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON property ${reader.$v.GetString()}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON token ${reader.$v.TokenType}`);
                    }
                }
                if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(id))
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Required property ${$.$stj.System.Text.Json.JsonEncodedText.ToString.call($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey)} not found.`);
                }
                return $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(id);
            }
            //--TRIMMABLE-BOUNDARY-END(12885688427)
            
            //--TRIMMABLE-BOUNDARY-START(17180655723)
            static /*void */ WriteJSObjectReference(/*Utf8JsonWriter*/ writer, /*JSObjectReference*/ objectReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                writer.WriteNumber$26($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey, objectReference.Id);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(17180655723)
            
            //--TRIMMABLE-BOUNDARY-START(4295753835)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590721131)
                    this.JSObjectIdKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("__jsObjectId", null);
                    //--TRIMMABLE-BOUNDARY-END(8590721131)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753835)
            
            static $h = 786539;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885688427),
    {
      "r": 917505,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        }
      ],
      "n": "ReadJSObjectReferenceIdentifier",
      "d": 786539,
      "h": 12885688427,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885688427),
//--TRIMMABLE-BOUNDARY-START(17180655723),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "objectReference",
          "p": 721003
        }
      ],
      "n": "WriteJSObjectReference",
      "d": 786539,
      "h": 17180655723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180655723)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721131),
    {
      "t": 2293844,
      "n": "JSObjectIdKey",
      "d": 786539,
      "h": 8590721131,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590721131)
  ],
  "h": 786539
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSObjectReferenceJsonWorker`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786539)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014763)
        $asm.$cls("$mj.Microsoft.JSInterop.JSRuntimeExtensions", ($self) => class JSRuntimeExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(34362753131)
            static /*ValueTask *//*async*/  InvokeVoidAsync(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362753131);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                    await jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, args);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34362753131)
            
            //--TRIMMABLE-BOUNDARY-START(8592949355)
            static /*ValueTask<TValue> */ InvokeAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592949355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync(TValue, identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(8592949355)
            
            //--TRIMMABLE-BOUNDARY-START(12887916651)
            static /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887916651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync$1(TValue, identifier, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(12887916651)
            
            //--TRIMMABLE-BOUNDARY-START(38657720427)
            static /*ValueTask *//*async*/  InvokeVoidAsync$1(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657720427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                    await jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, cancellationToken, args);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38657720427)
            
            //--TRIMMABLE-BOUNDARY-START(17182883947)
            static /*ValueTask<TValue> *//*async*/  InvokeAsync$2(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$(TValue), TValue, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182883947);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                    /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                    try
                    {
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                        return await jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync$1(TValue, identifier, cancellationToken, args);
                    }
                    finally
                    {
                        cancellationTokenSource?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182883947)
            
            //--TRIMMABLE-BOUNDARY-START(42952687723)
            static /*ValueTask *//*async*/  InvokeVoidAsync$2(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952687723);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                    /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                    try
                    {
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                        await jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, cancellationToken, args);
                    }
                    finally
                    {
                        cancellationTokenSource?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42952687723)
            
            //--TRIMMABLE-BOUNDARY-START(21477851243)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477851243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync(identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(21477851243)
            
            //--TRIMMABLE-BOUNDARY-START(25772818539)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772818539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1(identifier, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(25772818539)
            
            //--TRIMMABLE-BOUNDARY-START(30067785835)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$2(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067785835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                    return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1(identifier, cancellationToken, args);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067785835)
            
            //--TRIMMABLE-BOUNDARY-START(4297982059)
            static /*ValueTask<TValue> */ GetValueAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297982059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                    return jsRuntime.Microsoft$JSInterop$IJSRuntime$GetValueAsync(TValue, identifier, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297982059)
            
            //--TRIMMABLE-BOUNDARY-START(47247655019)
            static /*ValueTask */ SetValueAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TValue*/ value, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247655019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                    return jsRuntime.Microsoft$JSInterop$IJSRuntime$SetValueAsync(TValue, identifier, value, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247655019)
            
            static $h = 3014763;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362753131),
    {
      "r": 180420609,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "d": 3014763,
      "h": 34362753131,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(34362753131),
//--TRIMMABLE-BOUNDARY-START(8592949355),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "d": 3014763,
      "h": 8592949355,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8592949355),
//--TRIMMABLE-BOUNDARY-START(12887916651),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 3014763,
      "h": 12887916651,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887916651),
//--TRIMMABLE-BOUNDARY-START(38657720427),
    {
      "r": 180420609,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "o": "@$1",
      "d": 3014763,
      "h": 38657720427,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(38657720427),
//--TRIMMABLE-BOUNDARY-START(17182883947),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 185729025
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 3014763,
      "h": 17182883947,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(17182883947),
//--TRIMMABLE-BOUNDARY-START(42952687723),
    {
      "r": 180420609,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 185729025
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "o": "@$2",
      "d": 3014763,
      "h": 42952687723,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(42952687723),
//--TRIMMABLE-BOUNDARY-START(21477851243),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeConstructorAsync",
      "d": 3014763,
      "h": 21477851243,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477851243),
//--TRIMMABLE-BOUNDARY-START(25772818539),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$1",
      "d": 3014763,
      "h": 25772818539,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772818539),
//--TRIMMABLE-BOUNDARY-START(30067785835),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 185729025
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$2",
      "d": 3014763,
      "h": 30067785835,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067785835),
//--TRIMMABLE-BOUNDARY-START(4297982059),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "d": 3014763,
      "h": 4297982059,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4297982059),
//--TRIMMABLE-BOUNDARY-START(47247655019),
    {
      "r": 180420609,
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "d": 3014763,
      "h": 47247655019,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47247655019)
  ],
  "h": 3014763
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSRuntimeExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014763)
        
        
        //--TRIMMABLE-BOUNDARY-START(2883691)
        $asm.$cls("$mj.Microsoft.JSInterop.JSObjectReferenceExtensions", ($self) => class JSObjectReferenceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(34362622059)
            static /*ValueTask *//*async*/  InvokeVoidAsync(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362622059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                    await jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, args);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34362622059)
            
            //--TRIMMABLE-BOUNDARY-START(8592818283)
            static /*ValueTask<TValue> */ InvokeAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592818283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync(TValue, identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(8592818283)
            
            //--TRIMMABLE-BOUNDARY-START(12887785579)
            static /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887785579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1(TValue, identifier, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(12887785579)
            
            //--TRIMMABLE-BOUNDARY-START(38657589355)
            static /*ValueTask *//*async*/  InvokeVoidAsync$1(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657589355);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                    await jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, cancellationToken, args);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38657589355)
            
            //--TRIMMABLE-BOUNDARY-START(17182752875)
            static /*ValueTask<TValue> *//*async*/  InvokeAsync$2(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$(TValue), TValue, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182752875);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                    /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                    try
                    {
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                        return await jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1(TValue, identifier, cancellationToken, args);
                    }
                    finally
                    {
                        cancellationTokenSource?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182752875)
            
            //--TRIMMABLE-BOUNDARY-START(42952556651)
            static /*ValueTask *//*async*/  InvokeVoidAsync$2(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952556651);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                    /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                    try
                    {
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                        await jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, cancellationToken, args);
                    }
                    finally
                    {
                        cancellationTokenSource?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42952556651)
            
            //--TRIMMABLE-BOUNDARY-START(21477720171)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477720171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync(identifier, args);
            }
            //--TRIMMABLE-BOUNDARY-END(21477720171)
            
            //--TRIMMABLE-BOUNDARY-START(25772687467)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772687467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1(identifier, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(25772687467)
            
            //--TRIMMABLE-BOUNDARY-START(30067654763)
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$2(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067654763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                    return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1(identifier, cancellationToken, args);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067654763)
            
            //--TRIMMABLE-BOUNDARY-START(4297850987)
            static /*ValueTask<TValue> */ GetValueAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297850987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                    return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$GetValueAsync(TValue, identifier, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297850987)
            
            //--TRIMMABLE-BOUNDARY-START(47247523947)
            static /*ValueTask */ SetValueAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TValue*/ value, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247523947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$$.System.TimeSpan.op_Equality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$$.System.Threading.CancellationTokenSource().$ctor$4(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$$.System.Threading.CancellationToken.None;
                    return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$SetValueAsync(TValue, identifier, value, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247523947)
            
            static $h = 2883691;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362622059),
    {
      "r": 180420609,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "d": 2883691,
      "h": 34362622059,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(34362622059),
//--TRIMMABLE-BOUNDARY-START(8592818283),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "d": 2883691,
      "h": 8592818283,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8592818283),
//--TRIMMABLE-BOUNDARY-START(12887785579),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 2883691,
      "h": 12887785579,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887785579),
//--TRIMMABLE-BOUNDARY-START(38657589355),
    {
      "r": 180420609,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "o": "@$1",
      "d": 2883691,
      "h": 38657589355,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(38657589355),
//--TRIMMABLE-BOUNDARY-START(17182752875),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 185729025
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 2883691,
      "h": 17182752875,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(17182752875),
//--TRIMMABLE-BOUNDARY-START(42952556651),
    {
      "r": 180420609,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 185729025
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeVoidAsync",
      "o": "@$2",
      "d": 2883691,
      "h": 42952556651,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(42952556651),
//--TRIMMABLE-BOUNDARY-START(21477720171),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "InvokeConstructorAsync",
      "d": 2883691,
      "h": 21477720171,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477720171),
//--TRIMMABLE-BOUNDARY-START(25772687467),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$1",
      "d": 2883691,
      "h": 25772687467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772687467),
//--TRIMMABLE-BOUNDARY-START(30067654763),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 185729025
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$2",
      "d": 2883691,
      "h": 30067654763,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067654763),
//--TRIMMABLE-BOUNDARY-START(4297850987),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "d": 2883691,
      "h": 4297850987,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4297850987),
//--TRIMMABLE-BOUNDARY-START(47247523947),
    {
      "r": 180420609,
      "p": [
        {
          "n": "jsObjectReference",
          "p": 458859
        },
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "d": 2883691,
      "h": 47247523947,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47247523947)
  ],
  "h": 2883691
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSObjectReferenceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883691)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048683)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher", ($self) => class DotNetDispatcher
        {
            //--TRIMMABLE-BOUNDARY-START(38655754347)
            /*string*/ static DisposeDotNetObjectReferenceMethodName = null;
            //--TRIMMABLE-BOUNDARY-END(38655754347)
            
            //--TRIMMABLE-BOUNDARY-START(42950721643)
            /*JsonEncodedText*/ static DotNetObjectRefKey;
            //--TRIMMABLE-BOUNDARY-END(42950721643)
            
            //--TRIMMABLE-BOUNDARY-START(8590983275)
            /*ConcurrentDictionary<AssemblyKey, IReadOnlyDictionary<string, (MethodInfo, Type[])>>*/ static _cachedMethodsByAssembly = null;
            //--TRIMMABLE-BOUNDARY-END(8590983275)
            
            //--TRIMMABLE-BOUNDARY-START(12885950571)
            /*ConcurrentDictionary<Type, IReadOnlyDictionary<string, (MethodInfo, Type[])>>*/ static _cachedMethodsByType = null;
            //--TRIMMABLE-BOUNDARY-END(12885950571)
            
            //--TRIMMABLE-BOUNDARY-START(4296015979)
            /*ConcurrentDictionary<Type, Func<object, Task>>*/ static _cachedConvertToTaskByType = null;
            //--TRIMMABLE-BOUNDARY-END(4296015979)
            
            //--TRIMMABLE-BOUNDARY-START(17180917867)
            /*MethodInfo*/ static _taskConverterMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(17180917867)
            
            //--TRIMMABLE-BOUNDARY-START(77310460011)
            static /*string? */ Invoke(/*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ invocationInfo, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310460011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IDotNetObjectReference?*/ let targetInstance = null;
                if (invocationInfo.$v.DotNetObjectId !== 0n)
                {
                    targetInstance = jsRuntime.GetObjectReference(invocationInfo.$v.DotNetObjectId);
                }
                /*var*/ let syncResult = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.InvokeSynchronously(jsRuntime, invocationInfo, targetInstance, argsJson);
                if (syncResult === null)
                {
                    return null;
                }
                return $.$stj.System.Text.Json.JsonSerializer.Serialize$13($.$$.System.Object, syncResult, jsRuntime.JsonSerializerOptions);
            }
            //--TRIMMABLE-BOUNDARY-END(77310460011)
            
            //--TRIMMABLE-BOUNDARY-START(30065819755)
            static /*void */ BeginInvokeDotNet(/*JSRuntime*/ jsRuntime, /*DotNetInvocationInfo*/ invocationInfo, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065819755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let callId = invocationInfo.CallId;
                /*object?*/ let syncResult = null;
                /*ExceptionDispatchInfo?*/ let syncException = null;
                /*IDotNetObjectReference?*/ let targetInstance = null;
                try
                {
                    if (invocationInfo.DotNetObjectId !== 0n)
                    {
                        targetInstance = jsRuntime.GetObjectReference(invocationInfo.DotNetObjectId);
                    }
                    syncResult = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.InvokeSynchronously(jsRuntime, $.$ref(() => invocationInfo, ), targetInstance, argsJson);
                }
                catch(ex)
                {
                    syncException = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex);
                }
                let task;
                let valueTaskResult;
                const $t1 = syncResult;
                let syncResultType;
                const $t2 = syncResult;
                const $t3 = syncResult;
                if ($.$$.System.String.op_Equality(callId, null))
                {
                    return;
                }
                else if (syncException !== null)
                {
                    jsRuntime.EndInvokeDotNet(invocationInfo, $.$ref(() => new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult().$ctor$3(syncException.SourceException, "InvocationFailure"), ));
                }
                else if ($.$is(syncResult, $.$$.System.Threading.Tasks.Task, { set $v(v){ task = v; } }))
                {
                    task.ContinueWith$10(new ($.$$.System.Action$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "t",
      "p": 177537025
    }
  ],
  "n": "",
  "d": 1048683,
  "h": 0,
  "f": 17825794
}), $.$$.System.Threading.Tasks.TaskScheduler.Current);
                }
                else if ($.$is(syncResult, $.$$.System.Threading.Tasks.ValueTask, { set $v(v){ valueTaskResult = v; } }))
                {
                    valueTaskResult.AsTask().ContinueWith$10(new ($.$$.System.Action$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "t",
      "p": 177537025
    }
  ],
  "n": "",
  "d": 1048683,
  "h": 0,
  "f": 17825794
}), $.$$.System.Threading.Tasks.TaskScheduler.Current);
                }
                else if ($.$ifnn($t1, ($t) => $.$$.System.Object.GetType.call($t)) !== null && ((syncResultType = $.$ifnn($t2, ($t) => $.$$.System.Object.GetType.call($t)), syncResultType != null && $.$ifnn($t3, ($t) => $.$$.System.Object.GetType.call($t)).IsGenericType === true)) && $.$$.System.Type.op_Equality$1(syncResultType.GetGenericTypeDefinition(), $.$$.System.Threading.Tasks.ValueTask$$().$type))
                {
                    /*var*/ let innerTask = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetTaskByType($.$$.System.Array.$ReadT1.call(syncResultType.GenericTypeArguments, 0), syncResult);
                    innerTask.ContinueWith$10(new ($.$$.System.Action$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "t",
      "p": 177537025
    }
  ],
  "n": "",
  "d": 1048683,
  "h": 0,
  "f": 17825794
}), $.$$.System.Threading.Tasks.TaskScheduler.Current);
                }
                else 
                {
                    /*var*/ let syncResultJson = $.$stj.System.Text.Json.JsonSerializer.Serialize$13($.$$.System.Object, syncResult, jsRuntime.JsonSerializerOptions);
                    /*var*/ let dispatchResult = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult().$ctor$4(syncResultJson);
                    jsRuntime.EndInvokeDotNet(invocationInfo, $.$ref(() => dispatchResult, ));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065819755)
            
            //--TRIMMABLE-BOUNDARY-START(47245688939)
            static /*void */ EndInvokeDotNetAfterTask(/*Task*/ task, /*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ invocationInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245688939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (task.Exception !== null)
                {
                    /*var*/ let exceptionDispatchInfo = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(task.Exception.GetBaseException());
                    /*var*/ let dispatchResult = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult().$ctor$3(exceptionDispatchInfo.SourceException, "InvocationFailure");
                    jsRuntime.EndInvokeDotNet(invocationInfo.$v, $.$ref(() => dispatchResult, ));
                }
                /*var*/ let result = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.GetTaskResult(task);
                /*var*/ let resultJson = $.$stj.System.Text.Json.JsonSerializer.Serialize$13($.$$.System.Object, result, jsRuntime.JsonSerializerOptions);
                jsRuntime.EndInvokeDotNet(invocationInfo.$v, $.$ref(() => new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult().$ctor$4(resultJson), ));
            }
            //--TRIMMABLE-BOUNDARY-END(47245688939)
            
            //--TRIMMABLE-BOUNDARY-START(81605427307)
            static /*object? */ InvokeSynchronously(/*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ callInfo, /*IDotNetObjectReference?*/ objectReference, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605427307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let assemblyName = callInfo.$v.AssemblyName;
                /*var*/ let methodIdentifier = callInfo.$v.MethodIdentifier;
                /*AssemblyKey*/ let assemblyKey;
                /*MethodInfo*/ let methodInfo;
                /*Type[]*/ let parameterTypes;
                if (objectReference === null)
                {
                    assemblyKey = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey().$ctor$4(assemblyName);
                    $.$tupleUnpack(($tp) =>
                    {
                        methodInfo = $tp.Item1;
                        parameterTypes = $tp.Item2;
                    }).$v = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetCachedMethodInfo(assemblyKey, methodIdentifier);
                }
                else 
                {
                    if ($.$$.System.String.op_Inequality(assemblyName, null))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14(`For instance method calls, '${"assemblyName"}' should be null. Value received: '${assemblyName}'.`);
                    }
                    if ($.$$.System.String.Equals$2("__Dispose"/*DisposeDotNetObjectReferenceMethodName*/, methodIdentifier, 4/*StringComparison.Ordinal*/))
                    {
                        objectReference.System$IDisposable$Dispose();
                        return null;
                    }
                    $.$tupleUnpack(($tp) =>
                    {
                        methodInfo = $tp.Item1;
                        parameterTypes = $tp.Item2;
                    }).$v = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetCachedMethodInfo$1(objectReference, methodIdentifier);
                }
                /*var*/ let suppliedArgs = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.ParseArguments(jsRuntime, methodIdentifier, argsJson, parameterTypes);
                try
                {
                    return methodInfo.Invoke((objectReference?.Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value ?? null), suppliedArgs);
                }
                catch(tie)
                {
                    if (tie.InnerException !== null)
                    {
                        $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(tie.InnerException).Throw();
                        throw tie.InnerException;
                    }
                    throw tie;
                }
                finally
                {
                    {
                        jsRuntime.ByteArraysToBeRevived.Clear();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605427307)
            
            //--TRIMMABLE-BOUNDARY-START(90195361899)
            static /*object?[] */ ParseArguments(/*JSRuntime*/ jsRuntime, /*string*/ methodIdentifier, /*string*/ $arguments, /*Type[]*/ parameterTypes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195361899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (parameterTypes.length === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Object);
                }
                /*var*/ let count = $.$$.System.Text.Encoding.UTF8.GetByteCount$6($arguments);
                /*var*/ let buffer = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(count);
                try
                {
                    /*var*/ let receivedBytes = $.$$.System.Text.Encoding.UTF8.GetBytes$5($.$$.System.String.op_Implicit($arguments), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(buffer));
                    $.$$.System.Diagnostics.Debug.Assert$2(count === receivedBytes, "count == receivedBytes");
                    /*var*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, buffer, 0, count)), new $.$stj.System.Text.Json.JsonReaderOptions());
                    if (!reader.Read() || reader.TokenType !== 3/*JsonTokenType.StartArray*/)
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10("Invalid JSON");
                    }
                    /*var*/ let suppliedArgs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [parameterTypes.length], null);
                    /*var*/ let index = 0;
                    while(index < parameterTypes.length && reader.Read() && reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                    {
                        /*var*/ let parameterType = $.$$.System.Array.$ReadT1.call(parameterTypes, index);
                        if (reader.TokenType === 1/*JsonTokenType.StartObject*/ && IsIncorrectDotNetObjectRefUse(parameterType, reader.Clone()))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12(`In call to '${methodIdentifier}', parameter of type '${parameterType.Name}' at index ${(((index + 1) | 0))} must be declared as type 'DotNetObjectRef<${parameterType.Name}>' to receive the incoming value.`);
                        }
                        $.$$.System.Array.$WriteT1.call(suppliedArgs, $.$stj.System.Text.Json.JsonSerializer.Deserialize$21($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), parameterType, jsRuntime.JsonSerializerOptions), index);
                        index++;
                    }
                    if (index < parameterTypes.length)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14(`The call to '${methodIdentifier}' expects '${parameterTypes.length}' parameters, but received '${index}'.`);
                    }
                    if (!reader.Read() || reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON token ${reader.TokenType}. Ensure that the call to \`${methodIdentifier}' is supplied with exactly '${parameterTypes.length}' parameters.`);
                    }
                    return suppliedArgs;
                    /*static bool*/  function IsIncorrectDotNetObjectRefUse(/*Type*/ parameterType, /*Utf8JsonReader*/ jsonReader)
                    {
                        if (jsonReader.Read() && jsonReader.TokenType === 5/*JsonTokenType.PropertyName*/ && jsonReader.ValueTextEquals($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.DotNetObjectRefKey.EncodedUtf8Bytes))
                        {
                            return !parameterType.IsGenericType || $.$$.System.Type.op_Inequality$1(parameterType.GetGenericTypeDefinition(), $.$mj.Microsoft.JSInterop.DotNetObjectReference$$().$type);
                        }
                        return false;
                    }
                }
                finally
                {
                    {
                        $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(buffer, false);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195361899)
            
            //--TRIMMABLE-BOUNDARY-START(51540656235)
            static /*void */ EndInvokeJS(/*JSRuntime*/ jsRuntime, /*string*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let utf8JsonBytes = $.$$.System.Text.Encoding.UTF8.GetBytes$8($arguments);
                /*var*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(utf8JsonBytes), new $.$stj.System.Text.Json.JsonReaderOptions());
                if (!reader.Read() || reader.TokenType !== 3/*JsonTokenType.StartArray*/)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10("Invalid JSON");
                }
                reader.Read();
                /*var*/ let taskId = reader.GetInt64();
                reader.Read();
                /*var*/ let success = reader.GetBoolean();
                reader.Read();
                if (!jsRuntime.EndInvokeJS(taskId, success, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null)))
                {
                    return;
                }
                if (!reader.Read() || reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10("Invalid JSON");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540656235)
            
            //--TRIMMABLE-BOUNDARY-START(94490329195)
            static /*void */ ReceiveByteArray(/*JSRuntime*/ jsRuntime, /*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490329195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                jsRuntime.ReceiveByteArray(id, data);
            }
            //--TRIMMABLE-BOUNDARY-END(94490329195)
            
            //--TRIMMABLE-BOUNDARY-START(55835623531)
            static /*(MethodInfo, Type[]) */ GetCachedMethodInfo(/*AssemblyKey*/ assemblyKey, /*string*/ methodIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835623531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(assemblyKey.AssemblyName, "assemblyKey.AssemblyName");
                $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(methodIdentifier, "methodIdentifier");
                /*var*/ let assemblyMethods = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedMethodsByAssembly.GetOrAdd(assemblyKey, new ($.$$.System.Func$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)))))().$ctor($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher, $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.ScanAssemblyForCallableMethods));
                /*var*/ let result;
                if (assemblyMethods.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue(methodIdentifier, $.$ref(() => result, ($v) => result = $v, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type))), [$.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type))]))
                {
                    return result;
                }
                else 
                {
                    throw new $.$$.System.ArgumentException().$ctor$14(`The assembly '${assemblyKey.AssemblyName}' does not contain a public invokable method with [${"JSInvokableAttribute"}(\"${methodIdentifier}\")].`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835623531)
            
            //--TRIMMABLE-BOUNDARY-START(73015492715)
            static /*Task */ GetTaskByType(/*Type*/ type, /*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015492715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let converterDelegate = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedConvertToTaskByType.GetOrAdd$2($.$$.System.Reflection.MethodInfo, type, new ($.$$.System.Func$$$$($.$$.System.Type, $.$$.System.Reflection.MethodInfo, $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Threading.Tasks.Task)))().$ctor(this,  (/*Type*/ t, /*MethodInfo*/ taskConverterMethodInfo) =>
                {
                    return taskConverterMethodInfo.MakeGenericMethod($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ t ], null, null)).CreateDelegate$2($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Threading.Tasks.Task));
                }, {
  "r": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Threading.Tasks.Task).$h,
  "p": [
    {
      "n": "t",
      "p": 187629569
    },
    {
      "n": "taskConverterMethodInfo",
      "p": 116719617
    }
  ],
  "n": "",
  "d": 1048683,
  "h": 0,
  "f": 17825794
}), $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._taskConverterMethodInfo);
                return converterDelegate.Invoke(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(73015492715)
            
            //--TRIMMABLE-BOUNDARY-START(34360787051)
            static /*Task */ CreateValueTaskConverter(T, /*object*/ result)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360787051);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$cast(result, $.$$.System.Threading.Tasks.ValueTask$$(T))).AsTask();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360787051)
            
            //--TRIMMABLE-BOUNDARY-START(60130590827)
            static /*(MethodInfo methodInfo, Type[] parameterTypes) */ GetCachedMethodInfo$1(/*IDotNetObjectReference*/ objectReference, /*string*/ methodIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130590827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$$.System.Object.GetType.call(objectReference.Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value);
                /*var*/ let assemblyMethods = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedMethodsByType.GetOrAdd(type, new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)))))().$ctor($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher, ScanTypeForCallableMethods));
                /*var*/ let result;
                if (assemblyMethods.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue(methodIdentifier, $.$ref(() => result, ($v) => result = $v, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type))), [$.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type))]))
                {
                    return result;
                }
                else 
                {
                    throw new $.$$.System.ArgumentException().$ctor$14(`The type '${type.Name}' does not contain a public invokable method with [${"JSInvokableAttribute"}(\"${methodIdentifier}\")].`);
                }
                /*static Dictionary<string, (MethodInfo, Type[])>*/  function ScanTypeForCallableMethods(/*Type*/ type)
                {
                    /*var*/ let result = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type))))().$ctor$6($.$$.System.StringComparer.Ordinal);
                    let $i2 = 0;
                    let $arr2 = type.GetMethods$1(4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/);
                    while ($i2 < $arr2.length)
                    {
                        let method = $arr2[$i2++];
                        if (method.ContainsGenericParameters$1 || !method.IsDefined($.$mj.Microsoft.JSInterop.JSInvokableAttribute.$type, false))
                        {
                            continue;
                        }
                        var $en4 = $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$13($.$mj.Microsoft.JSInterop.JSInvokableAttribute, method, false).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var attr = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*var*/ let identifier = attr.Identifier ?? method.Name;
                                /*var*/ let parameterTypes = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetParameterTypes(method);
                                if (result.ContainsKey(identifier))
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12(`The type ${type.Name} contains more than one ` + `[JSInvokable] method with identifier '${identifier}'. All [JSInvokable] methods within the same ` + "type must have different identifiers. You can pass a custom identifier as a parameter to " + `the [JSInvokable] attribute.`);
                                }
                                result.Add(identifier, new ($.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)))().$ctor$3(method, parameterTypes));
                            }
                        }
                    }
                    return result;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130590827)
            
            //--TRIMMABLE-BOUNDARY-START(98785296491)
            static /*Dictionary<string, (MethodInfo, Type[])> */ ScanAssemblyForCallableMethods(/*AssemblyKey*/ assemblyKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785296491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type))))().$ctor$6($.$$.System.StringComparer.Ordinal);
                /*var*/ let exportedTypes = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetRequiredLoadedAssembly(assemblyKey).GetExportedTypes();
                let $i1 = 0;
                let $arr1 = exportedTypes;
                while ($i1 < $arr1.length)
                {
                    let type = $arr1[$i1++];
                    let $i2 = 0;
                    let $arr2 = type.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                    while ($i2 < $arr2.length)
                    {
                        let method = $arr2[$i2++];
                        if (method.ContainsGenericParameters$1 || !method.IsDefined($.$mj.Microsoft.JSInterop.JSInvokableAttribute.$type, false))
                        {
                            continue;
                        }
                        var $en4 = $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$13($.$mj.Microsoft.JSInterop.JSInvokableAttribute, method, false).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var attr = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*var*/ let identifier = attr.Identifier ?? method.Name;
                                /*var*/ let parameterTypes = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetParameterTypes(method);
                                if (result.ContainsKey(identifier))
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12(`The assembly '${assemblyKey.AssemblyName}' contains more than one ` + `[JSInvokable] method with identifier '${identifier}'. All [JSInvokable] methods within the same ` + `assembly must have different identifiers. You can pass a custom identifier as a parameter to ` + `the [JSInvokable] attribute.`);
                                }
                                result.Add(identifier, new ($.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)))().$ctor$3(method, parameterTypes));
                            }
                        }
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(98785296491)
            
            //--TRIMMABLE-BOUNDARY-START(64425558123)
            static /*Type[] */ GetParameterTypes(/*MethodInfo*/ method)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425558123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = method.GetParameters();
                if (parameters.length === 0)
                {
                    return $.$$.System.Type.EmptyTypes;
                }
                /*var*/ let parameterTypes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), null, [parameters.length], null);
                for(/*var*/ let i = 0; i < parameters.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(parameterTypes, $.$$.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                }
                return parameterTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(64425558123)
            
            //--TRIMMABLE-BOUNDARY-START(68720525419)
            static /*Assembly */ GetRequiredLoadedAssembly(/*AssemblyKey*/ assemblyKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720525419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Assembly?*/ let assembly = null;
                let $i1 = 0;
                let $arr1 = $.$$.System.AppDomain.CurrentDomain.GetAssemblies();
                while ($i1 < $arr1.length)
                {
                    let a = $arr1[$i1++];
                    if (new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey().$ctor$3(a).Equals$2(assemblyKey))
                    {
                        assembly = a;
                    }
                }
                return $.$firstOf(assembly, () => { throw new $.$$.System.ArgumentException().$ctor$14(`There is no loaded assembly with the name '${assemblyKey.AssemblyName}'.`) });
            }
            //--TRIMMABLE-BOUNDARY-END(68720525419)
            
            //--TRIMMABLE-BOUNDARY-START(1179755)
            static $_MetadataUpdateHandler;
            static get MetadataUpdateHandler()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher;
                return $cls.$_MetadataUpdateHandler ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.MetadataUpdateHandler", ($self) => class MetadataUpdateHandler
                {
                    //--TRIMMABLE-BOUNDARY-START(4296147051)
                    static /*void */ ClearCache(/*Type[]?*/ _)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296147051);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedMethodsByAssembly.Clear();
                        $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedMethodsByType.Clear();
                        $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedConvertToTaskByType.Clear();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296147051)
                    
                    static $h = 1179755;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296147051),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "ClearCache",
      "d": 1179755,
      "h": 4296147051,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296147051)
  ],
  "d": 1048683,
  "h": 1179755
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `DotNetDispatcher.MetadataUpdateHandler`; }
                }, $cls, ($v) => $cls.$_MetadataUpdateHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1179755)
            
            //--TRIMMABLE-BOUNDARY-START(1114219)
            static $_AssemblyKey;
            static get AssemblyKey()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher;
                return $cls.$_AssemblyKey ??= $asm.$nstr("$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey", ($self) => class AssemblyKey extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4296081515)
                    $ctor$3(/*Assembly*/ assembly)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296081515);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Assembly = assembly;
                            this.AssemblyName = assembly.GetName().Name;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296081515)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591048811)
                    $ctor$4(/*string*/ assemblyName)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591048811);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Assembly = null;
                            this.AssemblyName = assemblyName;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591048811)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770917995)
                    /*Assembly?*/ Assembly = null;
                    //--TRIMMABLE-BOUNDARY-END(25770917995)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065885291)
                    /*string*/ AssemblyName = null;
                    //--TRIMMABLE-BOUNDARY-END(30065885291)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360852587)
                    /*bool */ Equals$2(/*AssemblyKey*/ other)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360852587);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if ($.$$.System.Reflection.Assembly.op_Inequality(this.Assembly, null) && $.$$.System.Reflection.Assembly.op_Inequality(other.Assembly, null))
                        {
                            return $.$$.System.Reflection.Assembly.op_Equality(this.Assembly, other.Assembly);
                        }
                        return $.$$.System.String.Equals$4.call(this.AssemblyName, other.AssemblyName, 4/*StringComparison.Ordinal*/);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360852587)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 55835689067, 184683724801)
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(55835689067);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.StringComparer.Ordinal.GetHashCode$2(this.AssemblyName);
                        }
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey.GetHashCode.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 55835689067, 184683724801)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385210369)
                    //Generated interface implemetation for System.IEquatable<Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey>.Equals(Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey)
                    System$IEquatable$$$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385210369);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385210369)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.AssemblyName = this.AssemblyName;
                        return copy;
                    }
                    static $h = 1114219;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770917995),
    {
      "p": 106168321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787179,
        "f": 50331649
      },
      "n": "Assembly",
      "d": 1114219,
      "h": 25770917995,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770917995),
//--TRIMMABLE-BOUNDARY-START(30065885291),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721771,
        "f": 50331649
      },
      "n": "AssemblyName",
      "d": 1114219,
      "h": 30065885291,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065885291)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360852587),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1114219
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1114219,
      "h": 34360852587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360852587),
//--TRIMMABLE-BOUNDARY-START(ALL, 55835689067, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1114219,
      "h": 55835689067,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55835689067, 184683724801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081515),
    {
      "p": [
        {
          "n": "assembly",
          "p": 106168321
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114219,
      "h": 4296081515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081515),
//--TRIMMABLE-BOUNDARY-START(8591048811),
    {
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1114219,
      "h": 8591048811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048811),
//--TRIMMABLE-BOUNDARY-START(12886016107),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114219,
      "h": 12886016107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016107)
  ],
  "i": [$.$$.System.IEquatable$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey).$h
  ],
  "d": 1048683,
  "h": 1114219
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey) ]; }
                    static get $fullName() { return `DotNetDispatcher.AssemblyKey`; }
                }, $cls, ($v) => $cls.$_AssemblyKey = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114219)
            
            //--TRIMMABLE-BOUNDARY-START(21475885163)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(38655754347)
                    this.DisposeDotNetObjectReferenceMethodName = "__Dispose";
                    //--TRIMMABLE-BOUNDARY-END(38655754347)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950721643)
                    this.DotNetObjectRefKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("__dotNetObject", null);
                    //--TRIMMABLE-BOUNDARY-END(42950721643)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590983275)
                    this._cachedMethodsByAssembly = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)))))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8590983275)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885950571)
                    this._cachedMethodsByType = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)))))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(12885950571)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296015979)
                    this._cachedConvertToTaskByType = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Threading.Tasks.Task)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4296015979)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180917867)
                    this._taskConverterMethodInfo = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.$type.GetMethod$9("CreateValueTaskConverter", 32/*BindingFlags.NonPublic*/ | 8/*BindingFlags.Static*/);
                    //--TRIMMABLE-BOUNDARY-END(17180917867)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475885163)
            
            static $h = 1048683;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310460011),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "invocationInfo",
          "p": 1245291,
          "f": 8
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "Invoke",
      "d": 1048683,
      "h": 77310460011,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310460011),
//--TRIMMABLE-BOUNDARY-START(30065819755),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "invocationInfo",
          "p": 1245291
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "BeginInvokeDotNet",
      "d": 1048683,
      "h": 30065819755,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065819755),
//--TRIMMABLE-BOUNDARY-START(47245688939),
    {
      "r": 65537,
      "p": [
        {
          "n": "task",
          "p": 177537025
        },
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "invocationInfo",
          "p": 1245291,
          "f": 8
        }
      ],
      "n": "EndInvokeDotNetAfterTask",
      "d": 1048683,
      "h": 47245688939,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245688939),
//--TRIMMABLE-BOUNDARY-START(81605427307),
    {
      "r": 131073,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "callInfo",
          "p": 1245291,
          "f": 8
        },
        {
          "n": "objectReference",
          "p": 1572971
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "InvokeSynchronously",
      "d": 1048683,
      "h": 81605427307,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81605427307),
//--TRIMMABLE-BOUNDARY-START(90195361899),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": 1310721
        },
        {
          "n": "parameterTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "ParseArguments",
      "d": 1048683,
      "h": 90195361899,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90195361899),
//--TRIMMABLE-BOUNDARY-START(51540656235),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "arguments",
          "p": 1310721
        }
      ],
      "n": "EndInvokeJS",
      "d": 1048683,
      "h": 51540656235,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540656235),
//--TRIMMABLE-BOUNDARY-START(94490329195),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "ReceiveByteArray",
      "d": 1048683,
      "h": 94490329195,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94490329195),
//--TRIMMABLE-BOUNDARY-START(55835623531),
    {
      "r": $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)).$h,
      "p": [
        {
          "n": "assemblyKey",
          "p": 1114219
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        }
      ],
      "n": "GetCachedMethodInfo",
      "d": 1048683,
      "h": 55835623531,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835623531),
//--TRIMMABLE-BOUNDARY-START(73015492715),
    {
      "r": 177537025,
      "p": [
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "GetTaskByType",
      "d": 1048683,
      "h": 73015492715,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73015492715),
//--TRIMMABLE-BOUNDARY-START(34360787051),
    {
      "r": 177537025,
      "p": [
        {
          "n": "result",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateValueTaskConverter",
      "d": 1048683,
      "h": 34360787051,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(34360787051),
//--TRIMMABLE-BOUNDARY-START(60130590827),
    {
      "r": $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)).$h,
      "p": [
        {
          "n": "objectReference",
          "p": 1572971
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        }
      ],
      "n": "GetCachedMethodInfo",
      "o": "@$1",
      "d": 1048683,
      "h": 60130590827,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60130590827),
//--TRIMMABLE-BOUNDARY-START(98785296491),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type))).$h,
      "p": [
        {
          "n": "assemblyKey",
          "p": 1114219
        }
      ],
      "n": "ScanAssemblyForCallableMethods",
      "d": 1048683,
      "h": 98785296491,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98785296491),
//--TRIMMABLE-BOUNDARY-START(64425558123),
    {
      "r": $.$typeArray($.$$.System.Type).$h,
      "p": [
        {
          "n": "method",
          "p": 116719617
        }
      ],
      "n": "GetParameterTypes",
      "d": 1048683,
      "h": 64425558123,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425558123),
//--TRIMMABLE-BOUNDARY-START(68720525419),
    {
      "r": 106168321,
      "p": [
        {
          "n": "assemblyKey",
          "p": 1114219
        }
      ],
      "n": "GetRequiredLoadedAssembly",
      "d": 1048683,
      "h": 68720525419,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720525419)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655754347),
    {
      "t": 1310721,
      "n": "DisposeDotNetObjectReferenceMethodName",
      "d": 1048683,
      "h": 38655754347,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655754347),
//--TRIMMABLE-BOUNDARY-START(42950721643),
    {
      "t": 2293844,
      "n": "DotNetObjectRefKey",
      "d": 1048683,
      "h": 42950721643,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950721643),
//--TRIMMABLE-BOUNDARY-START(8590983275),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)))).$h,
      "n": "_cachedMethodsByAssembly",
      "d": 1048683,
      "h": 8590983275,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590983275),
//--TRIMMABLE-BOUNDARY-START(12885950571),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.ValueTuple$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Type)))).$h,
      "n": "_cachedMethodsByType",
      "d": 1048683,
      "h": 12885950571,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885950571),
//--TRIMMABLE-BOUNDARY-START(4296015979),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Threading.Tasks.Task)).$h,
      "n": "_cachedConvertToTaskByType",
      "d": 1048683,
      "h": 4296015979,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296015979),
//--TRIMMABLE-BOUNDARY-START(17180917867),
    {
      "t": 116719617,
      "n": "_taskConverterMethodInfo",
      "d": 1048683,
      "h": 17180917867,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180917867)
  ],
  "j": [1179755,1114219
  ],
  "h": 1048683
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `DotNetDispatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048683)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966187)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil", ($self) => class TaskGenericsUtil
        {
            //--TRIMMABLE-BOUNDARY-START(4296933483)
            /*ConcurrentDictionary<Type, ITaskResultGetter>*/ static _cachedResultGetters = null;
            //--TRIMMABLE-BOUNDARY-END(4296933483)
            
            //--TRIMMABLE-BOUNDARY-START(8591900779)
            /*ConcurrentDictionary<Type, ITcsResultSetter>*/ static _cachedResultSetters = null;
            //--TRIMMABLE-BOUNDARY-END(8591900779)
            
            //--TRIMMABLE-BOUNDARY-START(47246606443)
            static /*void */ SetTaskCompletionSourceResult(/*object*/ taskCompletionSource, /*object?*/ result)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246606443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetResult(taskCompletionSource, result);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246606443)
            
            //--TRIMMABLE-BOUNDARY-START(42951639147)
            static /*void */ SetTaskCompletionSourceException(/*object*/ taskCompletionSource, /*Exception*/ exception)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951639147);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetException(taskCompletionSource, exception);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951639147)
            
            //--TRIMMABLE-BOUNDARY-START(21476802667)
            static /*Type */ GetTaskCompletionSourceResultType(/*object*/ taskCompletionSource)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476802667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$ResultType;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476802667)
            
            //--TRIMMABLE-BOUNDARY-START(25771769963)
            static /*object? */ GetTaskResult(/*Task*/ task)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let getter = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil._cachedResultGetters.GetOrAdd($.$$.System.Object.GetType.call(task), new ($.$$.System.Func$$$($.$$.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter))().$ctor(this,  (/**/ taskInstanceType) =>
                {
                    /*var*/ let resultType = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.GetTaskResultType(taskInstanceType);
                    return $.$$.System.Type.op_Equality$1(resultType, null) ? new $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.VoidTaskResultGetter().$ctor$1() : $.$cast($.$$.System.Activator.CreateInstance$9($.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TaskResultGetter$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ resultType ], null, null))), $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter);
                }, {
  "r": 2031723,
  "p": [
    {
      "n": "taskInstanceType",
      "p": 187629569
    }
  ],
  "n": "",
  "d": 1966187,
  "h": 0,
  "f": 17825794
}));
                return getter.Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITaskResultGetter$GetResult(task);
            }
            //--TRIMMABLE-BOUNDARY-END(25771769963)
            
            //--TRIMMABLE-BOUNDARY-START(30066737259)
            static /*Type? */ GetTaskResultType(/*Type*/ taskType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while($.$$.System.Type.op_Inequality$1(taskType, $.$$.System.Threading.Tasks.Task.$type) && (!taskType.IsGenericType || $.$$.System.Type.op_Inequality$1(taskType.GetGenericTypeDefinition(), $.$$.System.Threading.Tasks.Task$$().$type)))
                {
                    taskType = $.$firstOf(taskType.BaseType, () => { throw new $.$$.System.ArgumentException().$ctor$14(`The type '${taskType.FullName}' is not inherited from '${$.$$.System.Threading.Tasks.Task.$type.FullName}'.`) });
                }
                return taskType.IsGenericType ? $.$$.System.Array.$ReadT1.call(taskType.GetGenericArguments(), 0) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(30066737259)
            
            //--TRIMMABLE-BOUNDARY-START(2097259)
            static $_ITcsResultSetter;
            static get ITcsResultSetter()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return $cls.$_ITcsResultSetter ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter", ($self) => class ITcsResultSetter
                {
                    static $h = 2097259;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886999147),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592031851,
        "f": 50331905
      },
      "n": "ResultType",
      "o": "Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$ResultType",
      "d": 2097259,
      "h": 12886999147,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886999147)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476933739),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        },
        {
          "n": "result",
          "p": 131073
        }
      ],
      "n": "SetResult",
      "o": "Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetResult",
      "d": 2097259,
      "h": 21476933739,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476933739),
//--TRIMMABLE-BOUNDARY-START(17181966443),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        },
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "SetException",
      "o": "Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetException",
      "d": 2097259,
      "h": 17181966443,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181966443)
  ],
  "d": 1966187,
  "h": 2097259
}; }
                    static get $fullName() { return `TaskGenericsUtil.ITcsResultSetter`; }
                }, $cls, ($v) => $cls.$_ITcsResultSetter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2097259)
            
            //--TRIMMABLE-BOUNDARY-START(2031723)
            static $_ITaskResultGetter;
            static get ITaskResultGetter()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return $cls.$_ITaskResultGetter ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter", ($self) => class ITaskResultGetter
                {
                    static $h = 2031723;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296999019),
    {
      "r": 131073,
      "p": [
        {
          "n": "task",
          "p": 177537025
        }
      ],
      "n": "GetResult",
      "o": "Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITaskResultGetter$GetResult",
      "d": 2031723,
      "h": 4296999019,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296999019)
  ],
  "d": 1966187,
  "h": 2031723
}; }
                    static get $fullName() { return `TaskGenericsUtil.ITaskResultGetter`; }
                }, $cls, ($v) => $cls.$_ITaskResultGetter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2031723)
            
            //--TRIMMABLE-BOUNDARY-START(2162795)
            static $_TaskResultGetter$$;
            static TaskResultGetter$$(T)
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return ($cls.$_TaskResultGetter$$ ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TaskResultGetter<>", (T) => $asm.$gt("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TaskResultGetter<>", [T], ($self) => class TaskResultGetter$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592097387)
                    /*object? */ GetResult(/*Task*/ task)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592097387);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$box($.$box(($.$cast(task, $.$$.System.Threading.Tasks.Task$$(T))).Result, T), T);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592097387)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296999019)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter.GetResult(System.Threading.Tasks.Task)
                    Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITaskResultGetter$GetResult()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296999019);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetResult(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296999019)
                    
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 2162795;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592097387),
    {
      "r": 131073,
      "p": [
        {
          "n": "task",
          "p": 177537025
        }
      ],
      "n": "GetResult",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592097387)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297130091),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297130091)
  ],
  "i": [2031723
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 1966187,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter ]; }
                    static get $fullName() { return `TaskGenericsUtil.TaskResultGetter<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_TaskResultGetter$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(2162795)
            
            //--TRIMMABLE-BOUNDARY-START(2293867)
            static $_VoidTaskResultGetter;
            static get VoidTaskResultGetter()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return $cls.$_VoidTaskResultGetter ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.VoidTaskResultGetter", ($self) => class VoidTaskResultGetter extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592228459)
                    /*object? */ GetResult(/*Task*/ task)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592228459);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        task.Wait();
                        return null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592228459)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296999019)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter.GetResult(System.Threading.Tasks.Task)
                    Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITaskResultGetter$GetResult()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296999019);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetResult(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296999019)
                    
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 2293867;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592228459),
    {
      "r": 131073,
      "p": [
        {
          "n": "task",
          "p": 177537025
        }
      ],
      "n": "GetResult",
      "d": 2293867,
      "h": 8592228459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592228459)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297261163),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2293867,
      "h": 4297261163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297261163)
  ],
  "i": [2031723
  ],
  "d": 1966187,
  "h": 2293867
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter ]; }
                    static get $fullName() { return `TaskGenericsUtil.VoidTaskResultGetter`; }
                }, $cls, ($v) => $cls.$_VoidTaskResultGetter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2293867)
            
            //--TRIMMABLE-BOUNDARY-START(2228331)
            static $_TcsResultSetter$$;
            static TcsResultSetter$$(T)
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return ($cls.$_TcsResultSetter$$ ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TcsResultSetter<>", (T) => $asm.$gt("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TcsResultSetter<>", [T], ($self) => class TcsResultSetter$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17182097515)
                    /*Type */ get ResultType()
                    {
                        return T.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182097515)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772032107)
                    /*void */ SetResult(/*object*/ tcs, /*object?*/ result)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772032107);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let typedTcs = $.$cast(tcs, $.$$.System.Threading.Tasks.TaskCompletionSource$$(T));
                        let resultT;
                        /*var*/ let typedResult = $.$is(result, T, { set $v(v){ resultT = v; } }) ? resultT : result === null && T.$type.IsGenericType && $.$$.System.Type.op_Equality$1(T.$type.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type) ? $.$default(T) : $.$cast($.$$.System.Convert.ChangeType(result, T.$type, $.$$.System.Globalization.CultureInfo.InvariantCulture), T);
                        typedTcs.SetResult(typedResult);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772032107)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477064811)
                    /*void */ SetException(/*object*/ tcs, /*Exception*/ exception)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477064811);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let typedTcs = $.$cast(tcs, $.$$.System.Threading.Tasks.TaskCompletionSource$$(T));
                        typedTcs.SetException$1(exception);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477064811)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592031851)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.ResultType.get
                    get Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$ResultType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886999147);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ResultType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592031851)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476933739)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.SetResult(object, object?)
                    Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetResult()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476933739);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.SetResult(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476933739)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181966443)
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.SetException(object, System.Exception)
                    Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetException()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181966443);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.SetException(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181966443)
                    
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 2228331;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182097515),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331649
      },
      "n": "ResultType",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182097515)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772032107),
    {
      "r": 65537,
      "p": [
        {
          "n": "tcs",
          "p": 131073
        },
        {
          "n": "result",
          "p": 131073
        }
      ],
      "n": "SetResult",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772032107),
//--TRIMMABLE-BOUNDARY-START(21477064811),
    {
      "r": 65537,
      "p": [
        {
          "n": "tcs",
          "p": 131073
        },
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "SetException",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477064811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195627),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297195627)
  ],
  "i": [2097259
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 1966187,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter ]; }
                    static get $fullName() { return `TaskGenericsUtil.TcsResultSetter<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_TcsResultSetter$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(2228331)
            
            //--TRIMMABLE-BOUNDARY-START(17181835371)
            static /*ITcsResultSetter */ CreateResultSetter(/*object*/ taskCompletionSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181835371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil._cachedResultSetters.GetOrAdd($.$$.System.Object.GetType.call(taskCompletionSource), new ($.$$.System.Func$$$($.$$.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter))().$ctor(this,  (/*tcsType*/ tcsType) =>
                {
                    /*var*/ let resultType = $.$$.System.Array.$ReadT1.call(tcsType.GetGenericArguments(), 0);
                    return $.$cast($.$$.System.Activator.CreateInstance$9($.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TcsResultSetter$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ resultType ], null, null))), $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter);
                }, {
  "r": 2097259,
  "p": [
    {
      "n": "tcsType",
      "p": 187629569
    }
  ],
  "n": "",
  "d": 1966187,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(17181835371)
            
            //--TRIMMABLE-BOUNDARY-START(12886868075)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4296933483)
                    this._cachedResultGetters = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4296933483)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591900779)
                    this._cachedResultSetters = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8591900779)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886868075)
            
            static $h = 1966187;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246606443),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        },
        {
          "n": "result",
          "p": 131073
        }
      ],
      "n": "SetTaskCompletionSourceResult",
      "d": 1966187,
      "h": 47246606443,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246606443),
//--TRIMMABLE-BOUNDARY-START(42951639147),
    {
      "r": 65537,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        },
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "SetTaskCompletionSourceException",
      "d": 1966187,
      "h": 42951639147,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951639147),
//--TRIMMABLE-BOUNDARY-START(21476802667),
    {
      "r": 187629569,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        }
      ],
      "n": "GetTaskCompletionSourceResultType",
      "d": 1966187,
      "h": 21476802667,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476802667),
//--TRIMMABLE-BOUNDARY-START(25771769963),
    {
      "r": 131073,
      "p": [
        {
          "n": "task",
          "p": 177537025
        }
      ],
      "n": "GetTaskResult",
      "d": 1966187,
      "h": 25771769963,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771769963),
//--TRIMMABLE-BOUNDARY-START(30066737259),
    {
      "r": 187629569,
      "p": [
        {
          "n": "taskType",
          "p": 187629569
        }
      ],
      "n": "GetTaskResultType",
      "d": 1966187,
      "h": 30066737259,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066737259),
//--TRIMMABLE-BOUNDARY-START(17181835371),
    {
      "r": 2097259,
      "p": [
        {
          "n": "taskCompletionSource",
          "p": 131073
        }
      ],
      "n": "CreateResultSetter",
      "d": 1966187,
      "h": 17181835371,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181835371)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296933483),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter).$h,
      "n": "_cachedResultGetters",
      "d": 1966187,
      "h": 4296933483,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296933483),
//--TRIMMABLE-BOUNDARY-START(8591900779),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter).$h,
      "n": "_cachedResultSetters",
      "d": 1966187,
      "h": 8591900779,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591900779)
  ],
  "j": [2097259,2031723,2162795,2293867,2228331
  ],
  "h": 1966187
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `TaskGenericsUtil`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966187)
        
        
        //--TRIMMABLE-BOUNDARY-START(262251)
        $asm.$cls("$mj.Microsoft.JSInterop.DotNetStreamReference", ($self) => class DotNetStreamReference extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295229547)
            $ctor$1(/*Stream*/ stream, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Stream = $.$firstOf(stream, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("stream") });
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229547)
            
            //--TRIMMABLE-BOUNDARY-START(42949935211)
            /*Stream*/ Stream = null;
            //--TRIMMABLE-BOUNDARY-END(42949935211)
            
            //--TRIMMABLE-BOUNDARY-START(38654967915)
            /*bool*/ LeaveOpen = false;
            //--TRIMMABLE-BOUNDARY-END(38654967915)
            
            //--TRIMMABLE-BOUNDARY-START(17180131435)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.LeaveOpen)
                {
                    this.Stream.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180131435)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 262251;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949935211),
    {
      "p": 94830593,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000619,
        "f": 50331649
      },
      "n": "Stream",
      "d": 262251,
      "h": 42949935211,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949935211),
//--TRIMMABLE-BOUNDARY-START(38654967915),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770066027,
        "f": 50331649
      },
      "n": "LeaveOpen",
      "d": 262251,
      "h": 38654967915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654967915)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131435),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262251,
      "h": 17180131435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131435)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229547),
    {
      "p": [
        {
          "n": "stream",
          "p": 94830593
        },
        {
          "n": "leaveOpen",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262251,
      "h": 4295229547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229547)
  ],
  "i": [90177537
  ],
  "h": 262251
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `DotNetStreamReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262251)
        
        
        //--TRIMMABLE-BOUNDARY-START(917611)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder<>", (T) => $asm.$gt("$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder<>", [T], ($self) => class ArrayBuilder$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885819499)
            /*T[]*/ _items = null;
            //--TRIMMABLE-BOUNDARY-END(12885819499)
            
            //--TRIMMABLE-BOUNDARY-START(17180786795)
            /*int*/ _itemsInUse = 0;
            //--TRIMMABLE-BOUNDARY-END(17180786795)
            
            //--TRIMMABLE-BOUNDARY-START(64425427051)
            /*T[]*/ static Empty = null;
            //--TRIMMABLE-BOUNDARY-END(64425427051)
            
            //--TRIMMABLE-BOUNDARY-START(4295884907)
            /*ArrayPool<T>*/ _arrayPool = null;
            //--TRIMMABLE-BOUNDARY-END(4295884907)
            
            //--TRIMMABLE-BOUNDARY-START(21475754091)
            /*int*/ _minCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(21475754091)
            
            //--TRIMMABLE-BOUNDARY-START(8590852203)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590852203)
            
            //--TRIMMABLE-BOUNDARY-START(30065688683)
            $ctor$1(/*int*/ minCapacity, /*ArrayPool<T>*/ arrayPool)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065688683);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayPool = arrayPool ?? $.$$.System.Buffers.ArrayPool$$(T).Shared;
                    this._minCapacity = minCapacity;
                    this._items = $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065688683)
            
            //--TRIMMABLE-BOUNDARY-START(55835492459)
            /*int */ get Count()
            {
                return this._itemsInUse;
            }
            //--TRIMMABLE-BOUNDARY-END(55835492459)
            
            //--TRIMMABLE-BOUNDARY-START(47245557867)
            /*T[] */ get Buffer()
            {
                return this._items;
            }
            //--TRIMMABLE-BOUNDARY-END(47245557867)
            
            //--TRIMMABLE-BOUNDARY-START(34360655979)
            /*int */ Append$2(/*in T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360655979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._itemsInUse === this._items.length)
                {
                    this.GrowBuffer(((this._items.length * 2) | 0));
                }
                /*var*/ let indexOfAppendedItem = this._itemsInUse++;
                $.$$.System.Array.$WriteT1.call(this._items, item.$v, indexOfAppendedItem);
                return indexOfAppendedItem;
            }
            //--TRIMMABLE-BOUNDARY-END(34360655979)
            
            //--TRIMMABLE-BOUNDARY-START(38655623275)
            /*int */ Append$1(/*T[]*/ source, /*int*/ startIndex, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655623275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Append($.$$.System.Span$$(T).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11(T, source, startIndex, length)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655623275)
            
            //--TRIMMABLE-BOUNDARY-START(42950590571)
            /*int */ Append(/*ReadOnlySpan<T>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let requiredCapacity = ((this._itemsInUse + source.Length) | 0);
                if (this._items.length < requiredCapacity)
                {
                    /*var*/ let candidateCapacity = $.$$.System.Math.Max$4(((this._items.length * 2) | 0), this._minCapacity);
                    while(candidateCapacity < requiredCapacity)
                    {
                        candidateCapacity *= 2;
                    }
                    this.GrowBuffer(candidateCapacity);
                }
                source.CopyTo($.$$.System.MemoryExtensions.AsSpan$12(T, this._items, this._itemsInUse));
                /*var*/ let startIndexOfAppendedItems = this._itemsInUse;
                this._itemsInUse += source.Length;
                return startIndexOfAppendedItems;
            }
            //--TRIMMABLE-BOUNDARY-END(42950590571)
            
            //--TRIMMABLE-BOUNDARY-START(94490198123)
            /*void */ Overwrite(/*int*/ index, /*in T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490198123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index > this._itemsInUse)
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                $.$$.System.Array.$WriteT1.call(this._items, value.$v, index);
            }
            //--TRIMMABLE-BOUNDARY-END(94490198123)
            
            //--TRIMMABLE-BOUNDARY-START(98785165419)
            /*void */ RemoveLast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785165419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._itemsInUse === 0)
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                this._itemsInUse--;
                $.$$.System.Array.$WriteT1.call(this._items, $.$default(T), this._itemsInUse);
            }
            //--TRIMMABLE-BOUNDARY-END(98785165419)
            
            //--TRIMMABLE-BOUNDARY-START(90195230827)
            /*void */ InsertExpensive(/*int*/ index, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195230827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index > this._itemsInUse)
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                if (this._itemsInUse === this._items.length)
                {
                    this.GrowBuffer(((this._items.length * 2) | 0));
                }
                $.$$.System.Array.Copy$2(this._items, index, this._items, ((index + 1) | 0), ((this._itemsInUse - index) | 0));
                this._itemsInUse++;
                $.$$.System.Array.$WriteT1.call(this._items, value, index);
            }
            //--TRIMMABLE-BOUNDARY-END(90195230827)
            
            //--TRIMMABLE-BOUNDARY-START(51540525163)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReturnBuffer();
                this._items = $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).Empty;
                this._itemsInUse = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525163)
            
            //--TRIMMABLE-BOUNDARY-START(85900263531)
            /*void */ GrowBuffer(/*int*/ desiredCapacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900263531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf$1(this._disposed, null);
                /*var*/ let newCapacity = $.$$.System.Math.Max$4(desiredCapacity, this._minCapacity);
                $.$$.System.Diagnostics.Debug.Assert$2(newCapacity > this._items.length, "newCapacity > _items.Length");
                /*var*/ let newItems = this._arrayPool.Rent(newCapacity);
                $.$$.System.Array.Copy(this._items, newItems, this._itemsInUse);
                this.ReturnBuffer();
                this._items = newItems;
            }
            //--TRIMMABLE-BOUNDARY-END(85900263531)
            
            //--TRIMMABLE-BOUNDARY-START(103080132715)
            /*void */ ReturnBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080132715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.Object.ReferenceEquals(this._items, $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).Empty))
                {
                    $.$$.System.Array.Clear(this._items, 0, this._itemsInUse);
                    this._arrayPool.Return(this._items, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080132715)
            
            //--TRIMMABLE-BOUNDARY-START(60130459755)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130459755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    this.ReturnBuffer();
                    this._items = $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).Empty;
                    this._itemsInUse = 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130459755)
            
            //--TRIMMABLE-BOUNDARY-START(107375100011)
            static /*void */ ThrowIndexOutOfBoundsException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375100011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
            }
            //--TRIMMABLE-BOUNDARY-END(107375100011)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //--TRIMMABLE-BOUNDARY-START(25770721387)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(64425427051)
                    this.Empty = $.$$.System.Array.Empty(T);
                    //--TRIMMABLE-BOUNDARY-END(64425427051)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721387)
            
            static $h = 917611;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835492459),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835492459),
//--TRIMMABLE-BOUNDARY-START(47245557867),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Buffer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245557867)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360655979),
    {
      "r": 655361,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 8
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360655979),
//--TRIMMABLE-BOUNDARY-START(38655623275),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38655623275),
//--TRIMMABLE-BOUNDARY-START(42950590571),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        }
      ],
      "n": "Append",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42950590571),
//--TRIMMABLE-BOUNDARY-START(94490198123),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": T?.$h??1507328,
          "f": 8
        }
      ],
      "n": "Overwrite",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490198123),
//--TRIMMABLE-BOUNDARY-START(98785165419),
    {
      "r": 65537,
      "n": "RemoveLast",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785165419),
//--TRIMMABLE-BOUNDARY-START(90195230827),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": T?.$h??1507328
        }
      ],
      "n": "InsertExpensive",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195230827),
//--TRIMMABLE-BOUNDARY-START(51540525163),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540525163),
//--TRIMMABLE-BOUNDARY-START(85900263531),
    {
      "r": 65537,
      "p": [
        {
          "n": "desiredCapacity",
          "p": 655361
        }
      ],
      "n": "GrowBuffer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(85900263531),
//--TRIMMABLE-BOUNDARY-START(103080132715),
    {
      "r": 65537,
      "n": "ReturnBuffer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080132715),
//--TRIMMABLE-BOUNDARY-START(60130459755),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130459755),
//--TRIMMABLE-BOUNDARY-START(107375100011),
    {
      "r": 65537,
      "n": "ThrowIndexOutOfBoundsException",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375100011)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819499),
    {
      "t": $.$typeArray(T).$h,
      "n": "_items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(12885819499),
//--TRIMMABLE-BOUNDARY-START(17180786795),
    {
      "t": 655361,
      "n": "_itemsInUse",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(17180786795),
//--TRIMMABLE-BOUNDARY-START(64425427051),
    {
      "t": $.$typeArray(T).$h,
      "n": "Empty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425427051),
//--TRIMMABLE-BOUNDARY-START(4295884907),
    {
      "t": $.$$.System.Buffers.ArrayPool$$(T).$h,
      "n": "_arrayPool",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884907),
//--TRIMMABLE-BOUNDARY-START(21475754091),
    {
      "t": 655361,
      "n": "_minCapacity",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475754091),
//--TRIMMABLE-BOUNDARY-START(8590852203),
    {
      "t": 262145,
      "n": "_disposed",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065688683),
    {
      "p": [
        {
          "n": "minCapacity",
          "p": 655361,
          "f": 65,
          "v": 32
        },
        {
          "n": "arrayPool",
          "p": $.$$.System.Buffers.ArrayPool$$(T).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688683)
  ],
  "i": [90177537
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `ArrayBuilder<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917611)
        
        
        //--TRIMMABLE-BOUNDARY-START(721003)
        $asm.$cls("$mj.Microsoft.JSInterop.Implementation.JSObjectReference", ($self) => class JSObjectReference extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688299)
            /*JSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4295688299)
            
            //--TRIMMABLE-BOUNDARY-START(25770524779)
            /*bool*/ Disposed = false;
            //--TRIMMABLE-BOUNDARY-END(25770524779)
            
            //--TRIMMABLE-BOUNDARY-START(55835295851)
            /*long*/ Id = 0n;
            //--TRIMMABLE-BOUNDARY-END(55835295851)
            
            //--TRIMMABLE-BOUNDARY-START(8590655595)
            $ctor$1(/*JSRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590655595);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                    this.Id = id;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590655595)
            
            //--TRIMMABLE-BOUNDARY-START(60130263147)
            /*ValueTask<TValue> */ InvokeAsync(TValue, /*string*/ identifier, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync(TValue, this.Id, identifier, 1/*JSCallType.FunctionCall*/, args);
            }
            //--TRIMMABLE-BOUNDARY-END(60130263147)
            
            //--TRIMMABLE-BOUNDARY-START(64425230443)
            /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$1(TValue, this.Id, identifier, 1/*JSCallType.FunctionCall*/, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(64425230443)
            
            //--TRIMMABLE-BOUNDARY-START(68720197739)
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync($.$mj.Microsoft.JSInterop.IJSObjectReference, this.Id, identifier, 2/*JSCallType.ConstructorCall*/, args);
            }
            //--TRIMMABLE-BOUNDARY-END(68720197739)
            
            //--TRIMMABLE-BOUNDARY-START(73015165035)
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$1($.$mj.Microsoft.JSInterop.IJSObjectReference, this.Id, identifier, 2/*JSCallType.ConstructorCall*/, cancellationToken, args);
            }
            //--TRIMMABLE-BOUNDARY-END(73015165035)
            
            //--TRIMMABLE-BOUNDARY-START(47245361259)
            /*ValueTask<TValue> */ GetValueAsync$1(TValue, /*string*/ identifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync(TValue, this.Id, identifier, 3/*JSCallType.GetValue*/, null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245361259)
            
            //--TRIMMABLE-BOUNDARY-START(51540328555)
            /*ValueTask<TValue> */ GetValueAsync(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$1(TValue, this.Id, identifier, 3/*JSCallType.GetValue*/, cancellationToken, null);
            }
            //--TRIMMABLE-BOUNDARY-END(51540328555)
            
            //--TRIMMABLE-BOUNDARY-START(85900066923)
            /*ValueTask *//*async*/  SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900066923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    await this._jsRuntime.InvokeAsync(TValue, this.Id, identifier, 4/*JSCallType.SetValue*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900066923)
            
            //--TRIMMABLE-BOUNDARY-START(90195034219)
            /*ValueTask *//*async*/  SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195034219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    await this._jsRuntime.InvokeAsync$1(TValue, this.Id, identifier, 4/*JSCallType.SetValue*/, cancellationToken, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90195034219)
            
            //--TRIMMABLE-BOUNDARY-START(21475557483)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557483);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.Disposed)
                    {
                        this.Disposed = true;
                        await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this._jsRuntime, "DotNet.disposeJSObjectReferenceById", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(this.Id, $.$$.System.Int64) ], null, null));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475557483)
            
            //--TRIMMABLE-BOUNDARY-START(94490001515)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(94490001515)
            
            //--TRIMMABLE-BOUNDARY-START(12885360747)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeAsync<TValue>(string, object?[]?)
            Microsoft$JSInterop$IJSObjectReference$InvokeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885360747)
            
            //--TRIMMABLE-BOUNDARY-START(17180328043)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeAsync<TValue>(string, System.Threading.CancellationToken, object?[]?)
            Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180328043)
            
            //--TRIMMABLE-BOUNDARY-START(21475295339)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeConstructorAsync(string, object?[]?)
            Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructorAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475295339)
            
            //--TRIMMABLE-BOUNDARY-START(25770262635)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeConstructorAsync(string, System.Threading.CancellationToken, object?[]?)
            Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructorAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770262635)
            
            //--TRIMMABLE-BOUNDARY-START(4295426155)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.GetValueAsync<TValue>(string)
            Microsoft$JSInterop$IJSObjectReference$GetValueAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426155)
            
            //--TRIMMABLE-BOUNDARY-START(8590393451)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.GetValueAsync<TValue>(string, System.Threading.CancellationToken)
            Microsoft$JSInterop$IJSObjectReference$GetValueAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393451)
            
            //--TRIMMABLE-BOUNDARY-START(30065229931)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.SetValueAsync<TValue>(string, TValue)
            Microsoft$JSInterop$IJSObjectReference$SetValueAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValueAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229931)
            
            //--TRIMMABLE-BOUNDARY-START(34360197227)
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.SetValueAsync<TValue>(string, TValue, System.Threading.CancellationToken)
            Microsoft$JSInterop$IJSObjectReference$SetValueAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValueAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360197227)
            
            //--TRIMMABLE-BOUNDARY-START(4384555009)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384555009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384555009)
            
            static $h = 721003;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770524779),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360459371,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605099627,
        "f": 83886088
      },
      "n": "Disposed",
      "d": 721003,
      "h": 25770524779,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25770524779),
//--TRIMMABLE-BOUNDARY-START(55835295851),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950393963,
        "f": 50331664
      },
      "n": "Id",
      "d": 721003,
      "h": 55835295851,
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(55835295851)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130263147),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "d": 721003,
      "h": 60130263147,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(60130263147),
//--TRIMMABLE-BOUNDARY-START(64425230443),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 721003,
      "h": 64425230443,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(64425230443),
//--TRIMMABLE-BOUNDARY-START(68720197739),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "d": 721003,
      "h": 68720197739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720197739),
//--TRIMMABLE-BOUNDARY-START(73015165035),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructorAsync",
      "o": "@$1",
      "d": 721003,
      "h": 73015165035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015165035),
//--TRIMMABLE-BOUNDARY-START(47245361259),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "o": "@$1",
      "d": 721003,
      "h": 47245361259,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(47245361259),
//--TRIMMABLE-BOUNDARY-START(51540328555),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValueAsync",
      "d": 721003,
      "h": 51540328555,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(51540328555),
//--TRIMMABLE-BOUNDARY-START(85900066923),
    {
      "r": 180420609,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "o": "@$1",
      "d": 721003,
      "h": 85900066923,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(85900066923),
//--TRIMMABLE-BOUNDARY-START(90195034219),
    {
      "r": 180420609,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValueAsync",
      "d": 721003,
      "h": 90195034219,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(90195034219),
//--TRIMMABLE-BOUNDARY-START(21475557483),
    {
      "r": 180420609,
      "n": "DisposeAsync",
      "d": 721003,
      "h": 21475557483,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475557483),
//--TRIMMABLE-BOUNDARY-START(94490001515),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 721003,
      "h": 94490001515,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(94490001515)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688299),
    {
      "t": 2949227,
      "n": "_jsRuntime",
      "d": 721003,
      "h": 4295688299,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688299)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590655595),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "id",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721003,
      "h": 8590655595,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(8590655595)
  ],
  "i": [458859,89587713
  ],
  "h": 721003
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `JSObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721003)
        
        
        //--TRIMMABLE-BOUNDARY-START(196715)
        $asm.$cls("$mj.Microsoft.JSInterop.DotNetObjectReference<>", (TValue) => $asm.$gt("$mj.Microsoft.JSInterop.DotNetObjectReference<>", [TValue], ($self) => class DotNetObjectReference$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885098603)
            /*TValue*/ _value = $.$default(TValue);
            //--TRIMMABLE-BOUNDARY-END(12885098603)
            
            //--TRIMMABLE-BOUNDARY-START(8590131307)
            /*long*/ _objectId = 0n;
            //--TRIMMABLE-BOUNDARY-END(8590131307)
            
            //--TRIMMABLE-BOUNDARY-START(4295164011)
            /*JSRuntime?*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4295164011)
            
            //--TRIMMABLE-BOUNDARY-START(17180065899)
            $ctor$1(/*TValue*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065899);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065899)
            
            //--TRIMMABLE-BOUNDARY-START(120259281003)
            /*TValue */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._value;
            }
            //--TRIMMABLE-BOUNDARY-END(120259281003)
            
            //--TRIMMABLE-BOUNDARY-START(85899542635)
            /*long */ get ObjectId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                $.$$.System.Diagnostics.Debug.Assert$2(this._objectId !== 0n, "Accessing ObjectId without tracking is always incorrect.");
                return this._objectId;
            }
            /*long */ set ObjectId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this._objectId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(85899542635)
            
            //--TRIMMABLE-BOUNDARY-START(68719673451)
            /*JSRuntime? */ get JSRuntime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime;
            }
            /*JSRuntime? */ set JSRuntime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079411819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this._jsRuntime = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68719673451)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81604575339, 12886474859)
            /*object */ get Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value()
            {
                return $.$box(this.Value, TValue);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 81604575339, 12886474859)
            
            //--TRIMMABLE-BOUNDARY-START(30064967787)
            /*bool*/ Disposed = false;
            //--TRIMMABLE-BOUNDARY-END(30064967787)
            
            //--TRIMMABLE-BOUNDARY-START(25770000491)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this._jsRuntime?.ReleaseObjectReference(this._objectId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770000491)
            
            //--TRIMMABLE-BOUNDARY-START(115964313707)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(115964313707)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 196715;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(120259281003),
    {
      "p": TValue?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259281003),
//--TRIMMABLE-BOUNDARY-START(85899542635),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 83886088
      },
      "n": "ObjectId",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(85899542635),
//--TRIMMABLE-BOUNDARY-START(68719673451),
    {
      "p": 2949227,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 83886088
      },
      "n": "JSRuntime",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68719673451),
//--TRIMMABLE-BOUNDARY-START(ALL, 81604575339, 12886474859),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331650
      },
      "n": "{1572971}.Value",
      "o": "Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81604575339, 12886474859),
//--TRIMMABLE-BOUNDARY-START(30064967787),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83886082
      },
      "n": "Disposed",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(30064967787)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770000491),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000491),
//--TRIMMABLE-BOUNDARY-START(115964313707),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115964313707)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885098603),
    {
      "t": TValue?.$h??1507328,
      "n": "_value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885098603),
//--TRIMMABLE-BOUNDARY-START(8590131307),
    {
      "t": 917505,
      "n": "_objectId",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131307),
//--TRIMMABLE-BOUNDARY-START(4295164011),
    {
      "t": 2949227,
      "n": "_jsRuntime",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295164011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065899),
    {
      "p": [
        {
          "n": "value",
          "p": TValue?.$h??1507328
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180065899)
  ],
  "i": [1572971,90177537
  ],
  "g": [TValue?.$h??1507328
  ],
  "s": [
    {
      "n": "TValue",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference, $.$$.System.IDisposable ]; }
            static get $fullName() { return `DotNetObjectReference<${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196715)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818155)
        $asm.$cls("$mj.Microsoft.JSInterop.JSInvokableAttribute", ($self) => class JSInvokableAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(25772621931)
            /*string?*/ Identifier = null;
            //--TRIMMABLE-BOUNDARY-END(25772621931)
            
            //--TRIMMABLE-BOUNDARY-START(4297785451)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297785451);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297785451)
            
            //--TRIMMABLE-BOUNDARY-START(8592752747)
            $ctor$3(/*string*/ identifier)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592752747);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentException.ThrowIfNullOrEmpty(identifier, "identifier");
                    this.Identifier = identifier;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592752747)
            
            static $h = 2818155;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772621931),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477654635,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 2818155,
      "h": 25772621931,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772621931)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297785451),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818155,
      "h": 4297785451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297785451),
//--TRIMMABLE-BOUNDARY-START(8592752747),
    {
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2818155,
      "h": 8592752747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592752747)
  ],
  "h": 2818155,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 64,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `JSInvokableAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818155)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769579)
        $asm.$str("$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo", ($self) => class JSInvocationInfo extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296736875)
            /*string?*/  get _argsJson() { return this.$getField(0, 4); }
            /*string?*/  set _argsJson(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296736875)
            
            //--TRIMMABLE-BOUNDARY-START(38656475243)
            /*long*/ AsyncHandle = 0n;
            //--TRIMMABLE-BOUNDARY-END(38656475243)
            
            //--TRIMMABLE-BOUNDARY-START(158915559531)
            /*long*/ TargetInstanceId = 0n;
            //--TRIMMABLE-BOUNDARY-END(158915559531)
            
            //--TRIMMABLE-BOUNDARY-START(98786017387)
            /*string*/ Identifier = null;
            //--TRIMMABLE-BOUNDARY-END(98786017387)
            
            //--TRIMMABLE-BOUNDARY-START(42951442539)
            /*JSCallType*/ CallType = 0;
            //--TRIMMABLE-BOUNDARY-END(42951442539)
            
            //--TRIMMABLE-BOUNDARY-START(103080984683)
            /*JSCallResultType*/ ResultType = 0;
            //--TRIMMABLE-BOUNDARY-END(103080984683)
            
            //--TRIMMABLE-BOUNDARY-START(34361507947)
            /*string */ get ArgsJson()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541377131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._argsJson ?? "[]";
            }
            /*string */ set ArgsJson(value)
            {
                return this._argsJson = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34361507947)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._argsJson = this._argsJson;
                copy.AsyncHandle = this.AsyncHandle;
                copy.TargetInstanceId = this.TargetInstanceId;
                copy.Identifier = this.Identifier;
                copy.CallType = this.CallType;
                copy.ResultType = this.ResultType;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296736875)
                this._argsJson = null;
                //--TRIMMABLE-BOUNDARY-END(4296736875)
                
            }
            static $h = 1769579;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656475243),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131311723,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260853867,
        "f": 83886081
      },
      "n": "AsyncHandle",
      "d": 1769579,
      "h": 38656475243,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656475243),
//--TRIMMABLE-BOUNDARY-START(158915559531),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491050091,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620592235,
        "f": 83886081
      },
      "n": "TargetInstanceId",
      "d": 1769579,
      "h": 158915559531,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158915559531),
//--TRIMMABLE-BOUNDARY-START(98786017387),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311180907,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440723051,
        "f": 83886081
      },
      "n": "Identifier",
      "d": 1769579,
      "h": 98786017387,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786017387),
//--TRIMMABLE-BOUNDARY-START(42951442539),
    {
      "p": 1704043,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721246315,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850788459,
        "f": 83886081
      },
      "n": "CallType",
      "d": 1769579,
      "h": 42951442539,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951442539),
//--TRIMMABLE-BOUNDARY-START(103080984683),
    {
      "p": 2359403,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901115499,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030657643,
        "f": 83886081
      },
      "n": "ResultType",
      "d": 1769579,
      "h": 103080984683,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080984683),
//--TRIMMABLE-BOUNDARY-START(34361507947),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541377131,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670919275,
        "f": 83886081
      },
      "n": "ArgsJson",
      "d": 1769579,
      "h": 34361507947,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361507947)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736875),
    {
      "t": 1310721,
      "n": "_argsJson",
      "d": 1769579,
      "h": 4296736875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591704171),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769579,
      "h": 8591704171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591704171)
  ],
  "h": 1769579
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `JSInvocationInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769579)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310827)
        $asm.$str("$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult", ($self) => class DotNetInvocationResult extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296278123)
            $ctor$3(/*Exception*/ exception, /*string?*/ errorKind)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ResultJson = null;
                    this.Exception = $.$firstOf(exception, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("exception") });
                    this.ErrorKind = errorKind;
                    this.Success = false;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278123)
            
            //--TRIMMABLE-BOUNDARY-START(8591245419)
            $ctor$4(/*string?*/ resultJson)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591245419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ResultJson = resultJson;
                    this.Exception = null;
                    this.ErrorKind = null;
                    this.Success = true;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245419)
            
            //--TRIMMABLE-BOUNDARY-START(38656016491)
            /*Exception?*/ Exception = null;
            //--TRIMMABLE-BOUNDARY-END(38656016491)
            
            //--TRIMMABLE-BOUNDARY-START(34361049195)
            /*string?*/ ErrorKind = null;
            //--TRIMMABLE-BOUNDARY-END(34361049195)
            
            //--TRIMMABLE-BOUNDARY-START(77310722155)
            /*string?*/ ResultJson = null;
            //--TRIMMABLE-BOUNDARY-END(77310722155)
            
            //--TRIMMABLE-BOUNDARY-START(81605689451)
            /*bool*/ Success = false;
            //--TRIMMABLE-BOUNDARY-END(81605689451)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Exception = this.Exception;
                copy.ErrorKind = this.ErrorKind;
                copy.ResultJson = this.ResultJson;
                copy.Success = this.Success;
                return copy;
            }
            static $h = 1310827;
            static $z = 13;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656016491),
    {
      "p": 79888385,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835885675,
        "f": 50331649
      },
      "n": "Exception",
      "d": 1310827,
      "h": 38656016491,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656016491),
//--TRIMMABLE-BOUNDARY-START(34361049195),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245951083,
        "f": 50331649
      },
      "n": "ErrorKind",
      "d": 1310827,
      "h": 34361049195,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361049195),
//--TRIMMABLE-BOUNDARY-START(77310722155),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425820267,
        "f": 50331649
      },
      "n": "ResultJson",
      "d": 1310827,
      "h": 77310722155,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310722155),
//--TRIMMABLE-BOUNDARY-START(81605689451),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015754859,
        "f": 50331649
      },
      "n": "Success",
      "d": 1310827,
      "h": 81605689451,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605689451)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278123),
    {
      "p": [
        {
          "n": "exception",
          "p": 79888385
        },
        {
          "n": "errorKind",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310827,
      "h": 4296278123,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296278123),
//--TRIMMABLE-BOUNDARY-START(8591245419),
    {
      "p": [
        {
          "n": "resultJson",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1310827,
      "h": 8591245419,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591245419),
//--TRIMMABLE-BOUNDARY-START(12886212715),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310827,
      "h": 12886212715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886212715)
  ],
  "h": 1310827
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `DotNetInvocationResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310827)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245291)
        $asm.$str("$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo", ($self) => class DotNetInvocationInfo extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296212587)
            $ctor$3(/*string?*/ assemblyName, /*string*/ methodIdentifier, /*long*/ dotNetObjectId, /*string?*/ callId)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296212587);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CallId = callId;
                    this.AssemblyName = assemblyName;
                    this.MethodIdentifier = methodIdentifier;
                    this.DotNetObjectId = dotNetObjectId;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212587)
            
            //--TRIMMABLE-BOUNDARY-START(30066016363)
            /*string?*/ AssemblyName = null;
            //--TRIMMABLE-BOUNDARY-END(30066016363)
            
            //--TRIMMABLE-BOUNDARY-START(77310656619)
            /*string*/ MethodIdentifier = null;
            //--TRIMMABLE-BOUNDARY-END(77310656619)
            
            //--TRIMMABLE-BOUNDARY-START(38655950955)
            /*long*/ DotNetObjectId = 0n;
            //--TRIMMABLE-BOUNDARY-END(38655950955)
            
            //--TRIMMABLE-BOUNDARY-START(34360983659)
            /*string?*/ CallId = null;
            //--TRIMMABLE-BOUNDARY-END(34360983659)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.AssemblyName = this.AssemblyName;
                copy.MethodIdentifier = this.MethodIdentifier;
                copy.DotNetObjectId = this.DotNetObjectId;
                copy.CallId = this.CallId;
                return copy;
            }
            static $h = 1245291;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066016363),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245885547,
        "f": 50331649
      },
      "n": "AssemblyName",
      "d": 1245291,
      "h": 30066016363,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066016363),
//--TRIMMABLE-BOUNDARY-START(77310656619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015689323,
        "f": 50331649
      },
      "n": "MethodIdentifier",
      "d": 1245291,
      "h": 77310656619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310656619),
//--TRIMMABLE-BOUNDARY-START(38655950955),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425754731,
        "f": 50331649
      },
      "n": "DotNetObjectId",
      "d": 1245291,
      "h": 38655950955,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655950955),
//--TRIMMABLE-BOUNDARY-START(34360983659),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835820139,
        "f": 50331649
      },
      "n": "CallId",
      "d": 1245291,
      "h": 34360983659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360983659)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212587),
    {
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "dotNetObjectId",
          "p": 917505
        },
        {
          "n": "callId",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245291,
      "h": 4296212587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212587),
//--TRIMMABLE-BOUNDARY-START(8591179883),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245291,
      "h": 8591179883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179883)
  ],
  "h": 1245291
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `DotNetInvocationInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245291)
        
        
        //--TRIMMABLE-BOUNDARY-START(983147)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter", ($self) => class ByteArrayJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$typeArray($.$$.System.Byte))
        {
            //--TRIMMABLE-BOUNDARY-START(4295950443)
            /*int*/ _byteArrayId = 0;
            //--TRIMMABLE-BOUNDARY-END(4295950443)
            
            //--TRIMMABLE-BOUNDARY-START(21475819627)
            /*JsonEncodedText*/ static ByteArrayRefKey;
            //--TRIMMABLE-BOUNDARY-END(21475819627)
            
            //--TRIMMABLE-BOUNDARY-START(12885885035)
            $ctor$3(/*JSRuntime*/ jSRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885885035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JSRuntime = jSRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885885035)
            
            //--TRIMMABLE-BOUNDARY-START(34360721515)
            /*JSRuntime*/ JSRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(34360721515)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38655688811, 77322977364)
            /*byte[]? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bytes;
                if (reader.$v.TokenType === 7/*JsonTokenType.String*/ && reader.$v.TryGetBytesFromBase64($.$ref(() => bytes, ($v) => bytes = $v, $.$typeArray($.$$.System.Byte))))
                {
                    return bytes;
                }
                if (this.JSRuntime.ByteArraysToBeRevived.Count === 0)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10("JSON serialization is attempting to deserialize an unexpected byte array.");
                }
                /*int*/ let byteArrayRef;
                if (reader.$v.TokenType !== 1/*JsonTokenType.StartObject*/)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON Token ${reader.$v.TokenType}, expected 'StartObject'.`);
                }
                if (reader.$v.Read() && reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                {
                    if (!reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter.ByteArrayRefKey.EncodedUtf8Bytes))
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON Property ${reader.$v.GetString()}.`);
                    }
                    else if (!reader.$v.Read() || reader.$v.TokenType !== 8/*JsonTokenType.Number*/)
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON Token ${reader.$v.TokenType}, expected 'Number'.`);
                    }
                    else if (!reader.$v.TryGetInt32($.$ref(() => byteArrayRef, ($v) => byteArrayRef = $v, $.$$.System.Int32)))
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected number, expected 32-bit integer.`);
                    }
                }
                else 
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON Token ${reader.$v.TokenType}, expected 'PropertyName'.`);
                }
                if (reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON Token ${reader.$v.TokenType}, expected 'EndObject'.`);
                }
                if (byteArrayRef >= this.JSRuntime.ByteArraysToBeRevived.Count || byteArrayRef < 0)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Byte array ${byteArrayRef} not found.`);
                }
                /*var*/ let byteArray = $.$$.System.Array.$ReadT1.call(this.JSRuntime.ByteArraysToBeRevived.Buffer, byteArrayRef);
                return byteArray;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38655688811, 77322977364)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42950656107, 150337421396)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*byte[]*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = ++this._byteArrayId;
                this.JSRuntime.SendByteArray(id, value);
                writer.WriteStartObject();
                writer.WriteNumber$25($.$mj.Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter.ByteArrayRefKey, id);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42950656107, 150337421396)
            
            //--TRIMMABLE-BOUNDARY-START(8590917739)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21475819627)
                    this.ByteArrayRefKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("__byte[]", null);
                    //--TRIMMABLE-BOUNDARY-END(21475819627)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590917739)
            
            static $h = 983147;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360721515),
    {
      "p": 2949227,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065754219,
        "f": 50331649
      },
      "n": "JSRuntime",
      "d": 983147,
      "h": 34360721515,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360721515)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 38655688811, 77322977364),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 983147,
      "h": 38655688811,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38655688811, 77322977364),
//--TRIMMABLE-BOUNDARY-START(ALL, 42950656107, 150337421396),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 983147,
      "h": 42950656107,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42950656107, 150337421396)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950443),
    {
      "t": 655361,
      "n": "_byteArrayId",
      "d": 983147,
      "h": 4295950443,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950443),
//--TRIMMABLE-BOUNDARY-START(21475819627),
    {
      "t": 2293844,
      "n": "ByteArrayRefKey",
      "d": 983147,
      "h": 21475819627,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475819627)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885885035),
    {
      "p": [
        {
          "n": "jSRuntime",
          "p": 2949227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 983147,
      "h": 12885885035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885885035)
  ],
  "h": 983147
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$typeArray($.$$.System.Byte)); }
            static get $fullName() { return `ByteArrayJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983147)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441899)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverterFactory", ($self) => class DotNetObjectReferenceJsonConverterFactory extends $.$stj.System.Text.Json.Serialization.JsonConverterFactory
        {
            //--TRIMMABLE-BOUNDARY-START(4296409195)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296409195);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409195)
            
            //--TRIMMABLE-BOUNDARY-START(30066212971)
            /*JSRuntime*/ JSRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(30066212971)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886343787, 68732977236)
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return typeToConvert.IsGenericType && $.$$.System.Type.op_Equality$1(typeToConvert.GetGenericTypeDefinition(), $.$mj.Microsoft.JSInterop.DotNetObjectReference$$().$type);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886343787, 68732977236)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181311083, 8603631700)
            /*JsonConverter */ CreateConverter(/*Type*/ typeToConvert, /*JsonSerializerOptions*/ jsonSerializerOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181311083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let instanceType = $.$$.System.Array.$ReadT1.call(typeToConvert.GetGenericArguments(), 0);
                /*var*/ let converterType = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ instanceType ], null, null));
                return $.$cast($.$$.System.Activator.CreateInstance$6(converterType, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this.JSRuntime ], null, null)), $.$stj.System.Text.Json.Serialization.JsonConverter);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181311083, 8603631700)
            
            static $h = 1441899;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 13697108,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066212971),
    {
      "p": 2949227,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771245675,
        "f": 50331649
      },
      "n": "JSRuntime",
      "d": 1441899,
      "h": 30066212971,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066212971)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12886343787, 68732977236),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeToConvert",
          "p": 187629569
        }
      ],
      "n": "CanConvert",
      "d": 1441899,
      "h": 12886343787,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886343787, 68732977236),
//--TRIMMABLE-BOUNDARY-START(ALL, 17181311083, 8603631700),
    {
      "r": 13500500,
      "p": [
        {
          "n": "typeToConvert",
          "p": 187629569
        },
        {
          "n": "jsonSerializerOptions",
          "p": 3342420
        }
      ],
      "n": "CreateConverter",
      "d": 1441899,
      "h": 17181311083,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181311083, 8603631700)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409195),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441899,
      "h": 4296409195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409195)
  ],
  "h": 1441899
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverterFactory; }
            static get $fullName() { return `DotNetObjectReferenceJsonConverterFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441899)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835115)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.JSObjectReferenceJsonConverter", ($self) => class JSObjectReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSObjectReference)
        {
            //--TRIMMABLE-BOUNDARY-START(4296802411)
            /*JSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4296802411)
            
            //--TRIMMABLE-BOUNDARY-START(8591769707)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591769707);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591769707)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886737003, 68732977236)
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886737003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.IJSObjectReference.$type) || $.$$.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference.$type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886737003, 68732977236)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181704299, 77322977364)
            /*IJSObjectReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181704299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.ReadJSObjectReferenceIdentifier(reader);
                if (id === BigInt(-1))
                {
                    return null;
                }
                return new $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference().$ctor$1(this._jsRuntime, id);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181704299, 77322977364)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21476671595, 150337421396)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSObjectReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476671595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21476671595, 150337421396)
            
            static $h = 1835115;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12886737003, 68732977236),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeToConvert",
          "p": 187629569
        }
      ],
      "n": "CanConvert",
      "d": 1835115,
      "h": 12886737003,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886737003, 68732977236),
//--TRIMMABLE-BOUNDARY-START(ALL, 17181704299, 77322977364),
    {
      "r": 458859,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 1835115,
      "h": 17181704299,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181704299, 77322977364),
//--TRIMMABLE-BOUNDARY-START(ALL, 21476671595, 150337421396),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 458859
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 1835115,
      "h": 21476671595,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21476671595, 150337421396)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296802411),
    {
      "t": 2949227,
      "n": "_jsRuntime",
      "d": 1835115,
      "h": 4296802411,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296802411)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591769707),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835115,
      "h": 8591769707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591769707)
  ],
  "h": 1835115
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSObjectReference); }
            static get $fullName() { return `JSObjectReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835115)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900651)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter", ($self) => class JSStreamReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSStreamReference)
        {
            //--TRIMMABLE-BOUNDARY-START(8591835243)
            /*JsonEncodedText*/ static _jsStreamReferenceLengthKey;
            //--TRIMMABLE-BOUNDARY-END(8591835243)
            
            //--TRIMMABLE-BOUNDARY-START(4296867947)
            /*JSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4296867947)
            
            //--TRIMMABLE-BOUNDARY-START(17181769835)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181769835);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181769835)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21476737131, 68732977236)
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476737131);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.IJSStreamReference.$type) || $.$$.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.Implementation.JSStreamReference.$type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21476737131, 68732977236)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25771704427, 77322977364)
            /*IJSStreamReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771704427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long?*/ let id = null;
                /*long?*/ let length = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (id === null && reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetInt64();
                        }
                        else if (length === null && reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter._jsStreamReferenceLengthKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            length = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON property ${reader.$v.GetString()}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON token ${reader.$v.TokenType}`);
                    }
                }
                if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(id))
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Required property ${$.$stj.System.Text.Json.JsonEncodedText.ToString.call($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey)} not found.`);
                }
                if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(length))
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Required property ${$.$stj.System.Text.Json.JsonEncodedText.ToString.call($.$mj.Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter._jsStreamReferenceLengthKey)} not found.`);
                }
                return new $.$mj.Microsoft.JSInterop.Implementation.JSStreamReference().$ctor$2(this._jsRuntime, $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(id), $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(length));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25771704427, 77322977364)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30066671723, 150337421396)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSStreamReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066671723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.Microsoft.JSInterop.Implementation.JSStreamReference));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30066671723, 150337421396)
            
            //--TRIMMABLE-BOUNDARY-START(12886802539)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8591835243)
                    this._jsStreamReferenceLengthKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("__jsStreamReferenceLength", null);
                    //--TRIMMABLE-BOUNDARY-END(8591835243)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886802539)
            
            static $h = 1900651;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 21476737131, 68732977236),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeToConvert",
          "p": 187629569
        }
      ],
      "n": "CanConvert",
      "d": 1900651,
      "h": 21476737131,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21476737131, 68732977236),
//--TRIMMABLE-BOUNDARY-START(ALL, 25771704427, 77322977364),
    {
      "r": 589931,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 1900651,
      "h": 25771704427,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771704427, 77322977364),
//--TRIMMABLE-BOUNDARY-START(ALL, 30066671723, 150337421396),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 589931
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 1900651,
      "h": 30066671723,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066671723, 150337421396)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591835243),
    {
      "t": 2293844,
      "n": "_jsStreamReferenceLengthKey",
      "d": 1900651,
      "h": 8591835243,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591835243),
//--TRIMMABLE-BOUNDARY-START(4296867947),
    {
      "t": 2949227,
      "n": "_jsRuntime",
      "d": 1900651,
      "h": 4296867947,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867947)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181769835),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1900651,
      "h": 17181769835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769835)
  ],
  "h": 1900651
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSStreamReference); }
            static get $fullName() { return `JSStreamReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900651)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359403)
        $asm.$str("$mj.Microsoft.JSInterop.JSCallResultType", ($self) => class JSCallResultType extends $.$$.System.Enum
        {
            static Default = 0;
            static JSObjectReference = 1;
            static JSStreamReference = 2;
            static JSVoidResult = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2359403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "JSObjectReference": 1n,
                    "JSStreamReference": 2n,
                    "JSVoidResult": 3n
                };
            }
            static $h = 2359403;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592293995),
    {
      "t": 2359403,
      "n": "Default",
      "d": 2359403,
      "h": 8592293995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592293995),
//--TRIMMABLE-BOUNDARY-START(12887261291),
    {
      "t": 2359403,
      "n": "JSObjectReference",
      "d": 2359403,
      "h": 12887261291,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887261291),
//--TRIMMABLE-BOUNDARY-START(17182228587),
    {
      "t": 2359403,
      "n": "JSStreamReference",
      "d": 2359403,
      "h": 17182228587,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182228587),
//--TRIMMABLE-BOUNDARY-START(21477195883),
    {
      "t": 2359403,
      "n": "JSVoidResult",
      "d": 2359403,
      "h": 21477195883,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477195883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326699),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2359403,
      "h": 4297326699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297326699)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 2359403
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `JSCallResultType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359403)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704043)
        $asm.$str("$mj.Microsoft.JSInterop.Infrastructure.JSCallType", ($self) => class JSCallType extends $.$$.System.Enum
        {
            static FunctionCall = 1;
            static ConstructorCall = 2;
            static GetValue = 3;
            static SetValue = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1704043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FunctionCall": 1n,
                    "ConstructorCall": 2n,
                    "GetValue": 3n,
                    "SetValue": 4n
                };
            }
            static $h = 1704043;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886605931),
    {
      "t": 1704043,
      "n": "FunctionCall",
      "d": 1704043,
      "h": 12886605931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886605931),
//--TRIMMABLE-BOUNDARY-START(8591638635),
    {
      "t": 1704043,
      "n": "ConstructorCall",
      "d": 1704043,
      "h": 8591638635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591638635),
//--TRIMMABLE-BOUNDARY-START(17181573227),
    {
      "t": 1704043,
      "n": "GetValue",
      "o": "@$1",
      "d": 1704043,
      "h": 17181573227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181573227),
//--TRIMMABLE-BOUNDARY-START(21476540523),
    {
      "t": 1704043,
      "n": "SetValue",
      "d": 1704043,
      "h": 21476540523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476540523)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671339),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704043,
      "h": 4296671339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671339)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1704043
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `JSCallType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704043)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507435)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.DotNetStreamReferenceJsonConverter", ($self) => class DotNetStreamReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.DotNetStreamReference)
        {
            //--TRIMMABLE-BOUNDARY-START(17181376619)
            /*JsonEncodedText*/ static DotNetStreamRefKey;
            //--TRIMMABLE-BOUNDARY-END(17181376619)
            
            //--TRIMMABLE-BOUNDARY-START(8591442027)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591442027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591442027)
            
            //--TRIMMABLE-BOUNDARY-START(30066278507)
            /*JSRuntime*/ JSRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(30066278507)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34361245803, 77322977364)
            /*DotNetStreamReference */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361245803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$12(`${"DotNetStreamReference"} cannot be supplied from JavaScript to .NET because the stream contents have already been transferred.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34361245803, 77322977364)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38656213099, 150337421396)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*DotNetStreamReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = this.JSRuntime.BeginTransmittingStream(value);
                writer.WriteStartObject();
                writer.WriteNumber$26($.$mj.Microsoft.JSInterop.Infrastructure.DotNetStreamReferenceJsonConverter.DotNetStreamRefKey, id);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38656213099, 150337421396)
            
            //--TRIMMABLE-BOUNDARY-START(4296474731)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17181376619)
                    this.DotNetStreamRefKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("__dotNetStream", null);
                    //--TRIMMABLE-BOUNDARY-END(17181376619)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296474731)
            
            static $h = 1507435;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066278507),
    {
      "p": 2949227,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771311211,
        "f": 50331649
      },
      "n": "JSRuntime",
      "d": 1507435,
      "h": 30066278507,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066278507)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 34361245803, 77322977364),
    {
      "r": 262251,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 1507435,
      "h": 34361245803,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34361245803, 77322977364),
//--TRIMMABLE-BOUNDARY-START(ALL, 38656213099, 150337421396),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 262251
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 1507435,
      "h": 38656213099,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38656213099, 150337421396)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181376619),
    {
      "t": 2293844,
      "n": "DotNetStreamRefKey",
      "d": 1507435,
      "h": 17181376619,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181376619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591442027),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507435,
      "h": 8591442027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591442027)
  ],
  "h": 1507435
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.DotNetStreamReference); }
            static get $fullName() { return `DotNetStreamReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507435)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376363)
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter<>", (TValue) => $asm.$gt("$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter<>", [TValue], ($self) => class DotNetObjectReferenceJsonConverter$$ extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue))
        {
            //--TRIMMABLE-BOUNDARY-START(4296343659)
            $ctor$3(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296343659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343659)
            
            //--TRIMMABLE-BOUNDARY-START(12886278251)
            static /*JsonEncodedText */ get DotNetObjectRefKey()
            {
                return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.DotNetObjectRefKey;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278251)
            
            //--TRIMMABLE-BOUNDARY-START(34361114731)
            /*JSRuntime*/ JSRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(34361114731)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38656082027, 77322977364)
            /*DotNetObjectReference<TValue> */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656082027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let dotNetObjectId = 0n;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (dotNetObjectId === 0n && reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            dotNetObjectId = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON property ${reader.$v.GetString()}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON Token ${reader.$v.TokenType}.`);
                    }
                }
                if (dotNetObjectId === 0n)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Required property ${$.$stj.System.Text.Json.JsonEncodedText.ToString.call($.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey)} not found.`);
                }
                /*var*/ let value = $.$cast(this.JSRuntime.GetObjectReference(dotNetObjectId), $.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue));
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38656082027, 77322977364)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42951049323, 150337421396)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*DotNetObjectReference<TValue>*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951049323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let objectId = this.JSRuntime.TrackObjectReference(TValue, value);
                writer.WriteStartObject();
                writer.WriteNumber$26($.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey, objectId);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42951049323, 150337421396)
            
            static $h = 1376363;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886278251),
    {
      "p": 2293844,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331682
      },
      "n": "DotNetObjectRefKey",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(12886278251),
//--TRIMMABLE-BOUNDARY-START(34361114731),
    {
      "p": 2949227,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "JSRuntime",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361114731)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 38656082027, 77322977364),
    {
      "r": $.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue).$h,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38656082027, 77322977364),
//--TRIMMABLE-BOUNDARY-START(ALL, 42951049323, 150337421396),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue).$h
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42951049323, 150337421396)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343659),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343659)
  ],
  "g": [TValue?.$h??1507328
  ],
  "s": [
    {
      "n": "TValue",
      "f": 1
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue)); }
            static get $fullName() { return `DotNetObjectReferenceJsonConverter<${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1376363)
        
        
        //--TRIMMABLE-BOUNDARY-START(852075)
        $asm.$cls("$mj.Microsoft.JSInterop.Implementation.JSStreamReference", ($self) => class JSStreamReference extends $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(4295819371)
            /*JSRuntime*/ _jsRuntime$1 = null;
            //--TRIMMABLE-BOUNDARY-END(4295819371)
            
            //--TRIMMABLE-BOUNDARY-START(25770655851)
            /*long*/ Length = 0n;
            //--TRIMMABLE-BOUNDARY-END(25770655851)
            
            //--TRIMMABLE-BOUNDARY-START(8590786667)
            $ctor$2(/*JSRuntime*/ jsRuntime, /*long*/ id, /*long*/ totalLength)
            {
                super.$ctor$1(jsRuntime, id);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590786667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (totalLength <= 0n)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("totalLength", $.$box(totalLength, $.$$.System.Int64), "Length must be a positive value.");
                    }
                    this._jsRuntime$1 = jsRuntime;
                    this.Length = totalLength;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786667)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30065623147, 17180459115)
            /*ValueTask<Stream> *//*async*/  Microsoft$JSInterop$IJSStreamReference$OpenReadStreamAsync(/*long*/ maxAllowedSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream), $.$$.System.IO.Stream, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065623147);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Length > maxAllowedSize)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("maxAllowedSize", `The incoming data stream of length ${this.Length} exceeds the maximum allowed length ${maxAllowedSize}.`);
                    }
                    return await this._jsRuntime$1.ReadJSDataAsStreamAsync(this, this.Length, cancellationToken);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30065623147, 17180459115)
            
            //--TRIMMABLE-BOUNDARY-START(8590524523)
            //Generated interface implemetation for Microsoft.JSInterop.IJSStreamReference.Length.get
            get Microsoft$JSInterop$IJSStreamReference$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524523)
            
            static $h = 852075;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 721003,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770655851),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475688555,
        "f": 50331649
      },
      "n": "Length",
      "d": 852075,
      "h": 25770655851,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770655851)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819371),
    {
      "t": 2949227,
      "n": "_jsRuntime",
      "o": "@$1",
      "d": 852075,
      "h": 4295819371,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819371)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786667),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2949227
        },
        {
          "n": "id",
          "p": 917505
        },
        {
          "n": "totalLength",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852075,
      "h": 8590786667,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590786667)
  ],
  "i": [458859,589931,89587713
  ],
  "h": 852075
}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$mj.Microsoft.JSInterop.IJSStreamReference, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `JSStreamReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852075)
        
        
        //--TRIMMABLE-BOUNDARY-START(655467)
        $asm.$cls("$mj.Microsoft.JSInterop.Implementation.JSInProcessObjectReference", ($self) => class JSInProcessObjectReference extends $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference
        {
            //--TRIMMABLE-BOUNDARY-START(4295622763)
            /*JSInProcessRuntime*/ _jsRuntime$1 = null;
            //--TRIMMABLE-BOUNDARY-END(4295622763)
            
            //--TRIMMABLE-BOUNDARY-START(8590590059)
            $ctor$2(/*JSInProcessRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor$1(jsRuntime, id);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime$1 = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590059)
            
            //--TRIMMABLE-BOUNDARY-START(25770459243)
            /*TValue */ Invoke(TValue, /*string*/ identifier, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime$1.Invoke(TValue, identifier, this.Id, 1/*JSCallType.FunctionCall*/, args);
            }
            //--TRIMMABLE-BOUNDARY-END(25770459243)
            
            //--TRIMMABLE-BOUNDARY-START(30065426539)
            /*IJSInProcessObjectReference */ InvokeConstructor(/*string*/ identifier, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime$1.Invoke($.$mj.Microsoft.JSInterop.IJSInProcessObjectReference, identifier, this.Id, 2/*JSCallType.ConstructorCall*/, args);
            }
            //--TRIMMABLE-BOUNDARY-END(30065426539)
            
            //--TRIMMABLE-BOUNDARY-START(21475491947)
            /*TValue */ GetValue(TValue, /*string*/ identifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                return this._jsRuntime$1.Invoke(TValue, identifier, this.Id, 3/*JSCallType.GetValue*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475491947)
            
            //--TRIMMABLE-BOUNDARY-START(34360393835)
            /*void */ SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this._jsRuntime$1.Invoke(TValue, identifier, this.Id, 4/*JSCallType.SetValue*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(value, TValue) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34360393835)
            
            //--TRIMMABLE-BOUNDARY-START(12885557355)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    globalThis.DotNet.disposeJSObjectReferenceById(this.Id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885557355)
            
            //--TRIMMABLE-BOUNDARY-START(8590262379)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.Invoke<TValue>(string, params object?[]?)
            Microsoft$JSInterop$IJSInProcessObjectReference$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262379)
            
            //--TRIMMABLE-BOUNDARY-START(12885229675)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.InvokeConstructor(string, object?[]?)
            Microsoft$JSInterop$IJSInProcessObjectReference$InvokeConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeConstructor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229675)
            
            //--TRIMMABLE-BOUNDARY-START(4295295083)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.GetValue<TValue>(string)
            Microsoft$JSInterop$IJSInProcessObjectReference$GetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295083)
            
            //--TRIMMABLE-BOUNDARY-START(17180196971)
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.SetValue<TValue>(string, TValue)
            Microsoft$JSInterop$IJSInProcessObjectReference$SetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180196971)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 655467;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 721003,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770459243),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "Invoke",
      "d": 655467,
      "h": 25770459243,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(25770459243),
//--TRIMMABLE-BOUNDARY-START(30065426539),
    {
      "r": 327787,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "InvokeConstructor",
      "d": 655467,
      "h": 30065426539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065426539),
//--TRIMMABLE-BOUNDARY-START(21475491947),
    {
      "r": (TValue) => TValue.$h,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetValue",
      "d": 655467,
      "h": 21475491947,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(21475491947),
//--TRIMMABLE-BOUNDARY-START(34360393835),
    {
      "r": 65537,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "SetValue",
      "d": 655467,
      "h": 34360393835,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(34360393835),
//--TRIMMABLE-BOUNDARY-START(12885557355),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 655467,
      "h": 12885557355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557355)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622763),
    {
      "t": 2687083,
      "n": "_jsRuntime",
      "o": "@$1",
      "d": 655467,
      "h": 4295622763,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622763)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590059),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 2687083
        },
        {
          "n": "id",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655467,
      "h": 8590590059,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(8590590059)
  ],
  "i": [327787,458859,89587713,90177537
  ],
  "h": 655467
}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference, $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$$.System.IAsyncDisposable, $.$$.System.IDisposable ]; }
            static get $fullName() { return `JSInProcessObjectReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655467)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490475)
        $asm.$cls("$mj.Microsoft.JSInterop.JSDisconnectedException", ($self) => class JSDisconnectedException extends $.$$.System.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4297457771)
            $ctor$5(/*string*/ message)
            {
                super.$ctor$4(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297457771);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297457771)
            
            static $h = 2490475;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79888385,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457771),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2490475,
      "h": 4297457771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297457771)
  ],
  "i": [157351937
  ],
  "h": 2490475
}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `JSDisconnectedException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490475)
        
        
        //--TRIMMABLE-BOUNDARY-START(2556011)
        $asm.$cls("$mj.Microsoft.JSInterop.JSException", ($self) => class JSException extends $.$$.System.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4297523307)
            $ctor$6(/*string*/ message)
            {
                super.$ctor$4(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297523307);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297523307)
            
            //--TRIMMABLE-BOUNDARY-START(8592490603)
            $ctor$5(/*string*/ message, /*Exception*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592490603);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592490603)
            
            static $h = 2556011;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79888385,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297523307),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2556011,
      "h": 4297523307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297523307),
//--TRIMMABLE-BOUNDARY-START(8592490603),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "innerException",
          "p": 79888385
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2556011,
      "h": 8592490603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592490603)
  ],
  "i": [157351937
  ],
  "h": 2556011
}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `JSException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2556011)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.IO.Pipelines", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.RegularExpressions", "NetJs.System.Text.Json"))
//--TRIMMABLE-BOUNDARY-END(107)
