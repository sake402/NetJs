
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $sipl, $srn, $ssc, $stew, $sris, $stc, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $srij, $sicb, $sci, $sdd, $srm, $snnr, $sds, $sre, $sns, $sscr, $str, $snn, $snsc, $stj, $snq, $snh) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.JSInterop", 
    {"h":30,"f":"Microsoft.JSInterop","v":"1.0.35.0","a":[{"t":78512129,"c":4373479425,"a":[{"v":1179678,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Abstractions and features for interop between .NET and JavaScript code.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.JSInterop","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.JSInterop","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.JSInterop.Tests","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.AspNetCore.Components.WebAssembly.Tests","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mj.Microsoft.JSInterop.IJSRuntime", ($self) => class IJSRuntime
        {
            /*ValueTask<IJSObjectReference> */ Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask<IJSObjectReference> */ Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask<TValue> */ Microsoft$JSInterop$IJSRuntime$GetValueAsync(TValue, /*string*/ identifier)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask<TValue> */ Microsoft$JSInterop$IJSRuntime$GetValueAsync$1(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask */ Microsoft$JSInterop$IJSRuntime$SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask */ Microsoft$JSInterop$IJSRuntime$SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            static $h = 524318;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","o":"Microsoft$JSInterop$IJSRuntime$InvokeAsync","d":524318,"h":4295491614,"f":131329},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","o":"Microsoft$JSInterop$IJSRuntime$InvokeAsync$1","d":524318,"h":8590458910,"f":131329},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync","d":524318,"h":12885426206,"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1","d":524318,"h":17180393502,"f":129},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721}],"g":["TValue"],"n":"GetValueAsync","o":"Microsoft$JSInterop$IJSRuntime$GetValueAsync","d":524318,"h":21475360798,"f":131201},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"GetValueAsync","o":"Microsoft$JSInterop$IJSRuntime$GetValueAsync$1","d":524318,"h":25770328094,"f":131201},{"r":136118273,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"SetValueAsync","o":"Microsoft$JSInterop$IJSRuntime$SetValueAsync","d":524318,"h":30065295390,"f":131201},{"r":136118273,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"SetValueAsync","o":"Microsoft$JSInterop$IJSRuntime$SetValueAsync$1","d":524318,"h":34360262686,"f":131201}],"h":524318}; }
            static get $fullName() { return `IJSRuntime`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult", ($self) => class IJSVoidResult
        {
            static $h = 1638430;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":1638430,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $fullName() { return `IJSVoidResult`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.IJSInProcessRuntime", ($self) => class IJSInProcessRuntime
        {
            /*IJSInProcessObjectReference */ Microsoft$JSInterop$IJSInProcessRuntime$InvokeConstructor(/*string*/ identifier, /*params object?[]?*/ args)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*TValue */ Microsoft$JSInterop$IJSInProcessRuntime$GetValue(TValue, /*string*/ identifier)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*void */ Microsoft$JSInterop$IJSInProcessRuntime$SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            static $h = 393246;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":(TResult) => TResult.$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"g":["TResult"],"n":"Invoke","o":"Microsoft$JSInterop$IJSInProcessRuntime$Invoke","d":393246,"h":4295360542,"f":131329},{"r":327710,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"n":"InvokeConstructor","o":"Microsoft$JSInterop$IJSInProcessRuntime$InvokeConstructor","d":393246,"h":8590327838,"f":129},{"r":(TValue) => TValue.$h,"p":[{"n":"identifier","p":1310721}],"g":["TValue"],"n":"GetValue","o":"Microsoft$JSInterop$IJSInProcessRuntime$GetValue","d":393246,"h":12885295134,"f":131201},{"r":65537,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"SetValue","o":"Microsoft$JSInterop$IJSInProcessRuntime$SetValue","d":393246,"h":17180262430,"f":131201}],"i":[524318],"h":393246}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSRuntime ]; }
            static get $fullName() { return `IJSInProcessRuntime`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.IJSObjectReference", ($self) => class IJSObjectReference
        {
            /*ValueTask<IJSObjectReference> */ Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask<IJSObjectReference> */ Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask<TValue> */ Microsoft$JSInterop$IJSObjectReference$GetValueAsync(TValue, /*string*/ identifier)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask<TValue> */ Microsoft$JSInterop$IJSObjectReference$GetValueAsync$1(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask */ Microsoft$JSInterop$IJSObjectReference$SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*ValueTask */ Microsoft$JSInterop$IJSObjectReference$SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            static $h = 458782;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","o":"Microsoft$JSInterop$IJSObjectReference$InvokeAsync","d":458782,"h":4295426078,"f":131329},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","o":"Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1","d":458782,"h":8590393374,"f":131329},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync","d":458782,"h":12885360670,"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1","d":458782,"h":17180327966,"f":129},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721}],"g":["TValue"],"n":"GetValueAsync","o":"Microsoft$JSInterop$IJSObjectReference$GetValueAsync","d":458782,"h":21475295262,"f":131201},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"GetValueAsync","o":"Microsoft$JSInterop$IJSObjectReference$GetValueAsync$1","d":458782,"h":25770262558,"f":131201},{"r":136118273,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"SetValueAsync","o":"Microsoft$JSInterop$IJSObjectReference$SetValueAsync","d":458782,"h":30065229854,"f":131201},{"r":136118273,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"SetValueAsync","o":"Microsoft$JSInterop$IJSObjectReference$SetValueAsync$1","d":458782,"h":34360197150,"f":131201}],"i":[56885249],"h":458782}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `IJSObjectReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.IJSStreamReference", ($self) => class IJSStreamReference
        {
            static $h = 589854;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":917505,"g":{"r":0,"d":0,"h":8590524446,"f":257},"n":"Length","o":"Microsoft$JSInterop$IJSStreamReference$Length","d":589854,"h":4295557150,"f":257}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream).$h,"p":[{"n":"maxAllowedSize","p":917505,"f":65,"v":512000},{"n":"cancellationToken","p":125960193,"f":65}],"n":"OpenReadStreamAsync","o":"Microsoft$JSInterop$IJSStreamReference$OpenReadStreamAsync","d":589854,"h":12885491742,"f":257}],"i":[56885249],"h":589854}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `IJSStreamReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference", ($self) => class IDotNetObjectReference
        {
            static $h = 1572894;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":131073,"g":{"r":0,"d":0,"h":8591507486,"f":257},"n":"Value","o":"Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value","d":1572894,"h":4296540190,"f":257}],"i":[57475073],"h":1572894}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `IDotNetObjectReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.IJSInProcessObjectReference", ($self) => class IJSInProcessObjectReference
        {
            /*IJSInProcessObjectReference */ Microsoft$JSInterop$IJSInProcessObjectReference$InvokeConstructor(/*string*/ identifier, /*object?[]?*/ args)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*TValue */ Microsoft$JSInterop$IJSInProcessObjectReference$GetValue(TValue, /*string*/ identifier)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*void */ Microsoft$JSInterop$IJSInProcessObjectReference$SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            static $h = 327710;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":(TValue) => TValue.$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"Invoke","o":"Microsoft$JSInterop$IJSInProcessObjectReference$Invoke","d":327710,"h":4295295006,"f":131329},{"r":327710,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"n":"InvokeConstructor","o":"Microsoft$JSInterop$IJSInProcessObjectReference$InvokeConstructor","d":327710,"h":8590262302,"f":129},{"r":(TValue) => TValue.$h,"p":[{"n":"identifier","p":1310721}],"g":["TValue"],"n":"GetValue","o":"Microsoft$JSInterop$IJSInProcessObjectReference$GetValue","d":327710,"h":12885229598,"f":131201},{"r":65537,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"SetValue","o":"Microsoft$JSInterop$IJSInProcessObjectReference$SetValue","d":327710,"h":17180196894,"f":131201}],"i":[458782,56885249,57475073],"h":327710}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$spc.System.IAsyncDisposable, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `IJSInProcessObjectReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSRuntime", ($self) => class JSRuntime extends $.$spc.System.Object
        {
            /*long*/ static WindowObjectId = 0n;
            /*long*/ _nextObjectReferenceId = 0n;
            /*long*/ _nextPendingTaskId = 1n;
            /*ConcurrentDictionary<long, object>*/ _pendingTasks = null;
            /*ConcurrentDictionary<long, IDotNetObjectReference>*/ _trackedRefsById = null;
            /*ConcurrentDictionary<long, CancellationTokenRegistration>*/ _cancellationRegistrations = null;
            /*ArrayBuilder<byte[]>*/ ByteArraysToBeRevived = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.JsonSerializerOptions = (() =>
                    {
                        //new $.$stj.System.Text.Json.JsonSerializerOptions()
                        const $t1 = $.$stj.System.Text.Json.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.MaxDepth = 32;
                        $i1.PropertyNamingPolicy = $.$stj.System.Text.Json.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverterFactory().$ctor$1(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.JSObjectReferenceJsonConverter().$ctor$1(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter().$ctor$1(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetStreamReferenceJsonConverter().$ctor$1(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        $i1.Converters.System$Collections$Generic$ICollection$$$Add(new $.$mj.Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter().$ctor$1(this), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                        return $i1;
                    })();
                }
                return this;
            }
            /*JsonSerializerOptions*/ JsonSerializerOptions = null;
            /*TimeSpan?*/ DefaultAsyncTimeout = null;
            /*ValueTask<TValue> */ InvokeAsync(TValue, /*string*/ identifier, /*object?[]?*/ args)
            {
                return this.InvokeAsync$2(TValue, 0n, identifier, 1/*JSCallType.FunctionCall*/, args);
            }
            /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                return this.InvokeAsync$3(TValue, 0n, identifier, 1/*JSCallType.FunctionCall*/, cancellationToken, args);
            }
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                return this.InvokeAsync$2($.$mj.Microsoft.JSInterop.IJSObjectReference, 0n, identifier, 2/*JSCallType.ConstructorCall*/, args);
            }
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                return this.InvokeAsync$3($.$mj.Microsoft.JSInterop.IJSObjectReference, 0n, identifier, 2/*JSCallType.ConstructorCall*/, cancellationToken, args);
            }
            /*ValueTask<TValue> */ GetValueAsync(TValue, /*string*/ identifier)
            {
                return this.InvokeAsync$2(TValue, 0n, identifier, 3/*JSCallType.GetValue*/, null);
            }
            /*ValueTask<TValue> */ GetValueAsync$1(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                return this.InvokeAsync$3(TValue, 0n, identifier, 3/*JSCallType.GetValue*/, cancellationToken, null);
            }
            /*ValueTask *//*async*/  SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    return await this.InvokeAsync$2($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, 0n, identifier, 4/*JSCallType.SetValue*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null));
                });
            }
            /*ValueTask *//*async*/  SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    return await this.InvokeAsync$3($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, 0n, identifier, 4/*JSCallType.SetValue*/, cancellationToken, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null));
                });
            }
            /*ValueTask<TValue> *//*async*/  InvokeAsync$2(TValue, /*long*/ targetInstanceId, /*string*/ identifier, /*JSCallType*/ callType, /*object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$(TValue), TValue, async () => 
                {
                    if ($.$spc.System.Nullable$$($.$spc.System.TimeSpan).HasValue$get.call(this.DefaultAsyncTimeout))
                    {
                        /*var*/ let cts = new $.$spc.System.Threading.CancellationTokenSource().$ctor$2($.$spc.System.Nullable$$($.$spc.System.TimeSpan).Value$get.call(this.DefaultAsyncTimeout));
                        try
                        {
                            return await this.InvokeAsync$3(TValue, targetInstanceId, identifier, callType, cts.Token, args);
                        }
                        finally
                        {
                            cts?.System$IDisposable$Dispose();
                        }
                    }
                    return await this.InvokeAsync$3(TValue, targetInstanceId, identifier, callType, $.$spc.System.Threading.CancellationToken.None, args);
                });
            }
            /*ValueTask<TValue> */ InvokeAsync$3(TValue, /*long*/ targetInstanceId, /*string*/ identifier, /*JSCallType*/ callType, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                /*var*/ let taskId = $.$spc.System.Threading.Interlocked.Increment$1($.$ref(() => this._nextPendingTaskId, ($v) => this._nextPendingTaskId = $v, $.$spc.System.Int64));
                /*var*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$(TValue))().$ctor$1();
                if (cancellationToken.CanBeCanceled)
                {
                    this._cancellationRegistrations.set_Item(taskId, cancellationToken.Register(new $.$spc.System.Action().$ctor(this,  () =>
                    {
                        tcs.TrySetCanceled$1(cancellationToken);
                        this.CleanupTasksAndRegistrations(taskId);
                    })));
                }
                this._pendingTasks.set_Item(taskId, tcs);
                try
                {
                    if (cancellationToken.IsCancellationRequested)
                    {
                        tcs.TrySetCanceled$1(cancellationToken);
                        this.CleanupTasksAndRegistrations(taskId);
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$(TValue))().$ctor$3(tcs.Task);
                    }
                    /*var*/ let argsJson = !(args === null) && args.length !== 0 ? $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$typeArray($.$spc.System.Object), args, this.JsonSerializerOptions) : "[]";
                    /*var*/ let resultType = $.$mj.Microsoft.JSInterop.JSCallResultTypeHelper.FromGeneric(TValue);
                    /*var*/ let invocationInfo = (() =>
                    {
                        //new $.$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo()
                        const $t2 = $.$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo;
                        const $i2 = new $t2();
                        $i2.AsyncHandle = taskId;
                        $i2.TargetInstanceId = targetInstanceId;
                        $i2.Identifier = identifier;
                        $i2.CallType = callType;
                        $i2.ResultType = resultType;
                        $i2.ArgsJson = argsJson;
                        return $i2;
                    })();
                    this.BeginInvokeJS$2($.$ref(() => invocationInfo, ));
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$(TValue))().$ctor$3(tcs.Task);
                }
                catch($e)
                {
                    this.CleanupTasksAndRegistrations(taskId);
                    throw $e;
                }
            }
            /*void */ CleanupTasksAndRegistrations(/*long*/ taskId)
            {
                this._pendingTasks.TryRemove(taskId, $.$discardRef());
                /*var*/ let registration;
                if (this._cancellationRegistrations.TryRemove(taskId, $.$ref(() => registration, ($v) => registration = $v, $.$spc.System.Threading.CancellationTokenRegistration)))
                {
                    registration.Dispose();
                }
            }
            /*void */ BeginInvokeJS(/*long*/ taskId, /*string*/ identifier, /*string?*/ argsJson)
            {
                return this.BeginInvokeJS$1(taskId, identifier, argsJson, 0/*JSCallResultType.Default*/, 0n);
            }
            /*void */ BeginInvokeJS$2(/*in JSInvocationInfo*/ invocationInfo)
            {
                this.BeginInvokeJS$1(invocationInfo.$v.AsyncHandle, invocationInfo.$v.Identifier, invocationInfo.$v.ArgsJson, invocationInfo.$v.ResultType, invocationInfo.$v.TargetInstanceId);
            }
            /*void */ SendByteArray(/*int*/ id, /*byte[]*/ data)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10("JSRuntime subclasses are responsible for implementing byte array transfer to JS.");
            }
            /*void */ ReceiveByteArray(/*int*/ id, /*byte[]*/ data)
            {
                if (id === 0)
                {
                    this.ByteArraysToBeRevived.Clear();
                }
                if (id !== this.ByteArraysToBeRevived.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$18(`Element id '${id}' cannot be added to the byte arrays to be revived with length '${this.ByteArraysToBeRevived.Count}'.`, null);
                }
                this.ByteArraysToBeRevived.Append($.$ref(() => data, ));
            }
            /*Task<Stream> */ ReadJSDataAsStreamAsync(/*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10("The current JavaScript runtime does not support reading data streams.");
            }
            /*bool */ EndInvokeJS(/*long*/ taskId, /*bool*/ succeeded, /*ref Utf8JsonReader*/ jsonReader)
            {
                /*var*/ let tcs;
                if (!this._pendingTasks.TryRemove(taskId, $.$ref(() => tcs, ($v) => tcs = $v, $.$spc.System.Object)))
                {
                    return false;
                }
                this.CleanupTasksAndRegistrations(taskId);
                try
                {
                    if (succeeded)
                    {
                        /*var*/ let resultType = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.GetTaskCompletionSourceResultType(tcs);
                        /*var*/ let result = $.$stj.System.Text.Json.JsonSerializer.Deserialize$36(jsonReader, resultType, this.JsonSerializerOptions);
                        this.ByteArraysToBeRevived.Clear();
                        $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.SetTaskCompletionSourceResult(tcs, result);
                    }
                    else 
                    {
                        /*var*/ let exceptionText = jsonReader.$v.GetString() ?? $.$spc.System.String.Empty;
                        $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.SetTaskCompletionSourceException(tcs, new $.$mj.Microsoft.JSInterop.JSException().$ctor$5(exceptionText));
                    }
                    return true;
                }
                catch(exception)
                {
                    /*var*/ let message = `An exception occurred executing JS interop: ${exception.Message}. See InnerException for more details.`;
                    $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.SetTaskCompletionSourceException(tcs, new $.$mj.Microsoft.JSInterop.JSException().$ctor$6(message, exception));
                    return false;
                }
            }
            /*Task */ TransmitStreamAsync(/*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                if (!dotNetStreamReference.LeaveOpen)
                {
                    dotNetStreamReference.Stream.Dispose();
                }
                throw new $.$spc.System.NotSupportedException().$ctor$10("The current JS runtime does not support sending streams from .NET to JS.");
            }
            /*long */ BeginTransmittingStream(/*DotNetStreamReference*/ dotNetStreamReference)
            {
                /*var*/ let streamId = $.$spc.System.Threading.Interlocked.Increment$1($.$ref(() => this._nextObjectReferenceId, ($v) => this._nextObjectReferenceId = $v, $.$spc.System.Int64));
                _ = this.TransmitStreamAsync(streamId, dotNetStreamReference);
                return streamId;
            }
            /*long */ TrackObjectReference(TValue, /*DotNetObjectReference<TValue>*/ dotNetObjectReference)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(dotNetObjectReference, "dotNetObjectReference");
                dotNetObjectReference.ThrowIfDisposed();
                /*var*/ let jsRuntime = dotNetObjectReference.JSRuntime;
                if (jsRuntime === null)
                {
                    /*var*/ let dotNetObjectId = $.$spc.System.Threading.Interlocked.Increment$1($.$ref(() => this._nextObjectReferenceId, ($v) => this._nextObjectReferenceId = $v, $.$spc.System.Int64));
                    dotNetObjectReference.JSRuntime = this;
                    dotNetObjectReference.ObjectId = dotNetObjectId;
                    this._trackedRefsById.set_Item(dotNetObjectId, dotNetObjectReference);
                }
                else if (!$.$spc.System.Object.ReferenceEquals(this, jsRuntime))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`${$.$spc.System.Object.GetType.call(dotNetObjectReference).Name} is already being tracked by a different instance of ${"JSRuntime"}.` + ` A common cause is caching an instance of ${"DotNetObjectReference"} globally. Consider creating instances of ${"DotNetObjectReference"} at the JSInterop callsite.`);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(dotNetObjectReference.ObjectId !== 0n, "dotNetObjectReference.ObjectId != 0");
                return dotNetObjectReference.ObjectId;
            }
            /*IDotNetObjectReference */ GetObjectReference(/*long*/ dotNetObjectId)
            {
                /*var*/ let dotNetObjectRef;
                return this._trackedRefsById.TryGetValue(dotNetObjectId, $.$ref(() => dotNetObjectRef, ($v) => dotNetObjectRef = $v, $.$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference)) ? dotNetObjectRef : (() =>
                {
        throw new $.$spc.System.ArgumentException().$ctor$13(`There is no tracked object with id '${dotNetObjectId}'. Perhaps the DotNetObjectReference instance was already disposed.`, "dotNetObjectId")        })();
            }
            /*void */ ReleaseObjectReference(/*long*/ dotNetObjectId)
            {
                return this._trackedRefsById.TryRemove(dotNetObjectId, $.$discardRef());
            }
            /*void */ Dispose()
            {
                return this.ByteArraysToBeRevived.Dispose();
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeAsync<TValue>(string, object?[]?)
            Microsoft$JSInterop$IJSRuntime$InvokeAsync()
            {
                return this.InvokeAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeAsync<TValue>(string, System.Threading.CancellationToken, object?[]?)
            Microsoft$JSInterop$IJSRuntime$InvokeAsync$1()
            {
                return this.InvokeAsync$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeConstructorAsync(string, object?[]?)
            Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync()
            {
                return this.InvokeConstructorAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.InvokeConstructorAsync(string, System.Threading.CancellationToken, object?[]?)
            Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1()
            {
                return this.InvokeConstructorAsync$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.GetValueAsync<TValue>(string)
            Microsoft$JSInterop$IJSRuntime$GetValueAsync()
            {
                return this.GetValueAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.GetValueAsync<TValue>(string, System.Threading.CancellationToken)
            Microsoft$JSInterop$IJSRuntime$GetValueAsync$1()
            {
                return this.GetValueAsync$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.SetValueAsync<TValue>(string, TValue)
            Microsoft$JSInterop$IJSRuntime$SetValueAsync()
            {
                return this.SetValueAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSRuntime.SetValueAsync<TValue>(string, TValue, System.Threading.CancellationToken)
            Microsoft$JSInterop$IJSRuntime$SetValueAsync$1()
            {
                return this.SetValueAsync$1(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._pendingTasks = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Int64, $.$spc.System.Object))().$ctor$1();
                this._trackedRefsById = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Int64, $.$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference))().$ctor$1();
                this._cancellationRegistrations = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Int64, $.$spc.System.Threading.CancellationTokenRegistration))().$ctor$1();
                this.ByteArraysToBeRevived = new ($.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$($.$typeArray($.$spc.System.Byte)))().$ctor$1(32, null);
                this.DefaultAsyncTimeout = null;
            }
            static $h = 2949150;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3401872,"g":{"r":0,"d":0,"h":47247589406,"f":16},"n":"JsonSerializerOptions","d":2949150,"h":42952622110,"f":16},{"p":$.$typeNullable($.$spc.System.TimeSpan).$h,"g":{"r":0,"d":0,"h":60132491294,"f":4},"s":{"r":0,"d":0,"h":64427458590,"f":4},"n":"DefaultAsyncTimeout","d":2949150,"h":55837523998,"f":4}],"m":[{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","d":2949150,"h":68722425886,"f":131073},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","o":"@$1","d":2949150,"h":73017393182,"f":131073},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"n":"InvokeConstructorAsync","d":2949150,"h":77312360478,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"@$1","d":2949150,"h":81607327774,"f":1},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721}],"g":["TValue"],"n":"GetValueAsync","d":2949150,"h":85902295070,"f":131073},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"GetValueAsync","o":"@$1","d":2949150,"h":90197262366,"f":131073},{"r":136118273,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"SetValueAsync","d":2949150,"h":94492229662,"f":135169},{"r":136118273,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"SetValueAsync","o":"@$1","d":2949150,"h":98787196958,"f":135169},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"targetInstanceId","p":917505},{"n":"identifier","p":1310721},{"n":"callType","p":1703966},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","o":"@$2","d":2949150,"h":103082164254,"f":135176},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"targetInstanceId","p":917505},{"n":"identifier","p":1310721},{"n":"callType","p":1703966},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","o":"@$3","d":2949150,"h":107377131550,"f":131080},{"r":65537,"p":[{"n":"taskId","p":917505}],"n":"CleanupTasksAndRegistrations","d":2949150,"h":111672098846,"f":2},{"r":65537,"p":[{"n":"taskId","p":917505},{"n":"identifier","p":1310721},{"n":"argsJson","p":1310721}],"n":"BeginInvokeJS","d":2949150,"h":115967066142,"f":132},{"r":65537,"p":[{"n":"taskId","p":917505},{"n":"identifier","p":1310721},{"n":"argsJson","p":1310721},{"n":"resultType","p":2359326},{"n":"targetInstanceId","p":917505}],"n":"BeginInvokeJS","o":"@$1","d":2949150,"h":120262033438,"f":260},{"r":65537,"p":[{"n":"invocationInfo","p":1769502,"f":8}],"n":"BeginInvokeJS","o":"@$2","d":2949150,"h":124557000734,"f":132},{"r":65537,"p":[{"n":"invocationInfo","p":1245214},{"n":"invocationResult","p":1310750,"f":8}],"n":"EndInvokeDotNet","d":2949150,"h":128851968030,"f":272},{"r":65537,"p":[{"n":"id","p":655361},{"n":"data","p":0}],"n":"SendByteArray","d":2949150,"h":133146935326,"f":144},{"r":65537,"p":[{"n":"id","p":655361},{"n":"data","p":0}],"n":"ReceiveByteArray","d":2949150,"h":137441902622,"f":144},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream).$h,"p":[{"n":"jsStreamReference","p":589854},{"n":"totalLength","p":917505},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadJSDataAsStreamAsync","d":2949150,"h":141736869918,"f":144},{"r":262145,"p":[{"n":"taskId","p":917505},{"n":"succeeded","p":262145},{"n":"jsonReader","p":18999440,"f":4}],"n":"EndInvokeJS","d":2949150,"h":146031837214,"f":8},{"r":133300225,"p":[{"n":"streamId","p":917505},{"n":"dotNetStreamReference","p":262174}],"n":"TransmitStreamAsync","d":2949150,"h":150326804510,"f":144},{"r":917505,"p":[{"n":"dotNetStreamReference","p":262174}],"n":"BeginTransmittingStream","d":2949150,"h":154621771806,"f":8},{"r":917505,"p":[{"n":"dotNetObjectReference","p":(TValue) => $.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue).$h}],"g":["TValue"],"n":"TrackObjectReference","d":2949150,"h":158916739102,"f":131080},{"r":1572894,"p":[{"n":"dotNetObjectId","p":917505}],"n":"GetObjectReference","d":2949150,"h":163211706398,"f":8},{"r":65537,"p":[{"n":"dotNetObjectId","p":917505}],"n":"ReleaseObjectReference","d":2949150,"h":167506673694,"f":8},{"r":65537,"n":"Dispose","d":2949150,"h":171801640990,"f":1}],"l":[{"t":917505,"n":"WindowObjectId","d":2949150,"h":4297916446,"f":40},{"t":917505,"n":"_nextObjectReferenceId","d":2949150,"h":8592883742,"f":2},{"t":917505,"n":"_nextPendingTaskId","d":2949150,"h":12887851038,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Int64, $.$spc.System.Object).$h,"n":"_pendingTasks","d":2949150,"h":17182818334,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Int64, $.$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference).$h,"n":"_trackedRefsById","d":2949150,"h":21477785630,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Int64, $.$spc.System.Threading.CancellationTokenRegistration).$h,"n":"_cancellationRegistrations","d":2949150,"h":25772752926,"f":2},{"t":$.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$($.$typeArray($.$spc.System.Byte)).$h,"n":"ByteArraysToBeRevived","d":2949150,"h":30067720222,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2949150,"h":34362687518,"f":4}],"i":[524318,57475073],"h":2949150}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSRuntime, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `JSRuntime`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSInProcessRuntime", ($self) => class JSInProcessRuntime extends $.$mj.Microsoft.JSInterop.JSRuntime
        {
            /*long*/ static SyncCallIndicator = 0n;
            /*TValue */ Invoke(TValue, /*string*/ identifier, /*params object?[]?*/ args)
            {
                return this.Invoke$1(TValue, identifier, 0n, 1/*JSCallType.FunctionCall*/, args);
            }
            /*IJSInProcessObjectReference */ InvokeConstructor(/*string*/ identifier, /*params object?[]?*/ args)
            {
                return this.Invoke$1($.$mj.Microsoft.JSInterop.IJSInProcessObjectReference, identifier, 0n, 2/*JSCallType.ConstructorCall*/, args);
            }
            /*TValue */ GetValue(TValue, /*string*/ identifier)
            {
                return this.Invoke$1(TValue, identifier, 0n, 3/*JSCallType.GetValue*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [  ], null, null));
            }
            /*void */ SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                return this.Invoke$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, 0n, 4/*JSCallType.SetValue*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(value, TValue) ], null, null));
            }
            /*TValue */ Invoke$1(TValue, /*string*/ identifier, /*long*/ targetInstanceId, /*JSCallType*/ callType, /*params object?[]?*/ args)
            {
                /*var*/ let argsJson = !(args === null) && args.length !== 0 ? $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$typeArray($.$spc.System.Object), args, this.JsonSerializerOptions) : "[]";
                /*var*/ let resultType = $.$mj.Microsoft.JSInterop.JSCallResultTypeHelper.FromGeneric(TValue);
                /*var*/ let invocationInfo = (() =>
                {
                    //new $.$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo()
                    const $t1 = $.$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo;
                    const $i1 = new $t1();
                    $i1.AsyncHandle = 0n;
                    $i1.TargetInstanceId = targetInstanceId;
                    $i1.Identifier = identifier;
                    $i1.CallType = callType;
                    $i1.ResultType = resultType;
                    $i1.ArgsJson = argsJson;
                    return $i1;
                })();
                /*var*/ let resultJson = this.InvokeJS$2($.$ref(() => invocationInfo, ));
                if (resultJson === null)
                {
                    return $.$default(TValue);
                }
                /*var*/ let result = $.$stj.System.Text.Json.JsonSerializer.Deserialize$25(TValue, resultJson, this.JsonSerializerOptions);
                this.ByteArraysToBeRevived.Clear();
                return result;
            }
            /*string? */ InvokeJS(/*string*/ identifier, /*string?*/ argsJson)
            {
                return this.InvokeJS$1(identifier, argsJson, 0/*JSCallResultType.Default*/, 0n);
            }
            /*string? */ InvokeJS$2(/*in JSInvocationInfo*/ invocationInfo)
            {
                return this.InvokeJS$1(invocationInfo.$v.Identifier, invocationInfo.$v.ArgsJson, invocationInfo.$v.ResultType, invocationInfo.$v.TargetInstanceId);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.Invoke<TResult>(string, params object?[]?)
            Microsoft$JSInterop$IJSInProcessRuntime$Invoke()
            {
                return this.Invoke(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.InvokeConstructor(string, params object?[]?)
            Microsoft$JSInterop$IJSInProcessRuntime$InvokeConstructor()
            {
                return this.InvokeConstructor(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.GetValue<TValue>(string)
            Microsoft$JSInterop$IJSInProcessRuntime$GetValue()
            {
                return this.GetValue(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessRuntime.SetValue<TValue>(string, TValue)
            Microsoft$JSInterop$IJSInProcessRuntime$SetValue()
            {
                return this.SetValue(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2687006;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2949150,"m":[{"r":(TValue) => TValue.$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"Invoke","d":2687006,"h":8592621598,"f":131073},{"r":327710,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"n":"InvokeConstructor","d":2687006,"h":12887588894,"f":1},{"r":(TValue) => TValue.$h,"p":[{"n":"identifier","p":1310721}],"g":["TValue"],"n":"GetValue","d":2687006,"h":17182556190,"f":131073},{"r":65537,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"SetValue","d":2687006,"h":21477523486,"f":131073},{"r":(TValue) => TValue.$h,"p":[{"n":"identifier","p":1310721},{"n":"targetInstanceId","p":917505},{"n":"callType","p":1703966},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"Invoke","o":"@$1","d":2687006,"h":25772490782,"f":131080},{"r":1310721,"p":[{"n":"identifier","p":1310721},{"n":"argsJson","p":1310721}],"n":"InvokeJS","d":2687006,"h":30067458078,"f":132},{"r":1310721,"p":[{"n":"identifier","p":1310721},{"n":"argsJson","p":1310721},{"n":"resultType","p":2359326},{"n":"targetInstanceId","p":917505}],"n":"InvokeJS","o":"@$1","d":2687006,"h":34362425374,"f":260},{"r":1310721,"p":[{"n":"invocationInfo","p":1769502,"f":8}],"n":"InvokeJS","o":"@$2","d":2687006,"h":38657392670,"f":132}],"l":[{"t":917505,"n":"SyncCallIndicator","d":2687006,"h":4297654302,"f":40}],"c":[{"n":".ctor","o":"$ctor$2","d":2687006,"h":42952359966,"f":4}],"i":[57475073,393246,524318],"h":2687006}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.JSRuntime; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$mj.Microsoft.JSInterop.IJSInProcessRuntime, $.$mj.Microsoft.JSInterop.IJSRuntime ]; }
            static get $fullName() { return `JSInProcessRuntime`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.DotNetObjectReference", ($self) => class DotNetObjectReference
        {
            static /*DotNetObjectReference<TValue> */ Create(TValue, /*TValue*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(value, TValue), "value");
                return new ($.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue))().$ctor$1(value);
            }
            static $h = 131102;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TValue) => $.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue).$h,"p":[{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"Create","d":131102,"h":4295098398,"f":131105}],"h":131102}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `DotNetObjectReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSCallResultTypeHelper", ($self) => class JSCallResultTypeHelper
        {
            /*Assembly*/ static _currentAssembly = null;
            static /*JSCallResultType */ FromGeneric(TResult, )
            {
                if ($.$spc.System.Reflection.Assembly.op_Equality(TResult.$type.Assembly, $.$mj.Microsoft.JSInterop.JSCallResultTypeHelper._currentAssembly))
                {
                    if ($.$spc.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSObjectReference.$type) || $.$spc.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference.$type))
                    {
                        return 1/*JSCallResultType.JSObjectReference*/;
                    }
                    else if ($.$spc.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.IJSStreamReference.$type))
                    {
                        return 2/*JSCallResultType.JSStreamReference*/;
                    }
                    else if ($.$spc.System.Type.op_Equality$1(TResult.$type, $.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult.$type))
                    {
                        return 3/*JSCallResultType.JSVoidResult*/;
                    }
                }
                return 0/*JSCallResultType.Default*/;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._currentAssembly = $.$mj.Microsoft.JSInterop.JSCallResultType.$type.Assembly;
                }
            }
            static $h = 2424862;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":2359326,"g":["TResult"],"n":"FromGeneric","d":2424862,"h":8592359454,"f":131105}],"l":[{"t":73465857,"n":"_currentAssembly","d":2424862,"h":4297392158,"f":34}],"h":2424862}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JSCallResultTypeHelper`; }
        });
        
        $asm.$cls("$mj.Microsoft.AspNetCore.Internal.LinkerFlags", ($self) => class LinkerFlags
        {
            /*DynamicallyAccessedMemberTypes*/ static JsonSerialized = 547;
            /*DynamicallyAccessedMemberTypes*/ static Component = -1;
            /*DynamicallyAccessedMemberTypes*/ static JSInvokable = 8;
            static $h = 65566;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":35848193,"n":"JsonSerialized","d":65566,"h":4295032862,"f":33},{"t":35848193,"n":"Component","d":65566,"h":8590000158,"f":33},{"t":35848193,"n":"JSInvokable","d":65566,"h":12884967454,"f":33}],"h":65566}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `LinkerFlags`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSInProcessObjectReferenceExtensions", ($self) => class JSInProcessObjectReferenceExtensions
        {
            static /*void */ InvokeVoid(/*this IJSInProcessObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                jsObjectReference.Microsoft$JSInterop$IJSInProcessObjectReference$Invoke($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, args);
            }
            static $h = 2621470;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"jsObjectReference","p":327710},{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"n":"InvokeVoid","d":2621470,"h":4297588766,"f":33}],"h":2621470}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JSInProcessObjectReferenceExtensions`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSInProcessRuntimeExtensions", ($self) => class JSInProcessRuntimeExtensions
        {
            static /*void */ InvokeVoid(/*this IJSInProcessRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                jsRuntime.Microsoft$JSInterop$IJSInProcessRuntime$Invoke($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, args);
            }
            static $h = 2752542;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"jsRuntime","p":393246},{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"n":"InvokeVoid","d":2752542,"h":4297719838,"f":33}],"h":2752542}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JSInProcessRuntimeExtensions`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker", ($self) => class JSObjectReferenceJsonWorker
        {
            /*JsonEncodedText*/ static JSObjectIdKey;
            static /*long */ ReadJSObjectReferenceIdentifier(/*ref Utf8JsonReader*/ reader)
            {
                /*long?*/ let id = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (id === null && reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON property ${reader.$v.GetString()}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON token ${reader.$v.TokenType}`);
                    }
                }
                if (!$.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(id))
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Required property ${$.$stj.System.Text.Json.JsonEncodedText.ToString.call($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey)} not found.`);
                }
                return $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(id);
            }
            static /*void */ WriteJSObjectReference(/*Utf8JsonWriter*/ writer, /*JSObjectReference*/ objectReference)
            {
                writer.WriteStartObject();
                writer.WriteNumber$15($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey, objectReference.Id);
                writer.WriteEndObject();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.JSObjectIdKey = $.$stj.System.Text.Json.JsonEncodedText.Encode("__jsObjectId", null);
                }
            }
            static $h = 786462;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":917505,"p":[{"n":"reader","p":18999440,"f":4}],"n":"ReadJSObjectReferenceIdentifier","d":786462,"h":8590721054,"f":33},{"r":65537,"p":[{"n":"writer","p":19130512},{"n":"objectReference","p":720926}],"n":"WriteJSObjectReference","d":786462,"h":12885688350,"f":33}],"l":[{"t":2353296,"n":"JSObjectIdKey","d":786462,"h":4295753758,"f":40}],"h":786462}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JSObjectReferenceJsonWorker`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSObjectReferenceExtensions", ($self) => class JSObjectReferenceExtensions
        {
            static /*ValueTask *//*async*/  InvokeVoidAsync(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                    await jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, args);
                });
            }
            static /*ValueTask<TValue> */ InvokeAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync(TValue, identifier, args);
            }
            static /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1(TValue, identifier, cancellationToken, args);
            }
            static /*ValueTask *//*async*/  InvokeVoidAsync$1(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                    await jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, cancellationToken, args);
                });
            }
            static /*ValueTask<TValue> *//*async*/  InvokeAsync$2(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$(TValue), TValue, async () => 
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                    /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                    try
                    {
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                        return await jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1(TValue, identifier, cancellationToken, args);
                    }
                    finally
                    {
                        cancellationTokenSource?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*ValueTask *//*async*/  InvokeVoidAsync$2(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                    /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                    try
                    {
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                        await jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, cancellationToken, args);
                    }
                    finally
                    {
                        cancellationTokenSource?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*params object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync(identifier, args);
            }
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1(identifier, cancellationToken, args);
            }
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$2(/*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout, /*object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                    return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1(identifier, cancellationToken, args);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            static /*ValueTask<TValue> */ GetValueAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TimeSpan*/ timeout)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                    return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$GetValueAsync$1(TValue, identifier, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            static /*ValueTask */ SetValueAsync(TValue, /*this IJSObjectReference*/ jsObjectReference, /*string*/ identifier, /*TValue*/ value, /*TimeSpan*/ timeout)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsObjectReference, "jsObjectReference");
                /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                    return jsObjectReference.Microsoft$JSInterop$IJSObjectReference$SetValueAsync$1(TValue, identifier, value, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            static $h = 2883614;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":136118273,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"n":"InvokeVoidAsync","d":2883614,"h":4297850910,"f":4129},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"InvokeAsync","d":2883614,"h":8592818206,"f":131105},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"InvokeAsync","o":"@$1","d":2883614,"h":12887785502,"f":131105},{"r":136118273,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0,"f":16}],"n":"InvokeVoidAsync","o":"@$1","d":2883614,"h":17182752798,"f":4129},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"timeout","p":140705793},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"InvokeAsync","o":"@$2","d":2883614,"h":21477720094,"f":135201},{"r":136118273,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"timeout","p":140705793},{"n":"args","p":0,"f":16}],"n":"InvokeVoidAsync","o":"@$2","d":2883614,"h":25772687390,"f":4129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"n":"InvokeConstructorAsync","d":2883614,"h":30067654686,"f":33},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"@$1","d":2883614,"h":34362621982,"f":33},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"timeout","p":140705793},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"@$2","d":2883614,"h":38657589278,"f":33},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"timeout","p":140705793}],"g":["TValue"],"n":"GetValueAsync","d":2883614,"h":42952556574,"f":131105},{"r":136118273,"p":[{"n":"jsObjectReference","p":458782},{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"timeout","p":140705793}],"g":["TValue"],"n":"SetValueAsync","d":2883614,"h":47247523870,"f":131105}],"h":2883614}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JSObjectReferenceExtensions`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSRuntimeExtensions", ($self) => class JSRuntimeExtensions
        {
            static /*ValueTask *//*async*/  InvokeVoidAsync(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                    await jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, args);
                });
            }
            static /*ValueTask<TValue> */ InvokeAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync(TValue, identifier, args);
            }
            static /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync$1(TValue, identifier, cancellationToken, args);
            }
            static /*ValueTask *//*async*/  InvokeVoidAsync$1(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*params object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                    await jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, cancellationToken, args);
                });
            }
            static /*ValueTask<TValue> *//*async*/  InvokeAsync$2(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$(TValue), TValue, async () => 
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                    /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                    try
                    {
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                        return await jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync$1(TValue, identifier, cancellationToken, args);
                    }
                    finally
                    {
                        cancellationTokenSource?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*ValueTask *//*async*/  InvokeVoidAsync$2(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*params object?[]?*/ args)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                    /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                    try
                    {
                        /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                        await jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeAsync$1($.$mj.Microsoft.JSInterop.Infrastructure.IJSVoidResult, identifier, cancellationToken, args);
                    }
                    finally
                    {
                        cancellationTokenSource?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*params object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync(identifier, args);
            }
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1(identifier, cancellationToken, args);
            }
            static /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$2(/*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout, /*object?[]?*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                    return jsRuntime.Microsoft$JSInterop$IJSRuntime$InvokeConstructorAsync$1(identifier, cancellationToken, args);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            static /*ValueTask<TValue> */ GetValueAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TimeSpan*/ timeout)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                    return jsRuntime.Microsoft$JSInterop$IJSRuntime$GetValueAsync$1(TValue, identifier, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            static /*ValueTask */ SetValueAsync(TValue, /*this IJSRuntime*/ jsRuntime, /*string*/ identifier, /*TValue*/ value, /*TimeSpan*/ timeout)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsRuntime, "jsRuntime");
                /*var*/ let cancellationTokenSource = $.$spc.System.TimeSpan.op_Equality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan) ? null : new $.$spc.System.Threading.CancellationTokenSource().$ctor$2(timeout);
                try
                {
                    /*var*/ let cancellationToken = (cancellationTokenSource?.Token ?? null) ?? $.$spc.System.Threading.CancellationToken.None;
                    return jsRuntime.Microsoft$JSInterop$IJSRuntime$SetValueAsync$1(TValue, identifier, value, cancellationToken);
                }
                finally
                {
                    cancellationTokenSource?.System$IDisposable$Dispose();
                }
            }
            static $h = 3014686;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":136118273,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"n":"InvokeVoidAsync","d":3014686,"h":4297981982,"f":4129},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"InvokeAsync","d":3014686,"h":8592949278,"f":131105},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"InvokeAsync","o":"@$1","d":3014686,"h":12887916574,"f":131105},{"r":136118273,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0,"f":16}],"n":"InvokeVoidAsync","o":"@$1","d":3014686,"h":17182883870,"f":4129},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"timeout","p":140705793},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"InvokeAsync","o":"@$2","d":3014686,"h":21477851166,"f":135201},{"r":136118273,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"timeout","p":140705793},{"n":"args","p":0,"f":16}],"n":"InvokeVoidAsync","o":"@$2","d":3014686,"h":25772818462,"f":4129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"n":"InvokeConstructorAsync","d":3014686,"h":30067785758,"f":33},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"@$1","d":3014686,"h":34362753054,"f":33},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"timeout","p":140705793},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"@$2","d":3014686,"h":38657720350,"f":33},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"timeout","p":140705793}],"g":["TValue"],"n":"GetValueAsync","d":3014686,"h":42952687646,"f":131105},{"r":136118273,"p":[{"n":"jsRuntime","p":524318},{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"timeout","p":140705793}],"g":["TValue"],"n":"SetValueAsync","d":3014686,"h":47247654942,"f":131105}],"h":3014686}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JSRuntimeExtensions`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher", ($self) => class DotNetDispatcher
        {
            /*string*/ static DisposeDotNetObjectReferenceMethodName = null;
            /*JsonEncodedText*/ static DotNetObjectRefKey;
            /*ConcurrentDictionary<AssemblyKey, IReadOnlyDictionary<string, (MethodInfo, Type[])>>*/ static _cachedMethodsByAssembly = null;
            /*ConcurrentDictionary<Type, IReadOnlyDictionary<string, (MethodInfo, Type[])>>*/ static _cachedMethodsByType = null;
            /*ConcurrentDictionary<Type, Func<object, Task>>*/ static _cachedConvertToTaskByType = null;
            /*MethodInfo*/ static _taskConverterMethodInfo = null;
            static /*string? */ Invoke(/*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ invocationInfo, /*string*/ argsJson)
            {
                /*IDotNetObjectReference?*/ let targetInstance = null;
                if (invocationInfo.$v.DotNetObjectId !== 0n)
                {
                    targetInstance = jsRuntime.GetObjectReference(invocationInfo.$v.DotNetObjectId);
                }
                /*var*/ let syncResult = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.InvokeSynchronously(jsRuntime, invocationInfo, targetInstance, argsJson);
                if (syncResult === null)
                {
                    return null;
                }
                return $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Object, syncResult, jsRuntime.JsonSerializerOptions);
            }
            static /*void */ BeginInvokeDotNet(/*JSRuntime*/ jsRuntime, /*DotNetInvocationInfo*/ invocationInfo, /*string*/ argsJson)
            {
                /*var*/ let callId = invocationInfo.CallId;
                /*object?*/ let syncResult = null;
                /*ExceptionDispatchInfo?*/ let syncException = null;
                /*IDotNetObjectReference?*/ let targetInstance = null;
                try
                {
                    if (invocationInfo.DotNetObjectId !== 0n)
                    {
                        targetInstance = jsRuntime.GetObjectReference(invocationInfo.DotNetObjectId);
                    }
                    syncResult = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.InvokeSynchronously(jsRuntime, $.$ref(() => invocationInfo, ), targetInstance, argsJson);
                }
                catch(ex)
                {
                    syncException = $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex);
                }
                let task;
                let valueTaskResult;
                const $t1 = syncResult;
                let syncResultType;
                const $t2 = syncResult;
                const $t3 = syncResult;
                if ($.$spc.System.String.op_Equality(callId, null))
                {
                    return;
                }
                else if (syncException !== null)
                {
                    jsRuntime.EndInvokeDotNet(invocationInfo, $.$ref(() => new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult().$ctor$2(syncException.SourceException, "InvocationFailure"), ));
                }
                else if ($.$is(syncResult, $.$spc.System.Threading.Tasks.Task, { set $v(v){ task = v; } }))
                {
                    task.ContinueWith$2(new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }), $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                }
                else if ($.$is(syncResult, $.$spc.System.Threading.Tasks.ValueTask, { set $v(v){ valueTaskResult = v; } }))
                {
                    valueTaskResult.AsTask().ContinueWith$2(new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  (/**/ t) =>
                    {
                        return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }), $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                }
                else if ($.$ifnn($t1, ($t) => $.$spc.System.Object.GetType.call($t)) !== null && ((syncResultType = $.$ifnn($t2, ($t) => $.$spc.System.Object.GetType.call($t)), syncResultType != null && $.$ifnn($t3, ($t) => $.$spc.System.Object.GetType.call($t)).IsGenericType === true)) && $.$spc.System.Type.op_Equality$1(syncResultType.GetGenericTypeDefinition(), $.$spc.System.Threading.Tasks.ValueTask$$().$type))
                {
                    /*var*/ let innerTask = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetTaskByType($.$spc.System.Array.$ReadT1.call(syncResultType.GenericTypeArguments, 0), syncResult);
                    innerTask.ContinueWith$2(new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.EndInvokeDotNetAfterTask(t, jsRuntime, $.$ref(() => invocationInfo, ));
                    }), $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                }
                else 
                {
                    /*var*/ let syncResultJson = $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Object, syncResult, jsRuntime.JsonSerializerOptions);
                    /*var*/ let dispatchResult = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult().$ctor$3(syncResultJson);
                    jsRuntime.EndInvokeDotNet(invocationInfo, $.$ref(() => dispatchResult, ));
                }
            }
            static /*void */ EndInvokeDotNetAfterTask(/*Task*/ task, /*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ invocationInfo)
            {
                if (task.Exception !== null)
                {
                    /*var*/ let exceptionDispatchInfo = $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(task.Exception.GetBaseException());
                    /*var*/ let dispatchResult = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult().$ctor$2(exceptionDispatchInfo.SourceException, "InvocationFailure");
                    jsRuntime.EndInvokeDotNet(invocationInfo.$v, $.$ref(() => dispatchResult, ));
                }
                /*var*/ let result = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.GetTaskResult(task);
                /*var*/ let resultJson = $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Object, result, jsRuntime.JsonSerializerOptions);
                jsRuntime.EndInvokeDotNet(invocationInfo.$v, $.$ref(() => new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult().$ctor$3(resultJson), ));
            }
            static /*object? */ InvokeSynchronously(/*JSRuntime*/ jsRuntime, /*in DotNetInvocationInfo*/ callInfo, /*IDotNetObjectReference?*/ objectReference, /*string*/ argsJson)
            {
                /*var*/ let assemblyName = callInfo.$v.AssemblyName;
                /*var*/ let methodIdentifier = callInfo.$v.MethodIdentifier;
                /*AssemblyKey*/ let assemblyKey;
                /*MethodInfo*/ let methodInfo;
                /*Type[]*/ let parameterTypes;
                if (objectReference === null)
                {
                    assemblyKey = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey().$ctor$3(assemblyName);
                    $.$tupleUnpack(($tp) =>
                    {
                        methodInfo = $tp.Item1;
                        parameterTypes = $tp.Item2;
                    }).$v = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetCachedMethodInfo(assemblyKey, methodIdentifier);
                }
                else 
                {
                    if ($.$spc.System.String.op_Inequality(assemblyName, null))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10(`For instance method calls, '${"assemblyName"}' should be null. Value received: '${assemblyName}'.`);
                    }
                    if ($.$spc.System.String.Equals$5("__Dispose"/*DisposeDotNetObjectReferenceMethodName*/, methodIdentifier, 4/*StringComparison.Ordinal*/))
                    {
                        objectReference.System$IDisposable$Dispose();
                        return null;
                    }
                    $.$tupleUnpack(($tp) =>
                    {
                        methodInfo = $tp.Item1;
                        parameterTypes = $tp.Item2;
                    }).$v = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetCachedMethodInfo$1(objectReference, methodIdentifier);
                }
                /*var*/ let suppliedArgs = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.ParseArguments(jsRuntime, methodIdentifier, argsJson, parameterTypes);
                try
                {
                    return methodInfo.Invoke((objectReference?.Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value ?? null), suppliedArgs);
                }
                catch(tie)
                {
                    if (tie.InnerException !== null)
                    {
                        $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(tie.InnerException).Throw();
                        throw tie.InnerException;
                    }
                    throw tie;
                }
                finally
                {
                    {
                        jsRuntime.ByteArraysToBeRevived.Clear();
                    }
                }
            }
            static /*object?[] */ ParseArguments(/*JSRuntime*/ jsRuntime, /*string*/ methodIdentifier, /*string*/ $arguments, /*Type[]*/ parameterTypes)
            {
                if (parameterTypes.length === 0)
                {
                    return $.$spc.System.Array.Empty($.$spc.System.Object);
                }
                /*var*/ let count = $.$spc.System.Text.Encoding.UTF8.GetByteCount$1($arguments);
                /*var*/ let buffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(count);
                try
                {
                    /*var*/ let receivedBytes = $.$spc.System.Text.Encoding.UTF8.GetBytes$7($.$spc.System.String.op_Implicit($arguments), $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(buffer));
                    $.$spc.System.Diagnostics.Debug.Assert$1(count === receivedBytes, "count == receivedBytes");
                    /*var*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$3($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, buffer, 0, count)), new $.$stj.System.Text.Json.JsonReaderOptions());
                    if (!reader.Read() || reader.TokenType !== 3/*JsonTokenType.StartArray*/)
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8("Invalid JSON");
                    }
                    /*var*/ let suppliedArgs = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [parameterTypes.length], null);
                    /*var*/ let index = 0;
                    while(index < parameterTypes.length && reader.Read() && reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                    {
                        /*var*/ let parameterType = $.$spc.System.Array.$ReadT1.call(parameterTypes, index);
                        if (reader.TokenType === 1/*JsonTokenType.StartObject*/ && IsIncorrectDotNetObjectRefUse(parameterType, reader.Clone()))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10(`In call to '${methodIdentifier}', parameter of type '${parameterType.Name}' at index ${(((index + 1) | 0))} must be declared as type 'DotNetObjectRef<${parameterType.Name}>' to receive the incoming value.`);
                        }
                        $.$spc.System.Array.$WriteT1.call(suppliedArgs, $.$stj.System.Text.Json.JsonSerializer.Deserialize$36($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), parameterType, jsRuntime.JsonSerializerOptions), index);
                        index++;
                    }
                    if (index < parameterTypes.length)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10(`The call to '${methodIdentifier}' expects '${parameterTypes.length}' parameters, but received '${index}'.`);
                    }
                    if (!reader.Read() || reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON token ${reader.TokenType}. Ensure that the call to \`${methodIdentifier}' is supplied with exactly '${parameterTypes.length}' parameters.`);
                    }
                    return suppliedArgs;
                    /*static bool*/  function IsIncorrectDotNetObjectRefUse(/*Type*/ parameterType, /*Utf8JsonReader*/ jsonReader)
                    {
                        if (jsonReader.Read() && jsonReader.TokenType === 5/*JsonTokenType.PropertyName*/ && jsonReader.ValueTextEquals($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.DotNetObjectRefKey.EncodedUtf8Bytes))
                        {
                            return !parameterType.IsGenericType || $.$spc.System.Type.op_Inequality$1(parameterType.GetGenericTypeDefinition(), $.$mj.Microsoft.JSInterop.DotNetObjectReference$$().$type);
                        }
                        return false;
                    }
                }
                finally
                {
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                    }
                }
            }
            static /*void */ EndInvokeJS(/*JSRuntime*/ jsRuntime, /*string*/ $arguments)
            {
                /*var*/ let utf8JsonBytes = $.$spc.System.Text.Encoding.UTF8.GetBytes$3($arguments);
                /*var*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$3($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(utf8JsonBytes), new $.$stj.System.Text.Json.JsonReaderOptions());
                if (!reader.Read() || reader.TokenType !== 3/*JsonTokenType.StartArray*/)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8("Invalid JSON");
                }
                reader.Read();
                /*var*/ let taskId = reader.GetInt64();
                reader.Read();
                /*var*/ let success = reader.GetBoolean();
                reader.Read();
                if (!jsRuntime.EndInvokeJS(taskId, success, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null)))
                {
                    return;
                }
                if (!reader.Read() || reader.TokenType !== 4/*JsonTokenType.EndArray*/)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8("Invalid JSON");
                }
            }
            static /*void */ ReceiveByteArray(/*JSRuntime*/ jsRuntime, /*int*/ id, /*byte[]*/ data)
            {
                jsRuntime.ReceiveByteArray(id, data);
            }
            static /*(MethodInfo, Type[]) */ GetCachedMethodInfo(/*AssemblyKey*/ assemblyKey, /*string*/ methodIdentifier)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrWhiteSpace(assemblyKey.AssemblyName, "assemblyKey.AssemblyName");
                $.$spc.System.ArgumentException.ThrowIfNullOrWhiteSpace(methodIdentifier, "methodIdentifier");
                /*var*/ let assemblyMethods = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedMethodsByAssembly.GetOrAdd(assemblyKey, new ($.$spc.System.Func$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey, $.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)))))().$ctor(null, $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.ScanAssemblyForCallableMethods));
                /*var*/ let result;
                if (assemblyMethods.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue(methodIdentifier, $.$ref(() => result, ($v) => result = $v, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type))), [$.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type))]))
                {
                    return result;
                }
                else 
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10(`The assembly '${assemblyKey.AssemblyName}' does not contain a public invokable method with [${"JSInvokableAttribute"}(\"${methodIdentifier}\")].`);
                }
            }
            static /*Task */ GetTaskByType(/*Type*/ type, /*object*/ obj)
            {
                /*var*/ let converterDelegate = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedConvertToTaskByType.GetOrAdd$1($.$spc.System.Reflection.MethodInfo, type, new ($.$spc.System.Func$$$$($.$spc.System.Type, $.$spc.System.Reflection.MethodInfo, $.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Threading.Tasks.Task)))().$ctor(this,  (/*Type*/ t, /*MethodInfo*/ taskConverterMethodInfo) =>
                {
                    return taskConverterMethodInfo.MakeGenericMethod($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ t ], null, null)).CreateDelegate$2($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Threading.Tasks.Task));
                }), $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._taskConverterMethodInfo);
                return converterDelegate.Invoke(obj);
            }
            static /*Task */ CreateValueTaskConverter(T, /*object*/ result)
            {
                return ($.$cast(result, $.$spc.System.Threading.Tasks.ValueTask$$(T))).AsTask();
            }
            static /*(MethodInfo methodInfo, Type[] parameterTypes) */ GetCachedMethodInfo$1(/*IDotNetObjectReference*/ objectReference, /*string*/ methodIdentifier)
            {
                /*var*/ let type = $.$spc.System.Object.GetType.call(objectReference.Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value);
                /*var*/ let assemblyMethods = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedMethodsByType.GetOrAdd(type, new ($.$spc.System.Func$$$($.$spc.System.Type, $.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)))))().$ctor(null, ScanTypeForCallableMethods));
                /*var*/ let result;
                if (assemblyMethods.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue(methodIdentifier, $.$ref(() => result, ($v) => result = $v, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type))), [$.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type))]))
                {
                    return result;
                }
                else 
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10(`The type '${type.Name}' does not contain a public invokable method with [${"JSInvokableAttribute"}(\"${methodIdentifier}\")].`);
                }
                /*static Dictionary<string, (MethodInfo, Type[])>*/  function ScanTypeForCallableMethods(/*Type*/ type)
                {
                    /*var*/ let result = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type))))().$ctor$3($.$spc.System.StringComparer.Ordinal);
                    let $i2 = 0;
                    let $arr2 = type.GetMethods$1(4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/);
                    while ($i2 < $arr2.length)
                    {
                        let method = $arr2[$i2++];
                        if (method.ContainsGenericParameters$1 || !method.IsDefined($.$mj.Microsoft.JSInterop.JSInvokableAttribute.$type, false))
                        {
                            continue;
                        }
                        var $en4 = $.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$16($.$mj.Microsoft.JSInterop.JSInvokableAttribute, method, false).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var attr = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*var*/ let identifier = attr.Identifier ?? method.Name;
                                /*var*/ let parameterTypes = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetParameterTypes(method);
                                if (result.ContainsKey(identifier))
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`The type ${type.Name} contains more than one ` + `[JSInvokable] method with identifier '${identifier}'. All [JSInvokable] methods within the same ` + "type must have different identifiers. You can pass a custom identifier as a parameter to " + `the [JSInvokable] attribute.`);
                                }
                                result.Add(identifier, new ($.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)))().$ctor$2(method, parameterTypes));
                            }
                        }
                    }
                    return result;
                }
            }
            static /*Dictionary<string, (MethodInfo, Type[])> */ ScanAssemblyForCallableMethods(/*AssemblyKey*/ assemblyKey)
            {
                /*var*/ let result = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type))))().$ctor$3($.$spc.System.StringComparer.Ordinal);
                /*var*/ let exportedTypes = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetRequiredLoadedAssembly(assemblyKey).GetExportedTypes();
                let $i1 = 0;
                let $arr1 = exportedTypes;
                while ($i1 < $arr1.length)
                {
                    let type = $arr1[$i1++];
                    let $i2 = 0;
                    let $arr2 = type.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                    while ($i2 < $arr2.length)
                    {
                        let method = $arr2[$i2++];
                        if (method.ContainsGenericParameters$1 || !method.IsDefined($.$mj.Microsoft.JSInterop.JSInvokableAttribute.$type, false))
                        {
                            continue;
                        }
                        var $en4 = $.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$16($.$mj.Microsoft.JSInterop.JSInvokableAttribute, method, false).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var attr = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*var*/ let identifier = attr.Identifier ?? method.Name;
                                /*var*/ let parameterTypes = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.GetParameterTypes(method);
                                if (result.ContainsKey(identifier))
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`The assembly '${assemblyKey.AssemblyName}' contains more than one ` + `[JSInvokable] method with identifier '${identifier}'. All [JSInvokable] methods within the same ` + `assembly must have different identifiers. You can pass a custom identifier as a parameter to ` + `the [JSInvokable] attribute.`);
                                }
                                result.Add(identifier, new ($.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)))().$ctor$2(method, parameterTypes));
                            }
                        }
                    }
                }
                return result;
            }
            static /*Type[] */ GetParameterTypes(/*MethodInfo*/ method)
            {
                /*var*/ let parameters = method.GetParameters();
                if (parameters.length === 0)
                {
                    return $.$spc.System.Type.EmptyTypes;
                }
                /*var*/ let parameterTypes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), null, [parameters.length], null);
                for(/*var*/ let i = 0; i < parameters.length; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(parameterTypes, $.$spc.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                }
                return parameterTypes;
            }
            static /*Assembly */ GetRequiredLoadedAssembly(/*AssemblyKey*/ assemblyKey)
            {
                /*Assembly?*/ let assembly = null;
                let $i1 = 0;
                let $arr1 = $.$spc.System.AppDomain.CurrentDomain.GetAssemblies();
                while ($i1 < $arr1.length)
                {
                    let a = $arr1[$i1++];
                    if (new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey().$ctor$2(a).Equals$2(assemblyKey))
                    {
                        assembly = a;
                    }
                }
                return $.$firstOf(assembly, () => { throw new $.$spc.System.ArgumentException().$ctor$10(`There is no loaded assembly with the name '${assemblyKey.AssemblyName}'.`) });
            }
            static $_MetadataUpdateHandler;
            static get MetadataUpdateHandler()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher;
                return $cls.$_MetadataUpdateHandler ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.MetadataUpdateHandler", ($self) => class MetadataUpdateHandler
                {
                    static /*void */ ClearCache(/*Type[]?*/ _)
                    {
                        $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedMethodsByAssembly.Clear();
                        $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedMethodsByType.Clear();
                        $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher._cachedConvertToTaskByType.Clear();
                    }
                    static $h = 1179678;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"_","p":0}],"n":"ClearCache","d":1179678,"h":4296146974,"f":33}],"d":1048606,"h":1179678}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `DotNetDispatcher.MetadataUpdateHandler`; }
                }, $cls, ($v) => $cls.$_MetadataUpdateHandler = $v);
            }
            static $_AssemblyKey;
            static get AssemblyKey()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher;
                return $cls.$_AssemblyKey ??= $asm.$nstr("$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey", ($self) => class AssemblyKey extends $.$spc.System.ValueType
                {
                    $ctor$2(/*Assembly*/ assembly)
                    {
                        super.$ctor$1();
                        {
                            this.Assembly = assembly;
                            this.AssemblyName = assembly.GetName().Name;
                        }
                        return this;
                    }
                    $ctor$3(/*string*/ assemblyName)
                    {
                        super.$ctor$1();
                        {
                            this.Assembly = null;
                            this.AssemblyName = assemblyName;
                        }
                        return this;
                    }
                    /*Assembly?*/ Assembly = null;
                    /*string*/ AssemblyName = null;
                    /*bool */ Equals$2(/*AssemblyKey*/ other)
                    {
                        if ($.$spc.System.Reflection.Assembly.op_Inequality(this.Assembly, null) && $.$spc.System.Reflection.Assembly.op_Inequality(other.Assembly, null))
                        {
                            return $.$spc.System.Reflection.Assembly.op_Equality(this.Assembly, other.Assembly);
                        }
                        return $.$spc.System.String.Equals$3.call(this.AssemblyName, other.AssemblyName, 4/*StringComparison.Ordinal*/);
                    }
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        return $.$spc.System.StringComparer.Ordinal.GetHashCode$2(this.AssemblyName);
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey.GetHashCode.apply(this, arguments); }
                    //Generated interface implemetation for System.IEquatable<Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey>.Equals(Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.AssemblyName = this.AssemblyName;
                        return copy;
                    }
                    static $h = 1114142;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":73465857,"g":{"r":0,"d":0,"h":21475950622,"f":1},"n":"Assembly","d":1114142,"h":17180983326,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360852510,"f":1},"n":"AssemblyName","d":1114142,"h":30065885214,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":1114142}],"n":"Equals","o":"@$2","d":1114142,"h":38655819806,"f":1},{"r":655361,"n":"GetHashCode","d":1114142,"h":42950787102,"f":32769}],"c":[{"p":[{"n":"assembly","p":73465857}],"n":".ctor","o":"$ctor$2","d":1114142,"h":4296081438,"f":1},{"p":[{"n":"assemblyName","p":1310721}],"n":".ctor","o":"$ctor$3","d":1114142,"h":8591048734,"f":1},{"n":".ctor","o":"$ctor$4","d":1114142,"h":47245754398,"f":1}],"i":[$.$spc.System.IEquatable$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey).$h],"d":1048606,"h":1114142}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey) ]; }
                    static get $fullName() { return `DotNetDispatcher.AssemblyKey`; }
                }, $cls, ($v) => $cls.$_AssemblyKey = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DisposeDotNetObjectReferenceMethodName = "__Dispose";
                }
                {
                    this.DotNetObjectRefKey = $.$stj.System.Text.Json.JsonEncodedText.Encode("__dotNetObject", null);
                }
                {
                    this._cachedMethodsByAssembly = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey, $.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)))))().$ctor$1();
                }
                {
                    this._cachedMethodsByType = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)))))().$ctor$1();
                }
                {
                    this._cachedConvertToTaskByType = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Threading.Tasks.Task)))().$ctor$1();
                }
                {
                    this._taskConverterMethodInfo = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.$type.GetMethod$2("CreateValueTaskConverter", 32/*BindingFlags.NonPublic*/ | 8/*BindingFlags.Static*/);
                }
            }
            static $h = 1048606;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"jsRuntime","p":2949150},{"n":"invocationInfo","p":1245214,"f":8},{"n":"argsJson","p":1310721}],"n":"Invoke","d":1048606,"h":30065819678,"f":33},{"r":65537,"p":[{"n":"jsRuntime","p":2949150},{"n":"invocationInfo","p":1245214},{"n":"argsJson","p":1310721}],"n":"BeginInvokeDotNet","d":1048606,"h":34360786974,"f":33},{"r":65537,"p":[{"n":"task","p":133300225},{"n":"jsRuntime","p":2949150},{"n":"invocationInfo","p":1245214,"f":8}],"n":"EndInvokeDotNetAfterTask","d":1048606,"h":38655754270,"f":34},{"r":131073,"p":[{"n":"jsRuntime","p":2949150},{"n":"callInfo","p":1245214,"f":8},{"n":"objectReference","p":1572894},{"n":"argsJson","p":1310721}],"n":"InvokeSynchronously","d":1048606,"h":42950721566,"f":34},{"r":0,"p":[{"n":"jsRuntime","p":2949150},{"n":"methodIdentifier","p":1310721},{"n":"arguments","p":1310721},{"n":"parameterTypes","p":0}],"n":"ParseArguments","d":1048606,"h":47245688862,"f":40},{"r":65537,"p":[{"n":"jsRuntime","p":2949150},{"n":"arguments","p":1310721}],"n":"EndInvokeJS","d":1048606,"h":51540656158,"f":33},{"r":65537,"p":[{"n":"jsRuntime","p":2949150},{"n":"id","p":655361},{"n":"data","p":0}],"n":"ReceiveByteArray","d":1048606,"h":55835623454,"f":33},{"r":$.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)).$h,"p":[{"n":"assemblyKey","p":1114142},{"n":"methodIdentifier","p":1310721}],"n":"GetCachedMethodInfo","d":1048606,"h":60130590750,"f":34},{"r":133300225,"p":[{"n":"type","p":142606337},{"n":"obj","p":131073}],"n":"GetTaskByType","d":1048606,"h":64425558046,"f":34},{"r":133300225,"p":[{"n":"result","p":131073}],"g":["T"],"n":"CreateValueTaskConverter","d":1048606,"h":68720525342,"f":131106},{"r":$.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)).$h,"p":[{"n":"objectReference","p":1572894},{"n":"methodIdentifier","p":1310721}],"n":"GetCachedMethodInfo","o":"@$1","d":1048606,"h":73015492638,"f":34},{"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type))).$h,"p":[{"n":"assemblyKey","p":1114142}],"n":"ScanAssemblyForCallableMethods","d":1048606,"h":77310459934,"f":34},{"r":0,"p":[{"n":"method","p":79626241}],"n":"GetParameterTypes","d":1048606,"h":81605427230,"f":34},{"r":73465857,"p":[{"n":"assemblyKey","p":1114142}],"n":"GetRequiredLoadedAssembly","d":1048606,"h":85900394526,"f":34}],"l":[{"t":1310721,"n":"DisposeDotNetObjectReferenceMethodName","d":1048606,"h":4296015902,"f":34},{"t":2353296,"n":"DotNetObjectRefKey","d":1048606,"h":8590983198,"f":40},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.AssemblyKey, $.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)))).$h,"n":"_cachedMethodsByAssembly","d":1048606,"h":12885950494,"f":34},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$spc.System.ValueTuple$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Type)))).$h,"n":"_cachedMethodsByType","d":1048606,"h":17180917790,"f":34},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Threading.Tasks.Task)).$h,"n":"_cachedConvertToTaskByType","d":1048606,"h":21475885086,"f":34},{"t":79626241,"n":"_taskConverterMethodInfo","d":1048606,"h":25770852382,"f":34}],"j":[1179678,1114142],"h":1048606}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `DotNetDispatcher`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil", ($self) => class TaskGenericsUtil
        {
            /*ConcurrentDictionary<Type, ITaskResultGetter>*/ static _cachedResultGetters = null;
            /*ConcurrentDictionary<Type, ITcsResultSetter>*/ static _cachedResultSetters = null;
            static /*void */ SetTaskCompletionSourceResult(/*object*/ taskCompletionSource, /*object?*/ result)
            {
                return $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetResult(taskCompletionSource, result);
            }
            static /*void */ SetTaskCompletionSourceException(/*object*/ taskCompletionSource, /*Exception*/ exception)
            {
                return $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetException(taskCompletionSource, exception);
            }
            static /*Type */ GetTaskCompletionSourceResultType(/*object*/ taskCompletionSource)
            {
                return $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.CreateResultSetter(taskCompletionSource).Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$ResultType;
            }
            static /*object? */ GetTaskResult(/*Task*/ task)
            {
                /*var*/ let getter = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil._cachedResultGetters.GetOrAdd($.$spc.System.Object.GetType.call(task), new ($.$spc.System.Func$$$($.$spc.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter))().$ctor(this,  (/*taskInstanceType*/ taskInstanceType) =>
                {
                    /*var*/ let resultType = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.GetTaskResultType(taskInstanceType);
                    return $.$spc.System.Type.op_Equality$1(resultType, null) ? new $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.VoidTaskResultGetter().$ctor$1() : $.$cast($.$spc.System.Activator.CreateInstance$3($.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TaskResultGetter$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ resultType ], null, null))), $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter);
                }));
                return getter.Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITaskResultGetter$GetResult(task);
            }
            static /*Type? */ GetTaskResultType(/*Type*/ taskType)
            {
                while($.$spc.System.Type.op_Inequality$1(taskType, $.$spc.System.Threading.Tasks.Task.$type) && (!taskType.IsGenericType || $.$spc.System.Type.op_Inequality$1(taskType.GetGenericTypeDefinition(), $.$spc.System.Threading.Tasks.Task$$().$type)))
                {
                    taskType = $.$firstOf(taskType.BaseType, () => { throw new $.$spc.System.ArgumentException().$ctor$10(`The type '${taskType.FullName}' is not inherited from '${$.$spc.System.Threading.Tasks.Task.$type.FullName}'.`) });
                }
                return taskType.IsGenericType ? $.$spc.System.Array.$ReadT1.call(taskType.GetGenericArguments(), 0) : null;
            }
            static $_ITcsResultSetter;
            static get ITcsResultSetter()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return $cls.$_ITcsResultSetter ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter", ($self) => class ITcsResultSetter
                {
                    static $h = 2097182;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":142606337,"g":{"r":0,"d":0,"h":8592031774,"f":257},"n":"ResultType","o":"Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$ResultType","d":2097182,"h":4297064478,"f":257}],"m":[{"r":65537,"p":[{"n":"taskCompletionSource","p":131073},{"n":"result","p":131073}],"n":"SetResult","o":"Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetResult","d":2097182,"h":12886999070,"f":257},{"r":65537,"p":[{"n":"taskCompletionSource","p":131073},{"n":"exception","p":47185921}],"n":"SetException","o":"Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetException","d":2097182,"h":17181966366,"f":257}],"d":1966110,"h":2097182}; }
                    static get $fullName() { return `TaskGenericsUtil.ITcsResultSetter`; }
                }, $cls, ($v) => $cls.$_ITcsResultSetter = $v);
            }
            static $_ITaskResultGetter;
            static get ITaskResultGetter()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return $cls.$_ITaskResultGetter ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter", ($self) => class ITaskResultGetter
                {
                    static $h = 2031646;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"task","p":133300225}],"n":"GetResult","o":"Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITaskResultGetter$GetResult","d":2031646,"h":4296998942,"f":257}],"d":1966110,"h":2031646}; }
                    static get $fullName() { return `TaskGenericsUtil.ITaskResultGetter`; }
                }, $cls, ($v) => $cls.$_ITaskResultGetter = $v);
            }
            static $_TaskResultGetter$$;
            static TaskResultGetter$$(T)
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return ($cls.$_TaskResultGetter$$ ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TaskResultGetter<>", (T) => $asm.$gt("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TaskResultGetter<>", [T], ($self) => class TaskResultGetter$$ extends $.$spc.System.Object
                {
                    /*object? */ GetResult(/*Task*/ task)
                    {
                        return $.$box(($.$cast(task, $.$spc.System.Threading.Tasks.Task$$(T))).Result, T);
                    }
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter.GetResult(System.Threading.Tasks.Task)
                    Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITaskResultGetter$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 2162718;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"task","p":133300225}],"n":"GetResult","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[2031646],"g":[T?.$h??1507328],"r":1,"d":1966110,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter ]; }
                    static get $fullName() { return `TaskGenericsUtil.TaskResultGetter<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_TaskResultGetter$$ = $v))(T);
            }
            static $_VoidTaskResultGetter;
            static get VoidTaskResultGetter()
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return $cls.$_VoidTaskResultGetter ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.VoidTaskResultGetter", ($self) => class VoidTaskResultGetter extends $.$spc.System.Object
                {
                    /*object? */ GetResult(/*Task*/ task)
                    {
                        task.Wait();
                        return null;
                    }
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter.GetResult(System.Threading.Tasks.Task)
                    Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITaskResultGetter$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 2293790;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"task","p":133300225}],"n":"GetResult","d":2293790,"h":4297261086,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2293790,"h":8592228382,"f":1}],"i":[2031646],"d":1966110,"h":2293790}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter ]; }
                    static get $fullName() { return `TaskGenericsUtil.VoidTaskResultGetter`; }
                }, $cls, ($v) => $cls.$_VoidTaskResultGetter = $v);
            }
            static $_TcsResultSetter$$;
            static TcsResultSetter$$(T)
            {
                let $cls = $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil;
                return ($cls.$_TcsResultSetter$$ ??= $asm.$ncls("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TcsResultSetter<>", (T) => $asm.$gt("$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TcsResultSetter<>", [T], ($self) => class TcsResultSetter$$ extends $.$spc.System.Object
                {
                    /*Type */ get ResultType()
                    {
                        return T.$type;
                    }
                    /*void */ SetResult(/*object*/ tcs, /*object?*/ result)
                    {
                        /*var*/ let typedTcs = $.$cast(tcs, $.$spc.System.Threading.Tasks.TaskCompletionSource$$(T));
                        let resultT;
                        /*var*/ let typedResult = $.$is(result, T, { set $v(v){ resultT = v; } }) ? resultT : result === null && T.$type.IsGenericType && $.$spc.System.Type.op_Equality$1(T.$type.GetGenericTypeDefinition(), $.$spc.System.Nullable$$().$type) ? $.$default(T) : $.$cast($.$spc.System.Convert.ChangeType$3(result, T.$type, $.$spc.System.Globalization.CultureInfo.InvariantCulture), T);
                        typedTcs.SetResult(typedResult);
                    }
                    /*void */ SetException(/*object*/ tcs, /*Exception*/ exception)
                    {
                        /*var*/ let typedTcs = $.$cast(tcs, $.$spc.System.Threading.Tasks.TaskCompletionSource$$(T));
                        typedTcs.SetException(exception);
                    }
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.ResultType.get
                    get Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$ResultType()
                    {
                        return this.ResultType;
                    }
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.SetResult(object, object?)
                    Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetResult()
                    {
                        return this.SetResult(...arguments);
                    }
                    //Generated interface implemetation for Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter.SetException(object, System.Exception)
                    Microsoft$JSInterop$Infrastructure$TaskGenericsUtil$ITcsResultSetter$SetException()
                    {
                        return this.SetException(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 2228254;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},"n":"ResultType","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"m":[{"r":65537,"p":[{"n":"tcs","p":131073},{"n":"result","p":131073}],"n":"SetResult","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"r":65537,"p":[{"n":"tcs","p":131073},{"n":"exception","p":47185921}],"n":"SetException","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"i":[2097182],"g":[T?.$h??1507328],"r":1,"d":1966110,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter ]; }
                    static get $fullName() { return `TaskGenericsUtil.TcsResultSetter<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_TcsResultSetter$$ = $v))(T);
            }
            static /*ITcsResultSetter */ CreateResultSetter(/*object*/ taskCompletionSource)
            {
                return $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil._cachedResultSetters.GetOrAdd($.$spc.System.Object.GetType.call(taskCompletionSource), new ($.$spc.System.Func$$$($.$spc.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter))().$ctor(this,  (/**/ tcsType) =>
                {
                    /*var*/ let resultType = $.$spc.System.Array.$ReadT1.call(tcsType.GetGenericArguments(), 0);
                    return $.$cast($.$spc.System.Activator.CreateInstance$3($.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.TcsResultSetter$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ resultType ], null, null))), $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter);
                }));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._cachedResultGetters = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter))().$ctor$1();
                }
                {
                    this._cachedResultSetters = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter))().$ctor$1();
                }
            }
            static $h = 1966110;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"taskCompletionSource","p":131073},{"n":"result","p":131073}],"n":"SetTaskCompletionSourceResult","d":1966110,"h":12886867998,"f":33},{"r":65537,"p":[{"n":"taskCompletionSource","p":131073},{"n":"exception","p":47185921}],"n":"SetTaskCompletionSourceException","d":1966110,"h":17181835294,"f":33},{"r":142606337,"p":[{"n":"taskCompletionSource","p":131073}],"n":"GetTaskCompletionSourceResultType","d":1966110,"h":21476802590,"f":33},{"r":131073,"p":[{"n":"task","p":133300225}],"n":"GetTaskResult","d":1966110,"h":25771769886,"f":33},{"r":142606337,"p":[{"n":"taskType","p":142606337}],"n":"GetTaskResultType","d":1966110,"h":30066737182,"f":34},{"r":2097182,"p":[{"n":"taskCompletionSource","p":131073}],"n":"CreateResultSetter","d":1966110,"h":55836540958,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITaskResultGetter).$h,"n":"_cachedResultGetters","d":1966110,"h":4296933406,"f":34},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$mj.Microsoft.JSInterop.Infrastructure.TaskGenericsUtil.ITcsResultSetter).$h,"n":"_cachedResultSetters","d":1966110,"h":8591900702,"f":34}],"j":[2097182,2031646,2162718,2293790,2228254],"h":1966110}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `TaskGenericsUtil`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.DotNetStreamReference", ($self) => class DotNetStreamReference extends $.$spc.System.Object
        {
            $ctor$1(/*Stream*/ stream, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    this.Stream = $.$firstOf(stream, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("stream") });
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*Stream*/ Stream = null;
            /*bool*/ LeaveOpen = false;
            /*void */ Dispose()
            {
                if (!this.LeaveOpen)
                {
                    this.Stream.Dispose();
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 262174;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":62128129,"g":{"r":0,"d":0,"h":17180131358,"f":1},"n":"Stream","d":262174,"h":12885164062,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065033246,"f":1},"n":"LeaveOpen","d":262174,"h":25770065950,"f":1}],"m":[{"r":65537,"n":"Dispose","d":262174,"h":34360000542,"f":1}],"c":[{"p":[{"n":"stream","p":62128129},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$1","d":262174,"h":4295229470,"f":1}],"i":[57475073],"h":262174}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `DotNetStreamReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder<>", (T) => $asm.$gt("$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder<>", [T], ($self) => class ArrayBuilder$$ extends $.$spc.System.Object
        {
            /*T[]*/ _items = null;
            /*int*/ _itemsInUse = 0;
            /*T[]*/ static Empty = null;
            /*ArrayPool<T>*/ _arrayPool = null;
            /*int*/ _minCapacity = 0;
            /*bool*/ _disposed = false;
            $ctor$1(/*int*/ minCapacity, /*ArrayPool<T>*/ arrayPool)
            {
                super.$ctor();
                {
                    this._arrayPool = arrayPool ?? $.$spc.System.Buffers.ArrayPool$$(T).Shared;
                    this._minCapacity = minCapacity;
                    this._items = $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).Empty;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._itemsInUse;
            }
            /*T[] */ get Buffer()
            {
                return this._items;
            }
            /*int */ Append(/*in T*/ item)
            {
                if (this._itemsInUse === this._items.length)
                {
                    this.GrowBuffer(((this._items.length * 2) | 0));
                }
                /*var*/ let indexOfAppendedItem = this._itemsInUse++;
                $.$spc.System.Array.$WriteT1.call(this._items, item.$v, indexOfAppendedItem);
                return indexOfAppendedItem;
            }
            /*int */ Append$1(/*T[]*/ source, /*int*/ startIndex, /*int*/ length)
            {
                return this.Append$2($.$spc.System.Span$$(T).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9(T, source, startIndex, length)));
            }
            /*int */ Append$2(/*ReadOnlySpan<T>*/ source)
            {
                /*var*/ let requiredCapacity = ((this._itemsInUse + source.Length) | 0);
                if (this._items.length < requiredCapacity)
                {
                    /*var*/ let candidateCapacity = $.$spc.System.Math.Max$4(((this._items.length * 2) | 0), this._minCapacity);
                    while(candidateCapacity < requiredCapacity)
                    {
                        candidateCapacity *= 2;
                    }
                    this.GrowBuffer(candidateCapacity);
                }
                source.CopyTo($.$spc.System.MemoryExtensions.AsSpan(T, this._items, this._itemsInUse));
                /*var*/ let startIndexOfAppendedItems = this._itemsInUse;
                this._itemsInUse += source.Length;
                return startIndexOfAppendedItems;
            }
            /*void */ Overwrite(/*int*/ index, /*in T*/ value)
            {
                if (index > this._itemsInUse)
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                $.$spc.System.Array.$WriteT1.call(this._items, value.$v, index);
            }
            /*void */ RemoveLast()
            {
                if (this._itemsInUse === 0)
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                this._itemsInUse--;
                $.$spc.System.Array.$WriteT1.call(this._items, $.$default(T), this._itemsInUse);
            }
            /*void */ InsertExpensive(/*int*/ index, /*T*/ value)
            {
                if (index > this._itemsInUse)
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).ThrowIndexOutOfBoundsException();
                }
                if (this._itemsInUse === this._items.length)
                {
                    this.GrowBuffer(((this._items.length * 2) | 0));
                }
                $.$spc.System.Array.Copy$1(this._items, index, this._items, ((index + 1) | 0), ((this._itemsInUse - index) | 0));
                this._itemsInUse++;
                $.$spc.System.Array.$WriteT1.call(this._items, value, index);
            }
            /*void */ Clear()
            {
                this.ReturnBuffer();
                this._items = $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).Empty;
                this._itemsInUse = 0;
            }
            /*void */ GrowBuffer(/*int*/ desiredCapacity)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf$1(this._disposed, null);
                /*var*/ let newCapacity = $.$spc.System.Math.Max$4(desiredCapacity, this._minCapacity);
                $.$spc.System.Diagnostics.Debug.Assert$1(newCapacity > this._items.length, "newCapacity > _items.Length");
                /*var*/ let newItems = this._arrayPool.Rent(newCapacity);
                $.$spc.System.Array.Copy(this._items, newItems, this._itemsInUse);
                this.ReturnBuffer();
                this._items = newItems;
            }
            /*void */ ReturnBuffer()
            {
                if (!$.$spc.System.Object.ReferenceEquals(this._items, $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).Empty))
                {
                    $.$spc.System.Array.Clear$1(this._items, 0, this._itemsInUse);
                    this._arrayPool.Return(this._items, false);
                }
            }
            /*void */ Dispose()
            {
                if (!this._disposed)
                {
                    this._disposed = true;
                    this.ReturnBuffer();
                    this._items = $.$mj.Microsoft.JSInterop.Infrastructure.ArrayBuilder$$(T).Empty;
                    this._itemsInUse = 0;
                }
            }
            static /*void */ ThrowIndexOutOfBoundsException()
            {
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("index");
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$spc.System.Array.Empty(T);
                }
            }
            static $h = 917534;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},{"p":0,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},"n":"Buffer","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1}],"m":[{"r":655361,"p":[{"n":"item","p":T?.$h??1507328,"f":8}],"n":"Append","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},{"r":655361,"p":[{"n":"source","p":0},{"n":"startIndex","p":655361},{"n":"length","p":655361}],"n":"Append","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":8},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$(T).$h}],"n":"Append","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":8},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":T?.$h??1507328,"f":8}],"n":"Overwrite","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1},{"r":65537,"n":"RemoveLast","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":T?.$h??1507328}],"n":"InsertExpensive","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":1},{"r":65537,"n":"Clear","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1},{"r":65537,"p":[{"n":"desiredCapacity","p":655361}],"n":"GrowBuffer","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":4},{"r":65537,"n":"ReturnBuffer","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":2},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":1},{"r":65537,"n":"ThrowIndexOutOfBoundsException","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":34}],"l":[{"t":0,"n":"_items","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4},{"t":655361,"n":"_itemsInUse","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4},{"t":0,"n":"Empty","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":34},{"t":$.$spc.System.Buffers.ArrayPool$$(T).$h,"n":"_arrayPool","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":655361,"n":"_minCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":262145,"n":"_disposed","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2}],"c":[{"p":[{"n":"minCapacity","p":655361,"f":65,"v":32},{"n":"arrayPool","p":$.$spc.System.Buffers.ArrayPool$$(T).$h,"f":65}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"i":[57475073],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `ArrayBuilder<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$mj.Microsoft.JSInterop.DotNetObjectReference<>", (TValue) => $asm.$gt("$mj.Microsoft.JSInterop.DotNetObjectReference<>", [TValue], ($self) => class DotNetObjectReference$$ extends $.$spc.System.Object
        {
            /*TValue*/ _value = $.$default(TValue);
            /*long*/ _objectId = 0n;
            /*JSRuntime?*/ _jsRuntime = null;
            $ctor$1(/*TValue*/ value)
            {
                super.$ctor();
                {
                    this._value = value;
                }
                return this;
            }
            /*TValue */ get Value()
            {
                this.ThrowIfDisposed();
                return this._value;
            }
            /*long */ get ObjectId()
            {
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this._objectId !== 0n, "Accessing ObjectId without tracking is always incorrect.");
                return this._objectId;
            }
            /*long */ set ObjectId(value)
            {
                this.ThrowIfDisposed();
                this._objectId = value;
            }
            /*JSRuntime? */ get JSRuntime()
            {
                this.ThrowIfDisposed();
                return this._jsRuntime;
            }
            /*JSRuntime? */ set JSRuntime(value)
            {
                this.ThrowIfDisposed();
                this._jsRuntime = value;
            }
            /*object */ get Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value()
            {
                return $.$box(this.Value, TValue);
            }
            /*bool*/ Disposed = false;
            /*void */ Dispose()
            {
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this._jsRuntime?.ReleaseObjectReference(this._objectId);
                }
            }
            /*void */ ThrowIfDisposed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Disposed = false;
            }
            static $h = 196638;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":TValue?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},{"p":917505,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":8},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":8},"n":"ObjectId","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":8},{"p":2949150,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":8},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":8},"n":"JSRuntime","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":8},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"{1572894}.Value","o":"Microsoft$JSInterop$Infrastructure$IDotNetObjectReference$Value","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1100000000n),"f":8},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2},"n":"Disposed","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":8}],"m":[{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},{"r":65537,"n":"ThrowIfDisposed","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":8}],"l":[{"t":TValue?.$h??1507328,"n":"_value","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":917505,"n":"_objectId","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":2949150,"n":"_jsRuntime","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"value","p":TValue?.$h??1507328}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"i":[1572894,57475073],"g":[TValue?.$h??1507328],"s":[{"n":"TValue","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.Infrastructure.IDotNetObjectReference, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `DotNetObjectReference<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$mj.Microsoft.JSInterop.Implementation.JSObjectReference", ($self) => class JSObjectReference extends $.$spc.System.Object
        {
            /*JSRuntime*/ _jsRuntime = null;
            /*bool*/ Disposed = false;
            /*long*/ Id = 0n;
            $ctor$1(/*JSRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor();
                {
                    this._jsRuntime = jsRuntime;
                    this.Id = id;
                }
                return this;
            }
            /*ValueTask<TValue> */ InvokeAsync(TValue, /*string*/ identifier, /*object?[]?*/ args)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$2(TValue, this.Id, identifier, 1/*JSCallType.FunctionCall*/, args);
            }
            /*ValueTask<TValue> */ InvokeAsync$1(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$3(TValue, this.Id, identifier, 1/*JSCallType.FunctionCall*/, cancellationToken, args);
            }
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync(/*string*/ identifier, /*object?[]?*/ args)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$2($.$mj.Microsoft.JSInterop.IJSObjectReference, this.Id, identifier, 2/*JSCallType.ConstructorCall*/, args);
            }
            /*ValueTask<IJSObjectReference> */ InvokeConstructorAsync$1(/*string*/ identifier, /*CancellationToken*/ cancellationToken, /*object?[]?*/ args)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$3($.$mj.Microsoft.JSInterop.IJSObjectReference, this.Id, identifier, 2/*JSCallType.ConstructorCall*/, cancellationToken, args);
            }
            /*ValueTask<TValue> */ GetValueAsync(TValue, /*string*/ identifier)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$2(TValue, this.Id, identifier, 3/*JSCallType.GetValue*/, null);
            }
            /*ValueTask<TValue> */ GetValueAsync$1(TValue, /*string*/ identifier, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.InvokeAsync$3(TValue, this.Id, identifier, 3/*JSCallType.GetValue*/, cancellationToken, null);
            }
            /*ValueTask *//*async*/  SetValueAsync(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfDisposed();
                    await this._jsRuntime.InvokeAsync$2(TValue, this.Id, identifier, 4/*JSCallType.SetValue*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null));
                });
            }
            /*ValueTask *//*async*/  SetValueAsync$1(TValue, /*string*/ identifier, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfDisposed();
                    await this._jsRuntime.InvokeAsync$3(TValue, this.Id, identifier, 4/*JSCallType.SetValue*/, cancellationToken, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TValue.$type, [ $.$box(value, TValue) ], null, null));
                });
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (!this.Disposed)
                    {
                        this.Disposed = true;
                        await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this._jsRuntime, "DotNet.disposeJSObjectReferenceById", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(this.Id, $.$spc.System.Int64) ], null, null));
                    }
                });
            }
            /*void */ ThrowIfDisposed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeAsync<TValue>(string, object?[]?)
            Microsoft$JSInterop$IJSObjectReference$InvokeAsync()
            {
                return this.InvokeAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeAsync<TValue>(string, System.Threading.CancellationToken, object?[]?)
            Microsoft$JSInterop$IJSObjectReference$InvokeAsync$1()
            {
                return this.InvokeAsync$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeConstructorAsync(string, object?[]?)
            Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync()
            {
                return this.InvokeConstructorAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.InvokeConstructorAsync(string, System.Threading.CancellationToken, object?[]?)
            Microsoft$JSInterop$IJSObjectReference$InvokeConstructorAsync$1()
            {
                return this.InvokeConstructorAsync$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.GetValueAsync<TValue>(string)
            Microsoft$JSInterop$IJSObjectReference$GetValueAsync()
            {
                return this.GetValueAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.GetValueAsync<TValue>(string, System.Threading.CancellationToken)
            Microsoft$JSInterop$IJSObjectReference$GetValueAsync$1()
            {
                return this.GetValueAsync$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.SetValueAsync<TValue>(string, TValue)
            Microsoft$JSInterop$IJSObjectReference$SetValueAsync()
            {
                return this.SetValueAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSObjectReference.SetValueAsync<TValue>(string, TValue, System.Threading.CancellationToken)
            Microsoft$JSInterop$IJSObjectReference$SetValueAsync$1()
            {
                return this.SetValueAsync$1(...arguments);
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Disposed = false;
            }
            static $h = 720926;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180590110,"f":8},"s":{"r":0,"d":0,"h":21475557406,"f":8},"n":"Disposed","d":720926,"h":12885622814,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":34360459294,"f":16},"n":"Id","d":720926,"h":30065491998,"f":16}],"m":[{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","d":720926,"h":42950393886,"f":131073},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"g":["TValue"],"n":"InvokeAsync","o":"@$1","d":720926,"h":47245361182,"f":131073},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"n":"InvokeConstructorAsync","d":720926,"h":51540328478,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$mj.Microsoft.JSInterop.IJSObjectReference).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193},{"n":"args","p":0}],"n":"InvokeConstructorAsync","o":"@$1","d":720926,"h":55835295774,"f":1},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721}],"g":["TValue"],"n":"GetValueAsync","d":720926,"h":60130263070,"f":131073},{"r":(TValue) => $.$spc.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"identifier","p":1310721},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"GetValueAsync","o":"@$1","d":720926,"h":64425230366,"f":131073},{"r":136118273,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"SetValueAsync","d":720926,"h":68720197662,"f":135169},{"r":136118273,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"SetValueAsync","o":"@$1","d":720926,"h":73015164958,"f":135169},{"r":136118273,"n":"DisposeAsync","d":720926,"h":77310132254,"f":4097},{"r":65537,"n":"ThrowIfDisposed","d":720926,"h":81605099550,"f":4}],"l":[{"t":2949150,"n":"_jsRuntime","d":720926,"h":4295688222,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":2949150},{"n":"id","p":917505}],"n":".ctor","o":"$ctor$1","d":720926,"h":38655426590,"f":16}],"i":[458782,56885249],"h":720926}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `JSObjectReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSInvokableAttribute", ($self) => class JSInvokableAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ Identifier = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ identifier)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(identifier, "identifier");
                    this.Identifier = identifier;
                }
                return this;
            }
            static $h = 2818078;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12887719966,"f":1},"n":"Identifier","d":2818078,"h":8592752670,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":2818078,"h":17182687262,"f":1},{"p":[{"n":"identifier","p":1310721}],"n":".ctor","o":"$ctor$3","d":2818078,"h":21477654558,"f":1}],"h":2818078,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `JSInvokableAttribute`; }
        });
        
        $asm.$str("$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo", ($self) => class DotNetInvocationInfo extends $.$spc.System.ValueType
        {
            $ctor$2(/*string?*/ assemblyName, /*string*/ methodIdentifier, /*long*/ dotNetObjectId, /*string?*/ callId)
            {
                super.$ctor$1();
                {
                    this.CallId = callId;
                    this.AssemblyName = assemblyName;
                    this.MethodIdentifier = methodIdentifier;
                    this.DotNetObjectId = dotNetObjectId;
                }
                return this;
            }
            /*string?*/ AssemblyName = null;
            /*string*/ MethodIdentifier = null;
            /*long*/ DotNetObjectId = 0n;
            /*string?*/ CallId = null;
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.AssemblyName = this.AssemblyName;
                copy.MethodIdentifier = this.MethodIdentifier;
                copy.DotNetObjectId = this.DotNetObjectId;
                copy.CallId = this.CallId;
                return copy;
            }
            static $h = 1245214;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181114398,"f":1},"n":"AssemblyName","d":1245214,"h":12886147102,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066016286,"f":1},"n":"MethodIdentifier","d":1245214,"h":25771048990,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":42950918174,"f":1},"n":"DotNetObjectId","d":1245214,"h":38655950878,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835820062,"f":1},"n":"CallId","d":1245214,"h":51540852766,"f":1}],"c":[{"p":[{"n":"assemblyName","p":1310721},{"n":"methodIdentifier","p":1310721},{"n":"dotNetObjectId","p":917505},{"n":"callId","p":1310721}],"n":".ctor","o":"$ctor$2","d":1245214,"h":4296212510,"f":1},{"n":".ctor","o":"$ctor$3","d":1245214,"h":60130787358,"f":1}],"h":1245214}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `DotNetInvocationInfo`; }
        });
        
        $asm.$str("$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationResult", ($self) => class DotNetInvocationResult extends $.$spc.System.ValueType
        {
            $ctor$2(/*Exception*/ exception, /*string?*/ errorKind)
            {
                super.$ctor$1();
                {
                    this.ResultJson = null;
                    this.Exception = $.$firstOf(exception, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("exception") });
                    this.ErrorKind = errorKind;
                    this.Success = false;
                }
                return this;
            }
            $ctor$3(/*string?*/ resultJson)
            {
                super.$ctor$1();
                {
                    this.ResultJson = resultJson;
                    this.Exception = null;
                    this.ErrorKind = null;
                    this.Success = true;
                }
                return this;
            }
            /*Exception?*/ Exception = null;
            /*string?*/ ErrorKind = null;
            /*string?*/ ResultJson = null;
            /*bool*/ Success = false;
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Exception = this.Exception;
                copy.ErrorKind = this.ErrorKind;
                copy.ResultJson = this.ResultJson;
                copy.Success = this.Success;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Success = false;
            }
            static $h = 1310750;
            static $z = 13;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":47185921,"g":{"r":0,"d":0,"h":21476147230,"f":1},"n":"Exception","d":1310750,"h":17181179934,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34361049118,"f":1},"n":"ErrorKind","d":1310750,"h":30066081822,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47245951006,"f":1},"n":"ResultJson","d":1310750,"h":42950983710,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60130852894,"f":1},"n":"Success","d":1310750,"h":55835885598,"f":1}],"c":[{"p":[{"n":"exception","p":47185921},{"n":"errorKind","p":1310721}],"n":".ctor","o":"$ctor$2","d":1310750,"h":4296278046,"f":8},{"p":[{"n":"resultJson","p":1310721}],"n":".ctor","o":"$ctor$3","d":1310750,"h":8591245342,"f":8},{"n":".ctor","o":"$ctor$4","d":1310750,"h":64425820190,"f":1}],"h":1310750}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `DotNetInvocationResult`; }
        });
        
        $asm.$str("$mj.Microsoft.JSInterop.Infrastructure.JSInvocationInfo", ($self) => class JSInvocationInfo extends $.$spc.System.ValueType
        {
            /*string?*/  get _argsJson() { return this.$getField(0, 4); }
            /*string?*/  set _argsJson(value) { this.$setField(0, 4, value); }
            /*long*/ AsyncHandle = 0n;
            /*long*/ TargetInstanceId = 0n;
            /*string*/ Identifier = null;
            /*JSCallType*/ CallType = 0;
            /*JSCallResultType*/ ResultType = 0;
            /*string */ get ArgsJson()
            {
                return this._argsJson ?? "[]";
            }
            /*string */ set ArgsJson(value)
            {
                this._argsJson = value;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._argsJson = this._argsJson;
                copy.AsyncHandle = this.AsyncHandle;
                copy.TargetInstanceId = this.TargetInstanceId;
                copy.Identifier = this.Identifier;
                copy.CallType = this.CallType;
                copy.ResultType = this.ResultType;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._argsJson = null;
                this.CallType = 0;
                this.ResultType = 0;
            }
            static $h = 1769502;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":917505,"g":{"r":0,"d":0,"h":17181638686,"f":1},"s":{"r":0,"d":0,"h":21476605982,"f":1},"n":"AsyncHandle","d":1769502,"h":12886671390,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":34361507870,"f":1},"s":{"r":0,"d":0,"h":38656475166,"f":1},"n":"TargetInstanceId","d":1769502,"h":30066540574,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51541377054,"f":1},"s":{"r":0,"d":0,"h":55836344350,"f":1},"n":"Identifier","d":1769502,"h":47246409758,"f":1},{"p":1703966,"g":{"r":0,"d":0,"h":68721246238,"f":1},"s":{"r":0,"d":0,"h":73016213534,"f":1},"n":"CallType","d":1769502,"h":64426278942,"f":1},{"p":2359326,"g":{"r":0,"d":0,"h":85901115422,"f":1},"s":{"r":0,"d":0,"h":90196082718,"f":1},"n":"ResultType","d":1769502,"h":81606148126,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":98786017310,"f":1},"s":{"r":0,"d":0,"h":103080984606,"f":1},"n":"ArgsJson","d":1769502,"h":94491050014,"f":1}],"l":[{"t":1310721,"n":"_argsJson","d":1769502,"h":4296736798,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1769502,"h":107375951902,"f":1}],"h":1769502}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `JSInvocationInfo`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverterFactory", ($self) => class DotNetObjectReferenceJsonConverterFactory extends $.$stj.System.Text.Json.Serialization.JsonConverterFactory
        {
            $ctor$1(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            /*JSRuntime*/ JSRuntime = null;
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                return typeToConvert.IsGenericType && $.$spc.System.Type.op_Equality$1(typeToConvert.GetGenericTypeDefinition(), $.$mj.Microsoft.JSInterop.DotNetObjectReference$$().$type);
            }
            /*JsonConverter */ CreateConverter(/*Type*/ typeToConvert, /*JsonSerializerOptions*/ jsonSerializerOptions)
            {
                /*var*/ let instanceType = $.$spc.System.Array.$ReadT1.call(typeToConvert.GetGenericArguments(), 0);
                /*var*/ let converterType = $.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ instanceType ], null, null));
                return $.$cast($.$spc.System.Activator.CreateInstance$1(converterType, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ this.JSRuntime ], null, null)), $.$stj.System.Text.Json.Serialization.JsonConverter);
            }
            static $h = 1441822;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":13363344,"p":[{"p":2949150,"g":{"r":0,"d":0,"h":17181311006,"f":1},"n":"JSRuntime","d":1441822,"h":12886343710,"f":1}],"m":[{"r":262145,"p":[{"n":"typeToConvert","p":142606337}],"n":"CanConvert","d":1441822,"h":21476278302,"f":32769},{"r":13166736,"p":[{"n":"typeToConvert","p":142606337},{"n":"jsonSerializerOptions","p":3401872}],"n":"CreateConverter","d":1441822,"h":25771245598,"f":32769}],"c":[{"p":[{"n":"jsRuntime","p":2949150}],"n":".ctor","o":"$ctor$1","d":1441822,"h":4296409118,"f":1}],"h":1441822}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverterFactory; }
            static get $fullName() { return `DotNetObjectReferenceJsonConverterFactory`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter", ($self) => class ByteArrayJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$typeArray($.$spc.System.Byte))
        {
            /*int*/ _byteArrayId = 0;
            /*JsonEncodedText*/ static ByteArrayRefKey;
            $ctor$1(/*JSRuntime*/ jSRuntime)
            {
                super.$ctor$2();
                {
                    this.JSRuntime = jSRuntime;
                }
                return this;
            }
            /*JSRuntime*/ JSRuntime = null;
            /*byte[]? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                /*var*/ let bytes;
                if (reader.$v.TokenType === 7/*JsonTokenType.String*/ && reader.$v.TryGetBytesFromBase64($.$ref(() => bytes, ($v) => bytes = $v, $.$typeArray($.$spc.System.Byte))))
                {
                    return bytes;
                }
                if (this.JSRuntime.ByteArraysToBeRevived.Count === 0)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8("JSON serialization is attempting to deserialize an unexpected byte array.");
                }
                /*int*/ let byteArrayRef;
                if (reader.$v.TokenType !== 1/*JsonTokenType.StartObject*/)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON Token ${reader.$v.TokenType}, expected 'StartObject'.`);
                }
                if (reader.$v.Read() && reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                {
                    if (!reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter.ByteArrayRefKey.EncodedUtf8Bytes))
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON Property ${reader.$v.GetString()}.`);
                    }
                    else if (!reader.$v.Read() || reader.$v.TokenType !== 8/*JsonTokenType.Number*/)
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON Token ${reader.$v.TokenType}, expected 'Number'.`);
                    }
                    else if (!reader.$v.TryGetInt32($.$ref(() => byteArrayRef, ($v) => byteArrayRef = $v, $.$spc.System.Int32)))
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected number, expected 32-bit integer.`);
                    }
                }
                else 
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON Token ${reader.$v.TokenType}, expected 'PropertyName'.`);
                }
                if (reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON Token ${reader.$v.TokenType}, expected 'EndObject'.`);
                }
                if (byteArrayRef >= this.JSRuntime.ByteArraysToBeRevived.Count || byteArrayRef < 0)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Byte array ${byteArrayRef} not found.`);
                }
                /*var*/ let byteArray = $.$spc.System.Array.$ReadT1.call(this.JSRuntime.ByteArraysToBeRevived.Buffer, byteArrayRef);
                return byteArray;
            }
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*byte[]*/ value, /*JsonSerializerOptions*/ options)
            {
                /*var*/ let id = ++this._byteArrayId;
                this.JSRuntime.SendByteArray(id, value);
                writer.WriteStartObject();
                writer.WriteNumber$19($.$mj.Microsoft.JSInterop.Infrastructure.ByteArrayJsonConverter.ByteArrayRefKey, id);
                writer.WriteEndObject();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ByteArrayRefKey = $.$stj.System.Text.Json.JsonEncodedText.Encode("__byte[]", null);
                }
            }
            static $h = 983070;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2949150,"g":{"r":0,"d":0,"h":25770786846,"f":1},"n":"JSRuntime","d":983070,"h":21475819550,"f":1}],"m":[{"r":0,"p":[{"n":"reader","p":18999440,"f":4},{"n":"typeToConvert","p":142606337},{"n":"options","p":3401872}],"n":"Read","d":983070,"h":30065754142,"f":32769},{"r":65537,"p":[{"n":"writer","p":19130512},{"n":"value","p":0},{"n":"options","p":3401872}],"n":"Write","d":983070,"h":34360721438,"f":32769}],"l":[{"t":655361,"n":"_byteArrayId","d":983070,"h":4295950366,"f":2},{"t":2353296,"n":"ByteArrayRefKey","d":983070,"h":8590917662,"f":40}],"c":[{"p":[{"n":"jSRuntime","p":2949150}],"n":".ctor","o":"$ctor$1","d":983070,"h":12885884958,"f":1}],"h":983070}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$typeArray($.$spc.System.Byte)); }
            static get $fullName() { return `ByteArrayJsonConverter`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.JSObjectReferenceJsonConverter", ($self) => class JSObjectReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSObjectReference)
        {
            /*JSRuntime*/ _jsRuntime = null;
            $ctor$1(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                return $.$spc.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.IJSObjectReference.$type) || $.$spc.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference.$type);
            }
            /*IJSObjectReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                /*var*/ let id = $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.ReadJSObjectReferenceIdentifier(reader);
                if (id === BigInt(-1))
                {
                    return null;
                }
                return new $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference().$ctor$1(this._jsRuntime, id);
            }
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSObjectReference*/ value, /*JsonSerializerOptions*/ options)
            {
                $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference));
            }
            static $h = 1835038;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"typeToConvert","p":142606337}],"n":"CanConvert","d":1835038,"h":12886736926,"f":32769},{"r":458782,"p":[{"n":"reader","p":18999440,"f":4},{"n":"typeToConvert","p":142606337},{"n":"options","p":3401872}],"n":"Read","d":1835038,"h":17181704222,"f":32769},{"r":65537,"p":[{"n":"writer","p":19130512},{"n":"value","p":458782},{"n":"options","p":3401872}],"n":"Write","d":1835038,"h":21476671518,"f":32769}],"l":[{"t":2949150,"n":"_jsRuntime","d":1835038,"h":4296802334,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":2949150}],"n":".ctor","o":"$ctor$1","d":1835038,"h":8591769630,"f":1}],"h":1835038}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSObjectReference); }
            static get $fullName() { return `JSObjectReferenceJsonConverter`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter", ($self) => class JSStreamReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSStreamReference)
        {
            /*JsonEncodedText*/ static _jsStreamReferenceLengthKey;
            /*JSRuntime*/ _jsRuntime = null;
            $ctor$1(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            /*bool */ CanConvert(/*Type*/ typeToConvert)
            {
                return $.$spc.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.IJSStreamReference.$type) || $.$spc.System.Type.op_Equality$1(typeToConvert, $.$mj.Microsoft.JSInterop.Implementation.JSStreamReference.$type);
            }
            /*IJSStreamReference? */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                /*long?*/ let id = null;
                /*long?*/ let length = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (id === null && reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetInt64();
                        }
                        else if (length === null && reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter._jsStreamReferenceLengthKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            length = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON property ${reader.$v.GetString()}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON token ${reader.$v.TokenType}`);
                    }
                }
                if (!$.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(id))
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Required property ${$.$stj.System.Text.Json.JsonEncodedText.ToString.call($.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.JSObjectIdKey)} not found.`);
                }
                if (!$.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(length))
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Required property ${$.$stj.System.Text.Json.JsonEncodedText.ToString.call($.$mj.Microsoft.JSInterop.Infrastructure.JSStreamReferenceJsonConverter._jsStreamReferenceLengthKey)} not found.`);
                }
                return new $.$mj.Microsoft.JSInterop.Implementation.JSStreamReference().$ctor$2(this._jsRuntime, $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(id), $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(length));
            }
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*IJSStreamReference*/ value, /*JsonSerializerOptions*/ options)
            {
                $.$mj.Microsoft.JSInterop.Implementation.JSObjectReferenceJsonWorker.WriteJSObjectReference(writer, $.$cast(value, $.$mj.Microsoft.JSInterop.Implementation.JSStreamReference));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._jsStreamReferenceLengthKey = $.$stj.System.Text.Json.JsonEncodedText.Encode("__jsStreamReferenceLength", null);
                }
            }
            static $h = 1900574;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"typeToConvert","p":142606337}],"n":"CanConvert","d":1900574,"h":17181769758,"f":32769},{"r":589854,"p":[{"n":"reader","p":18999440,"f":4},{"n":"typeToConvert","p":142606337},{"n":"options","p":3401872}],"n":"Read","d":1900574,"h":21476737054,"f":32769},{"r":65537,"p":[{"n":"writer","p":19130512},{"n":"value","p":589854},{"n":"options","p":3401872}],"n":"Write","d":1900574,"h":25771704350,"f":32769}],"l":[{"t":2353296,"n":"_jsStreamReferenceLengthKey","d":1900574,"h":4296867870,"f":34},{"t":2949150,"n":"_jsRuntime","d":1900574,"h":8591835166,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":2949150}],"n":".ctor","o":"$ctor$1","d":1900574,"h":12886802462,"f":1}],"h":1900574}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.IJSStreamReference); }
            static get $fullName() { return `JSStreamReferenceJsonConverter`; }
        });
        
        $asm.$str("$mj.Microsoft.JSInterop.JSCallResultType", ($self) => class JSCallResultType extends $.$spc.System.Enum
        {
            static Default = 0;
            static JSObjectReference = 1;
            static JSStreamReference = 2;
            static JSVoidResult = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "JSObjectReference": 1n,
                    "JSStreamReference": 2n,
                    "JSVoidResult": 3n
                };
            }
            static $h = 2359326;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2359326,"n":"Default","d":2359326,"h":4297326622,"f":33},{"t":2359326,"n":"JSObjectReference","d":2359326,"h":8592293918,"f":33},{"t":2359326,"n":"JSStreamReference","d":2359326,"h":12887261214,"f":33},{"t":2359326,"n":"JSVoidResult","d":2359326,"h":17182228510,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2359326,"h":21477195806,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2359326}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `JSCallResultType`; }
        });
        
        $asm.$str("$mj.Microsoft.JSInterop.Infrastructure.JSCallType", ($self) => class JSCallType extends $.$spc.System.Enum
        {
            static FunctionCall = 1;
            static ConstructorCall = 2;
            static GetValue = 3;
            static SetValue = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FunctionCall": 1n,
                    "ConstructorCall": 2n,
                    "GetValue": 3n,
                    "SetValue": 4n
                };
            }
            static $h = 1703966;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1703966,"n":"FunctionCall","d":1703966,"h":4296671262,"f":33},{"t":1703966,"n":"ConstructorCall","d":1703966,"h":8591638558,"f":33},{"t":1703966,"n":"GetValue","d":1703966,"h":12886605854,"f":33},{"t":1703966,"n":"SetValue","d":1703966,"h":17181573150,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1703966,"h":21476540446,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1703966}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `JSCallType`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.DotNetStreamReferenceJsonConverter", ($self) => class DotNetStreamReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.DotNetStreamReference)
        {
            /*JsonEncodedText*/ static DotNetStreamRefKey;
            $ctor$1(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            /*JSRuntime*/ JSRuntime = null;
            /*DotNetStreamReference */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10(`${"DotNetStreamReference"} cannot be supplied from JavaScript to .NET because the stream contents have already been transferred.`);
            }
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*DotNetStreamReference*/ value, /*JsonSerializerOptions*/ options)
            {
                /*var*/ let id = this.JSRuntime.BeginTransmittingStream(value);
                writer.WriteStartObject();
                writer.WriteNumber$15($.$mj.Microsoft.JSInterop.Infrastructure.DotNetStreamReferenceJsonConverter.DotNetStreamRefKey, id);
                writer.WriteEndObject();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DotNetStreamRefKey = $.$stj.System.Text.Json.JsonEncodedText.Encode("__dotNetStream", null);
                }
            }
            static $h = 1507358;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2949150,"g":{"r":0,"d":0,"h":21476343838,"f":1},"n":"JSRuntime","d":1507358,"h":17181376542,"f":1}],"m":[{"r":262174,"p":[{"n":"reader","p":18999440,"f":4},{"n":"typeToConvert","p":142606337},{"n":"options","p":3401872}],"n":"Read","d":1507358,"h":25771311134,"f":32769},{"r":65537,"p":[{"n":"writer","p":19130512},{"n":"value","p":262174},{"n":"options","p":3401872}],"n":"Write","d":1507358,"h":30066278430,"f":32769}],"l":[{"t":2353296,"n":"DotNetStreamRefKey","d":1507358,"h":4296474654,"f":34}],"c":[{"p":[{"n":"jsRuntime","p":2949150}],"n":".ctor","o":"$ctor$1","d":1507358,"h":8591441950,"f":1}],"h":1507358}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.DotNetStreamReference); }
            static get $fullName() { return `DotNetStreamReferenceJsonConverter`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter<>", (TValue) => $asm.$gt("$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter<>", [TValue], ($self) => class DotNetObjectReferenceJsonConverter$$ extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue))
        {
            $ctor$1(/*JSRuntime*/ jsRuntime)
            {
                super.$ctor$2();
                {
                    this.JSRuntime = jsRuntime;
                }
                return this;
            }
            static /*JsonEncodedText */ get DotNetObjectRefKey()
            {
                return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.DotNetObjectRefKey;
            }
            /*JSRuntime*/ JSRuntime = null;
            /*DotNetObjectReference<TValue> */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                /*long*/ let dotNetObjectId = 0n;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (dotNetObjectId === 0n && reader.$v.ValueTextEquals($.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            dotNetObjectId = reader.$v.GetInt64();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON property ${reader.$v.GetString()}.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON Token ${reader.$v.TokenType}.`);
                    }
                }
                if (dotNetObjectId === 0n)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Required property ${$.$stj.System.Text.Json.JsonEncodedText.ToString.call($.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey)} not found.`);
                }
                /*var*/ let value = $.$cast(this.JSRuntime.GetObjectReference(dotNetObjectId), $.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue));
                return value;
            }
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*DotNetObjectReference<TValue>*/ value, /*JsonSerializerOptions*/ options)
            {
                /*var*/ let objectId = this.JSRuntime.TrackObjectReference(TValue, value);
                writer.WriteStartObject();
                writer.WriteNumber$15($.$mj.Microsoft.JSInterop.Infrastructure.DotNetObjectReferenceJsonConverter$$(TValue).DotNetObjectRefKey, objectId);
                writer.WriteEndObject();
            }
            static $h = 1376286;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2353296,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":34},"n":"DotNetObjectRefKey","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":34},{"p":2949150,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"JSRuntime","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"m":[{"r":$.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue).$h,"p":[{"n":"reader","p":18999440,"f":4},{"n":"typeToConvert","p":142606337},{"n":"options","p":3401872}],"n":"Read","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},{"r":65537,"p":[{"n":"writer","p":19130512},{"n":"value","p":$.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue).$h},{"n":"options","p":3401872}],"n":"Write","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769}],"c":[{"p":[{"n":"jsRuntime","p":2949150}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"g":[TValue?.$h??1507328],"s":[{"n":"TValue","f":1}],"r":1,"h":this.$h}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mj.Microsoft.JSInterop.DotNetObjectReference$$(TValue)); }
            static get $fullName() { return `DotNetObjectReferenceJsonConverter<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$mj.Microsoft.JSInterop.Implementation.JSStreamReference", ($self) => class JSStreamReference extends $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference
        {
            /*JSRuntime*/ _jsRuntime = null;
            /*long*/ Length = 0n;
            $ctor$2(/*JSRuntime*/ jsRuntime, /*long*/ id, /*long*/ totalLength)
            {
                super.$ctor$1(jsRuntime, id);
                {
                    if (totalLength <= 0n)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("totalLength", $.$box(totalLength, $.$spc.System.Int64), "Length must be a positive value.");
                    }
                    this._jsRuntime = jsRuntime;
                    this.Length = totalLength;
                }
                return this;
            }
            /*ValueTask<Stream> *//*async*/  Microsoft$JSInterop$IJSStreamReference$OpenReadStreamAsync(/*long*/ maxAllowedSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream), $.$spc.System.IO.Stream, async () => 
                {
                    if (this.Length > maxAllowedSize)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("maxAllowedSize", `The incoming data stream of length ${this.Length} exceeds the maximum allowed length ${maxAllowedSize}.`);
                    }
                    return await this._jsRuntime.ReadJSDataAsStreamAsync(this, this.Length, cancellationToken);
                });
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSStreamReference.Length.get
            get Microsoft$JSInterop$IJSStreamReference$Length()
            {
                return this.Length;
            }
            static $h = 851998;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":720926,"p":[{"p":917505,"g":{"r":0,"d":0,"h":17180721182,"f":1},"n":"Length","d":851998,"h":12885753886,"f":1}],"l":[{"t":2949150,"n":"_jsRuntime","d":851998,"h":4295819294,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":2949150},{"n":"id","p":917505},{"n":"totalLength","p":917505}],"n":".ctor","o":"$ctor$2","d":851998,"h":21475688478,"f":8}],"i":[458782,589854,56885249],"h":851998}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$mj.Microsoft.JSInterop.IJSStreamReference, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `JSStreamReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.Implementation.JSInProcessObjectReference", ($self) => class JSInProcessObjectReference extends $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference
        {
            /*JSInProcessRuntime*/ _jsRuntime = null;
            $ctor$2(/*JSInProcessRuntime*/ jsRuntime, /*long*/ id)
            {
                super.$ctor$1(jsRuntime, id);
                {
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            /*TValue */ Invoke(TValue, /*string*/ identifier, /*params object?[]?*/ args)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.Invoke$1(TValue, identifier, this.Id, 1/*JSCallType.FunctionCall*/, args);
            }
            /*IJSInProcessObjectReference */ InvokeConstructor(/*string*/ identifier, /*object?[]?*/ args)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.Invoke$1($.$mj.Microsoft.JSInterop.IJSInProcessObjectReference, identifier, this.Id, 2/*JSCallType.ConstructorCall*/, args);
            }
            /*TValue */ GetValue(TValue, /*string*/ identifier)
            {
                this.ThrowIfDisposed();
                return this._jsRuntime.Invoke$1(TValue, identifier, this.Id, 3/*JSCallType.GetValue*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [  ], null, null));
            }
            /*void */ SetValue(TValue, /*string*/ identifier, /*TValue*/ value)
            {
                this.ThrowIfDisposed();
                this._jsRuntime.Invoke$1(TValue, identifier, this.Id, 4/*JSCallType.SetValue*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(value, TValue) ], null, null));
            }
            /*void */ Dispose()
            {
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    globalThis.DotNet.disposeJSObjectReferenceById(this.Id);
                }
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.Invoke<TValue>(string, params object?[]?)
            Microsoft$JSInterop$IJSInProcessObjectReference$Invoke()
            {
                return this.Invoke(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.InvokeConstructor(string, object?[]?)
            Microsoft$JSInterop$IJSInProcessObjectReference$InvokeConstructor()
            {
                return this.InvokeConstructor(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.GetValue<TValue>(string)
            Microsoft$JSInterop$IJSInProcessObjectReference$GetValue()
            {
                return this.GetValue(...arguments);
            }
            //Generated interface implemetation for Microsoft.JSInterop.IJSInProcessObjectReference.SetValue<TValue>(string, TValue)
            Microsoft$JSInterop$IJSInProcessObjectReference$SetValue()
            {
                return this.SetValue(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 655390;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":720926,"m":[{"r":(TValue) => TValue.$h,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0,"f":16}],"g":["TValue"],"n":"Invoke","d":655390,"h":12885557278,"f":131073},{"r":327710,"p":[{"n":"identifier","p":1310721},{"n":"args","p":0}],"n":"InvokeConstructor","d":655390,"h":17180524574,"f":1},{"r":(TValue) => TValue.$h,"p":[{"n":"identifier","p":1310721}],"g":["TValue"],"n":"GetValue","d":655390,"h":21475491870,"f":131073},{"r":65537,"p":[{"n":"identifier","p":1310721},{"n":"value","p":(TValue) => TValue.$h}],"g":["TValue"],"n":"SetValue","d":655390,"h":25770459166,"f":131073},{"r":65537,"n":"Dispose","d":655390,"h":30065426462,"f":1}],"l":[{"t":2687006,"n":"_jsRuntime","d":655390,"h":4295622686,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":2687006},{"n":"id","p":917505}],"n":".ctor","o":"$ctor$2","d":655390,"h":8590589982,"f":16}],"i":[327710,458782,56885249,57475073],"h":655390}; }
            static get $b() { return $.$mj.Microsoft.JSInterop.Implementation.JSObjectReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mj.Microsoft.JSInterop.IJSInProcessObjectReference, $.$mj.Microsoft.JSInterop.IJSObjectReference, $.$spc.System.IAsyncDisposable, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `JSInProcessObjectReference`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSDisconnectedException", ($self) => class JSDisconnectedException extends $.$spc.System.Exception
        {
            $ctor$5(/*string*/ message)
            {
                super.$ctor$2(message);
                {
                }
                return this;
            }
            static $h = 2490398;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"c":[{"p":[{"n":"message","p":1310721}],"n":".ctor","o":"$ctor$5","d":2490398,"h":4297457694,"f":1}],"i":[113377281],"h":2490398}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `JSDisconnectedException`; }
        });
        
        $asm.$cls("$mj.Microsoft.JSInterop.JSException", ($self) => class JSException extends $.$spc.System.Exception
        {
            $ctor$5(/*string*/ message)
            {
                super.$ctor$2(message);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ message, /*Exception*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                }
                return this;
            }
            static $h = 2555934;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"c":[{"p":[{"n":"message","p":1310721}],"n":".ctor","o":"$ctor$5","d":2555934,"h":4297523230,"f":1},{"p":[{"n":"message","p":1310721},{"n":"innerException","p":47185921}],"n":".ctor","o":"$ctor$6","d":2555934,"h":8592490526,"f":1}],"i":[113377281],"h":2555934}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `JSException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.IO.Pipelines", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Text.Encodings.Web", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.System.Text.Json", "NetJs.System.Net.Quic", "NetJs.System.Net.Http"))