
//--TRIMMABLE-BOUNDARY-START(122)
(async function () {
(function ($global, $, $$, $sm, $mep, $mwp, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh) {
    "use strict";
    let _;
    let $JfRFqg;
    let $YfSlhc;
    let $vTTcWc;
    let $JUdwib;
    let $jTqfed;
    let $nCNfJg;
    let $yragzg;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Net.Http.Headers", 
    {
  "h": 122,
  "f": "Microsoft.Net.Http.Headers",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "HTTP header parser implementations.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Net.Http.Headers",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Net.Http.Headers",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Net.Http.Headers.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(983162)
        $asm.$cls(`$mnhh.MNHH.HttpHeaderParser<>`, (T) => $asm.$gt(`$mnhh.MNHH.HttpHeaderParser<>`, [T], ($self) => class HttpHeaderParser$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295950458)
            /*bool*/ _supportsMultipleValues = false;
            //--TRIMMABLE-BOUNDARY-END(4295950458)
            
            //--TRIMMABLE-BOUNDARY-START(8590917754)
            $ctor$1(/*bool*/ supportsMultipleValues)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917754);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._supportsMultipleValues = supportsMultipleValues;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917754)
            
            //--TRIMMABLE-BOUNDARY-START(38655688826)
            /*bool */ get SupportsMultipleValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._supportsMultipleValues;
            }
            //--TRIMMABLE-BOUNDARY-END(38655688826)
            
            //--TRIMMABLE-BOUNDARY-START(25770786938)
            /*T? */ ParseValue(/*StringSegment*/ value, /*ref int*/ index)
            {
                /*var*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if (!this.TryParseValue(value, index, $.$ref(() => result, ($v) => result = $v, T)))
                {
                    throw new $.$$.S.FormatException().$ctor$12($.$$.S.String.Format$3($.$$.SG.CultureInfo.InvariantCulture, "The header contains invalid values at index {0}: '{1}'", $.$box(index.$v, $.$$.S.Int32), value.Value ?? "<null>"));
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(25770786938)
            
            //--TRIMMABLE-BOUNDARY-START(55835558010)
            /*bool */ TryParseValues(/*IList<string>?*/ values, /*out IList<T>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835558010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryParseValues$1(values, false, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(55835558010)
            
            //--TRIMMABLE-BOUNDARY-START(47245623418)
            /*bool */ TryParseStrictValues(/*IList<string>?*/ values, /*out IList<T>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryParseValues$1(values, true, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(47245623418)
            
            //--TRIMMABLE-BOUNDARY-START(60130525306)
            /*bool */ TryParseValues$1(/*IList<string>?*/ values, /*bool*/ strict, /*out IList<T>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SDC$1.Contract.Assert$1(this._supportsMultipleValues);
                parsedValues.$v = null;
                /*List<T>?*/ let results = null;
                if (values === null)
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < values.SCG$ICollection$$$Count; i++)
                {
                    /*var*/ let value = values.SCG$IList$$$get_Item(i);
                    /*var*/ let index = 0;
                    while(!$.$$.S.String.IsNullOrEmpty(value) && index < value.length)
                    {
                        /*var*/ let output;
                        if (this.TryParseValue($.$mep.MEP.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => output, ($v) => output = $v, T)))
                        {
                            if (output !== null)
                            {
                                if (results === null)
                                {
                                    results = new ($.$$.SCG.List$$(T))().$ctor$1();
                                }
                                results.Add(output);
                            }
                        }
                        else if (strict)
                        {
                            return false;
                        }
                        else 
                        {
                            index++;
                        }
                    }
                }
                if (results !== null)
                {
                    parsedValues.$v = results;
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(60130525306)
            
            //--TRIMMABLE-BOUNDARY-START(34360721530)
            /*IList<T> */ ParseValues$1(/*IList<string>?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360721530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseValues(values, false);
            }
            //--TRIMMABLE-BOUNDARY-END(34360721530)
            
            //--TRIMMABLE-BOUNDARY-START(21475819642)
            /*IList<T> */ ParseStrictValues(/*IList<string>?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseValues(values, true);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819642)
            
            //--TRIMMABLE-BOUNDARY-START(30065754234)
            /*IList<T> */ ParseValues(/*IList<string>?*/ values, /*bool*/ strict)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SDC$1.Contract.Assert$1(this._supportsMultipleValues);
                /*var*/ let parsedValues = new ($.$$.SCG.List$$(T))().$ctor$1();
                if (values === null)
                {
                    return parsedValues;
                }
                let $en7 = values.SCG$IEnumerable$$$GetEnumerator();
                while ($en7.SC$1$IEnumerator$MoveNext())
                {
                    let value = $en7.SCG$IEnumerator$$$Current;
                    {
                        /*int*/ let index = 0;
                        while(!$.$$.S.String.IsNullOrEmpty(value) && index < value.length)
                        {
                            /*var*/ let output;
                            if (this.TryParseValue($.$mep.MEP.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => output, ($v) => output = $v, T)))
                            {
                                if (output !== null)
                                {
                                    parsedValues.Add(output);
                                }
                            }
                            else if (strict)
                            {
                                throw new $.$$.S.FormatException().$ctor$12($.$$.S.String.Format$3($.$$.SG.CultureInfo.InvariantCulture, "The header contains invalid values at index {0}: '{1}'", $.$box(index, $.$$.S.Int32), value));
                            }
                            else 
                            {
                                index++;
                            }
                        }
                    }
                }
                return parsedValues;
            }
            //--TRIMMABLE-BOUNDARY-END(30065754234)
            
            //--TRIMMABLE-BOUNDARY-START(42950656122)
            /*string */ ToString$1(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dsp(value, $.$$.S.Object, ($t) => $t.ToString);
            }
            //--TRIMMABLE-BOUNDARY-END(42950656122)
            
            static $H = 983162;
            static $h = 983162;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655688826),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180852346,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "SupportsMultipleValues",
      "d": this.$h,
      "H": 38655688826,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655688826)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540590714),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryParseValue",
      "d": this.$h,
      "H": 51540590714,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51540590714),
//--TRIMMABLE-BOUNDARY-START(25770786938),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "ParseValue",
      "d": this.$h,
      "H": 25770786938,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770786938),
//--TRIMMABLE-BOUNDARY-START(55835558010),
    {
      "r": 262145,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryParseValues",
      "d": this.$h,
      "H": 55835558010,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835558010),
//--TRIMMABLE-BOUNDARY-START(47245623418),
    {
      "r": 262145,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictValues",
      "d": this.$h,
      "H": 47245623418,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47245623418),
//--TRIMMABLE-BOUNDARY-START(60130525306),
    {
      "r": 262145,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "strict",
          "p": 262145
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryParseValues",
      "o": "@$1",
      "d": this.$h,
      "H": 60130525306,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(60130525306),
//--TRIMMABLE-BOUNDARY-START(34360721530),
    {
      "r": $.$$.SCG.IList$$(T).$h,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseValues",
      "o": "@$1",
      "d": this.$h,
      "H": 34360721530,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34360721530),
//--TRIMMABLE-BOUNDARY-START(21475819642),
    {
      "r": $.$$.SCG.IList$$(T).$h,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseStrictValues",
      "d": this.$h,
      "H": 21475819642,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475819642),
//--TRIMMABLE-BOUNDARY-START(30065754234),
    {
      "r": $.$$.SCG.IList$$(T).$h,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "strict",
          "p": 262145
        }
      ],
      "n": "ParseValues",
      "d": this.$h,
      "H": 30065754234,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30065754234),
//--TRIMMABLE-BOUNDARY-START(42950656122),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": this.$h,
      "H": 42950656122,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42950656122)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950458),
    {
      "t": 262145,
      "n": "_supportsMultipleValues",
      "d": this.$h,
      "H": 4295950458,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950458)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917754),
    {
      "p": [
        {
          "n": "supportsMultipleValues",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590917754,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590917754)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 983162,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.HttpHeaderParser<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}HttpHeaderParser$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(983162)
        
        

        //--TRIMMABLE-BOUNDARY-START(65658)
        $asm.$cls(`$mnhh.MNHH.BaseHeaderParser<>`, (T) => $asm.$gt(`$mnhh.MNHH.BaseHeaderParser<>`, [T], ($self) => class BaseHeaderParser$$ extends $.$mnhh.MNHH.HttpHeaderParser$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(4295032954)
            $ctor$2(/*bool*/ supportsMultipleValues)
            {
                super.$ctor$1(supportsMultipleValues);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032954);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032954)
            
            //--TRIMMABLE-BOUNDARY-START(12884967546)
            /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*out T?*/ parsedValue)
            {
                /*var*/ let separatorFound;
                /*var*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parsedValue.$v = $.$default(T);
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(value) || (index.$v === value.Length))
                {
                    return this.SupportsMultipleValues;
                }
                /*var*/ let current = $.$mnhh.MNHH.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(value, index.$v, this.SupportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.S.Boolean));
                if (separatorFound && !this.SupportsMultipleValues)
                {
                    return false;
                }
                if (current === value.Length)
                {
                    if (this.SupportsMultipleValues)
                    {
                        index.$v = current;
                    }
                    return this.SupportsMultipleValues;
                }
                /*var*/ let length = this.GetParsedValueLength(value, current, $.$ref(() => result, ($v) => result = $v, T));
                if (length === 0)
                {
                    return false;
                }
                current = ((current + length) | 0);
                current = $.$mnhh.MNHH.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(value, current, this.SupportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.S.Boolean));
                if ((separatorFound && !this.SupportsMultipleValues) || (!separatorFound && (current < value.Length)))
                {
                    return false;
                }
                index.$v = current;
                parsedValue.$v = result;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967546)
            
            static $H = 65658;
            static $h = 65658;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mnhh.MNHH.HttpHeaderParser$$(T); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000250),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "GetParsedValueLength",
      "d": this.$h,
      "H": 8590000250,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8590000250),
//--TRIMMABLE-BOUNDARY-START(12884967546),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryParseValue",
      "d": this.$h,
      "H": 12884967546,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(12884967546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032954),
    {
      "p": [
        {
          "n": "supportsMultipleValues",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295032954,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295032954)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 65658,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.BaseHeaderParser<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}BaseHeaderParser$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(65658)
        
        

        //--TRIMMABLE-BOUNDARY-START(852090)
        $asm.$cls(`$mnhh.MNHH.HeaderQuality`, ($self) => class HeaderQuality
        {
            //--TRIMMABLE-BOUNDARY-START(4295819386)
            /*double*/ static Match = 1;
            //--TRIMMABLE-BOUNDARY-END(4295819386)
            
            //--TRIMMABLE-BOUNDARY-START(8590786682)
            /*double*/ static NoMatch = 0;
            //--TRIMMABLE-BOUNDARY-END(8590786682)
            
            static $h = 852090;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819386),
    {
      "t": 1179649,
      "n": "Match",
      "d": 852090,
      "h": 4295819386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295819386),
//--TRIMMABLE-BOUNDARY-START(8590786682),
    {
      "t": 1179649,
      "n": "NoMatch",
      "d": 852090,
      "h": 8590786682,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786682)
  ],
  "h": 852090
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.HeaderQuality`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}HeaderQuality`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852090)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507450)
        $asm.$cls(`$mnhh.MNHH.RangeHeaderValue`, ($self) => class RangeHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60131049594)
            /*HttpHeaderParser<RangeHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(60131049594)
            
            //--TRIMMABLE-BOUNDARY-START(8591442042)
            /*StringSegment*/ _unit;
            //--TRIMMABLE-BOUNDARY-END(8591442042)
            
            //--TRIMMABLE-BOUNDARY-START(4296474746)
            /*ICollection<RangeItemHeaderValue>?*/ _ranges = null;
            //--TRIMMABLE-BOUNDARY-END(4296474746)
            
            //--TRIMMABLE-BOUNDARY-START(17181376634)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376634);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._unit = $.$mep.MEP.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376634)
            
            //--TRIMMABLE-BOUNDARY-START(21476343930)
            $ctor$2(/*long?*/ $from, /*long?*/ to)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343930);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._unit = $.$mep.MEP.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                    this.Ranges.SCG$ICollection$$$Add(new $.$mnhh.MNHH.RangeItemHeaderValue().$ctor$1($from, to));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343930)
            
            //--TRIMMABLE-BOUNDARY-START(85900853370)
            /*StringSegment */ get Unit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._unit;
            }
            /*StringSegment */ set Unit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.CheckValidToken(value, "value");
                this._unit = value;
            }
            //--TRIMMABLE-BOUNDARY-END(85900853370)
            
            //--TRIMMABLE-BOUNDARY-START(64426016890)
            /*ICollection<RangeItemHeaderValue> */ get Ranges()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._ranges === null)
                {
                    this._ranges = new ($.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.RangeItemHeaderValue))().$ctor$3();
                }
                return this._ranges;
            }
            //--TRIMMABLE-BOUNDARY-END(64426016890)
            
            //--TRIMMABLE-BOUNDARY-START(77310918778)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310918778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                sb.Append$17(this._unit.AsSpan());
                sb.Append$5(/*=*/ 61);
                /*var*/ let first = true;
                let $en1 = this.Ranges.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let range = $en1.SCG$IEnumerator$$$Current;
                    {
                        if (first)
                        {
                            first = false;
                        }
                        else 
                        {
                            sb.Append$21(", ");
                        }
                        sb.Append$15($.$box(range.From, $.$$.S.Int64));
                        sb.Append$5(/*-*/ 45);
                        sb.Append$15($.$box(range.To, $.$$.S.Int64));
                    }
                }
                return sb.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(77310918778)
            
            //--TRIMMABLE-BOUNDARY-START(25771311226)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.RangeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.MEP.StringSegment.Equals$5(this._unit, other._unit, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.MNHH.HeaderUtilities.AreEqualCollections$1($.$mnhh.MNHH.RangeItemHeaderValue, this.Ranges, other.Ranges);
            }
            //--TRIMMABLE-BOUNDARY-END(25771311226)
            
            //--TRIMMABLE-BOUNDARY-START(47246147706)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._unit);
                let $en2 = this.Ranges.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let range = $en2.SCG$IEnumerator$$$Current;
                    {
                        result = result ^ range.GetHashCode();
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(47246147706)
            
            //--TRIMMABLE-BOUNDARY-START(55836082298)
            static /*RangeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.RangeHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(55836082298)
            
            //--TRIMMABLE-BOUNDARY-START(81605886074)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out RangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605886074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.RangeHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(81605886074)
            
            //--TRIMMABLE-BOUNDARY-START(51541115002)
            static /*int */ GetRangeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541115002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let unitLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, startIndex);
                if (unitLength === 0)
                {
                    return 0;
                }
                /*RangeHeaderValue*/ let result = new $.$mnhh.MNHH.RangeHeaderValue().$ctor$1();
                result._unit = input.Subsegment(startIndex, unitLength);
                /*var*/ let current = ((startIndex + unitLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item$1(current) !== /*=*/ 61))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let rangesLength = $.$mnhh.MNHH.RangeItemHeaderValue.GetRangeItemListLength(input, current, result.Ranges);
                if (rangesLength === 0)
                {
                    return 0;
                }
                current = ((current + rangesLength) | 0);
                $.$$.SDC$1.Contract.Assert(current === input.Length, "GetRangeItemListLength() should consume the whole string or fail.");
                parsedValue.$v = result;
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(51541115002)
            
            //--TRIMMABLE-BOUNDARY-START(17181376634)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181376634)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591442042)
                this._unit = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591442042)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886409338)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886409338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(60131049594)
                    this.Parser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.RangeHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.RangeHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.RangeHeaderValue, $.$mnhh.MNHH.RangeHeaderValue.GetRangeLength));
                    //--TRIMMABLE-BOUNDARY-END(60131049594)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886409338)
            
            static $h = 1507450;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900853370),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951180410,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015951482,
        "f": 83886081
      },
      "n": "Unit",
      "d": 1507450,
      "h": 85900853370,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900853370),
//--TRIMMABLE-BOUNDARY-START(64426016890),
    {
      "p": $.$$.SCG.ICollection$$($.$mnhh.MNHH.RangeItemHeaderValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361245818,
        "f": 50331649
      },
      "n": "Ranges",
      "d": 1507450,
      "h": 64426016890,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426016890)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310918778),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1507450,
      "h": 77310918778,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310918778),
//--TRIMMABLE-BOUNDARY-START(25771311226),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1507450,
      "h": 25771311226,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771311226),
//--TRIMMABLE-BOUNDARY-START(47246147706),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1507450,
      "h": 47246147706,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246147706),
//--TRIMMABLE-BOUNDARY-START(55836082298),
    {
      "r": 1507450,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1507450,
      "h": 55836082298,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836082298),
//--TRIMMABLE-BOUNDARY-START(81605886074),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1507450,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1507450,
      "h": 81605886074,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605886074),
//--TRIMMABLE-BOUNDARY-START(51541115002),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1507450,
          "f": 2
        }
      ],
      "n": "GetRangeLength",
      "d": 1507450,
      "h": 51541115002,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51541115002)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60131049594),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.RangeHeaderValue).$h,
      "n": "Parser",
      "d": 1507450,
      "h": 60131049594,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131049594),
//--TRIMMABLE-BOUNDARY-START(8591442042),
    {
      "t": 852053,
      "n": "_unit",
      "d": 1507450,
      "h": 8591442042,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442042),
//--TRIMMABLE-BOUNDARY-START(4296474746),
    {
      "t": $.$$.SCG.ICollection$$($.$mnhh.MNHH.RangeItemHeaderValue).$h,
      "n": "_ranges",
      "d": 1507450,
      "h": 4296474746,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474746)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181376634),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507450,
      "h": 17181376634,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376634),
//--TRIMMABLE-BOUNDARY-START(21476343930),
    {
      "p": [
        {
          "n": "from",
          "p": $.$typeNullable($.$$.S.Int64).$h
        },
        {
          "n": "to",
          "p": $.$typeNullable($.$$.S.Int64).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507450,
      "h": 21476343930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343930)
  ],
  "h": 1507450
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.RangeHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}RangeHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507450)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441914)
        $asm.$cls(`$mnhh.MNHH.RangeConditionHeaderValue`, ($self) => class RangeConditionHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77310853242)
            /*HttpHeaderParser<RangeConditionHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(77310853242)
            
            //--TRIMMABLE-BOUNDARY-START(8591376506)
            /*DateTimeOffset?*/ _lastModified = null;
            //--TRIMMABLE-BOUNDARY-END(8591376506)
            
            //--TRIMMABLE-BOUNDARY-START(4296409210)
            /*EntityTagHeaderValue?*/ _entityTag = null;
            //--TRIMMABLE-BOUNDARY-END(4296409210)
            
            //--TRIMMABLE-BOUNDARY-START(17181311098)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181311098);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311098)
            
            //--TRIMMABLE-BOUNDARY-START(25771245690)
            $ctor$3(/*DateTimeOffset*/ lastModified)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771245690);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._lastModified = lastModified;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245690)
            
            //--TRIMMABLE-BOUNDARY-START(21476278394)
            $ctor$2(/*EntityTagHeaderValue*/ entityTag)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476278394);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(entityTag, "entityTag");
                    this._entityTag = entityTag;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278394)
            
            //--TRIMMABLE-BOUNDARY-START(30066212986)
            $ctor$4(/*string?*/ entityTag)
            {
                this.$ctor$2(new $.$mnhh.MNHH.EntityTagHeaderValue().$ctor$3($.$mep.MEP.StringSegment.op_Implicit$2(entityTag)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066212986);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212986)
            
            //--TRIMMABLE-BOUNDARY-START(68720918650)
            /*DateTimeOffset? */ get LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$clone(this._lastModified);
            }
            //--TRIMMABLE-BOUNDARY-END(68720918650)
            
            //--TRIMMABLE-BOUNDARY-START(34361180282)
            /*EntityTagHeaderValue? */ get EntityTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._entityTag;
            }
            //--TRIMMABLE-BOUNDARY-END(34361180282)
            
            //--TRIMMABLE-BOUNDARY-START(81605820538)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._entityTag === null)
                {
                    return $.$mnhh.MNHH.HeaderUtilities.FormatDate$1($.$$.S.Nullable$$($.$$.S.DateTimeOffset).GetValueOrDefault.call(this._lastModified));
                }
                return this._entityTag.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(81605820538)
            
            //--TRIMMABLE-BOUNDARY-START(38656147578)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.RangeConditionHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (this._entityTag === null)
                {
                    return (other._lastModified !== null) && ($.$$.S.DateTimeOffset.op_Equality($.$$.S.Nullable$$($.$$.S.DateTimeOffset).GetValueOrDefault.call(this._lastModified), $.$$.S.Nullable$$($.$$.S.DateTimeOffset).GetValueOrDefault.call(other._lastModified)));
                }
                return this._entityTag.Equals$1(other._entityTag);
            }
            //--TRIMMABLE-BOUNDARY-END(38656147578)
            
            //--TRIMMABLE-BOUNDARY-START(60130984058)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130984058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._entityTag === null)
                {
                    return $.$$.S.Nullable$$($.$$.S.DateTimeOffset).GetValueOrDefault.call(this._lastModified).GetHashCode();
                }
                return this._entityTag.GetHashCode();
            }
            //--TRIMMABLE-BOUNDARY-END(60130984058)
            
            //--TRIMMABLE-BOUNDARY-START(73015885946)
            static /*RangeConditionHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.RangeConditionHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(73015885946)
            
            //--TRIMMABLE-BOUNDARY-START(85900787834)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out RangeConditionHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.RangeConditionHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(85900787834)
            
            //--TRIMMABLE-BOUNDARY-START(64425951354)
            static /*int */ GetRangeConditionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeConditionHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (((startIndex + 1) | 0) >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*DateTimeOffset*/ let date = $.$$.S.DateTimeOffset.MinValue;
                /*EntityTagHeaderValue?*/ let entityTag = null;
                /*var*/ let firstChar = input.get_Item$1(current);
                /*var*/ let secondChar = input.get_Item$1(((current + 1) | 0));
                if ((firstChar === /*\"*/ 34) || (((firstChar === /*w*/ 119) || (firstChar === /*W*/ 87)) && (secondChar === /*/*/ 47)))
                {
                    /*var*/ let entityTagLength = $.$mnhh.MNHH.EntityTagHeaderValue.GetEntityTagLength(input, current, $.$ref(() => entityTag, ($v) => entityTag = $v, $.$mnhh.MNHH.EntityTagHeaderValue));
                    if (entityTagLength === 0)
                    {
                        return 0;
                    }
                    current = ((current + entityTagLength) | 0);
                    if (current !== input.Length)
                    {
                        return 0;
                    }
                }
                else 
                {
                    if (!$.$mnhh.MNHH.HttpRuleParser.TryStringToDate(input.Subsegment$1(current), $.$ref(() => date, ($v) => date = $v, $.$$.S.DateTimeOffset)))
                    {
                        return 0;
                    }
                    current = input.Length;
                }
                parsedValue.$v = new $.$mnhh.MNHH.RangeConditionHeaderValue().$ctor$1();
                if (entityTag === null)
                {
                    parsedValue.$v._lastModified = date;
                }
                else 
                {
                    parsedValue.$v._entityTag = entityTag;
                }
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(64425951354)
            
            //--TRIMMABLE-BOUNDARY-START(17181311098)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181311098)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591376506)
                this._lastModified = null;
                //--TRIMMABLE-BOUNDARY-END(8591376506)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886343802)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(77310853242)
                    this.Parser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.RangeConditionHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.RangeConditionHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.RangeConditionHeaderValue, $.$mnhh.MNHH.RangeConditionHeaderValue.GetRangeConditionLength));
                    //--TRIMMABLE-BOUNDARY-END(77310853242)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886343802)
            
            static $h = 1441914;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720918650),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836016762,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 1441914,
      "h": 68720918650,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720918650),
//--TRIMMABLE-BOUNDARY-START(34361180282),
    {
      "p": 589946,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246082170,
        "f": 50331649
      },
      "n": "EntityTag",
      "d": 1441914,
      "h": 34361180282,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361180282)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605820538),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1441914,
      "h": 81605820538,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605820538),
//--TRIMMABLE-BOUNDARY-START(38656147578),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1441914,
      "h": 38656147578,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656147578),
//--TRIMMABLE-BOUNDARY-START(60130984058),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1441914,
      "h": 60130984058,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130984058),
//--TRIMMABLE-BOUNDARY-START(73015885946),
    {
      "r": 1441914,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1441914,
      "h": 73015885946,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015885946),
//--TRIMMABLE-BOUNDARY-START(85900787834),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1441914,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1441914,
      "h": 85900787834,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85900787834),
//--TRIMMABLE-BOUNDARY-START(64425951354),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1441914,
          "f": 2
        }
      ],
      "n": "GetRangeConditionLength",
      "d": 1441914,
      "h": 64425951354,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425951354)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77310853242),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.RangeConditionHeaderValue).$h,
      "n": "Parser",
      "d": 1441914,
      "h": 77310853242,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310853242),
//--TRIMMABLE-BOUNDARY-START(8591376506),
    {
      "t": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "n": "_lastModified",
      "d": 1441914,
      "h": 8591376506,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591376506),
//--TRIMMABLE-BOUNDARY-START(4296409210),
    {
      "t": 589946,
      "n": "_entityTag",
      "d": 1441914,
      "h": 4296409210,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409210)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181311098),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441914,
      "h": 17181311098,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181311098),
//--TRIMMABLE-BOUNDARY-START(25771245690),
    {
      "p": [
        {
          "n": "lastModified",
          "p": 66191361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441914,
      "h": 25771245690,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771245690),
//--TRIMMABLE-BOUNDARY-START(21476278394),
    {
      "p": [
        {
          "n": "entityTag",
          "p": 589946
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441914,
      "h": 21476278394,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476278394),
//--TRIMMABLE-BOUNDARY-START(30066212986),
    {
      "p": [
        {
          "n": "entityTag",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1441914,
      "h": 30066212986,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066212986)
  ],
  "h": 1441914
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.RangeConditionHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}RangeConditionHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441914)
        
        

        //--TRIMMABLE-BOUNDARY-START(262266)
        $asm.$cls(`$mnhh.MNHH.ContentDispositionHeaderValueIdentityExtensions`, ($self) => class ContentDispositionHeaderValueIdentityExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295229562)
            static /*bool */ IsFileDisposition(/*this ContentDispositionHeaderValue*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(header, "header");
                return header.DispositionType.Equals$3("form-data") && (!$.$mep.MEP.StringSegment.IsNullOrEmpty(header.FileName) || !$.$mep.MEP.StringSegment.IsNullOrEmpty(header.FileNameStar));
            }
            //--TRIMMABLE-BOUNDARY-END(4295229562)
            
            //--TRIMMABLE-BOUNDARY-START(8590196858)
            static /*bool */ IsFormDisposition(/*this ContentDispositionHeaderValue*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(header, "header");
                return header.DispositionType.Equals$3("form-data") && $.$mep.MEP.StringSegment.IsNullOrEmpty(header.FileName) && $.$mep.MEP.StringSegment.IsNullOrEmpty(header.FileNameStar);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196858)
            
            static $h = 262266;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229562),
    {
      "r": 262145,
      "p": [
        {
          "n": "header",
          "p": 196730
        }
      ],
      "n": "IsFileDisposition",
      "d": 262266,
      "h": 4295229562,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295229562),
//--TRIMMABLE-BOUNDARY-START(8590196858),
    {
      "r": 262145,
      "p": [
        {
          "n": "header",
          "p": 196730
        }
      ],
      "n": "IsFormDisposition",
      "d": 262266,
      "h": 8590196858,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196858)
  ],
  "h": 262266
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.ContentDispositionHeaderValueIdentityExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}ContentDispositionHeaderValueIdentityExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262266)
        
        

        //--TRIMMABLE-BOUNDARY-START(786554)
        $asm.$cls(`$mnhh.MNHH.HeaderNames`, ($self) => class HeaderNames
        {
            //--TRIMMABLE-BOUNDARY-START(274878693498)
            /*string*/ static PseudoHeaderNamesObsoletionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878693498)
            
            //--TRIMMABLE-BOUNDARY-START(8590721146)
            /*string*/ static Accept = null;
            //--TRIMMABLE-BOUNDARY-END(8590721146)
            
            //--TRIMMABLE-BOUNDARY-START(12885688442)
            /*string*/ static AcceptCharset = null;
            //--TRIMMABLE-BOUNDARY-END(12885688442)
            
            //--TRIMMABLE-BOUNDARY-START(17180655738)
            /*string*/ static AcceptEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(17180655738)
            
            //--TRIMMABLE-BOUNDARY-START(21475623034)
            /*string*/ static AcceptLanguage = null;
            //--TRIMMABLE-BOUNDARY-END(21475623034)
            
            //--TRIMMABLE-BOUNDARY-START(25770590330)
            /*string*/ static AcceptRanges = null;
            //--TRIMMABLE-BOUNDARY-END(25770590330)
            
            //--TRIMMABLE-BOUNDARY-START(30065557626)
            /*string*/ static AccessControlAllowCredentials = null;
            //--TRIMMABLE-BOUNDARY-END(30065557626)
            
            //--TRIMMABLE-BOUNDARY-START(34360524922)
            /*string*/ static AccessControlAllowHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(34360524922)
            
            //--TRIMMABLE-BOUNDARY-START(38655492218)
            /*string*/ static AccessControlAllowMethods = null;
            //--TRIMMABLE-BOUNDARY-END(38655492218)
            
            //--TRIMMABLE-BOUNDARY-START(42950459514)
            /*string*/ static AccessControlAllowOrigin = null;
            //--TRIMMABLE-BOUNDARY-END(42950459514)
            
            //--TRIMMABLE-BOUNDARY-START(47245426810)
            /*string*/ static AccessControlExposeHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(47245426810)
            
            //--TRIMMABLE-BOUNDARY-START(51540394106)
            /*string*/ static AccessControlMaxAge = null;
            //--TRIMMABLE-BOUNDARY-END(51540394106)
            
            //--TRIMMABLE-BOUNDARY-START(55835361402)
            /*string*/ static AccessControlRequestHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(55835361402)
            
            //--TRIMMABLE-BOUNDARY-START(60130328698)
            /*string*/ static AccessControlRequestMethod = null;
            //--TRIMMABLE-BOUNDARY-END(60130328698)
            
            //--TRIMMABLE-BOUNDARY-START(64425295994)
            /*string*/ static Age = null;
            //--TRIMMABLE-BOUNDARY-END(64425295994)
            
            //--TRIMMABLE-BOUNDARY-START(68720263290)
            /*string*/ static Allow = null;
            //--TRIMMABLE-BOUNDARY-END(68720263290)
            
            //--TRIMMABLE-BOUNDARY-START(73015230586)
            /*string*/ static AltSvc = null;
            //--TRIMMABLE-BOUNDARY-END(73015230586)
            
            //--TRIMMABLE-BOUNDARY-START(77310197882)
            /*string*/ static Authority = null;
            //--TRIMMABLE-BOUNDARY-END(77310197882)
            
            //--TRIMMABLE-BOUNDARY-START(81605165178)
            /*string*/ static Authorization = null;
            //--TRIMMABLE-BOUNDARY-END(81605165178)
            
            //--TRIMMABLE-BOUNDARY-START(85900132474)
            /*string*/ static Baggage = null;
            //--TRIMMABLE-BOUNDARY-END(85900132474)
            
            //--TRIMMABLE-BOUNDARY-START(90195099770)
            /*string*/ static CacheControl = null;
            //--TRIMMABLE-BOUNDARY-END(90195099770)
            
            //--TRIMMABLE-BOUNDARY-START(94490067066)
            /*string*/ static Connection = null;
            //--TRIMMABLE-BOUNDARY-END(94490067066)
            
            //--TRIMMABLE-BOUNDARY-START(98785034362)
            /*string*/ static ContentDisposition = null;
            //--TRIMMABLE-BOUNDARY-END(98785034362)
            
            //--TRIMMABLE-BOUNDARY-START(103080001658)
            /*string*/ static ContentEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(103080001658)
            
            //--TRIMMABLE-BOUNDARY-START(107374968954)
            /*string*/ static ContentLanguage = null;
            //--TRIMMABLE-BOUNDARY-END(107374968954)
            
            //--TRIMMABLE-BOUNDARY-START(111669936250)
            /*string*/ static ContentLength = null;
            //--TRIMMABLE-BOUNDARY-END(111669936250)
            
            //--TRIMMABLE-BOUNDARY-START(115964903546)
            /*string*/ static ContentLocation = null;
            //--TRIMMABLE-BOUNDARY-END(115964903546)
            
            //--TRIMMABLE-BOUNDARY-START(120259870842)
            /*string*/ static ContentMD5 = null;
            //--TRIMMABLE-BOUNDARY-END(120259870842)
            
            //--TRIMMABLE-BOUNDARY-START(124554838138)
            /*string*/ static ContentRange = null;
            //--TRIMMABLE-BOUNDARY-END(124554838138)
            
            //--TRIMMABLE-BOUNDARY-START(128849805434)
            /*string*/ static ContentSecurityPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(128849805434)
            
            //--TRIMMABLE-BOUNDARY-START(133144772730)
            /*string*/ static ContentSecurityPolicyReportOnly = null;
            //--TRIMMABLE-BOUNDARY-END(133144772730)
            
            //--TRIMMABLE-BOUNDARY-START(137439740026)
            /*string*/ static ContentType = null;
            //--TRIMMABLE-BOUNDARY-END(137439740026)
            
            //--TRIMMABLE-BOUNDARY-START(146029674618)
            /*string*/ static CorrelationContext = null;
            //--TRIMMABLE-BOUNDARY-END(146029674618)
            
            //--TRIMMABLE-BOUNDARY-START(141734707322)
            /*string*/ static Cookie = null;
            //--TRIMMABLE-BOUNDARY-END(141734707322)
            
            //--TRIMMABLE-BOUNDARY-START(150324641914)
            /*string*/ static Date = null;
            //--TRIMMABLE-BOUNDARY-END(150324641914)
            
            //--TRIMMABLE-BOUNDARY-START(154619609210)
            /*string*/ static DNT = null;
            //--TRIMMABLE-BOUNDARY-END(154619609210)
            
            //--TRIMMABLE-BOUNDARY-START(158914576506)
            /*string*/ static ETag = null;
            //--TRIMMABLE-BOUNDARY-END(158914576506)
            
            //--TRIMMABLE-BOUNDARY-START(167504511098)
            /*string*/ static Expires = null;
            //--TRIMMABLE-BOUNDARY-END(167504511098)
            
            //--TRIMMABLE-BOUNDARY-START(163209543802)
            /*string*/ static Expect = null;
            //--TRIMMABLE-BOUNDARY-END(163209543802)
            
            //--TRIMMABLE-BOUNDARY-START(171799478394)
            /*string*/ static From = null;
            //--TRIMMABLE-BOUNDARY-END(171799478394)
            
            //--TRIMMABLE-BOUNDARY-START(176094445690)
            /*string*/ static GrpcAcceptEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(176094445690)
            
            //--TRIMMABLE-BOUNDARY-START(180389412986)
            /*string*/ static GrpcEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(180389412986)
            
            //--TRIMMABLE-BOUNDARY-START(184684380282)
            /*string*/ static GrpcMessage = null;
            //--TRIMMABLE-BOUNDARY-END(184684380282)
            
            //--TRIMMABLE-BOUNDARY-START(188979347578)
            /*string*/ static GrpcStatus = null;
            //--TRIMMABLE-BOUNDARY-END(188979347578)
            
            //--TRIMMABLE-BOUNDARY-START(193274314874)
            /*string*/ static GrpcTimeout = null;
            //--TRIMMABLE-BOUNDARY-END(193274314874)
            
            //--TRIMMABLE-BOUNDARY-START(197569282170)
            /*string*/ static Host = null;
            //--TRIMMABLE-BOUNDARY-END(197569282170)
            
            //--TRIMMABLE-BOUNDARY-START(223339085946)
            /*string*/ static KeepAlive = null;
            //--TRIMMABLE-BOUNDARY-END(223339085946)
            
            //--TRIMMABLE-BOUNDARY-START(201864249466)
            /*string*/ static IfMatch = null;
            //--TRIMMABLE-BOUNDARY-END(201864249466)
            
            //--TRIMMABLE-BOUNDARY-START(206159216762)
            /*string*/ static IfModifiedSince = null;
            //--TRIMMABLE-BOUNDARY-END(206159216762)
            
            //--TRIMMABLE-BOUNDARY-START(210454184058)
            /*string*/ static IfNoneMatch = null;
            //--TRIMMABLE-BOUNDARY-END(210454184058)
            
            //--TRIMMABLE-BOUNDARY-START(214749151354)
            /*string*/ static IfRange = null;
            //--TRIMMABLE-BOUNDARY-END(214749151354)
            
            //--TRIMMABLE-BOUNDARY-START(219044118650)
            /*string*/ static IfUnmodifiedSince = null;
            //--TRIMMABLE-BOUNDARY-END(219044118650)
            
            //--TRIMMABLE-BOUNDARY-START(227634053242)
            /*string*/ static LastModified = null;
            //--TRIMMABLE-BOUNDARY-END(227634053242)
            
            //--TRIMMABLE-BOUNDARY-START(231929020538)
            /*string*/ static Link = null;
            //--TRIMMABLE-BOUNDARY-END(231929020538)
            
            //--TRIMMABLE-BOUNDARY-START(236223987834)
            /*string*/ static Location = null;
            //--TRIMMABLE-BOUNDARY-END(236223987834)
            
            //--TRIMMABLE-BOUNDARY-START(240518955130)
            /*string*/ static MaxForwards = null;
            //--TRIMMABLE-BOUNDARY-END(240518955130)
            
            //--TRIMMABLE-BOUNDARY-START(244813922426)
            /*string*/ static Method = null;
            //--TRIMMABLE-BOUNDARY-END(244813922426)
            
            //--TRIMMABLE-BOUNDARY-START(249108889722)
            /*string*/ static Origin = null;
            //--TRIMMABLE-BOUNDARY-END(249108889722)
            
            //--TRIMMABLE-BOUNDARY-START(253403857018)
            /*string*/ static Path = null;
            //--TRIMMABLE-BOUNDARY-END(253403857018)
            
            //--TRIMMABLE-BOUNDARY-START(257698824314)
            /*string*/ static Pragma = null;
            //--TRIMMABLE-BOUNDARY-END(257698824314)
            
            //--TRIMMABLE-BOUNDARY-START(261993791610)
            /*string*/ static ProxyAuthenticate = null;
            //--TRIMMABLE-BOUNDARY-END(261993791610)
            
            //--TRIMMABLE-BOUNDARY-START(266288758906)
            /*string*/ static ProxyAuthorization = null;
            //--TRIMMABLE-BOUNDARY-END(266288758906)
            
            //--TRIMMABLE-BOUNDARY-START(270583726202)
            /*string*/ static ProxyConnection = null;
            //--TRIMMABLE-BOUNDARY-END(270583726202)
            
            //--TRIMMABLE-BOUNDARY-START(279173660794)
            /*string*/ static Range = null;
            //--TRIMMABLE-BOUNDARY-END(279173660794)
            
            //--TRIMMABLE-BOUNDARY-START(283468628090)
            /*string*/ static Referer = null;
            //--TRIMMABLE-BOUNDARY-END(283468628090)
            
            //--TRIMMABLE-BOUNDARY-START(292058562682)
            /*string*/ static RetryAfter = null;
            //--TRIMMABLE-BOUNDARY-END(292058562682)
            
            //--TRIMMABLE-BOUNDARY-START(287763595386)
            /*string*/ static RequestId = null;
            //--TRIMMABLE-BOUNDARY-END(287763595386)
            
            //--TRIMMABLE-BOUNDARY-START(296353529978)
            /*string*/ static Scheme = null;
            //--TRIMMABLE-BOUNDARY-END(296353529978)
            
            //--TRIMMABLE-BOUNDARY-START(300648497274)
            /*string*/ static SecWebSocketAccept = null;
            //--TRIMMABLE-BOUNDARY-END(300648497274)
            
            //--TRIMMABLE-BOUNDARY-START(309238431866)
            /*string*/ static SecWebSocketKey = null;
            //--TRIMMABLE-BOUNDARY-END(309238431866)
            
            //--TRIMMABLE-BOUNDARY-START(313533399162)
            /*string*/ static SecWebSocketProtocol = null;
            //--TRIMMABLE-BOUNDARY-END(313533399162)
            
            //--TRIMMABLE-BOUNDARY-START(317828366458)
            /*string*/ static SecWebSocketVersion = null;
            //--TRIMMABLE-BOUNDARY-END(317828366458)
            
            //--TRIMMABLE-BOUNDARY-START(304943464570)
            /*string*/ static SecWebSocketExtensions = null;
            //--TRIMMABLE-BOUNDARY-END(304943464570)
            
            //--TRIMMABLE-BOUNDARY-START(322123333754)
            /*string*/ static Server = null;
            //--TRIMMABLE-BOUNDARY-END(322123333754)
            
            //--TRIMMABLE-BOUNDARY-START(326418301050)
            /*string*/ static SetCookie = null;
            //--TRIMMABLE-BOUNDARY-END(326418301050)
            
            //--TRIMMABLE-BOUNDARY-START(330713268346)
            /*string*/ static Status = null;
            //--TRIMMABLE-BOUNDARY-END(330713268346)
            
            //--TRIMMABLE-BOUNDARY-START(335008235642)
            /*string*/ static StrictTransportSecurity = null;
            //--TRIMMABLE-BOUNDARY-END(335008235642)
            
            //--TRIMMABLE-BOUNDARY-START(339303202938)
            /*string*/ static TE = null;
            //--TRIMMABLE-BOUNDARY-END(339303202938)
            
            //--TRIMMABLE-BOUNDARY-START(352188104826)
            /*string*/ static Trailer = null;
            //--TRIMMABLE-BOUNDARY-END(352188104826)
            
            //--TRIMMABLE-BOUNDARY-START(356483072122)
            /*string*/ static TransferEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(356483072122)
            
            //--TRIMMABLE-BOUNDARY-START(360778039418)
            /*string*/ static Translate = null;
            //--TRIMMABLE-BOUNDARY-END(360778039418)
            
            //--TRIMMABLE-BOUNDARY-START(343598170234)
            /*string*/ static TraceParent = null;
            //--TRIMMABLE-BOUNDARY-END(343598170234)
            
            //--TRIMMABLE-BOUNDARY-START(347893137530)
            /*string*/ static TraceState = null;
            //--TRIMMABLE-BOUNDARY-END(347893137530)
            
            //--TRIMMABLE-BOUNDARY-START(365073006714)
            /*string*/ static Upgrade = null;
            //--TRIMMABLE-BOUNDARY-END(365073006714)
            
            //--TRIMMABLE-BOUNDARY-START(369367974010)
            /*string*/ static UpgradeInsecureRequests = null;
            //--TRIMMABLE-BOUNDARY-END(369367974010)
            
            //--TRIMMABLE-BOUNDARY-START(373662941306)
            /*string*/ static UserAgent = null;
            //--TRIMMABLE-BOUNDARY-END(373662941306)
            
            //--TRIMMABLE-BOUNDARY-START(377957908602)
            /*string*/ static Vary = null;
            //--TRIMMABLE-BOUNDARY-END(377957908602)
            
            //--TRIMMABLE-BOUNDARY-START(382252875898)
            /*string*/ static Via = null;
            //--TRIMMABLE-BOUNDARY-END(382252875898)
            
            //--TRIMMABLE-BOUNDARY-START(386547843194)
            /*string*/ static Warning = null;
            //--TRIMMABLE-BOUNDARY-END(386547843194)
            
            //--TRIMMABLE-BOUNDARY-START(390842810490)
            /*string*/ static WebSocketSubProtocols = null;
            //--TRIMMABLE-BOUNDARY-END(390842810490)
            
            //--TRIMMABLE-BOUNDARY-START(395137777786)
            /*string*/ static WWWAuthenticate = null;
            //--TRIMMABLE-BOUNDARY-END(395137777786)
            
            //--TRIMMABLE-BOUNDARY-START(399432745082)
            /*string*/ static XContentTypeOptions = null;
            //--TRIMMABLE-BOUNDARY-END(399432745082)
            
            //--TRIMMABLE-BOUNDARY-START(403727712378)
            /*string*/ static XFrameOptions = null;
            //--TRIMMABLE-BOUNDARY-END(403727712378)
            
            //--TRIMMABLE-BOUNDARY-START(408022679674)
            /*string*/ static XPoweredBy = null;
            //--TRIMMABLE-BOUNDARY-END(408022679674)
            
            //--TRIMMABLE-BOUNDARY-START(412317646970)
            /*string*/ static XRequestedWith = null;
            //--TRIMMABLE-BOUNDARY-END(412317646970)
            
            //--TRIMMABLE-BOUNDARY-START(416612614266)
            /*string*/ static XUACompatible = null;
            //--TRIMMABLE-BOUNDARY-END(416612614266)
            
            //--TRIMMABLE-BOUNDARY-START(420907581562)
            /*string*/ static XXSSProtection = null;
            //--TRIMMABLE-BOUNDARY-END(420907581562)
            
            //--TRIMMABLE-BOUNDARY-START(4295753850)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(274878693498)
                    this.PseudoHeaderNamesObsoletionMessage = "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.";
                    //--TRIMMABLE-BOUNDARY-END(274878693498)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590721146)
                    this.Accept = "Accept";
                    //--TRIMMABLE-BOUNDARY-END(8590721146)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885688442)
                    this.AcceptCharset = "Accept-Charset";
                    //--TRIMMABLE-BOUNDARY-END(12885688442)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180655738)
                    this.AcceptEncoding = "Accept-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(17180655738)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475623034)
                    this.AcceptLanguage = "Accept-Language";
                    //--TRIMMABLE-BOUNDARY-END(21475623034)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770590330)
                    this.AcceptRanges = "Accept-Ranges";
                    //--TRIMMABLE-BOUNDARY-END(25770590330)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065557626)
                    this.AccessControlAllowCredentials = "Access-Control-Allow-Credentials";
                    //--TRIMMABLE-BOUNDARY-END(30065557626)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360524922)
                    this.AccessControlAllowHeaders = "Access-Control-Allow-Headers";
                    //--TRIMMABLE-BOUNDARY-END(34360524922)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655492218)
                    this.AccessControlAllowMethods = "Access-Control-Allow-Methods";
                    //--TRIMMABLE-BOUNDARY-END(38655492218)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950459514)
                    this.AccessControlAllowOrigin = "Access-Control-Allow-Origin";
                    //--TRIMMABLE-BOUNDARY-END(42950459514)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245426810)
                    this.AccessControlExposeHeaders = "Access-Control-Expose-Headers";
                    //--TRIMMABLE-BOUNDARY-END(47245426810)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540394106)
                    this.AccessControlMaxAge = "Access-Control-Max-Age";
                    //--TRIMMABLE-BOUNDARY-END(51540394106)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835361402)
                    this.AccessControlRequestHeaders = "Access-Control-Request-Headers";
                    //--TRIMMABLE-BOUNDARY-END(55835361402)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130328698)
                    this.AccessControlRequestMethod = "Access-Control-Request-Method";
                    //--TRIMMABLE-BOUNDARY-END(60130328698)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425295994)
                    this.Age = "Age";
                    //--TRIMMABLE-BOUNDARY-END(64425295994)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720263290)
                    this.Allow = "Allow";
                    //--TRIMMABLE-BOUNDARY-END(68720263290)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015230586)
                    this.AltSvc = "Alt-Svc";
                    //--TRIMMABLE-BOUNDARY-END(73015230586)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310197882)
                    this.Authority = ":authority";
                    //--TRIMMABLE-BOUNDARY-END(77310197882)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605165178)
                    this.Authorization = "Authorization";
                    //--TRIMMABLE-BOUNDARY-END(81605165178)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900132474)
                    this.Baggage = "baggage";
                    //--TRIMMABLE-BOUNDARY-END(85900132474)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195099770)
                    this.CacheControl = "Cache-Control";
                    //--TRIMMABLE-BOUNDARY-END(90195099770)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490067066)
                    this.Connection = "Connection";
                    //--TRIMMABLE-BOUNDARY-END(94490067066)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98785034362)
                    this.ContentDisposition = "Content-Disposition";
                    //--TRIMMABLE-BOUNDARY-END(98785034362)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080001658)
                    this.ContentEncoding = "Content-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(103080001658)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374968954)
                    this.ContentLanguage = "Content-Language";
                    //--TRIMMABLE-BOUNDARY-END(107374968954)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669936250)
                    this.ContentLength = "Content-Length";
                    //--TRIMMABLE-BOUNDARY-END(111669936250)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964903546)
                    this.ContentLocation = "Content-Location";
                    //--TRIMMABLE-BOUNDARY-END(115964903546)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259870842)
                    this.ContentMD5 = "Content-MD5";
                    //--TRIMMABLE-BOUNDARY-END(120259870842)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554838138)
                    this.ContentRange = "Content-Range";
                    //--TRIMMABLE-BOUNDARY-END(124554838138)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849805434)
                    this.ContentSecurityPolicy = "Content-Security-Policy";
                    //--TRIMMABLE-BOUNDARY-END(128849805434)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144772730)
                    this.ContentSecurityPolicyReportOnly = "Content-Security-Policy-Report-Only";
                    //--TRIMMABLE-BOUNDARY-END(133144772730)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439740026)
                    this.ContentType = "Content-Type";
                    //--TRIMMABLE-BOUNDARY-END(137439740026)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029674618)
                    this.CorrelationContext = "Correlation-Context";
                    //--TRIMMABLE-BOUNDARY-END(146029674618)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734707322)
                    this.Cookie = "Cookie";
                    //--TRIMMABLE-BOUNDARY-END(141734707322)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324641914)
                    this.Date = "Date";
                    //--TRIMMABLE-BOUNDARY-END(150324641914)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619609210)
                    this.DNT = "DNT";
                    //--TRIMMABLE-BOUNDARY-END(154619609210)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914576506)
                    this.ETag = "ETag";
                    //--TRIMMABLE-BOUNDARY-END(158914576506)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504511098)
                    this.Expires = "Expires";
                    //--TRIMMABLE-BOUNDARY-END(167504511098)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209543802)
                    this.Expect = "Expect";
                    //--TRIMMABLE-BOUNDARY-END(163209543802)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799478394)
                    this.From = "From";
                    //--TRIMMABLE-BOUNDARY-END(171799478394)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094445690)
                    this.GrpcAcceptEncoding = "Grpc-Accept-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(176094445690)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389412986)
                    this.GrpcEncoding = "Grpc-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(180389412986)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184684380282)
                    this.GrpcMessage = "Grpc-Message";
                    //--TRIMMABLE-BOUNDARY-END(184684380282)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979347578)
                    this.GrpcStatus = "Grpc-Status";
                    //--TRIMMABLE-BOUNDARY-END(188979347578)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274314874)
                    this.GrpcTimeout = "Grpc-Timeout";
                    //--TRIMMABLE-BOUNDARY-END(193274314874)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569282170)
                    this.Host = "Host";
                    //--TRIMMABLE-BOUNDARY-END(197569282170)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223339085946)
                    this.KeepAlive = "Keep-Alive";
                    //--TRIMMABLE-BOUNDARY-END(223339085946)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201864249466)
                    this.IfMatch = "If-Match";
                    //--TRIMMABLE-BOUNDARY-END(201864249466)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206159216762)
                    this.IfModifiedSince = "If-Modified-Since";
                    //--TRIMMABLE-BOUNDARY-END(206159216762)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210454184058)
                    this.IfNoneMatch = "If-None-Match";
                    //--TRIMMABLE-BOUNDARY-END(210454184058)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749151354)
                    this.IfRange = "If-Range";
                    //--TRIMMABLE-BOUNDARY-END(214749151354)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219044118650)
                    this.IfUnmodifiedSince = "If-Unmodified-Since";
                    //--TRIMMABLE-BOUNDARY-END(219044118650)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227634053242)
                    this.LastModified = "Last-Modified";
                    //--TRIMMABLE-BOUNDARY-END(227634053242)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929020538)
                    this.Link = "Link";
                    //--TRIMMABLE-BOUNDARY-END(231929020538)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223987834)
                    this.Location = "Location";
                    //--TRIMMABLE-BOUNDARY-END(236223987834)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518955130)
                    this.MaxForwards = "Max-Forwards";
                    //--TRIMMABLE-BOUNDARY-END(240518955130)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813922426)
                    this.Method = ":method";
                    //--TRIMMABLE-BOUNDARY-END(244813922426)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108889722)
                    this.Origin = "Origin";
                    //--TRIMMABLE-BOUNDARY-END(249108889722)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403857018)
                    this.Path = ":path";
                    //--TRIMMABLE-BOUNDARY-END(253403857018)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698824314)
                    this.Pragma = "Pragma";
                    //--TRIMMABLE-BOUNDARY-END(257698824314)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993791610)
                    this.ProxyAuthenticate = "Proxy-Authenticate";
                    //--TRIMMABLE-BOUNDARY-END(261993791610)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288758906)
                    this.ProxyAuthorization = "Proxy-Authorization";
                    //--TRIMMABLE-BOUNDARY-END(266288758906)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583726202)
                    this.ProxyConnection = "Proxy-Connection";
                    //--TRIMMABLE-BOUNDARY-END(270583726202)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173660794)
                    this.Range = "Range";
                    //--TRIMMABLE-BOUNDARY-END(279173660794)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468628090)
                    this.Referer = "Referer";
                    //--TRIMMABLE-BOUNDARY-END(283468628090)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292058562682)
                    this.RetryAfter = "Retry-After";
                    //--TRIMMABLE-BOUNDARY-END(292058562682)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763595386)
                    this.RequestId = "Request-Id";
                    //--TRIMMABLE-BOUNDARY-END(287763595386)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296353529978)
                    this.Scheme = ":scheme";
                    //--TRIMMABLE-BOUNDARY-END(296353529978)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300648497274)
                    this.SecWebSocketAccept = "Sec-WebSocket-Accept";
                    //--TRIMMABLE-BOUNDARY-END(300648497274)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309238431866)
                    this.SecWebSocketKey = "Sec-WebSocket-Key";
                    //--TRIMMABLE-BOUNDARY-END(309238431866)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313533399162)
                    this.SecWebSocketProtocol = "Sec-WebSocket-Protocol";
                    //--TRIMMABLE-BOUNDARY-END(313533399162)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317828366458)
                    this.SecWebSocketVersion = "Sec-WebSocket-Version";
                    //--TRIMMABLE-BOUNDARY-END(317828366458)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943464570)
                    this.SecWebSocketExtensions = "Sec-WebSocket-Extensions";
                    //--TRIMMABLE-BOUNDARY-END(304943464570)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322123333754)
                    this.Server = "Server";
                    //--TRIMMABLE-BOUNDARY-END(322123333754)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326418301050)
                    this.SetCookie = "Set-Cookie";
                    //--TRIMMABLE-BOUNDARY-END(326418301050)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713268346)
                    this.Status = ":status";
                    //--TRIMMABLE-BOUNDARY-END(330713268346)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335008235642)
                    this.StrictTransportSecurity = "Strict-Transport-Security";
                    //--TRIMMABLE-BOUNDARY-END(335008235642)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339303202938)
                    this.TE = "TE";
                    //--TRIMMABLE-BOUNDARY-END(339303202938)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352188104826)
                    this.Trailer = "Trailer";
                    //--TRIMMABLE-BOUNDARY-END(352188104826)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356483072122)
                    this.TransferEncoding = "Transfer-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(356483072122)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360778039418)
                    this.Translate = "Translate";
                    //--TRIMMABLE-BOUNDARY-END(360778039418)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598170234)
                    this.TraceParent = "traceparent";
                    //--TRIMMABLE-BOUNDARY-END(343598170234)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347893137530)
                    this.TraceState = "tracestate";
                    //--TRIMMABLE-BOUNDARY-END(347893137530)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365073006714)
                    this.Upgrade = "Upgrade";
                    //--TRIMMABLE-BOUNDARY-END(365073006714)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367974010)
                    this.UpgradeInsecureRequests = "Upgrade-Insecure-Requests";
                    //--TRIMMABLE-BOUNDARY-END(369367974010)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662941306)
                    this.UserAgent = "User-Agent";
                    //--TRIMMABLE-BOUNDARY-END(373662941306)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957908602)
                    this.Vary = "Vary";
                    //--TRIMMABLE-BOUNDARY-END(377957908602)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(382252875898)
                    this.Via = "Via";
                    //--TRIMMABLE-BOUNDARY-END(382252875898)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547843194)
                    this.Warning = "Warning";
                    //--TRIMMABLE-BOUNDARY-END(386547843194)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842810490)
                    this.WebSocketSubProtocols = "Sec-WebSocket-Protocol";
                    //--TRIMMABLE-BOUNDARY-END(390842810490)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137777786)
                    this.WWWAuthenticate = "WWW-Authenticate";
                    //--TRIMMABLE-BOUNDARY-END(395137777786)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432745082)
                    this.XContentTypeOptions = "X-Content-Type-Options";
                    //--TRIMMABLE-BOUNDARY-END(399432745082)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727712378)
                    this.XFrameOptions = "X-Frame-Options";
                    //--TRIMMABLE-BOUNDARY-END(403727712378)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022679674)
                    this.XPoweredBy = "X-Powered-By";
                    //--TRIMMABLE-BOUNDARY-END(408022679674)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412317646970)
                    this.XRequestedWith = "X-Requested-With";
                    //--TRIMMABLE-BOUNDARY-END(412317646970)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416612614266)
                    this.XUACompatible = "X-UA-Compatible";
                    //--TRIMMABLE-BOUNDARY-END(416612614266)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420907581562)
                    this.XXSSProtection = "X-XSS-Protection";
                    //--TRIMMABLE-BOUNDARY-END(420907581562)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753850)
            
            static $h = 786554;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(274878693498),
    {
      "t": 1310721,
      "n": "PseudoHeaderNamesObsoletionMessage",
      "d": 786554,
      "h": 274878693498,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(274878693498),
//--TRIMMABLE-BOUNDARY-START(8590721146),
    {
      "t": 1310721,
      "n": "Accept",
      "d": 786554,
      "h": 8590721146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721146),
//--TRIMMABLE-BOUNDARY-START(12885688442),
    {
      "t": 1310721,
      "n": "AcceptCharset",
      "d": 786554,
      "h": 12885688442,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688442),
//--TRIMMABLE-BOUNDARY-START(17180655738),
    {
      "t": 1310721,
      "n": "AcceptEncoding",
      "d": 786554,
      "h": 17180655738,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180655738),
//--TRIMMABLE-BOUNDARY-START(21475623034),
    {
      "t": 1310721,
      "n": "AcceptLanguage",
      "d": 786554,
      "h": 21475623034,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475623034),
//--TRIMMABLE-BOUNDARY-START(25770590330),
    {
      "t": 1310721,
      "n": "AcceptRanges",
      "d": 786554,
      "h": 25770590330,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770590330),
//--TRIMMABLE-BOUNDARY-START(30065557626),
    {
      "t": 1310721,
      "n": "AccessControlAllowCredentials",
      "d": 786554,
      "h": 30065557626,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065557626),
//--TRIMMABLE-BOUNDARY-START(34360524922),
    {
      "t": 1310721,
      "n": "AccessControlAllowHeaders",
      "d": 786554,
      "h": 34360524922,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360524922),
//--TRIMMABLE-BOUNDARY-START(38655492218),
    {
      "t": 1310721,
      "n": "AccessControlAllowMethods",
      "d": 786554,
      "h": 38655492218,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655492218),
//--TRIMMABLE-BOUNDARY-START(42950459514),
    {
      "t": 1310721,
      "n": "AccessControlAllowOrigin",
      "d": 786554,
      "h": 42950459514,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950459514),
//--TRIMMABLE-BOUNDARY-START(47245426810),
    {
      "t": 1310721,
      "n": "AccessControlExposeHeaders",
      "d": 786554,
      "h": 47245426810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245426810),
//--TRIMMABLE-BOUNDARY-START(51540394106),
    {
      "t": 1310721,
      "n": "AccessControlMaxAge",
      "d": 786554,
      "h": 51540394106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540394106),
//--TRIMMABLE-BOUNDARY-START(55835361402),
    {
      "t": 1310721,
      "n": "AccessControlRequestHeaders",
      "d": 786554,
      "h": 55835361402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835361402),
//--TRIMMABLE-BOUNDARY-START(60130328698),
    {
      "t": 1310721,
      "n": "AccessControlRequestMethod",
      "d": 786554,
      "h": 60130328698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130328698),
//--TRIMMABLE-BOUNDARY-START(64425295994),
    {
      "t": 1310721,
      "n": "Age",
      "d": 786554,
      "h": 64425295994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425295994),
//--TRIMMABLE-BOUNDARY-START(68720263290),
    {
      "t": 1310721,
      "n": "Allow",
      "d": 786554,
      "h": 68720263290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720263290),
//--TRIMMABLE-BOUNDARY-START(73015230586),
    {
      "t": 1310721,
      "n": "AltSvc",
      "d": 786554,
      "h": 73015230586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015230586),
//--TRIMMABLE-BOUNDARY-START(77310197882),
    {
      "t": 1310721,
      "n": "Authority",
      "d": 786554,
      "h": 77310197882,
      "f": 4194337,
      "a": [
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310197882),
//--TRIMMABLE-BOUNDARY-START(81605165178),
    {
      "t": 1310721,
      "n": "Authorization",
      "d": 786554,
      "h": 81605165178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605165178),
//--TRIMMABLE-BOUNDARY-START(85900132474),
    {
      "t": 1310721,
      "n": "Baggage",
      "d": 786554,
      "h": 85900132474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900132474),
//--TRIMMABLE-BOUNDARY-START(90195099770),
    {
      "t": 1310721,
      "n": "CacheControl",
      "d": 786554,
      "h": 90195099770,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195099770),
//--TRIMMABLE-BOUNDARY-START(94490067066),
    {
      "t": 1310721,
      "n": "Connection",
      "d": 786554,
      "h": 94490067066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490067066),
//--TRIMMABLE-BOUNDARY-START(98785034362),
    {
      "t": 1310721,
      "n": "ContentDisposition",
      "d": 786554,
      "h": 98785034362,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785034362),
//--TRIMMABLE-BOUNDARY-START(103080001658),
    {
      "t": 1310721,
      "n": "ContentEncoding",
      "d": 786554,
      "h": 103080001658,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080001658),
//--TRIMMABLE-BOUNDARY-START(107374968954),
    {
      "t": 1310721,
      "n": "ContentLanguage",
      "d": 786554,
      "h": 107374968954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374968954),
//--TRIMMABLE-BOUNDARY-START(111669936250),
    {
      "t": 1310721,
      "n": "ContentLength",
      "d": 786554,
      "h": 111669936250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669936250),
//--TRIMMABLE-BOUNDARY-START(115964903546),
    {
      "t": 1310721,
      "n": "ContentLocation",
      "d": 786554,
      "h": 115964903546,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964903546),
//--TRIMMABLE-BOUNDARY-START(120259870842),
    {
      "t": 1310721,
      "n": "ContentMD5",
      "d": 786554,
      "h": 120259870842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259870842),
//--TRIMMABLE-BOUNDARY-START(124554838138),
    {
      "t": 1310721,
      "n": "ContentRange",
      "d": 786554,
      "h": 124554838138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554838138),
//--TRIMMABLE-BOUNDARY-START(128849805434),
    {
      "t": 1310721,
      "n": "ContentSecurityPolicy",
      "d": 786554,
      "h": 128849805434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849805434),
//--TRIMMABLE-BOUNDARY-START(133144772730),
    {
      "t": 1310721,
      "n": "ContentSecurityPolicyReportOnly",
      "d": 786554,
      "h": 133144772730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144772730),
//--TRIMMABLE-BOUNDARY-START(137439740026),
    {
      "t": 1310721,
      "n": "ContentType",
      "d": 786554,
      "h": 137439740026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439740026),
//--TRIMMABLE-BOUNDARY-START(146029674618),
    {
      "t": 1310721,
      "n": "CorrelationContext",
      "d": 786554,
      "h": 146029674618,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029674618),
//--TRIMMABLE-BOUNDARY-START(141734707322),
    {
      "t": 1310721,
      "n": "Cookie",
      "d": 786554,
      "h": 141734707322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734707322),
//--TRIMMABLE-BOUNDARY-START(150324641914),
    {
      "t": 1310721,
      "n": "Date",
      "d": 786554,
      "h": 150324641914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324641914),
//--TRIMMABLE-BOUNDARY-START(154619609210),
    {
      "t": 1310721,
      "n": "DNT",
      "d": 786554,
      "h": 154619609210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619609210),
//--TRIMMABLE-BOUNDARY-START(158914576506),
    {
      "t": 1310721,
      "n": "ETag",
      "d": 786554,
      "h": 158914576506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914576506),
//--TRIMMABLE-BOUNDARY-START(167504511098),
    {
      "t": 1310721,
      "n": "Expires",
      "d": 786554,
      "h": 167504511098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504511098),
//--TRIMMABLE-BOUNDARY-START(163209543802),
    {
      "t": 1310721,
      "n": "Expect",
      "d": 786554,
      "h": 163209543802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209543802),
//--TRIMMABLE-BOUNDARY-START(171799478394),
    {
      "t": 1310721,
      "n": "From",
      "d": 786554,
      "h": 171799478394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799478394),
//--TRIMMABLE-BOUNDARY-START(176094445690),
    {
      "t": 1310721,
      "n": "GrpcAcceptEncoding",
      "d": 786554,
      "h": 176094445690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094445690),
//--TRIMMABLE-BOUNDARY-START(180389412986),
    {
      "t": 1310721,
      "n": "GrpcEncoding",
      "d": 786554,
      "h": 180389412986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389412986),
//--TRIMMABLE-BOUNDARY-START(184684380282),
    {
      "t": 1310721,
      "n": "GrpcMessage",
      "d": 786554,
      "h": 184684380282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684380282),
//--TRIMMABLE-BOUNDARY-START(188979347578),
    {
      "t": 1310721,
      "n": "GrpcStatus",
      "d": 786554,
      "h": 188979347578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188979347578),
//--TRIMMABLE-BOUNDARY-START(193274314874),
    {
      "t": 1310721,
      "n": "GrpcTimeout",
      "d": 786554,
      "h": 193274314874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193274314874),
//--TRIMMABLE-BOUNDARY-START(197569282170),
    {
      "t": 1310721,
      "n": "Host",
      "d": 786554,
      "h": 197569282170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197569282170),
//--TRIMMABLE-BOUNDARY-START(223339085946),
    {
      "t": 1310721,
      "n": "KeepAlive",
      "d": 786554,
      "h": 223339085946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223339085946),
//--TRIMMABLE-BOUNDARY-START(201864249466),
    {
      "t": 1310721,
      "n": "IfMatch",
      "d": 786554,
      "h": 201864249466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201864249466),
//--TRIMMABLE-BOUNDARY-START(206159216762),
    {
      "t": 1310721,
      "n": "IfModifiedSince",
      "d": 786554,
      "h": 206159216762,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206159216762),
//--TRIMMABLE-BOUNDARY-START(210454184058),
    {
      "t": 1310721,
      "n": "IfNoneMatch",
      "d": 786554,
      "h": 210454184058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210454184058),
//--TRIMMABLE-BOUNDARY-START(214749151354),
    {
      "t": 1310721,
      "n": "IfRange",
      "d": 786554,
      "h": 214749151354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214749151354),
//--TRIMMABLE-BOUNDARY-START(219044118650),
    {
      "t": 1310721,
      "n": "IfUnmodifiedSince",
      "d": 786554,
      "h": 219044118650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219044118650),
//--TRIMMABLE-BOUNDARY-START(227634053242),
    {
      "t": 1310721,
      "n": "LastModified",
      "d": 786554,
      "h": 227634053242,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227634053242),
//--TRIMMABLE-BOUNDARY-START(231929020538),
    {
      "t": 1310721,
      "n": "Link",
      "d": 786554,
      "h": 231929020538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231929020538),
//--TRIMMABLE-BOUNDARY-START(236223987834),
    {
      "t": 1310721,
      "n": "Location",
      "d": 786554,
      "h": 236223987834,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236223987834),
//--TRIMMABLE-BOUNDARY-START(240518955130),
    {
      "t": 1310721,
      "n": "MaxForwards",
      "d": 786554,
      "h": 240518955130,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240518955130),
//--TRIMMABLE-BOUNDARY-START(244813922426),
    {
      "t": 1310721,
      "n": "Method",
      "d": 786554,
      "h": 244813922426,
      "f": 4194337,
      "a": [
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244813922426),
//--TRIMMABLE-BOUNDARY-START(249108889722),
    {
      "t": 1310721,
      "n": "Origin",
      "d": 786554,
      "h": 249108889722,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249108889722),
//--TRIMMABLE-BOUNDARY-START(253403857018),
    {
      "t": 1310721,
      "n": "Path",
      "d": 786554,
      "h": 253403857018,
      "f": 4194337,
      "a": [
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253403857018),
//--TRIMMABLE-BOUNDARY-START(257698824314),
    {
      "t": 1310721,
      "n": "Pragma",
      "d": 786554,
      "h": 257698824314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257698824314),
//--TRIMMABLE-BOUNDARY-START(261993791610),
    {
      "t": 1310721,
      "n": "ProxyAuthenticate",
      "d": 786554,
      "h": 261993791610,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993791610),
//--TRIMMABLE-BOUNDARY-START(266288758906),
    {
      "t": 1310721,
      "n": "ProxyAuthorization",
      "d": 786554,
      "h": 266288758906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288758906),
//--TRIMMABLE-BOUNDARY-START(270583726202),
    {
      "t": 1310721,
      "n": "ProxyConnection",
      "d": 786554,
      "h": 270583726202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270583726202),
//--TRIMMABLE-BOUNDARY-START(279173660794),
    {
      "t": 1310721,
      "n": "Range",
      "d": 786554,
      "h": 279173660794,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173660794),
//--TRIMMABLE-BOUNDARY-START(283468628090),
    {
      "t": 1310721,
      "n": "Referer",
      "d": 786554,
      "h": 283468628090,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283468628090),
//--TRIMMABLE-BOUNDARY-START(292058562682),
    {
      "t": 1310721,
      "n": "RetryAfter",
      "d": 786554,
      "h": 292058562682,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292058562682),
//--TRIMMABLE-BOUNDARY-START(287763595386),
    {
      "t": 1310721,
      "n": "RequestId",
      "d": 786554,
      "h": 287763595386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287763595386),
//--TRIMMABLE-BOUNDARY-START(296353529978),
    {
      "t": 1310721,
      "n": "Scheme",
      "d": 786554,
      "h": 296353529978,
      "f": 4194337,
      "a": [
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(296353529978),
//--TRIMMABLE-BOUNDARY-START(300648497274),
    {
      "t": 1310721,
      "n": "SecWebSocketAccept",
      "d": 786554,
      "h": 300648497274,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(300648497274),
//--TRIMMABLE-BOUNDARY-START(309238431866),
    {
      "t": 1310721,
      "n": "SecWebSocketKey",
      "d": 786554,
      "h": 309238431866,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(309238431866),
//--TRIMMABLE-BOUNDARY-START(313533399162),
    {
      "t": 1310721,
      "n": "SecWebSocketProtocol",
      "d": 786554,
      "h": 313533399162,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313533399162),
//--TRIMMABLE-BOUNDARY-START(317828366458),
    {
      "t": 1310721,
      "n": "SecWebSocketVersion",
      "d": 786554,
      "h": 317828366458,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(317828366458),
//--TRIMMABLE-BOUNDARY-START(304943464570),
    {
      "t": 1310721,
      "n": "SecWebSocketExtensions",
      "d": 786554,
      "h": 304943464570,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304943464570),
//--TRIMMABLE-BOUNDARY-START(322123333754),
    {
      "t": 1310721,
      "n": "Server",
      "d": 786554,
      "h": 322123333754,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322123333754),
//--TRIMMABLE-BOUNDARY-START(326418301050),
    {
      "t": 1310721,
      "n": "SetCookie",
      "d": 786554,
      "h": 326418301050,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(326418301050),
//--TRIMMABLE-BOUNDARY-START(330713268346),
    {
      "t": 1310721,
      "n": "Status",
      "d": 786554,
      "h": 330713268346,
      "f": 4194337,
      "a": [
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330713268346),
//--TRIMMABLE-BOUNDARY-START(335008235642),
    {
      "t": 1310721,
      "n": "StrictTransportSecurity",
      "d": 786554,
      "h": 335008235642,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335008235642),
//--TRIMMABLE-BOUNDARY-START(339303202938),
    {
      "t": 1310721,
      "n": "TE",
      "d": 786554,
      "h": 339303202938,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339303202938),
//--TRIMMABLE-BOUNDARY-START(352188104826),
    {
      "t": 1310721,
      "n": "Trailer",
      "d": 786554,
      "h": 352188104826,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352188104826),
//--TRIMMABLE-BOUNDARY-START(356483072122),
    {
      "t": 1310721,
      "n": "TransferEncoding",
      "d": 786554,
      "h": 356483072122,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(356483072122),
//--TRIMMABLE-BOUNDARY-START(360778039418),
    {
      "t": 1310721,
      "n": "Translate",
      "d": 786554,
      "h": 360778039418,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360778039418),
//--TRIMMABLE-BOUNDARY-START(343598170234),
    {
      "t": 1310721,
      "n": "TraceParent",
      "d": 786554,
      "h": 343598170234,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343598170234),
//--TRIMMABLE-BOUNDARY-START(347893137530),
    {
      "t": 1310721,
      "n": "TraceState",
      "d": 786554,
      "h": 347893137530,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347893137530),
//--TRIMMABLE-BOUNDARY-START(365073006714),
    {
      "t": 1310721,
      "n": "Upgrade",
      "d": 786554,
      "h": 365073006714,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(365073006714),
//--TRIMMABLE-BOUNDARY-START(369367974010),
    {
      "t": 1310721,
      "n": "UpgradeInsecureRequests",
      "d": 786554,
      "h": 369367974010,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369367974010),
//--TRIMMABLE-BOUNDARY-START(373662941306),
    {
      "t": 1310721,
      "n": "UserAgent",
      "d": 786554,
      "h": 373662941306,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(373662941306),
//--TRIMMABLE-BOUNDARY-START(377957908602),
    {
      "t": 1310721,
      "n": "Vary",
      "d": 786554,
      "h": 377957908602,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(377957908602),
//--TRIMMABLE-BOUNDARY-START(382252875898),
    {
      "t": 1310721,
      "n": "Via",
      "d": 786554,
      "h": 382252875898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(382252875898),
//--TRIMMABLE-BOUNDARY-START(386547843194),
    {
      "t": 1310721,
      "n": "Warning",
      "d": 786554,
      "h": 386547843194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(386547843194),
//--TRIMMABLE-BOUNDARY-START(390842810490),
    {
      "t": 1310721,
      "n": "WebSocketSubProtocols",
      "d": 786554,
      "h": 390842810490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(390842810490),
//--TRIMMABLE-BOUNDARY-START(395137777786),
    {
      "t": 1310721,
      "n": "WWWAuthenticate",
      "d": 786554,
      "h": 395137777786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(395137777786),
//--TRIMMABLE-BOUNDARY-START(399432745082),
    {
      "t": 1310721,
      "n": "XContentTypeOptions",
      "d": 786554,
      "h": 399432745082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(399432745082),
//--TRIMMABLE-BOUNDARY-START(403727712378),
    {
      "t": 1310721,
      "n": "XFrameOptions",
      "d": 786554,
      "h": 403727712378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(403727712378),
//--TRIMMABLE-BOUNDARY-START(408022679674),
    {
      "t": 1310721,
      "n": "XPoweredBy",
      "d": 786554,
      "h": 408022679674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(408022679674),
//--TRIMMABLE-BOUNDARY-START(412317646970),
    {
      "t": 1310721,
      "n": "XRequestedWith",
      "d": 786554,
      "h": 412317646970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(412317646970),
//--TRIMMABLE-BOUNDARY-START(416612614266),
    {
      "t": 1310721,
      "n": "XUACompatible",
      "d": 786554,
      "h": 416612614266,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(416612614266),
//--TRIMMABLE-BOUNDARY-START(420907581562),
    {
      "t": 1310721,
      "n": "XXSSProtection",
      "d": 786554,
      "h": 420907581562,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(420907581562)
  ],
  "h": 786554
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.HeaderNames`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}HeaderNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786554)
        
        

        //--TRIMMABLE-BOUNDARY-START(524410)
        $asm.$cls(`$mnhh.MNHH.CookieHeaderValue`, ($self) => class CookieHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(103079739514)
            /*CookieHeaderParser*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(103079739514)
            
            //--TRIMMABLE-BOUNDARY-START(64425033850)
            /*CookieHeaderParser*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(64425033850)
            
            //--TRIMMABLE-BOUNDARY-START(4295491706)
            /*StringSegment*/ _name;
            //--TRIMMABLE-BOUNDARY-END(4295491706)
            
            //--TRIMMABLE-BOUNDARY-START(8590459002)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(8590459002)
            
            //--TRIMMABLE-BOUNDARY-START(17180393594)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393594);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393594)
            
            //--TRIMMABLE-BOUNDARY-START(25770328186)
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.MEP.StringSegment.Empty);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$mep.MEP.StringSegment.op_Equality(name, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770328186)
            
            //--TRIMMABLE-BOUNDARY-START(21475360890)
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$mep.MEP.StringSegment.op_Equality(name, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                    }
                    if ($.$mep.MEP.StringSegment.op_Equality(value, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("value");
                    }
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360890)
            
            //--TRIMMABLE-BOUNDARY-START(68720001146)
            /*StringSegment */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245164666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*StringSegment */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.CookieHeaderValue.CheckNameFormat(value, "value");
                this._name = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68720001146)
            
            //--TRIMMABLE-BOUNDARY-START(124554575994)
            /*StringSegment */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.CookieHeaderValue.CheckValueFormat(value, "value");
                this._value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(124554575994)
            
            //--TRIMMABLE-BOUNDARY-START(107374706810)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374706810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let header = new $.$$.ST.StringBuilder().$ctor$1();
                header.Append$17(this._name.AsSpan());
                header.Append$5(/*=*/ 61);
                header.Append$17(this._value.AsSpan());
                return header.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(107374706810)
            
            //--TRIMMABLE-BOUNDARY-START(73014968442)
            static /*CookieHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.CookieHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(73014968442)
            
            //--TRIMMABLE-BOUNDARY-START(111669674106)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out CookieHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669674106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.CookieHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(111669674106)
            
            //--TRIMMABLE-BOUNDARY-START(77309935738)
            static /*IList<CookieHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.CookieHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(77309935738)
            
            //--TRIMMABLE-BOUNDARY-START(81604903034)
            static /*IList<CookieHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604903034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.CookieHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(81604903034)
            
            //--TRIMMABLE-BOUNDARY-START(115964641402)
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<CookieHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964641402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.CookieHeaderValue.MultipleValueParser.TryParseValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(115964641402)
            
            //--TRIMMABLE-BOUNDARY-START(120259608698)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<CookieHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259608698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.CookieHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(120259608698)
            
            //--TRIMMABLE-BOUNDARY-START(30065295482)
            static /*void */ CheckNameFormat(/*StringSegment*/ name, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.op_Equality(name, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                }
                if ($.$mnhh.MNHH.HttpRuleParser.GetTokenLength(name, 0) !== name.Length)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("Invalid cookie name: " + $.$strNN(name.ToString()), parameterName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065295482)
            
            //--TRIMMABLE-BOUNDARY-START(34360262778)
            static /*void */ CheckValueFormat(/*StringSegment*/ value, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.op_Equality(value, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("value");
                }
                /*var*/ let offset = 0;
                /*var*/ let result = $.$mnhh.MNHH.CookieHeaderParserShared.GetCookieValue(value, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32));
                if (result.Length !== value.Length)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("Invalid cookie value: " + $.$strNN(value.ToString()), parameterName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262778)
            
            //--TRIMMABLE-BOUNDARY-START(38655230074)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655230074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.CookieHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.MEP.StringSegment.Equals$5(this._name, other._name, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.MEP.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(38655230074)
            
            //--TRIMMABLE-BOUNDARY-START(60130066554)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name.GetHashCode() ^ this._value.GetHashCode();
            }
            //--TRIMMABLE-BOUNDARY-END(60130066554)
            
            //--TRIMMABLE-BOUNDARY-START(17180393594)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180393594)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295491706)
                this._name = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(4295491706)
                
                //--TRIMMABLE-BOUNDARY-START(8590459002)
                this._value = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8590459002)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885426298)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(103079739514)
                    this.SingleValueParser = new $.$mnhh.MNHH.CookieHeaderParser().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(103079739514)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425033850)
                    this.MultipleValueParser = new $.$mnhh.MNHH.CookieHeaderParser().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(64425033850)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885426298)
            
            static $h = 524410;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720001146),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245164666,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194837626,
        "f": 83886081
      },
      "n": "Name",
      "d": 524410,
      "h": 68720001146,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720001146),
//--TRIMMABLE-BOUNDARY-START(124554575994),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835099258,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784772218,
        "f": 83886081
      },
      "n": "Value",
      "d": 524410,
      "h": 124554575994,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554575994)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107374706810),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 524410,
      "h": 107374706810,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107374706810),
//--TRIMMABLE-BOUNDARY-START(73014968442),
    {
      "r": 524410,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 524410,
      "h": 73014968442,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014968442),
//--TRIMMABLE-BOUNDARY-START(111669674106),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 524410,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 524410,
      "h": 111669674106,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111669674106),
//--TRIMMABLE-BOUNDARY-START(77309935738),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.CookieHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseList",
      "d": 524410,
      "h": 77309935738,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309935738),
//--TRIMMABLE-BOUNDARY-START(81604903034),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.CookieHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 524410,
      "h": 81604903034,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604903034),
//--TRIMMABLE-BOUNDARY-START(115964641402),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.CookieHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 524410,
      "h": 115964641402,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964641402),
//--TRIMMABLE-BOUNDARY-START(120259608698),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.CookieHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 524410,
      "h": 120259608698,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120259608698),
//--TRIMMABLE-BOUNDARY-START(30065295482),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckNameFormat",
      "d": 524410,
      "h": 30065295482,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065295482),
//--TRIMMABLE-BOUNDARY-START(34360262778),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckValueFormat",
      "d": 524410,
      "h": 34360262778,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360262778),
//--TRIMMABLE-BOUNDARY-START(38655230074),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 524410,
      "h": 38655230074,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655230074),
//--TRIMMABLE-BOUNDARY-START(60130066554),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 524410,
      "h": 60130066554,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130066554)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(103079739514),
    {
      "t": 393338,
      "n": "SingleValueParser",
      "d": 524410,
      "h": 103079739514,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103079739514),
//--TRIMMABLE-BOUNDARY-START(64425033850),
    {
      "t": 393338,
      "n": "MultipleValueParser",
      "d": 524410,
      "h": 64425033850,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425033850),
//--TRIMMABLE-BOUNDARY-START(4295491706),
    {
      "t": 852053,
      "n": "_name",
      "d": 524410,
      "h": 4295491706,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491706),
//--TRIMMABLE-BOUNDARY-START(8590459002),
    {
      "t": 852053,
      "n": "_value",
      "d": 524410,
      "h": 8590459002,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590459002)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180393594),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524410,
      "h": 17180393594,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180393594),
//--TRIMMABLE-BOUNDARY-START(25770328186),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524410,
      "h": 25770328186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328186),
//--TRIMMABLE-BOUNDARY-START(21475360890),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524410,
      "h": 21475360890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360890)
  ],
  "h": 524410
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.CookieHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}CookieHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524410)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114234)
        $asm.$cls(`$mnhh.MNHH.HttpRuleParser`, ($self) => class HttpRuleParser
        {
            //--TRIMMABLE-BOUNDARY-START(73015558266)
            /*SearchValues<char>*/ static TokenChars = null;
            //--TRIMMABLE-BOUNDARY-END(73015558266)
            
            //--TRIMMABLE-BOUNDARY-START(60130656378)
            /*int*/ static MaxNestedCount = 5;
            //--TRIMMABLE-BOUNDARY-END(60130656378)
            
            //--TRIMMABLE-BOUNDARY-START(12886016122)
            /*string[]*/ static DateFormats = null;
            //--TRIMMABLE-BOUNDARY-END(12886016122)
            
            //--TRIMMABLE-BOUNDARY-START(8591048826)
            /*char*/ static CR = /*\r*/ 13;
            //--TRIMMABLE-BOUNDARY-END(8591048826)
            
            //--TRIMMABLE-BOUNDARY-START(47245754490)
            /*char*/ static LF = /*\n*/ 10;
            //--TRIMMABLE-BOUNDARY-END(47245754490)
            
            //--TRIMMABLE-BOUNDARY-START(64425623674)
            /*char*/ static SP = /* */ 32;
            //--TRIMMABLE-BOUNDARY-END(64425623674)
            
            //--TRIMMABLE-BOUNDARY-START(68720590970)
            /*char*/ static Tab = /*\t*/ 9;
            //--TRIMMABLE-BOUNDARY-END(68720590970)
            
            //--TRIMMABLE-BOUNDARY-START(55835689082)
            /*int*/ static MaxInt64Digits = 19;
            //--TRIMMABLE-BOUNDARY-END(55835689082)
            
            //--TRIMMABLE-BOUNDARY-START(51540721786)
            /*int*/ static MaxInt32Digits = 10;
            //--TRIMMABLE-BOUNDARY-END(51540721786)
            
            //--TRIMMABLE-BOUNDARY-START(17180983418)
            /*Encoding*/ static DefaultHttpEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(17180983418)
            
            //--TRIMMABLE-BOUNDARY-START(38655819898)
            static /*int */ GetTokenLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655819898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let subspan = input.AsSpan$2(startIndex);
                /*var*/ let firstNonTokenCharIdx = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, subspan, $.$mnhh.MNHH.HttpRuleParser.TokenChars);
                return (firstNonTokenCharIdx === -1) ? subspan.Length : firstNonTokenCharIdx;
            }
            //--TRIMMABLE-BOUNDARY-END(38655819898)
            
            //--TRIMMABLE-BOUNDARY-START(42950787194)
            static /*int */ GetWhitespaceLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950787194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*char*/ let c;
                while(current < input.Length)
                {
                    c = input.get_Item$1(current);
                    if ((c === /* */ 32) || (c === /*\t*/ 9))
                    {
                        current++;
                        continue;
                    }
                    if (c === /*\r*/ 13)
                    {
                        if ((((current + 2) | 0) < input.Length) && (input.get_Item$1(((current + 1) | 0)) === /*\n*/ 10))
                        {
                            /*var*/ let spaceOrTab = input.get_Item$1(((current + 2) | 0));
                            if ((spaceOrTab === /* */ 32) || (spaceOrTab === /*\t*/ 9))
                            {
                                current += 3;
                                continue;
                            }
                        }
                    }
                    return ((current - startIndex) | 0);
                }
                return ((input.Length - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42950787194)
            
            //--TRIMMABLE-BOUNDARY-START(25770918010)
            static /*int */ GetNumberLength(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ allowDecimal)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770918010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                ;
                /*var*/ let current = startIndex;
                /*char*/ let c;
                /*var*/ let haveDot = !allowDecimal;
                if (input.get_Item$1(current) === /*.*/ 46)
                {
                    return 0;
                }
                while(current < input.Length)
                {
                    c = input.get_Item$1(current);
                    if ((c >= /*0*/ 48) && (c <= /*9*/ 57))
                    {
                        current++;
                    }
                    else if (!haveDot && (c === /*.*/ 46))
                    {
                        haveDot = true;
                        current++;
                    }
                    else 
                    {
                        break;
                    }
                }
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(25770918010)
            
            //--TRIMMABLE-BOUNDARY-START(34360852602)
            static /*HttpParseResult */ GetQuotedStringLength(/*StringSegment*/ input, /*int*/ startIndex, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360852602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nestedCount = 0;
                return $.$mnhh.MNHH.HttpRuleParser.GetExpressionLength(input, startIndex, /*\"*/ 34, /*\"*/ 34, false, $.$ref(() => nestedCount, ($v) => nestedCount = $v, $.$$.S.Int32), length);
            }
            //--TRIMMABLE-BOUNDARY-END(34360852602)
            
            //--TRIMMABLE-BOUNDARY-START(30065885306)
            static /*HttpParseResult */ GetQuotedPairLength(/*StringSegment*/ input, /*int*/ startIndex, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                length.$v = 0;
                if (input.get_Item$1(startIndex) !== /*\\*/ 92)
                {
                    return 1/*HttpParseResult.NotParsed*/;
                }
                if ((((startIndex + 2) | 0) > input.Length) || (input.get_Item$1(((startIndex + 1) | 0)) > 127))
                {
                    return 2/*HttpParseResult.InvalidFormat*/;
                }
                length.$v = 2;
                return 0/*HttpParseResult.Parsed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065885306)
            
            //--TRIMMABLE-BOUNDARY-START(77310525562)
            static /*bool */ TryStringToDate(/*StringSegment*/ input, /*out DateTimeOffset*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310525562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let inputSpan = input.AsSpan();
                /*DateTimeFormatInfo*/ let invariant = $.$$.SG.DateTimeFormatInfo.InvariantInfo;
                return $.$$.S.DateTimeOffset.TryParseExact(inputSpan, $.$$.S.String.op_Implicit("r"), invariant, 0/*DateTimeStyles.None*/, result) || $.$$.S.DateTimeOffset.TryParseExact$1(inputSpan, $.$mnhh.MNHH.HttpRuleParser.DateFormats, invariant, 7/*DateTimeStyles.AllowWhiteSpaces*/ | 64/*DateTimeStyles.AssumeUniversal*/, result);
            }
            //--TRIMMABLE-BOUNDARY-END(77310525562)
            
            //--TRIMMABLE-BOUNDARY-START(21475950714)
            static /*HttpParseResult */ GetExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*char*/ openChar, /*char*/ closeChar, /*bool*/ supportsNesting, /*ref int*/ nestedCount, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                ;
                length.$v = 0;
                if (input.get_Item$1(startIndex) !== openChar)
                {
                    return 1/*HttpParseResult.NotParsed*/;
                }
                /*var*/ let current = ((startIndex + 1) | 0);
                while(current < input.Length)
                {
                    /*var*/ let quotedPairLength;
                    if ((((current + 2) | 0) < input.Length) && ($.$mnhh.MNHH.HttpRuleParser.GetQuotedPairLength(input, current, $.$ref(() => quotedPairLength, ($v) => quotedPairLength = $v, $.$$.S.Int32)) === 0/*HttpParseResult.Parsed*/))
                    {
                        current = ((current + quotedPairLength) | 0);
                        continue;
                    }
                    if (supportsNesting && (input.get_Item$1(current) === openChar))
                    {
                        nestedCount.$v++;
                        try
                        {
                            if (nestedCount.$v > 5/*MaxNestedCount*/)
                            {
                                return 2/*HttpParseResult.InvalidFormat*/;
                            }
                            /*var*/ let nestedLength = 0;
                            /*var*/ let nestedResult = $.$mnhh.MNHH.HttpRuleParser.GetExpressionLength(input, current, openChar, closeChar, supportsNesting, nestedCount, $.$ref(() => nestedLength, ($v) => nestedLength = $v, $.$$.S.Int32));
                            switch(nestedResult)
                            {
                                case 0/*HttpParseResult.Parsed*/:
                                current += nestedLength;
                                break;
                                case 1/*HttpParseResult.NotParsed*/:
                                $.$$.SDC$1.Contract.Assert(false, "'NotParsed' is unexpected: We started nested expression " + "parsing, because we found the open-char. So either it's a valid nested " + "expression or it has invalid format.");
                                break;
                                case 2/*HttpParseResult.InvalidFormat*/:
                                return 2/*HttpParseResult.InvalidFormat*/;
                                default:
                                $.$$.SDC$1.Contract.Assert(false, "Unknown enum result: " + $.$$.S.Enum.ToStringT($.$mnhh.MNHH.HttpParseResult, $.$$.S.UInt32, nestedResult));
                                break;
                            }
                        }
                        finally
                        {
                            {
                                nestedCount.$v--;
                            }
                        }
                    }
                    if (input.get_Item$1(current) === closeChar)
                    {
                        length.$v = ((((current - startIndex) | 0) + 1) | 0);
                        return 0/*HttpParseResult.Parsed*/;
                    }
                    current++;
                }
                return 2/*HttpParseResult.InvalidFormat*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21475950714)
            
            //--TRIMMABLE-BOUNDARY-START(4296081530)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(73015558266)
                    this.TokenChars = $.$$.SB.SearchValues.Create$1($.$$.S.String.op_Implicit("!#$%&'*+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"));
                    //--TRIMMABLE-BOUNDARY-END(73015558266)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886016122)
                    this.DateFormats = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["ddd, d MMM yyyy H:m:s 'GMT'", "ddd, d MMM yyyy H:m:s", "d MMM yyyy H:m:s 'GMT'", "d MMM yyyy H:m:s", "ddd, d MMM yy H:m:s 'GMT'", "ddd, d MMM yy H:m:s", "d MMM yy H:m:s 'GMT'", "d MMM yy H:m:s", "dddd, d'-'MMM'-'yy H:m:s 'GMT'", "dddd, d'-'MMM'-'yy H:m:s", "ddd, d'-'MMM'-'yyyy H:m:s 'GMT'", "ddd MMM d H:m:s yyyy", "ddd, d MMM yyyy H:m:s zzz", "ddd, d MMM yyyy H:m:s", "d MMM yyyy H:m:s zzz", "d MMM yyyy H:m:s"], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12886016122)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180983418)
                    this.DefaultHttpEncoding = $.$$.ST.Encoding.GetEncoding$3("iso-8859-1");
                    //--TRIMMABLE-BOUNDARY-END(17180983418)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296081530)
            
            static $h = 1114234;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655819898),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "GetTokenLength",
      "d": 1114234,
      "h": 38655819898,
      "f": 16777256,
      "a": [
        {
          "t": 70451201,
          "c": 4365418497
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655819898),
//--TRIMMABLE-BOUNDARY-START(42950787194),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "GetWhitespaceLength",
      "d": 1114234,
      "h": 42950787194,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950787194),
//--TRIMMABLE-BOUNDARY-START(25770918010),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "allowDecimal",
          "p": 262145
        }
      ],
      "n": "GetNumberLength",
      "d": 1114234,
      "h": 25770918010,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770918010),
//--TRIMMABLE-BOUNDARY-START(34360852602),
    {
      "r": 1048698,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetQuotedStringLength",
      "d": 1114234,
      "h": 34360852602,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360852602),
//--TRIMMABLE-BOUNDARY-START(30065885306),
    {
      "r": 1048698,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetQuotedPairLength",
      "d": 1114234,
      "h": 30065885306,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065885306),
//--TRIMMABLE-BOUNDARY-START(77310525562),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "result",
          "p": 66191361,
          "f": 2
        }
      ],
      "n": "TryStringToDate",
      "d": 1114234,
      "h": 77310525562,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77310525562),
//--TRIMMABLE-BOUNDARY-START(21475950714),
    {
      "r": 1048698,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "openChar",
          "p": 458753
        },
        {
          "n": "closeChar",
          "p": 458753
        },
        {
          "n": "supportsNesting",
          "p": 262145
        },
        {
          "n": "nestedCount",
          "p": 655361,
          "f": 4
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetExpressionLength",
      "d": 1114234,
      "h": 21475950714,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475950714)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015558266),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "TokenChars",
      "d": 1114234,
      "h": 73015558266,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015558266),
//--TRIMMABLE-BOUNDARY-START(60130656378),
    {
      "t": 655361,
      "n": "MaxNestedCount",
      "d": 1114234,
      "h": 60130656378,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60130656378),
//--TRIMMABLE-BOUNDARY-START(12886016122),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "DateFormats",
      "d": 1114234,
      "h": 12886016122,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886016122),
//--TRIMMABLE-BOUNDARY-START(8591048826),
    {
      "t": 458753,
      "n": "CR",
      "d": 1114234,
      "h": 8591048826,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8591048826),
//--TRIMMABLE-BOUNDARY-START(47245754490),
    {
      "t": 458753,
      "n": "LF",
      "d": 1114234,
      "h": 47245754490,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245754490),
//--TRIMMABLE-BOUNDARY-START(64425623674),
    {
      "t": 458753,
      "n": "SP",
      "d": 1114234,
      "h": 64425623674,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425623674),
//--TRIMMABLE-BOUNDARY-START(68720590970),
    {
      "t": 458753,
      "n": "Tab",
      "d": 1114234,
      "h": 68720590970,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720590970),
//--TRIMMABLE-BOUNDARY-START(55835689082),
    {
      "t": 655361,
      "n": "MaxInt64Digits",
      "d": 1114234,
      "h": 55835689082,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835689082),
//--TRIMMABLE-BOUNDARY-START(51540721786),
    {
      "t": 655361,
      "n": "MaxInt32Digits",
      "d": 1114234,
      "h": 51540721786,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540721786),
//--TRIMMABLE-BOUNDARY-START(17180983418),
    {
      "t": 166723585,
      "n": "DefaultHttpEncoding",
      "d": 1114234,
      "h": 17180983418,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180983418)
  ],
  "h": 1114234
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.HttpRuleParser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}HttpRuleParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114234)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769594)
        $asm.$cls(`$mnhh.MNHH.StringWithQualityHeaderValue`, ($self) => class StringWithQualityHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81606148218)
            /*HttpHeaderParser<StringWithQualityHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(81606148218)
            
            //--TRIMMABLE-BOUNDARY-START(60131311738)
            /*HttpHeaderParser<StringWithQualityHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(60131311738)
            
            //--TRIMMABLE-BOUNDARY-START(8591704186)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(8591704186)
            
            //--TRIMMABLE-BOUNDARY-START(4296736890)
            /*double?*/ _quality = null;
            //--TRIMMABLE-BOUNDARY-END(4296736890)
            
            //--TRIMMABLE-BOUNDARY-START(17181638778)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181638778);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181638778)
            
            //--TRIMMABLE-BOUNDARY-START(25771573370)
            $ctor$3(/*StringSegment*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771573370);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.MNHH.HeaderUtilities.CheckValidToken(value, "value");
                    this._value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771573370)
            
            //--TRIMMABLE-BOUNDARY-START(21476606074)
            $ctor$2(/*StringSegment*/ value, /*double*/ quality)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476606074);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.MNHH.HeaderUtilities.CheckValidToken(value, "value");
                    if ((quality < 0) || (quality > 1))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("quality");
                    }
                    this._value = value;
                    this._quality = quality;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476606074)
            
            //--TRIMMABLE-BOUNDARY-START(107375951994)
            /*StringSegment */ get Value()
            {
                return this._value;
            }
            //--TRIMMABLE-BOUNDARY-END(107375951994)
            
            //--TRIMMABLE-BOUNDARY-START(77311180922)
            /*double? */ get Quality()
            {
                return this._quality;
            }
            //--TRIMMABLE-BOUNDARY-END(77311180922)
            
            //--TRIMMABLE-BOUNDARY-START(85901115514)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901115514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Double).HasValue$get.call(this._quality))
                {
                    return $.$strNN(this._value.ToString()) + "; q=" + $.$strNN($.$$.S.Double.ToString$2.call($.$$.S.Nullable$$($.$$.S.Double).GetValueOrDefault.call(this._quality), "0.0##", $.$$.SG.NumberFormatInfo.InvariantInfo));
                }
                return this._value.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(85901115514)
            
            //--TRIMMABLE-BOUNDARY-START(30066540666)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066540666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.StringWithQualityHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (!$.$mep.MEP.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if ($.$$.S.Nullable$$($.$$.S.Double).HasValue$get.call(this._quality))
                {
                    return $.$$.S.Nullable$$($.$$.S.Double).HasValue$get.call(other._quality) && ($.$$.S.Nullable$$($.$$.S.Double).GetValueOrDefault.call(this._quality) === $.$$.S.Nullable$$($.$$.S.Double).Value$get.call(other._quality));
                }
                return !$.$$.S.Nullable$$($.$$.S.Double).HasValue$get.call(other._quality);
            }
            //--TRIMMABLE-BOUNDARY-END(30066540666)
            
            //--TRIMMABLE-BOUNDARY-START(51541377146)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541377146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value);
                if ($.$$.S.Nullable$$($.$$.S.Double).HasValue$get.call(this._quality))
                {
                    result = result ^ $.$$.S.Double.GetHashCode.call($.$$.S.Nullable$$($.$$.S.Double).GetValueOrDefault.call(this._quality));
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(51541377146)
            
            //--TRIMMABLE-BOUNDARY-START(64426279034)
            static /*StringWithQualityHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426279034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.StringWithQualityHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(64426279034)
            
            //--TRIMMABLE-BOUNDARY-START(90196082810)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out StringWithQualityHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196082810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.StringWithQualityHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(90196082810)
            
            //--TRIMMABLE-BOUNDARY-START(68721246330)
            static /*IList<StringWithQualityHeaderValue> */ ParseList(/*IList<string>?*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721246330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.StringWithQualityHeaderValue.MultipleValueParser.ParseValues$1(input);
            }
            //--TRIMMABLE-BOUNDARY-END(68721246330)
            
            //--TRIMMABLE-BOUNDARY-START(73016213626)
            static /*IList<StringWithQualityHeaderValue> */ ParseStrictList(/*IList<string>?*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016213626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.StringWithQualityHeaderValue.MultipleValueParser.ParseStrictValues(input);
            }
            //--TRIMMABLE-BOUNDARY-END(73016213626)
            
            //--TRIMMABLE-BOUNDARY-START(94491050106)
            static /*bool */ TryParseList(/*IList<string>?*/ input, /*out IList<StringWithQualityHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491050106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.StringWithQualityHeaderValue.MultipleValueParser.TryParseValues(input, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(94491050106)
            
            //--TRIMMABLE-BOUNDARY-START(98786017402)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ input, /*out IList<StringWithQualityHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786017402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.StringWithQualityHeaderValue.MultipleValueParser.TryParseStrictValues(input, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(98786017402)
            
            //--TRIMMABLE-BOUNDARY-START(55836344442)
            static /*int */ GetStringWithQualityLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringWithQualityHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836344442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let valueLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, startIndex);
                if (valueLength === 0)
                {
                    return 0;
                }
                /*StringWithQualityHeaderValue*/ let result = new $.$mnhh.MNHH.StringWithQualityHeaderValue().$ctor$1();
                result._value = input.Subsegment(startIndex, valueLength);
                /*var*/ let current = ((startIndex + valueLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item$1(current) !== /*;*/ 59))
                {
                    parsedValue.$v = result;
                    return ((current - startIndex) | 0);
                }
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (!$.$mnhh.MNHH.StringWithQualityHeaderValue.TryReadQuality(input, result, $.$ref(() => current, ($v) => current = $v, $.$$.S.Int32)))
                {
                    return 0;
                }
                parsedValue.$v = result;
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(55836344442)
            
            //--TRIMMABLE-BOUNDARY-START(103080984698)
            static /*bool */ TryReadQuality(/*StringSegment*/ input, /*StringWithQualityHeaderValue*/ result, /*ref int*/ index)
            {
                /*var*/ let quality;
                /*var*/ let qualityLength;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080984698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let current = index.$v;
                if ((current === input.Length) || ((input.get_Item$1(current) !== /*q*/ 113) && (input.get_Item$1(current) !== /*Q*/ 81)))
                {
                    return false;
                }
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item$1(current) !== /*=*/ 61))
                {
                    return false;
                }
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (current === input.Length)
                {
                    return false;
                }
                if (!$.$mnhh.MNHH.HeaderUtilities.TryParseQualityDouble(input, current, $.$ref(() => quality, ($v) => quality = $v, $.$$.S.Double), $.$ref(() => qualityLength, ($v) => qualityLength = $v, $.$$.S.Int32)))
                {
                    return false;
                }
                result._quality = quality;
                current = ((current + qualityLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                index.$v = current;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(103080984698)
            
            //--TRIMMABLE-BOUNDARY-START(17181638778)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181638778)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591704186)
                this._value = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591704186)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886671482)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886671482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(81606148218)
                    this.SingleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.StringWithQualityHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.StringWithQualityHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.StringWithQualityHeaderValue, $.$mnhh.MNHH.StringWithQualityHeaderValue.GetStringWithQualityLength));
                    //--TRIMMABLE-BOUNDARY-END(81606148218)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60131311738)
                    this.MultipleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.StringWithQualityHeaderValue))().$ctor$3(true, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.StringWithQualityHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.StringWithQualityHeaderValue, $.$mnhh.MNHH.StringWithQualityHeaderValue.GetStringWithQualityLength));
                    //--TRIMMABLE-BOUNDARY-END(60131311738)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886671482)
            
            static $h = 1769594;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375951994),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246409850,
        "f": 50331649
      },
      "n": "Value",
      "d": 1769594,
      "h": 107375951994,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375951994),
//--TRIMMABLE-BOUNDARY-START(77311180922),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656475258,
        "f": 50331649
      },
      "n": "Quality",
      "d": 1769594,
      "h": 77311180922,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311180922)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901115514),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1769594,
      "h": 85901115514,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901115514),
//--TRIMMABLE-BOUNDARY-START(30066540666),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1769594,
      "h": 30066540666,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066540666),
//--TRIMMABLE-BOUNDARY-START(51541377146),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1769594,
      "h": 51541377146,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541377146),
//--TRIMMABLE-BOUNDARY-START(64426279034),
    {
      "r": 1769594,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1769594,
      "h": 64426279034,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426279034),
//--TRIMMABLE-BOUNDARY-START(90196082810),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1769594,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1769594,
      "h": 90196082810,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90196082810),
//--TRIMMABLE-BOUNDARY-START(68721246330),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.StringWithQualityHeaderValue).$h,
      "p": [
        {
          "n": "input",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseList",
      "d": 1769594,
      "h": 68721246330,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68721246330),
//--TRIMMABLE-BOUNDARY-START(73016213626),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.StringWithQualityHeaderValue).$h,
      "p": [
        {
          "n": "input",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 1769594,
      "h": 73016213626,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016213626),
//--TRIMMABLE-BOUNDARY-START(94491050106),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.StringWithQualityHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 1769594,
      "h": 94491050106,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94491050106),
//--TRIMMABLE-BOUNDARY-START(98786017402),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.StringWithQualityHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 1769594,
      "h": 98786017402,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98786017402),
//--TRIMMABLE-BOUNDARY-START(55836344442),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1769594,
          "f": 2
        }
      ],
      "n": "GetStringWithQualityLength",
      "d": 1769594,
      "h": 55836344442,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55836344442),
//--TRIMMABLE-BOUNDARY-START(103080984698),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "result",
          "p": 1769594
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "TryReadQuality",
      "d": 1769594,
      "h": 103080984698,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103080984698)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81606148218),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.StringWithQualityHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 1769594,
      "h": 81606148218,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81606148218),
//--TRIMMABLE-BOUNDARY-START(60131311738),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.StringWithQualityHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 1769594,
      "h": 60131311738,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131311738),
//--TRIMMABLE-BOUNDARY-START(8591704186),
    {
      "t": 852053,
      "n": "_value",
      "d": 1769594,
      "h": 8591704186,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704186),
//--TRIMMABLE-BOUNDARY-START(4296736890),
    {
      "t": $.$typeNullable($.$$.S.Double).$h,
      "n": "_quality",
      "d": 1769594,
      "h": 4296736890,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736890)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181638778),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769594,
      "h": 17181638778,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181638778),
//--TRIMMABLE-BOUNDARY-START(25771573370),
    {
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769594,
      "h": 25771573370,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771573370),
//--TRIMMABLE-BOUNDARY-START(21476606074),
    {
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "quality",
          "p": 1179649
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769594,
      "h": 21476606074,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476606074)
  ],
  "h": 1769594
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.StringWithQualityHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}StringWithQualityHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769594)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572986)
        $asm.$cls(`$mnhh.MNHH.RangeItemHeaderValue`, ($self) => class RangeItemHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296540282)
            /*long?*/ _from = null;
            //--TRIMMABLE-BOUNDARY-END(4296540282)
            
            //--TRIMMABLE-BOUNDARY-START(8591507578)
            /*long?*/ _to = null;
            //--TRIMMABLE-BOUNDARY-END(8591507578)
            
            //--TRIMMABLE-BOUNDARY-START(12886474874)
            $ctor$1(/*long?*/ $from, /*long?*/ to)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886474874);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call($from) && !$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(to))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14("Invalid header range.");
                    }
                    if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call($from) && ($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call($from) < 0n))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(to) && ($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(to) < 0n))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("to");
                    }
                    if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call($from) && $.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(to) && ($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call($from) > $.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(to)))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this._from = $from;
                    this._to = to;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886474874)
            
            //--TRIMMABLE-BOUNDARY-START(21476409466)
            /*long? */ get From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066344058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._from;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409466)
            
            //--TRIMMABLE-BOUNDARY-START(55836147834)
            /*long? */ get To()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656278650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._to;
            }
            //--TRIMMABLE-BOUNDARY-END(55836147834)
            
            //--TRIMMABLE-BOUNDARY-START(60131115130)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131115130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this._from))
                {
                    return "-" + $.$strNN($.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this._to), $.$$.SG.NumberFormatInfo.InvariantInfo));
                }
                else if (!$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this._to))
                {
                    return $.$strNN($.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this._from), $.$$.SG.NumberFormatInfo.InvariantInfo)) + "-";
                }
                return $.$strNN($.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this._from), $.$$.SG.NumberFormatInfo.InvariantInfo)) + "-" + $.$strNN($.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this._to), $.$$.SG.NumberFormatInfo.InvariantInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(60131115130)
            
            //--TRIMMABLE-BOUNDARY-START(17181442170)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$mnhh.MNHH.RangeItemHeaderValue, { set $v($v){ other = $v; } }) && ((this._from === other._from) && (this._to === other._to));
            }
            //--TRIMMABLE-BOUNDARY-END(17181442170)
            
            //--TRIMMABLE-BOUNDARY-START(42951245946)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this._from))
                {
                    return $.$$.S.Int64.GetHashCode.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this._to));
                }
                else if (!$.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this._to))
                {
                    return $.$$.S.Int64.GetHashCode.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this._from));
                }
                return $.$$.S.Int64.GetHashCode.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this._from)) ^ $.$$.S.Int64.GetHashCode.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this._to));
            }
            //--TRIMMABLE-BOUNDARY-END(42951245946)
            
            //--TRIMMABLE-BOUNDARY-START(51541180538)
            static /*int */ GetRangeItemListLength(/*StringSegment*/ input, /*int*/ startIndex, /*ICollection<RangeItemHeaderValue>*/ rangeCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541180538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                ;
                if (($.$mep.MEP.StringSegment.IsNullOrEmpty(input)) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = $.$mnhh.MNHH.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(input, startIndex, true, $.$discardRef());
                if (current === input.Length)
                {
                    return 0;
                }
                while(true)
                {
                    /*var*/ let range;
                    /*var*/ let separatorFound;
                    /*var*/ let rangeLength = $.$mnhh.MNHH.RangeItemHeaderValue.GetRangeItemLength(input, current, $.$ref(() => range, ($v) => range = $v, $.$mnhh.MNHH.RangeItemHeaderValue));
                    if (rangeLength === 0)
                    {
                        return 0;
                    }
                    rangeCollection.SCG$ICollection$$$Add(range);
                    current = ((current + rangeLength) | 0);
                    current = $.$mnhh.MNHH.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(input, current, true, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.S.Boolean));
                    if ((current < input.Length) && !separatorFound)
                    {
                        return 0;
                    }
                    if (current === input.Length)
                    {
                        return ((current - startIndex) | 0);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541180538)
            
            //--TRIMMABLE-BOUNDARY-START(47246213242)
            static /*int */ GetRangeItemLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeItemHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*var*/ let fromStartIndex = current;
                /*var*/ let fromLength = $.$mnhh.MNHH.HttpRuleParser.GetNumberLength(input, current, false);
                if (fromLength > 19/*HttpRuleParser.MaxInt64Digits*/)
                {
                    return 0;
                }
                current = ((current + fromLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item$1(current) !== /*-*/ 45))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let toStartIndex = current;
                /*var*/ let toLength = 0;
                if (current < input.Length)
                {
                    toLength = $.$mnhh.MNHH.HttpRuleParser.GetNumberLength(input, current, false);
                    if (toLength > 19/*HttpRuleParser.MaxInt64Digits*/)
                    {
                        return 0;
                    }
                    current = ((current + toLength) | 0);
                    current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                }
                if ((fromLength === 0) && (toLength === 0))
                {
                    return 0;
                }
                /*long*/ let $from = 0n;
                if ((fromLength > 0) && !$.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(fromStartIndex, fromLength), $.$ref(() => $from, ($v) => $from = $v, $.$$.S.Int64)))
                {
                    return 0;
                }
                /*long*/ let to = 0n;
                if ((toLength > 0) && !$.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(toStartIndex, toLength), $.$ref(() => to, ($v) => to = $v, $.$$.S.Int64)))
                {
                    return 0;
                }
                if ((fromLength > 0) && (toLength > 0) && ($from > to))
                {
                    return 0;
                }
                parsedValue.$v = new $.$mnhh.MNHH.RangeItemHeaderValue().$ctor$1((fromLength === 0 ? null : $.$cast($from, $.$$.S.Nullable$$($.$$.S.Int64))), (toLength === 0 ? null : $.$cast(to, $.$$.S.Nullable$$($.$$.S.Int64))));
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(47246213242)
            
            static $h = 1572986;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476409466),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066344058,
        "f": 50331649
      },
      "n": "From",
      "d": 1572986,
      "h": 21476409466,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476409466),
//--TRIMMABLE-BOUNDARY-START(55836147834),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656278650,
        "f": 50331649
      },
      "n": "To",
      "d": 1572986,
      "h": 55836147834,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836147834)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131115130),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1572986,
      "h": 60131115130,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131115130),
//--TRIMMABLE-BOUNDARY-START(17181442170),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1572986,
      "h": 17181442170,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181442170),
//--TRIMMABLE-BOUNDARY-START(42951245946),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1572986,
      "h": 42951245946,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951245946),
//--TRIMMABLE-BOUNDARY-START(51541180538),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "rangeCollection",
          "p": $.$$.SCG.ICollection$$($.$mnhh.MNHH.RangeItemHeaderValue).$h
        }
      ],
      "n": "GetRangeItemListLength",
      "d": 1572986,
      "h": 51541180538,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51541180538),
//--TRIMMABLE-BOUNDARY-START(47246213242),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1572986,
          "f": 2
        }
      ],
      "n": "GetRangeItemLength",
      "d": 1572986,
      "h": 47246213242,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246213242)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296540282),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_from",
      "d": 1572986,
      "h": 4296540282,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540282),
//--TRIMMABLE-BOUNDARY-START(8591507578),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_to",
      "d": 1572986,
      "h": 8591507578,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507578)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886474874),
    {
      "p": [
        {
          "n": "from",
          "p": $.$typeNullable($.$$.S.Int64).$h
        },
        {
          "n": "to",
          "p": $.$typeNullable($.$$.S.Int64).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572986,
      "h": 12886474874,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886474874)
  ],
  "h": 1572986
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.RangeItemHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}RangeItemHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572986)
        
        

        //--TRIMMABLE-BOUNDARY-START(327802)
        $asm.$cls(`$mnhh.MNHH.ContentRangeHeaderValue`, ($self) => class ContentRangeHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(128849346682)
            /*HttpHeaderParser<ContentRangeHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(128849346682)
            
            //--TRIMMABLE-BOUNDARY-START(4295295098)
            /*StringSegment*/ _unit;
            //--TRIMMABLE-BOUNDARY-END(4295295098)
            
            //--TRIMMABLE-BOUNDARY-START(25770131578)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131578)
            
            //--TRIMMABLE-BOUNDARY-START(30065098874)
            $ctor$2(/*long*/ $from, /*long*/ to, /*long*/ length)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098874);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int64, length, "length");
                    if ((to < 0n) || (length <= to))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("to");
                    }
                    if (($from < 0n) || ($from > to))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this.From = $from;
                    this.To = to;
                    this.Length = length;
                    this._unit = $.$mep.MEP.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065098874)
            
            //--TRIMMABLE-BOUNDARY-START(38655033466)
            $ctor$4(/*long*/ length)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655033466);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int64, length, "length");
                    this.Length = length;
                    this._unit = $.$mep.MEP.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655033466)
            
            //--TRIMMABLE-BOUNDARY-START(34360066170)
            $ctor$3(/*long*/ $from, /*long*/ to)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360066170);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int64, to, "to");
                    if (($from < 0n) || ($from > to))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this.From = $from;
                    this.To = to;
                    this._unit = $.$mep.MEP.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360066170)
            
            //--TRIMMABLE-BOUNDARY-START(193273856122)
            /*StringSegment */ get Unit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._unit;
            }
            /*StringSegment */ set Unit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209085050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.CheckValidToken(value, "value");
                this._unit = value;
            }
            //--TRIMMABLE-BOUNDARY-END(193273856122)
            
            //--TRIMMABLE-BOUNDARY-START(47244968058)
            /*long?*/ From = null;
            //--TRIMMABLE-BOUNDARY-END(47244968058)
            
            //--TRIMMABLE-BOUNDARY-START(167504052346)
            /*long?*/ To = null;
            //--TRIMMABLE-BOUNDARY-END(167504052346)
            
            //--TRIMMABLE-BOUNDARY-START(120259412090)
            /*long?*/ Length = null;
            //--TRIMMABLE-BOUNDARY-END(120259412090)
            
            //--TRIMMABLE-BOUNDARY-START(111669477498)
            /*bool */ get HasLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(111669477498)
            
            //--TRIMMABLE-BOUNDARY-START(115964444794)
            /*bool */ get HasRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.From !== null && this.To !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(115964444794)
            
            //--TRIMMABLE-BOUNDARY-START(42950000762)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.ContentRangeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return ((this.From === other.From) && (this.To === other.To) && (this.Length === other.Length) && $.$mep.MEP.StringSegment.Equals$5(this.Unit, other.Unit, 5/*StringComparison.OrdinalIgnoreCase*/));
            }
            //--TRIMMABLE-BOUNDARY-END(42950000762)
            
            //--TRIMMABLE-BOUNDARY-START(107374510202)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Unit);
                if (this.HasRange)
                {
                    result = result ^ $.$$.S.Nullable$$($.$$.S.Int64).GetHashCode.call(this.From) ^ $.$$.S.Nullable$$($.$$.S.Int64).GetHashCode.call(this.To);
                }
                if (this.HasLength)
                {
                    result = result ^ $.$$.S.Nullable$$($.$$.S.Int64).GetHashCode.call(this.Length);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(107374510202)
            
            //--TRIMMABLE-BOUNDARY-START(171799019642)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                sb.Append$17(this.Unit.AsSpan());
                sb.Append$5(/* */ 32);
                if (this.HasRange)
                {
                    sb.Append$21($.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this.From), $.$$.SG.NumberFormatInfo.InvariantInfo));
                    sb.Append$5(/*-*/ 45);
                    sb.Append$21($.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this.To), $.$$.SG.NumberFormatInfo.InvariantInfo));
                }
                else 
                {
                    sb.Append$5(/***/ 42);
                }
                sb.Append$5(/*/*/ 47);
                if (this.HasLength)
                {
                    sb.Append$21($.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this.Length), $.$$.SG.NumberFormatInfo.InvariantInfo));
                }
                else 
                {
                    sb.Append$5(/***/ 42);
                }
                return sb.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(171799019642)
            
            //--TRIMMABLE-BOUNDARY-START(124554379386)
            static /*ContentRangeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.ContentRangeHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(124554379386)
            
            //--TRIMMABLE-BOUNDARY-START(188978888826)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978888826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.ContentRangeHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(188978888826)
            
            //--TRIMMABLE-BOUNDARY-START(103079542906)
            static /*int */ GetContentRangeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                /*var*/ let fromLength;
                /*var*/ let toStartIndex;
                /*var*/ let toLength;
                /*var*/ let lengthLength;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let unitLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, startIndex);
                if (unitLength === 0)
                {
                    return 0;
                }
                /*var*/ let unit = input.Subsegment(startIndex, unitLength);
                /*var*/ let current = ((startIndex + unitLength) | 0);
                /*var*/ let separatorLength = $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current);
                if (separatorLength === 0)
                {
                    return 0;
                }
                current = ((current + separatorLength) | 0);
                if (current === input.Length)
                {
                    return 0;
                }
                /*var*/ let fromStartIndex = current;
                if (!$.$mnhh.MNHH.ContentRangeHeaderValue.TryGetRangeLength(input, $.$ref(() => current, ($v) => current = $v, $.$$.S.Int32), $.$ref(() => fromLength, ($v) => fromLength = $v, $.$$.S.Int32), $.$ref(() => toStartIndex, ($v) => toStartIndex = $v, $.$$.S.Int32), $.$ref(() => toLength, ($v) => toLength = $v, $.$$.S.Int32)))
                {
                    return 0;
                }
                if ((current === input.Length) || (input.get_Item$1(current) !== /*/*/ 47))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (current === input.Length)
                {
                    return 0;
                }
                /*var*/ let lengthStartIndex = current;
                if (!$.$mnhh.MNHH.ContentRangeHeaderValue.TryGetLengthLength(input, $.$ref(() => current, ($v) => current = $v, $.$$.S.Int32), $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.S.Int32)))
                {
                    return 0;
                }
                if (!$.$mnhh.MNHH.ContentRangeHeaderValue.TryCreateContentRange(input, unit, fromStartIndex, fromLength, toStartIndex, toLength, lengthStartIndex, lengthLength, parsedValue))
                {
                    return 0;
                }
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(103079542906)
            
            //--TRIMMABLE-BOUNDARY-START(180388954234)
            static /*bool */ TryGetLengthLength(/*StringSegment*/ input, /*ref int*/ current, /*out int*/ lengthLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388954234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                lengthLength.$v = 0;
                if (input.get_Item$1(current.$v) === /***/ 42)
                {
                    current.$v++;
                }
                else 
                {
                    lengthLength.$v = $.$mnhh.MNHH.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((lengthLength.$v === 0) || (lengthLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + lengthLength.$v) | 0);
                }
                current.$v = ((current.$v + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(180388954234)
            
            //--TRIMMABLE-BOUNDARY-START(184683921530)
            static /*bool */ TryGetRangeLength(/*StringSegment*/ input, /*ref int*/ current, /*out int*/ fromLength, /*out int*/ toStartIndex, /*out int*/ toLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683921530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                fromLength.$v = 0;
                toStartIndex.$v = 0;
                toLength.$v = 0;
                if (input.get_Item$1(current.$v) === /***/ 42)
                {
                    current.$v++;
                }
                else 
                {
                    fromLength.$v = $.$mnhh.MNHH.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((fromLength.$v === 0) || (fromLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + fromLength.$v) | 0);
                    current.$v = ((current.$v + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                    if ((current.$v === input.Length) || (input.get_Item$1(current.$v) !== /*-*/ 45))
                    {
                        return false;
                    }
                    current.$v++;
                    current.$v = ((current.$v + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                    if (current.$v === input.Length)
                    {
                        return false;
                    }
                    toStartIndex.$v = current.$v;
                    toLength.$v = $.$mnhh.MNHH.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((toLength.$v === 0) || (toLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + toLength.$v) | 0);
                }
                current.$v = ((current.$v + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(184683921530)
            
            //--TRIMMABLE-BOUNDARY-START(176093986938)
            static /*bool */ TryCreateContentRange(/*StringSegment*/ input, /*StringSegment*/ unit, /*int*/ fromStartIndex, /*int*/ fromLength, /*int*/ toStartIndex, /*int*/ toLength, /*int*/ lengthStartIndex, /*int*/ lengthLength, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093986938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parsedValue.$v = null;
                /*long*/ let $from = 0n;
                if ((fromLength > 0) && !$.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(fromStartIndex, fromLength), $.$ref(() => $from, ($v) => $from = $v, $.$$.S.Int64)))
                {
                    return false;
                }
                /*long*/ let to = 0n;
                if ((toLength > 0) && !$.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(toStartIndex, toLength), $.$ref(() => to, ($v) => to = $v, $.$$.S.Int64)))
                {
                    return false;
                }
                if ((fromLength > 0) && (toLength > 0) && ($from > to))
                {
                    return false;
                }
                /*long*/ let length = 0n;
                if ((lengthLength > 0) && !$.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(lengthStartIndex, lengthLength), $.$ref(() => length, ($v) => length = $v, $.$$.S.Int64)))
                {
                    return false;
                }
                if ((toLength > 0) && (lengthLength > 0) && (to >= length))
                {
                    return false;
                }
                /*var*/ let result = new $.$mnhh.MNHH.ContentRangeHeaderValue().$ctor$1();
                result._unit = unit;
                if (fromLength > 0)
                {
                    result.From = $from;
                    result.To = to;
                }
                if (lengthLength > 0)
                {
                    result.Length = length;
                }
                parsedValue.$v = result;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(176093986938)
            
            //--TRIMMABLE-BOUNDARY-START(25770131578)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770131578)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295295098)
                this._unit = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(4295295098)
                
            }
            //--TRIMMABLE-BOUNDARY-START(21475164282)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(128849346682)
                    this.Parser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.ContentRangeHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.ContentRangeHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.ContentRangeHeaderValue, $.$mnhh.MNHH.ContentRangeHeaderValue.GetContentRangeLength));
                    //--TRIMMABLE-BOUNDARY-END(128849346682)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475164282)
            
            static $h = 327802;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(193273856122),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784575610,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209085050,
        "f": 83886081
      },
      "n": "Unit",
      "d": 327802,
      "h": 193273856122,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193273856122),
//--TRIMMABLE-BOUNDARY-START(47244968058),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902650,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439281274,
        "f": 83886082
      },
      "n": "From",
      "d": 327802,
      "h": 47244968058,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244968058),
//--TRIMMABLE-BOUNDARY-START(167504052346),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194641018,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619150458,
        "f": 83886082
      },
      "n": "To",
      "d": 327802,
      "h": 167504052346,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504052346),
//--TRIMMABLE-BOUNDARY-START(120259412090),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604706426,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029215866,
        "f": 83886082
      },
      "n": "Length",
      "d": 327802,
      "h": 120259412090,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259412090),
//--TRIMMABLE-BOUNDARY-START(111669477498),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837242,
        "f": 50331649
      },
      "n": "HasLength",
      "d": 327802,
      "h": 111669477498,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669477498),
//--TRIMMABLE-BOUNDARY-START(115964444794),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014771834,
        "f": 50331649
      },
      "n": "HasRange",
      "d": 327802,
      "h": 115964444794,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964444794)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950000762),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 327802,
      "h": 42950000762,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950000762),
//--TRIMMABLE-BOUNDARY-START(107374510202),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 327802,
      "h": 107374510202,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107374510202),
//--TRIMMABLE-BOUNDARY-START(171799019642),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 327802,
      "h": 171799019642,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171799019642),
//--TRIMMABLE-BOUNDARY-START(124554379386),
    {
      "r": 327802,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 327802,
      "h": 124554379386,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124554379386),
//--TRIMMABLE-BOUNDARY-START(188978888826),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 327802,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 327802,
      "h": 188978888826,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188978888826),
//--TRIMMABLE-BOUNDARY-START(103079542906),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 327802,
          "f": 2
        }
      ],
      "n": "GetContentRangeLength",
      "d": 327802,
      "h": 103079542906,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079542906),
//--TRIMMABLE-BOUNDARY-START(180388954234),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "current",
          "p": 655361,
          "f": 4
        },
        {
          "n": "lengthLength",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetLengthLength",
      "d": 327802,
      "h": 180388954234,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(180388954234),
//--TRIMMABLE-BOUNDARY-START(184683921530),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "current",
          "p": 655361,
          "f": 4
        },
        {
          "n": "fromLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "toStartIndex",
          "p": 655361,
          "f": 2
        },
        {
          "n": "toLength",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetRangeLength",
      "d": 327802,
      "h": 184683921530,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(184683921530),
//--TRIMMABLE-BOUNDARY-START(176093986938),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "unit",
          "p": 852053
        },
        {
          "n": "fromStartIndex",
          "p": 655361
        },
        {
          "n": "fromLength",
          "p": 655361
        },
        {
          "n": "toStartIndex",
          "p": 655361
        },
        {
          "n": "toLength",
          "p": 655361
        },
        {
          "n": "lengthStartIndex",
          "p": 655361
        },
        {
          "n": "lengthLength",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 327802,
          "f": 2
        }
      ],
      "n": "TryCreateContentRange",
      "d": 327802,
      "h": 176093986938,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176093986938)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128849346682),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.ContentRangeHeaderValue).$h,
      "n": "Parser",
      "d": 327802,
      "h": 128849346682,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128849346682),
//--TRIMMABLE-BOUNDARY-START(4295295098),
    {
      "t": 852053,
      "n": "_unit",
      "d": 327802,
      "h": 4295295098,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295098)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770131578),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327802,
      "h": 25770131578,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770131578),
//--TRIMMABLE-BOUNDARY-START(30065098874),
    {
      "p": [
        {
          "n": "from",
          "p": 917505
        },
        {
          "n": "to",
          "p": 917505
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327802,
      "h": 30065098874,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098874),
//--TRIMMABLE-BOUNDARY-START(38655033466),
    {
      "p": [
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 327802,
      "h": 38655033466,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033466),
//--TRIMMABLE-BOUNDARY-START(34360066170),
    {
      "p": [
        {
          "n": "from",
          "p": 917505
        },
        {
          "n": "to",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327802,
      "h": 34360066170,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066170)
  ],
  "h": 327802
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.ContentRangeHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}ContentRangeHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327802)
        
        

        //--TRIMMABLE-BOUNDARY-START(131194)
        $asm.$cls(`$mnhh.MNHH.CacheControlHeaderValue`, ($self) => class CacheControlHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(369367318650)
            /*string*/ static PublicString = null;
            //--TRIMMABLE-BOUNDARY-END(369367318650)
            
            //--TRIMMABLE-BOUNDARY-START(352187449466)
            /*string*/ static PrivateString = null;
            //--TRIMMABLE-BOUNDARY-END(352187449466)
            
            //--TRIMMABLE-BOUNDARY-START(261993136250)
            /*string*/ static MaxAgeString = null;
            //--TRIMMABLE-BOUNDARY-END(261993136250)
            
            //--TRIMMABLE-BOUNDARY-START(489626402938)
            /*string*/ static SharedMaxAgeString = null;
            //--TRIMMABLE-BOUNDARY-END(489626402938)
            
            //--TRIMMABLE-BOUNDARY-START(304942809210)
            /*string*/ static NoCacheString = null;
            //--TRIMMABLE-BOUNDARY-END(304942809210)
            
            //--TRIMMABLE-BOUNDARY-START(313532743802)
            /*string*/ static NoStoreString = null;
            //--TRIMMABLE-BOUNDARY-END(313532743802)
            
            //--TRIMMABLE-BOUNDARY-START(274878038138)
            /*string*/ static MaxStaleString = null;
            //--TRIMMABLE-BOUNDARY-END(274878038138)
            
            //--TRIMMABLE-BOUNDARY-START(283467972730)
            /*string*/ static MinFreshString = null;
            //--TRIMMABLE-BOUNDARY-END(283467972730)
            
            //--TRIMMABLE-BOUNDARY-START(322122678394)
            /*string*/ static NoTransformString = null;
            //--TRIMMABLE-BOUNDARY-END(322122678394)
            
            //--TRIMMABLE-BOUNDARY-START(330712612986)
            /*string*/ static OnlyIfCachedString = null;
            //--TRIMMABLE-BOUNDARY-END(330712612986)
            
            //--TRIMMABLE-BOUNDARY-START(292057907322)
            /*string*/ static MustRevalidateString = null;
            //--TRIMMABLE-BOUNDARY-END(292057907322)
            
            //--TRIMMABLE-BOUNDARY-START(360777384058)
            /*string*/ static ProxyRevalidateString = null;
            //--TRIMMABLE-BOUNDARY-END(360777384058)
            
            //--TRIMMABLE-BOUNDARY-START(339302547578)
            /*HttpHeaderParser<CacheControlHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(339302547578)
            
            //--TRIMMABLE-BOUNDARY-START(98784379002)
            /*Action<StringSegment>*/ static CheckIsValidTokenAction = null;
            //--TRIMMABLE-BOUNDARY-END(98784379002)
            
            //--TRIMMABLE-BOUNDARY-START(30064902266)
            /*bool*/ _noCache = false;
            //--TRIMMABLE-BOUNDARY-END(30064902266)
            
            //--TRIMMABLE-BOUNDARY-START(34359869562)
            /*ICollection<StringSegment>?*/ _noCacheHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(34359869562)
            
            //--TRIMMABLE-BOUNDARY-START(38654836858)
            /*bool*/ _noStore = false;
            //--TRIMMABLE-BOUNDARY-END(38654836858)
            
            //--TRIMMABLE-BOUNDARY-START(8590065786)
            /*TimeSpan?*/ _maxAge = null;
            //--TRIMMABLE-BOUNDARY-END(8590065786)
            
            //--TRIMMABLE-BOUNDARY-START(68719607930)
            /*TimeSpan?*/ _sharedMaxAge = null;
            //--TRIMMABLE-BOUNDARY-END(68719607930)
            
            //--TRIMMABLE-BOUNDARY-START(12885033082)
            /*bool*/ _maxStale = false;
            //--TRIMMABLE-BOUNDARY-END(12885033082)
            
            //--TRIMMABLE-BOUNDARY-START(17180000378)
            /*TimeSpan?*/ _maxStaleLimit = null;
            //--TRIMMABLE-BOUNDARY-END(17180000378)
            
            //--TRIMMABLE-BOUNDARY-START(21474967674)
            /*TimeSpan?*/ _minFresh = null;
            //--TRIMMABLE-BOUNDARY-END(21474967674)
            
            //--TRIMMABLE-BOUNDARY-START(42949804154)
            /*bool*/ _noTransform = false;
            //--TRIMMABLE-BOUNDARY-END(42949804154)
            
            //--TRIMMABLE-BOUNDARY-START(47244771450)
            /*bool*/ _onlyIfCached = false;
            //--TRIMMABLE-BOUNDARY-END(47244771450)
            
            //--TRIMMABLE-BOUNDARY-START(64424640634)
            /*bool*/ _public = false;
            //--TRIMMABLE-BOUNDARY-END(64424640634)
            
            //--TRIMMABLE-BOUNDARY-START(51539738746)
            /*bool*/ _private = false;
            //--TRIMMABLE-BOUNDARY-END(51539738746)
            
            //--TRIMMABLE-BOUNDARY-START(55834706042)
            /*ICollection<StringSegment>?*/ _privateHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(55834706042)
            
            //--TRIMMABLE-BOUNDARY-START(25769934970)
            /*bool*/ _mustRevalidate = false;
            //--TRIMMABLE-BOUNDARY-END(25769934970)
            
            //--TRIMMABLE-BOUNDARY-START(60129673338)
            /*bool*/ _proxyRevalidate = false;
            //--TRIMMABLE-BOUNDARY-END(60129673338)
            
            //--TRIMMABLE-BOUNDARY-START(4295098490)
            /*IList<NameValueHeaderValue>?*/ _extensions = null;
            //--TRIMMABLE-BOUNDARY-END(4295098490)
            
            //--TRIMMABLE-BOUNDARY-START(77309542522)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309542522);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309542522)
            
            //--TRIMMABLE-BOUNDARY-START(296352874618)
            /*bool */ get NoCache()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503855738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._noCache;
            }
            /*bool */ set NoCache(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420906926202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._noCache = value;
            }
            //--TRIMMABLE-BOUNDARY-END(296352874618)
            
            //--TRIMMABLE-BOUNDARY-START(300647841914)
            /*ICollection<StringSegment> */ get NoCacheHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093790330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._noCacheHeaders === null)
                {
                    this._noCacheHeaders = new ($.$mnhh.MNHH.ObjectCollection$$($.$mep.MEP.StringSegment))().$ctor$4($.$mnhh.MNHH.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                }
                return this._noCacheHeaders;
            }
            //--TRIMMABLE-BOUNDARY-END(300647841914)
            
            //--TRIMMABLE-BOUNDARY-START(309237776506)
            /*bool */ get NoStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683724922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._noStore;
            }
            /*bool */ set NoStore(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429496860794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._noStore = value;
            }
            //--TRIMMABLE-BOUNDARY-END(309237776506)
            
            //--TRIMMABLE-BOUNDARY-START(257698168954)
            /*TimeSpan? */ get MaxAge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554182778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$clone(this._maxAge);
            }
            /*TimeSpan? */ set MaxAge(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957253242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._maxAge = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(257698168954)
            
            //--TRIMMABLE-BOUNDARY-START(485331435642)
            /*TimeSpan? */ get SharedMaxAge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813267066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$clone(this._sharedMaxAge);
            }
            /*TimeSpan? */ set SharedMaxAge(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036468346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._sharedMaxAge = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(485331435642)
            
            //--TRIMMABLE-BOUNDARY-START(266288103546)
            /*bool */ get MaxStale()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144117370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._maxStale;
            }
            /*bool */ set MaxStale(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547187834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._maxStale = value;
            }
            //--TRIMMABLE-BOUNDARY-END(266288103546)
            
            //--TRIMMABLE-BOUNDARY-START(270583070842)
            /*TimeSpan? */ get MaxStaleLimit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734051962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$clone(this._maxStaleLimit);
            }
            /*TimeSpan? */ set MaxStaleLimit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137122426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._maxStaleLimit = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(270583070842)
            
            //--TRIMMABLE-BOUNDARY-START(279173005434)
            /*TimeSpan? */ get MinFresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323986554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$clone(this._minFresh);
            }
            /*TimeSpan? */ set MinFresh(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727057018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._minFresh = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(279173005434)
            
            //--TRIMMABLE-BOUNDARY-START(317827711098)
            /*bool */ get NoTransform()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273659514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._noTransform;
            }
            /*bool */ set NoTransform(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438086795386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._noTransform = value;
            }
            //--TRIMMABLE-BOUNDARY-END(317827711098)
            
            //--TRIMMABLE-BOUNDARY-START(326417645690)
            /*bool */ get OnlyIfCached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863594106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._onlyIfCached;
            }
            /*bool */ set OnlyIfCached(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446676729978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._onlyIfCached = value;
            }
            //--TRIMMABLE-BOUNDARY-END(326417645690)
            
            //--TRIMMABLE-BOUNDARY-START(365072351354)
            /*bool */ get Public()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223332474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._public;
            }
            /*bool */ set Public(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472446533754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._public = value;
            }
            //--TRIMMABLE-BOUNDARY-END(365072351354)
            
            //--TRIMMABLE-BOUNDARY-START(343597514874)
            /*bool */ get Private()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453528698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._private;
            }
            /*bool */ set Private(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455266664570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._private = value;
            }
            //--TRIMMABLE-BOUNDARY-END(343597514874)
            
            //--TRIMMABLE-BOUNDARY-START(347892482170)
            /*ICollection<StringSegment> */ get PrivateHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043463290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._privateHeaders === null)
                {
                    this._privateHeaders = new ($.$mnhh.MNHH.ObjectCollection$$($.$mep.MEP.StringSegment))().$ctor$4($.$mnhh.MNHH.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                }
                return this._privateHeaders;
            }
            //--TRIMMABLE-BOUNDARY-END(347892482170)
            
            //--TRIMMABLE-BOUNDARY-START(287762940026)
            /*bool */ get MustRevalidate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913921146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mustRevalidate;
            }
            /*bool */ set MustRevalidate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412316991610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._mustRevalidate = value;
            }
            //--TRIMMABLE-BOUNDARY-END(287762940026)
            
            //--TRIMMABLE-BOUNDARY-START(356482416762)
            /*bool */ get ProxyRevalidate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633397882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._proxyRevalidate;
            }
            /*bool */ set ProxyRevalidate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463856599162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._proxyRevalidate = value;
            }
            //--TRIMMABLE-BOUNDARY-END(356482416762)
            
            //--TRIMMABLE-BOUNDARY-START(107374313594)
            /*IList<NameValueHeaderValue> */ get Extensions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964248186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._extensions === null)
                {
                    this._extensions = new ($.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.NameValueHeaderValue))().$ctor$3();
                }
                return this._extensions;
            }
            //--TRIMMABLE-BOUNDARY-END(107374313594)
            
            //--TRIMMABLE-BOUNDARY-START(493921370234)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493921370234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueIfRequired(sb, this._noStore, $.$mnhh.MNHH.CacheControlHeaderValue.NoStoreString);
                $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueIfRequired(sb, this._noTransform, $.$mnhh.MNHH.CacheControlHeaderValue.NoTransformString);
                $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueIfRequired(sb, this._onlyIfCached, $.$mnhh.MNHH.CacheControlHeaderValue.OnlyIfCachedString);
                $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueIfRequired(sb, this._public, $.$mnhh.MNHH.CacheControlHeaderValue.PublicString);
                $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueIfRequired(sb, this._mustRevalidate, $.$mnhh.MNHH.CacheControlHeaderValue.MustRevalidateString);
                $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueIfRequired(sb, this._proxyRevalidate, $.$mnhh.MNHH.CacheControlHeaderValue.ProxyRevalidateString);
                if (this._noCache)
                {
                    $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.MNHH.CacheControlHeaderValue.NoCacheString);
                    if ((this._noCacheHeaders !== null) && (this._noCacheHeaders.SCG$ICollection$$$Count > 0))
                    {
                        sb.Append$21("=\"");
                        $.$mnhh.MNHH.CacheControlHeaderValue.AppendValues(sb, this._noCacheHeaders);
                        sb.Append$5(/*\"*/ 34);
                    }
                }
                if ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this._maxAge))
                {
                    $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.MNHH.CacheControlHeaderValue.MaxAgeString);
                    sb.Append$5(/*=*/ 61);
                    sb.Append$21($.$$.S.Int32.ToString$1.call(($.$cast($.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this._maxAge).TotalSeconds, $.$$.S.Int32)), $.$$.SG.NumberFormatInfo.InvariantInfo));
                }
                if ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this._sharedMaxAge))
                {
                    $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.MNHH.CacheControlHeaderValue.SharedMaxAgeString);
                    sb.Append$5(/*=*/ 61);
                    sb.Append$21($.$$.S.Int32.ToString$1.call(($.$cast($.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this._sharedMaxAge).TotalSeconds, $.$$.S.Int32)), $.$$.SG.NumberFormatInfo.InvariantInfo));
                }
                if (this._maxStale)
                {
                    $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.MNHH.CacheControlHeaderValue.MaxStaleString);
                    if ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this._maxStaleLimit))
                    {
                        sb.Append$5(/*=*/ 61);
                        sb.Append$21($.$$.S.Int32.ToString$1.call(($.$cast($.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this._maxStaleLimit).TotalSeconds, $.$$.S.Int32)), $.$$.SG.NumberFormatInfo.InvariantInfo));
                    }
                }
                if ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this._minFresh))
                {
                    $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.MNHH.CacheControlHeaderValue.MinFreshString);
                    sb.Append$5(/*=*/ 61);
                    sb.Append$21($.$$.S.Int32.ToString$1.call(($.$cast($.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this._minFresh).TotalSeconds, $.$$.S.Int32)), $.$$.SG.NumberFormatInfo.InvariantInfo));
                }
                if (this._private)
                {
                    $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.MNHH.CacheControlHeaderValue.PrivateString);
                    if ((this._privateHeaders !== null) && (this._privateHeaders.SCG$ICollection$$$Count > 0))
                    {
                        sb.Append$21("=\"");
                        $.$mnhh.MNHH.CacheControlHeaderValue.AppendValues(sb, this._privateHeaders);
                        sb.Append$5(/*\"*/ 34);
                    }
                }
                $.$mnhh.MNHH.NameValueHeaderValue.ToString$1(this._extensions, /*,*/ 44, false, sb);
                return sb.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(493921370234)
            
            //--TRIMMABLE-BOUNDARY-START(103079346298)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.CacheControlHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if ((this._noCache !== other._noCache) || (this._noStore !== other._noStore) || (this._maxAge !== other._maxAge) || (this._sharedMaxAge !== other._sharedMaxAge) || (this._maxStale !== other._maxStale) || (this._maxStaleLimit !== other._maxStaleLimit) || (this._minFresh !== other._minFresh) || (this._noTransform !== other._noTransform) || (this._onlyIfCached !== other._onlyIfCached) || (this._public !== other._public) || (this._private !== other._private) || (this._mustRevalidate !== other._mustRevalidate) || (this._proxyRevalidate !== other._proxyRevalidate))
                {
                    return false;
                }
                if (!$.$mnhh.MNHH.HeaderUtilities.AreEqualCollections($.$mep.MEP.StringSegment, this._noCacheHeaders, other._noCacheHeaders, $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase))
                {
                    return false;
                }
                if (!$.$mnhh.MNHH.HeaderUtilities.AreEqualCollections($.$mep.MEP.StringSegment, this._privateHeaders, other._privateHeaders, $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase))
                {
                    return false;
                }
                if (!$.$mnhh.MNHH.HeaderUtilities.AreEqualCollections$1($.$mnhh.MNHH.NameValueHeaderValue, this._extensions, other._extensions))
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(103079346298)
            
            //--TRIMMABLE-BOUNDARY-START(253403201658)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403201658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let result = $.$$.S.Boolean.GetHashCode.call(this._noCache) ^ ($.$$.S.Boolean.GetHashCode.call(this._noStore) << 1) ^ ($.$$.S.Boolean.GetHashCode.call(this._maxStale) << 2) ^ ($.$$.S.Boolean.GetHashCode.call(this._noTransform) << 3) ^ ($.$$.S.Boolean.GetHashCode.call(this._onlyIfCached) << 4) ^ ($.$$.S.Boolean.GetHashCode.call(this._public) << 5) ^ ($.$$.S.Boolean.GetHashCode.call(this._private) << 6) ^ ($.$$.S.Boolean.GetHashCode.call(this._mustRevalidate) << 7) ^ ($.$$.S.Boolean.GetHashCode.call(this._proxyRevalidate) << 8);
                result = result ^ ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this._maxAge) ? $.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this._maxAge).GetHashCode() ^ 1 : 0) ^ ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this._sharedMaxAge) ? $.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this._sharedMaxAge).GetHashCode() ^ 2 : 0) ^ ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this._maxStaleLimit) ? $.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this._maxStaleLimit).GetHashCode() ^ 4 : 0) ^ ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this._minFresh) ? $.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this._minFresh).GetHashCode() ^ 8 : 0);
                if ((this._noCacheHeaders !== null) && (this._noCacheHeaders.SCG$ICollection$$$Count > 0))
                {
                    let $en1 = this._noCacheHeaders.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let noCacheHeader = $en1.SCG$IEnumerator$$$Current;
                        {
                            result = result ^ $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(noCacheHeader);
                        }
                    }
                }
                if ((this._privateHeaders !== null) && (this._privateHeaders.SCG$ICollection$$$Count > 0))
                {
                    let $en2 = this._privateHeaders.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let privateHeader = $en2.SCG$IEnumerator$$$Current;
                        {
                            result = result ^ $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(privateHeader);
                        }
                    }
                }
                if ((this._extensions !== null) && (this._extensions.SCG$ICollection$$$Count > 0))
                {
                    let $en3 = this._extensions.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        let extension = $en3.SCG$IEnumerator$$$Current;
                        {
                            result = result ^ extension.GetHashCode();
                        }
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(253403201658)
            
            //--TRIMMABLE-BOUNDARY-START(335007580282)
            static /*CacheControlHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007580282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                /*var*/ let result = $.$mnhh.MNHH.CacheControlHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
                if (result === null)
                {
                    throw new $.$$.S.FormatException().$ctor$12("No cache directives found.");
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(335007580282)
            
            //--TRIMMABLE-BOUNDARY-START(498216337530)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out CacheControlHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216337530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                if ($.$mnhh.MNHH.CacheControlHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue) && parsedValue.$v !== null)
                {
                    return true;
                }
                parsedValue.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(498216337530)
            
            //--TRIMMABLE-BOUNDARY-START(249108234362)
            static /*int */ GetCacheControlLength(/*StringSegment*/ input, /*int*/ startIndex, /*out CacheControlHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108234362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*var*/ let nameValueList = new ($.$$.SCG.List$$($.$mnhh.MNHH.NameValueHeaderValue))().$ctor$1();
                while(current < input.Length)
                {
                    /*var*/ let nameValue;
                    if (!$.$mnhh.MNHH.NameValueHeaderValue.MultipleValueParser.TryParseValue(input, $.$ref(() => current, ($v) => current = $v, $.$$.S.Int32), $.$ref(() => nameValue, ($v) => nameValue = $v, $.$mnhh.MNHH.NameValueHeaderValue)))
                    {
                        return 0;
                    }
                    if (nameValue !== null)
                    {
                        nameValueList.Add(nameValue);
                    }
                }
                /*var*/ let result = new $.$mnhh.MNHH.CacheControlHeaderValue().$ctor$1();
                if (!$.$mnhh.MNHH.CacheControlHeaderValue.TrySetCacheControlValues(result, nameValueList))
                {
                    return 0;
                }
                parsedValue.$v = result;
                return ((input.Length - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(249108234362)
            
            //--TRIMMABLE-BOUNDARY-START(502511304826)
            static /*bool */ TrySetCacheControlValues(/*CacheControlHeaderValue*/ cc, /*List<NameValueHeaderValue>*/ nameValueList)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511304826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = 0; i < nameValueList.Count; i++)
                {
                    /*var*/ let nameValue = nameValueList.get_Item(i);
                    /*var*/ let name = nameValue.Name;
                    /*var*/ let success = true;
                    let $switchJumpState9;
                    $switchJumpStart9: while(true)
                    {
                        let $switch9 = $switchJumpState9 ?? (name.Length);
                        switch($switch9)
                        {
                            case 6:
                            if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.PublicString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => cc._public, ($v) => cc._public = $v, null, true));
                            }
                            else 
                            {
                                $switchJumpState9 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart9;
                            }
                            break;
                            case 7:
                            if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.MaxAgeString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.TimeSpan), () => cc._maxAge, ($v) => cc._maxAge = $v, null, true));
                            }
                            else if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.PrivateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetOptionalTokenList(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => cc._private, ($v) => cc._private = $v, null, true), $.$ref(() => cc._privateHeaders, ($v) => cc._privateHeaders = $v, $.$$.SCG.ICollection$$($.$mep.MEP.StringSegment)));
                            }
                            else 
                            {
                                $switchJumpState9 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart9;
                            }
                            break;
                            case 8:
                            if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.NoCacheString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetOptionalTokenList(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => cc._noCache, ($v) => cc._noCache = $v, null, true), $.$ref(() => cc._noCacheHeaders, ($v) => cc._noCacheHeaders = $v, $.$$.SCG.ICollection$$($.$mep.MEP.StringSegment)));
                            }
                            else if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.NoStoreString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => cc._noStore, ($v) => cc._noStore = $v, null, true));
                            }
                            else if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.SharedMaxAgeString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.TimeSpan), () => cc._sharedMaxAge, ($v) => cc._sharedMaxAge = $v, null, true));
                            }
                            else 
                            {
                                $switchJumpState9 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart9;
                            }
                            break;
                            case 9:
                            if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.MaxStaleString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = (($.$mep.MEP.StringSegment.op_Equality(nameValue.Value, $.$mep.MEP.StringSegment.op_Implicit$2(null))) || $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.TimeSpan), () => cc._maxStaleLimit, ($v) => cc._maxStaleLimit = $v, null, true)));
                                if (success)
                                {
                                    cc._maxStale = true;
                                }
                            }
                            else if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.MinFreshString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.TimeSpan), () => cc._minFresh, ($v) => cc._minFresh = $v, null, true));
                            }
                            else 
                            {
                                $switchJumpState9 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart9;
                            }
                            break;
                            case 12:
                            if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.NoTransformString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => cc._noTransform, ($v) => cc._noTransform = $v, null, true));
                            }
                            else 
                            {
                                $switchJumpState9 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart9;
                            }
                            break;
                            case 14:
                            if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.OnlyIfCachedString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => cc._onlyIfCached, ($v) => cc._onlyIfCached = $v, null, true));
                            }
                            else 
                            {
                                $switchJumpState9 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart9;
                            }
                            break;
                            case 15:
                            if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.MustRevalidateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => cc._mustRevalidate, ($v) => cc._mustRevalidate = $v, null, true));
                            }
                            else 
                            {
                                $switchJumpState9 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart9;
                            }
                            break;
                            case 16:
                            if ($.$mep.MEP.StringSegment.Equals$5($.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.CacheControlHeaderValue.ProxyRevalidateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.MNHH.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => cc._proxyRevalidate, ($v) => cc._proxyRevalidate = $v, null, true));
                            }
                            else 
                            {
                                $switchJumpState9 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart9;
                            }
                            break;
                            default:
                            cc.Extensions.SCG$ICollection$$$Add(nameValue);
                            break;
                        }
                        break;
                    }
                    if (!success)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(502511304826)
            
            //--TRIMMABLE-BOUNDARY-START(515396206714)
            static /*bool */ TrySetTokenOnlyValue(/*NameValueHeaderValue*/ nameValue, /*ref bool*/ boolField)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396206714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.op_Inequality(nameValue.Value, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    return false;
                }
                boolField.$v = true;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(515396206714)
            
            //--TRIMMABLE-BOUNDARY-START(506806272122)
            static /*bool */ TrySetOptionalTokenList(/*NameValueHeaderValue*/ nameValue, /*ref bool*/ boolField, /*ref ICollection<StringSegment>?*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506806272122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.op_Equality(nameValue.Value, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    boolField.$v = true;
                    return true;
                }
                /*var*/ let valueString = nameValue.Value;
                if ((valueString.Length < 3) || (valueString.get_Item$1(0) !== /*\"*/ 34) || (valueString.get_Item$1(((valueString.Length - 1) | 0)) !== /*\"*/ 34))
                {
                    return false;
                }
                /*var*/ let current = 1;
                /*var*/ let maxLength = ((valueString.Length - 1) | 0);
                /*var*/ let originalValueCount = destination.$v === null ? 0 : destination.$v.SCG$ICollection$$$Count;
                while(current < maxLength)
                {
                    /*var*/ let separatorFound;
                    current = $.$mnhh.MNHH.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(valueString, current, true, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.S.Boolean));
                    if (current === maxLength)
                    {
                        break;
                    }
                    /*var*/ let tokenLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(valueString, current);
                    if (tokenLength === 0)
                    {
                        return false;
                    }
                    if (destination.$v === null)
                    {
                        destination.$v = new ($.$mnhh.MNHH.ObjectCollection$$($.$mep.MEP.StringSegment))().$ctor$4($.$mnhh.MNHH.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                    }
                    destination.$v.SCG$ICollection$$$Add(valueString.Subsegment(current, tokenLength));
                    current = ((current + tokenLength) | 0);
                }
                if ((destination.$v !== null) && (destination.$v.SCG$ICollection$$$Count > originalValueCount))
                {
                    boolField.$v = true;
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(506806272122)
            
            //--TRIMMABLE-BOUNDARY-START(511101239418)
            static /*bool */ TrySetTimeSpan(/*NameValueHeaderValue*/ nameValue, /*ref TimeSpan?*/ timeSpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101239418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.op_Equality(nameValue.Value, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    return false;
                }
                /*int*/ let seconds;
                if (!$.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt32(nameValue.Value, $.$ref(() => seconds, ($v) => seconds = $v, $.$$.S.Int32)))
                {
                    return false;
                }
                timeSpan.$v = new $.$$.S.TimeSpan().$ctor$6(0, 0, seconds);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(511101239418)
            
            //--TRIMMABLE-BOUNDARY-START(81604509818)
            static /*void */ AppendValueIfRequired(/*StringBuilder*/ sb, /*bool*/ appendValue, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604509818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (appendValue)
                {
                    $.$mnhh.MNHH.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604509818)
            
            //--TRIMMABLE-BOUNDARY-START(90194444410)
            static /*void */ AppendValueWithSeparatorIfRequired(/*StringBuilder*/ sb, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194444410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sb.Length > 0)
                {
                    sb.Append$21(", ");
                }
                sb.Append$21(value);
            }
            //--TRIMMABLE-BOUNDARY-END(90194444410)
            
            //--TRIMMABLE-BOUNDARY-START(85899477114)
            static /*void */ AppendValues(/*StringBuilder*/ sb, /*IEnumerable<StringSegment>*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899477114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let first = true;
                let $en26 = values.SCG$IEnumerable$$$GetEnumerator();
                while ($en26.SC$1$IEnumerator$MoveNext())
                {
                    let value = $en26.SCG$IEnumerator$$$Current;
                    {
                        if (first)
                        {
                            first = false;
                        }
                        else 
                        {
                            sb.Append$21(", ");
                        }
                        sb.Append$17(value.AsSpan());
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899477114)
            
            //--TRIMMABLE-BOUNDARY-START(94489411706)
            static /*void */ CheckIsValidToken(/*StringSegment*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489411706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.CheckValidToken(item, "item");
            }
            //--TRIMMABLE-BOUNDARY-END(94489411706)
            
            //--TRIMMABLE-BOUNDARY-START(77309542522)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(77309542522)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590065786)
                this._maxAge = null;
                //--TRIMMABLE-BOUNDARY-END(8590065786)
                
                //--TRIMMABLE-BOUNDARY-START(68719607930)
                this._sharedMaxAge = null;
                //--TRIMMABLE-BOUNDARY-END(68719607930)
                
                //--TRIMMABLE-BOUNDARY-START(17180000378)
                this._maxStaleLimit = null;
                //--TRIMMABLE-BOUNDARY-END(17180000378)
                
                //--TRIMMABLE-BOUNDARY-START(21474967674)
                this._minFresh = null;
                //--TRIMMABLE-BOUNDARY-END(21474967674)
                
            }
            //--TRIMMABLE-BOUNDARY-START(73014575226)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(369367318650)
                    this.PublicString = "public";
                    //--TRIMMABLE-BOUNDARY-END(369367318650)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187449466)
                    this.PrivateString = "private";
                    //--TRIMMABLE-BOUNDARY-END(352187449466)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993136250)
                    this.MaxAgeString = "max-age";
                    //--TRIMMABLE-BOUNDARY-END(261993136250)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626402938)
                    this.SharedMaxAgeString = "s-maxage";
                    //--TRIMMABLE-BOUNDARY-END(489626402938)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942809210)
                    this.NoCacheString = "no-cache";
                    //--TRIMMABLE-BOUNDARY-END(304942809210)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532743802)
                    this.NoStoreString = "no-store";
                    //--TRIMMABLE-BOUNDARY-END(313532743802)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878038138)
                    this.MaxStaleString = "max-stale";
                    //--TRIMMABLE-BOUNDARY-END(274878038138)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283467972730)
                    this.MinFreshString = "min-fresh";
                    //--TRIMMABLE-BOUNDARY-END(283467972730)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122678394)
                    this.NoTransformString = "no-transform";
                    //--TRIMMABLE-BOUNDARY-END(322122678394)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712612986)
                    this.OnlyIfCachedString = "only-if-cached";
                    //--TRIMMABLE-BOUNDARY-END(330712612986)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057907322)
                    this.MustRevalidateString = "must-revalidate";
                    //--TRIMMABLE-BOUNDARY-END(292057907322)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777384058)
                    this.ProxyRevalidateString = "proxy-revalidate";
                    //--TRIMMABLE-BOUNDARY-END(360777384058)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302547578)
                    this.Parser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.CacheControlHeaderValue))().$ctor$3(true, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.CacheControlHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.CacheControlHeaderValue, $.$mnhh.MNHH.CacheControlHeaderValue.GetCacheControlLength));
                    //--TRIMMABLE-BOUNDARY-END(339302547578)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784379002)
                    this.CheckIsValidTokenAction = new ($.$$.S.Action$$($.$mep.MEP.StringSegment))().$ctor($.$mnhh.MNHH.CacheControlHeaderValue, $.$mnhh.MNHH.CacheControlHeaderValue.CheckIsValidToken);
                    //--TRIMMABLE-BOUNDARY-END(98784379002)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014575226)
            
            static $h = 131194;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(296352874618),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503855738,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 420906926202,
        "f": 83886081
      },
      "n": "NoCache",
      "d": 131194,
      "h": 296352874618,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296352874618),
//--TRIMMABLE-BOUNDARY-START(300647841914),
    {
      "p": $.$$.SCG.ICollection$$($.$mep.MEP.StringSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093790330,
        "f": 50331649
      },
      "n": "NoCacheHeaders",
      "d": 131194,
      "h": 300647841914,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300647841914),
//--TRIMMABLE-BOUNDARY-START(309237776506),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683724922,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429496860794,
        "f": 83886081
      },
      "n": "NoStore",
      "d": 131194,
      "h": 309237776506,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309237776506),
//--TRIMMABLE-BOUNDARY-START(257698168954),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554182778,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377957253242,
        "f": 83886081
      },
      "n": "MaxAge",
      "d": 131194,
      "h": 257698168954,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698168954),
//--TRIMMABLE-BOUNDARY-START(485331435642),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813267066,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 481036468346,
        "f": 83886081
      },
      "n": "SharedMaxAge",
      "d": 131194,
      "h": 485331435642,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(485331435642),
//--TRIMMABLE-BOUNDARY-START(266288103546),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144117370,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386547187834,
        "f": 83886081
      },
      "n": "MaxStale",
      "d": 131194,
      "h": 266288103546,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266288103546),
//--TRIMMABLE-BOUNDARY-START(270583070842),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734051962,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 395137122426,
        "f": 83886081
      },
      "n": "MaxStaleLimit",
      "d": 131194,
      "h": 270583070842,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583070842),
//--TRIMMABLE-BOUNDARY-START(279173005434),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150323986554,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 403727057018,
        "f": 83886081
      },
      "n": "MinFresh",
      "d": 131194,
      "h": 279173005434,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173005434),
//--TRIMMABLE-BOUNDARY-START(317827711098),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273659514,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 438086795386,
        "f": 83886081
      },
      "n": "NoTransform",
      "d": 131194,
      "h": 317827711098,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317827711098),
//--TRIMMABLE-BOUNDARY-START(326417645690),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863594106,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 446676729978,
        "f": 83886081
      },
      "n": "OnlyIfCached",
      "d": 131194,
      "h": 326417645690,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326417645690),
//--TRIMMABLE-BOUNDARY-START(365072351354),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223332474,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 472446533754,
        "f": 83886081
      },
      "n": "Public",
      "d": 131194,
      "h": 365072351354,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(365072351354),
//--TRIMMABLE-BOUNDARY-START(343597514874),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453528698,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 455266664570,
        "f": 83886081
      },
      "n": "Private",
      "d": 131194,
      "h": 343597514874,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343597514874),
//--TRIMMABLE-BOUNDARY-START(347892482170),
    {
      "p": $.$$.SCG.ICollection$$($.$mep.MEP.StringSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043463290,
        "f": 50331649
      },
      "n": "PrivateHeaders",
      "d": 131194,
      "h": 347892482170,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(347892482170),
//--TRIMMABLE-BOUNDARY-START(287762940026),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913921146,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 412316991610,
        "f": 83886081
      },
      "n": "MustRevalidate",
      "d": 131194,
      "h": 287762940026,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287762940026),
//--TRIMMABLE-BOUNDARY-START(356482416762),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633397882,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 463856599162,
        "f": 83886081
      },
      "n": "ProxyRevalidate",
      "d": 131194,
      "h": 356482416762,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356482416762),
//--TRIMMABLE-BOUNDARY-START(107374313594),
    {
      "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964248186,
        "f": 50331649
      },
      "n": "Extensions",
      "d": 131194,
      "h": 107374313594,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374313594)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(493921370234),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 131194,
      "h": 493921370234,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(493921370234),
//--TRIMMABLE-BOUNDARY-START(103079346298),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 131194,
      "h": 103079346298,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103079346298),
//--TRIMMABLE-BOUNDARY-START(253403201658),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 131194,
      "h": 253403201658,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(253403201658),
//--TRIMMABLE-BOUNDARY-START(335007580282),
    {
      "r": 131194,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 131194,
      "h": 335007580282,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(335007580282),
//--TRIMMABLE-BOUNDARY-START(498216337530),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 131194,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 131194,
      "h": 498216337530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(498216337530),
//--TRIMMABLE-BOUNDARY-START(249108234362),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 131194,
          "f": 2
        }
      ],
      "n": "GetCacheControlLength",
      "d": 131194,
      "h": 249108234362,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(249108234362),
//--TRIMMABLE-BOUNDARY-START(502511304826),
    {
      "r": 262145,
      "p": [
        {
          "n": "cc",
          "p": 131194
        },
        {
          "n": "nameValueList",
          "p": $.$$.SCG.List$$($.$mnhh.MNHH.NameValueHeaderValue).$h
        }
      ],
      "n": "TrySetCacheControlValues",
      "d": 131194,
      "h": 502511304826,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(502511304826),
//--TRIMMABLE-BOUNDARY-START(515396206714),
    {
      "r": 262145,
      "p": [
        {
          "n": "nameValue",
          "p": 1310842
        },
        {
          "n": "boolField",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "TrySetTokenOnlyValue",
      "d": 131194,
      "h": 515396206714,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(515396206714),
//--TRIMMABLE-BOUNDARY-START(506806272122),
    {
      "r": 262145,
      "p": [
        {
          "n": "nameValue",
          "p": 1310842
        },
        {
          "n": "boolField",
          "p": 262145,
          "f": 4
        },
        {
          "n": "destination",
          "p": $.$$.SCG.ICollection$$($.$mep.MEP.StringSegment).$h,
          "f": 4
        }
      ],
      "n": "TrySetOptionalTokenList",
      "d": 131194,
      "h": 506806272122,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(506806272122),
//--TRIMMABLE-BOUNDARY-START(511101239418),
    {
      "r": 262145,
      "p": [
        {
          "n": "nameValue",
          "p": 1310842
        },
        {
          "n": "timeSpan",
          "p": $.$typeNullable($.$$.S.TimeSpan).$h,
          "f": 4
        }
      ],
      "n": "TrySetTimeSpan",
      "d": 131194,
      "h": 511101239418,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(511101239418),
//--TRIMMABLE-BOUNDARY-START(81604509818),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 167837697
        },
        {
          "n": "appendValue",
          "p": 262145
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AppendValueIfRequired",
      "d": 131194,
      "h": 81604509818,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604509818),
//--TRIMMABLE-BOUNDARY-START(90194444410),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 167837697
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AppendValueWithSeparatorIfRequired",
      "d": 131194,
      "h": 90194444410,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90194444410),
//--TRIMMABLE-BOUNDARY-START(85899477114),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 167837697
        },
        {
          "n": "values",
          "p": $.$$.SCG.IEnumerable$$($.$mep.MEP.StringSegment).$h
        }
      ],
      "n": "AppendValues",
      "d": 131194,
      "h": 85899477114,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899477114),
//--TRIMMABLE-BOUNDARY-START(94489411706),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": 852053
        }
      ],
      "n": "CheckIsValidToken",
      "d": 131194,
      "h": 94489411706,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489411706)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(369367318650),
    {
      "t": 1310721,
      "n": "PublicString",
      "d": 131194,
      "h": 369367318650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369367318650),
//--TRIMMABLE-BOUNDARY-START(352187449466),
    {
      "t": 1310721,
      "n": "PrivateString",
      "d": 131194,
      "h": 352187449466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352187449466),
//--TRIMMABLE-BOUNDARY-START(261993136250),
    {
      "t": 1310721,
      "n": "MaxAgeString",
      "d": 131194,
      "h": 261993136250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993136250),
//--TRIMMABLE-BOUNDARY-START(489626402938),
    {
      "t": 1310721,
      "n": "SharedMaxAgeString",
      "d": 131194,
      "h": 489626402938,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(489626402938),
//--TRIMMABLE-BOUNDARY-START(304942809210),
    {
      "t": 1310721,
      "n": "NoCacheString",
      "d": 131194,
      "h": 304942809210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304942809210),
//--TRIMMABLE-BOUNDARY-START(313532743802),
    {
      "t": 1310721,
      "n": "NoStoreString",
      "d": 131194,
      "h": 313532743802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313532743802),
//--TRIMMABLE-BOUNDARY-START(274878038138),
    {
      "t": 1310721,
      "n": "MaxStaleString",
      "d": 131194,
      "h": 274878038138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274878038138),
//--TRIMMABLE-BOUNDARY-START(283467972730),
    {
      "t": 1310721,
      "n": "MinFreshString",
      "d": 131194,
      "h": 283467972730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283467972730),
//--TRIMMABLE-BOUNDARY-START(322122678394),
    {
      "t": 1310721,
      "n": "NoTransformString",
      "d": 131194,
      "h": 322122678394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322122678394),
//--TRIMMABLE-BOUNDARY-START(330712612986),
    {
      "t": 1310721,
      "n": "OnlyIfCachedString",
      "d": 131194,
      "h": 330712612986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330712612986),
//--TRIMMABLE-BOUNDARY-START(292057907322),
    {
      "t": 1310721,
      "n": "MustRevalidateString",
      "d": 131194,
      "h": 292057907322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292057907322),
//--TRIMMABLE-BOUNDARY-START(360777384058),
    {
      "t": 1310721,
      "n": "ProxyRevalidateString",
      "d": 131194,
      "h": 360777384058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360777384058),
//--TRIMMABLE-BOUNDARY-START(339302547578),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.CacheControlHeaderValue).$h,
      "n": "Parser",
      "d": 131194,
      "h": 339302547578,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(339302547578),
//--TRIMMABLE-BOUNDARY-START(98784379002),
    {
      "t": $.$$.S.Action$$($.$mep.MEP.StringSegment).$h,
      "n": "CheckIsValidTokenAction",
      "d": 131194,
      "h": 98784379002,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(98784379002),
//--TRIMMABLE-BOUNDARY-START(30064902266),
    {
      "t": 262145,
      "n": "_noCache",
      "d": 131194,
      "h": 30064902266,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064902266),
//--TRIMMABLE-BOUNDARY-START(34359869562),
    {
      "t": $.$$.SCG.ICollection$$($.$mep.MEP.StringSegment).$h,
      "n": "_noCacheHeaders",
      "d": 131194,
      "h": 34359869562,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359869562),
//--TRIMMABLE-BOUNDARY-START(38654836858),
    {
      "t": 262145,
      "n": "_noStore",
      "d": 131194,
      "h": 38654836858,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654836858),
//--TRIMMABLE-BOUNDARY-START(8590065786),
    {
      "t": $.$typeNullable($.$$.S.TimeSpan).$h,
      "n": "_maxAge",
      "d": 131194,
      "h": 8590065786,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065786),
//--TRIMMABLE-BOUNDARY-START(68719607930),
    {
      "t": $.$typeNullable($.$$.S.TimeSpan).$h,
      "n": "_sharedMaxAge",
      "d": 131194,
      "h": 68719607930,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68719607930),
//--TRIMMABLE-BOUNDARY-START(12885033082),
    {
      "t": 262145,
      "n": "_maxStale",
      "d": 131194,
      "h": 12885033082,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033082),
//--TRIMMABLE-BOUNDARY-START(17180000378),
    {
      "t": $.$typeNullable($.$$.S.TimeSpan).$h,
      "n": "_maxStaleLimit",
      "d": 131194,
      "h": 17180000378,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180000378),
//--TRIMMABLE-BOUNDARY-START(21474967674),
    {
      "t": $.$typeNullable($.$$.S.TimeSpan).$h,
      "n": "_minFresh",
      "d": 131194,
      "h": 21474967674,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474967674),
//--TRIMMABLE-BOUNDARY-START(42949804154),
    {
      "t": 262145,
      "n": "_noTransform",
      "d": 131194,
      "h": 42949804154,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949804154),
//--TRIMMABLE-BOUNDARY-START(47244771450),
    {
      "t": 262145,
      "n": "_onlyIfCached",
      "d": 131194,
      "h": 47244771450,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47244771450),
//--TRIMMABLE-BOUNDARY-START(64424640634),
    {
      "t": 262145,
      "n": "_public",
      "d": 131194,
      "h": 64424640634,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64424640634),
//--TRIMMABLE-BOUNDARY-START(51539738746),
    {
      "t": 262145,
      "n": "_private",
      "d": 131194,
      "h": 51539738746,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51539738746),
//--TRIMMABLE-BOUNDARY-START(55834706042),
    {
      "t": $.$$.SCG.ICollection$$($.$mep.MEP.StringSegment).$h,
      "n": "_privateHeaders",
      "d": 131194,
      "h": 55834706042,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834706042),
//--TRIMMABLE-BOUNDARY-START(25769934970),
    {
      "t": 262145,
      "n": "_mustRevalidate",
      "d": 131194,
      "h": 25769934970,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769934970),
//--TRIMMABLE-BOUNDARY-START(60129673338),
    {
      "t": 262145,
      "n": "_proxyRevalidate",
      "d": 131194,
      "h": 60129673338,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60129673338),
//--TRIMMABLE-BOUNDARY-START(4295098490),
    {
      "t": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "n": "_extensions",
      "d": 131194,
      "h": 4295098490,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098490)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(77309542522),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131194,
      "h": 77309542522,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309542522)
  ],
  "h": 131194
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.CacheControlHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}CacheControlHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131194)
        
        

        //--TRIMMABLE-BOUNDARY-START(458874)
        $asm.$cls(`$mnhh.MNHH.CookieHeaderParserShared`, ($self) => class CookieHeaderParserShared
        {
            //--TRIMMABLE-BOUNDARY-START(8590393466)
            /*SearchValues<char>*/ static CookieValueChar = null;
            //--TRIMMABLE-BOUNDARY-END(8590393466)
            
            //--TRIMMABLE-BOUNDARY-START(34360197242)
            static /*bool */ TryParseValues(/*StringValues*/ values, /*IDictionary<string, string>*/ store, /*bool*/ supportsMultipleValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (values.Count === 0)
                {
                    return false;
                }
                /*var*/ let hasFoundValue = false;
                for(/*var*/ let i = 0; i < values.Count; i++)
                {
                    /*var*/ let value = values.get_Item$1(i);
                    /*var*/ let index = 0;
                    while(!$.$$.S.String.IsNullOrEmpty(value) && index < value.length)
                    {
                        /*var*/ let parsedName;
                        /*var*/ let parsedValue;
                        if ($.$mnhh.MNHH.CookieHeaderParserShared.TryParseValue($.$mep.MEP.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), supportsMultipleValues, $.$ref(() => parsedName, ($v) => parsedName = $v, $.$typeNullable($.$mep.MEP.StringSegment)), $.$ref(() => parsedValue, ($v) => parsedValue = $v, $.$typeNullable($.$mep.MEP.StringSegment))))
                        {
                            if (parsedName === null || $.$mep.MEP.StringSegment.IsNullOrEmpty($.$$.S.Nullable$$($.$mep.MEP.StringSegment).Value$get.call(parsedName)) || parsedValue === null || $.$mep.MEP.StringSegment.IsNullOrEmpty($.$$.S.Nullable$$($.$mep.MEP.StringSegment).Value$get.call(parsedValue)))
                            {
                                continue;
                            }
                            store.SCG$IDictionary$$$$set_Item($.$$.S.Nullable$$($.$mep.MEP.StringSegment).Value$get.call(parsedName).Value, $.$spu.S.Uri.UnescapeDataString$2($.$$.S.Nullable$$($.$mep.MEP.StringSegment).Value$get.call(parsedValue).Value));
                            hasFoundValue = true;
                        }
                        else 
                        {
                            index++;
                        }
                    }
                }
                return hasFoundValue;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197242)
            
            //--TRIMMABLE-BOUNDARY-START(30065229946)
            static /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*bool*/ supportsMultipleValues, /*out StringSegment?*/ parsedName, /*out StringSegment?*/ parsedValue)
            {
                /*var*/ let separatorFound;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parsedName.$v = null;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(value) || (index.$v === value.Length))
                {
                    return supportsMultipleValues;
                }
                /*var*/ let current = $.$mnhh.MNHH.CookieHeaderParserShared.GetNextNonEmptyOrWhitespaceIndex(value, index.$v, supportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.S.Boolean));
                if (separatorFound && !supportsMultipleValues)
                {
                    return false;
                }
                if (current === value.Length)
                {
                    if (supportsMultipleValues)
                    {
                        index.$v = current;
                    }
                    return supportsMultipleValues;
                }
                if (!$.$mnhh.MNHH.CookieHeaderParserShared.TryGetCookieLength(value, $.$ref(() => current, ($v) => current = $v, $.$$.S.Int32), parsedName, parsedValue))
                {
                    /*var*/ let separatorIndex = value.IndexOf$1(/*;*/ 59, current);
                    if (separatorIndex > 0)
                    {
                        index.$v = separatorIndex;
                    }
                    else 
                    {
                        index.$v = value.Length;
                    }
                    return false;
                }
                current = $.$mnhh.MNHH.CookieHeaderParserShared.GetNextNonEmptyOrWhitespaceIndex(value, current, supportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.S.Boolean));
                if ((separatorFound && !supportsMultipleValues) || (!separatorFound && (current < value.Length)))
                {
                    /*var*/ let separatorIndex = value.IndexOf$1(/*;*/ 59, current);
                    if (separatorIndex > 0)
                    {
                        index.$v = separatorIndex;
                    }
                    else 
                    {
                        index.$v = value.Length;
                    }
                    return false;
                }
                index.$v = current;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30065229946)
            
            //--TRIMMABLE-BOUNDARY-START(17180328058)
            static /*int */ GetNextNonEmptyOrWhitespaceIndex(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ skipEmptyValues, /*out bool*/ separatorFound)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                separatorFound.$v = false;
                /*var*/ let current = ((startIndex + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                if (current === input.Length || input.get_Item$1(current) !== /*;*/ 59)
                {
                    return current;
                }
                separatorFound.$v = true;
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (skipEmptyValues)
                {
                    while(current < input.Length && input.get_Item$1(current) === /*;*/ 59)
                    {
                        current++;
                        current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                }
                return current;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328058)
            
            //--TRIMMABLE-BOUNDARY-START(25770262650)
            static /*bool */ TryGetCookieLength(/*StringSegment*/ input, /*ref int*/ offset, /*out StringSegment?*/ parsedName, /*out StringSegment?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedName.$v = null;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (offset.$v >= input.Length))
                {
                    return false;
                }
                /*var*/ let itemLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, offset.$v);
                if (itemLength === 0)
                {
                    return false;
                }
                parsedName.$v = input.Subsegment(offset.$v, itemLength);
                offset.$v += itemLength;
                if (!$.$mnhh.MNHH.CookieHeaderParserShared.ReadEqualsSign(input, offset))
                {
                    return false;
                }
                parsedValue.$v = $.$mnhh.MNHH.CookieHeaderParserShared.GetCookieValue(input, offset);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262650)
            
            //--TRIMMABLE-BOUNDARY-START(12885360762)
            static /*StringSegment */ GetCookieValue(/*StringSegment*/ input, /*ref int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                ;
                /*var*/ let startIndex = offset.$v;
                if (offset.$v >= input.Length)
                {
                    return $.$mep.MEP.StringSegment.Empty;
                }
                /*var*/ let inQuotes = false;
                if (input.get_Item$1(offset.$v) === /*\"*/ 34)
                {
                    inQuotes = true;
                    offset.$v++;
                }
                /*var*/ let delta = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, input.AsSpan$2(offset.$v), $.$mnhh.MNHH.CookieHeaderParserShared.CookieValueChar);
                if (delta < 0)
                {
                    offset.$v = input.Length;
                }
                else 
                {
                    offset.$v += delta;
                }
                if (inQuotes)
                {
                    if (offset.$v === input.Length || input.get_Item$1(offset.$v) !== /*\"*/ 34)
                    {
                        return $.$mep.MEP.StringSegment.Empty;
                    }
                    offset.$v++;
                }
                /*var*/ let length = ((offset.$v - startIndex) | 0);
                if (offset.$v > startIndex)
                {
                    return input.Subsegment(startIndex, length);
                }
                return $.$mep.MEP.StringSegment.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360762)
            
            //--TRIMMABLE-BOUNDARY-START(21475295354)
            static /*bool */ ReadEqualsSign(/*StringSegment*/ input, /*ref int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset.$v >= input.Length || input.get_Item$1(offset.$v) !== /*=*/ 61)
                {
                    return false;
                }
                offset.$v++;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295354)
            
            //--TRIMMABLE-BOUNDARY-START(4295426170)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393466)
                    this.CookieValueChar = $.$$.SB.SearchValues.Create$1($.$$.S.String.op_Implicit("!#$%&'()*+-./0123456789:<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
                    //--TRIMMABLE-BOUNDARY-END(8590393466)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426170)
            
            static $h = 458874;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360197242),
    {
      "r": 262145,
      "p": [
        {
          "n": "values",
          "p": 1114197
        },
        {
          "n": "store",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        },
        {
          "n": "supportsMultipleValues",
          "p": 262145
        }
      ],
      "n": "TryParseValues",
      "d": 458874,
      "h": 34360197242,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360197242),
//--TRIMMABLE-BOUNDARY-START(30065229946),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "supportsMultipleValues",
          "p": 262145
        },
        {
          "n": "parsedName",
          "p": $.$typeNullable($.$mep.MEP.StringSegment).$h,
          "f": 2
        },
        {
          "n": "parsedValue",
          "p": $.$typeNullable($.$mep.MEP.StringSegment).$h,
          "f": 2
        }
      ],
      "n": "TryParseValue",
      "d": 458874,
      "h": 30065229946,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065229946),
//--TRIMMABLE-BOUNDARY-START(17180328058),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "skipEmptyValues",
          "p": 262145
        },
        {
          "n": "separatorFound",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "GetNextNonEmptyOrWhitespaceIndex",
      "d": 458874,
      "h": 17180328058,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180328058),
//--TRIMMABLE-BOUNDARY-START(25770262650),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        },
        {
          "n": "parsedName",
          "p": $.$typeNullable($.$mep.MEP.StringSegment).$h,
          "f": 2
        },
        {
          "n": "parsedValue",
          "p": $.$typeNullable($.$mep.MEP.StringSegment).$h,
          "f": 2
        }
      ],
      "n": "TryGetCookieLength",
      "d": 458874,
      "h": 25770262650,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770262650),
//--TRIMMABLE-BOUNDARY-START(12885360762),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "GetCookieValue",
      "d": 458874,
      "h": 12885360762,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885360762),
//--TRIMMABLE-BOUNDARY-START(21475295354),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "ReadEqualsSign",
      "d": 458874,
      "h": 21475295354,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475295354)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393466),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "CookieValueChar",
      "d": 458874,
      "h": 8590393466,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590393466)
  ],
  "h": 458874
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.CookieHeaderParserShared`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}CookieHeaderParserShared`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458874)
        
        

        //--TRIMMABLE-BOUNDARY-START(589946)
        $asm.$cls(`$mnhh.MNHH.EntityTagHeaderValue`, ($self) => class EntityTagHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(103079805050)
            /*HttpHeaderParser<EntityTagHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(103079805050)
            
            //--TRIMMABLE-BOUNDARY-START(85899935866)
            /*HttpHeaderParser<EntityTagHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(85899935866)
            
            //--TRIMMABLE-BOUNDARY-START(8590524538)
            /*StringSegment*/ _tag;
            //--TRIMMABLE-BOUNDARY-END(8590524538)
            
            //--TRIMMABLE-BOUNDARY-START(4295557242)
            /*bool*/ _isWeak = false;
            //--TRIMMABLE-BOUNDARY-END(4295557242)
            
            //--TRIMMABLE-BOUNDARY-START(21475426426)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426426);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426426)
            
            //--TRIMMABLE-BOUNDARY-START(30065361018)
            $ctor$3(/*StringSegment*/ tag)
            {
                this.$ctor$2(tag, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065361018);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065361018)
            
            //--TRIMMABLE-BOUNDARY-START(25770393722)
            $ctor$2(/*StringSegment*/ tag, /*bool*/ isWeak)
            {
                super.$ctor();
                {
                    /*var*/ let length;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393722);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$mep.MEP.StringSegment.IsNullOrEmpty(tag))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13("An empty string is not allowed.", "tag");
                    }
                    if (!isWeak && $.$mep.MEP.StringSegment.Equals$5(tag, $.$mep.MEP.StringSegment.op_Implicit$2("*"), 4/*StringComparison.Ordinal*/))
                    {
                        this._tag = tag;
                    }
                    else if (($.$mnhh.MNHH.HttpRuleParser.GetQuotedStringLength(tag, 0, $.$ref(() => length, ($v) => length = $v, $.$$.S.Int32)) !== 0/*HttpParseResult.Parsed*/) || (length !== tag.Length))
                    {
                        throw new $.$$.S.FormatException().$ctor$12("Invalid ETag name");
                    }
                    this._tag = tag;
                    this._isWeak = isWeak;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393722)
            
            //--TRIMMABLE-BOUNDARY-START(34360328314)
            /*EntityTagHeaderValue*/ static Any = null;
            //--TRIMMABLE-BOUNDARY-END(34360328314)
            
            //--TRIMMABLE-BOUNDARY-START(107374772346)
            /*StringSegment */ get Tag()
            {
                return this._tag;
            }
            //--TRIMMABLE-BOUNDARY-END(107374772346)
            
            //--TRIMMABLE-BOUNDARY-START(81604968570)
            /*bool */ get IsWeak()
            {
                return this._isWeak;
            }
            //--TRIMMABLE-BOUNDARY-END(81604968570)
            
            //--TRIMMABLE-BOUNDARY-START(111669739642)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isWeak)
                {
                    return "W/" + $.$strNN(this._tag.ToString());
                }
                return this._tag.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(111669739642)
            
            //--TRIMMABLE-BOUNDARY-START(42950262906)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$mnhh.MNHH.EntityTagHeaderValue, { set $v($v){ other = $v; } }) && this._isWeak === other._isWeak && $.$mep.MEP.StringSegment.Equals$5(this._tag, other._tag, 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(42950262906)
            
            //--TRIMMABLE-BOUNDARY-START(77310001274)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._tag.GetHashCode() ^ $.$$.S.Boolean.GetHashCode.call(this._isWeak);
            }
            //--TRIMMABLE-BOUNDARY-END(77310001274)
            
            //--TRIMMABLE-BOUNDARY-START(38655295610)
            /*bool */ Compare(/*EntityTagHeaderValue?*/ other, /*bool*/ useStrongComparison)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (other === null)
                {
                    return false;
                }
                if (useStrongComparison)
                {
                    return !this.IsWeak && !other.IsWeak && $.$mep.MEP.StringSegment.Equals$5(this.Tag, other.Tag, 4/*StringComparison.Ordinal*/);
                }
                else 
                {
                    return $.$mep.MEP.StringSegment.Equals$5(this.Tag, other.Tag, 4/*StringComparison.Ordinal*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655295610)
            
            //--TRIMMABLE-BOUNDARY-START(90194903162)
            static /*EntityTagHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.EntityTagHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(90194903162)
            
            //--TRIMMABLE-BOUNDARY-START(115964706938)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out EntityTagHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.EntityTagHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(115964706938)
            
            //--TRIMMABLE-BOUNDARY-START(94489870458)
            static /*IList<EntityTagHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.EntityTagHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(94489870458)
            
            //--TRIMMABLE-BOUNDARY-START(98784837754)
            static /*IList<EntityTagHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.EntityTagHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(98784837754)
            
            //--TRIMMABLE-BOUNDARY-START(120259674234)
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<EntityTagHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.EntityTagHeaderValue.MultipleValueParser.TryParseValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(120259674234)
            
            //--TRIMMABLE-BOUNDARY-START(124554641530)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<EntityTagHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.EntityTagHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(124554641530)
            
            //--TRIMMABLE-BOUNDARY-START(73015033978)
            static /*int */ GetEntityTagLength(/*StringSegment*/ input, /*int*/ startIndex, /*out EntityTagHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let isWeak = false;
                /*var*/ let current = startIndex;
                /*var*/ let firstChar = input.get_Item$1(startIndex);
                if (firstChar === /***/ 42)
                {
                    parsedValue.$v = $.$mnhh.MNHH.EntityTagHeaderValue.Any;
                    current++;
                }
                else 
                {
                    /*var*/ let tagLength;
                    if ((firstChar === /*W*/ 87) || (firstChar === /*w*/ 119))
                    {
                        current++;
                        if ((((current + 2) | 0) >= input.Length) || (input.get_Item$1(current) !== /*/*/ 47))
                        {
                            return 0;
                        }
                        isWeak = true;
                        current++;
                        current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                    /*var*/ let tagStartIndex = current;
                    if ($.$mnhh.MNHH.HttpRuleParser.GetQuotedStringLength(input, current, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.S.Int32)) !== 0/*HttpParseResult.Parsed*/)
                    {
                        return 0;
                    }
                    parsedValue.$v = new $.$mnhh.MNHH.EntityTagHeaderValue().$ctor$1();
                    if (tagLength === input.Length)
                    {
                        $.$$.SDC$1.Contract.Assert$1(startIndex === 0);
                        $.$$.SDC$1.Contract.Assert$1(!isWeak);
                        parsedValue.$v._tag = input;
                        parsedValue.$v._isWeak = false;
                    }
                    else 
                    {
                        parsedValue.$v._tag = input.Subsegment(tagStartIndex, tagLength);
                        parsedValue.$v._isWeak = isWeak;
                    }
                    current = ((current + tagLength) | 0);
                }
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(73015033978)
            
            //--TRIMMABLE-BOUNDARY-START(21475426426)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475426426)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590524538)
                this._tag = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8590524538)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17180459130)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(103079805050)
                    this.SingleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.EntityTagHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.EntityTagHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.EntityTagHeaderValue, $.$mnhh.MNHH.EntityTagHeaderValue.GetEntityTagLength));
                    //--TRIMMABLE-BOUNDARY-END(103079805050)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899935866)
                    this.MultipleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.EntityTagHeaderValue))().$ctor$3(true, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.EntityTagHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.EntityTagHeaderValue, $.$mnhh.MNHH.EntityTagHeaderValue.GetEntityTagLength));
                    //--TRIMMABLE-BOUNDARY-END(85899935866)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360328314)
                    this.Any = new $.$mnhh.MNHH.EntityTagHeaderValue().$ctor$2($.$mep.MEP.StringSegment.op_Implicit$2("*"), false);
                    //--TRIMMABLE-BOUNDARY-END(34360328314)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180459130)
            
            static $h = 589946;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360328314),
    {
      "p": 589946,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197498,
        "f": 50331681
      },
      "n": "Any",
      "d": 589946,
      "h": 34360328314,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360328314),
//--TRIMMABLE-BOUNDARY-START(107374772346),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066682,
        "f": 50331649
      },
      "n": "Tag",
      "d": 589946,
      "h": 107374772346,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374772346),
//--TRIMMABLE-BOUNDARY-START(81604968570),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132090,
        "f": 50331649
      },
      "n": "IsWeak",
      "d": 589946,
      "h": 81604968570,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604968570)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669739642),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 589946,
      "h": 111669739642,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669739642),
//--TRIMMABLE-BOUNDARY-START(42950262906),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 589946,
      "h": 42950262906,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950262906),
//--TRIMMABLE-BOUNDARY-START(77310001274),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 589946,
      "h": 77310001274,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310001274),
//--TRIMMABLE-BOUNDARY-START(38655295610),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 589946
        },
        {
          "n": "useStrongComparison",
          "p": 262145
        }
      ],
      "n": "Compare",
      "d": 589946,
      "h": 38655295610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295610),
//--TRIMMABLE-BOUNDARY-START(90194903162),
    {
      "r": 589946,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 589946,
      "h": 90194903162,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194903162),
//--TRIMMABLE-BOUNDARY-START(115964706938),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 589946,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 589946,
      "h": 115964706938,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964706938),
//--TRIMMABLE-BOUNDARY-START(94489870458),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.EntityTagHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseList",
      "d": 589946,
      "h": 94489870458,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94489870458),
//--TRIMMABLE-BOUNDARY-START(98784837754),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.EntityTagHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 589946,
      "h": 98784837754,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98784837754),
//--TRIMMABLE-BOUNDARY-START(120259674234),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.EntityTagHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 589946,
      "h": 120259674234,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120259674234),
//--TRIMMABLE-BOUNDARY-START(124554641530),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.EntityTagHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 589946,
      "h": 124554641530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124554641530),
//--TRIMMABLE-BOUNDARY-START(73015033978),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 589946,
          "f": 2
        }
      ],
      "n": "GetEntityTagLength",
      "d": 589946,
      "h": 73015033978,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73015033978)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(103079805050),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.EntityTagHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 589946,
      "h": 103079805050,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103079805050),
//--TRIMMABLE-BOUNDARY-START(85899935866),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.EntityTagHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 589946,
      "h": 85899935866,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85899935866),
//--TRIMMABLE-BOUNDARY-START(8590524538),
    {
      "t": 852053,
      "n": "_tag",
      "d": 589946,
      "h": 8590524538,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524538),
//--TRIMMABLE-BOUNDARY-START(4295557242),
    {
      "t": 262145,
      "n": "_isWeak",
      "d": 589946,
      "h": 4295557242,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557242)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426426),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589946,
      "h": 21475426426,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475426426),
//--TRIMMABLE-BOUNDARY-START(30065361018),
    {
      "p": [
        {
          "n": "tag",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589946,
      "h": 30065361018,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065361018),
//--TRIMMABLE-BOUNDARY-START(25770393722),
    {
      "p": [
        {
          "n": "tag",
          "p": 852053
        },
        {
          "n": "isWeak",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589946,
      "h": 25770393722,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393722)
  ],
  "h": 589946
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.EntityTagHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}EntityTagHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589946)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179770)
        $asm.$cls(`$mnhh.MNHH.MediaTypeHeaderValue`, ($self) => class MediaTypeHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655885434)
            /*string*/ static BoundaryString = null;
            //--TRIMMABLE-BOUNDARY-END(38655885434)
            
            //--TRIMMABLE-BOUNDARY-START(47245820026)
            /*string*/ static CharsetString = null;
            //--TRIMMABLE-BOUNDARY-END(47245820026)
            
            //--TRIMMABLE-BOUNDARY-START(231929413754)
            /*string*/ static MatchesAllString = null;
            //--TRIMMABLE-BOUNDARY-END(231929413754)
            
            //--TRIMMABLE-BOUNDARY-START(343598563450)
            /*string*/ static QualityString = null;
            //--TRIMMABLE-BOUNDARY-END(343598563450)
            
            //--TRIMMABLE-BOUNDARY-START(429497909370)
            /*string*/ static WildcardString = null;
            //--TRIMMABLE-BOUNDARY-END(429497909370)
            
            //--TRIMMABLE-BOUNDARY-START(77310591098)
            /*char*/ static ForwardSlashCharacter = /*/*/ 47;
            //--TRIMMABLE-BOUNDARY-END(77310591098)
            
            //--TRIMMABLE-BOUNDARY-START(326418694266)
            /*char*/ static PeriodCharacter = /*.*/ 46;
            //--TRIMMABLE-BOUNDARY-END(326418694266)
            
            //--TRIMMABLE-BOUNDARY-START(335008628858)
            /*char*/ static PlusCharacter = /*+*/ 43;
            //--TRIMMABLE-BOUNDARY-END(335008628858)
            
            //--TRIMMABLE-BOUNDARY-START(330713661562)
            /*char[]*/ static PeriodCharacterArray = null;
            //--TRIMMABLE-BOUNDARY-END(330713661562)
            
            //--TRIMMABLE-BOUNDARY-START(390843203706)
            /*HttpHeaderParser<MediaTypeHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(390843203706)
            
            //--TRIMMABLE-BOUNDARY-START(304943857786)
            /*HttpHeaderParser<MediaTypeHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(304943857786)
            
            //--TRIMMABLE-BOUNDARY-START(12886081658)
            /*ObjectCollection<NameValueHeaderValue>?*/ _parameters = null;
            //--TRIMMABLE-BOUNDARY-END(12886081658)
            
            //--TRIMMABLE-BOUNDARY-START(8591114362)
            /*StringSegment*/ _mediaType;
            //--TRIMMABLE-BOUNDARY-END(8591114362)
            
            //--TRIMMABLE-BOUNDARY-START(4296147066)
            /*bool*/ _isReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(4296147066)
            
            //--TRIMMABLE-BOUNDARY-START(21476016250)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476016250);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016250)
            
            //--TRIMMABLE-BOUNDARY-START(30065950842)
            $ctor$3(/*StringSegment*/ mediaType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065950842);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.MNHH.MediaTypeHeaderValue.CheckMediaTypeFormat(mediaType, "mediaType");
                    this._mediaType = mediaType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065950842)
            
            //--TRIMMABLE-BOUNDARY-START(25770983546)
            $ctor$2(/*StringSegment*/ mediaType, /*double*/ quality)
            {
                this.$ctor$3(mediaType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770983546);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Quality = quality;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983546)
            
            //--TRIMMABLE-BOUNDARY-START(42950852730)
            /*StringSegment */ get Charset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490460282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2("charset"/*CharsetString*/))?.Value ?? null) ?? new $.$mep.MEP.StringSegment();
            }
            /*StringSegment */ set Charset(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778432634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                /*var*/ let charsetParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2("charset"/*CharsetString*/));
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(value))
                {
                    if (charsetParameter !== null)
                    {
                        this.Parameters.SCG$ICollection$$$Remove(charsetParameter);
                    }
                }
                else 
                {
                    if (charsetParameter !== null)
                    {
                        charsetParameter.Value = value;
                    }
                    else 
                    {
                        this.Parameters.SCG$ICollection$$$Add(new $.$mnhh.MNHH.NameValueHeaderValue().$ctor$2($.$mep.MEP.StringSegment.op_Implicit$2("charset"/*CharsetString*/), value));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950852730)
            
            //--TRIMMABLE-BOUNDARY-START(64425689210)
            /*Encoding? */ get Encoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080394874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let charset = this.Charset;
                if (charset.HasValue && !$.$mep.MEP.StringSegment.IsNullOrEmpty(charset))
                {
                    try
                    {
                        return $.$$.ST.Encoding.GetEncoding$3(charset.Value);
                    }
                    catch($e)
                    {
                    }
                }
                return null;
            }
            /*Encoding? */ set Encoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368367226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                if (value === null)
                {
                    this.Charset = $.$mep.MEP.StringSegment.op_Implicit$2(null);
                }
                else 
                {
                    this.Charset = $.$mep.MEP.StringSegment.op_Implicit$2(value.WebName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425689210)
            
            //--TRIMMABLE-BOUNDARY-START(34360918138)
            /*StringSegment */ get Boundary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900525690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/))?.Value ?? null) ?? $.$default($.$mep.MEP.StringSegment);
            }
            /*StringSegment */ set Boundary(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188498042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                /*var*/ let boundaryParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/));
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(value))
                {
                    if (boundaryParameter !== null)
                    {
                        this.Parameters.SCG$ICollection$$$Remove(boundaryParameter);
                    }
                }
                else 
                {
                    if (boundaryParameter !== null)
                    {
                        boundaryParameter.Value = value;
                    }
                    else 
                    {
                        this.Parameters.SCG$ICollection$$$Add(new $.$mnhh.MNHH.NameValueHeaderValue().$ctor$2($.$mep.MEP.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/), value));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360918138)
            
            //--TRIMMABLE-BOUNDARY-START(309238825082)
            /*IList<NameValueHeaderValue> */ get Parameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209937018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._parameters === null)
                {
                    if (this.IsReadOnly)
                    {
                        this._parameters = $.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.NameValueHeaderValue).EmptyReadOnlyCollection;
                    }
                    else 
                    {
                        this._parameters = new ($.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.NameValueHeaderValue))().$ctor$3();
                    }
                }
                return this._parameters;
            }
            //--TRIMMABLE-BOUNDARY-END(309238825082)
            
            //--TRIMMABLE-BOUNDARY-START(339303596154)
            /*double? */ get Quality()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799871610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.HeaderUtilities.GetQuality(this._parameters);
            }
            /*double? */ set Quality(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548236410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.MNHH.HeaderUtilities.SetQuality(this.Parameters, value);
            }
            //--TRIMMABLE-BOUNDARY-END(339303596154)
            
            //--TRIMMABLE-BOUNDARY-START(300648890490)
            /*StringSegment */ get MediaType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620002426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mediaType;
            }
            /*StringSegment */ set MediaType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958301818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.MNHH.MediaTypeHeaderValue.CheckMediaTypeFormat(value, "value");
                this._mediaType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(300648890490)
            
            //--TRIMMABLE-BOUNDARY-START(425202942074)
            /*StringSegment */ get Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159609978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mediaType.Subsegment(0, this._mediaType.IndexOf$2(/*/*/ 47));
            }
            //--TRIMMABLE-BOUNDARY-END(425202942074)
            
            //--TRIMMABLE-BOUNDARY-START(395138171002)
            /*StringSegment */ get SubType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389806202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mediaType.Subsegment$1(((this._mediaType.IndexOf$2(/*/*/ 47) + 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(395138171002)
            
            //--TRIMMABLE-BOUNDARY-START(399433138298)
            /*StringSegment */ get SubTypeWithoutSuffix()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979740794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let subType = this.SubType;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    return subType;
                }
                else 
                {
                    return subType.Subsegment(0, startOfSuffix);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(399433138298)
            
            //--TRIMMABLE-BOUNDARY-START(403728105594)
            /*StringSegment */ get Suffix()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569675386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let subType = this.SubType;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    return $.$default($.$mep.MEP.StringSegment);
                }
                else 
                {
                    return subType.Subsegment$1(((startOfSuffix + 1) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(403728105594)
            
            //--TRIMMABLE-BOUNDARY-START(73015623802)
            /*IEnumerable<StringSegment> */ get Facets()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670329466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubTypeWithoutSuffix.Split($.$mnhh.MNHH.MediaTypeHeaderValue.PeriodCharacterArray);
            }
            //--TRIMMABLE-BOUNDARY-END(73015623802)
            
            //--TRIMMABLE-BOUNDARY-START(244814315642)
            /*bool */ get MatchesAllTypes()
            {
                return this.MediaType.Equals$2("*/*"/*MatchesAllString*/, 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(244814315642)
            
            //--TRIMMABLE-BOUNDARY-START(236224381050)
            /*bool */ get MatchesAllSubTypes()
            {
                return this.SubType.Equals$2("*"/*WildcardString*/, 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(236224381050)
            
            //--TRIMMABLE-BOUNDARY-START(240519348346)
            /*bool */ get MatchesAllSubTypesWithoutSuffix()
            {
                return this.SubTypeWithoutSuffix.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(240519348346)
            
            //--TRIMMABLE-BOUNDARY-START(223339479162)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260264058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._isReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(223339479162)
            
            //--TRIMMABLE-BOUNDARY-START(227634446458)
            /*bool */ IsSubsetOf(/*MediaTypeHeaderValue*/ otherMediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634446458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (otherMediaType === null)
                {
                    return false;
                }
                return this.MatchesType$1(otherMediaType) && this.MatchesSubtype$1(otherMediaType) && this.MatchesParameters(otherMediaType);
            }
            //--TRIMMABLE-BOUNDARY-END(227634446458)
            
            //--TRIMMABLE-BOUNDARY-START(55835754618)
            /*MediaTypeHeaderValue */ Copy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835754618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = new $.$mnhh.MNHH.MediaTypeHeaderValue().$ctor$1();
                other._mediaType = this._mediaType;
                if (this._parameters !== null)
                {
                    other._parameters = new ($.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.NameValueHeaderValue))().$ctor$5($.$sl.SL.Enumerable.Select$1($.$mnhh.MNHH.NameValueHeaderValue, $.$mnhh.MNHH.NameValueHeaderValue, this._parameters, new ($.$$.S.Func$$$($.$mnhh.MNHH.NameValueHeaderValue, $.$mnhh.MNHH.NameValueHeaderValue))().$ctor(this,  (/*item*/ item) =>
                    {
                        return item.Copy();
                    }, $JfRFqg ??= {"r":1310842,"p":[{"n":"item","p":1310842}],"n":"","d":1179770,"h":0,"f":17825794})), false);
                }
                return other;
            }
            //--TRIMMABLE-BOUNDARY-END(55835754618)
            
            //--TRIMMABLE-BOUNDARY-START(60130721914)
            /*MediaTypeHeaderValue */ CopyAsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130721914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    return this;
                }
                /*var*/ let other = new $.$mnhh.MNHH.MediaTypeHeaderValue().$ctor$1();
                other._mediaType = this._mediaType;
                if (this._parameters !== null)
                {
                    other._parameters = new ($.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.NameValueHeaderValue))().$ctor$5($.$sl.SL.Enumerable.Select$1($.$mnhh.MNHH.NameValueHeaderValue, $.$mnhh.MNHH.NameValueHeaderValue, this._parameters, new ($.$$.S.Func$$$($.$mnhh.MNHH.NameValueHeaderValue, $.$mnhh.MNHH.NameValueHeaderValue))().$ctor(this,  (/*item*/ item) =>
                    {
                        return item.CopyAsReadOnly();
                    }, $YfSlhc ??= {"r":1310842,"p":[{"n":"item","p":1310842}],"n":"","d":1179770,"h":0,"f":17825794})), true);
                }
                other._isReadOnly = true;
                return other;
            }
            //--TRIMMABLE-BOUNDARY-END(60130721914)
            
            //--TRIMMABLE-BOUNDARY-START(257699217530)
            /*bool */ MatchesMediaType(/*StringSegment*/ otherMediaType)
            {
                /*var*/ let mediaType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699217530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(otherMediaType))
                {
                    return false;
                }
                $.$mnhh.MNHH.MediaTypeHeaderValue.GetMediaTypeExpressionLength(otherMediaType, 0, $.$ref(() => mediaType, ($v) => mediaType = $v, $.$mep.MEP.StringSegment));
                return this.MatchesType(mediaType) && this.MatchesSubtype(mediaType);
            }
            //--TRIMMABLE-BOUNDARY-END(257699217530)
            
            //--TRIMMABLE-BOUNDARY-START(408023072890)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023072890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$$.ST.StringBuilder().$ctor$1();
                builder.Append$17(this._mediaType.AsSpan());
                $.$mnhh.MNHH.NameValueHeaderValue.ToString$1(this._parameters, /*;*/ 59, true, builder);
                return builder.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(408023072890)
            
            //--TRIMMABLE-BOUNDARY-START(68720656506)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720656506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.MediaTypeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return this._mediaType.Equals$4(other._mediaType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.MNHH.HeaderUtilities.AreEqualCollections$1($.$mnhh.MNHH.NameValueHeaderValue, this._parameters, other._parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(68720656506)
            
            //--TRIMMABLE-BOUNDARY-START(210454577274)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454577274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._mediaType) ^ $.$mnhh.MNHH.NameValueHeaderValue.GetHashCode$1(this._parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(210454577274)
            
            //--TRIMMABLE-BOUNDARY-START(313533792378)
            static /*MediaTypeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533792378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.MediaTypeHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(313533792378)
            
            //--TRIMMABLE-BOUNDARY-START(412318040186)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out MediaTypeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318040186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.MediaTypeHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(412318040186)
            
            //--TRIMMABLE-BOUNDARY-START(317828759674)
            static /*IList<MediaTypeHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828759674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.MediaTypeHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(317828759674)
            
            //--TRIMMABLE-BOUNDARY-START(322123726970)
            static /*IList<MediaTypeHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123726970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.MediaTypeHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(322123726970)
            
            //--TRIMMABLE-BOUNDARY-START(416613007482)
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<MediaTypeHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613007482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.MediaTypeHeaderValue.MultipleValueParser.TryParseValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(416613007482)
            
            //--TRIMMABLE-BOUNDARY-START(420907974778)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<MediaTypeHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907974778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.MediaTypeHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(420907974778)
            
            //--TRIMMABLE-BOUNDARY-START(219044511866)
            static /*int */ GetMediaTypeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out MediaTypeHeaderValue?*/ parsedValue)
            {
                /*var*/ let mediaType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044511866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let mediaTypeLength = $.$mnhh.MNHH.MediaTypeHeaderValue.GetMediaTypeExpressionLength(input, startIndex, $.$ref(() => mediaType, ($v) => mediaType = $v, $.$mep.MEP.StringSegment));
                if (mediaTypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + mediaTypeLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*MediaTypeHeaderValue?*/ let mediaTypeHeader;
                if ((current < input.Length) && (input.get_Item$1(current) === /*;*/ 59))
                {
                    mediaTypeHeader = new $.$mnhh.MNHH.MediaTypeHeaderValue().$ctor$1();
                    mediaTypeHeader._mediaType = mediaType;
                    current++;
                    /*var*/ let parameterLength = $.$mnhh.MNHH.NameValueHeaderValue.GetNameValueListLength(input, current, /*;*/ 59, mediaTypeHeader.Parameters);
                    parsedValue.$v = mediaTypeHeader;
                    return ((((current + parameterLength) | 0) - startIndex) | 0);
                }
                mediaTypeHeader = new $.$mnhh.MNHH.MediaTypeHeaderValue().$ctor$1();
                mediaTypeHeader._mediaType = mediaType;
                parsedValue.$v = mediaTypeHeader;
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(219044511866)
            
            //--TRIMMABLE-BOUNDARY-START(214749544570)
            static /*int */ GetMediaTypeExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringSegment*/ mediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749544570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                mediaType.$v = $.$mep.MEP.StringSegment.op_Implicit$2(null);
                /*var*/ let typeLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, startIndex);
                if (typeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + typeLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current >= input.Length) || (input.get_Item$1(current) !== /*/*/ 47))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let subtypeLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, current);
                if (subtypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let mediaTypeLength = ((((current + subtypeLength) | 0) - startIndex) | 0);
                if (((((typeLength + subtypeLength) | 0) + 1) | 0) === mediaTypeLength)
                {
                    mediaType.$v = input.Subsegment(startIndex, mediaTypeLength);
                }
                else 
                {
                    mediaType.$v = $.$mep.MEP.StringSegment.op_Implicit$2($.$$.S.String.Concat$7(input.AsSpan().Slice(startIndex, typeLength), $.$$.S.String.op_Implicit("/"), input.AsSpan().Slice(current, subtypeLength)));
                }
                return mediaTypeLength;
            }
            //--TRIMMABLE-BOUNDARY-END(214749544570)
            
            //--TRIMMABLE-BOUNDARY-START(51540787322)
            static /*void */ CheckMediaTypeFormat(/*StringSegment*/ mediaType, /*string*/ parameterName)
            {
                /*var*/ let tempMediaType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540787322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(mediaType))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                /*var*/ let mediaTypeLength = $.$mnhh.MNHH.MediaTypeHeaderValue.GetMediaTypeExpressionLength(mediaType, 0, $.$ref(() => tempMediaType, ($v) => tempMediaType = $v, $.$mep.MEP.StringSegment));
                if ((mediaTypeLength === 0) || (tempMediaType.Length !== mediaType.Length))
                {
                    throw new $.$$.S.FormatException().$ctor$12($.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, "Invalid media type '{0}'.", mediaType));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540787322)
            
            //--TRIMMABLE-BOUNDARY-START(296353923194)
            /*bool */ MatchesType$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353923194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return set.MatchesAllTypes || set.Type.Equals$4(this.Type, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(296353923194)
            
            //--TRIMMABLE-BOUNDARY-START(292058955898)
            /*bool */ MatchesType(/*StringSegment*/ mediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058955898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = mediaType.Subsegment(0, mediaType.IndexOf$2(/*/*/ 47));
                return this.MatchesAllTypes || this.Type.Equals$4(type, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(292058955898)
            
            //--TRIMMABLE-BOUNDARY-START(270584119418)
            /*bool */ MatchesSubtype$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584119418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (set.MatchesAllSubTypes)
                {
                    return true;
                }
                if (set.Suffix.HasValue)
                {
                    if (this.Suffix.HasValue)
                    {
                        return this.MatchesSubtypeWithoutSuffix$1(set) && this.MatchesSubtypeSuffix$1(set);
                    }
                    else 
                    {
                        return false;
                    }
                }
                else 
                {
                    return this.MatchesEitherSubtypeOrSuffix$1(set);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270584119418)
            
            //--TRIMMABLE-BOUNDARY-START(266289152122)
            /*bool */ MatchesSubtype(/*StringSegment*/ mediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289152122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.MatchesAllSubTypes)
                {
                    return true;
                }
                /*var*/ let subType = mediaType.Subsegment$1(((mediaType.IndexOf$2(/*/*/ 47) + 1) | 0));
                /*StringSegment*/ let suffix;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    suffix = $.$default($.$mep.MEP.StringSegment);
                }
                else 
                {
                    suffix = subType.Subsegment$1(((startOfSuffix + 1) | 0));
                }
                if (this.Suffix.HasValue)
                {
                    if (suffix.HasValue)
                    {
                        return this.MatchesSubtypeWithoutSuffix(subType, startOfSuffix) && this.MatchesSubtypeSuffix(suffix);
                    }
                    else 
                    {
                        return false;
                    }
                }
                else 
                {
                    return this.MatchesEitherSubtypeOrSuffix(subType, suffix);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266289152122)
            
            //--TRIMMABLE-BOUNDARY-START(287763988602)
            /*bool */ MatchesSubtypeWithoutSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763988602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return set.MatchesAllSubTypesWithoutSuffix || set.SubTypeWithoutSuffix.Equals$4(this.SubTypeWithoutSuffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(287763988602)
            
            //--TRIMMABLE-BOUNDARY-START(283469021306)
            /*bool */ MatchesSubtypeWithoutSuffix(/*StringSegment*/ subType, /*int*/ startOfSuffix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469021306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StringSegment*/ let subTypeWithoutSuffix;
                if (startOfSuffix === -1)
                {
                    subTypeWithoutSuffix = subType;
                }
                else 
                {
                    subTypeWithoutSuffix = subType.Subsegment(0, startOfSuffix);
                }
                return this.SubTypeWithoutSuffix.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/) || this.SubTypeWithoutSuffix.Equals$4(subTypeWithoutSuffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(283469021306)
            
            //--TRIMMABLE-BOUNDARY-START(253404250234)
            /*bool */ MatchesEitherSubtypeOrSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404250234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return set.SubType.Equals$4(this.SubType, 5/*StringComparison.OrdinalIgnoreCase*/) || set.SubType.Equals$4(this.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(253404250234)
            
            //--TRIMMABLE-BOUNDARY-START(249109282938)
            /*bool */ MatchesEitherSubtypeOrSuffix(/*StringSegment*/ subType, /*StringSegment*/ suffix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109282938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return subType.Equals$4(this.SubType, 5/*StringComparison.OrdinalIgnoreCase*/) || this.SubType.Equals$4(suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(249109282938)
            
            //--TRIMMABLE-BOUNDARY-START(261994184826)
            /*bool */ MatchesParameters(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994184826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (set._parameters !== null && set._parameters.Count !== 0)
                {
                    let $en9 = set._parameters.GetEnumerator();
                    while ($en9.SC$1$IEnumerator$MoveNext())
                    {
                        let parameter = $en9.SCG$IEnumerator$$$Current;
                        {
                            if (parameter.Name.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                continue;
                            }
                            if (parameter.Name.Equals$2("q"/*QualityString*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                break;
                            }
                            /*var*/ let localParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, parameter.Name);
                            if (localParameter === null)
                            {
                                return false;
                            }
                            if (!$.$mep.MEP.StringSegment.Equals$5(parameter.Value, localParameter.Value, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(261994184826)
            
            //--TRIMMABLE-BOUNDARY-START(279174054010)
            /*bool */ MatchesSubtypeSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174054010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return set.Suffix.Equals$4(this.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(279174054010)
            
            //--TRIMMABLE-BOUNDARY-START(274879086714)
            /*bool */ MatchesSubtypeSuffix(/*StringSegment*/ suffix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879086714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Suffix.Equals$4(suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(274879086714)
            
            //--TRIMMABLE-BOUNDARY-START(21476016250)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476016250)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591114362)
                this._mediaType = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591114362)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17181048954)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(38655885434)
                    this.BoundaryString = "boundary";
                    //--TRIMMABLE-BOUNDARY-END(38655885434)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245820026)
                    this.CharsetString = "charset";
                    //--TRIMMABLE-BOUNDARY-END(47245820026)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929413754)
                    this.MatchesAllString = "*/*";
                    //--TRIMMABLE-BOUNDARY-END(231929413754)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598563450)
                    this.QualityString = "q";
                    //--TRIMMABLE-BOUNDARY-END(343598563450)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429497909370)
                    this.WildcardString = "*";
                    //--TRIMMABLE-BOUNDARY-END(429497909370)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713661562)
                    this.PeriodCharacterArray = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.Char.$type, [ /*.*/ 46 ], null, null);
                    //--TRIMMABLE-BOUNDARY-END(330713661562)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390843203706)
                    this.SingleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.MediaTypeHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.MediaTypeHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.MediaTypeHeaderValue, $.$mnhh.MNHH.MediaTypeHeaderValue.GetMediaTypeLength));
                    //--TRIMMABLE-BOUNDARY-END(390843203706)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943857786)
                    this.MultipleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.MediaTypeHeaderValue))().$ctor$3(true, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.MediaTypeHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.MediaTypeHeaderValue, $.$mnhh.MNHH.MediaTypeHeaderValue.GetMediaTypeLength));
                    //--TRIMMABLE-BOUNDARY-END(304943857786)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181048954)
            
            static $h = 1179770;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950852730),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490460282,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360778432634,
        "f": 83886081
      },
      "n": "Charset",
      "d": 1179770,
      "h": 42950852730,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950852730),
//--TRIMMABLE-BOUNDARY-START(64425689210),
    {
      "p": 166723585,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080394874,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369368367226,
        "f": 83886081
      },
      "n": "Encoding",
      "d": 1179770,
      "h": 64425689210,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425689210),
//--TRIMMABLE-BOUNDARY-START(34360918138),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900525690,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352188498042,
        "f": 83886081
      },
      "n": "Boundary",
      "d": 1179770,
      "h": 34360918138,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360918138),
//--TRIMMABLE-BOUNDARY-START(309238825082),
    {
      "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209937018,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 1179770,
      "h": 309238825082,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309238825082),
//--TRIMMABLE-BOUNDARY-START(339303596154),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799871610,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386548236410,
        "f": 83886081
      },
      "n": "Quality",
      "d": 1179770,
      "h": 339303596154,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339303596154),
//--TRIMMABLE-BOUNDARY-START(300648890490),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620002426,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377958301818,
        "f": 83886081
      },
      "n": "MediaType",
      "d": 1179770,
      "h": 300648890490,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300648890490),
//--TRIMMABLE-BOUNDARY-START(425202942074),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159609978,
        "f": 50331649
      },
      "n": "Type",
      "d": 1179770,
      "h": 425202942074,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(425202942074),
//--TRIMMABLE-BOUNDARY-START(395138171002),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389806202,
        "f": 50331649
      },
      "n": "SubType",
      "d": 1179770,
      "h": 395138171002,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(395138171002),
//--TRIMMABLE-BOUNDARY-START(399433138298),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979740794,
        "f": 50331649
      },
      "n": "SubTypeWithoutSuffix",
      "d": 1179770,
      "h": 399433138298,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399433138298),
//--TRIMMABLE-BOUNDARY-START(403728105594),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569675386,
        "f": 50331649
      },
      "n": "Suffix",
      "d": 1179770,
      "h": 403728105594,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403728105594),
//--TRIMMABLE-BOUNDARY-START(73015623802),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mep.MEP.StringSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670329466,
        "f": 50331649
      },
      "n": "Facets",
      "d": 1179770,
      "h": 73015623802,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015623802),
//--TRIMMABLE-BOUNDARY-START(244814315642),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030067834,
        "f": 50331649
      },
      "n": "MatchesAllTypes",
      "d": 1179770,
      "h": 244814315642,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244814315642),
//--TRIMMABLE-BOUNDARY-START(236224381050),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850198650,
        "f": 50331649
      },
      "n": "MatchesAllSubTypes",
      "d": 1179770,
      "h": 236224381050,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224381050),
//--TRIMMABLE-BOUNDARY-START(240519348346),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440133242,
        "f": 50331649
      },
      "n": "MatchesAllSubTypesWithoutSuffix",
      "d": 1179770,
      "h": 240519348346,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519348346),
//--TRIMMABLE-BOUNDARY-START(223339479162),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260264058,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1179770,
      "h": 223339479162,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223339479162)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(227634446458),
    {
      "r": 262145,
      "p": [
        {
          "n": "otherMediaType",
          "p": 1179770
        }
      ],
      "n": "IsSubsetOf",
      "d": 1179770,
      "h": 227634446458,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227634446458),
//--TRIMMABLE-BOUNDARY-START(55835754618),
    {
      "r": 1179770,
      "n": "Copy",
      "d": 1179770,
      "h": 55835754618,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835754618),
//--TRIMMABLE-BOUNDARY-START(60130721914),
    {
      "r": 1179770,
      "n": "CopyAsReadOnly",
      "d": 1179770,
      "h": 60130721914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130721914),
//--TRIMMABLE-BOUNDARY-START(257699217530),
    {
      "r": 262145,
      "p": [
        {
          "n": "otherMediaType",
          "p": 852053
        }
      ],
      "n": "MatchesMediaType",
      "d": 1179770,
      "h": 257699217530,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257699217530),
//--TRIMMABLE-BOUNDARY-START(408023072890),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1179770,
      "h": 408023072890,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(408023072890),
//--TRIMMABLE-BOUNDARY-START(68720656506),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1179770,
      "h": 68720656506,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720656506),
//--TRIMMABLE-BOUNDARY-START(210454577274),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1179770,
      "h": 210454577274,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(210454577274),
//--TRIMMABLE-BOUNDARY-START(313533792378),
    {
      "r": 1179770,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1179770,
      "h": 313533792378,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313533792378),
//--TRIMMABLE-BOUNDARY-START(412318040186),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1179770,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1179770,
      "h": 412318040186,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(412318040186),
//--TRIMMABLE-BOUNDARY-START(317828759674),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.MediaTypeHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseList",
      "d": 1179770,
      "h": 317828759674,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(317828759674),
//--TRIMMABLE-BOUNDARY-START(322123726970),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.MediaTypeHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 1179770,
      "h": 322123726970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(322123726970),
//--TRIMMABLE-BOUNDARY-START(416613007482),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.MediaTypeHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 1179770,
      "h": 416613007482,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(416613007482),
//--TRIMMABLE-BOUNDARY-START(420907974778),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.MediaTypeHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 1179770,
      "h": 420907974778,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(420907974778),
//--TRIMMABLE-BOUNDARY-START(219044511866),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1179770,
          "f": 2
        }
      ],
      "n": "GetMediaTypeLength",
      "d": 1179770,
      "h": 219044511866,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(219044511866),
//--TRIMMABLE-BOUNDARY-START(214749544570),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "mediaType",
          "p": 852053,
          "f": 2
        }
      ],
      "n": "GetMediaTypeExpressionLength",
      "d": 1179770,
      "h": 214749544570,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(214749544570),
//--TRIMMABLE-BOUNDARY-START(51540787322),
    {
      "r": 65537,
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckMediaTypeFormat",
      "d": 1179770,
      "h": 51540787322,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51540787322),
//--TRIMMABLE-BOUNDARY-START(296353923194),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179770
        }
      ],
      "n": "MatchesType",
      "o": "@$1",
      "d": 1179770,
      "h": 296353923194,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(296353923194),
//--TRIMMABLE-BOUNDARY-START(292058955898),
    {
      "r": 262145,
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        }
      ],
      "n": "MatchesType",
      "d": 1179770,
      "h": 292058955898,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(292058955898),
//--TRIMMABLE-BOUNDARY-START(270584119418),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179770
        }
      ],
      "n": "MatchesSubtype",
      "o": "@$1",
      "d": 1179770,
      "h": 270584119418,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(270584119418),
//--TRIMMABLE-BOUNDARY-START(266289152122),
    {
      "r": 262145,
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        }
      ],
      "n": "MatchesSubtype",
      "d": 1179770,
      "h": 266289152122,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(266289152122),
//--TRIMMABLE-BOUNDARY-START(287763988602),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179770
        }
      ],
      "n": "MatchesSubtypeWithoutSuffix",
      "o": "@$1",
      "d": 1179770,
      "h": 287763988602,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(287763988602),
//--TRIMMABLE-BOUNDARY-START(283469021306),
    {
      "r": 262145,
      "p": [
        {
          "n": "subType",
          "p": 852053
        },
        {
          "n": "startOfSuffix",
          "p": 655361
        }
      ],
      "n": "MatchesSubtypeWithoutSuffix",
      "d": 1179770,
      "h": 283469021306,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283469021306),
//--TRIMMABLE-BOUNDARY-START(253404250234),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179770
        }
      ],
      "n": "MatchesEitherSubtypeOrSuffix",
      "o": "@$1",
      "d": 1179770,
      "h": 253404250234,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253404250234),
//--TRIMMABLE-BOUNDARY-START(249109282938),
    {
      "r": 262145,
      "p": [
        {
          "n": "subType",
          "p": 852053
        },
        {
          "n": "suffix",
          "p": 852053
        }
      ],
      "n": "MatchesEitherSubtypeOrSuffix",
      "d": 1179770,
      "h": 249109282938,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249109282938),
//--TRIMMABLE-BOUNDARY-START(261994184826),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179770
        }
      ],
      "n": "MatchesParameters",
      "d": 1179770,
      "h": 261994184826,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261994184826),
//--TRIMMABLE-BOUNDARY-START(279174054010),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179770
        }
      ],
      "n": "MatchesSubtypeSuffix",
      "o": "@$1",
      "d": 1179770,
      "h": 279174054010,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279174054010),
//--TRIMMABLE-BOUNDARY-START(274879086714),
    {
      "r": 262145,
      "p": [
        {
          "n": "suffix",
          "p": 852053
        }
      ],
      "n": "MatchesSubtypeSuffix",
      "d": 1179770,
      "h": 274879086714,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(274879086714)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655885434),
    {
      "t": 1310721,
      "n": "BoundaryString",
      "d": 1179770,
      "h": 38655885434,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655885434),
//--TRIMMABLE-BOUNDARY-START(47245820026),
    {
      "t": 1310721,
      "n": "CharsetString",
      "d": 1179770,
      "h": 47245820026,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245820026),
//--TRIMMABLE-BOUNDARY-START(231929413754),
    {
      "t": 1310721,
      "n": "MatchesAllString",
      "d": 1179770,
      "h": 231929413754,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(231929413754),
//--TRIMMABLE-BOUNDARY-START(343598563450),
    {
      "t": 1310721,
      "n": "QualityString",
      "d": 1179770,
      "h": 343598563450,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(343598563450),
//--TRIMMABLE-BOUNDARY-START(429497909370),
    {
      "t": 1310721,
      "n": "WildcardString",
      "d": 1179770,
      "h": 429497909370,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(429497909370),
//--TRIMMABLE-BOUNDARY-START(77310591098),
    {
      "t": 458753,
      "n": "ForwardSlashCharacter",
      "d": 1179770,
      "h": 77310591098,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310591098),
//--TRIMMABLE-BOUNDARY-START(326418694266),
    {
      "t": 458753,
      "n": "PeriodCharacter",
      "d": 1179770,
      "h": 326418694266,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(326418694266),
//--TRIMMABLE-BOUNDARY-START(335008628858),
    {
      "t": 458753,
      "n": "PlusCharacter",
      "d": 1179770,
      "h": 335008628858,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(335008628858),
//--TRIMMABLE-BOUNDARY-START(330713661562),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "PeriodCharacterArray",
      "d": 1179770,
      "h": 330713661562,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(330713661562),
//--TRIMMABLE-BOUNDARY-START(390843203706),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.MediaTypeHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 1179770,
      "h": 390843203706,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(390843203706),
//--TRIMMABLE-BOUNDARY-START(304943857786),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.MediaTypeHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 1179770,
      "h": 304943857786,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(304943857786),
//--TRIMMABLE-BOUNDARY-START(12886081658),
    {
      "t": $.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "n": "_parameters",
      "d": 1179770,
      "h": 12886081658,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081658),
//--TRIMMABLE-BOUNDARY-START(8591114362),
    {
      "t": 852053,
      "n": "_mediaType",
      "d": 1179770,
      "h": 8591114362,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114362),
//--TRIMMABLE-BOUNDARY-START(4296147066),
    {
      "t": 262145,
      "n": "_isReadOnly",
      "d": 1179770,
      "h": 4296147066,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147066)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476016250),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179770,
      "h": 21476016250,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476016250),
//--TRIMMABLE-BOUNDARY-START(30065950842),
    {
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179770,
      "h": 30065950842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065950842),
//--TRIMMABLE-BOUNDARY-START(25770983546),
    {
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        },
        {
          "n": "quality",
          "p": 1179649
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179770,
      "h": 25770983546,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770983546)
  ],
  "h": 1179770
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.MediaTypeHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}MediaTypeHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179770)
        
        

        //--TRIMMABLE-BOUNDARY-START(917626)
        $asm.$cls(`$mnhh.MNHH.HeaderUtilities`, ($self) => class HeaderUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(4295884922)
            /*int*/ static _qualityValueMaxCharCount = 10;
            //--TRIMMABLE-BOUNDARY-END(4295884922)
            
            //--TRIMMABLE-BOUNDARY-START(77310328954)
            /*string*/ static QualityName = null;
            //--TRIMMABLE-BOUNDARY-END(77310328954)
            
            //--TRIMMABLE-BOUNDARY-START(21475754106)
            /*string*/ static BytesUnit = null;
            //--TRIMMABLE-BOUNDARY-END(21475754106)
            
            //--TRIMMABLE-BOUNDARY-START(85900263546)
            static /*void */ SetQuality(/*IList<NameValueHeaderValue>*/ parameters, /*double?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900263546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let qualityParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(parameters, $.$mep.MEP.StringSegment.op_Implicit$2("q"/*QualityName*/));
                if ($.$$.S.Nullable$$($.$$.S.Double).HasValue$get.call(value))
                {
                    if (($.$$.S.Double.op_LessThan(value, 0)) || ($.$$.S.Double.op_GreaterThan(value, 1)))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("value");
                    }
                    /*var*/ let qualityString = $.$$.S.Double.ToString$2.call(($.$cast(value, $.$$.S.Double)), "0.0##", $.$$.SG.NumberFormatInfo.InvariantInfo);
                    if (qualityParameter !== null)
                    {
                        qualityParameter.Value = $.$mep.MEP.StringSegment.op_Implicit$2(qualityString);
                    }
                    else 
                    {
                        parameters.SCG$ICollection$$$Add(new $.$mnhh.MNHH.NameValueHeaderValue().$ctor$2($.$mep.MEP.StringSegment.op_Implicit$2("q"/*QualityName*/), $.$mep.MEP.StringSegment.op_Implicit$2(qualityString)));
                    }
                }
                else 
                {
                    if (qualityParameter !== null)
                    {
                        parameters.SCG$ICollection$$$Remove(qualityParameter);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900263546)
            
            //--TRIMMABLE-BOUNDARY-START(68720394362)
            static /*double? */ GetQuality(/*IList<NameValueHeaderValue>?*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720394362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let qualityParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(parameters, $.$mep.MEP.StringSegment.op_Implicit$2("q"/*QualityName*/));
                if (qualityParameter !== null)
                {
                    /*var*/ let qualityValue;
                    if ($.$mnhh.MNHH.HeaderUtilities.TryParseQualityDouble(qualityParameter.Value, 0, $.$ref(() => qualityValue, ($v) => qualityValue = $v, $.$$.S.Double), $.$discardRef()))
                    {
                        return qualityValue;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(68720394362)
            
            //--TRIMMABLE-BOUNDARY-START(25770721402)
            static /*void */ CheckValidToken(/*StringSegment*/ value, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(value))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                if ($.$mnhh.MNHH.HttpRuleParser.GetTokenLength(value, 0) !== value.Length)
                {
                    throw new $.$$.S.FormatException().$ctor$12($.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, "Invalid token '{0}'.", value));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721402)
            
            //--TRIMMABLE-BOUNDARY-START(17180786810)
            static /*bool */ AreEqualCollections$1(T, /*ICollection<T>?*/ x, /*ICollection<T>?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180786810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.HeaderUtilities.AreEqualCollections(T, x, y, null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180786810)
            
            //--TRIMMABLE-BOUNDARY-START(12885819514)
            static /*bool */ AreEqualCollections(T, /*ICollection<T>?*/ x, /*ICollection<T>?*/ y, /*IEqualityComparer<T>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (x === null)
                {
                    return (y === null) || (y.SCG$ICollection$$$Count === 0);
                }
                if (y === null)
                {
                    return (x.SCG$ICollection$$$Count === 0);
                }
                if (x.SCG$ICollection$$$Count !== y.SCG$ICollection$$$Count)
                {
                    return false;
                }
                if (x.SCG$ICollection$$$Count === 0)
                {
                    return true;
                }
                /*var*/ let alreadyFound = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Boolean), null, [x.SCG$ICollection$$$Count], null);
                /*var*/ let i = 0;
                let $en2 = x.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let xItem = $en2.SCG$IEnumerator$$$Current;
                    {
                        $.$$.SDC$1.Contract.Assert$1(xItem !== null);
                        i = 0;
                        /*var*/ let found = false;
                        let $en3 = y.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let yItem = $en3.SCG$IEnumerator$$$Current;
                            {
                                if (!$.$$.System.Array.$ReadT1.call(alreadyFound, i))
                                {
                                    if (((comparer === null) && $.$dspc(xItem, T, ($t) => $t.Equals$1, $.$box(yItem, T))) || ((comparer !== null) && comparer[`SCG$IEqualityComparer$${T.$getFullName('$')}$Equals`](xItem, yItem)))
                                    {
                                        $.$$.System.Array.$WriteT1.call(alreadyFound, true, i);
                                        found = true;
                                        break;
                                    }
                                }
                                i++;
                            }
                        }
                        if (!found)
                        {
                            return false;
                        }
                    }
                }
                $.$$.SDC$1.Contract.Assert($.$$.SDC$1.Contract.ForAll$1($.$$.S.Boolean, alreadyFound, new ($.$$.S.Predicate$$($.$$.S.Boolean))().$ctor(this,  (/*value*/ value) =>
                {
                    return value;
                }, $JUdwib ??= {"r":262145,"p":[{"n":"value","p":262145}],"n":"","d":917626,"h":0,"f":17825794})), "Expected all values in 'alreadyFound' to be true since collections are considered equal.");
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819514)
            
            //--TRIMMABLE-BOUNDARY-START(64425427066)
            static /*int */ GetNextNonEmptyOrWhitespaceIndex(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ skipEmptyValues, /*out bool*/ separatorFound)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425427066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                separatorFound.$v = false;
                /*var*/ let current = ((startIndex + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                if ((current === input.Length) || (input.get_Item$1(current) !== /*,*/ 44))
                {
                    return current;
                }
                separatorFound.$v = true;
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (skipEmptyValues)
                {
                    while((current < input.Length) && (input.get_Item$1(current) === /*,*/ 44))
                    {
                        current++;
                        current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                }
                return current;
            }
            //--TRIMMABLE-BOUNDARY-END(64425427066)
            
            //--TRIMMABLE-BOUNDARY-START(8590852218)
            static /*int */ AdvanceCacheDirectiveIndex(/*int*/ current, /*string*/ headerValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                current += $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength($.$mep.MEP.StringSegment.op_Implicit$2(headerValue), current);
                if (current < headerValue.length && $.$$.S.String.get_Chars.call(headerValue, current) === /*=*/ 61)
                {
                    current++;
                    current += $.$mnhh.MNHH.NameValueHeaderValue.GetValueLength($.$mep.MEP.StringSegment.op_Implicit$2(headerValue), current);
                }
                current = $.$$.S.String.IndexOf$1.call(headerValue, /*,*/ 44, current);
                if (current === -1)
                {
                    return headerValue.length;
                }
                current++;
                current += $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength($.$mep.MEP.StringSegment.op_Implicit$2(headerValue), current);
                return current;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852218)
            
            //--TRIMMABLE-BOUNDARY-START(115965034618)
            static /*bool */ TryParseSeconds(/*StringValues*/ headerValues, /*string*/ targetValue, /*out TimeSpan?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965034618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringValues.IsNullOrEmpty(headerValues) || $.$$.S.String.IsNullOrEmpty(targetValue))
                {
                    value.$v = null;
                    return false;
                }
                for(/*var*/ let i = 0; i < headerValues.Count; i++)
                {
                    /*var*/ let segment = headerValues.get_Item$1(i) ?? $.$$.S.String.Empty;
                    /*var*/ let current = $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength($.$mep.MEP.StringSegment.op_Implicit$2(segment), 0);
                    while(current < segment.length)
                    {
                        /*long*/ let seconds;
                        /*var*/ let initial = current;
                        /*var*/ let tokenLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength($.$mep.MEP.StringSegment.op_Implicit$2(headerValues.get_Item$1(i)), current);
                        if (tokenLength === targetValue.length && $.$$.S.String.Compare$3(headerValues.get_Item$1(i), current, targetValue, 0, tokenLength, 5/*StringComparison.OrdinalIgnoreCase*/) === 0 && $.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64FromHeaderValue(((current + tokenLength) | 0), segment, $.$ref(() => seconds, ($v) => seconds = $v, $.$$.S.Int64)))
                        {
                            value.$v = $.$$.S.TimeSpan.FromSeconds$2(seconds);
                            return true;
                        }
                        current = $.$mnhh.MNHH.HeaderUtilities.AdvanceCacheDirectiveIndex(((current + tokenLength) | 0), segment);
                        if (current <= initial)
                        {
                            $.$$.SD.Debug.Assert$4(false, `Index '${$.$strNN("current")}' not advanced, this is a bug.`);
                            value.$v = null;
                            return false;
                        }
                    }
                }
                value.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(115965034618)
            
            //--TRIMMABLE-BOUNDARY-START(30065688698)
            static /*bool */ ContainsCacheDirective(/*StringValues*/ cacheControlDirectives, /*string*/ targetDirectives)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065688698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringValues.IsNullOrEmpty(cacheControlDirectives) || $.$$.S.String.IsNullOrEmpty(targetDirectives))
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < cacheControlDirectives.Count; i++)
                {
                    /*var*/ let segment = cacheControlDirectives.get_Item$1(i) ?? $.$$.S.String.Empty;
                    /*var*/ let current = $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength($.$mep.MEP.StringSegment.op_Implicit$2(segment), 0);
                    while(current < segment.length)
                    {
                        /*var*/ let initial = current;
                        /*var*/ let tokenLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength($.$mep.MEP.StringSegment.op_Implicit$2(segment), current);
                        if (tokenLength === targetDirectives.length && $.$$.S.String.Compare$3(segment, current, targetDirectives, 0, tokenLength, 5/*StringComparison.OrdinalIgnoreCase*/) === 0)
                        {
                            return true;
                        }
                        current = $.$mnhh.MNHH.HeaderUtilities.AdvanceCacheDirectiveIndex(((current + tokenLength) | 0), segment);
                        if (current <= initial)
                        {
                            $.$$.SD.Debug.Assert$4(false, `Index '${$.$strNN("current")}' not advanced, this is a bug.`);
                            return false;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30065688698)
            
            //--TRIMMABLE-BOUNDARY-START(107375100026)
            static /*bool */ TryParseNonNegativeInt64FromHeaderValue(/*int*/ startIndex, /*string*/ headerValue, /*out long*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375100026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                startIndex += $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength($.$mep.MEP.StringSegment.op_Implicit$2(headerValue), startIndex);
                if (startIndex >= ((headerValue.length - 1) | 0) || $.$$.S.String.get_Chars.call(headerValue, startIndex) !== /*=*/ 61)
                {
                    result.$v = 0n;
                    return false;
                }
                startIndex++;
                startIndex += $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength($.$mep.MEP.StringSegment.op_Implicit$2(headerValue), startIndex);
                if ($.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64(new $.$mep.MEP.StringSegment().$ctor$3(headerValue, startIndex, $.$mnhh.MNHH.HttpRuleParser.GetNumberLength($.$mep.MEP.StringSegment.op_Implicit$2(headerValue), startIndex, false)), result))
                {
                    return true;
                }
                result.$v = 0n;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(107375100026)
            
            //--TRIMMABLE-BOUNDARY-START(98785165434)
            static /*bool */ TryParseNonNegativeInt32(/*StringSegment*/ value, /*out int*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785165434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(value.Buffer) || value.Length === 0)
                {
                    result.$v = 0;
                    return false;
                }
                return $.$$.S.Int32.TryParse$4(value.AsSpan(), 0/*NumberStyles.None*/, $.$$.SG.NumberFormatInfo.InvariantInfo, result);
            }
            //--TRIMMABLE-BOUNDARY-END(98785165434)
            
            //--TRIMMABLE-BOUNDARY-START(103080132730)
            static /*bool */ TryParseNonNegativeInt64(/*StringSegment*/ value, /*out long*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080132730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(value.Buffer) || value.Length === 0)
                {
                    result.$v = 0n;
                    return false;
                }
                return $.$$.S.Int64.TryParse$4(value.AsSpan(), 0/*NumberStyles.None*/, $.$$.SG.NumberFormatInfo.InvariantInfo, result);
            }
            //--TRIMMABLE-BOUNDARY-END(103080132730)
            
            //--TRIMMABLE-BOUNDARY-START(111670067322)
            static /*bool */ TryParseQualityDouble(/*StringSegment*/ input, /*int*/ startIndex, /*out double*/ quality, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670067322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                quality.$v = 0;
                length.$v = 0;
                /*var*/ let inputLength = input.Length;
                /*var*/ let current = startIndex;
                /*var*/ let limit = ((startIndex + 10/*_qualityValueMaxCharCount*/) | 0);
                /*var*/ let decPart = 0;
                /*var*/ let decPow = 1;
                if (current >= inputLength)
                {
                    return false;
                }
                /*var*/ let ch = input.get_Item$1(current);
                /*int*/ let intPart;
                if (ch >= /*0*/ 48 && ch <= /*1*/ 49)
                {
                    intPart = ch - /*0*/ 48;
                    current++;
                }
                else 
                {
                    return false;
                }
                if (current < inputLength)
                {
                    ch = input.get_Item$1(current);
                    if (ch >= /*0*/ 48 && ch <= /*9*/ 57)
                    {
                        return false;
                    }
                    if (ch === /*.*/ 46)
                    {
                        current++;
                        while(current < inputLength)
                        {
                            ch = input.get_Item$1(current);
                            if (ch >= /*0*/ 48 && ch <= /*9*/ 57)
                            {
                                if (current >= limit)
                                {
                                    return false;
                                }
                                decPart = ((((((decPart * 10) | 0) + ch) | 0) - /*0*/ 48) | 0);
                                decPow *= 10;
                                current++;
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                }
                if (decPart !== 0)
                {
                    quality.$v = intPart + decPart / $.$cast(decPow, $.$$.S.Double);
                }
                else 
                {
                    quality.$v = intPart;
                }
                if (quality.$v > 1)
                {
                    quality.$v = 0;
                    return false;
                }
                length.$v = ((current - startIndex) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(111670067322)
            
            //--TRIMMABLE-BOUNDARY-START(60130459770)
            static /*string */ FormatNonNegativeInt64(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130459770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.S.Int64), "The value to be formatted must be non-negative.");
                }
                if (value === 0n)
                {
                    return "0";
                }
                return $.$$.S.UInt64.ToString$1.call(($.$cast(value, $.$$.S.UInt64)), $.$$.SG.NumberFormatInfo.InvariantInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(60130459770)
            
            //--TRIMMABLE-BOUNDARY-START(55835492474)
            static /*string */ FormatInt64(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835492474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    if (value === 0n)
                    {
                        return "0";
                    }
                    if (value === 1n)
                    {
                        return "1";
                    }
                    if (value === BigInt(-1))
                    {
                        return "-1";
                    }
                    return $.$$.S.Int64.ToString$1.call(value, $.$$.SG.NumberFormatInfo.InvariantInfo);
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(55835492474)
            
            //--TRIMMABLE-BOUNDARY-START(94490198138)
            static /*bool */ TryParseDate(/*StringSegment*/ input, /*out DateTimeOffset*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490198138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.HttpRuleParser.TryStringToDate(input, result);
            }
            //--TRIMMABLE-BOUNDARY-END(94490198138)
            
            //--TRIMMABLE-BOUNDARY-START(51540525178)
            static /*string */ FormatDate$1(/*DateTimeOffset*/ dateTime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.HeaderUtilities.FormatDate(dateTime, false);
            }
            //--TRIMMABLE-BOUNDARY-END(51540525178)
            
            //--TRIMMABLE-BOUNDARY-START(47245557882)
            static /*string */ FormatDate(/*DateTimeOffset*/ dateTime, /*bool*/ quoted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (quoted)
                {
                    return $.$$.S.String.Create$10($.$$.S.DateTimeOffset, 31, dateTime, new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$$.S.DateTimeOffset))().$ctor(this,  (/*span*/ span, /*dt*/ dt) =>
                    {
                        span._reference.SetAt(span._reference.SetAt(/*\"*/ 34, 30), 0);
                        dt.TryFormat$1(span.Slice$1(1), $.$discardRef(), $.$$.S.String.op_Implicit("r"), $.$$.SG.CultureInfo.InvariantCulture);
                    }, $jTqfed ??= {"r":65537,"p":[{"n":"span","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"dt","p":66191361}],"n":"","d":917626,"h":0,"f":17825794}));
                }
                return dateTime.ToString$2("r", $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(47245557882)
            
            //--TRIMMABLE-BOUNDARY-START(81605296250)
            static /*StringSegment */ RemoveQuotes(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mnhh.MNHH.HeaderUtilities.IsQuoted(input))
                {
                    input = input.Subsegment(1, ((input.Length - 2) | 0));
                }
                return input;
            }
            //--TRIMMABLE-BOUNDARY-END(81605296250)
            
            //--TRIMMABLE-BOUNDARY-START(73015361658)
            static /*bool */ IsQuoted(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !$.$mep.MEP.StringSegment.IsNullOrEmpty(input) && input.Length >= 2 && input.get_Item$1(0) === /*\"*/ 34 && input.get_Item$1(((input.Length - 1) | 0)) === /*\"*/ 34;
            }
            //--TRIMMABLE-BOUNDARY-END(73015361658)
            
            //--TRIMMABLE-BOUNDARY-START(120260001914)
            static /*StringSegment */ UnescapeAsQuotedString(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260001914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                input = $.$mnhh.MNHH.HeaderUtilities.RemoveQuotes(input);
                /*var*/ let backSlashCount = $.$mnhh.MNHH.HeaderUtilities.CountBackslashesForDecodingQuotedString(input);
                if (backSlashCount === 0)
                {
                    return input;
                }
                return $.$mep.MEP.StringSegment.op_Implicit$2($.$$.S.String.Create$10($.$mep.MEP.StringSegment, ((input.Length - backSlashCount) | 0), input, new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$mep.MEP.StringSegment))().$ctor(this,  (/*span*/ span, /*segment*/ segment) =>
                {
                    /*var*/ let spanIndex = 0;
                    /*var*/ let spanLength = span.Length;
                    for(/*var*/ let i = 0; i < segment.Length && (spanIndex >>> 0) < (spanLength >>> 0); i++)
                    {
                        /*int*/ let nextIndex = ((i + 1) | 0);
                        if ((nextIndex >>> 0) < (segment.Length >>> 0) && segment.get_Item$1(i) === /*\\*/ 92)
                        {
                            span._reference.SetAt(segment.get_Item$1(nextIndex), spanIndex);
                            i++;
                        }
                        else 
                        {
                            span._reference.SetAt(segment.get_Item$1(i), spanIndex);
                        }
                        spanIndex++;
                    }
                }, $nCNfJg ??= {"r":65537,"p":[{"n":"span","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"segment","p":852053}],"n":"","d":917626,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(120260001914)
            
            //--TRIMMABLE-BOUNDARY-START(38655623290)
            static /*int */ CountBackslashesForDecodingQuotedString(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let numberBackSlashes = 0;
                for(/*var*/ let i = 0; i < input.Length; i++)
                {
                    if (i < ((input.Length - 1) | 0) && input.get_Item$1(i) === /*\\*/ 92)
                    {
                        if (input.get_Item$1(((i + 1) | 0)) === /*\\*/ 92)
                        {
                            i++;
                        }
                        numberBackSlashes++;
                    }
                }
                return numberBackSlashes;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623290)
            
            //--TRIMMABLE-BOUNDARY-START(42950590586)
            static /*StringSegment */ EscapeAsQuotedString(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let backSlashCount = $.$mnhh.MNHH.HeaderUtilities.CountAndCheckCharactersNeedingBackslashesWhenEncoding(input);
                return $.$mep.MEP.StringSegment.op_Implicit$2($.$$.S.String.Create$10($.$mep.MEP.StringSegment, ((((input.Length + backSlashCount) | 0) + 2) | 0), input, new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$mep.MEP.StringSegment))().$ctor(this,  (/*span*/ span, /*segment*/ segment) =>
                {
                    span._reference.SetAt(span._reference.SetAt(/*\"*/ 34, 0), ((span.Length - 1) | 0));
                    /*var*/ let spanIndex = 1;
                    for(/*var*/ let i = 0; i < segment.Length; i++)
                    {
                        if (segment.get_Item$1(i) === /*\\*/ 92 || segment.get_Item$1(i) === /*\"*/ 34)
                        {
                            span._reference.SetAt(/*\\*/ 92, spanIndex++);
                        }
                        else if ((segment.get_Item$1(i) <= 31 || segment.get_Item$1(i) === 127) && segment.get_Item$1(i) !== 9)
                        {
                            throw new $.$$.S.FormatException().$ctor$12(`Invalid control character '${$.$strNN($.$$.S.Char.ToString.call(segment.get_Item$1(i)))}' in input.`);
                        }
                        span._reference.SetAt(segment.get_Item$1(i), spanIndex++);
                    }
                }, $yragzg ??= {"r":65537,"p":[{"n":"span","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"segment","p":852053}],"n":"","d":917626,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(42950590586)
            
            //--TRIMMABLE-BOUNDARY-START(34360655994)
            static /*int */ CountAndCheckCharactersNeedingBackslashesWhenEncoding(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360655994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let numberOfCharactersNeedingEscaping = 0;
                for(/*var*/ let i = 0; i < input.Length; i++)
                {
                    if (input.get_Item$1(i) === /*\\*/ 92 || input.get_Item$1(i) === /*\"*/ 34)
                    {
                        numberOfCharactersNeedingEscaping++;
                    }
                }
                return numberOfCharactersNeedingEscaping;
            }
            //--TRIMMABLE-BOUNDARY-END(34360655994)
            
            //--TRIMMABLE-BOUNDARY-START(90195230842)
            static /*void */ ThrowIfReadOnly(/*bool*/ isReadOnly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195230842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isReadOnly)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("The object cannot be modified because it is read-only.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195230842)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(77310328954)
                    this.QualityName = "q";
                    //--TRIMMABLE-BOUNDARY-END(77310328954)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475754106)
                    this.BytesUnit = "bytes";
                    //--TRIMMABLE-BOUNDARY-END(21475754106)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 917626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900263546),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h
        },
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Double).$h
        }
      ],
      "n": "SetQuality",
      "d": 917626,
      "h": 85900263546,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(85900263546),
//--TRIMMABLE-BOUNDARY-START(68720394362),
    {
      "r": $.$typeNullable($.$$.S.Double).$h,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h
        }
      ],
      "n": "GetQuality",
      "d": 917626,
      "h": 68720394362,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(68720394362),
//--TRIMMABLE-BOUNDARY-START(25770721402),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckValidToken",
      "d": 917626,
      "h": 25770721402,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770721402),
//--TRIMMABLE-BOUNDARY-START(17180786810),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": (T) => $.$$.SCG.ICollection$$(T).$h
        },
        {
          "n": "y",
          "p": (T) => $.$$.SCG.ICollection$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AreEqualCollections",
      "o": "@$1",
      "d": 917626,
      "h": 17180786810,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(17180786810),
//--TRIMMABLE-BOUNDARY-START(12885819514),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": (T) => $.$$.SCG.ICollection$$(T).$h
        },
        {
          "n": "y",
          "p": (T) => $.$$.SCG.ICollection$$(T).$h
        },
        {
          "n": "comparer",
          "p": (T) => $.$$.SCG.IEqualityComparer$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AreEqualCollections",
      "d": 917626,
      "h": 12885819514,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(12885819514),
//--TRIMMABLE-BOUNDARY-START(64425427066),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "skipEmptyValues",
          "p": 262145
        },
        {
          "n": "separatorFound",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "GetNextNonEmptyOrWhitespaceIndex",
      "d": 917626,
      "h": 64425427066,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64425427066),
//--TRIMMABLE-BOUNDARY-START(8590852218),
    {
      "r": 655361,
      "p": [
        {
          "n": "current",
          "p": 655361
        },
        {
          "n": "headerValue",
          "p": 1310721
        }
      ],
      "n": "AdvanceCacheDirectiveIndex",
      "d": 917626,
      "h": 8590852218,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590852218),
//--TRIMMABLE-BOUNDARY-START(115965034618),
    {
      "r": 262145,
      "p": [
        {
          "n": "headerValues",
          "p": 1114197
        },
        {
          "n": "targetValue",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.TimeSpan).$h,
          "f": 2
        }
      ],
      "n": "TryParseSeconds",
      "d": 917626,
      "h": 115965034618,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115965034618),
//--TRIMMABLE-BOUNDARY-START(30065688698),
    {
      "r": 262145,
      "p": [
        {
          "n": "cacheControlDirectives",
          "p": 1114197
        },
        {
          "n": "targetDirectives",
          "p": 1310721
        }
      ],
      "n": "ContainsCacheDirective",
      "d": 917626,
      "h": 30065688698,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065688698),
//--TRIMMABLE-BOUNDARY-START(107375100026),
    {
      "r": 262145,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "headerValue",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryParseNonNegativeInt64FromHeaderValue",
      "d": 917626,
      "h": 107375100026,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375100026),
//--TRIMMABLE-BOUNDARY-START(98785165434),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "result",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryParseNonNegativeInt32",
      "d": 917626,
      "h": 98785165434,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98785165434),
//--TRIMMABLE-BOUNDARY-START(103080132730),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "result",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryParseNonNegativeInt64",
      "d": 917626,
      "h": 103080132730,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103080132730),
//--TRIMMABLE-BOUNDARY-START(111670067322),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "quality",
          "p": 1179649,
          "f": 2
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryParseQualityDouble",
      "d": 917626,
      "h": 111670067322,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(111670067322),
//--TRIMMABLE-BOUNDARY-START(60130459770),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "FormatNonNegativeInt64",
      "d": 917626,
      "h": 60130459770,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130459770),
//--TRIMMABLE-BOUNDARY-START(55835492474),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "FormatInt64",
      "d": 917626,
      "h": 55835492474,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835492474),
//--TRIMMABLE-BOUNDARY-START(94490198138),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "result",
          "p": 66191361,
          "f": 2
        }
      ],
      "n": "TryParseDate",
      "d": 917626,
      "h": 94490198138,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94490198138),
//--TRIMMABLE-BOUNDARY-START(51540525178),
    {
      "r": 1310721,
      "p": [
        {
          "n": "dateTime",
          "p": 66191361
        }
      ],
      "n": "FormatDate",
      "o": "@$1",
      "d": 917626,
      "h": 51540525178,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540525178),
//--TRIMMABLE-BOUNDARY-START(47245557882),
    {
      "r": 1310721,
      "p": [
        {
          "n": "dateTime",
          "p": 66191361
        },
        {
          "n": "quoted",
          "p": 262145
        }
      ],
      "n": "FormatDate",
      "d": 917626,
      "h": 47245557882,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245557882),
//--TRIMMABLE-BOUNDARY-START(81605296250),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "RemoveQuotes",
      "d": 917626,
      "h": 81605296250,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605296250),
//--TRIMMABLE-BOUNDARY-START(73015361658),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "IsQuoted",
      "d": 917626,
      "h": 73015361658,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015361658),
//--TRIMMABLE-BOUNDARY-START(120260001914),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "UnescapeAsQuotedString",
      "d": 917626,
      "h": 120260001914,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120260001914),
//--TRIMMABLE-BOUNDARY-START(38655623290),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "CountBackslashesForDecodingQuotedString",
      "d": 917626,
      "h": 38655623290,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655623290),
//--TRIMMABLE-BOUNDARY-START(42950590586),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "EscapeAsQuotedString",
      "d": 917626,
      "h": 42950590586,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950590586),
//--TRIMMABLE-BOUNDARY-START(34360655994),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "CountAndCheckCharactersNeedingBackslashesWhenEncoding",
      "d": 917626,
      "h": 34360655994,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360655994),
//--TRIMMABLE-BOUNDARY-START(90195230842),
    {
      "r": 65537,
      "p": [
        {
          "n": "isReadOnly",
          "p": 262145
        }
      ],
      "n": "ThrowIfReadOnly",
      "d": 917626,
      "h": 90195230842,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90195230842)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884922),
    {
      "t": 655361,
      "n": "_qualityValueMaxCharCount",
      "d": 917626,
      "h": 4295884922,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295884922),
//--TRIMMABLE-BOUNDARY-START(77310328954),
    {
      "t": 1310721,
      "n": "QualityName",
      "d": 917626,
      "h": 77310328954,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310328954),
//--TRIMMABLE-BOUNDARY-START(21475754106),
    {
      "t": 1310721,
      "n": "BytesUnit",
      "d": 917626,
      "h": 21475754106,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475754106)
  ],
  "h": 917626
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.HeaderUtilities`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}HeaderUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917626)
        
        

        //--TRIMMABLE-BOUNDARY-START(196730)
        $asm.$cls(`$mnhh.MNHH.ContentDispositionHeaderValue`, ($self) => class ContentDispositionHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81604575354)
            /*string*/ static FileNameString = null;
            //--TRIMMABLE-BOUNDARY-END(81604575354)
            
            //--TRIMMABLE-BOUNDARY-START(249108299898)
            /*string*/ static NameString = null;
            //--TRIMMABLE-BOUNDARY-END(249108299898)
            
            //--TRIMMABLE-BOUNDARY-START(77309608058)
            /*string*/ static FileNameStarString = null;
            //--TRIMMABLE-BOUNDARY-END(77309608058)
            
            //--TRIMMABLE-BOUNDARY-START(34359935098)
            /*string*/ static CreationDateString = null;
            //--TRIMMABLE-BOUNDARY-END(34359935098)
            
            //--TRIMMABLE-BOUNDARY-START(240518365306)
            /*string*/ static ModificationDateString = null;
            //--TRIMMABLE-BOUNDARY-END(240518365306)
            
            //--TRIMMABLE-BOUNDARY-START(274878103674)
            /*string*/ static ReadDateString = null;
            //--TRIMMABLE-BOUNDARY-END(274878103674)
            
            //--TRIMMABLE-BOUNDARY-START(386547253370)
            /*string*/ static SizeString = null;
            //--TRIMMABLE-BOUNDARY-END(386547253370)
            
            //--TRIMMABLE-BOUNDARY-START(223338496122)
            /*int*/ static MaxStackAllocSizeBytes = 256;
            //--TRIMMABLE-BOUNDARY-END(223338496122)
            
            //--TRIMMABLE-BOUNDARY-START(266288169082)
            /*char[]*/ static QuestionMark = null;
            //--TRIMMABLE-BOUNDARY-END(266288169082)
            
            //--TRIMMABLE-BOUNDARY-START(377957318778)
            /*char[]*/ static SingleQuote = null;
            //--TRIMMABLE-BOUNDARY-END(377957318778)
            
            //--TRIMMABLE-BOUNDARY-START(64424706170)
            /*char[]*/ static EscapeChars = null;
            //--TRIMMABLE-BOUNDARY-END(64424706170)
            
            //--TRIMMABLE-BOUNDARY-START(227633463418)
            static /*ReadOnlySpan<byte> */ get MimePrefix()
            {
                return this.$cacheMimePrefix ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([34, 61, 63, 117, 116, 102, 45, 56, 63, 66, 63]);
            }
            //--TRIMMABLE-BOUNDARY-END(227633463418)
            
            //--TRIMMABLE-BOUNDARY-START(231928430714)
            static /*ReadOnlySpan<byte> */ get MimeSuffix()
            {
                return this.$cacheMimeSuffix ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([63, 61, 34]);
            }
            //--TRIMMABLE-BOUNDARY-END(231928430714)
            
            //--TRIMMABLE-BOUNDARY-START(283468038266)
            /*SearchValues<char>*/ static Rfc5987AttrChar = null;
            //--TRIMMABLE-BOUNDARY-END(283468038266)
            
            //--TRIMMABLE-BOUNDARY-START(261993201786)
            /*HttpHeaderParser<ContentDispositionHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(261993201786)
            
            //--TRIMMABLE-BOUNDARY-START(8590131322)
            /*ObjectCollection<NameValueHeaderValue>?*/ _parameters = null;
            //--TRIMMABLE-BOUNDARY-END(8590131322)
            
            //--TRIMMABLE-BOUNDARY-START(4295164026)
            /*StringSegment*/ _dispositionType;
            //--TRIMMABLE-BOUNDARY-END(4295164026)
            
            //--TRIMMABLE-BOUNDARY-START(17180065914)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065914);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065914)
            
            //--TRIMMABLE-BOUNDARY-START(21475033210)
            $ctor$2(/*StringSegment*/ dispositionType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475033210);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.MNHH.ContentDispositionHeaderValue.CheckDispositionTypeFormat(dispositionType, "dispositionType");
                    this._dispositionType = dispositionType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475033210)
            
            //--TRIMMABLE-BOUNDARY-START(38654902394)
            /*StringSegment */ get DispositionType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784444538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._dispositionType;
            }
            /*StringSegment */ set DispositionType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942874746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.ContentDispositionHeaderValue.CheckDispositionTypeFormat(value, "value");
                this._dispositionType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38654902394)
            
            //--TRIMMABLE-BOUNDARY-START(253403267194)
            /*IList<NameValueHeaderValue> */ get Parameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913986682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._parameters === null)
                {
                    this._parameters = new ($.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.NameValueHeaderValue))().$ctor$3();
                }
                return this._parameters;
            }
            //--TRIMMABLE-BOUNDARY-END(253403267194)
            
            //--TRIMMABLE-BOUNDARY-START(244813332602)
            /*StringSegment */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324052090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetName("name"/*NameString*/);
            }
            /*StringSegment */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302613114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetName($.$mep.MEP.StringSegment.op_Implicit$2("name"/*NameString*/), value);
            }
            //--TRIMMABLE-BOUNDARY-END(244813332602)
            
            //--TRIMMABLE-BOUNDARY-START(68719673466)
            /*StringSegment */ get FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374379130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetName("filename"/*FileNameString*/);
            }
            /*StringSegment */ set FileName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532809338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetName($.$mep.MEP.StringSegment.op_Implicit$2("filename"/*FileNameString*/), value);
            }
            //--TRIMMABLE-BOUNDARY-END(68719673466)
            
            //--TRIMMABLE-BOUNDARY-START(73014640762)
            /*StringSegment */ get FileNameStar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetName("filename*"/*FileNameStarString*/);
            }
            /*StringSegment */ set FileNameStar(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122743930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetName($.$mep.MEP.StringSegment.op_Implicit$2("filename*"/*FileNameStarString*/), value);
            }
            //--TRIMMABLE-BOUNDARY-END(73014640762)
            
            //--TRIMMABLE-BOUNDARY-START(30064967802)
            /*DateTimeOffset? */ get CreationDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194509946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDate("creation-date"/*CreationDateString*/);
            }
            /*DateTimeOffset? */ set CreationDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296352940154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetDate("creation-date"/*CreationDateString*/, $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(30064967802)
            
            //--TRIMMABLE-BOUNDARY-START(236223398010)
            /*DateTimeOffset? */ get ModificationDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734117498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDate("modification-date"/*ModificationDateString*/);
            }
            /*DateTimeOffset? */ set ModificationDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712678522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetDate("modification-date"/*ModificationDateString*/, $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(236223398010)
            
            //--TRIMMABLE-BOUNDARY-START(270583136378)
            /*DateTimeOffset? */ get ReadDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503921274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDate("read-date"/*ReadDateString*/);
            }
            /*DateTimeOffset? */ set ReadDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892547706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetDate("read-date"/*ReadDateString*/, $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(270583136378)
            
            //--TRIMMABLE-BOUNDARY-START(382252286074)
            /*long? */ get Size()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093855866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sizeParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2("size"/*SizeString*/));
                if (sizeParameter !== null)
                {
                    /*var*/ let value;
                    /*var*/ let sizeString = sizeParameter.Value;
                    if ($.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64(sizeString, $.$ref(() => value, ($v) => value = $v, $.$$.S.Int64)))
                    {
                        return value;
                    }
                }
                return null;
            }
            /*long? */ set Size(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482482298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sizeParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2("size"/*SizeString*/));
                if (value === null)
                {
                    if (sizeParameter !== null)
                    {
                        this._parameters.Remove(sizeParameter);
                    }
                }
                else if ($.$$.S.Int64.op_LessThan(value, 0))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("value");
                }
                else if (sizeParameter !== null)
                {
                    sizeParameter.Value = $.$mep.MEP.StringSegment.op_Implicit$2($.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(value), $.$$.SG.CultureInfo.InvariantCulture));
                }
                else 
                {
                    /*var*/ let sizeString = $.$$.S.Int64.ToString$1.call($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(value), $.$$.SG.CultureInfo.InvariantCulture);
                    this.Parameters.SCG$ICollection$$$Add(new $.$mnhh.MNHH.NameValueHeaderValue().$ctor$2($.$mep.MEP.StringSegment.op_Implicit$2("size"/*SizeString*/), $.$mep.MEP.StringSegment.op_Implicit$2(sizeString)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(382252286074)
            
            //--TRIMMABLE-BOUNDARY-START(365072416890)
            /*void */ SetHttpFileName(/*StringSegment*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072416890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$mep.MEP.StringSegment.IsNullOrEmpty(fileName))
                {
                    this.FileName = $.$mnhh.MNHH.ContentDispositionHeaderValue.Sanitize(fileName);
                }
                else 
                {
                    this.FileName = fileName;
                }
                this.FileNameStar = fileName;
            }
            //--TRIMMABLE-BOUNDARY-END(365072416890)
            
            //--TRIMMABLE-BOUNDARY-START(369367384186)
            /*void */ SetMimeFileName(/*StringSegment*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367384186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FileNameStar = $.$mep.MEP.StringSegment.op_Implicit$2(null);
                this.FileName = fileName;
            }
            //--TRIMMABLE-BOUNDARY-END(369367384186)
            
            //--TRIMMABLE-BOUNDARY-START(390842220666)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842220666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$strNN(this._dispositionType.ToString()) + $.$mnhh.MNHH.NameValueHeaderValue.ToString$2(this._parameters, /*;*/ 59, true);
            }
            //--TRIMMABLE-BOUNDARY-END(390842220666)
            
            //--TRIMMABLE-BOUNDARY-START(60129738874)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.ContentDispositionHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return this._dispositionType.Equals$4(other._dispositionType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.MNHH.HeaderUtilities.AreEqualCollections$1($.$mnhh.MNHH.NameValueHeaderValue, this._parameters, other._parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(60129738874)
            
            //--TRIMMABLE-BOUNDARY-START(193273725050)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273725050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._dispositionType) ^ $.$mnhh.MNHH.NameValueHeaderValue.GetHashCode$1(this._parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(193273725050)
            
            //--TRIMMABLE-BOUNDARY-START(257698234490)
            static /*ContentDispositionHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698234490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.ContentDispositionHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(257698234490)
            
            //--TRIMMABLE-BOUNDARY-START(403727122554)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out ContentDispositionHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727122554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.ContentDispositionHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(403727122554)
            
            //--TRIMMABLE-BOUNDARY-START(188978757754)
            static /*int */ GetDispositionTypeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out ContentDispositionHeaderValue?*/ parsedValue)
            {
                /*var*/ let dispositionType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978757754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let dispositionTypeLength = $.$mnhh.MNHH.ContentDispositionHeaderValue.GetDispositionTypeExpressionLength(input, startIndex, $.$ref(() => dispositionType, ($v) => dispositionType = $v, $.$mep.MEP.StringSegment));
                if (dispositionTypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + dispositionTypeLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let contentDispositionHeader = new $.$mnhh.MNHH.ContentDispositionHeaderValue().$ctor$1();
                contentDispositionHeader._dispositionType = dispositionType;
                if ((current < input.Length) && (input.get_Item$1(current) === /*;*/ 59))
                {
                    current++;
                    /*int*/ let parameterLength = $.$mnhh.MNHH.NameValueHeaderValue.GetNameValueListLength(input, current, /*;*/ 59, contentDispositionHeader.Parameters);
                    parsedValue.$v = contentDispositionHeader;
                    return ((((current + parameterLength) | 0) - startIndex) | 0);
                }
                parsedValue.$v = contentDispositionHeader;
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(188978757754)
            
            //--TRIMMABLE-BOUNDARY-START(184683790458)
            static /*int */ GetDispositionTypeExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringSegment*/ dispositionType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683790458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                dispositionType.$v = $.$mep.MEP.StringSegment.op_Implicit$2(null);
                /*var*/ let typeLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, startIndex);
                if (typeLength === 0)
                {
                    return 0;
                }
                dispositionType.$v = input.Subsegment(startIndex, typeLength);
                return typeLength;
            }
            //--TRIMMABLE-BOUNDARY-END(184683790458)
            
            //--TRIMMABLE-BOUNDARY-START(25770000506)
            static /*void */ CheckDispositionTypeFormat(/*StringSegment*/ dispositionType, /*string*/ parameterName)
            {
                /*var*/ let tempDispositionType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(dispositionType))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                /*var*/ let dispositionTypeLength = $.$mnhh.MNHH.ContentDispositionHeaderValue.GetDispositionTypeExpressionLength(dispositionType, 0, $.$ref(() => tempDispositionType, ($v) => tempDispositionType = $v, $.$mep.MEP.StringSegment));
                if ((dispositionTypeLength === 0) || (tempDispositionType.Length !== dispositionType.Length))
                {
                    throw new $.$$.S.FormatException().$ctor$12($.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, "Invalid disposition type '{0}'.", dispositionType));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770000506)
            
            //--TRIMMABLE-BOUNDARY-START(180388823162)
            /*DateTimeOffset? */ GetDate(/*string*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388823162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dateParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2(parameter));
                if (dateParameter !== null)
                {
                    /*var*/ let dateString = dateParameter.Value;
                    if ($.$mnhh.MNHH.ContentDispositionHeaderValue.IsQuoted(dateString))
                    {
                        dateString = dateString.Subsegment(1, ((dateString.Length - 2) | 0));
                    }
                    /*DateTimeOffset*/ let date;
                    if ($.$mnhh.MNHH.HttpRuleParser.TryStringToDate(dateString, $.$ref(() => date, ($v) => date = $v, $.$$.S.DateTimeOffset)))
                    {
                        return date;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(180388823162)
            
            //--TRIMMABLE-BOUNDARY-START(360777449594)
            /*void */ SetDate(/*string*/ parameter, /*DateTimeOffset?*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777449594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dateParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2(parameter));
                if (date === null)
                {
                    if (dateParameter !== null)
                    {
                        this._parameters.Remove(dateParameter);
                    }
                }
                else 
                {
                    /*var*/ let dateString = $.$mnhh.MNHH.HeaderUtilities.FormatDate($.$$.S.Nullable$$($.$$.S.DateTimeOffset).GetValueOrDefault.call(date), true);
                    if (dateParameter !== null)
                    {
                        dateParameter.Value = $.$mep.MEP.StringSegment.op_Implicit$2(dateString);
                    }
                    else 
                    {
                        this.Parameters.SCG$ICollection$$$Add(new $.$mnhh.MNHH.NameValueHeaderValue().$ctor$2($.$mep.MEP.StringSegment.op_Implicit$2(parameter), $.$mep.MEP.StringSegment.op_Implicit$2(dateString)));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(360777449594)
            
            //--TRIMMABLE-BOUNDARY-START(197568692346)
            /*StringSegment */ GetName(/*string*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568692346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nameParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, $.$mep.MEP.StringSegment.op_Implicit$2(parameter));
                if (nameParameter !== null)
                {
                    /*string?*/ let result;
                    if (parameter.endsWith("*"))
                    {
                        if ($.$mnhh.MNHH.ContentDispositionHeaderValue.TryDecode5987(nameParameter.Value, $.$ref(() => result, ($v) => result = $v, $.$$.S.String)))
                        {
                            return $.$mep.MEP.StringSegment.op_Implicit$2(result);
                        }
                        return $.$mep.MEP.StringSegment.op_Implicit$2(null);
                    }
                    if ($.$mnhh.MNHH.ContentDispositionHeaderValue.TryDecodeMime(nameParameter.Value, $.$ref(() => result, ($v) => result = $v, $.$$.S.String)))
                    {
                        return $.$mep.MEP.StringSegment.op_Implicit$2(result);
                    }
                    return $.$mnhh.MNHH.HeaderUtilities.RemoveQuotes(nameParameter.Value);
                }
                return $.$mep.MEP.StringSegment.op_Implicit$2(null);
            }
            //--TRIMMABLE-BOUNDARY-END(197568692346)
            
            //--TRIMMABLE-BOUNDARY-START(373662351482)
            /*void */ SetName(/*StringSegment*/ parameter, /*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662351482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nameParameter = $.$mnhh.MNHH.NameValueHeaderValue.Find(this._parameters, parameter);
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(value))
                {
                    if (nameParameter !== null)
                    {
                        this._parameters.Remove(nameParameter);
                    }
                }
                else 
                {
                    /*StringSegment*/ let processedValue;
                    if (parameter.EndsWith("*", 4/*StringComparison.Ordinal*/))
                    {
                        processedValue = $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.ContentDispositionHeaderValue.Encode5987(value));
                    }
                    else 
                    {
                        processedValue = this.EncodeAndQuoteMime(value);
                    }
                    if (nameParameter !== null)
                    {
                        nameParameter.Value = processedValue;
                    }
                    else 
                    {
                        this.Parameters.SCG$ICollection$$$Add(new $.$mnhh.MNHH.NameValueHeaderValue().$ctor$2(parameter, processedValue));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(373662351482)
            
            //--TRIMMABLE-BOUNDARY-START(47244836986)
            /*StringSegment */ EncodeAndQuoteMime(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = input;
                /*var*/ let needsQuotes = false;
                if ($.$mnhh.MNHH.ContentDispositionHeaderValue.IsQuoted(result))
                {
                    result = result.Subsegment(1, ((result.Length - 2) | 0));
                    needsQuotes = true;
                }
                if ($.$mnhh.MNHH.ContentDispositionHeaderValue.RequiresEncoding(result))
                {
                    needsQuotes = false;
                    result = $.$mep.MEP.StringSegment.op_Implicit$2(this.EncodeMimeWithQuotes(result));
                }
                else if (!needsQuotes && $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(result, 0) !== result.Length)
                {
                    needsQuotes = true;
                }
                if (needsQuotes)
                {
                    if (result.IndexOfAny$2($.$mnhh.MNHH.ContentDispositionHeaderValue.EscapeChars) !== -1)
                    {
                        result = $.$mep.MEP.StringSegment.op_Implicit$2(result.ToString().replaceAll("\\", "\\\\").replaceAll("\"", "\\\""));
                    }
                    result = $.$mep.MEP.StringSegment.op_Implicit$2($.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, "\"{0}\"", result));
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(47244836986)
            
            //--TRIMMABLE-BOUNDARY-START(287763005562)
            static /*StringSegment */ Sanitize(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763005562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = input;
                if ($.$mnhh.MNHH.ContentDispositionHeaderValue.RequiresEncoding(result))
                {
                    /*var*/ let builder = new $.$$.ST.StringBuilder().$ctor$4(result.Length);
                    for(/*int*/ let i = 0; i < result.Length; i++)
                    {
                        /*var*/ let c = result.get_Item$1(i);
                        if ($.$cast(c, $.$$.S.Int32) >= 127 || $.$cast(c, $.$$.S.Int32) < 32)
                        {
                            c = /*_*/ 95;
                        }
                        builder.Append$5(c);
                    }
                    result = $.$mep.MEP.StringSegment.op_Implicit$2(builder.ToString());
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(287763005562)
            
            //--TRIMMABLE-BOUNDARY-START(219043528826)
            static /*bool */ IsQuoted(/*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043528826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SDC$1.Contract.Assert$1($.$mep.MEP.StringSegment.op_Inequality(value, $.$mep.MEP.StringSegment.op_Implicit$2(null)));
                return value.Length > 1 && value.StartsWith("\"", 4/*StringComparison.Ordinal*/) && value.EndsWith("\"", 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(219043528826)
            
            //--TRIMMABLE-BOUNDARY-START(279173070970)
            static /*bool */ RequiresEncoding(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173070970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SDC$1.Contract.Assert$1($.$mep.MEP.StringSegment.op_Inequality(input, $.$mep.MEP.StringSegment.op_Implicit$2(null)));
                return $.$$.S.MemoryExtensions.IndexOfAnyExceptInRange($.$$.S.Char, input.AsSpan(), 32, 126) >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(279173070970)
            
            //--TRIMMABLE-BOUNDARY-START(51539804282)
            /*string */ EncodeMimeWithQuotes(/*StringSegment*/ input)
            {
                /*var*/ let base64ContentLength;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let requiredLength = (((($.$mnhh.MNHH.ContentDispositionHeaderValue.MimePrefix.Length + $.$$.SBT.Base64.GetMaxEncodedToUtf8Length($.$$.ST.Encoding.UTF8.GetByteCount$4(input.AsSpan()))) | 0) + $.$mnhh.MNHH.ContentDispositionHeaderValue.MimeSuffix.Length) | 0);
                /*byte[]?*/ let bufferFromPool = null;
                /*Span<byte>*/ let buffer = requiredLength <= 256/*MaxStackAllocSizeBytes*/ ? $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 256/*MaxStackAllocSizeBytes*/, null) : $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(bufferFromPool = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(requiredLength));
                let $t10 = buffer;
                buffer = $t10.Slice(0, requiredLength);
                $.$mnhh.MNHH.ContentDispositionHeaderValue.MimePrefix.CopyTo(buffer);
                /*var*/ let bufferContent = buffer.Slice$1($.$mnhh.MNHH.ContentDispositionHeaderValue.MimePrefix.Length);
                /*var*/ let contentLength = $.$$.ST.Encoding.UTF8.GetBytes$5(input.AsSpan(), bufferContent);
                $.$$.SBT.Base64.EncodeToUtf8InPlace(bufferContent, contentLength, $.$ref(() => base64ContentLength, ($v) => base64ContentLength = $v, $.$$.S.Int32));
                $.$mnhh.MNHH.ContentDispositionHeaderValue.MimeSuffix.CopyTo(bufferContent.Slice$1(base64ContentLength));
                /*var*/ let result = $.$$.ST.Encoding.UTF8.GetString$3($.$$.S.Span$$($.$$.S.Byte).op_Implicit(buffer.Slice(0, (((($.$mnhh.MNHH.ContentDispositionHeaderValue.MimePrefix.Length + base64ContentLength) | 0) + $.$mnhh.MNHH.ContentDispositionHeaderValue.MimeSuffix.Length) | 0))));
                if (!(bufferFromPool === null))
                {
                    $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(bufferFromPool, false);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804282)
            
            //--TRIMMABLE-BOUNDARY-START(399432155258)
            static /*bool */ TryDecodeMime(/*StringSegment*/ input, /*out string?*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432155258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SDC$1.Contract.Assert$1($.$mep.MEP.StringSegment.op_Inequality(input, $.$mep.MEP.StringSegment.op_Implicit$2(null)));
                output.$v = null;
                /*var*/ let processedInput = input;
                if (!$.$mnhh.MNHH.ContentDispositionHeaderValue.IsQuoted(processedInput) || processedInput.Length < 10)
                {
                    return false;
                }
                /*var*/ let parts = $.$sl.SL.Enumerable.ToArray($.$mep.MEP.StringSegment, processedInput.Split($.$mnhh.MNHH.ContentDispositionHeaderValue.QuestionMark));
                if (parts.length !== 5 || $.$mep.MEP.StringSegment.op_Inequality($.$$.System.Array.$ReadT1.call(parts, 0), $.$mep.MEP.StringSegment.op_Implicit$2("\"=")) || $.$mep.MEP.StringSegment.op_Inequality($.$$.System.Array.$ReadT1.call(parts, 4), $.$mep.MEP.StringSegment.op_Implicit$2("=\"")) || !$.$$.System.Array.$ReadT1.call(parts, 2).Equals$2("b", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                try
                {
                    /*var*/ let encoding = $.$$.ST.Encoding.GetEncoding$3($.$$.System.Array.$ReadT1.call(parts, 1).ToString());
                    /*var*/ let bytes = $.$$.S.Convert.FromBase64String($.$$.System.Array.$ReadT1.call(parts, 3).ToString());
                    output.$v = encoding.GetString(bytes, 0, bytes.length);
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.S.ArgumentException)
                    {
                    }
                    else if ($e instanceof $.$$.S.FormatException)
                    {
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(399432155258)
            
            //--TRIMMABLE-BOUNDARY-START(42949869690)
            static /*string */ Encode5987(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$$.ST.StringBuilder().$ctor$8("UTF-8''");
                /*var*/ let remaining = input.AsSpan();
                while(remaining.Length > 0)
                {
                    /*var*/ let length = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, remaining, $.$mnhh.MNHH.ContentDispositionHeaderValue.Rfc5987AttrChar);
                    if (length < 0)
                    {
                        length = remaining.Length;
                    }
                    let $t12 = remaining;
                    builder.Append$17($t12.Slice(0, length));
                    remaining = remaining.Slice$1(length);
                    if (remaining.Length === 0)
                    {
                        break;
                    }
                    length = $.$$.S.MemoryExtensions.IndexOfAny$2($.$$.S.Char, remaining, $.$mnhh.MNHH.ContentDispositionHeaderValue.Rfc5987AttrChar);
                    if (length < 0)
                    {
                        length = remaining.Length;
                    }
                    for(/*var*/ let i = 0; i < length; )
                    {
                        /*Rune*/ let rune;
                        /*var*/ let runeLength;
                        $.$$.ST.Rune.DecodeFromUtf16(remaining.Slice$1(i), $.$ref(() => rune, ($v) => rune = $v, $.$$.ST.Rune), $.$ref(() => runeLength, ($v) => runeLength = $v, $.$$.S.Int32));
                        $.$mnhh.MNHH.ContentDispositionHeaderValue.EncodeToUtf8Hex(rune, builder);
                        i += runeLength;
                    }
                    remaining = remaining.Slice$1(length);
                }
                return builder.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(42949869690)
            
            //--TRIMMABLE-BOUNDARY-START(206158626938)
            /*char[]*/ static HexUpperChars = null;
            //--TRIMMABLE-BOUNDARY-END(206158626938)
            
            //--TRIMMABLE-BOUNDARY-START(55834771578)
            static /*void */ EncodeToUtf8Hex(/*Rune*/ rune, /*StringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let value = (rune.Value >>> 0);
                if (rune.IsAscii)
                {
                    /*var*/ let byteValue = ((value & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                }
                else if (BigInt(rune.Value) <= 2047n)
                {
                    /*var*/ let byteValue = ((((((value + ((6 << 11) >>> 0)) >>> 0)) >>> 6) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                    byteValue = ((((((value & 63) + 128) >>> 0)) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                }
                else if (BigInt(rune.Value) <= 65535n)
                {
                    /*var*/ let byteValue = ((((value + (14 << 16)) >>> 12) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                    byteValue = (((((((value & ((63 << 6) >>> 0)) >>> 6) + 128) >>> 0)) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                    byteValue = ((((((value & 63) + 128) >>> 0)) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                }
                else 
                {
                    /*var*/ let byteValue = ((((value + (30 << 21)) >>> 18) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                    byteValue = (((((((value & ((63 << 12) >>> 0)) >>> 12) + 128) >>> 0)) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                    byteValue = (((((((value & ((63 << 6) >>> 0)) >>> 6) + 128) >>> 0)) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                    byteValue = ((((((value & 63) + 128) >>> 0)) & 0xFF) >>> 0);
                    builder.Append$11($.$$.SG.CultureInfo.InvariantCulture, `%${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4)))}${$.$strNN($.$$.S.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.MNHH.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15)))}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834771578)
            
            //--TRIMMABLE-BOUNDARY-START(395137187962)
            static /*bool */ TryDecode5987(/*StringSegment*/ input, /*out string?*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137187962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                output.$v = null;
                /*var*/ let parts = $.$sl.SL.Enumerable.ToArray($.$mep.MEP.StringSegment, input.Split($.$mnhh.MNHH.ContentDispositionHeaderValue.SingleQuote));
                if (parts.length !== 3)
                {
                    return false;
                }
                /*var*/ let decoded = new $.$$.ST.StringBuilder().$ctor$1();
                /*byte[]?*/ let unescapedBytes = null;
                try
                {
                    /*var*/ let encoding = $.$$.ST.Encoding.GetEncoding$3($.$$.System.Array.$ReadT1.call(parts, 0).ToString());
                    /*var*/ let dataString = $.$$.System.Array.$ReadT1.call(parts, 2);
                    unescapedBytes = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(dataString.Length);
                    /*var*/ let unescapedBytesCount = 0;
                    for(/*var*/ let index = 0; index < dataString.Length; index++)
                    {
                        if ($.$mnhh.MNHH.ContentDispositionHeaderValue.IsHexEncoding(dataString, index))
                        {
                            $.$$.System.Array.$WriteT1.call(unescapedBytes, $.$mnhh.MNHH.ContentDispositionHeaderValue.HexUnescape(dataString, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32)), unescapedBytesCount++);
                            index--;
                        }
                        else 
                        {
                            if (unescapedBytesCount > 0)
                            {
                                decoded.Append$21(encoding.GetString(unescapedBytes, 0, unescapedBytesCount));
                                unescapedBytesCount = 0;
                            }
                            decoded.Append$5(dataString.get_Item$1(index));
                        }
                    }
                    if (unescapedBytesCount > 0)
                    {
                        decoded.Append$21(encoding.GetString(unescapedBytes, 0, unescapedBytesCount));
                    }
                }
                catch($e)
                {
                    return false;
                }
                finally
                {
                    {
                        if (unescapedBytes !== null)
                        {
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(unescapedBytes, false);
                        }
                    }
                }
                output.$v = decoded.ToString();
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(395137187962)
            
            //--TRIMMABLE-BOUNDARY-START(214748561530)
            static /*bool */ IsHexEncoding(/*StringSegment*/ pattern, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748561530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((((pattern.Length - index) | 0)) < 3)
                {
                    return false;
                }
                if ((pattern.get_Item$1(index) === /*%*/ 37) && $.$mnhh.MNHH.ContentDispositionHeaderValue.IsEscapedAscii(pattern.get_Item$1(((index + 1) | 0)), pattern.get_Item$1(((index + 2) | 0))))
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(214748561530)
            
            //--TRIMMABLE-BOUNDARY-START(210453594234)
            static /*bool */ IsEscapedAscii(/*char*/ digit, /*char*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453594234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(((digit >= /*0*/ 48) && (digit <= /*9*/ 57)) || ((digit >= /*A*/ 65) && (digit <= /*F*/ 70)) || ((digit >= /*a*/ 97) && (digit <= /*f*/ 102))))
                {
                    return false;
                }
                if (!(((next >= /*0*/ 48) && (next <= /*9*/ 57)) || ((next >= /*A*/ 65) && (next <= /*F*/ 70)) || ((next >= /*a*/ 97) && (next <= /*f*/ 102))))
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(210453594234)
            
            //--TRIMMABLE-BOUNDARY-START(201863659642)
            static /*byte */ HexUnescape(/*StringSegment*/ pattern, /*ref int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863659642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((index.$v < 0) || (index.$v >= pattern.Length))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("index");
                }
                if ((pattern.get_Item$1(index.$v) === /*%*/ 37) && (((pattern.Length - index.$v) | 0) >= 3))
                {
                    /*var*/ let ret = $.$mnhh.MNHH.ContentDispositionHeaderValue.UnEscapeAscii(pattern.get_Item$1(((index.$v + 1) | 0)), pattern.get_Item$1(((index.$v + 2) | 0)));
                    index.$v += 3;
                    return ret;
                }
                return ((pattern.get_Item$1(index.$v++) & 0xFF) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(201863659642)
            
            //--TRIMMABLE-BOUNDARY-START(408022089850)
            static /*byte */ UnEscapeAscii(/*char*/ digit, /*char*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022089850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(((digit >= /*0*/ 48) && (digit <= /*9*/ 57)) || ((digit >= /*A*/ 65) && (digit <= /*F*/ 70)) || ((digit >= /*a*/ 97) && (digit <= /*f*/ 102))))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("digit");
                }
                /*var*/ let res = (digit <= /*9*/ 57) ? ((($.$cast(digit, $.$$.S.Int32) - /*0*/ 48) | 0)) : (((((digit <= /*F*/ 70) ? ((($.$cast(digit, $.$$.S.Int32) - /*A*/ 65) | 0)) : ((($.$cast(digit, $.$$.S.Int32) - /*a*/ 97) | 0))) + 10) | 0));
                if (!(((next >= /*0*/ 48) && (next <= /*9*/ 57)) || ((next >= /*A*/ 65) && (next <= /*F*/ 70)) || ((next >= /*a*/ 97) && (next <= /*f*/ 102))))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("next");
                }
                return $.$cast(((((res << 4) + ((next <= /*9*/ 57) ? ((($.$cast(next, $.$$.S.Int32) - /*0*/ 48) | 0)) : (((((next <= /*F*/ 70) ? ((($.$cast(next, $.$$.S.Int32) - /*A*/ 65) | 0)) : ((($.$cast(next, $.$$.S.Int32) - /*a*/ 97) | 0))) + 10) | 0)))) | 0)), $.$$.S.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(408022089850)
            
            //--TRIMMABLE-BOUNDARY-START(17180065914)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180065914)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295164026)
                this._dispositionType = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(4295164026)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885098618)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(81604575354)
                    this.FileNameString = "filename";
                    //--TRIMMABLE-BOUNDARY-END(81604575354)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108299898)
                    this.NameString = "name";
                    //--TRIMMABLE-BOUNDARY-END(249108299898)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309608058)
                    this.FileNameStarString = "filename*";
                    //--TRIMMABLE-BOUNDARY-END(77309608058)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359935098)
                    this.CreationDateString = "creation-date";
                    //--TRIMMABLE-BOUNDARY-END(34359935098)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518365306)
                    this.ModificationDateString = "modification-date";
                    //--TRIMMABLE-BOUNDARY-END(240518365306)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878103674)
                    this.ReadDateString = "read-date";
                    //--TRIMMABLE-BOUNDARY-END(274878103674)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547253370)
                    this.SizeString = "size";
                    //--TRIMMABLE-BOUNDARY-END(386547253370)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288169082)
                    this.QuestionMark = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*?*/ 63], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(266288169082)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957318778)
                    this.SingleQuote = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*'*/ 39], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(377957318778)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424706170)
                    this.EscapeChars = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*\\*/ 92, /*\"*/ 34], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(64424706170)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468038266)
                    this.Rfc5987AttrChar = $.$$.SB.SearchValues.Create$1($.$$.S.String.op_Implicit("!#$&+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"));
                    //--TRIMMABLE-BOUNDARY-END(283468038266)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993201786)
                    this.Parser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.ContentDispositionHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.ContentDispositionHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.ContentDispositionHeaderValue, $.$mnhh.MNHH.ContentDispositionHeaderValue.GetDispositionTypeLength));
                    //--TRIMMABLE-BOUNDARY-END(261993201786)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158626938)
                    this.HexUpperChars = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*0*/ 48, /*1*/ 49, /*2*/ 50, /*3*/ 51, /*4*/ 52, /*5*/ 53, /*6*/ 54, /*7*/ 55, /*8*/ 56, /*9*/ 57, /*A*/ 65, /*B*/ 66, /*C*/ 67, /*D*/ 68, /*E*/ 69, /*F*/ 70], null, null);
                    //--TRIMMABLE-BOUNDARY-END(206158626938)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885098618)
            
            static $h = 196730;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(227633463418),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554248314,
        "f": 50331682
      },
      "n": "MimePrefix",
      "d": 196730,
      "h": 227633463418,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(227633463418),
//--TRIMMABLE-BOUNDARY-START(231928430714),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144182906,
        "f": 50331682
      },
      "n": "MimeSuffix",
      "d": 196730,
      "h": 231928430714,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(231928430714),
//--TRIMMABLE-BOUNDARY-START(38654902394),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784444538,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304942874746,
        "f": 83886081
      },
      "n": "DispositionType",
      "d": 196730,
      "h": 38654902394,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654902394),
//--TRIMMABLE-BOUNDARY-START(253403267194),
    {
      "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913986682,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 196730,
      "h": 253403267194,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403267194),
//--TRIMMABLE-BOUNDARY-START(244813332602),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324052090,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339302613114,
        "f": 83886081
      },
      "n": "Name",
      "d": 196730,
      "h": 244813332602,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244813332602),
//--TRIMMABLE-BOUNDARY-START(68719673466),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374379130,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313532809338,
        "f": 83886081
      },
      "n": "FileName",
      "d": 196730,
      "h": 68719673466,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719673466),
//--TRIMMABLE-BOUNDARY-START(73014640762),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964313722,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322122743930,
        "f": 83886081
      },
      "n": "FileNameStar",
      "d": 196730,
      "h": 73014640762,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014640762),
//--TRIMMABLE-BOUNDARY-START(30064967802),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194509946,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296352940154,
        "f": 83886081
      },
      "n": "CreationDate",
      "d": 196730,
      "h": 30064967802,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064967802),
//--TRIMMABLE-BOUNDARY-START(236223398010),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734117498,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330712678522,
        "f": 83886081
      },
      "n": "ModificationDate",
      "d": 196730,
      "h": 236223398010,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236223398010),
//--TRIMMABLE-BOUNDARY-START(270583136378),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503921274,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347892547706,
        "f": 83886081
      },
      "n": "ReadDate",
      "d": 196730,
      "h": 270583136378,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583136378),
//--TRIMMABLE-BOUNDARY-START(382252286074),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093855866,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356482482298,
        "f": 83886081
      },
      "n": "Size",
      "d": 196730,
      "h": 382252286074,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(382252286074)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(365072416890),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 852053
        }
      ],
      "n": "SetHttpFileName",
      "d": 196730,
      "h": 365072416890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(365072416890),
//--TRIMMABLE-BOUNDARY-START(369367384186),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 852053
        }
      ],
      "n": "SetMimeFileName",
      "d": 196730,
      "h": 369367384186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(369367384186),
//--TRIMMABLE-BOUNDARY-START(390842220666),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 196730,
      "h": 390842220666,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(390842220666),
//--TRIMMABLE-BOUNDARY-START(60129738874),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 196730,
      "h": 60129738874,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60129738874),
//--TRIMMABLE-BOUNDARY-START(193273725050),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 196730,
      "h": 193273725050,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193273725050),
//--TRIMMABLE-BOUNDARY-START(257698234490),
    {
      "r": 196730,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 196730,
      "h": 257698234490,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257698234490),
//--TRIMMABLE-BOUNDARY-START(403727122554),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 196730,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 196730,
      "h": 403727122554,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(403727122554),
//--TRIMMABLE-BOUNDARY-START(188978757754),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 196730,
          "f": 2
        }
      ],
      "n": "GetDispositionTypeLength",
      "d": 196730,
      "h": 188978757754,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(188978757754),
//--TRIMMABLE-BOUNDARY-START(184683790458),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "dispositionType",
          "p": 852053,
          "f": 2
        }
      ],
      "n": "GetDispositionTypeExpressionLength",
      "d": 196730,
      "h": 184683790458,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(184683790458),
//--TRIMMABLE-BOUNDARY-START(25770000506),
    {
      "r": 65537,
      "p": [
        {
          "n": "dispositionType",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckDispositionTypeFormat",
      "d": 196730,
      "h": 25770000506,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770000506),
//--TRIMMABLE-BOUNDARY-START(180388823162),
    {
      "r": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "p": [
        {
          "n": "parameter",
          "p": 1310721
        }
      ],
      "n": "GetDate",
      "d": 196730,
      "h": 180388823162,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180388823162),
//--TRIMMABLE-BOUNDARY-START(360777449594),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameter",
          "p": 1310721
        },
        {
          "n": "date",
          "p": $.$typeNullable($.$$.S.DateTimeOffset).$h
        }
      ],
      "n": "SetDate",
      "d": 196730,
      "h": 360777449594,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(360777449594),
//--TRIMMABLE-BOUNDARY-START(197568692346),
    {
      "r": 852053,
      "p": [
        {
          "n": "parameter",
          "p": 1310721
        }
      ],
      "n": "GetName",
      "d": 196730,
      "h": 197568692346,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197568692346),
//--TRIMMABLE-BOUNDARY-START(373662351482),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameter",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "SetName",
      "d": 196730,
      "h": 373662351482,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(373662351482),
//--TRIMMABLE-BOUNDARY-START(47244836986),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "EncodeAndQuoteMime",
      "d": 196730,
      "h": 47244836986,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244836986),
//--TRIMMABLE-BOUNDARY-START(287763005562),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Sanitize",
      "d": 196730,
      "h": 287763005562,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(287763005562),
//--TRIMMABLE-BOUNDARY-START(219043528826),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "IsQuoted",
      "d": 196730,
      "h": 219043528826,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(219043528826),
//--TRIMMABLE-BOUNDARY-START(279173070970),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "RequiresEncoding",
      "d": 196730,
      "h": 279173070970,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(279173070970),
//--TRIMMABLE-BOUNDARY-START(51539804282),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "EncodeMimeWithQuotes",
      "d": 196730,
      "h": 51539804282,
      "f": 16777218,
      "a": [
        {
          "t": 133693441,
          "c": 4428660737
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539804282),
//--TRIMMABLE-BOUNDARY-START(399432155258),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "output",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryDecodeMime",
      "d": 196730,
      "h": 399432155258,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(399432155258),
//--TRIMMABLE-BOUNDARY-START(42949869690),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Encode5987",
      "d": 196730,
      "h": 42949869690,
      "f": 16777250,
      "a": [
        {
          "t": 133693441,
          "c": 4428660737
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949869690),
//--TRIMMABLE-BOUNDARY-START(55834771578),
    {
      "r": 65537,
      "p": [
        {
          "n": "rune",
          "p": 167641089
        },
        {
          "n": "builder",
          "p": 167837697
        }
      ],
      "n": "EncodeToUtf8Hex",
      "d": 196730,
      "h": 55834771578,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834771578),
//--TRIMMABLE-BOUNDARY-START(395137187962),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "output",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryDecode5987",
      "d": 196730,
      "h": 395137187962,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(395137187962),
//--TRIMMABLE-BOUNDARY-START(214748561530),
    {
      "r": 262145,
      "p": [
        {
          "n": "pattern",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "IsHexEncoding",
      "d": 196730,
      "h": 214748561530,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(214748561530),
//--TRIMMABLE-BOUNDARY-START(210453594234),
    {
      "r": 262145,
      "p": [
        {
          "n": "digit",
          "p": 458753
        },
        {
          "n": "next",
          "p": 458753
        }
      ],
      "n": "IsEscapedAscii",
      "d": 196730,
      "h": 210453594234,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(210453594234),
//--TRIMMABLE-BOUNDARY-START(201863659642),
    {
      "r": 393217,
      "p": [
        {
          "n": "pattern",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "HexUnescape",
      "d": 196730,
      "h": 201863659642,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201863659642),
//--TRIMMABLE-BOUNDARY-START(408022089850),
    {
      "r": 393217,
      "p": [
        {
          "n": "digit",
          "p": 458753
        },
        {
          "n": "next",
          "p": 458753
        }
      ],
      "n": "UnEscapeAscii",
      "d": 196730,
      "h": 408022089850,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(408022089850)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81604575354),
    {
      "t": 1310721,
      "n": "FileNameString",
      "d": 196730,
      "h": 81604575354,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81604575354),
//--TRIMMABLE-BOUNDARY-START(249108299898),
    {
      "t": 1310721,
      "n": "NameString",
      "d": 196730,
      "h": 249108299898,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(249108299898),
//--TRIMMABLE-BOUNDARY-START(77309608058),
    {
      "t": 1310721,
      "n": "FileNameStarString",
      "d": 196730,
      "h": 77309608058,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77309608058),
//--TRIMMABLE-BOUNDARY-START(34359935098),
    {
      "t": 1310721,
      "n": "CreationDateString",
      "d": 196730,
      "h": 34359935098,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359935098),
//--TRIMMABLE-BOUNDARY-START(240518365306),
    {
      "t": 1310721,
      "n": "ModificationDateString",
      "d": 196730,
      "h": 240518365306,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(240518365306),
//--TRIMMABLE-BOUNDARY-START(274878103674),
    {
      "t": 1310721,
      "n": "ReadDateString",
      "d": 196730,
      "h": 274878103674,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(274878103674),
//--TRIMMABLE-BOUNDARY-START(386547253370),
    {
      "t": 1310721,
      "n": "SizeString",
      "d": 196730,
      "h": 386547253370,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(386547253370),
//--TRIMMABLE-BOUNDARY-START(223338496122),
    {
      "t": 655361,
      "n": "MaxStackAllocSizeBytes",
      "d": 196730,
      "h": 223338496122,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(223338496122),
//--TRIMMABLE-BOUNDARY-START(266288169082),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "QuestionMark",
      "d": 196730,
      "h": 266288169082,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(266288169082),
//--TRIMMABLE-BOUNDARY-START(377957318778),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "SingleQuote",
      "d": 196730,
      "h": 377957318778,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(377957318778),
//--TRIMMABLE-BOUNDARY-START(64424706170),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "EscapeChars",
      "d": 196730,
      "h": 64424706170,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64424706170),
//--TRIMMABLE-BOUNDARY-START(283468038266),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "Rfc5987AttrChar",
      "d": 196730,
      "h": 283468038266,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(283468038266),
//--TRIMMABLE-BOUNDARY-START(261993201786),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.ContentDispositionHeaderValue).$h,
      "n": "Parser",
      "d": 196730,
      "h": 261993201786,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(261993201786),
//--TRIMMABLE-BOUNDARY-START(8590131322),
    {
      "t": $.$mnhh.MNHH.ObjectCollection$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "n": "_parameters",
      "d": 196730,
      "h": 8590131322,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131322),
//--TRIMMABLE-BOUNDARY-START(4295164026),
    {
      "t": 852053,
      "n": "_dispositionType",
      "d": 196730,
      "h": 4295164026,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295164026),
//--TRIMMABLE-BOUNDARY-START(206158626938),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "HexUpperChars",
      "d": 196730,
      "h": 206158626938,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(206158626938)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065914),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196730,
      "h": 17180065914,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180065914),
//--TRIMMABLE-BOUNDARY-START(21475033210),
    {
      "p": [
        {
          "n": "dispositionType",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196730,
      "h": 21475033210,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033210)
  ],
  "h": 196730
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.ContentDispositionHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}ContentDispositionHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196730)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704058)
        $asm.$cls(`$mnhh.MNHH.SetCookieHeaderValue`, ($self) => class SetCookieHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(111670853754)
            /*string*/ static ExpiresToken = null;
            //--TRIMMABLE-BOUNDARY-END(111670853754)
            
            //--TRIMMABLE-BOUNDARY-START(227634970746)
            /*string*/ static MaxAgeToken = null;
            //--TRIMMABLE-BOUNDARY-END(227634970746)
            
            //--TRIMMABLE-BOUNDARY-START(85901049978)
            /*string*/ static DomainToken = null;
            //--TRIMMABLE-BOUNDARY-END(85901049978)
            
            //--TRIMMABLE-BOUNDARY-START(257699741818)
            /*string*/ static PathToken = null;
            //--TRIMMABLE-BOUNDARY-END(257699741818)
            
            //--TRIMMABLE-BOUNDARY-START(296354447482)
            /*string*/ static SecureToken = null;
            //--TRIMMABLE-BOUNDARY-END(296354447482)
            
            //--TRIMMABLE-BOUNDARY-START(287764512890)
            /*string*/ static SameSiteToken = null;
            //--TRIMMABLE-BOUNDARY-END(287764512890)
            
            //--TRIMMABLE-BOUNDARY-START(279174578298)
            /*string*/ static SameSiteNoneToken = null;
            //--TRIMMABLE-BOUNDARY-END(279174578298)
            
            //--TRIMMABLE-BOUNDARY-START(274879611002)
            /*string*/ static SameSiteLaxToken = null;
            //--TRIMMABLE-BOUNDARY-END(274879611002)
            
            //--TRIMMABLE-BOUNDARY-START(283469545594)
            /*string*/ static SameSiteStrictToken = null;
            //--TRIMMABLE-BOUNDARY-END(283469545594)
            
            //--TRIMMABLE-BOUNDARY-START(219045036154)
            /*string*/ static HttpOnlyToken = null;
            //--TRIMMABLE-BOUNDARY-END(219045036154)
            
            //--TRIMMABLE-BOUNDARY-START(300649414778)
            /*string*/ static SeparatorToken = null;
            //--TRIMMABLE-BOUNDARY-END(300649414778)
            
            //--TRIMMABLE-BOUNDARY-START(94490984570)
            /*string*/ static EqualsToken = null;
            //--TRIMMABLE-BOUNDARY-END(94490984570)
            
            //--TRIMMABLE-BOUNDARY-START(107375886458)
            /*int*/ static ExpiresDateLength = 29;
            //--TRIMMABLE-BOUNDARY-END(107375886458)
            
            //--TRIMMABLE-BOUNDARY-START(103080919162)
            /*string*/ static ExpiresDateFormat = null;
            //--TRIMMABLE-BOUNDARY-END(103080919162)
            
            //--TRIMMABLE-BOUNDARY-START(382253793402)
            /*HttpHeaderParser<SetCookieHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(382253793402)
            
            //--TRIMMABLE-BOUNDARY-START(231929938042)
            /*HttpHeaderParser<SetCookieHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(231929938042)
            
            //--TRIMMABLE-BOUNDARY-START(8591638650)
            /*StringSegment*/ _name;
            //--TRIMMABLE-BOUNDARY-END(8591638650)
            
            //--TRIMMABLE-BOUNDARY-START(12886605946)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(12886605946)
            
            //--TRIMMABLE-BOUNDARY-START(4296671354)
            /*List<StringSegment>?*/ _extensions = null;
            //--TRIMMABLE-BOUNDARY-END(4296671354)
            
            //--TRIMMABLE-BOUNDARY-START(51541311610)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541311610);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541311610)
            
            //--TRIMMABLE-BOUNDARY-START(60131246202)
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.MEP.StringSegment.Empty);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131246202);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60131246202)
            
            //--TRIMMABLE-BOUNDARY-START(55836278906)
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836278906);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$mep.MEP.StringSegment.op_Equality(name, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                    }
                    if ($.$mep.MEP.StringSegment.op_Equality(value, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("value");
                    }
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55836278906)
            
            //--TRIMMABLE-BOUNDARY-START(236224905338)
            /*StringSegment */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505428602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*StringSegment */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599087738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.CookieHeaderValue.CheckNameFormat(value, "value");
                this._name = value;
            }
            //--TRIMMABLE-BOUNDARY-END(236224905338)
            
            //--TRIMMABLE-BOUNDARY-START(403728629882)
            /*StringSegment */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865166970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958826106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.CookieHeaderValue.CheckValueFormat(value, "value");
                this._value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(403728629882)
            
            //--TRIMMABLE-BOUNDARY-START(98785951866)
            /*DateTimeOffset?*/ Expires = null;
            //--TRIMMABLE-BOUNDARY-END(98785951866)
            
            //--TRIMMABLE-BOUNDARY-START(223340003450)
            /*TimeSpan?*/ MaxAge = null;
            //--TRIMMABLE-BOUNDARY-END(223340003450)
            
            //--TRIMMABLE-BOUNDARY-START(81606082682)
            /*StringSegment*/ Domain;
            //--TRIMMABLE-BOUNDARY-END(81606082682)
            
            //--TRIMMABLE-BOUNDARY-START(253404774522)
            /*StringSegment*/ Path;
            //--TRIMMABLE-BOUNDARY-END(253404774522)
            
            //--TRIMMABLE-BOUNDARY-START(292059480186)
            /*bool*/ Secure = false;
            //--TRIMMABLE-BOUNDARY-END(292059480186)
            
            //--TRIMMABLE-BOUNDARY-START(270584643706)
            /*SameSiteMode*/ SameSite = 0;
            //--TRIMMABLE-BOUNDARY-END(270584643706)
            
            //--TRIMMABLE-BOUNDARY-START(214750068858)
            /*bool*/ HttpOnly = false;
            //--TRIMMABLE-BOUNDARY-END(214750068858)
            
            //--TRIMMABLE-BOUNDARY-START(115965821050)
            /*IList<StringSegment> */ get Extensions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735624826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._extensions ??= new ($.$$.SCG.List$$($.$mep.MEP.StringSegment))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(115965821050)
            
            //--TRIMMABLE-BOUNDARY-START(386548760698)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548760698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let length = ((((this._name.Length + "="/*EqualsToken*/.length) | 0) + this._value.Length) | 0);
                /*string?*/ let maxAge = null;
                /*string?*/ let sameSite = null;
                if ($.$$.S.Nullable$$($.$$.S.DateTimeOffset).HasValue$get.call(this.Expires))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "expires"/*ExpiresToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + 29/*ExpiresDateLength*/) | 0);
                }
                if ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this.MaxAge))
                {
                    maxAge = $.$mnhh.MNHH.HeaderUtilities.FormatInt64($.$cast($.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this.MaxAge).TotalSeconds, $.$$.S.Int64));
                    length += (((((("; "/*SeparatorToken*/.length + "max-age"/*MaxAgeToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + maxAge.length) | 0);
                }
                if ($.$mep.MEP.StringSegment.op_Inequality(this.Domain, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "domain"/*DomainToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + this.Domain.Length) | 0);
                }
                if ($.$mep.MEP.StringSegment.op_Inequality(this.Path, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "path"/*PathToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + this.Path.Length) | 0);
                }
                if (this.Secure)
                {
                    length += (("; "/*SeparatorToken*/.length + "secure"/*SecureToken*/.length) | 0);
                }
                if (this.SameSite === 0/*SameSiteMode.None*/)
                {
                    sameSite = $.$mnhh.MNHH.SetCookieHeaderValue.SameSiteNoneToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                else if (this.SameSite === 1/*SameSiteMode.Lax*/)
                {
                    sameSite = $.$mnhh.MNHH.SetCookieHeaderValue.SameSiteLaxToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                else if (this.SameSite === 2/*SameSiteMode.Strict*/)
                {
                    sameSite = $.$mnhh.MNHH.SetCookieHeaderValue.SameSiteStrictToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                if (this.HttpOnly)
                {
                    length += (("; "/*SeparatorToken*/.length + "httponly"/*HttpOnlyToken*/.length) | 0);
                }
                if ($.$$.S.Int32.op_GreaterThan((this._extensions?.Count ?? null), 0))
                {
                    let $en1 = this._extensions.GetEnumerator();
                    while ($en1.MoveNext())
                    {
                        let extension = $en1.Current;
                        {
                            length += (("; "/*SeparatorToken*/.length + extension.Length) | 0);
                        }
                    }
                }
                return $.$$.S.String.Create$10($.$$.S.ValueTuple$$$$($.$mnhh.MNHH.SetCookieHeaderValue, $.$$.S.String, $.$$.S.String), length, new ($.$$.S.ValueTuple$$$$($.$mnhh.MNHH.SetCookieHeaderValue, $.$$.S.String, $.$$.S.String))().$ctor$3(this, maxAge, sameSite), new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$$.S.ValueTuple$$$$($.$mnhh.MNHH.SetCookieHeaderValue, $.$$.S.String, $.$$.S.String)))().$ctor(this,  (/*span*/ span, /*tuple*/ tuple) =>
                {
                    /*var*/ let  [ headerValue, maxAgeValue, sameSite ] = $.$destructure(tuple, 3);
                    $.$mnhh.MNHH.SetCookieHeaderValue.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$mep.MEP.StringSegment.op_Implicit$1(headerValue._name));
                    $.$mnhh.MNHH.SetCookieHeaderValue.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$$.S.String.op_Implicit("="/*EqualsToken*/));
                    $.$mnhh.MNHH.SetCookieHeaderValue.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$mep.MEP.StringSegment.op_Implicit$1(headerValue._value));
                    let expiresValue;
                    if ($.$is(headerValue.Expires, $.$$.S.DateTimeOffset, { set $v($v){ expiresValue = $v; } }))
                    {
                        /*var*/ let charsWritten;
                        $.$mnhh.MNHH.SetCookieHeaderValue.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$$.S.String.op_Implicit("; "/*SeparatorToken*/));
                        $.$mnhh.MNHH.SetCookieHeaderValue.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$$.S.String.op_Implicit("expires"/*ExpiresToken*/));
                        $.$mnhh.MNHH.SetCookieHeaderValue.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$$.S.String.op_Implicit("="/*EqualsToken*/));
                        /*var*/ let formatted = expiresValue.TryFormat$1(span, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.S.Int32), $.$$.S.String.op_Implicit("r"/*ExpiresDateFormat*/), $.$$.SG.CultureInfo.InvariantCulture);
                        span = span.Slice$1(charsWritten);
                        $.$$.SD.Debug.Assert$4(formatted, "formatted");
                    }
                    if (maxAgeValue !== null)
                    {
                        $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$mep.MEP.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), $.$mep.MEP.StringSegment.op_Implicit$2(maxAgeValue));
                    }
                    if ($.$mep.MEP.StringSegment.op_Inequality(headerValue.Domain, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                    {
                        $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$mep.MEP.StringSegment.op_Implicit$2("domain"/*DomainToken*/), headerValue.Domain);
                    }
                    if ($.$mep.MEP.StringSegment.op_Inequality(headerValue.Path, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                    {
                        $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$mep.MEP.StringSegment.op_Implicit$2("path"/*PathToken*/), headerValue.Path);
                    }
                    if (headerValue.Secure)
                    {
                        $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$mep.MEP.StringSegment.op_Implicit$2("secure"/*SecureToken*/), $.$mep.MEP.StringSegment.op_Implicit$2(null));
                    }
                    if (sameSite !== null)
                    {
                        $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$mep.MEP.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.MEP.StringSegment.op_Implicit$2(sameSite));
                    }
                    if (headerValue.HttpOnly)
                    {
                        $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), $.$mep.MEP.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), $.$mep.MEP.StringSegment.op_Implicit$2(null));
                    }
                    if ($.$$.S.Int32.op_GreaterThan((this._extensions?.Count ?? null), 0))
                    {
                        let $en15 = this._extensions.GetEnumerator();
                        while ($en15.MoveNext())
                        {
                            let extension = $en15.Current;
                            {
                                $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Char), () => span, ($v) => span = $v, null, true), extension, $.$mep.MEP.StringSegment.op_Implicit$2(null));
                            }
                        }
                    }
                }, $vTTcWc ??= {"r":65537,"p":[{"n":"span","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"tuple","p":$.$$.S.ValueTuple$$$$($.$mnhh.MNHH.SetCookieHeaderValue, $.$$.S.String, $.$$.S.String).$h}],"n":"","d":1704058,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(386548760698)
            
            //--TRIMMABLE-BOUNDARY-START(68721180794)
            static /*void */ AppendSegment(/*ref Span<char>*/ span, /*StringSegment*/ name, /*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721180794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.SetCookieHeaderValue.Append(span, $.$$.S.String.op_Implicit("; "/*SeparatorToken*/));
                $.$mnhh.MNHH.SetCookieHeaderValue.Append(span, name.AsSpan());
                if ($.$mep.MEP.StringSegment.op_Inequality(value, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.Append(span, $.$$.S.String.op_Implicit("="/*EqualsToken*/));
                    $.$mnhh.MNHH.SetCookieHeaderValue.Append(span, value.AsSpan());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721180794)
            
            //--TRIMMABLE-BOUNDARY-START(64426213498)
            static /*void */ Append(/*ref Span<char>*/ span, /*ReadOnlySpan<char>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426213498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                other.CopyTo(span.$v);
                span.$v = span.$v.Slice$1(other.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(64426213498)
            
            //--TRIMMABLE-BOUNDARY-START(77311115386)
            /*void */ AppendToStringBuilder(/*StringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311115386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.Append$17(this._name.AsSpan());
                builder.Append$5(/*=*/ 61);
                builder.Append$17(this._value.AsSpan());
                if ($.$$.S.Nullable$$($.$$.S.DateTimeOffset).HasValue$get.call(this.Expires))
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("expires"/*ExpiresToken*/), $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.HeaderUtilities.FormatDate$1($.$$.S.Nullable$$($.$$.S.DateTimeOffset).GetValueOrDefault.call(this.Expires))));
                }
                if ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this.MaxAge))
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.HeaderUtilities.FormatInt64($.$cast($.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(this.MaxAge).TotalSeconds, $.$$.S.Int64))));
                }
                if ($.$mep.MEP.StringSegment.op_Inequality(this.Domain, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("domain"/*DomainToken*/), this.Domain);
                }
                if ($.$mep.MEP.StringSegment.op_Inequality(this.Path, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("path"/*PathToken*/), this.Path);
                }
                if (this.Secure)
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("secure"/*SecureToken*/), $.$mep.MEP.StringSegment.op_Implicit$2(null));
                }
                if (this.SameSite === 0/*SameSiteMode.None*/)
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.SetCookieHeaderValue.SameSiteNoneToken));
                }
                else if (this.SameSite === 1/*SameSiteMode.Lax*/)
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.SetCookieHeaderValue.SameSiteLaxToken));
                }
                else if (this.SameSite === 2/*SameSiteMode.Strict*/)
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.SetCookieHeaderValue.SameSiteStrictToken));
                }
                if (this.HttpOnly)
                {
                    $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, $.$mep.MEP.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), $.$mep.MEP.StringSegment.op_Implicit$2(null));
                }
                if ($.$$.S.Int32.op_GreaterThan((this._extensions?.Count ?? null), 0))
                {
                    let $en21 = this._extensions.GetEnumerator();
                    while ($en21.MoveNext())
                    {
                        let extension = $en21.Current;
                        {
                            $.$mnhh.MNHH.SetCookieHeaderValue.AppendSegment$1(builder, extension, $.$mep.MEP.StringSegment.op_Implicit$2(null));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311115386)
            
            //--TRIMMABLE-BOUNDARY-START(73016148090)
            static /*void */ AppendSegment$1(/*StringBuilder*/ builder, /*StringSegment*/ name, /*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016148090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.Append$21("; ");
                builder.Append$17(name.AsSpan());
                if ($.$mep.MEP.StringSegment.op_Inequality(value, $.$mep.MEP.StringSegment.op_Implicit$2(null)))
                {
                    builder.Append$5(/*=*/ 61);
                    builder.Append$17(value.AsSpan());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016148090)
            
            //--TRIMMABLE-BOUNDARY-START(240519872634)
            static /*SetCookieHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519872634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.SetCookieHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(240519872634)
            
            //--TRIMMABLE-BOUNDARY-START(390843727994)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out SetCookieHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843727994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.SetCookieHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(390843727994)
            
            //--TRIMMABLE-BOUNDARY-START(244814839930)
            static /*IList<SetCookieHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814839930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.SetCookieHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(244814839930)
            
            //--TRIMMABLE-BOUNDARY-START(249109807226)
            static /*IList<SetCookieHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109807226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.SetCookieHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(249109807226)
            
            //--TRIMMABLE-BOUNDARY-START(395138695290)
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<SetCookieHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138695290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.SetCookieHeaderValue.MultipleValueParser.TryParseValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(395138695290)
            
            //--TRIMMABLE-BOUNDARY-START(399433662586)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<SetCookieHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433662586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.SetCookieHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(399433662586)
            
            //--TRIMMABLE-BOUNDARY-START(210455101562)
            static /*int */ GetSetCookieLength(/*StringSegment*/ input, /*int*/ startIndex, /*out SetCookieHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455101562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                /*var*/ let offset = startIndex;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (offset >= input.Length))
                {
                    return 0;
                }
                /*var*/ let result = new $.$mnhh.MNHH.SetCookieHeaderValue().$ctor$1();
                /*var*/ let itemLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, offset);
                if (itemLength === 0)
                {
                    return 0;
                }
                result._name = input.Subsegment(offset, itemLength);
                offset += itemLength;
                if (!$.$mnhh.MNHH.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32)))
                {
                    return 0;
                }
                result._value = $.$mnhh.MNHH.CookieHeaderParserShared.GetCookieValue(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32));
                while(offset < input.Length)
                {
                    if (input.get_Item$1(offset) === /*,*/ 44)
                    {
                        break;
                    }
                    if (input.get_Item$1(offset) !== /*;*/ 59)
                    {
                        return 0;
                    }
                    offset++;
                    offset += $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, offset);
                    itemLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, offset);
                    if (itemLength === 0)
                    {
                        break;
                    }
                    /*var*/ let token = input.Subsegment(offset, itemLength);
                    offset += itemLength;
                    if ($.$mep.MEP.StringSegment.Equals$5(token, $.$mep.MEP.StringSegment.op_Implicit$2("expires"/*ExpiresToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.MNHH.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32)))
                        {
                            return 0;
                        }
                        /*var*/ let dateString = $.$mnhh.MNHH.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32), false);
                        /*DateTimeOffset*/ let expirationDate;
                        if (!$.$mnhh.MNHH.HttpRuleParser.TryStringToDate(dateString, $.$ref(() => expirationDate, ($v) => expirationDate = $v, $.$$.S.DateTimeOffset)))
                        {
                            return 0;
                        }
                        result.Expires = expirationDate;
                    }
                    else if ($.$mep.MEP.StringSegment.Equals$5(token, $.$mep.MEP.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.MNHH.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32)))
                        {
                            return 0;
                        }
                        /*var*/ let isNegative = false;
                        if (input.get_Item$1(offset) === /*-*/ 45)
                        {
                            isNegative = true;
                            offset++;
                        }
                        itemLength = $.$mnhh.MNHH.HttpRuleParser.GetNumberLength(input, offset, false);
                        if (itemLength === 0)
                        {
                            return 0;
                        }
                        /*var*/ let numberString = input.Subsegment(offset, itemLength);
                        /*long*/ let maxAge;
                        if (!$.$mnhh.MNHH.HeaderUtilities.TryParseNonNegativeInt64(numberString, $.$ref(() => maxAge, ($v) => maxAge = $v, $.$$.S.Int64)))
                        {
                            return 0;
                        }
                        if (isNegative)
                        {
                            maxAge = -maxAge;
                        }
                        result.MaxAge = $.$$.S.TimeSpan.FromSeconds$2(maxAge);
                        offset += itemLength;
                    }
                    else if ($.$mep.MEP.StringSegment.Equals$5(token, $.$mep.MEP.StringSegment.op_Implicit$2("domain"/*DomainToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.MNHH.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32)))
                        {
                            return 0;
                        }
                        result.Domain = $.$mnhh.MNHH.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32), true);
                    }
                    else if ($.$mep.MEP.StringSegment.Equals$5(token, $.$mep.MEP.StringSegment.op_Implicit$2("path"/*PathToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.MNHH.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32)))
                        {
                            return 0;
                        }
                        result.Path = $.$mnhh.MNHH.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32), true);
                    }
                    else if ($.$mep.MEP.StringSegment.Equals$5(token, $.$mep.MEP.StringSegment.op_Implicit$2("secure"/*SecureToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        result.Secure = true;
                    }
                    else if ($.$mep.MEP.StringSegment.Equals$5(token, $.$mep.MEP.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.MNHH.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32)))
                        {
                            result.SameSite = -1/*SameSiteMode.Unspecified*/;
                        }
                        else 
                        {
                            /*var*/ let enforcementMode = $.$mnhh.MNHH.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32), true);
                            if ($.$mep.MEP.StringSegment.Equals$5(enforcementMode, $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.SetCookieHeaderValue.SameSiteStrictToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 2/*SameSiteMode.Strict*/;
                            }
                            else if ($.$mep.MEP.StringSegment.Equals$5(enforcementMode, $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.SetCookieHeaderValue.SameSiteLaxToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 1/*SameSiteMode.Lax*/;
                            }
                            else if ($.$mep.MEP.StringSegment.Equals$5(enforcementMode, $.$mep.MEP.StringSegment.op_Implicit$2($.$mnhh.MNHH.SetCookieHeaderValue.SameSiteNoneToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 0/*SameSiteMode.None*/;
                            }
                            else 
                            {
                                result.SameSite = -1/*SameSiteMode.Unspecified*/;
                            }
                        }
                    }
                    else if ($.$mep.MEP.StringSegment.Equals$5(token, $.$mep.MEP.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        result.HttpOnly = true;
                    }
                    else 
                    {
                        /*var*/ let tokenStart = ((offset - itemLength) | 0);
                        $.$mnhh.MNHH.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32), true);
                        result.Extensions.SCG$ICollection$$$Add(input.Subsegment(tokenStart, ((offset - tokenStart) | 0)));
                    }
                }
                parsedValue.$v = result;
                return ((offset - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(210455101562)
            
            //--TRIMMABLE-BOUNDARY-START(261994709114)
            static /*bool */ ReadEqualsSign(/*StringSegment*/ input, /*ref int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994709114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset.$v >= input.Length || input.get_Item$1(offset.$v) !== /*=*/ 61)
                {
                    return false;
                }
                offset.$v++;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(261994709114)
            
            //--TRIMMABLE-BOUNDARY-START(266289676410)
            static /*StringSegment */ ReadToSemicolonOrEnd(/*StringSegment*/ input, /*ref int*/ offset, /*bool*/ includeComma)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289676410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let end = input.IndexOf$1(/*;*/ 59, offset.$v);
                if (end < 0)
                {
                    if (includeComma)
                    {
                        end = input.IndexOf$1(/*,*/ 44, offset.$v);
                    }
                }
                else if (includeComma)
                {
                    /*var*/ let commaPosition = input.IndexOf$1(/*,*/ 44, offset.$v);
                    if (commaPosition >= 0 && commaPosition < end)
                    {
                        end = commaPosition;
                    }
                }
                if (end < 0)
                {
                    end = input.Length;
                }
                /*var*/ let itemLength = ((end - offset.$v) | 0);
                /*var*/ let result = input.Subsegment(offset.$v, itemLength);
                offset.$v += itemLength;
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(266289676410)
            
            //--TRIMMABLE-BOUNDARY-START(90196017274)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196017274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.SetCookieHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.MEP.StringSegment.Equals$5(this._name, other._name, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.MEP.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/) && this.Expires.Equals$1(other.Expires) && this.MaxAge.Equals$1(other.MaxAge) && $.$mep.MEP.StringSegment.Equals$5(this.Domain, other.Domain, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.MEP.StringSegment.Equals$5(this.Path, other.Path, 5/*StringComparison.OrdinalIgnoreCase*/) && this.Secure === other.Secure && this.SameSite === other.SameSite && this.HttpOnly === other.HttpOnly && $.$mnhh.MNHH.HeaderUtilities.AreEqualCollections($.$mep.MEP.StringSegment, this._extensions, other._extensions, $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase);
            }
            //--TRIMMABLE-BOUNDARY-END(90196017274)
            
            //--TRIMMABLE-BOUNDARY-START(206160134266)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160134266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hash = $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._name) ^ $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value) ^ ($.$$.S.Nullable$$($.$$.S.DateTimeOffset).HasValue$get.call(this.Expires) ? this.Expires.GetHashCode() : 0) ^ ($.$$.S.Nullable$$($.$$.S.TimeSpan).HasValue$get.call(this.MaxAge) ? this.MaxAge.GetHashCode() : 0) ^ ($.$mep.MEP.StringSegment.op_Inequality(this.Domain, $.$mep.MEP.StringSegment.op_Implicit$2(null)) ? $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Domain) : 0) ^ ($.$mep.MEP.StringSegment.op_Inequality(this.Path, $.$mep.MEP.StringSegment.op_Implicit$2(null)) ? $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Path) : 0) ^ $.$$.S.Boolean.GetHashCode.call(this.Secure) ^ this.SameSite ^ $.$$.S.Boolean.GetHashCode.call(this.HttpOnly);
                if ($.$$.S.Int32.op_GreaterThan((this._extensions?.Count ?? null), 0))
                {
                    let $en41 = this._extensions.GetEnumerator();
                    while ($en41.MoveNext())
                    {
                        let extension = $en41.Current;
                        {
                            hash ^= extension.GetHashCode();
                        }
                    }
                }
                return hash;
            }
            //--TRIMMABLE-BOUNDARY-END(206160134266)
            
            //--TRIMMABLE-BOUNDARY-START(51541311610)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(51541311610)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591638650)
                this._name = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591638650)
                
                //--TRIMMABLE-BOUNDARY-START(12886605946)
                this._value = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(12886605946)
                
                //--TRIMMABLE-BOUNDARY-START(98785951866)
                this.Expires = null;
                //--TRIMMABLE-BOUNDARY-END(98785951866)
                
                //--TRIMMABLE-BOUNDARY-START(223340003450)
                this.MaxAge = null;
                //--TRIMMABLE-BOUNDARY-END(223340003450)
                
                //--TRIMMABLE-BOUNDARY-START(81606082682)
                this.Domain = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(81606082682)
                
                //--TRIMMABLE-BOUNDARY-START(253404774522)
                this.Path = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(253404774522)
                
                //--TRIMMABLE-BOUNDARY-START(270584643706)
                this.SameSite = -1;
                //--TRIMMABLE-BOUNDARY-END(270584643706)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47246344314)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246344314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(111670853754)
                    this.ExpiresToken = "expires";
                    //--TRIMMABLE-BOUNDARY-END(111670853754)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227634970746)
                    this.MaxAgeToken = "max-age";
                    //--TRIMMABLE-BOUNDARY-END(227634970746)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85901049978)
                    this.DomainToken = "domain";
                    //--TRIMMABLE-BOUNDARY-END(85901049978)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257699741818)
                    this.PathToken = "path";
                    //--TRIMMABLE-BOUNDARY-END(257699741818)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296354447482)
                    this.SecureToken = "secure";
                    //--TRIMMABLE-BOUNDARY-END(296354447482)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287764512890)
                    this.SameSiteToken = "samesite";
                    //--TRIMMABLE-BOUNDARY-END(287764512890)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279174578298)
                    this.SameSiteNoneToken = "None".toLowerCase();
                    //--TRIMMABLE-BOUNDARY-END(279174578298)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274879611002)
                    this.SameSiteLaxToken = "Lax".toLowerCase();
                    //--TRIMMABLE-BOUNDARY-END(274879611002)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283469545594)
                    this.SameSiteStrictToken = "Strict".toLowerCase();
                    //--TRIMMABLE-BOUNDARY-END(283469545594)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219045036154)
                    this.HttpOnlyToken = "httponly";
                    //--TRIMMABLE-BOUNDARY-END(219045036154)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300649414778)
                    this.SeparatorToken = "; ";
                    //--TRIMMABLE-BOUNDARY-END(300649414778)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490984570)
                    this.EqualsToken = "=";
                    //--TRIMMABLE-BOUNDARY-END(94490984570)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080919162)
                    this.ExpiresDateFormat = "r";
                    //--TRIMMABLE-BOUNDARY-END(103080919162)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(382253793402)
                    this.SingleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.SetCookieHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.SetCookieHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.SetCookieHeaderValue, $.$mnhh.MNHH.SetCookieHeaderValue.GetSetCookieLength));
                    //--TRIMMABLE-BOUNDARY-END(382253793402)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929938042)
                    this.MultipleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.SetCookieHeaderValue))().$ctor$3(true, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.SetCookieHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.SetCookieHeaderValue, $.$mnhh.MNHH.SetCookieHeaderValue.GetSetCookieLength));
                    //--TRIMMABLE-BOUNDARY-END(231929938042)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246344314)
            
            static $h = 1704058;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(236224905338),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505428602,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343599087738,
        "f": 83886081
      },
      "n": "Name",
      "d": 1704058,
      "h": 236224905338,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224905338),
//--TRIMMABLE-BOUNDARY-START(403728629882),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865166970,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377958826106,
        "f": 83886081
      },
      "n": "Value",
      "d": 1704058,
      "h": 403728629882,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403728629882),
//--TRIMMABLE-BOUNDARY-START(98785951866),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145690234,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317829283962,
        "f": 83886081
      },
      "n": "Expires",
      "d": 1704058,
      "h": 98785951866,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785951866),
//--TRIMMABLE-BOUNDARY-START(223340003450),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915494010,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335009153146,
        "f": 83886081
      },
      "n": "MaxAge",
      "d": 1704058,
      "h": 223340003450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223340003450),
//--TRIMMABLE-BOUNDARY-START(81606082682),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555755642,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309239349370,
        "f": 83886081
      },
      "n": "Domain",
      "d": 1704058,
      "h": 81606082682,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606082682),
//--TRIMMABLE-BOUNDARY-START(253404774522),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095363194,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352189022330,
        "f": 83886081
      },
      "n": "Path",
      "d": 1704058,
      "h": 253404774522,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253404774522),
//--TRIMMABLE-BOUNDARY-START(292059480186),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275232378,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369368891514,
        "f": 83886081
      },
      "n": "Secure",
      "d": 1704058,
      "h": 292059480186,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292059480186),
//--TRIMMABLE-BOUNDARY-START(270584643706),
    {
      "p": 1638522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685297786,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360778956922,
        "f": 83886081
      },
      "n": "SameSite",
      "d": 1704058,
      "h": 270584643706,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270584643706),
//--TRIMMABLE-BOUNDARY-START(214750068858),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325559418,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326419218554,
        "f": 83886081
      },
      "n": "HttpOnly",
      "d": 1704058,
      "h": 214750068858,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214750068858),
//--TRIMMABLE-BOUNDARY-START(115965821050),
    {
      "p": $.$$.SCG.IList$$($.$mep.MEP.StringSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735624826,
        "f": 50331649
      },
      "n": "Extensions",
      "d": 1704058,
      "h": 115965821050,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965821050)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(386548760698),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1704058,
      "h": 386548760698,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(386548760698),
//--TRIMMABLE-BOUNDARY-START(68721180794),
    {
      "r": 65537,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.Span$$($.$$.S.Char).$h,
          "f": 4
        },
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "AppendSegment",
      "d": 1704058,
      "h": 68721180794,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68721180794),
//--TRIMMABLE-BOUNDARY-START(64426213498),
    {
      "r": 65537,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.Span$$($.$$.S.Char).$h,
          "f": 4
        },
        {
          "n": "other",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "Append",
      "d": 1704058,
      "h": 64426213498,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64426213498),
//--TRIMMABLE-BOUNDARY-START(77311115386),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        }
      ],
      "n": "AppendToStringBuilder",
      "d": 1704058,
      "h": 77311115386,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311115386),
//--TRIMMABLE-BOUNDARY-START(73016148090),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        },
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "AppendSegment",
      "o": "@$1",
      "d": 1704058,
      "h": 73016148090,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73016148090),
//--TRIMMABLE-BOUNDARY-START(240519872634),
    {
      "r": 1704058,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1704058,
      "h": 240519872634,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(240519872634),
//--TRIMMABLE-BOUNDARY-START(390843727994),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1704058,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1704058,
      "h": 390843727994,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(390843727994),
//--TRIMMABLE-BOUNDARY-START(244814839930),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.SetCookieHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseList",
      "d": 1704058,
      "h": 244814839930,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(244814839930),
//--TRIMMABLE-BOUNDARY-START(249109807226),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.SetCookieHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 1704058,
      "h": 249109807226,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(249109807226),
//--TRIMMABLE-BOUNDARY-START(395138695290),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.SetCookieHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 1704058,
      "h": 395138695290,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(395138695290),
//--TRIMMABLE-BOUNDARY-START(399433662586),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.SetCookieHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 1704058,
      "h": 399433662586,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(399433662586),
//--TRIMMABLE-BOUNDARY-START(210455101562),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1704058,
          "f": 2
        }
      ],
      "n": "GetSetCookieLength",
      "d": 1704058,
      "h": 210455101562,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(210455101562),
//--TRIMMABLE-BOUNDARY-START(261994709114),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "ReadEqualsSign",
      "d": 1704058,
      "h": 261994709114,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(261994709114),
//--TRIMMABLE-BOUNDARY-START(266289676410),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        },
        {
          "n": "includeComma",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "ReadToSemicolonOrEnd",
      "d": 1704058,
      "h": 266289676410,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(266289676410),
//--TRIMMABLE-BOUNDARY-START(90196017274),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1704058,
      "h": 90196017274,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196017274),
//--TRIMMABLE-BOUNDARY-START(206160134266),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1704058,
      "h": 206160134266,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(206160134266)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(111670853754),
    {
      "t": 1310721,
      "n": "ExpiresToken",
      "d": 1704058,
      "h": 111670853754,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(111670853754),
//--TRIMMABLE-BOUNDARY-START(227634970746),
    {
      "t": 1310721,
      "n": "MaxAgeToken",
      "d": 1704058,
      "h": 227634970746,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(227634970746),
//--TRIMMABLE-BOUNDARY-START(85901049978),
    {
      "t": 1310721,
      "n": "DomainToken",
      "d": 1704058,
      "h": 85901049978,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85901049978),
//--TRIMMABLE-BOUNDARY-START(257699741818),
    {
      "t": 1310721,
      "n": "PathToken",
      "d": 1704058,
      "h": 257699741818,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(257699741818),
//--TRIMMABLE-BOUNDARY-START(296354447482),
    {
      "t": 1310721,
      "n": "SecureToken",
      "d": 1704058,
      "h": 296354447482,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(296354447482),
//--TRIMMABLE-BOUNDARY-START(287764512890),
    {
      "t": 1310721,
      "n": "SameSiteToken",
      "d": 1704058,
      "h": 287764512890,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(287764512890),
//--TRIMMABLE-BOUNDARY-START(279174578298),
    {
      "t": 1310721,
      "n": "SameSiteNoneToken",
      "d": 1704058,
      "h": 279174578298,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(279174578298),
//--TRIMMABLE-BOUNDARY-START(274879611002),
    {
      "t": 1310721,
      "n": "SameSiteLaxToken",
      "d": 1704058,
      "h": 274879611002,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(274879611002),
//--TRIMMABLE-BOUNDARY-START(283469545594),
    {
      "t": 1310721,
      "n": "SameSiteStrictToken",
      "d": 1704058,
      "h": 283469545594,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(283469545594),
//--TRIMMABLE-BOUNDARY-START(219045036154),
    {
      "t": 1310721,
      "n": "HttpOnlyToken",
      "d": 1704058,
      "h": 219045036154,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(219045036154),
//--TRIMMABLE-BOUNDARY-START(300649414778),
    {
      "t": 1310721,
      "n": "SeparatorToken",
      "d": 1704058,
      "h": 300649414778,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(300649414778),
//--TRIMMABLE-BOUNDARY-START(94490984570),
    {
      "t": 1310721,
      "n": "EqualsToken",
      "d": 1704058,
      "h": 94490984570,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(94490984570),
//--TRIMMABLE-BOUNDARY-START(107375886458),
    {
      "t": 655361,
      "n": "ExpiresDateLength",
      "d": 1704058,
      "h": 107375886458,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(107375886458),
//--TRIMMABLE-BOUNDARY-START(103080919162),
    {
      "t": 1310721,
      "n": "ExpiresDateFormat",
      "d": 1704058,
      "h": 103080919162,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103080919162),
//--TRIMMABLE-BOUNDARY-START(382253793402),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.SetCookieHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 1704058,
      "h": 382253793402,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(382253793402),
//--TRIMMABLE-BOUNDARY-START(231929938042),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.SetCookieHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 1704058,
      "h": 231929938042,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(231929938042),
//--TRIMMABLE-BOUNDARY-START(8591638650),
    {
      "t": 852053,
      "n": "_name",
      "d": 1704058,
      "h": 8591638650,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638650),
//--TRIMMABLE-BOUNDARY-START(12886605946),
    {
      "t": 852053,
      "n": "_value",
      "d": 1704058,
      "h": 12886605946,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886605946),
//--TRIMMABLE-BOUNDARY-START(4296671354),
    {
      "t": $.$$.SCG.List$$($.$mep.MEP.StringSegment).$h,
      "n": "_extensions",
      "d": 1704058,
      "h": 4296671354,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671354)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51541311610),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1704058,
      "h": 51541311610,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541311610),
//--TRIMMABLE-BOUNDARY-START(60131246202),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704058,
      "h": 60131246202,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131246202),
//--TRIMMABLE-BOUNDARY-START(55836278906),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1704058,
      "h": 55836278906,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836278906)
  ],
  "h": 1704058
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.SetCookieHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}SetCookieHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704058)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310842)
        $asm.$cls(`$mnhh.MNHH.NameValueHeaderValue`, ($self) => class NameValueHeaderValue extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(150325166202)
            /*HttpHeaderParser<NameValueHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(150325166202)
            
            //--TRIMMABLE-BOUNDARY-START(115965427834)
            /*HttpHeaderParser<NameValueHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(115965427834)
            
            //--TRIMMABLE-BOUNDARY-START(8591245434)
            /*StringSegment*/ _name;
            //--TRIMMABLE-BOUNDARY-END(8591245434)
            
            //--TRIMMABLE-BOUNDARY-START(12886212730)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(12886212730)
            
            //--TRIMMABLE-BOUNDARY-START(4296278138)
            /*bool*/ _isReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(4296278138)
            
            //--TRIMMABLE-BOUNDARY-START(21476147322)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476147322);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476147322)
            
            //--TRIMMABLE-BOUNDARY-START(30066081914)
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.MEP.StringSegment.op_Implicit$2(null));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066081914);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066081914)
            
            //--TRIMMABLE-BOUNDARY-START(25771114618)
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771114618);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.MNHH.NameValueHeaderValue.CheckNameValueFormat(name, value);
                    this._name = name;
                    this._value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771114618)
            
            //--TRIMMABLE-BOUNDARY-START(120260395130)
            /*StringSegment */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015754874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            //--TRIMMABLE-BOUNDARY-END(120260395130)
            
            //--TRIMMABLE-BOUNDARY-START(180389937274)
            /*StringSegment */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605689466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735231610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.MNHH.NameValueHeaderValue.CheckValueFormat(value);
                this._value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(180389937274)
            
            //--TRIMMABLE-BOUNDARY-START(111670460538)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425820282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._isReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(111670460538)
            
            //--TRIMMABLE-BOUNDARY-START(42950983802)
            /*NameValueHeaderValue */ Copy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$mnhh.MNHH.NameValueHeaderValue()
                    const $t1 = $.$mnhh.MNHH.NameValueHeaderValue;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1._name = this._name;
                    $i1._value = this._value;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(42950983802)
            
            //--TRIMMABLE-BOUNDARY-START(47245951098)
            /*NameValueHeaderValue */ CopyAsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245951098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    return this;
                }
                return (() =>
                {
                    //new $.$mnhh.MNHH.NameValueHeaderValue()
                    const $t2 = $.$mnhh.MNHH.NameValueHeaderValue;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2._name = this._name;
                    $i2._value = this._value;
                    $i2._isReadOnly = true;
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(47245951098)
            
            //--TRIMMABLE-BOUNDARY-START(85900656762)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900656762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SDC$1.Contract.Assert$1($.$mep.MEP.StringSegment.op_Inequality(this._name, $.$mep.MEP.StringSegment.op_Implicit$2(null)));
                /*var*/ let nameHashCode = $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._name);
                if (!$.$mep.MEP.StringSegment.IsNullOrEmpty(this._value))
                {
                    if (this._value.get_Item$1(0) === /*\"*/ 34)
                    {
                        return nameHashCode ^ this._value.GetHashCode();
                    }
                    return nameHashCode ^ $.$mep.MEP.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value);
                }
                return nameHashCode;
            }
            //--TRIMMABLE-BOUNDARY-END(85900656762)
            
            //--TRIMMABLE-BOUNDARY-START(51540918394)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.MNHH.NameValueHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (!this._name.Equals$4(other._name, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(this._value))
                {
                    return $.$mep.MEP.StringSegment.IsNullOrEmpty(other._value);
                }
                if (this._value.get_Item$1(0) === /*\"*/ 34)
                {
                    return (this._value.Equals$4(other._value, 4/*StringComparison.Ordinal*/));
                }
                else 
                {
                    return (this._value.Equals$4(other._value, 5/*StringComparison.OrdinalIgnoreCase*/));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540918394)
            
            //--TRIMMABLE-BOUNDARY-START(103080525946)
            /*StringSegment */ GetUnescapedValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080525946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$mnhh.MNHH.HeaderUtilities.IsQuoted(this._value))
                {
                    return this._value;
                }
                return $.$mnhh.MNHH.HeaderUtilities.UnescapeAsQuotedString(this._value);
            }
            //--TRIMMABLE-BOUNDARY-END(103080525946)
            
            //--TRIMMABLE-BOUNDARY-START(146030198906)
            /*void */ SetAndEscapeValue(/*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030198906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(value) || ($.$mnhh.MNHH.NameValueHeaderValue.GetValueLength(value, 0) === value.Length))
                {
                    this._value = value;
                }
                else 
                {
                    this.Value = $.$mnhh.MNHH.HeaderUtilities.EscapeAsQuotedString(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030198906)
            
            //--TRIMMABLE-BOUNDARY-START(124555362426)
            static /*NameValueHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555362426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.NameValueHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(124555362426)
            
            //--TRIMMABLE-BOUNDARY-START(167505035386)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out NameValueHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505035386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.MNHH.NameValueHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(167505035386)
            
            //--TRIMMABLE-BOUNDARY-START(128850329722)
            static /*IList<NameValueHeaderValue> */ ParseList(/*IList<string>?*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850329722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.NameValueHeaderValue.MultipleValueParser.ParseValues$1(input);
            }
            //--TRIMMABLE-BOUNDARY-END(128850329722)
            
            //--TRIMMABLE-BOUNDARY-START(133145297018)
            static /*IList<NameValueHeaderValue> */ ParseStrictList(/*IList<string>?*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145297018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.NameValueHeaderValue.MultipleValueParser.ParseStrictValues(input);
            }
            //--TRIMMABLE-BOUNDARY-END(133145297018)
            
            //--TRIMMABLE-BOUNDARY-START(171800002682)
            static /*bool */ TryParseList(/*IList<string>?*/ input, /*out IList<NameValueHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800002682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.NameValueHeaderValue.MultipleValueParser.TryParseValues(input, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(171800002682)
            
            //--TRIMMABLE-BOUNDARY-START(176094969978)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ input, /*out IList<NameValueHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094969978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.MNHH.NameValueHeaderValue.MultipleValueParser.TryParseStrictValues(input, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(176094969978)
            
            //--TRIMMABLE-BOUNDARY-START(154620133498)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620133498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$mep.MEP.StringSegment.IsNullOrEmpty(this._value))
                {
                    return $.$strNN(this._name.ToString()) + "=" + $.$strNN(this._value.ToString());
                }
                return this._name.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(154620133498)
            
            //--TRIMMABLE-BOUNDARY-START(158915100794)
            static /*void */ ToString$1(/*IList<NameValueHeaderValue>?*/ values, /*char*/ separator, /*bool*/ leadingSeparator, /*StringBuilder*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915100794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SDC$1.Contract.Assert$1(destination !== null);
                if ((values === null) || (values.SCG$ICollection$$$Count === 0))
                {
                    return;
                }
                for(/*var*/ let i = 0; i < values.SCG$ICollection$$$Count; i++)
                {
                    if (leadingSeparator || (destination.Length > 0))
                    {
                        destination.Append$5(separator);
                        destination.Append$5(/* */ 32);
                    }
                    destination.Append$17(values.SCG$IList$$$get_Item(i).Name.AsSpan());
                    if (!$.$mep.MEP.StringSegment.IsNullOrEmpty(values.SCG$IList$$$get_Item(i).Value))
                    {
                        destination.Append$5(/*=*/ 61);
                        destination.Append$17(values.SCG$IList$$$get_Item(i).Value.AsSpan());
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915100794)
            
            //--TRIMMABLE-BOUNDARY-START(163210068090)
            static /*string? */ ToString$2(/*IList<NameValueHeaderValue>?*/ values, /*char*/ separator, /*bool*/ leadingSeparator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210068090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((values === null) || (values.SCG$ICollection$$$Count === 0))
                {
                    return null;
                }
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                $.$mnhh.MNHH.NameValueHeaderValue.ToString$1(values, separator, leadingSeparator, sb);
                return sb.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(163210068090)
            
            //--TRIMMABLE-BOUNDARY-START(90195624058)
            static /*int */ GetHashCode$1(/*IList<NameValueHeaderValue>?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195624058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((values === null) || (values.SCG$ICollection$$$Count === 0))
                {
                    return 0;
                }
                /*var*/ let result = 0;
                for(/*var*/ let i = 0; i < values.SCG$ICollection$$$Count; i++)
                {
                    result = result ^ values.SCG$IList$$$get_Item(i).GetHashCode();
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(90195624058)
            
            //--TRIMMABLE-BOUNDARY-START(94490591354)
            static /*int */ GetNameValueLength(/*StringSegment*/ input, /*int*/ startIndex, /*out NameValueHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490591354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.MEP.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let nameLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, startIndex);
                if (nameLength === 0)
                {
                    return 0;
                }
                /*var*/ let name = input.Subsegment(startIndex, nameLength);
                /*var*/ let current = ((startIndex + nameLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item$1(current) !== /*=*/ 61))
                {
                    parsedValue.$v = new $.$mnhh.MNHH.NameValueHeaderValue().$ctor$1();
                    parsedValue.$v._name = name;
                    current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    return ((current - startIndex) | 0);
                }
                current++;
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*int*/ let valueLength = $.$mnhh.MNHH.NameValueHeaderValue.GetValueLength(input, current);
                parsedValue.$v = new $.$mnhh.MNHH.NameValueHeaderValue().$ctor$1();
                parsedValue.$v._name = name;
                parsedValue.$v._value = input.Subsegment(current, valueLength);
                current = ((current + valueLength) | 0);
                current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(94490591354)
            
            //--TRIMMABLE-BOUNDARY-START(98785558650)
            static /*int */ GetNameValueListLength(/*StringSegment*/ input, /*int*/ startIndex, /*char*/ delimiter, /*IList<NameValueHeaderValue>*/ nameValueCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785558650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if (($.$mep.MEP.StringSegment.IsNullOrEmpty(input)) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                while(true)
                {
                    /*var*/ let parameter;
                    /*var*/ let nameValueLength = $.$mnhh.MNHH.NameValueHeaderValue.GetNameValueLength(input, current, $.$ref(() => parameter, ($v) => parameter = $v, $.$mnhh.MNHH.NameValueHeaderValue));
                    if (nameValueLength === 0)
                    {
                        return ((current - startIndex) | 0);
                    }
                    nameValueCollection.SCG$ICollection$$$Add(parameter);
                    current = ((current + nameValueLength) | 0);
                    current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    if ((current === input.Length) || (input.get_Item$1(current) !== delimiter))
                    {
                        return ((current - startIndex) | 0);
                    }
                    current++;
                    current = ((current + $.$mnhh.MNHH.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785558650)
            
            //--TRIMMABLE-BOUNDARY-START(55835885690)
            static /*NameValueHeaderValue? */ Find(/*IList<NameValueHeaderValue>?*/ values, /*StringSegment*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835885690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if ((values === null) || (values.SCG$ICollection$$$Count === 0))
                {
                    return null;
                }
                for(/*var*/ let i = 0; i < values.SCG$ICollection$$$Count; i++)
                {
                    /*var*/ let value = values.SCG$IList$$$get_Item(i);
                    if (value.Name.Equals$4(name, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return value;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(55835885690)
            
            //--TRIMMABLE-BOUNDARY-START(107375493242)
            static /*int */ GetValueLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375493242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let valueLength = $.$mnhh.MNHH.HttpRuleParser.GetTokenLength(input, startIndex);
                if (valueLength === 0)
                {
                    if ($.$mnhh.MNHH.HttpRuleParser.GetQuotedStringLength(input, startIndex, $.$ref(() => valueLength, ($v) => valueLength = $v, $.$$.S.Int32)) !== 0/*HttpParseResult.Parsed*/)
                    {
                        return 0;
                    }
                }
                return valueLength;
            }
            //--TRIMMABLE-BOUNDARY-END(107375493242)
            
            //--TRIMMABLE-BOUNDARY-START(34361049210)
            static /*void */ CheckNameValueFormat(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.MNHH.HeaderUtilities.CheckValidToken(name, "name");
                $.$mnhh.MNHH.NameValueHeaderValue.CheckValueFormat(value);
            }
            //--TRIMMABLE-BOUNDARY-END(34361049210)
            
            //--TRIMMABLE-BOUNDARY-START(38656016506)
            static /*void */ CheckValueFormat(/*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656016506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!($.$mep.MEP.StringSegment.IsNullOrEmpty(value) || ($.$mnhh.MNHH.NameValueHeaderValue.GetValueLength(value, 0) === value.Length)))
                {
                    throw new $.$$.S.FormatException().$ctor$12($.$$.S.String.Format$4($.$$.SG.CultureInfo.InvariantCulture, "The header value is invalid: '{0}'", value));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656016506)
            
            //--TRIMMABLE-BOUNDARY-START(21476147322)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476147322)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591245434)
                this._name = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591245434)
                
                //--TRIMMABLE-BOUNDARY-START(12886212730)
                this._value = $.$default($.$mep.MEP.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(12886212730)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17181180026)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181180026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(150325166202)
                    this.SingleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.NameValueHeaderValue))().$ctor$3(false, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.NameValueHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.NameValueHeaderValue, $.$mnhh.MNHH.NameValueHeaderValue.GetNameValueLength));
                    //--TRIMMABLE-BOUNDARY-END(150325166202)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115965427834)
                    this.MultipleValueParser = new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.NameValueHeaderValue))().$ctor$3(true, new ($.$mnhh.MNHH.GenericHeaderParser$$($.$mnhh.MNHH.NameValueHeaderValue).GetParsedValueLengthDelegate)().$ctor($.$mnhh.MNHH.NameValueHeaderValue, $.$mnhh.MNHH.NameValueHeaderValue.GetNameValueLength));
                    //--TRIMMABLE-BOUNDARY-END(115965427834)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181180026)
            
            static $h = 1310842;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260395130),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015754874,
        "f": 50331649
      },
      "n": "Name",
      "d": 1310842,
      "h": 120260395130,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260395130),
//--TRIMMABLE-BOUNDARY-START(180389937274),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605689466,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735231610,
        "f": 83886081
      },
      "n": "Value",
      "d": 1310842,
      "h": 180389937274,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389937274),
//--TRIMMABLE-BOUNDARY-START(111670460538),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425820282,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1310842,
      "h": 111670460538,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670460538)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950983802),
    {
      "r": 1310842,
      "n": "Copy",
      "d": 1310842,
      "h": 42950983802,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950983802),
//--TRIMMABLE-BOUNDARY-START(47245951098),
    {
      "r": 1310842,
      "n": "CopyAsReadOnly",
      "d": 1310842,
      "h": 47245951098,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245951098),
//--TRIMMABLE-BOUNDARY-START(85900656762),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1310842,
      "h": 85900656762,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900656762),
//--TRIMMABLE-BOUNDARY-START(51540918394),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1310842,
      "h": 51540918394,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540918394),
//--TRIMMABLE-BOUNDARY-START(103080525946),
    {
      "r": 852053,
      "n": "GetUnescapedValue",
      "d": 1310842,
      "h": 103080525946,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080525946),
//--TRIMMABLE-BOUNDARY-START(146030198906),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "SetAndEscapeValue",
      "d": 1310842,
      "h": 146030198906,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030198906),
//--TRIMMABLE-BOUNDARY-START(124555362426),
    {
      "r": 1310842,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1310842,
      "h": 124555362426,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124555362426),
//--TRIMMABLE-BOUNDARY-START(167505035386),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1310842,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1310842,
      "h": 167505035386,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167505035386),
//--TRIMMABLE-BOUNDARY-START(128850329722),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "p": [
        {
          "n": "input",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseList",
      "d": 1310842,
      "h": 128850329722,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128850329722),
//--TRIMMABLE-BOUNDARY-START(133145297018),
    {
      "r": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "p": [
        {
          "n": "input",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 1310842,
      "h": 133145297018,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133145297018),
//--TRIMMABLE-BOUNDARY-START(171800002682),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 1310842,
      "h": 171800002682,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171800002682),
//--TRIMMABLE-BOUNDARY-START(176094969978),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 1310842,
      "h": 176094969978,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(176094969978),
//--TRIMMABLE-BOUNDARY-START(154620133498),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1310842,
      "h": 154620133498,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154620133498),
//--TRIMMABLE-BOUNDARY-START(158915100794),
    {
      "r": 65537,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h
        },
        {
          "n": "separator",
          "p": 458753
        },
        {
          "n": "leadingSeparator",
          "p": 262145
        },
        {
          "n": "destination",
          "p": 167837697
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 1310842,
      "h": 158915100794,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(158915100794),
//--TRIMMABLE-BOUNDARY-START(163210068090),
    {
      "r": 1310721,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h
        },
        {
          "n": "separator",
          "p": 458753
        },
        {
          "n": "leadingSeparator",
          "p": 262145
        }
      ],
      "n": "ToString",
      "o": "@$2",
      "d": 1310842,
      "h": 163210068090,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(163210068090),
//--TRIMMABLE-BOUNDARY-START(90195624058),
    {
      "r": 655361,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 1310842,
      "h": 90195624058,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90195624058),
//--TRIMMABLE-BOUNDARY-START(94490591354),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1310842,
          "f": 2
        }
      ],
      "n": "GetNameValueLength",
      "d": 1310842,
      "h": 94490591354,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94490591354),
//--TRIMMABLE-BOUNDARY-START(98785558650),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "delimiter",
          "p": 458753
        },
        {
          "n": "nameValueCollection",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h
        }
      ],
      "n": "GetNameValueListLength",
      "d": 1310842,
      "h": 98785558650,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(98785558650),
//--TRIMMABLE-BOUNDARY-START(55835885690),
    {
      "r": 1310842,
      "p": [
        {
          "n": "values",
          "p": $.$$.SCG.IList$$($.$mnhh.MNHH.NameValueHeaderValue).$h
        },
        {
          "n": "name",
          "p": 852053
        }
      ],
      "n": "Find",
      "d": 1310842,
      "h": 55835885690,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835885690),
//--TRIMMABLE-BOUNDARY-START(107375493242),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "GetValueLength",
      "d": 1310842,
      "h": 107375493242,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107375493242),
//--TRIMMABLE-BOUNDARY-START(34361049210),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "CheckNameValueFormat",
      "d": 1310842,
      "h": 34361049210,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361049210),
//--TRIMMABLE-BOUNDARY-START(38656016506),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "CheckValueFormat",
      "d": 1310842,
      "h": 38656016506,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656016506)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(150325166202),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 1310842,
      "h": 150325166202,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(150325166202),
//--TRIMMABLE-BOUNDARY-START(115965427834),
    {
      "t": $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.NameValueHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 1310842,
      "h": 115965427834,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115965427834),
//--TRIMMABLE-BOUNDARY-START(8591245434),
    {
      "t": 852053,
      "n": "_name",
      "d": 1310842,
      "h": 8591245434,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245434),
//--TRIMMABLE-BOUNDARY-START(12886212730),
    {
      "t": 852053,
      "n": "_value",
      "d": 1310842,
      "h": 12886212730,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886212730),
//--TRIMMABLE-BOUNDARY-START(4296278138),
    {
      "t": 262145,
      "n": "_isReadOnly",
      "d": 1310842,
      "h": 4296278138,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278138)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476147322),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310842,
      "h": 21476147322,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476147322),
//--TRIMMABLE-BOUNDARY-START(30066081914),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310842,
      "h": 30066081914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066081914),
//--TRIMMABLE-BOUNDARY-START(25771114618),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310842,
      "h": 25771114618,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771114618)
  ],
  "h": 1310842
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.NameValueHeaderValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}NameValueHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310842)
        
        

        //--TRIMMABLE-BOUNDARY-START(655482)
        $asm.$cls(`$mnhh.MNHH.GenericHeaderParser<>`, (T) => $asm.$gt(`$mnhh.MNHH.GenericHeaderParser<>`, [T], ($self) => class GenericHeaderParser$$ extends $.$mnhh.MNHH.BaseHeaderParser$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(721018)
            static $_GetParsedValueLengthDelegate;
            static get GetParsedValueLengthDelegate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mnhh.MNHH.GenericHeaderParser$$(T);
                return $cls.$_GetParsedValueLengthDelegate ??= $asm.$ncls(`$mnhh.MNHH.GenericHeaderParser<${T?.$fullName}>.GetParsedValueLengthDelegate`, ($self) => class GetParsedValueLengthDelegate extends $.$$.S.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*int*/ Invoke(/**/ value, /*$.$$.S.Int32*/ startIndex, /**/ parsedValue)
                    {
                        return this.$nativeFunction.call(this.$target, value, startIndex, parsedValue);
                    }
                    static $H = 721018;
                    static $h = 721018;
                    static $f = 0b10000000011000000;
                    static $k = 5;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590202),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "Invoke",
      "d": 721018,
      "H": 17180590202,
      "h": Number(BigInt(721018)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180590202),
//--TRIMMABLE-BOUNDARY-START(8590655610),
    {
      "r": 90570753,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 721018,
      "H": 8590655610,
      "h": Number(BigInt(721018)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590655610),
//--TRIMMABLE-BOUNDARY-START(12885622906),
    {
      "r": 655361,
      "p": [
        {
          "n": "parsedValue",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 721018,
      "H": 12885622906,
      "h": Number(BigInt(721018)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885622906)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688314),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 721018,
      "H": 4295688314,
      "h": Number(BigInt(721018)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688314)
  ],
  "d": 655482,
  "H": 721018,
  "h": 721018
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.GenericHeaderParser<${T?.$fullName}>+GetParsedValueLengthDelegate`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}GenericHeaderParser$${T?.$getFullName(separator)}$${separator}GetParsedValueLengthDelegate`; }
                }, $cls, ($v) => $cls.$_GetParsedValueLengthDelegate = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(721018)
            
            //--TRIMMABLE-BOUNDARY-START(4295622778)
            /*GetParsedValueLengthDelegate*/ _getParsedValueLength = null;
            //--TRIMMABLE-BOUNDARY-END(4295622778)
            
            //--TRIMMABLE-BOUNDARY-START(8590590074)
            $ctor$3(/*bool*/ supportsMultipleValues, /*GetParsedValueLengthDelegate*/ getParsedValueLength)
            {
                super.$ctor$2(supportsMultipleValues);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590074);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(getParsedValueLength, "getParsedValueLength");
                    this._getParsedValueLength = getParsedValueLength;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590074)
            
            //--TRIMMABLE-BOUNDARY-START(12885557370)
            /*int */ GetParsedValueLength(/*StringSegment*/ value, /*int*/ startIndex, /*out T?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._getParsedValueLength.Invoke(value, startIndex, parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(12885557370)
            
            static $H = 655482;
            static $h = 655482;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mnhh.MNHH.BaseHeaderParser$$(T); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885557370),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "GetParsedValueLength",
      "d": this.$h,
      "H": 12885557370,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885557370)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622778),
    {
      "t": 721018,
      "n": "_getParsedValueLength",
      "d": this.$h,
      "H": 4295622778,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622778)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590074),
    {
      "p": [
        {
          "n": "supportsMultipleValues",
          "p": 262145
        },
        {
          "n": "getParsedValueLength",
          "p": 721018
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 8590590074,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590590074)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 655482,
  "h": this.$h
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mnhh.MNHH.GenericHeaderParser$$(T).GetParsedValueLengthDelegate ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.GenericHeaderParser<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}GenericHeaderParser$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(655482)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048698)
        $asm.$str(`$mnhh.MNHH.HttpParseResult`, ($self) => class HttpParseResult extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Parsed = 0;
            static NotParsed = 1;
            static InvalidFormat = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Parsed": 0n,
                    "NotParsed": 1n,
                    "InvalidFormat": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296015994)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015994)
            
            //--TRIMMABLE-BOUNDARY-START(4296015994)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296015994)
            
            static $h = 1048698;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180917882),
    {
      "t": 1048698,
      "n": "Parsed",
      "d": 1048698,
      "h": 17180917882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180917882),
//--TRIMMABLE-BOUNDARY-START(12885950586),
    {
      "t": 1048698,
      "n": "NotParsed",
      "d": 1048698,
      "h": 12885950586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950586),
//--TRIMMABLE-BOUNDARY-START(8590983290),
    {
      "t": 1048698,
      "n": "InvalidFormat",
      "d": 1048698,
      "h": 8590983290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590983290)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015994),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048698,
      "h": 4296015994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015994)
  ],
  "h": 1048698
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.HttpParseResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}HttpParseResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048698)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638522)
        $asm.$str(`$mnhh.MNHH.SameSiteMode`, ($self) => class SameSiteMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Unspecified = -1;
            static None = 0;
            static Lax = 1;
            static Strict = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unspecified": 4294967295n,
                    "None": 0n,
                    "Lax": 1n,
                    "Strict": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296605818)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605818)
            
            //--TRIMMABLE-BOUNDARY-START(4296605818)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605818)
            
            static $h = 1638522;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476475002),
    {
      "t": 1638522,
      "n": "Unspecified",
      "d": 1638522,
      "h": 21476475002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476475002),
//--TRIMMABLE-BOUNDARY-START(12886540410),
    {
      "t": 1638522,
      "n": "None",
      "d": 1638522,
      "h": 12886540410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886540410),
//--TRIMMABLE-BOUNDARY-START(8591573114),
    {
      "t": 1638522,
      "n": "Lax",
      "d": 1638522,
      "h": 8591573114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591573114),
//--TRIMMABLE-BOUNDARY-START(17181507706),
    {
      "t": 1638522,
      "n": "Strict",
      "d": 1638522,
      "h": 17181507706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181507706)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605818),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638522,
      "h": 4296605818,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605818)
  ],
  "h": 1638522
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.SameSiteMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}SameSiteMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638522)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835130)
        $asm.$cls(`$mnhh.MNHH.StringWithQualityHeaderValueComparer`, ($self) => class StringWithQualityHeaderValueComparer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181704314)
            /*StringSegment*/ static Any;
            //--TRIMMABLE-BOUNDARY-END(17181704314)
            
            //--TRIMMABLE-BOUNDARY-START(12886737018)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886737018);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886737018)
            
            //--TRIMMABLE-BOUNDARY-START(34361573498)
            /*StringWithQualityHeaderValueComparer*/ static QualityComparer = null;
            //--TRIMMABLE-BOUNDARY-END(34361573498)
            
            //--TRIMMABLE-BOUNDARY-START(21476671610)
            /*int */ Compare(/*StringWithQualityHeaderValue?*/ stringWithQuality1, /*StringWithQualityHeaderValue?*/ stringWithQuality2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476671610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(stringWithQuality1, "stringWithQuality1");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(stringWithQuality2, "stringWithQuality2");
                /*var*/ let quality1 = stringWithQuality1.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let quality2 = stringWithQuality2.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let qualityDifference = quality1 - quality2;
                if (qualityDifference < 0)
                {
                    return -1;
                }
                else if (qualityDifference > 0)
                {
                    return 1;
                }
                if (!$.$mep.MEP.StringSegment.Equals$5(stringWithQuality1.Value, stringWithQuality2.Value, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    if ($.$mep.MEP.StringSegment.Equals$5(stringWithQuality1.Value, $.$mnhh.MNHH.StringWithQualityHeaderValueComparer.Any, 4/*StringComparison.Ordinal*/))
                    {
                        return -1;
                    }
                    else if ($.$mep.MEP.StringSegment.Equals$5(stringWithQuality2.Value, $.$mnhh.MNHH.StringWithQualityHeaderValueComparer.Any, 4/*StringComparison.Ordinal*/))
                    {
                        return 1;
                    }
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(21476671610)
            
            //--TRIMMABLE-BOUNDARY-START(4355129345)
            //Generated interface implemetation for System.Collections.Generic.IComparer<Microsoft.Net.Http.Headers.StringWithQualityHeaderValue>.Compare(Microsoft.Net.Http.Headers.StringWithQualityHeaderValue?, Microsoft.Net.Http.Headers.StringWithQualityHeaderValue?)
            SCG$IComparer$Microsoft$Net$Http$Headers$StringWithQualityHeaderValue$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355129345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355129345)
            
            //--TRIMMABLE-BOUNDARY-START(12886737018)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886737018)
            
            //--TRIMMABLE-BOUNDARY-START(8591769722)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591769722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17181704314)
                    this.Any = new $.$mep.MEP.StringSegment().$ctor$4("*");
                    //--TRIMMABLE-BOUNDARY-END(17181704314)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361573498)
                    this.QualityComparer = new $.$mnhh.MNHH.StringWithQualityHeaderValueComparer().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(34361573498)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591769722)
            
            static $h = 1835130;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361573498),
    {
      "p": 1835130,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066606202,
        "f": 50331681
      },
      "n": "QualityComparer",
      "d": 1835130,
      "h": 34361573498,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34361573498)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476671610),
    {
      "r": 655361,
      "p": [
        {
          "n": "stringWithQuality1",
          "p": 1769594
        },
        {
          "n": "stringWithQuality2",
          "p": 1769594
        }
      ],
      "n": "Compare",
      "d": 1835130,
      "h": 21476671610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476671610)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181704314),
    {
      "t": 852053,
      "n": "Any",
      "d": 1835130,
      "h": 17181704314,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181704314)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886737018),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1835130,
      "h": 12886737018,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886737018)
  ],
  "h": 1835130
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IComparer$$($.$mnhh.MNHH.StringWithQualityHeaderValue) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}StringWithQualityHeaderValueComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835130)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245306)
        $asm.$cls(`$mnhh.MNHH.MediaTypeHeaderValueComparer`, ($self) => class MediaTypeHeaderValueComparer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886147194)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886147194);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886147194)
            
            //--TRIMMABLE-BOUNDARY-START(34360983674)
            /*MediaTypeHeaderValueComparer*/ static QualityComparer = null;
            //--TRIMMABLE-BOUNDARY-END(34360983674)
            
            //--TRIMMABLE-BOUNDARY-START(17181114490)
            /*int */ Compare(/*MediaTypeHeaderValue?*/ mediaType1, /*MediaTypeHeaderValue?*/ mediaType2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals(mediaType1, mediaType2))
                {
                    return 0;
                }
                if (mediaType1 === null)
                {
                    return -1;
                }
                if (mediaType2 === null)
                {
                    return 1;
                }
                /*var*/ let returnValue = $.$mnhh.MNHH.MediaTypeHeaderValueComparer.CompareBasedOnQualityFactor(mediaType1, mediaType2);
                if (returnValue === 0)
                {
                    if (!mediaType1.Type.Equals$4(mediaType2.Type, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllTypes)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypes && !mediaType2.MatchesAllSubTypes)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypes && mediaType2.MatchesAllSubTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypesWithoutSuffix && !mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypesWithoutSuffix && mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                    else if (!mediaType1.SubType.Equals$4(mediaType2.SubType, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllSubTypes)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllSubTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypesWithoutSuffix && !mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypesWithoutSuffix && mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                    else if (!mediaType1.Suffix.Equals$4(mediaType2.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                }
                return returnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(17181114490)
            
            //--TRIMMABLE-BOUNDARY-START(21476081786)
            static /*int */ CompareBasedOnQualityFactor(/*MediaTypeHeaderValue*/ mediaType1, /*MediaTypeHeaderValue*/ mediaType2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let mediaType1Quality = mediaType1.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let mediaType2Quality = mediaType2.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let qualityDifference = mediaType1Quality - mediaType2Quality;
                if (qualityDifference < 0)
                {
                    return -1;
                }
                else if (qualityDifference > 0)
                {
                    return 1;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(21476081786)
            
            //--TRIMMABLE-BOUNDARY-START(4355129345)
            //Generated interface implemetation for System.Collections.Generic.IComparer<Microsoft.Net.Http.Headers.MediaTypeHeaderValue>.Compare(Microsoft.Net.Http.Headers.MediaTypeHeaderValue?, Microsoft.Net.Http.Headers.MediaTypeHeaderValue?)
            SCG$IComparer$Microsoft$Net$Http$Headers$MediaTypeHeaderValue$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355129345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355129345)
            
            //--TRIMMABLE-BOUNDARY-START(12886147194)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886147194)
            
            //--TRIMMABLE-BOUNDARY-START(8591179898)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591179898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(34360983674)
                    this.QualityComparer = new $.$mnhh.MNHH.MediaTypeHeaderValueComparer().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(34360983674)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591179898)
            
            static $h = 1245306;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360983674),
    {
      "p": 1245306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066016378,
        "f": 50331681
      },
      "n": "QualityComparer",
      "d": 1245306,
      "h": 34360983674,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360983674)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181114490),
    {
      "r": 655361,
      "p": [
        {
          "n": "mediaType1",
          "p": 1179770
        },
        {
          "n": "mediaType2",
          "p": 1179770
        }
      ],
      "n": "Compare",
      "d": 1245306,
      "h": 17181114490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181114490),
//--TRIMMABLE-BOUNDARY-START(21476081786),
    {
      "r": 655361,
      "p": [
        {
          "n": "mediaType1",
          "p": 1179770
        },
        {
          "n": "mediaType2",
          "p": 1179770
        }
      ],
      "n": "CompareBasedOnQualityFactor",
      "d": 1245306,
      "h": 21476081786,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476081786)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886147194),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245306,
      "h": 12886147194,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886147194)
  ],
  "h": 1245306
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IComparer$$($.$mnhh.MNHH.MediaTypeHeaderValue) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.MediaTypeHeaderValueComparer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}MediaTypeHeaderValueComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245306)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376378)
        $asm.$cls(`$mnhh.MNHH.ObjectCollection<>`, (T) => $asm.$gt(`$mnhh.MNHH.ObjectCollection<>`, [T], ($self) => class ObjectCollection$$ extends $.$$.SCO.Collection$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(34361114746)
            /*Action<T>*/ static DefaultValidator = null;
            //--TRIMMABLE-BOUNDARY-END(34361114746)
            
            //--TRIMMABLE-BOUNDARY-START(38656082042)
            /*ObjectCollection<T>*/ static EmptyReadOnlyCollection = null;
            //--TRIMMABLE-BOUNDARY-END(38656082042)
            
            //--TRIMMABLE-BOUNDARY-START(4296343674)
            /*Action<T>*/ _validator = null;
            //--TRIMMABLE-BOUNDARY-END(4296343674)
            
            //--TRIMMABLE-BOUNDARY-START(30066147450)
            static /*IList<T> */ CreateInnerList(/*bool*/ isReadOnly, /*IEnumerable<T>?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066147450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let list = other === null ? new ($.$$.SCG.List$$(T))().$ctor$1() : new ($.$$.SCG.List$$(T))().$ctor$2(other);
                if (isReadOnly)
                {
                    return new ($.$$.SCO.ReadOnlyCollection$$(T))().$ctor$1(list);
                }
                else 
                {
                    return list;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066147450)
            
            //--TRIMMABLE-BOUNDARY-START(12886278266)
            $ctor$3()
            {
                this.$ctor$4($.$mnhh.MNHH.ObjectCollection$$(T).DefaultValidator, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886278266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278266)
            
            //--TRIMMABLE-BOUNDARY-START(17181245562)
            $ctor$4(/*Action<T>*/ validator, /*bool*/ isReadOnly)
            {
                super.$ctor$2($.$mnhh.MNHH.ObjectCollection$$(T).CreateInnerList(isReadOnly, null));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181245562);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._validator = validator;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181245562)
            
            //--TRIMMABLE-BOUNDARY-START(21476212858)
            $ctor$5(/*IEnumerable<T>*/ other, /*bool*/ isReadOnly)
            {
                super.$ctor$2($.$mnhh.MNHH.ObjectCollection$$(T).CreateInnerList(isReadOnly, other));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476212858);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._validator = $.$mnhh.MNHH.ObjectCollection$$(T).DefaultValidator;
                    let $en1 = this.Items.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let item = $en1.SCG$IEnumerator$$$Current;
                        {
                            this._validator.Invoke(item);
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476212858)
            
            //--TRIMMABLE-BOUNDARY-START(55835951226)
            /*bool */ get IsReadOnly()
            {
                return (this).SCG$ICollection$$$IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(55835951226)
            
            //--TRIMMABLE-BOUNDARY-START(51540983930)
            /*void */ InsertItem(/*int*/ index, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540983930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validator.Invoke(item);
                super.InsertItem(index, item);
            }
            //--TRIMMABLE-BOUNDARY-END(51540983930)
            
            //--TRIMMABLE-BOUNDARY-START(60130918522)
            /*void */ SetItem(/*int*/ index, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130918522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validator.Invoke(item);
                super.SetItem(index, item);
            }
            //--TRIMMABLE-BOUNDARY-END(60130918522)
            
            //--TRIMMABLE-BOUNDARY-START(25771180154)
            static /*void */ CheckNotNull(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (item === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("item");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771180154)
            
            //--TRIMMABLE-BOUNDARY-START(12886278266)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886278266)
            
            //--TRIMMABLE-BOUNDARY-START(8591310970)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(34361114746)
                    this.DefaultValidator = new ($.$$.S.Action$$(T))().$ctor($.$mnhh.MNHH.ObjectCollection$$(T), $.$mnhh.MNHH.ObjectCollection$$(T).CheckNotNull);
                    //--TRIMMABLE-BOUNDARY-END(34361114746)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38656082042)
                    this.EmptyReadOnlyCollection = new ($.$mnhh.MNHH.ObjectCollection$$(T))().$ctor$4($.$mnhh.MNHH.ObjectCollection$$(T).DefaultValidator, true);
                    //--TRIMMABLE-BOUNDARY-END(38656082042)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591310970)
            
            static $H = 1376378;
            static $h = 1376378;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SCO.Collection$$(T); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835951226),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246016634,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": this.$h,
      "H": 55835951226,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835951226)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066147450),
    {
      "r": $.$$.SCG.IList$$(T).$h,
      "p": [
        {
          "n": "isReadOnly",
          "p": 262145
        },
        {
          "n": "other",
          "p": $.$$.SCG.IEnumerable$$(T).$h,
          "f": 65
        }
      ],
      "n": "CreateInnerList",
      "d": this.$h,
      "H": 30066147450,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066147450),
//--TRIMMABLE-BOUNDARY-START(51540983930),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "InsertItem",
      "d": this.$h,
      "H": 51540983930,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540983930),
//--TRIMMABLE-BOUNDARY-START(60130918522),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "SetItem",
      "d": this.$h,
      "H": 60130918522,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60130918522),
//--TRIMMABLE-BOUNDARY-START(25771180154),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "CheckNotNull",
      "d": this.$h,
      "H": 25771180154,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771180154)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361114746),
    {
      "t": $.$$.S.Action$$(T).$h,
      "n": "DefaultValidator",
      "d": this.$h,
      "H": 34361114746,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34361114746),
//--TRIMMABLE-BOUNDARY-START(38656082042),
    {
      "t": this.$h,
      "n": "EmptyReadOnlyCollection",
      "d": this.$h,
      "H": 38656082042,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38656082042),
//--TRIMMABLE-BOUNDARY-START(4296343674),
    {
      "t": $.$$.S.Action$$(T).$h,
      "n": "_validator",
      "d": this.$h,
      "H": 4296343674,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343674)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886278266),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 12886278266,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886278266),
//--TRIMMABLE-BOUNDARY-START(17181245562),
    {
      "p": [
        {
          "n": "validator",
          "p": $.$$.S.Action$$(T).$h
        },
        {
          "n": "isReadOnly",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 17181245562,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181245562),
//--TRIMMABLE-BOUNDARY-START(21476212858),
    {
      "p": [
        {
          "n": "other",
          "p": $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "isReadOnly",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 21476212858,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476212858)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 1376378,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IList$$(T), $.$$.SCG.ICollection$$(T), $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyList$$(T), $.$$.SCG.IReadOnlyCollection$$(T), $.$$.SCG.IEnumerable$$(T), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.ObjectCollection<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}ObjectCollection$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1376378)
        
        

        //--TRIMMABLE-BOUNDARY-START(393338)
        $asm.$cls(`$mnhh.MNHH.CookieHeaderParser`, ($self) => class CookieHeaderParser extends $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.CookieHeaderValue)
        {
            //--TRIMMABLE-BOUNDARY-START(4295360634)
            $ctor$2(/*bool*/ supportsMultipleValues)
            {
                super.$ctor$1(supportsMultipleValues);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360634);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360634)
            
            //--TRIMMABLE-BOUNDARY-START(8590327930)
            /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*out CookieHeaderValue?*/ cookieValue)
            {
                /*var*/ let parsedName;
                /*var*/ let parsedValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cookieValue.$v = null;
                if (!$.$mnhh.MNHH.CookieHeaderParserShared.TryParseValue(value, index, this.SupportsMultipleValues, $.$ref(() => parsedName, ($v) => parsedName = $v, $.$typeNullable($.$mep.MEP.StringSegment)), $.$ref(() => parsedValue, ($v) => parsedValue = $v, $.$typeNullable($.$mep.MEP.StringSegment))))
                {
                    return false;
                }
                if (parsedName === null || parsedValue === null)
                {
                    return true;
                }
                cookieValue.$v = new $.$mnhh.MNHH.CookieHeaderValue().$ctor$2($.$$.S.Nullable$$($.$mep.MEP.StringSegment).Value$get.call(parsedName), $.$$.S.Nullable$$($.$mep.MEP.StringSegment).Value$get.call(parsedValue));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327930)
            
            static $h = 393338;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mnhh.MNHH.HttpHeaderParser$$($.$mnhh.MNHH.CookieHeaderValue); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327930),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "cookieValue",
          "p": 524410,
          "f": 2
        }
      ],
      "n": "TryParseValue",
      "d": 393338,
      "h": 8590327930,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590327930)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360634),
    {
      "p": [
        {
          "n": "supportsMultipleValues",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393338,
      "h": 4295360634,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295360634)
  ],
  "h": 393338
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Net.Http.Headers.CookieHeaderParser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Net${separator}Http${separator}Headers${separator}CookieHeaderParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393338)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http"));
})();
//--TRIMMABLE-BOUNDARY-END(122)
