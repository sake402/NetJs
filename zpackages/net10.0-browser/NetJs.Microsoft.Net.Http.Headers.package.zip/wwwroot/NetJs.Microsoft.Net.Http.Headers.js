
//--TRIMMABLE-BOUNDARY-START(115)
(function ($global, $, $$, $sm, $mep, $mwp, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Net.Http.Headers", 
    {
  "h": 115,
  "f": "Microsoft.Net.Http.Headers",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "HTTP header parser implementations.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.Net.Http.Headers",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Net.Http.Headers",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.Net.Http.Headers.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(983155)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser<>", (T) => $asm.$gt("$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser<>", [T], ($self) => class HttpHeaderParser$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295950451)
            /*bool*/ _supportsMultipleValues = false;
            //--TRIMMABLE-BOUNDARY-END(4295950451)
            
            //--TRIMMABLE-BOUNDARY-START(8590917747)
            $ctor$1(/*bool*/ supportsMultipleValues)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917747);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._supportsMultipleValues = supportsMultipleValues;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917747)
            
            //--TRIMMABLE-BOUNDARY-START(38655688819)
            /*bool */ get SupportsMultipleValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._supportsMultipleValues;
            }
            //--TRIMMABLE-BOUNDARY-END(38655688819)
            
            //--TRIMMABLE-BOUNDARY-START(25770786931)
            /*T? */ ParseValue(/*StringSegment*/ value, /*ref int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                /*var*/ let result;
                if (!this.TryParseValue(value, index, $.$ref(() => result, ($v) => result = $v, T)))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "The header contains invalid values at index {0}: '{1}'", $.$box(index.$v, $.$$.System.Int32), value.Value ?? "<null>"));
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(25770786931)
            
            //--TRIMMABLE-BOUNDARY-START(55835558003)
            /*bool */ TryParseValues$1(/*IList<string>?*/ values, /*out IList<T>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835558003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryParseValues(values, false, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(55835558003)
            
            //--TRIMMABLE-BOUNDARY-START(47245623411)
            /*bool */ TryParseStrictValues(/*IList<string>?*/ values, /*out IList<T>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryParseValues(values, true, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(47245623411)
            
            //--TRIMMABLE-BOUNDARY-START(60130525299)
            /*bool */ TryParseValues(/*IList<string>?*/ values, /*bool*/ strict, /*out IList<T>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1(this._supportsMultipleValues);
                parsedValues.$v = null;
                /*List<T>?*/ let results = null;
                if (values === null)
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < values.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*var*/ let value = values.System$Collections$Generic$IList$$$get_Item(i, [$.$$.System.String]);
                    /*var*/ let index = 0;
                    while(!$.$$.System.String.IsNullOrEmpty(value) && index < value.length)
                    {
                        /*var*/ let output;
                        if (this.TryParseValue($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => output, ($v) => output = $v, T)))
                        {
                            if ($.$box(output, T) !== null)
                            {
                                if (results === null)
                                {
                                    results = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                                }
                                results.Add(output);
                            }
                        }
                        else if (strict)
                        {
                            return false;
                        }
                        else 
                        {
                            index++;
                        }
                    }
                }
                if (results !== null)
                {
                    parsedValues.$v = results;
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(60130525299)
            
            //--TRIMMABLE-BOUNDARY-START(30065754227)
            /*IList<T> */ ParseValues$1(/*IList<string>?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseValues(values, false);
            }
            //--TRIMMABLE-BOUNDARY-END(30065754227)
            
            //--TRIMMABLE-BOUNDARY-START(21475819635)
            /*IList<T> */ ParseStrictValues(/*IList<string>?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseValues(values, true);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819635)
            
            //--TRIMMABLE-BOUNDARY-START(34360721523)
            /*IList<T> */ ParseValues(/*IList<string>?*/ values, /*bool*/ strict)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360721523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1(this._supportsMultipleValues);
                /*var*/ let parsedValues = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                if (values === null)
                {
                    return parsedValues;
                }
                var $en2 = values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var value = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*int*/ let index = 0;
                        while(!$.$$.System.String.IsNullOrEmpty(value) && index < value.length)
                        {
                            /*var*/ let output;
                            if (this.TryParseValue($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => output, ($v) => output = $v, T)))
                            {
                                if ($.$box(output, T) !== null)
                                {
                                    parsedValues.Add(output);
                                }
                            }
                            else if (strict)
                            {
                                throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "The header contains invalid values at index {0}: '{1}'", $.$box(index, $.$$.System.Int32), value));
                            }
                            else 
                            {
                                index++;
                            }
                        }
                    }
                }
                return parsedValues;
            }
            //--TRIMMABLE-BOUNDARY-END(34360721523)
            
            //--TRIMMABLE-BOUNDARY-START(42950656115)
            /*string */ ToString$1(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Object.ToString.call(value);
            }
            //--TRIMMABLE-BOUNDARY-END(42950656115)
            
            static $h = 983155;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655688819),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "SupportsMultipleValues",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655688819)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540590707),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryParseValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51540590707),
//--TRIMMABLE-BOUNDARY-START(25770786931),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "ParseValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770786931),
//--TRIMMABLE-BOUNDARY-START(55835558003),
    {
      "r": 262145,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryParseValues",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835558003),
//--TRIMMABLE-BOUNDARY-START(47245623411),
    {
      "r": 262145,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictValues",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47245623411),
//--TRIMMABLE-BOUNDARY-START(60130525299),
    {
      "r": 262145,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "strict",
          "p": 262145
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryParseValues",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(60130525299),
//--TRIMMABLE-BOUNDARY-START(30065754227),
    {
      "r": $.$$.System.Collections.Generic.IList$$(T).$h,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseValues",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30065754227),
//--TRIMMABLE-BOUNDARY-START(21475819635),
    {
      "r": $.$$.System.Collections.Generic.IList$$(T).$h,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseStrictValues",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475819635),
//--TRIMMABLE-BOUNDARY-START(34360721523),
    {
      "r": $.$$.System.Collections.Generic.IList$$(T).$h,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "strict",
          "p": 262145
        }
      ],
      "n": "ParseValues",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(34360721523),
//--TRIMMABLE-BOUNDARY-START(42950656115),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42950656115)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950451),
    {
      "t": 262145,
      "n": "_supportsMultipleValues",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950451)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917747),
    {
      "p": [
        {
          "n": "supportsMultipleValues",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590917747)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HttpHeaderParser<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(983155)
        
        
        //--TRIMMABLE-BOUNDARY-START(65651)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.BaseHeaderParser<>", (T) => $asm.$gt("$mnhh.Microsoft.Net.Http.Headers.BaseHeaderParser<>", [T], ($self) => class BaseHeaderParser$$ extends $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(4295032947)
            $ctor$2(/*bool*/ supportsMultipleValues)
            {
                super.$ctor$1(supportsMultipleValues);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032947);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032947)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12884967539, 51540590707)
            /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*out T?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parsedValue.$v = $.$default(T);
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value) || (index.$v === value.Length))
                {
                    return this.SupportsMultipleValues;
                }
                /*var*/ let separatorFound;
                /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(value, index.$v, this.SupportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                if (separatorFound && !this.SupportsMultipleValues)
                {
                    return false;
                }
                if (current === value.Length)
                {
                    if (this.SupportsMultipleValues)
                    {
                        index.$v = current;
                    }
                    return this.SupportsMultipleValues;
                }
                /*var*/ let result;
                /*var*/ let length = this.GetParsedValueLength(value, current, $.$ref(() => result, ($v) => result = $v, T));
                if (length === 0)
                {
                    return false;
                }
                current = ((current + length) | 0);
                current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(value, current, this.SupportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                if ((separatorFound && !this.SupportsMultipleValues) || (!separatorFound && (current < value.Length)))
                {
                    return false;
                }
                index.$v = current;
                parsedValue.$v = result;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12884967539, 51540590707)
            
            static $h = 65651;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000243),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "GetParsedValueLength",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8590000243),
//--TRIMMABLE-BOUNDARY-START(ALL, 12884967539, 51540590707),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryParseValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12884967539, 51540590707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032947),
    {
      "p": [
        {
          "n": "supportsMultipleValues",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295032947)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$(T); }
            static get $fullName() { return `BaseHeaderParser<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(65651)
        
        
        //--TRIMMABLE-BOUNDARY-START(524403)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue", ($self) => class CookieHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(103079739507)
            /*CookieHeaderParser*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(103079739507)
            
            //--TRIMMABLE-BOUNDARY-START(64425033843)
            /*CookieHeaderParser*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(64425033843)
            
            //--TRIMMABLE-BOUNDARY-START(4295491699)
            /*StringSegment*/ _name;
            //--TRIMMABLE-BOUNDARY-END(4295491699)
            
            //--TRIMMABLE-BOUNDARY-START(8590458995)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(8590458995)
            
            //--TRIMMABLE-BOUNDARY-START(17180393587)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393587);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393587)
            
            //--TRIMMABLE-BOUNDARY-START(21475360883)
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("name");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360883)
            
            //--TRIMMABLE-BOUNDARY-START(25770328179)
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328179);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("name");
                    }
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("value");
                    }
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770328179)
            
            //--TRIMMABLE-BOUNDARY-START(68720001139)
            /*StringSegment */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245164659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*StringSegment */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.CheckNameFormat(value, "value");
                this._name = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68720001139)
            
            //--TRIMMABLE-BOUNDARY-START(124554575987)
            /*StringSegment */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.CheckValueFormat(value, "value");
                this._value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(124554575987)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 107374706803, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374706803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let header = new $.$$.System.Text.StringBuilder().$ctor$1();
                header.Append$15(this._name.AsSpan());
                header.Append$3(/*=*/ 61);
                header.Append$15(this._value.AsSpan());
                return $.$$.System.Text.StringBuilder.ToString.call(header);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 107374706803, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(73014968435)
            static /*CookieHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(73014968435)
            
            //--TRIMMABLE-BOUNDARY-START(111669674099)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out CookieHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669674099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(111669674099)
            
            //--TRIMMABLE-BOUNDARY-START(77309935731)
            static /*IList<CookieHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(77309935731)
            
            //--TRIMMABLE-BOUNDARY-START(81604903027)
            static /*IList<CookieHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604903027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(81604903027)
            
            //--TRIMMABLE-BOUNDARY-START(115964641395)
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<CookieHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964641395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.MultipleValueParser.TryParseValues$1(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(115964641395)
            
            //--TRIMMABLE-BOUNDARY-START(120259608691)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<CookieHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259608691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(120259608691)
            
            //--TRIMMABLE-BOUNDARY-START(30065295475)
            static /*void */ CheckNameFormat(/*StringSegment*/ name, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("name");
                }
                if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(name, 0) !== name.Length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("Invalid cookie name: " + $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(name), parameterName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065295475)
            
            //--TRIMMABLE-BOUNDARY-START(34360262771)
            static /*void */ CheckValueFormat(/*StringSegment*/ value, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("value");
                }
                /*var*/ let offset = 0;
                /*var*/ let result = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetCookieValue(value, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32));
                if (result.Length !== value.Length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("Invalid cookie value: " + $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(value), parameterName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262771)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38655230067, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655230067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._name, other._name, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38655230067, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60130066547, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(this._name) ^ $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(this._value);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60130066547, 184683724801)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295491699)
                this._name = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(4295491699)
                
                //--TRIMMABLE-BOUNDARY-START(8590458995)
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8590458995)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885426291)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(103079739507)
                    this.SingleValueParser = new $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParser().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(103079739507)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425033843)
                    this.MultipleValueParser = new $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParser().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(64425033843)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885426291)
            
            static $h = 524403;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720001139),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245164659,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194837619,
        "f": 83886081
      },
      "n": "Name",
      "d": 524403,
      "h": 68720001139,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720001139),
//--TRIMMABLE-BOUNDARY-START(124554575987),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835099251,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784772211,
        "f": 83886081
      },
      "n": "Value",
      "d": 524403,
      "h": 124554575987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554575987)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 107374706803, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 524403,
      "h": 107374706803,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 107374706803, 330712612865),
//--TRIMMABLE-BOUNDARY-START(73014968435),
    {
      "r": 524403,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 524403,
      "h": 73014968435,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014968435),
//--TRIMMABLE-BOUNDARY-START(111669674099),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 524403,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 524403,
      "h": 111669674099,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111669674099),
//--TRIMMABLE-BOUNDARY-START(77309935731),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseList",
      "d": 524403,
      "h": 77309935731,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309935731),
//--TRIMMABLE-BOUNDARY-START(81604903027),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 524403,
      "h": 81604903027,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604903027),
//--TRIMMABLE-BOUNDARY-START(115964641395),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 524403,
      "h": 115964641395,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964641395),
//--TRIMMABLE-BOUNDARY-START(120259608691),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 524403,
      "h": 120259608691,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120259608691),
//--TRIMMABLE-BOUNDARY-START(30065295475),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckNameFormat",
      "d": 524403,
      "h": 30065295475,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065295475),
//--TRIMMABLE-BOUNDARY-START(34360262771),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckValueFormat",
      "d": 524403,
      "h": 34360262771,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360262771),
//--TRIMMABLE-BOUNDARY-START(ALL, 38655230067, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 524403,
      "h": 38655230067,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38655230067, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 60130066547, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 524403,
      "h": 60130066547,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60130066547, 184683724801)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(103079739507),
    {
      "t": 393331,
      "n": "SingleValueParser",
      "d": 524403,
      "h": 103079739507,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103079739507),
//--TRIMMABLE-BOUNDARY-START(64425033843),
    {
      "t": 393331,
      "n": "MultipleValueParser",
      "d": 524403,
      "h": 64425033843,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425033843),
//--TRIMMABLE-BOUNDARY-START(4295491699),
    {
      "t": 852053,
      "n": "_name",
      "d": 524403,
      "h": 4295491699,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491699),
//--TRIMMABLE-BOUNDARY-START(8590458995),
    {
      "t": 852053,
      "n": "_value",
      "d": 524403,
      "h": 8590458995,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458995)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180393587),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524403,
      "h": 17180393587,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180393587),
//--TRIMMABLE-BOUNDARY-START(21475360883),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524403,
      "h": 21475360883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360883),
//--TRIMMABLE-BOUNDARY-START(25770328179),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524403,
      "h": 25770328179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328179)
  ],
  "h": 524403
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `CookieHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524403)
        
        
        //--TRIMMABLE-BOUNDARY-START(262259)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValueIdentityExtensions", ($self) => class ContentDispositionHeaderValueIdentityExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295229555)
            static /*bool */ IsFileDisposition(/*this ContentDispositionHeaderValue*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(header, "header");
                return header.DispositionType.Equals$3("form-data") && (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(header.FileName) || !$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(header.FileNameStar));
            }
            //--TRIMMABLE-BOUNDARY-END(4295229555)
            
            //--TRIMMABLE-BOUNDARY-START(8590196851)
            static /*bool */ IsFormDisposition(/*this ContentDispositionHeaderValue*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(header, "header");
                return header.DispositionType.Equals$3("form-data") && $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(header.FileName) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(header.FileNameStar);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196851)
            
            static $h = 262259;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229555),
    {
      "r": 262145,
      "p": [
        {
          "n": "header",
          "p": 196723
        }
      ],
      "n": "IsFileDisposition",
      "d": 262259,
      "h": 4295229555,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295229555),
//--TRIMMABLE-BOUNDARY-START(8590196851),
    {
      "r": 262145,
      "p": [
        {
          "n": "header",
          "p": 196723
        }
      ],
      "n": "IsFormDisposition",
      "d": 262259,
      "h": 8590196851,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196851)
  ],
  "h": 262259
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ContentDispositionHeaderValueIdentityExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262259)
        
        
        //--TRIMMABLE-BOUNDARY-START(786547)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HeaderNames", ($self) => class HeaderNames
        {
            //--TRIMMABLE-BOUNDARY-START(274878693491)
            /*string*/ static PseudoHeaderNamesObsoletionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878693491)
            
            //--TRIMMABLE-BOUNDARY-START(8590721139)
            /*string*/ static Accept = null;
            //--TRIMMABLE-BOUNDARY-END(8590721139)
            
            //--TRIMMABLE-BOUNDARY-START(12885688435)
            /*string*/ static AcceptCharset = null;
            //--TRIMMABLE-BOUNDARY-END(12885688435)
            
            //--TRIMMABLE-BOUNDARY-START(17180655731)
            /*string*/ static AcceptEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(17180655731)
            
            //--TRIMMABLE-BOUNDARY-START(21475623027)
            /*string*/ static AcceptLanguage = null;
            //--TRIMMABLE-BOUNDARY-END(21475623027)
            
            //--TRIMMABLE-BOUNDARY-START(25770590323)
            /*string*/ static AcceptRanges = null;
            //--TRIMMABLE-BOUNDARY-END(25770590323)
            
            //--TRIMMABLE-BOUNDARY-START(30065557619)
            /*string*/ static AccessControlAllowCredentials = null;
            //--TRIMMABLE-BOUNDARY-END(30065557619)
            
            //--TRIMMABLE-BOUNDARY-START(34360524915)
            /*string*/ static AccessControlAllowHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(34360524915)
            
            //--TRIMMABLE-BOUNDARY-START(38655492211)
            /*string*/ static AccessControlAllowMethods = null;
            //--TRIMMABLE-BOUNDARY-END(38655492211)
            
            //--TRIMMABLE-BOUNDARY-START(42950459507)
            /*string*/ static AccessControlAllowOrigin = null;
            //--TRIMMABLE-BOUNDARY-END(42950459507)
            
            //--TRIMMABLE-BOUNDARY-START(47245426803)
            /*string*/ static AccessControlExposeHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(47245426803)
            
            //--TRIMMABLE-BOUNDARY-START(51540394099)
            /*string*/ static AccessControlMaxAge = null;
            //--TRIMMABLE-BOUNDARY-END(51540394099)
            
            //--TRIMMABLE-BOUNDARY-START(55835361395)
            /*string*/ static AccessControlRequestHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(55835361395)
            
            //--TRIMMABLE-BOUNDARY-START(60130328691)
            /*string*/ static AccessControlRequestMethod = null;
            //--TRIMMABLE-BOUNDARY-END(60130328691)
            
            //--TRIMMABLE-BOUNDARY-START(64425295987)
            /*string*/ static Age = null;
            //--TRIMMABLE-BOUNDARY-END(64425295987)
            
            //--TRIMMABLE-BOUNDARY-START(68720263283)
            /*string*/ static Allow = null;
            //--TRIMMABLE-BOUNDARY-END(68720263283)
            
            //--TRIMMABLE-BOUNDARY-START(73015230579)
            /*string*/ static AltSvc = null;
            //--TRIMMABLE-BOUNDARY-END(73015230579)
            
            //--TRIMMABLE-BOUNDARY-START(77310197875)
            /*string*/ static Authority = null;
            //--TRIMMABLE-BOUNDARY-END(77310197875)
            
            //--TRIMMABLE-BOUNDARY-START(81605165171)
            /*string*/ static Authorization = null;
            //--TRIMMABLE-BOUNDARY-END(81605165171)
            
            //--TRIMMABLE-BOUNDARY-START(85900132467)
            /*string*/ static Baggage = null;
            //--TRIMMABLE-BOUNDARY-END(85900132467)
            
            //--TRIMMABLE-BOUNDARY-START(90195099763)
            /*string*/ static CacheControl = null;
            //--TRIMMABLE-BOUNDARY-END(90195099763)
            
            //--TRIMMABLE-BOUNDARY-START(94490067059)
            /*string*/ static Connection = null;
            //--TRIMMABLE-BOUNDARY-END(94490067059)
            
            //--TRIMMABLE-BOUNDARY-START(98785034355)
            /*string*/ static ContentDisposition = null;
            //--TRIMMABLE-BOUNDARY-END(98785034355)
            
            //--TRIMMABLE-BOUNDARY-START(103080001651)
            /*string*/ static ContentEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(103080001651)
            
            //--TRIMMABLE-BOUNDARY-START(107374968947)
            /*string*/ static ContentLanguage = null;
            //--TRIMMABLE-BOUNDARY-END(107374968947)
            
            //--TRIMMABLE-BOUNDARY-START(111669936243)
            /*string*/ static ContentLength = null;
            //--TRIMMABLE-BOUNDARY-END(111669936243)
            
            //--TRIMMABLE-BOUNDARY-START(115964903539)
            /*string*/ static ContentLocation = null;
            //--TRIMMABLE-BOUNDARY-END(115964903539)
            
            //--TRIMMABLE-BOUNDARY-START(120259870835)
            /*string*/ static ContentMD5 = null;
            //--TRIMMABLE-BOUNDARY-END(120259870835)
            
            //--TRIMMABLE-BOUNDARY-START(124554838131)
            /*string*/ static ContentRange = null;
            //--TRIMMABLE-BOUNDARY-END(124554838131)
            
            //--TRIMMABLE-BOUNDARY-START(128849805427)
            /*string*/ static ContentSecurityPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(128849805427)
            
            //--TRIMMABLE-BOUNDARY-START(133144772723)
            /*string*/ static ContentSecurityPolicyReportOnly = null;
            //--TRIMMABLE-BOUNDARY-END(133144772723)
            
            //--TRIMMABLE-BOUNDARY-START(137439740019)
            /*string*/ static ContentType = null;
            //--TRIMMABLE-BOUNDARY-END(137439740019)
            
            //--TRIMMABLE-BOUNDARY-START(146029674611)
            /*string*/ static CorrelationContext = null;
            //--TRIMMABLE-BOUNDARY-END(146029674611)
            
            //--TRIMMABLE-BOUNDARY-START(141734707315)
            /*string*/ static Cookie = null;
            //--TRIMMABLE-BOUNDARY-END(141734707315)
            
            //--TRIMMABLE-BOUNDARY-START(150324641907)
            /*string*/ static Date = null;
            //--TRIMMABLE-BOUNDARY-END(150324641907)
            
            //--TRIMMABLE-BOUNDARY-START(154619609203)
            /*string*/ static DNT = null;
            //--TRIMMABLE-BOUNDARY-END(154619609203)
            
            //--TRIMMABLE-BOUNDARY-START(158914576499)
            /*string*/ static ETag = null;
            //--TRIMMABLE-BOUNDARY-END(158914576499)
            
            //--TRIMMABLE-BOUNDARY-START(167504511091)
            /*string*/ static Expires = null;
            //--TRIMMABLE-BOUNDARY-END(167504511091)
            
            //--TRIMMABLE-BOUNDARY-START(163209543795)
            /*string*/ static Expect = null;
            //--TRIMMABLE-BOUNDARY-END(163209543795)
            
            //--TRIMMABLE-BOUNDARY-START(171799478387)
            /*string*/ static From = null;
            //--TRIMMABLE-BOUNDARY-END(171799478387)
            
            //--TRIMMABLE-BOUNDARY-START(176094445683)
            /*string*/ static GrpcAcceptEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(176094445683)
            
            //--TRIMMABLE-BOUNDARY-START(180389412979)
            /*string*/ static GrpcEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(180389412979)
            
            //--TRIMMABLE-BOUNDARY-START(184684380275)
            /*string*/ static GrpcMessage = null;
            //--TRIMMABLE-BOUNDARY-END(184684380275)
            
            //--TRIMMABLE-BOUNDARY-START(188979347571)
            /*string*/ static GrpcStatus = null;
            //--TRIMMABLE-BOUNDARY-END(188979347571)
            
            //--TRIMMABLE-BOUNDARY-START(193274314867)
            /*string*/ static GrpcTimeout = null;
            //--TRIMMABLE-BOUNDARY-END(193274314867)
            
            //--TRIMMABLE-BOUNDARY-START(197569282163)
            /*string*/ static Host = null;
            //--TRIMMABLE-BOUNDARY-END(197569282163)
            
            //--TRIMMABLE-BOUNDARY-START(223339085939)
            /*string*/ static KeepAlive = null;
            //--TRIMMABLE-BOUNDARY-END(223339085939)
            
            //--TRIMMABLE-BOUNDARY-START(201864249459)
            /*string*/ static IfMatch = null;
            //--TRIMMABLE-BOUNDARY-END(201864249459)
            
            //--TRIMMABLE-BOUNDARY-START(206159216755)
            /*string*/ static IfModifiedSince = null;
            //--TRIMMABLE-BOUNDARY-END(206159216755)
            
            //--TRIMMABLE-BOUNDARY-START(210454184051)
            /*string*/ static IfNoneMatch = null;
            //--TRIMMABLE-BOUNDARY-END(210454184051)
            
            //--TRIMMABLE-BOUNDARY-START(214749151347)
            /*string*/ static IfRange = null;
            //--TRIMMABLE-BOUNDARY-END(214749151347)
            
            //--TRIMMABLE-BOUNDARY-START(219044118643)
            /*string*/ static IfUnmodifiedSince = null;
            //--TRIMMABLE-BOUNDARY-END(219044118643)
            
            //--TRIMMABLE-BOUNDARY-START(227634053235)
            /*string*/ static LastModified = null;
            //--TRIMMABLE-BOUNDARY-END(227634053235)
            
            //--TRIMMABLE-BOUNDARY-START(231929020531)
            /*string*/ static Link = null;
            //--TRIMMABLE-BOUNDARY-END(231929020531)
            
            //--TRIMMABLE-BOUNDARY-START(236223987827)
            /*string*/ static Location = null;
            //--TRIMMABLE-BOUNDARY-END(236223987827)
            
            //--TRIMMABLE-BOUNDARY-START(240518955123)
            /*string*/ static MaxForwards = null;
            //--TRIMMABLE-BOUNDARY-END(240518955123)
            
            //--TRIMMABLE-BOUNDARY-START(244813922419)
            /*string*/ static Method = null;
            //--TRIMMABLE-BOUNDARY-END(244813922419)
            
            //--TRIMMABLE-BOUNDARY-START(249108889715)
            /*string*/ static Origin = null;
            //--TRIMMABLE-BOUNDARY-END(249108889715)
            
            //--TRIMMABLE-BOUNDARY-START(253403857011)
            /*string*/ static Path = null;
            //--TRIMMABLE-BOUNDARY-END(253403857011)
            
            //--TRIMMABLE-BOUNDARY-START(257698824307)
            /*string*/ static Pragma = null;
            //--TRIMMABLE-BOUNDARY-END(257698824307)
            
            //--TRIMMABLE-BOUNDARY-START(261993791603)
            /*string*/ static ProxyAuthenticate = null;
            //--TRIMMABLE-BOUNDARY-END(261993791603)
            
            //--TRIMMABLE-BOUNDARY-START(266288758899)
            /*string*/ static ProxyAuthorization = null;
            //--TRIMMABLE-BOUNDARY-END(266288758899)
            
            //--TRIMMABLE-BOUNDARY-START(270583726195)
            /*string*/ static ProxyConnection = null;
            //--TRIMMABLE-BOUNDARY-END(270583726195)
            
            //--TRIMMABLE-BOUNDARY-START(279173660787)
            /*string*/ static Range = null;
            //--TRIMMABLE-BOUNDARY-END(279173660787)
            
            //--TRIMMABLE-BOUNDARY-START(283468628083)
            /*string*/ static Referer = null;
            //--TRIMMABLE-BOUNDARY-END(283468628083)
            
            //--TRIMMABLE-BOUNDARY-START(292058562675)
            /*string*/ static RetryAfter = null;
            //--TRIMMABLE-BOUNDARY-END(292058562675)
            
            //--TRIMMABLE-BOUNDARY-START(287763595379)
            /*string*/ static RequestId = null;
            //--TRIMMABLE-BOUNDARY-END(287763595379)
            
            //--TRIMMABLE-BOUNDARY-START(296353529971)
            /*string*/ static Scheme = null;
            //--TRIMMABLE-BOUNDARY-END(296353529971)
            
            //--TRIMMABLE-BOUNDARY-START(300648497267)
            /*string*/ static SecWebSocketAccept = null;
            //--TRIMMABLE-BOUNDARY-END(300648497267)
            
            //--TRIMMABLE-BOUNDARY-START(309238431859)
            /*string*/ static SecWebSocketKey = null;
            //--TRIMMABLE-BOUNDARY-END(309238431859)
            
            //--TRIMMABLE-BOUNDARY-START(313533399155)
            /*string*/ static SecWebSocketProtocol = null;
            //--TRIMMABLE-BOUNDARY-END(313533399155)
            
            //--TRIMMABLE-BOUNDARY-START(317828366451)
            /*string*/ static SecWebSocketVersion = null;
            //--TRIMMABLE-BOUNDARY-END(317828366451)
            
            //--TRIMMABLE-BOUNDARY-START(304943464563)
            /*string*/ static SecWebSocketExtensions = null;
            //--TRIMMABLE-BOUNDARY-END(304943464563)
            
            //--TRIMMABLE-BOUNDARY-START(322123333747)
            /*string*/ static Server = null;
            //--TRIMMABLE-BOUNDARY-END(322123333747)
            
            //--TRIMMABLE-BOUNDARY-START(326418301043)
            /*string*/ static SetCookie = null;
            //--TRIMMABLE-BOUNDARY-END(326418301043)
            
            //--TRIMMABLE-BOUNDARY-START(330713268339)
            /*string*/ static Status = null;
            //--TRIMMABLE-BOUNDARY-END(330713268339)
            
            //--TRIMMABLE-BOUNDARY-START(335008235635)
            /*string*/ static StrictTransportSecurity = null;
            //--TRIMMABLE-BOUNDARY-END(335008235635)
            
            //--TRIMMABLE-BOUNDARY-START(339303202931)
            /*string*/ static TE = null;
            //--TRIMMABLE-BOUNDARY-END(339303202931)
            
            //--TRIMMABLE-BOUNDARY-START(352188104819)
            /*string*/ static Trailer = null;
            //--TRIMMABLE-BOUNDARY-END(352188104819)
            
            //--TRIMMABLE-BOUNDARY-START(356483072115)
            /*string*/ static TransferEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(356483072115)
            
            //--TRIMMABLE-BOUNDARY-START(360778039411)
            /*string*/ static Translate = null;
            //--TRIMMABLE-BOUNDARY-END(360778039411)
            
            //--TRIMMABLE-BOUNDARY-START(343598170227)
            /*string*/ static TraceParent = null;
            //--TRIMMABLE-BOUNDARY-END(343598170227)
            
            //--TRIMMABLE-BOUNDARY-START(347893137523)
            /*string*/ static TraceState = null;
            //--TRIMMABLE-BOUNDARY-END(347893137523)
            
            //--TRIMMABLE-BOUNDARY-START(365073006707)
            /*string*/ static Upgrade = null;
            //--TRIMMABLE-BOUNDARY-END(365073006707)
            
            //--TRIMMABLE-BOUNDARY-START(369367974003)
            /*string*/ static UpgradeInsecureRequests = null;
            //--TRIMMABLE-BOUNDARY-END(369367974003)
            
            //--TRIMMABLE-BOUNDARY-START(373662941299)
            /*string*/ static UserAgent = null;
            //--TRIMMABLE-BOUNDARY-END(373662941299)
            
            //--TRIMMABLE-BOUNDARY-START(377957908595)
            /*string*/ static Vary = null;
            //--TRIMMABLE-BOUNDARY-END(377957908595)
            
            //--TRIMMABLE-BOUNDARY-START(382252875891)
            /*string*/ static Via = null;
            //--TRIMMABLE-BOUNDARY-END(382252875891)
            
            //--TRIMMABLE-BOUNDARY-START(386547843187)
            /*string*/ static Warning = null;
            //--TRIMMABLE-BOUNDARY-END(386547843187)
            
            //--TRIMMABLE-BOUNDARY-START(390842810483)
            /*string*/ static WebSocketSubProtocols = null;
            //--TRIMMABLE-BOUNDARY-END(390842810483)
            
            //--TRIMMABLE-BOUNDARY-START(395137777779)
            /*string*/ static WWWAuthenticate = null;
            //--TRIMMABLE-BOUNDARY-END(395137777779)
            
            //--TRIMMABLE-BOUNDARY-START(399432745075)
            /*string*/ static XContentTypeOptions = null;
            //--TRIMMABLE-BOUNDARY-END(399432745075)
            
            //--TRIMMABLE-BOUNDARY-START(403727712371)
            /*string*/ static XFrameOptions = null;
            //--TRIMMABLE-BOUNDARY-END(403727712371)
            
            //--TRIMMABLE-BOUNDARY-START(408022679667)
            /*string*/ static XPoweredBy = null;
            //--TRIMMABLE-BOUNDARY-END(408022679667)
            
            //--TRIMMABLE-BOUNDARY-START(412317646963)
            /*string*/ static XRequestedWith = null;
            //--TRIMMABLE-BOUNDARY-END(412317646963)
            
            //--TRIMMABLE-BOUNDARY-START(416612614259)
            /*string*/ static XUACompatible = null;
            //--TRIMMABLE-BOUNDARY-END(416612614259)
            
            //--TRIMMABLE-BOUNDARY-START(420907581555)
            /*string*/ static XXSSProtection = null;
            //--TRIMMABLE-BOUNDARY-END(420907581555)
            
            //--TRIMMABLE-BOUNDARY-START(4295753843)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(274878693491)
                    this.PseudoHeaderNamesObsoletionMessage = "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.";
                    //--TRIMMABLE-BOUNDARY-END(274878693491)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590721139)
                    this.Accept = "Accept";
                    //--TRIMMABLE-BOUNDARY-END(8590721139)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885688435)
                    this.AcceptCharset = "Accept-Charset";
                    //--TRIMMABLE-BOUNDARY-END(12885688435)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180655731)
                    this.AcceptEncoding = "Accept-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(17180655731)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475623027)
                    this.AcceptLanguage = "Accept-Language";
                    //--TRIMMABLE-BOUNDARY-END(21475623027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770590323)
                    this.AcceptRanges = "Accept-Ranges";
                    //--TRIMMABLE-BOUNDARY-END(25770590323)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065557619)
                    this.AccessControlAllowCredentials = "Access-Control-Allow-Credentials";
                    //--TRIMMABLE-BOUNDARY-END(30065557619)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360524915)
                    this.AccessControlAllowHeaders = "Access-Control-Allow-Headers";
                    //--TRIMMABLE-BOUNDARY-END(34360524915)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655492211)
                    this.AccessControlAllowMethods = "Access-Control-Allow-Methods";
                    //--TRIMMABLE-BOUNDARY-END(38655492211)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950459507)
                    this.AccessControlAllowOrigin = "Access-Control-Allow-Origin";
                    //--TRIMMABLE-BOUNDARY-END(42950459507)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245426803)
                    this.AccessControlExposeHeaders = "Access-Control-Expose-Headers";
                    //--TRIMMABLE-BOUNDARY-END(47245426803)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540394099)
                    this.AccessControlMaxAge = "Access-Control-Max-Age";
                    //--TRIMMABLE-BOUNDARY-END(51540394099)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835361395)
                    this.AccessControlRequestHeaders = "Access-Control-Request-Headers";
                    //--TRIMMABLE-BOUNDARY-END(55835361395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130328691)
                    this.AccessControlRequestMethod = "Access-Control-Request-Method";
                    //--TRIMMABLE-BOUNDARY-END(60130328691)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425295987)
                    this.Age = "Age";
                    //--TRIMMABLE-BOUNDARY-END(64425295987)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720263283)
                    this.Allow = "Allow";
                    //--TRIMMABLE-BOUNDARY-END(68720263283)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015230579)
                    this.AltSvc = "Alt-Svc";
                    //--TRIMMABLE-BOUNDARY-END(73015230579)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310197875)
                    this.Authority = ":authority";
                    //--TRIMMABLE-BOUNDARY-END(77310197875)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605165171)
                    this.Authorization = "Authorization";
                    //--TRIMMABLE-BOUNDARY-END(81605165171)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900132467)
                    this.Baggage = "baggage";
                    //--TRIMMABLE-BOUNDARY-END(85900132467)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195099763)
                    this.CacheControl = "Cache-Control";
                    //--TRIMMABLE-BOUNDARY-END(90195099763)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490067059)
                    this.Connection = "Connection";
                    //--TRIMMABLE-BOUNDARY-END(94490067059)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98785034355)
                    this.ContentDisposition = "Content-Disposition";
                    //--TRIMMABLE-BOUNDARY-END(98785034355)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080001651)
                    this.ContentEncoding = "Content-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(103080001651)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374968947)
                    this.ContentLanguage = "Content-Language";
                    //--TRIMMABLE-BOUNDARY-END(107374968947)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669936243)
                    this.ContentLength = "Content-Length";
                    //--TRIMMABLE-BOUNDARY-END(111669936243)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964903539)
                    this.ContentLocation = "Content-Location";
                    //--TRIMMABLE-BOUNDARY-END(115964903539)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259870835)
                    this.ContentMD5 = "Content-MD5";
                    //--TRIMMABLE-BOUNDARY-END(120259870835)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554838131)
                    this.ContentRange = "Content-Range";
                    //--TRIMMABLE-BOUNDARY-END(124554838131)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849805427)
                    this.ContentSecurityPolicy = "Content-Security-Policy";
                    //--TRIMMABLE-BOUNDARY-END(128849805427)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144772723)
                    this.ContentSecurityPolicyReportOnly = "Content-Security-Policy-Report-Only";
                    //--TRIMMABLE-BOUNDARY-END(133144772723)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439740019)
                    this.ContentType = "Content-Type";
                    //--TRIMMABLE-BOUNDARY-END(137439740019)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029674611)
                    this.CorrelationContext = "Correlation-Context";
                    //--TRIMMABLE-BOUNDARY-END(146029674611)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734707315)
                    this.Cookie = "Cookie";
                    //--TRIMMABLE-BOUNDARY-END(141734707315)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324641907)
                    this.Date = "Date";
                    //--TRIMMABLE-BOUNDARY-END(150324641907)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619609203)
                    this.DNT = "DNT";
                    //--TRIMMABLE-BOUNDARY-END(154619609203)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914576499)
                    this.ETag = "ETag";
                    //--TRIMMABLE-BOUNDARY-END(158914576499)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504511091)
                    this.Expires = "Expires";
                    //--TRIMMABLE-BOUNDARY-END(167504511091)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209543795)
                    this.Expect = "Expect";
                    //--TRIMMABLE-BOUNDARY-END(163209543795)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799478387)
                    this.From = "From";
                    //--TRIMMABLE-BOUNDARY-END(171799478387)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094445683)
                    this.GrpcAcceptEncoding = "Grpc-Accept-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(176094445683)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389412979)
                    this.GrpcEncoding = "Grpc-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(180389412979)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184684380275)
                    this.GrpcMessage = "Grpc-Message";
                    //--TRIMMABLE-BOUNDARY-END(184684380275)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979347571)
                    this.GrpcStatus = "Grpc-Status";
                    //--TRIMMABLE-BOUNDARY-END(188979347571)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274314867)
                    this.GrpcTimeout = "Grpc-Timeout";
                    //--TRIMMABLE-BOUNDARY-END(193274314867)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569282163)
                    this.Host = "Host";
                    //--TRIMMABLE-BOUNDARY-END(197569282163)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223339085939)
                    this.KeepAlive = "Keep-Alive";
                    //--TRIMMABLE-BOUNDARY-END(223339085939)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201864249459)
                    this.IfMatch = "If-Match";
                    //--TRIMMABLE-BOUNDARY-END(201864249459)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206159216755)
                    this.IfModifiedSince = "If-Modified-Since";
                    //--TRIMMABLE-BOUNDARY-END(206159216755)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210454184051)
                    this.IfNoneMatch = "If-None-Match";
                    //--TRIMMABLE-BOUNDARY-END(210454184051)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749151347)
                    this.IfRange = "If-Range";
                    //--TRIMMABLE-BOUNDARY-END(214749151347)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219044118643)
                    this.IfUnmodifiedSince = "If-Unmodified-Since";
                    //--TRIMMABLE-BOUNDARY-END(219044118643)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227634053235)
                    this.LastModified = "Last-Modified";
                    //--TRIMMABLE-BOUNDARY-END(227634053235)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929020531)
                    this.Link = "Link";
                    //--TRIMMABLE-BOUNDARY-END(231929020531)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223987827)
                    this.Location = "Location";
                    //--TRIMMABLE-BOUNDARY-END(236223987827)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518955123)
                    this.MaxForwards = "Max-Forwards";
                    //--TRIMMABLE-BOUNDARY-END(240518955123)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813922419)
                    this.Method = ":method";
                    //--TRIMMABLE-BOUNDARY-END(244813922419)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108889715)
                    this.Origin = "Origin";
                    //--TRIMMABLE-BOUNDARY-END(249108889715)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403857011)
                    this.Path = ":path";
                    //--TRIMMABLE-BOUNDARY-END(253403857011)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698824307)
                    this.Pragma = "Pragma";
                    //--TRIMMABLE-BOUNDARY-END(257698824307)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993791603)
                    this.ProxyAuthenticate = "Proxy-Authenticate";
                    //--TRIMMABLE-BOUNDARY-END(261993791603)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288758899)
                    this.ProxyAuthorization = "Proxy-Authorization";
                    //--TRIMMABLE-BOUNDARY-END(266288758899)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583726195)
                    this.ProxyConnection = "Proxy-Connection";
                    //--TRIMMABLE-BOUNDARY-END(270583726195)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173660787)
                    this.Range = "Range";
                    //--TRIMMABLE-BOUNDARY-END(279173660787)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468628083)
                    this.Referer = "Referer";
                    //--TRIMMABLE-BOUNDARY-END(283468628083)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292058562675)
                    this.RetryAfter = "Retry-After";
                    //--TRIMMABLE-BOUNDARY-END(292058562675)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763595379)
                    this.RequestId = "Request-Id";
                    //--TRIMMABLE-BOUNDARY-END(287763595379)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296353529971)
                    this.Scheme = ":scheme";
                    //--TRIMMABLE-BOUNDARY-END(296353529971)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300648497267)
                    this.SecWebSocketAccept = "Sec-WebSocket-Accept";
                    //--TRIMMABLE-BOUNDARY-END(300648497267)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309238431859)
                    this.SecWebSocketKey = "Sec-WebSocket-Key";
                    //--TRIMMABLE-BOUNDARY-END(309238431859)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313533399155)
                    this.SecWebSocketProtocol = "Sec-WebSocket-Protocol";
                    //--TRIMMABLE-BOUNDARY-END(313533399155)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317828366451)
                    this.SecWebSocketVersion = "Sec-WebSocket-Version";
                    //--TRIMMABLE-BOUNDARY-END(317828366451)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943464563)
                    this.SecWebSocketExtensions = "Sec-WebSocket-Extensions";
                    //--TRIMMABLE-BOUNDARY-END(304943464563)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322123333747)
                    this.Server = "Server";
                    //--TRIMMABLE-BOUNDARY-END(322123333747)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326418301043)
                    this.SetCookie = "Set-Cookie";
                    //--TRIMMABLE-BOUNDARY-END(326418301043)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713268339)
                    this.Status = ":status";
                    //--TRIMMABLE-BOUNDARY-END(330713268339)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335008235635)
                    this.StrictTransportSecurity = "Strict-Transport-Security";
                    //--TRIMMABLE-BOUNDARY-END(335008235635)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339303202931)
                    this.TE = "TE";
                    //--TRIMMABLE-BOUNDARY-END(339303202931)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352188104819)
                    this.Trailer = "Trailer";
                    //--TRIMMABLE-BOUNDARY-END(352188104819)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356483072115)
                    this.TransferEncoding = "Transfer-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(356483072115)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360778039411)
                    this.Translate = "Translate";
                    //--TRIMMABLE-BOUNDARY-END(360778039411)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598170227)
                    this.TraceParent = "traceparent";
                    //--TRIMMABLE-BOUNDARY-END(343598170227)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347893137523)
                    this.TraceState = "tracestate";
                    //--TRIMMABLE-BOUNDARY-END(347893137523)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365073006707)
                    this.Upgrade = "Upgrade";
                    //--TRIMMABLE-BOUNDARY-END(365073006707)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367974003)
                    this.UpgradeInsecureRequests = "Upgrade-Insecure-Requests";
                    //--TRIMMABLE-BOUNDARY-END(369367974003)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662941299)
                    this.UserAgent = "User-Agent";
                    //--TRIMMABLE-BOUNDARY-END(373662941299)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957908595)
                    this.Vary = "Vary";
                    //--TRIMMABLE-BOUNDARY-END(377957908595)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(382252875891)
                    this.Via = "Via";
                    //--TRIMMABLE-BOUNDARY-END(382252875891)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547843187)
                    this.Warning = "Warning";
                    //--TRIMMABLE-BOUNDARY-END(386547843187)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842810483)
                    this.WebSocketSubProtocols = "Sec-WebSocket-Protocol";
                    //--TRIMMABLE-BOUNDARY-END(390842810483)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137777779)
                    this.WWWAuthenticate = "WWW-Authenticate";
                    //--TRIMMABLE-BOUNDARY-END(395137777779)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432745075)
                    this.XContentTypeOptions = "X-Content-Type-Options";
                    //--TRIMMABLE-BOUNDARY-END(399432745075)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727712371)
                    this.XFrameOptions = "X-Frame-Options";
                    //--TRIMMABLE-BOUNDARY-END(403727712371)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022679667)
                    this.XPoweredBy = "X-Powered-By";
                    //--TRIMMABLE-BOUNDARY-END(408022679667)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412317646963)
                    this.XRequestedWith = "X-Requested-With";
                    //--TRIMMABLE-BOUNDARY-END(412317646963)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416612614259)
                    this.XUACompatible = "X-UA-Compatible";
                    //--TRIMMABLE-BOUNDARY-END(416612614259)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420907581555)
                    this.XXSSProtection = "X-XSS-Protection";
                    //--TRIMMABLE-BOUNDARY-END(420907581555)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753843)
            
            static $h = 786547;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(274878693491),
    {
      "t": 1310721,
      "n": "PseudoHeaderNamesObsoletionMessage",
      "d": 786547,
      "h": 274878693491,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(274878693491),
//--TRIMMABLE-BOUNDARY-START(8590721139),
    {
      "t": 1310721,
      "n": "Accept",
      "d": 786547,
      "h": 8590721139,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721139),
//--TRIMMABLE-BOUNDARY-START(12885688435),
    {
      "t": 1310721,
      "n": "AcceptCharset",
      "d": 786547,
      "h": 12885688435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688435),
//--TRIMMABLE-BOUNDARY-START(17180655731),
    {
      "t": 1310721,
      "n": "AcceptEncoding",
      "d": 786547,
      "h": 17180655731,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180655731),
//--TRIMMABLE-BOUNDARY-START(21475623027),
    {
      "t": 1310721,
      "n": "AcceptLanguage",
      "d": 786547,
      "h": 21475623027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475623027),
//--TRIMMABLE-BOUNDARY-START(25770590323),
    {
      "t": 1310721,
      "n": "AcceptRanges",
      "d": 786547,
      "h": 25770590323,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770590323),
//--TRIMMABLE-BOUNDARY-START(30065557619),
    {
      "t": 1310721,
      "n": "AccessControlAllowCredentials",
      "d": 786547,
      "h": 30065557619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065557619),
//--TRIMMABLE-BOUNDARY-START(34360524915),
    {
      "t": 1310721,
      "n": "AccessControlAllowHeaders",
      "d": 786547,
      "h": 34360524915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360524915),
//--TRIMMABLE-BOUNDARY-START(38655492211),
    {
      "t": 1310721,
      "n": "AccessControlAllowMethods",
      "d": 786547,
      "h": 38655492211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655492211),
//--TRIMMABLE-BOUNDARY-START(42950459507),
    {
      "t": 1310721,
      "n": "AccessControlAllowOrigin",
      "d": 786547,
      "h": 42950459507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950459507),
//--TRIMMABLE-BOUNDARY-START(47245426803),
    {
      "t": 1310721,
      "n": "AccessControlExposeHeaders",
      "d": 786547,
      "h": 47245426803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245426803),
//--TRIMMABLE-BOUNDARY-START(51540394099),
    {
      "t": 1310721,
      "n": "AccessControlMaxAge",
      "d": 786547,
      "h": 51540394099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540394099),
//--TRIMMABLE-BOUNDARY-START(55835361395),
    {
      "t": 1310721,
      "n": "AccessControlRequestHeaders",
      "d": 786547,
      "h": 55835361395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835361395),
//--TRIMMABLE-BOUNDARY-START(60130328691),
    {
      "t": 1310721,
      "n": "AccessControlRequestMethod",
      "d": 786547,
      "h": 60130328691,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130328691),
//--TRIMMABLE-BOUNDARY-START(64425295987),
    {
      "t": 1310721,
      "n": "Age",
      "d": 786547,
      "h": 64425295987,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425295987),
//--TRIMMABLE-BOUNDARY-START(68720263283),
    {
      "t": 1310721,
      "n": "Allow",
      "d": 786547,
      "h": 68720263283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720263283),
//--TRIMMABLE-BOUNDARY-START(73015230579),
    {
      "t": 1310721,
      "n": "AltSvc",
      "d": 786547,
      "h": 73015230579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015230579),
//--TRIMMABLE-BOUNDARY-START(77310197875),
    {
      "t": 1310721,
      "n": "Authority",
      "d": 786547,
      "h": 77310197875,
      "f": 4194337,
      "a": [
        {
          "t": 103612417,
          "c": 12988514305,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310197875),
//--TRIMMABLE-BOUNDARY-START(81605165171),
    {
      "t": 1310721,
      "n": "Authorization",
      "d": 786547,
      "h": 81605165171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605165171),
//--TRIMMABLE-BOUNDARY-START(85900132467),
    {
      "t": 1310721,
      "n": "Baggage",
      "d": 786547,
      "h": 85900132467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900132467),
//--TRIMMABLE-BOUNDARY-START(90195099763),
    {
      "t": 1310721,
      "n": "CacheControl",
      "d": 786547,
      "h": 90195099763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195099763),
//--TRIMMABLE-BOUNDARY-START(94490067059),
    {
      "t": 1310721,
      "n": "Connection",
      "d": 786547,
      "h": 94490067059,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490067059),
//--TRIMMABLE-BOUNDARY-START(98785034355),
    {
      "t": 1310721,
      "n": "ContentDisposition",
      "d": 786547,
      "h": 98785034355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785034355),
//--TRIMMABLE-BOUNDARY-START(103080001651),
    {
      "t": 1310721,
      "n": "ContentEncoding",
      "d": 786547,
      "h": 103080001651,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080001651),
//--TRIMMABLE-BOUNDARY-START(107374968947),
    {
      "t": 1310721,
      "n": "ContentLanguage",
      "d": 786547,
      "h": 107374968947,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374968947),
//--TRIMMABLE-BOUNDARY-START(111669936243),
    {
      "t": 1310721,
      "n": "ContentLength",
      "d": 786547,
      "h": 111669936243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669936243),
//--TRIMMABLE-BOUNDARY-START(115964903539),
    {
      "t": 1310721,
      "n": "ContentLocation",
      "d": 786547,
      "h": 115964903539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964903539),
//--TRIMMABLE-BOUNDARY-START(120259870835),
    {
      "t": 1310721,
      "n": "ContentMD5",
      "d": 786547,
      "h": 120259870835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259870835),
//--TRIMMABLE-BOUNDARY-START(124554838131),
    {
      "t": 1310721,
      "n": "ContentRange",
      "d": 786547,
      "h": 124554838131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554838131),
//--TRIMMABLE-BOUNDARY-START(128849805427),
    {
      "t": 1310721,
      "n": "ContentSecurityPolicy",
      "d": 786547,
      "h": 128849805427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849805427),
//--TRIMMABLE-BOUNDARY-START(133144772723),
    {
      "t": 1310721,
      "n": "ContentSecurityPolicyReportOnly",
      "d": 786547,
      "h": 133144772723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144772723),
//--TRIMMABLE-BOUNDARY-START(137439740019),
    {
      "t": 1310721,
      "n": "ContentType",
      "d": 786547,
      "h": 137439740019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439740019),
//--TRIMMABLE-BOUNDARY-START(146029674611),
    {
      "t": 1310721,
      "n": "CorrelationContext",
      "d": 786547,
      "h": 146029674611,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029674611),
//--TRIMMABLE-BOUNDARY-START(141734707315),
    {
      "t": 1310721,
      "n": "Cookie",
      "d": 786547,
      "h": 141734707315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734707315),
//--TRIMMABLE-BOUNDARY-START(150324641907),
    {
      "t": 1310721,
      "n": "Date",
      "d": 786547,
      "h": 150324641907,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324641907),
//--TRIMMABLE-BOUNDARY-START(154619609203),
    {
      "t": 1310721,
      "n": "DNT",
      "d": 786547,
      "h": 154619609203,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619609203),
//--TRIMMABLE-BOUNDARY-START(158914576499),
    {
      "t": 1310721,
      "n": "ETag",
      "d": 786547,
      "h": 158914576499,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914576499),
//--TRIMMABLE-BOUNDARY-START(167504511091),
    {
      "t": 1310721,
      "n": "Expires",
      "d": 786547,
      "h": 167504511091,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504511091),
//--TRIMMABLE-BOUNDARY-START(163209543795),
    {
      "t": 1310721,
      "n": "Expect",
      "d": 786547,
      "h": 163209543795,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209543795),
//--TRIMMABLE-BOUNDARY-START(171799478387),
    {
      "t": 1310721,
      "n": "From",
      "d": 786547,
      "h": 171799478387,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799478387),
//--TRIMMABLE-BOUNDARY-START(176094445683),
    {
      "t": 1310721,
      "n": "GrpcAcceptEncoding",
      "d": 786547,
      "h": 176094445683,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094445683),
//--TRIMMABLE-BOUNDARY-START(180389412979),
    {
      "t": 1310721,
      "n": "GrpcEncoding",
      "d": 786547,
      "h": 180389412979,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389412979),
//--TRIMMABLE-BOUNDARY-START(184684380275),
    {
      "t": 1310721,
      "n": "GrpcMessage",
      "d": 786547,
      "h": 184684380275,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684380275),
//--TRIMMABLE-BOUNDARY-START(188979347571),
    {
      "t": 1310721,
      "n": "GrpcStatus",
      "d": 786547,
      "h": 188979347571,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188979347571),
//--TRIMMABLE-BOUNDARY-START(193274314867),
    {
      "t": 1310721,
      "n": "GrpcTimeout",
      "d": 786547,
      "h": 193274314867,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193274314867),
//--TRIMMABLE-BOUNDARY-START(197569282163),
    {
      "t": 1310721,
      "n": "Host",
      "d": 786547,
      "h": 197569282163,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197569282163),
//--TRIMMABLE-BOUNDARY-START(223339085939),
    {
      "t": 1310721,
      "n": "KeepAlive",
      "d": 786547,
      "h": 223339085939,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223339085939),
//--TRIMMABLE-BOUNDARY-START(201864249459),
    {
      "t": 1310721,
      "n": "IfMatch",
      "d": 786547,
      "h": 201864249459,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201864249459),
//--TRIMMABLE-BOUNDARY-START(206159216755),
    {
      "t": 1310721,
      "n": "IfModifiedSince",
      "d": 786547,
      "h": 206159216755,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206159216755),
//--TRIMMABLE-BOUNDARY-START(210454184051),
    {
      "t": 1310721,
      "n": "IfNoneMatch",
      "d": 786547,
      "h": 210454184051,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210454184051),
//--TRIMMABLE-BOUNDARY-START(214749151347),
    {
      "t": 1310721,
      "n": "IfRange",
      "d": 786547,
      "h": 214749151347,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214749151347),
//--TRIMMABLE-BOUNDARY-START(219044118643),
    {
      "t": 1310721,
      "n": "IfUnmodifiedSince",
      "d": 786547,
      "h": 219044118643,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219044118643),
//--TRIMMABLE-BOUNDARY-START(227634053235),
    {
      "t": 1310721,
      "n": "LastModified",
      "d": 786547,
      "h": 227634053235,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227634053235),
//--TRIMMABLE-BOUNDARY-START(231929020531),
    {
      "t": 1310721,
      "n": "Link",
      "d": 786547,
      "h": 231929020531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231929020531),
//--TRIMMABLE-BOUNDARY-START(236223987827),
    {
      "t": 1310721,
      "n": "Location",
      "d": 786547,
      "h": 236223987827,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236223987827),
//--TRIMMABLE-BOUNDARY-START(240518955123),
    {
      "t": 1310721,
      "n": "MaxForwards",
      "d": 786547,
      "h": 240518955123,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240518955123),
//--TRIMMABLE-BOUNDARY-START(244813922419),
    {
      "t": 1310721,
      "n": "Method",
      "d": 786547,
      "h": 244813922419,
      "f": 4194337,
      "a": [
        {
          "t": 103612417,
          "c": 12988514305,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244813922419),
//--TRIMMABLE-BOUNDARY-START(249108889715),
    {
      "t": 1310721,
      "n": "Origin",
      "d": 786547,
      "h": 249108889715,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249108889715),
//--TRIMMABLE-BOUNDARY-START(253403857011),
    {
      "t": 1310721,
      "n": "Path",
      "d": 786547,
      "h": 253403857011,
      "f": 4194337,
      "a": [
        {
          "t": 103612417,
          "c": 12988514305,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253403857011),
//--TRIMMABLE-BOUNDARY-START(257698824307),
    {
      "t": 1310721,
      "n": "Pragma",
      "d": 786547,
      "h": 257698824307,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257698824307),
//--TRIMMABLE-BOUNDARY-START(261993791603),
    {
      "t": 1310721,
      "n": "ProxyAuthenticate",
      "d": 786547,
      "h": 261993791603,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993791603),
//--TRIMMABLE-BOUNDARY-START(266288758899),
    {
      "t": 1310721,
      "n": "ProxyAuthorization",
      "d": 786547,
      "h": 266288758899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288758899),
//--TRIMMABLE-BOUNDARY-START(270583726195),
    {
      "t": 1310721,
      "n": "ProxyConnection",
      "d": 786547,
      "h": 270583726195,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270583726195),
//--TRIMMABLE-BOUNDARY-START(279173660787),
    {
      "t": 1310721,
      "n": "Range",
      "d": 786547,
      "h": 279173660787,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173660787),
//--TRIMMABLE-BOUNDARY-START(283468628083),
    {
      "t": 1310721,
      "n": "Referer",
      "d": 786547,
      "h": 283468628083,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283468628083),
//--TRIMMABLE-BOUNDARY-START(292058562675),
    {
      "t": 1310721,
      "n": "RetryAfter",
      "d": 786547,
      "h": 292058562675,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292058562675),
//--TRIMMABLE-BOUNDARY-START(287763595379),
    {
      "t": 1310721,
      "n": "RequestId",
      "d": 786547,
      "h": 287763595379,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287763595379),
//--TRIMMABLE-BOUNDARY-START(296353529971),
    {
      "t": 1310721,
      "n": "Scheme",
      "d": 786547,
      "h": 296353529971,
      "f": 4194337,
      "a": [
        {
          "t": 103612417,
          "c": 12988514305,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(296353529971),
//--TRIMMABLE-BOUNDARY-START(300648497267),
    {
      "t": 1310721,
      "n": "SecWebSocketAccept",
      "d": 786547,
      "h": 300648497267,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(300648497267),
//--TRIMMABLE-BOUNDARY-START(309238431859),
    {
      "t": 1310721,
      "n": "SecWebSocketKey",
      "d": 786547,
      "h": 309238431859,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(309238431859),
//--TRIMMABLE-BOUNDARY-START(313533399155),
    {
      "t": 1310721,
      "n": "SecWebSocketProtocol",
      "d": 786547,
      "h": 313533399155,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313533399155),
//--TRIMMABLE-BOUNDARY-START(317828366451),
    {
      "t": 1310721,
      "n": "SecWebSocketVersion",
      "d": 786547,
      "h": 317828366451,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(317828366451),
//--TRIMMABLE-BOUNDARY-START(304943464563),
    {
      "t": 1310721,
      "n": "SecWebSocketExtensions",
      "d": 786547,
      "h": 304943464563,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304943464563),
//--TRIMMABLE-BOUNDARY-START(322123333747),
    {
      "t": 1310721,
      "n": "Server",
      "d": 786547,
      "h": 322123333747,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322123333747),
//--TRIMMABLE-BOUNDARY-START(326418301043),
    {
      "t": 1310721,
      "n": "SetCookie",
      "d": 786547,
      "h": 326418301043,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(326418301043),
//--TRIMMABLE-BOUNDARY-START(330713268339),
    {
      "t": 1310721,
      "n": "Status",
      "d": 786547,
      "h": 330713268339,
      "f": 4194337,
      "a": [
        {
          "t": 103612417,
          "c": 12988514305,
          "a": [
            {
              "v": "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.",
              "t": 1310721
            },
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330713268339),
//--TRIMMABLE-BOUNDARY-START(335008235635),
    {
      "t": 1310721,
      "n": "StrictTransportSecurity",
      "d": 786547,
      "h": 335008235635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335008235635),
//--TRIMMABLE-BOUNDARY-START(339303202931),
    {
      "t": 1310721,
      "n": "TE",
      "d": 786547,
      "h": 339303202931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339303202931),
//--TRIMMABLE-BOUNDARY-START(352188104819),
    {
      "t": 1310721,
      "n": "Trailer",
      "d": 786547,
      "h": 352188104819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352188104819),
//--TRIMMABLE-BOUNDARY-START(356483072115),
    {
      "t": 1310721,
      "n": "TransferEncoding",
      "d": 786547,
      "h": 356483072115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(356483072115),
//--TRIMMABLE-BOUNDARY-START(360778039411),
    {
      "t": 1310721,
      "n": "Translate",
      "d": 786547,
      "h": 360778039411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360778039411),
//--TRIMMABLE-BOUNDARY-START(343598170227),
    {
      "t": 1310721,
      "n": "TraceParent",
      "d": 786547,
      "h": 343598170227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343598170227),
//--TRIMMABLE-BOUNDARY-START(347893137523),
    {
      "t": 1310721,
      "n": "TraceState",
      "d": 786547,
      "h": 347893137523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347893137523),
//--TRIMMABLE-BOUNDARY-START(365073006707),
    {
      "t": 1310721,
      "n": "Upgrade",
      "d": 786547,
      "h": 365073006707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(365073006707),
//--TRIMMABLE-BOUNDARY-START(369367974003),
    {
      "t": 1310721,
      "n": "UpgradeInsecureRequests",
      "d": 786547,
      "h": 369367974003,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369367974003),
//--TRIMMABLE-BOUNDARY-START(373662941299),
    {
      "t": 1310721,
      "n": "UserAgent",
      "d": 786547,
      "h": 373662941299,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(373662941299),
//--TRIMMABLE-BOUNDARY-START(377957908595),
    {
      "t": 1310721,
      "n": "Vary",
      "d": 786547,
      "h": 377957908595,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(377957908595),
//--TRIMMABLE-BOUNDARY-START(382252875891),
    {
      "t": 1310721,
      "n": "Via",
      "d": 786547,
      "h": 382252875891,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(382252875891),
//--TRIMMABLE-BOUNDARY-START(386547843187),
    {
      "t": 1310721,
      "n": "Warning",
      "d": 786547,
      "h": 386547843187,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(386547843187),
//--TRIMMABLE-BOUNDARY-START(390842810483),
    {
      "t": 1310721,
      "n": "WebSocketSubProtocols",
      "d": 786547,
      "h": 390842810483,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(390842810483),
//--TRIMMABLE-BOUNDARY-START(395137777779),
    {
      "t": 1310721,
      "n": "WWWAuthenticate",
      "d": 786547,
      "h": 395137777779,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(395137777779),
//--TRIMMABLE-BOUNDARY-START(399432745075),
    {
      "t": 1310721,
      "n": "XContentTypeOptions",
      "d": 786547,
      "h": 399432745075,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(399432745075),
//--TRIMMABLE-BOUNDARY-START(403727712371),
    {
      "t": 1310721,
      "n": "XFrameOptions",
      "d": 786547,
      "h": 403727712371,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(403727712371),
//--TRIMMABLE-BOUNDARY-START(408022679667),
    {
      "t": 1310721,
      "n": "XPoweredBy",
      "d": 786547,
      "h": 408022679667,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(408022679667),
//--TRIMMABLE-BOUNDARY-START(412317646963),
    {
      "t": 1310721,
      "n": "XRequestedWith",
      "d": 786547,
      "h": 412317646963,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(412317646963),
//--TRIMMABLE-BOUNDARY-START(416612614259),
    {
      "t": 1310721,
      "n": "XUACompatible",
      "d": 786547,
      "h": 416612614259,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(416612614259),
//--TRIMMABLE-BOUNDARY-START(420907581555),
    {
      "t": 1310721,
      "n": "XXSSProtection",
      "d": 786547,
      "h": 420907581555,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(420907581555)
  ],
  "h": 786547
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HeaderNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786547)
        
        
        //--TRIMMABLE-BOUNDARY-START(852083)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HeaderQuality", ($self) => class HeaderQuality
        {
            //--TRIMMABLE-BOUNDARY-START(4295819379)
            /*double*/ static Match = 1;
            //--TRIMMABLE-BOUNDARY-END(4295819379)
            
            //--TRIMMABLE-BOUNDARY-START(8590786675)
            /*double*/ static NoMatch = 0;
            //--TRIMMABLE-BOUNDARY-END(8590786675)
            
            static $h = 852083;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819379),
    {
      "t": 1179649,
      "n": "Match",
      "d": 852083,
      "h": 4295819379,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295819379),
//--TRIMMABLE-BOUNDARY-START(8590786675),
    {
      "t": 1179649,
      "n": "NoMatch",
      "d": 852083,
      "h": 8590786675,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786675)
  ],
  "h": 852083
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HeaderQuality`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852083)
        
        
        //--TRIMMABLE-BOUNDARY-START(458867)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared", ($self) => class CookieHeaderParserShared
        {
            //--TRIMMABLE-BOUNDARY-START(8590393459)
            /*SearchValues<char>*/ static CookieValueChar = null;
            //--TRIMMABLE-BOUNDARY-END(8590393459)
            
            //--TRIMMABLE-BOUNDARY-START(34360197235)
            static /*bool */ TryParseValues(/*StringValues*/ values, /*IDictionary<string, string>*/ store, /*bool*/ supportsMultipleValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (values.Count === 0)
                {
                    return false;
                }
                /*var*/ let hasFoundValue = false;
                for(/*var*/ let i = 0; i < values.Count; i++)
                {
                    /*var*/ let value = values.get_Item(i);
                    /*var*/ let index = 0;
                    while(!$.$$.System.String.IsNullOrEmpty(value) && index < value.length)
                    {
                        /*var*/ let parsedName;
                        /*var*/ let parsedValue;
                        if ($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.TryParseValue($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), supportsMultipleValues, $.$ref(() => parsedName, ($v) => parsedName = $v, $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment)), $.$ref(() => parsedValue, ($v) => parsedValue = $v, $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment))))
                        {
                            if (parsedName === null || $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedName)) || parsedValue === null || $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedValue)))
                            {
                                continue;
                            }
                            store.System$Collections$Generic$IDictionary$$$$set_Item($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedName).Value, $.$spu.System.Uri.UnescapeDataString$2($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedValue).Value), [$.$$.System.String, $.$$.System.String]);
                            hasFoundValue = true;
                        }
                        else 
                        {
                            index++;
                        }
                    }
                }
                return hasFoundValue;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197235)
            
            //--TRIMMABLE-BOUNDARY-START(30065229939)
            static /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*bool*/ supportsMultipleValues, /*out StringSegment?*/ parsedName, /*out StringSegment?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parsedName.$v = null;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value) || (index.$v === value.Length))
                {
                    return supportsMultipleValues;
                }
                /*var*/ let separatorFound;
                /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetNextNonEmptyOrWhitespaceIndex(value, index.$v, supportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                if (separatorFound && !supportsMultipleValues)
                {
                    return false;
                }
                if (current === value.Length)
                {
                    if (supportsMultipleValues)
                    {
                        index.$v = current;
                    }
                    return supportsMultipleValues;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.TryGetCookieLength(value, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), parsedName, parsedValue))
                {
                    /*var*/ let separatorIndex = value.IndexOf$1(/*;*/ 59, current);
                    if (separatorIndex > 0)
                    {
                        index.$v = separatorIndex;
                    }
                    else 
                    {
                        index.$v = value.Length;
                    }
                    return false;
                }
                current = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetNextNonEmptyOrWhitespaceIndex(value, current, supportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                if ((separatorFound && !supportsMultipleValues) || (!separatorFound && (current < value.Length)))
                {
                    /*var*/ let separatorIndex = value.IndexOf$1(/*;*/ 59, current);
                    if (separatorIndex > 0)
                    {
                        index.$v = separatorIndex;
                    }
                    else 
                    {
                        index.$v = value.Length;
                    }
                    return false;
                }
                index.$v = current;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30065229939)
            
            //--TRIMMABLE-BOUNDARY-START(17180328051)
            static /*int */ GetNextNonEmptyOrWhitespaceIndex(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ skipEmptyValues, /*out bool*/ separatorFound)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                separatorFound.$v = false;
                /*var*/ let current = ((startIndex + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                if (current === input.Length || input.get_Item(current) !== /*;*/ 59)
                {
                    return current;
                }
                separatorFound.$v = true;
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (skipEmptyValues)
                {
                    while(current < input.Length && input.get_Item(current) === /*;*/ 59)
                    {
                        current++;
                        current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                }
                return current;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328051)
            
            //--TRIMMABLE-BOUNDARY-START(25770262643)
            static /*bool */ TryGetCookieLength(/*StringSegment*/ input, /*ref int*/ offset, /*out StringSegment?*/ parsedName, /*out StringSegment?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedName.$v = null;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (offset.$v >= input.Length))
                {
                    return false;
                }
                /*var*/ let itemLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, offset.$v);
                if (itemLength === 0)
                {
                    return false;
                }
                parsedName.$v = input.Subsegment(offset.$v, itemLength);
                offset.$v += itemLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.ReadEqualsSign(input, offset))
                {
                    return false;
                }
                parsedValue.$v = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetCookieValue(input, offset);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262643)
            
            //--TRIMMABLE-BOUNDARY-START(12885360755)
            static /*StringSegment */ GetCookieValue(/*StringSegment*/ input, /*ref int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                ;
                /*var*/ let startIndex = offset.$v;
                if (offset.$v >= input.Length)
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty;
                }
                /*var*/ let inQuotes = false;
                if (input.get_Item(offset.$v) === /*\"*/ 34)
                {
                    inQuotes = true;
                    offset.$v++;
                }
                /*var*/ let delta = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, input.AsSpan$2(offset.$v), $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.CookieValueChar);
                if (delta < 0)
                {
                    offset.$v = input.Length;
                }
                else 
                {
                    offset.$v += delta;
                }
                if (inQuotes)
                {
                    if (offset.$v === input.Length || input.get_Item(offset.$v) !== /*\"*/ 34)
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty;
                    }
                    offset.$v++;
                }
                /*var*/ let length = ((offset.$v - startIndex) | 0);
                if (offset.$v > startIndex)
                {
                    return input.Subsegment(startIndex, length);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360755)
            
            //--TRIMMABLE-BOUNDARY-START(21475295347)
            static /*bool */ ReadEqualsSign(/*StringSegment*/ input, /*ref int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset.$v >= input.Length || input.get_Item(offset.$v) !== /*=*/ 61)
                {
                    return false;
                }
                offset.$v++;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295347)
            
            //--TRIMMABLE-BOUNDARY-START(4295426163)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393459)
                    this.CookieValueChar = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!#$%&'()*+-./0123456789:<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
                    //--TRIMMABLE-BOUNDARY-END(8590393459)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426163)
            
            static $h = 458867;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360197235),
    {
      "r": 262145,
      "p": [
        {
          "n": "values",
          "p": 1114197
        },
        {
          "n": "store",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        },
        {
          "n": "supportsMultipleValues",
          "p": 262145
        }
      ],
      "n": "TryParseValues",
      "d": 458867,
      "h": 34360197235,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360197235),
//--TRIMMABLE-BOUNDARY-START(30065229939),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "supportsMultipleValues",
          "p": 262145
        },
        {
          "n": "parsedName",
          "p": $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
          "f": 2
        },
        {
          "n": "parsedValue",
          "p": $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
          "f": 2
        }
      ],
      "n": "TryParseValue",
      "d": 458867,
      "h": 30065229939,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065229939),
//--TRIMMABLE-BOUNDARY-START(17180328051),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "skipEmptyValues",
          "p": 262145
        },
        {
          "n": "separatorFound",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "GetNextNonEmptyOrWhitespaceIndex",
      "d": 458867,
      "h": 17180328051,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180328051),
//--TRIMMABLE-BOUNDARY-START(25770262643),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        },
        {
          "n": "parsedName",
          "p": $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
          "f": 2
        },
        {
          "n": "parsedValue",
          "p": $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
          "f": 2
        }
      ],
      "n": "TryGetCookieLength",
      "d": 458867,
      "h": 25770262643,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770262643),
//--TRIMMABLE-BOUNDARY-START(12885360755),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "GetCookieValue",
      "d": 458867,
      "h": 12885360755,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885360755),
//--TRIMMABLE-BOUNDARY-START(21475295347),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "ReadEqualsSign",
      "d": 458867,
      "h": 21475295347,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475295347)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393459),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "CookieValueChar",
      "d": 458867,
      "h": 8590393459,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590393459)
  ],
  "h": 458867
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `CookieHeaderParserShared`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458867)
        
        
        //--TRIMMABLE-BOUNDARY-START(589939)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue", ($self) => class EntityTagHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(103079805043)
            /*HttpHeaderParser<EntityTagHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(103079805043)
            
            //--TRIMMABLE-BOUNDARY-START(85899935859)
            /*HttpHeaderParser<EntityTagHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(85899935859)
            
            //--TRIMMABLE-BOUNDARY-START(8590524531)
            /*StringSegment*/ _tag;
            //--TRIMMABLE-BOUNDARY-END(8590524531)
            
            //--TRIMMABLE-BOUNDARY-START(4295557235)
            /*bool*/ _isWeak = false;
            //--TRIMMABLE-BOUNDARY-END(4295557235)
            
            //--TRIMMABLE-BOUNDARY-START(17180459123)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459123)
            
            //--TRIMMABLE-BOUNDARY-START(21475426419)
            $ctor$3(/*StringSegment*/ tag)
            {
                this.$ctor$2(tag, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426419)
            
            //--TRIMMABLE-BOUNDARY-START(25770393715)
            $ctor$2(/*StringSegment*/ tag, /*bool*/ isWeak)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393715);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(tag))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("An empty string is not allowed.", "tag");
                    }
                    /*var*/ let length;
                    if (!isWeak && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(tag, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("*"), 4/*StringComparison.Ordinal*/))
                    {
                        this._tag = tag;
                    }
                    else if (($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetQuotedStringLength(tag, 0, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)) !== 0/*HttpParseResult.Parsed*/) || (length !== tag.Length))
                    {
                        throw new $.$$.System.FormatException().$ctor$12("Invalid ETag name");
                    }
                    this._tag = tag;
                    this._isWeak = isWeak;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393715)
            
            //--TRIMMABLE-BOUNDARY-START(34360328307)
            /*EntityTagHeaderValue*/ static Any = null;
            //--TRIMMABLE-BOUNDARY-END(34360328307)
            
            //--TRIMMABLE-BOUNDARY-START(107374772339)
            /*StringSegment */ get Tag()
            {
                return this._tag;
            }
            //--TRIMMABLE-BOUNDARY-END(107374772339)
            
            //--TRIMMABLE-BOUNDARY-START(81604968563)
            /*bool */ get IsWeak()
            {
                return this._isWeak;
            }
            //--TRIMMABLE-BOUNDARY-END(81604968563)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 111669739635, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isWeak)
                {
                    return "W/" + $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._tag);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._tag);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 111669739635, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42950262899, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue, { set $v(v){ other = v; } }) && this._isWeak === other._isWeak && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._tag, other._tag, 4/*StringComparison.Ordinal*/);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42950262899, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 77310001267, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(this._tag) ^ $.$$.System.Boolean.GetHashCode.call(this._isWeak);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 77310001267, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(38655295603)
            /*bool */ Compare(/*EntityTagHeaderValue?*/ other, /*bool*/ useStrongComparison)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (other === null)
                {
                    return false;
                }
                if (useStrongComparison)
                {
                    return !this.IsWeak && !other.IsWeak && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Tag, other.Tag, 4/*StringComparison.Ordinal*/);
                }
                else 
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Tag, other.Tag, 4/*StringComparison.Ordinal*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655295603)
            
            //--TRIMMABLE-BOUNDARY-START(90194903155)
            static /*EntityTagHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(90194903155)
            
            //--TRIMMABLE-BOUNDARY-START(115964706931)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out EntityTagHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(115964706931)
            
            //--TRIMMABLE-BOUNDARY-START(94489870451)
            static /*IList<EntityTagHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(94489870451)
            
            //--TRIMMABLE-BOUNDARY-START(98784837747)
            static /*IList<EntityTagHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(98784837747)
            
            //--TRIMMABLE-BOUNDARY-START(120259674227)
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<EntityTagHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.MultipleValueParser.TryParseValues$1(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(120259674227)
            
            //--TRIMMABLE-BOUNDARY-START(124554641523)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<EntityTagHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(124554641523)
            
            //--TRIMMABLE-BOUNDARY-START(73015033971)
            static /*int */ GetEntityTagLength(/*StringSegment*/ input, /*int*/ startIndex, /*out EntityTagHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let isWeak = false;
                /*var*/ let current = startIndex;
                /*var*/ let firstChar = input.get_Item(startIndex);
                if (firstChar === /***/ 42)
                {
                    parsedValue.$v = $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.Any;
                    current++;
                }
                else 
                {
                    if ((firstChar === /*W*/ 87) || (firstChar === /*w*/ 119))
                    {
                        current++;
                        if ((((current + 2) | 0) >= input.Length) || (input.get_Item(current) !== /*/*/ 47))
                        {
                            return 0;
                        }
                        isWeak = true;
                        current++;
                        current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                    /*var*/ let tagStartIndex = current;
                    /*var*/ let tagLength;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetQuotedStringLength(input, current, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.System.Int32)) !== 0/*HttpParseResult.Parsed*/)
                    {
                        return 0;
                    }
                    parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue().$ctor$1();
                    if (tagLength === input.Length)
                    {
                        $.$$.System.Diagnostics.Contracts.Contract.Assert$1(startIndex === 0);
                        $.$$.System.Diagnostics.Contracts.Contract.Assert$1(!isWeak);
                        parsedValue.$v._tag = input;
                        parsedValue.$v._isWeak = false;
                    }
                    else 
                    {
                        parsedValue.$v._tag = input.Subsegment(tagStartIndex, tagLength);
                        parsedValue.$v._isWeak = isWeak;
                    }
                    current = ((current + tagLength) | 0);
                }
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(73015033971)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590524531)
                this._tag = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8590524531)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885491827)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(103079805043)
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetEntityTagLength));
                    //--TRIMMABLE-BOUNDARY-END(103079805043)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899935859)
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetEntityTagLength));
                    //--TRIMMABLE-BOUNDARY-END(85899935859)
                    
                }
                {
                    this.Any = new $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("*"), false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885491827)
            
            static $h = 589939;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360328307),
    {
      "p": 589939,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197491,
        "f": 50331681
      },
      "n": "Any",
      "d": 589939,
      "h": 34360328307,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360328307),
//--TRIMMABLE-BOUNDARY-START(107374772339),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066675,
        "f": 50331649
      },
      "n": "Tag",
      "d": 589939,
      "h": 107374772339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374772339),
//--TRIMMABLE-BOUNDARY-START(81604968563),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132083,
        "f": 50331649
      },
      "n": "IsWeak",
      "d": 589939,
      "h": 81604968563,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604968563)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 111669739635, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 589939,
      "h": 111669739635,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 111669739635, 330712612865),
//--TRIMMABLE-BOUNDARY-START(ALL, 42950262899, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 589939,
      "h": 42950262899,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42950262899, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 77310001267, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 589939,
      "h": 77310001267,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 77310001267, 184683724801),
//--TRIMMABLE-BOUNDARY-START(38655295603),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 589939
        },
        {
          "n": "useStrongComparison",
          "p": 262145
        }
      ],
      "n": "Compare",
      "d": 589939,
      "h": 38655295603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295603),
//--TRIMMABLE-BOUNDARY-START(90194903155),
    {
      "r": 589939,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 589939,
      "h": 90194903155,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194903155),
//--TRIMMABLE-BOUNDARY-START(115964706931),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 589939,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 589939,
      "h": 115964706931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964706931),
//--TRIMMABLE-BOUNDARY-START(94489870451),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseList",
      "d": 589939,
      "h": 94489870451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94489870451),
//--TRIMMABLE-BOUNDARY-START(98784837747),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 589939,
      "h": 98784837747,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98784837747),
//--TRIMMABLE-BOUNDARY-START(120259674227),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 589939,
      "h": 120259674227,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120259674227),
//--TRIMMABLE-BOUNDARY-START(124554641523),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 589939,
      "h": 124554641523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124554641523),
//--TRIMMABLE-BOUNDARY-START(73015033971),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 589939,
          "f": 2
        }
      ],
      "n": "GetEntityTagLength",
      "d": 589939,
      "h": 73015033971,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73015033971)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(103079805043),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 589939,
      "h": 103079805043,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103079805043),
//--TRIMMABLE-BOUNDARY-START(85899935859),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 589939,
      "h": 85899935859,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85899935859),
//--TRIMMABLE-BOUNDARY-START(8590524531),
    {
      "t": 852053,
      "n": "_tag",
      "d": 589939,
      "h": 8590524531,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524531),
//--TRIMMABLE-BOUNDARY-START(4295557235),
    {
      "t": 262145,
      "n": "_isWeak",
      "d": 589939,
      "h": 4295557235,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180459123),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589939,
      "h": 17180459123,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180459123),
//--TRIMMABLE-BOUNDARY-START(21475426419),
    {
      "p": [
        {
          "n": "tag",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589939,
      "h": 21475426419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426419),
//--TRIMMABLE-BOUNDARY-START(25770393715),
    {
      "p": [
        {
          "n": "tag",
          "p": 852053
        },
        {
          "n": "isWeak",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589939,
      "h": 25770393715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393715)
  ],
  "h": 589939
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EntityTagHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589939)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114227)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser", ($self) => class HttpRuleParser
        {
            //--TRIMMABLE-BOUNDARY-START(73015558259)
            /*SearchValues<char>*/ static TokenChars = null;
            //--TRIMMABLE-BOUNDARY-END(73015558259)
            
            //--TRIMMABLE-BOUNDARY-START(60130656371)
            /*int*/ static MaxNestedCount = 5;
            //--TRIMMABLE-BOUNDARY-END(60130656371)
            
            //--TRIMMABLE-BOUNDARY-START(12886016115)
            /*string[]*/ static DateFormats = null;
            //--TRIMMABLE-BOUNDARY-END(12886016115)
            
            //--TRIMMABLE-BOUNDARY-START(8591048819)
            /*char*/ static CR = /*\r*/ 13;
            //--TRIMMABLE-BOUNDARY-END(8591048819)
            
            //--TRIMMABLE-BOUNDARY-START(47245754483)
            /*char*/ static LF = /*\n*/ 10;
            //--TRIMMABLE-BOUNDARY-END(47245754483)
            
            //--TRIMMABLE-BOUNDARY-START(64425623667)
            /*char*/ static SP = /* */ 32;
            //--TRIMMABLE-BOUNDARY-END(64425623667)
            
            //--TRIMMABLE-BOUNDARY-START(68720590963)
            /*char*/ static Tab = /*\t*/ 9;
            //--TRIMMABLE-BOUNDARY-END(68720590963)
            
            //--TRIMMABLE-BOUNDARY-START(55835689075)
            /*int*/ static MaxInt64Digits = 19;
            //--TRIMMABLE-BOUNDARY-END(55835689075)
            
            //--TRIMMABLE-BOUNDARY-START(51540721779)
            /*int*/ static MaxInt32Digits = 10;
            //--TRIMMABLE-BOUNDARY-END(51540721779)
            
            //--TRIMMABLE-BOUNDARY-START(17180983411)
            /*Encoding*/ static DefaultHttpEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(17180983411)
            
            //--TRIMMABLE-BOUNDARY-START(38655819891)
            static /*int */ GetTokenLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655819891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let subspan = input.AsSpan$2(startIndex);
                /*var*/ let firstNonTokenCharIdx = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, subspan, $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TokenChars);
                return (firstNonTokenCharIdx === -1) ? subspan.Length : firstNonTokenCharIdx;
            }
            //--TRIMMABLE-BOUNDARY-END(38655819891)
            
            //--TRIMMABLE-BOUNDARY-START(42950787187)
            static /*int */ GetWhitespaceLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950787187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*char*/ let c;
                while(current < input.Length)
                {
                    c = input.get_Item(current);
                    if ((c === /* */ 32) || (c === /*\t*/ 9))
                    {
                        current++;
                        continue;
                    }
                    if (c === /*\r*/ 13)
                    {
                        if ((((current + 2) | 0) < input.Length) && (input.get_Item(((current + 1) | 0)) === /*\n*/ 10))
                        {
                            /*var*/ let spaceOrTab = input.get_Item(((current + 2) | 0));
                            if ((spaceOrTab === /* */ 32) || (spaceOrTab === /*\t*/ 9))
                            {
                                current += 3;
                                continue;
                            }
                        }
                    }
                    return ((current - startIndex) | 0);
                }
                return ((input.Length - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42950787187)
            
            //--TRIMMABLE-BOUNDARY-START(25770918003)
            static /*int */ GetNumberLength(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ allowDecimal)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770918003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                ;
                /*var*/ let current = startIndex;
                /*char*/ let c;
                /*var*/ let haveDot = !allowDecimal;
                if (input.get_Item(current) === /*.*/ 46)
                {
                    return 0;
                }
                while(current < input.Length)
                {
                    c = input.get_Item(current);
                    if ((c >= /*0*/ 48) && (c <= /*9*/ 57))
                    {
                        current++;
                    }
                    else if (!haveDot && (c === /*.*/ 46))
                    {
                        haveDot = true;
                        current++;
                    }
                    else 
                    {
                        break;
                    }
                }
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(25770918003)
            
            //--TRIMMABLE-BOUNDARY-START(34360852595)
            static /*HttpParseResult */ GetQuotedStringLength(/*StringSegment*/ input, /*int*/ startIndex, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360852595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nestedCount = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetExpressionLength(input, startIndex, /*\"*/ 34, /*\"*/ 34, false, $.$ref(() => nestedCount, ($v) => nestedCount = $v, $.$$.System.Int32), length);
            }
            //--TRIMMABLE-BOUNDARY-END(34360852595)
            
            //--TRIMMABLE-BOUNDARY-START(30065885299)
            static /*HttpParseResult */ GetQuotedPairLength(/*StringSegment*/ input, /*int*/ startIndex, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                length.$v = 0;
                if (input.get_Item(startIndex) !== /*\\*/ 92)
                {
                    return 1/*HttpParseResult.NotParsed*/;
                }
                if ((((startIndex + 2) | 0) > input.Length) || (input.get_Item(((startIndex + 1) | 0)) > 127))
                {
                    return 2/*HttpParseResult.InvalidFormat*/;
                }
                length.$v = 2;
                return 0/*HttpParseResult.Parsed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065885299)
            
            //--TRIMMABLE-BOUNDARY-START(77310525555)
            static /*bool */ TryStringToDate(/*StringSegment*/ input, /*out DateTimeOffset*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310525555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let inputSpan = input.AsSpan();
                /*DateTimeFormatInfo*/ let invariant = $.$$.System.Globalization.DateTimeFormatInfo.InvariantInfo;
                return $.$$.System.DateTimeOffset.TryParseExact(inputSpan, $.$$.System.String.op_Implicit("r"), invariant, 0/*DateTimeStyles.None*/, result) || $.$$.System.DateTimeOffset.TryParseExact$1(inputSpan, $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.DateFormats, invariant, 7/*DateTimeStyles.AllowWhiteSpaces*/ | 64/*DateTimeStyles.AssumeUniversal*/, result);
            }
            //--TRIMMABLE-BOUNDARY-END(77310525555)
            
            //--TRIMMABLE-BOUNDARY-START(21475950707)
            static /*HttpParseResult */ GetExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*char*/ openChar, /*char*/ closeChar, /*bool*/ supportsNesting, /*ref int*/ nestedCount, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                ;
                length.$v = 0;
                if (input.get_Item(startIndex) !== openChar)
                {
                    return 1/*HttpParseResult.NotParsed*/;
                }
                /*var*/ let current = ((startIndex + 1) | 0);
                while(current < input.Length)
                {
                    /*var*/ let quotedPairLength;
                    if ((((current + 2) | 0) < input.Length) && ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetQuotedPairLength(input, current, $.$ref(() => quotedPairLength, ($v) => quotedPairLength = $v, $.$$.System.Int32)) === 0/*HttpParseResult.Parsed*/))
                    {
                        current = ((current + quotedPairLength) | 0);
                        continue;
                    }
                    if (supportsNesting && (input.get_Item(current) === openChar))
                    {
                        nestedCount.$v++;
                        try
                        {
                            if (nestedCount.$v > 5/*MaxNestedCount*/)
                            {
                                return 2/*HttpParseResult.InvalidFormat*/;
                            }
                            /*var*/ let nestedLength = 0;
                            /*var*/ let nestedResult = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetExpressionLength(input, current, openChar, closeChar, supportsNesting, nestedCount, $.$ref(() => nestedLength, ($v) => nestedLength = $v, $.$$.System.Int32));
                            switch(nestedResult)
                            {
                                case 0/*HttpParseResult.Parsed*/:
                                current += nestedLength;
                                break;
                                case 1/*HttpParseResult.NotParsed*/:
                                $.$$.System.Diagnostics.Contracts.Contract.Assert(false, "'NotParsed' is unexpected: We started nested expression " + "parsing, because we found the open-char. So either it's a valid nested " + "expression or it has invalid format.");
                                break;
                                case 2/*HttpParseResult.InvalidFormat*/:
                                return 2/*HttpParseResult.InvalidFormat*/;
                                default:
                                $.$$.System.Diagnostics.Contracts.Contract.Assert(false, "Unknown enum result: " + $.$$.System.Enum.ToString.call(nestedResult));
                                break;
                            }
                        }
                        finally
                        {
                            {
                                nestedCount.$v--;
                            }
                        }
                    }
                    if (input.get_Item(current) === closeChar)
                    {
                        length.$v = ((((current - startIndex) | 0) + 1) | 0);
                        return 0/*HttpParseResult.Parsed*/;
                    }
                    current++;
                }
                return 2/*HttpParseResult.InvalidFormat*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21475950707)
            
            //--TRIMMABLE-BOUNDARY-START(4296081523)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(73015558259)
                    this.TokenChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!#$%&'*+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"));
                    //--TRIMMABLE-BOUNDARY-END(73015558259)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886016115)
                    this.DateFormats = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), ["ddd, d MMM yyyy H:m:s 'GMT'", "ddd, d MMM yyyy H:m:s", "d MMM yyyy H:m:s 'GMT'", "d MMM yyyy H:m:s", "ddd, d MMM yy H:m:s 'GMT'", "ddd, d MMM yy H:m:s", "d MMM yy H:m:s 'GMT'", "d MMM yy H:m:s", "dddd, d'-'MMM'-'yy H:m:s 'GMT'", "dddd, d'-'MMM'-'yy H:m:s", "ddd, d'-'MMM'-'yyyy H:m:s 'GMT'", "ddd MMM d H:m:s yyyy", "ddd, d MMM yyyy H:m:s zzz", "ddd, d MMM yyyy H:m:s", "d MMM yyyy H:m:s zzz", "d MMM yyyy H:m:s"], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12886016115)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180983411)
                    this.DefaultHttpEncoding = $.$$.System.Text.Encoding.GetEncoding$3("iso-8859-1");
                    //--TRIMMABLE-BOUNDARY-END(17180983411)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296081523)
            
            static $h = 1114227;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655819891),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "GetTokenLength",
      "d": 1114227,
      "h": 38655819891,
      "f": 16777256,
      "a": [
        {
          "t": 69599233,
          "c": 4364566529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655819891),
//--TRIMMABLE-BOUNDARY-START(42950787187),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "GetWhitespaceLength",
      "d": 1114227,
      "h": 42950787187,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950787187),
//--TRIMMABLE-BOUNDARY-START(25770918003),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "allowDecimal",
          "p": 262145
        }
      ],
      "n": "GetNumberLength",
      "d": 1114227,
      "h": 25770918003,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770918003),
//--TRIMMABLE-BOUNDARY-START(34360852595),
    {
      "r": 1048691,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetQuotedStringLength",
      "d": 1114227,
      "h": 34360852595,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360852595),
//--TRIMMABLE-BOUNDARY-START(30065885299),
    {
      "r": 1048691,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetQuotedPairLength",
      "d": 1114227,
      "h": 30065885299,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065885299),
//--TRIMMABLE-BOUNDARY-START(77310525555),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "result",
          "p": 65339393,
          "f": 2
        }
      ],
      "n": "TryStringToDate",
      "d": 1114227,
      "h": 77310525555,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77310525555),
//--TRIMMABLE-BOUNDARY-START(21475950707),
    {
      "r": 1048691,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "openChar",
          "p": 458753
        },
        {
          "n": "closeChar",
          "p": 458753
        },
        {
          "n": "supportsNesting",
          "p": 262145
        },
        {
          "n": "nestedCount",
          "p": 655361,
          "f": 4
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetExpressionLength",
      "d": 1114227,
      "h": 21475950707,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475950707)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015558259),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "TokenChars",
      "d": 1114227,
      "h": 73015558259,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015558259),
//--TRIMMABLE-BOUNDARY-START(60130656371),
    {
      "t": 655361,
      "n": "MaxNestedCount",
      "d": 1114227,
      "h": 60130656371,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60130656371),
//--TRIMMABLE-BOUNDARY-START(12886016115),
    {
      "t": $.$typeArray($.$$.System.String).$h,
      "n": "DateFormats",
      "d": 1114227,
      "h": 12886016115,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886016115),
//--TRIMMABLE-BOUNDARY-START(8591048819),
    {
      "t": 458753,
      "n": "CR",
      "d": 1114227,
      "h": 8591048819,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8591048819),
//--TRIMMABLE-BOUNDARY-START(47245754483),
    {
      "t": 458753,
      "n": "LF",
      "d": 1114227,
      "h": 47245754483,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245754483),
//--TRIMMABLE-BOUNDARY-START(64425623667),
    {
      "t": 458753,
      "n": "SP",
      "d": 1114227,
      "h": 64425623667,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425623667),
//--TRIMMABLE-BOUNDARY-START(68720590963),
    {
      "t": 458753,
      "n": "Tab",
      "d": 1114227,
      "h": 68720590963,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720590963),
//--TRIMMABLE-BOUNDARY-START(55835689075),
    {
      "t": 655361,
      "n": "MaxInt64Digits",
      "d": 1114227,
      "h": 55835689075,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835689075),
//--TRIMMABLE-BOUNDARY-START(51540721779),
    {
      "t": 655361,
      "n": "MaxInt32Digits",
      "d": 1114227,
      "h": 51540721779,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540721779),
//--TRIMMABLE-BOUNDARY-START(17180983411),
    {
      "t": 165806081,
      "n": "DefaultHttpEncoding",
      "d": 1114227,
      "h": 17180983411,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180983411)
  ],
  "h": 1114227
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HttpRuleParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114227)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572979)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue", ($self) => class RangeItemHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296540275)
            /*long?*/ _from = null;
            //--TRIMMABLE-BOUNDARY-END(4296540275)
            
            //--TRIMMABLE-BOUNDARY-START(8591507571)
            /*long?*/ _to = null;
            //--TRIMMABLE-BOUNDARY-END(8591507571)
            
            //--TRIMMABLE-BOUNDARY-START(12886474867)
            $ctor$1(/*long?*/ $from, /*long?*/ to)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886474867);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call($from) && !$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(to))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14("Invalid header range.");
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call($from) && ($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call($from) < 0n))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(to) && ($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(to) < 0n))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("to");
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call($from) && $.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(to) && ($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call($from) > $.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(to)))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this._from = $from;
                    this._to = to;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886474867)
            
            //--TRIMMABLE-BOUNDARY-START(21476409459)
            /*long? */ get From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066344051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._from;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409459)
            
            //--TRIMMABLE-BOUNDARY-START(55836147827)
            /*long? */ get To()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656278643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._to;
            }
            //--TRIMMABLE-BOUNDARY-END(55836147827)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60131115123, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131115123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._from))
                {
                    return "-" + $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._to), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                }
                else if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._to))
                {
                    return $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._from), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo) + "-";
                }
                return $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._from), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo) + "-" + $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._to), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60131115123, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181442163, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue, { set $v(v){ other = v; } }) && ((this._from === other._from) && (this._to === other._to));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181442163, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42951245939, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._from))
                {
                    return $.$$.System.Int64.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._to));
                }
                else if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._to))
                {
                    return $.$$.System.Int64.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._from));
                }
                return $.$$.System.Int64.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._from)) ^ $.$$.System.Int64.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._to));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42951245939, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(51541180531)
            static /*int */ GetRangeItemListLength(/*StringSegment*/ input, /*int*/ startIndex, /*ICollection<RangeItemHeaderValue>*/ rangeCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541180531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                ;
                if (($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input)) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(input, startIndex, true, $.$discardRef());
                if (current === input.Length)
                {
                    return 0;
                }
                while(true)
                {
                    /*var*/ let range;
                    /*var*/ let rangeLength = $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.GetRangeItemLength(input, current, $.$ref(() => range, ($v) => range = $v, $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue));
                    if (rangeLength === 0)
                    {
                        return 0;
                    }
                    rangeCollection.System$Collections$Generic$ICollection$$$Add(range, [$.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue]);
                    current = ((current + rangeLength) | 0);
                    /*var*/ let separatorFound;
                    current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(input, current, true, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                    if ((current < input.Length) && !separatorFound)
                    {
                        return 0;
                    }
                    if (current === input.Length)
                    {
                        return ((current - startIndex) | 0);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541180531)
            
            //--TRIMMABLE-BOUNDARY-START(47246213235)
            static /*int */ GetRangeItemLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeItemHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*var*/ let fromStartIndex = current;
                /*var*/ let fromLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current, false);
                if (fromLength > 19/*HttpRuleParser.MaxInt64Digits*/)
                {
                    return 0;
                }
                current = ((current + fromLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*-*/ 45))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let toStartIndex = current;
                /*var*/ let toLength = 0;
                if (current < input.Length)
                {
                    toLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current, false);
                    if (toLength > 19/*HttpRuleParser.MaxInt64Digits*/)
                    {
                        return 0;
                    }
                    current = ((current + toLength) | 0);
                    current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                }
                if ((fromLength === 0) && (toLength === 0))
                {
                    return 0;
                }
                /*long*/ let $from = 0n;
                if ((fromLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(fromStartIndex, fromLength), $.$ref(() => $from, ($v) => $from = $v, $.$$.System.Int64)))
                {
                    return 0;
                }
                /*long*/ let to = 0n;
                if ((toLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(toStartIndex, toLength), $.$ref(() => to, ($v) => to = $v, $.$$.System.Int64)))
                {
                    return 0;
                }
                if ((fromLength > 0) && (toLength > 0) && ($from > to))
                {
                    return 0;
                }
                parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue().$ctor$1((fromLength === 0 ? null : $.$cast($from, $.$$.System.Nullable$$($.$$.System.Int64))), (toLength === 0 ? null : $.$cast(to, $.$$.System.Nullable$$($.$$.System.Int64))));
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(47246213235)
            
            static $h = 1572979;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476409459),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066344051,
        "f": 50331649
      },
      "n": "From",
      "d": 1572979,
      "h": 21476409459,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476409459),
//--TRIMMABLE-BOUNDARY-START(55836147827),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656278643,
        "f": 50331649
      },
      "n": "To",
      "d": 1572979,
      "h": 55836147827,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836147827)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 60131115123, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1572979,
      "h": 60131115123,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60131115123, 330712612865),
//--TRIMMABLE-BOUNDARY-START(ALL, 17181442163, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1572979,
      "h": 17181442163,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181442163, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 42951245939, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1572979,
      "h": 42951245939,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42951245939, 184683724801),
//--TRIMMABLE-BOUNDARY-START(51541180531),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "rangeCollection",
          "p": $.$$.System.Collections.Generic.ICollection$$($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue).$h
        }
      ],
      "n": "GetRangeItemListLength",
      "d": 1572979,
      "h": 51541180531,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51541180531),
//--TRIMMABLE-BOUNDARY-START(47246213235),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1572979,
          "f": 2
        }
      ],
      "n": "GetRangeItemLength",
      "d": 1572979,
      "h": 47246213235,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246213235)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296540275),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_from",
      "d": 1572979,
      "h": 4296540275,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540275),
//--TRIMMABLE-BOUNDARY-START(8591507571),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_to",
      "d": 1572979,
      "h": 8591507571,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507571)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886474867),
    {
      "p": [
        {
          "n": "from",
          "p": $.$typeNullable($.$$.System.Int64).$h
        },
        {
          "n": "to",
          "p": $.$typeNullable($.$$.System.Int64).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572979,
      "h": 12886474867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886474867)
  ],
  "h": 1572979
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RangeItemHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572979)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441907)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue", ($self) => class RangeConditionHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77310853235)
            /*HttpHeaderParser<RangeConditionHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(77310853235)
            
            //--TRIMMABLE-BOUNDARY-START(8591376499)
            /*DateTimeOffset?*/ _lastModified = null;
            //--TRIMMABLE-BOUNDARY-END(8591376499)
            
            //--TRIMMABLE-BOUNDARY-START(4296409203)
            /*EntityTagHeaderValue?*/ _entityTag = null;
            //--TRIMMABLE-BOUNDARY-END(4296409203)
            
            //--TRIMMABLE-BOUNDARY-START(17181311091)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181311091);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311091)
            
            //--TRIMMABLE-BOUNDARY-START(21476278387)
            $ctor$2(/*DateTimeOffset*/ lastModified)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476278387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._lastModified = lastModified;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278387)
            
            //--TRIMMABLE-BOUNDARY-START(25771245683)
            $ctor$4(/*EntityTagHeaderValue*/ entityTag)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771245683);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(entityTag, "entityTag");
                    this._entityTag = entityTag;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245683)
            
            //--TRIMMABLE-BOUNDARY-START(30066212979)
            $ctor$3(/*string?*/ entityTag)
            {
                this.$ctor$4(new $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue().$ctor$3($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(entityTag)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066212979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212979)
            
            //--TRIMMABLE-BOUNDARY-START(68720918643)
            /*DateTimeOffset? */ get LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._lastModified;
            }
            //--TRIMMABLE-BOUNDARY-END(68720918643)
            
            //--TRIMMABLE-BOUNDARY-START(34361180275)
            /*EntityTagHeaderValue? */ get EntityTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._entityTag;
            }
            //--TRIMMABLE-BOUNDARY-END(34361180275)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81605820531, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._entityTag === null)
                {
                    return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatDate$1($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(this._lastModified));
                }
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.ToString.call(this._entityTag);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 81605820531, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38656147571, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (this._entityTag === null)
                {
                    return (other._lastModified !== null) && ($.$$.System.DateTimeOffset.op_Equality($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(this._lastModified), $.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(other._lastModified)));
                }
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.Equals$1.call(this._entityTag, other._entityTag);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38656147571, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60130984051, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130984051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._entityTag === null)
                {
                    return $.$$.System.DateTimeOffset.GetHashCode.call($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(this._lastModified));
                }
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetHashCode.call(this._entityTag);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60130984051, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(73015885939)
            static /*RangeConditionHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(73015885939)
            
            //--TRIMMABLE-BOUNDARY-START(85900787827)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out RangeConditionHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(85900787827)
            
            //--TRIMMABLE-BOUNDARY-START(64425951347)
            static /*int */ GetRangeConditionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeConditionHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (((startIndex + 1) | 0) >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*DateTimeOffset*/ let date = $.$$.System.DateTimeOffset.MinValue;
                /*EntityTagHeaderValue?*/ let entityTag = null;
                /*var*/ let firstChar = input.get_Item(current);
                /*var*/ let secondChar = input.get_Item(((current + 1) | 0));
                if ((firstChar === /*\"*/ 34) || (((firstChar === /*w*/ 119) || (firstChar === /*W*/ 87)) && (secondChar === /*/*/ 47)))
                {
                    /*var*/ let entityTagLength = $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetEntityTagLength(input, current, $.$ref(() => entityTag, ($v) => entityTag = $v, $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue));
                    if (entityTagLength === 0)
                    {
                        return 0;
                    }
                    current = ((current + entityTagLength) | 0);
                    if (current !== input.Length)
                    {
                        return 0;
                    }
                }
                else 
                {
                    if (!$.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TryStringToDate(input.Subsegment$1(current), $.$ref(() => date, ($v) => date = $v, $.$$.System.DateTimeOffset)))
                    {
                        return 0;
                    }
                    current = input.Length;
                }
                parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue().$ctor$1();
                if (entityTag === null)
                {
                    parsedValue.$v._lastModified = date;
                }
                else 
                {
                    parsedValue.$v._entityTag = entityTag;
                }
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(64425951347)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591376499)
                this._lastModified = null;
                //--TRIMMABLE-BOUNDARY-END(8591376499)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886343795)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(77310853235)
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.GetRangeConditionLength));
                    //--TRIMMABLE-BOUNDARY-END(77310853235)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886343795)
            
            static $h = 1441907;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720918643),
    {
      "p": $.$typeNullable($.$$.System.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836016755,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 1441907,
      "h": 68720918643,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720918643),
//--TRIMMABLE-BOUNDARY-START(34361180275),
    {
      "p": 589939,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246082163,
        "f": 50331649
      },
      "n": "EntityTag",
      "d": 1441907,
      "h": 34361180275,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361180275)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 81605820531, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1441907,
      "h": 81605820531,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81605820531, 330712612865),
//--TRIMMABLE-BOUNDARY-START(ALL, 38656147571, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1441907,
      "h": 38656147571,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38656147571, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 60130984051, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1441907,
      "h": 60130984051,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60130984051, 184683724801),
//--TRIMMABLE-BOUNDARY-START(73015885939),
    {
      "r": 1441907,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1441907,
      "h": 73015885939,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015885939),
//--TRIMMABLE-BOUNDARY-START(85900787827),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1441907,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1441907,
      "h": 85900787827,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85900787827),
//--TRIMMABLE-BOUNDARY-START(64425951347),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1441907,
          "f": 2
        }
      ],
      "n": "GetRangeConditionLength",
      "d": 1441907,
      "h": 64425951347,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425951347)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77310853235),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue).$h,
      "n": "Parser",
      "d": 1441907,
      "h": 77310853235,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310853235),
//--TRIMMABLE-BOUNDARY-START(8591376499),
    {
      "t": $.$typeNullable($.$$.System.DateTimeOffset).$h,
      "n": "_lastModified",
      "d": 1441907,
      "h": 8591376499,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591376499),
//--TRIMMABLE-BOUNDARY-START(4296409203),
    {
      "t": 589939,
      "n": "_entityTag",
      "d": 1441907,
      "h": 4296409203,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181311091),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441907,
      "h": 17181311091,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181311091),
//--TRIMMABLE-BOUNDARY-START(21476278387),
    {
      "p": [
        {
          "n": "lastModified",
          "p": 65339393
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441907,
      "h": 21476278387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476278387),
//--TRIMMABLE-BOUNDARY-START(25771245683),
    {
      "p": [
        {
          "n": "entityTag",
          "p": 589939
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1441907,
      "h": 25771245683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771245683),
//--TRIMMABLE-BOUNDARY-START(30066212979),
    {
      "p": [
        {
          "n": "entityTag",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441907,
      "h": 30066212979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066212979)
  ],
  "h": 1441907
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RangeConditionHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441907)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769587)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue", ($self) => class StringWithQualityHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81606148211)
            /*HttpHeaderParser<StringWithQualityHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(81606148211)
            
            //--TRIMMABLE-BOUNDARY-START(60131311731)
            /*HttpHeaderParser<StringWithQualityHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(60131311731)
            
            //--TRIMMABLE-BOUNDARY-START(8591704179)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(8591704179)
            
            //--TRIMMABLE-BOUNDARY-START(4296736883)
            /*double?*/ _quality = null;
            //--TRIMMABLE-BOUNDARY-END(4296736883)
            
            //--TRIMMABLE-BOUNDARY-START(17181638771)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181638771);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181638771)
            
            //--TRIMMABLE-BOUNDARY-START(21476606067)
            $ctor$3(/*StringSegment*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476606067);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(value, "value");
                    this._value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476606067)
            
            //--TRIMMABLE-BOUNDARY-START(25771573363)
            $ctor$2(/*StringSegment*/ value, /*double*/ quality)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771573363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(value, "value");
                    if ((quality < 0) || (quality > 1))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("quality");
                    }
                    this._value = value;
                    this._quality = quality;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771573363)
            
            //--TRIMMABLE-BOUNDARY-START(107375951987)
            /*StringSegment */ get Value()
            {
                return this._value;
            }
            //--TRIMMABLE-BOUNDARY-END(107375951987)
            
            //--TRIMMABLE-BOUNDARY-START(77311180915)
            /*double? */ get Quality()
            {
                return this._quality;
            }
            //--TRIMMABLE-BOUNDARY-END(77311180915)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 85901115507, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901115507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(this._quality))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._value) + "; q=" + $.$$.System.Double.ToString$2.call($.$$.System.Nullable$$($.$$.System.Double).GetValueOrDefault.call(this._quality), "0.0##", $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._value);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 85901115507, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30066540659, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066540659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(this._quality))
                {
                    return $.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(other._quality) && ($.$$.System.Nullable$$($.$$.System.Double).GetValueOrDefault.call(this._quality) === $.$$.System.Nullable$$($.$$.System.Double).Value$get.call(other._quality));
                }
                return !$.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(other._quality);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30066540659, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51541377139, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541377139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value);
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(this._quality))
                {
                    result = result ^ $.$$.System.Double.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Double).GetValueOrDefault.call(this._quality));
                }
                return result;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51541377139, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(64426279027)
            static /*StringWithQualityHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426279027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(64426279027)
            
            //--TRIMMABLE-BOUNDARY-START(90196082803)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out StringWithQualityHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196082803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(90196082803)
            
            //--TRIMMABLE-BOUNDARY-START(68721246323)
            static /*IList<StringWithQualityHeaderValue> */ ParseList(/*IList<string>?*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721246323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.MultipleValueParser.ParseValues$1(input);
            }
            //--TRIMMABLE-BOUNDARY-END(68721246323)
            
            //--TRIMMABLE-BOUNDARY-START(73016213619)
            static /*IList<StringWithQualityHeaderValue> */ ParseStrictList(/*IList<string>?*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016213619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.MultipleValueParser.ParseStrictValues(input);
            }
            //--TRIMMABLE-BOUNDARY-END(73016213619)
            
            //--TRIMMABLE-BOUNDARY-START(94491050099)
            static /*bool */ TryParseList(/*IList<string>?*/ input, /*out IList<StringWithQualityHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491050099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.MultipleValueParser.TryParseValues$1(input, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(94491050099)
            
            //--TRIMMABLE-BOUNDARY-START(98786017395)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ input, /*out IList<StringWithQualityHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786017395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.MultipleValueParser.TryParseStrictValues(input, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(98786017395)
            
            //--TRIMMABLE-BOUNDARY-START(55836344435)
            static /*int */ GetStringWithQualityLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringWithQualityHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836344435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let valueLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (valueLength === 0)
                {
                    return 0;
                }
                /*StringWithQualityHeaderValue*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue().$ctor$1();
                result._value = input.Subsegment(startIndex, valueLength);
                /*var*/ let current = ((startIndex + valueLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*;*/ 59))
                {
                    parsedValue.$v = result;
                    return ((current - startIndex) | 0);
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (!$.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.TryReadQuality(input, result, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32)))
                {
                    return 0;
                }
                parsedValue.$v = result;
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(55836344435)
            
            //--TRIMMABLE-BOUNDARY-START(103080984691)
            static /*bool */ TryReadQuality(/*StringSegment*/ input, /*StringWithQualityHeaderValue*/ result, /*ref int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080984691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let current = index.$v;
                if ((current === input.Length) || ((input.get_Item(current) !== /*q*/ 113) && (input.get_Item(current) !== /*Q*/ 81)))
                {
                    return false;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*=*/ 61))
                {
                    return false;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (current === input.Length)
                {
                    return false;
                }
                /*var*/ let quality;
                /*var*/ let qualityLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseQualityDouble(input, current, $.$ref(() => quality, ($v) => quality = $v, $.$$.System.Double), $.$ref(() => qualityLength, ($v) => qualityLength = $v, $.$$.System.Int32)))
                {
                    return false;
                }
                result._quality = quality;
                current = ((current + qualityLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                index.$v = current;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(103080984691)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591704179)
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591704179)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886671475)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(81606148211)
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.GetStringWithQualityLength));
                    //--TRIMMABLE-BOUNDARY-END(81606148211)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60131311731)
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.GetStringWithQualityLength));
                    //--TRIMMABLE-BOUNDARY-END(60131311731)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886671475)
            
            static $h = 1769587;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375951987),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246409843,
        "f": 50331649
      },
      "n": "Value",
      "d": 1769587,
      "h": 107375951987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375951987),
//--TRIMMABLE-BOUNDARY-START(77311180915),
    {
      "p": $.$typeNullable($.$$.System.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656475251,
        "f": 50331649
      },
      "n": "Quality",
      "d": 1769587,
      "h": 77311180915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311180915)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 85901115507, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1769587,
      "h": 85901115507,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 85901115507, 330712612865),
//--TRIMMABLE-BOUNDARY-START(ALL, 30066540659, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1769587,
      "h": 30066540659,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066540659, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 51541377139, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1769587,
      "h": 51541377139,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51541377139, 184683724801),
//--TRIMMABLE-BOUNDARY-START(64426279027),
    {
      "r": 1769587,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1769587,
      "h": 64426279027,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426279027),
//--TRIMMABLE-BOUNDARY-START(90196082803),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1769587,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1769587,
      "h": 90196082803,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90196082803),
//--TRIMMABLE-BOUNDARY-START(68721246323),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseList",
      "d": 1769587,
      "h": 68721246323,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68721246323),
//--TRIMMABLE-BOUNDARY-START(73016213619),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 1769587,
      "h": 73016213619,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016213619),
//--TRIMMABLE-BOUNDARY-START(94491050099),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 1769587,
      "h": 94491050099,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94491050099),
//--TRIMMABLE-BOUNDARY-START(98786017395),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 1769587,
      "h": 98786017395,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98786017395),
//--TRIMMABLE-BOUNDARY-START(55836344435),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1769587,
          "f": 2
        }
      ],
      "n": "GetStringWithQualityLength",
      "d": 1769587,
      "h": 55836344435,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55836344435),
//--TRIMMABLE-BOUNDARY-START(103080984691),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "result",
          "p": 1769587
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "TryReadQuality",
      "d": 1769587,
      "h": 103080984691,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103080984691)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81606148211),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 1769587,
      "h": 81606148211,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81606148211),
//--TRIMMABLE-BOUNDARY-START(60131311731),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 1769587,
      "h": 60131311731,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131311731),
//--TRIMMABLE-BOUNDARY-START(8591704179),
    {
      "t": 852053,
      "n": "_value",
      "d": 1769587,
      "h": 8591704179,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704179),
//--TRIMMABLE-BOUNDARY-START(4296736883),
    {
      "t": $.$typeNullable($.$$.System.Double).$h,
      "n": "_quality",
      "d": 1769587,
      "h": 4296736883,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181638771),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769587,
      "h": 17181638771,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181638771),
//--TRIMMABLE-BOUNDARY-START(21476606067),
    {
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769587,
      "h": 21476606067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476606067),
//--TRIMMABLE-BOUNDARY-START(25771573363),
    {
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "quality",
          "p": 1179649
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769587,
      "h": 25771573363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771573363)
  ],
  "h": 1769587
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `StringWithQualityHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769587)
        
        
        //--TRIMMABLE-BOUNDARY-START(327795)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue", ($self) => class ContentRangeHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(128849346675)
            /*HttpHeaderParser<ContentRangeHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(128849346675)
            
            //--TRIMMABLE-BOUNDARY-START(4295295091)
            /*StringSegment*/ _unit;
            //--TRIMMABLE-BOUNDARY-END(4295295091)
            
            //--TRIMMABLE-BOUNDARY-START(12885229683)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229683);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229683)
            
            //--TRIMMABLE-BOUNDARY-START(17180196979)
            $ctor$2(/*long*/ $from, /*long*/ to, /*long*/ length)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, length, "length");
                    if ((to < 0n) || (length <= to))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("to");
                    }
                    if (($from < 0n) || ($from > to))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this.From = $from;
                    this.To = to;
                    this.Length = length;
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196979)
            
            //--TRIMMABLE-BOUNDARY-START(21475164275)
            $ctor$4(/*long*/ length)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475164275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, length, "length");
                    this.Length = length;
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164275)
            
            //--TRIMMABLE-BOUNDARY-START(25770131571)
            $ctor$3(/*long*/ $from, /*long*/ to)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131571);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, to, "to");
                    if (($from < 0n) || ($from > to))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this.From = $from;
                    this.To = to;
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131571)
            
            //--TRIMMABLE-BOUNDARY-START(193273856115)
            /*StringSegment */ get Unit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._unit;
            }
            /*StringSegment */ set Unit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209085043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(value, "value");
                this._unit = value;
            }
            //--TRIMMABLE-BOUNDARY-END(193273856115)
            
            //--TRIMMABLE-BOUNDARY-START(47244968051)
            /*long?*/ From = null;
            //--TRIMMABLE-BOUNDARY-END(47244968051)
            
            //--TRIMMABLE-BOUNDARY-START(167504052339)
            /*long?*/ To = null;
            //--TRIMMABLE-BOUNDARY-END(167504052339)
            
            //--TRIMMABLE-BOUNDARY-START(120259412083)
            /*long?*/ Length = null;
            //--TRIMMABLE-BOUNDARY-END(120259412083)
            
            //--TRIMMABLE-BOUNDARY-START(111669477491)
            /*bool */ get HasLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(111669477491)
            
            //--TRIMMABLE-BOUNDARY-START(115964444787)
            /*bool */ get HasRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.From !== null && this.To !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(115964444787)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42950000755, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return ((this.From === other.From) && (this.To === other.To) && (this.Length === other.Length) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Unit, other.Unit, 5/*StringComparison.OrdinalIgnoreCase*/));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42950000755, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 107374510195, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Unit);
                if (this.HasRange)
                {
                    result = result ^ $.$$.System.Nullable$$($.$$.System.Int64).GetHashCode.call(this.From) ^ $.$$.System.Nullable$$($.$$.System.Int64).GetHashCode.call(this.To);
                }
                if (this.HasLength)
                {
                    result = result ^ $.$$.System.Nullable$$($.$$.System.Int64).GetHashCode.call(this.Length);
                }
                return result;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 107374510195, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 171799019635, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                sb.Append$15(this.Unit.AsSpan());
                sb.Append$3(/* */ 32);
                if (this.HasRange)
                {
                    sb.Append$19($.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this.From), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                    sb.Append$3(/*-*/ 45);
                    sb.Append$19($.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this.To), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                else 
                {
                    sb.Append$3(/***/ 42);
                }
                sb.Append$3(/*/*/ 47);
                if (this.HasLength)
                {
                    sb.Append$19($.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this.Length), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                else 
                {
                    sb.Append$3(/***/ 42);
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 171799019635, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(124554379379)
            static /*ContentRangeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(124554379379)
            
            //--TRIMMABLE-BOUNDARY-START(188978888819)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978888819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(188978888819)
            
            //--TRIMMABLE-BOUNDARY-START(103079542899)
            static /*int */ GetContentRangeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let unitLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (unitLength === 0)
                {
                    return 0;
                }
                /*var*/ let unit = input.Subsegment(startIndex, unitLength);
                /*var*/ let current = ((startIndex + unitLength) | 0);
                /*var*/ let separatorLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current);
                if (separatorLength === 0)
                {
                    return 0;
                }
                current = ((current + separatorLength) | 0);
                if (current === input.Length)
                {
                    return 0;
                }
                /*var*/ let fromStartIndex = current;
                /*var*/ let fromLength;
                /*var*/ let toStartIndex;
                /*var*/ let toLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.TryGetRangeLength(input, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => fromLength, ($v) => fromLength = $v, $.$$.System.Int32), $.$ref(() => toStartIndex, ($v) => toStartIndex = $v, $.$$.System.Int32), $.$ref(() => toLength, ($v) => toLength = $v, $.$$.System.Int32)))
                {
                    return 0;
                }
                if ((current === input.Length) || (input.get_Item(current) !== /*/*/ 47))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (current === input.Length)
                {
                    return 0;
                }
                /*var*/ let lengthStartIndex = current;
                /*var*/ let lengthLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.TryGetLengthLength(input, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.System.Int32)))
                {
                    return 0;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.TryCreateContentRange(input, unit, fromStartIndex, fromLength, toStartIndex, toLength, lengthStartIndex, lengthLength, parsedValue))
                {
                    return 0;
                }
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(103079542899)
            
            //--TRIMMABLE-BOUNDARY-START(180388954227)
            static /*bool */ TryGetLengthLength(/*StringSegment*/ input, /*ref int*/ current, /*out int*/ lengthLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388954227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                lengthLength.$v = 0;
                if (input.get_Item(current.$v) === /***/ 42)
                {
                    current.$v++;
                }
                else 
                {
                    lengthLength.$v = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((lengthLength.$v === 0) || (lengthLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + lengthLength.$v) | 0);
                }
                current.$v = ((current.$v + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(180388954227)
            
            //--TRIMMABLE-BOUNDARY-START(184683921523)
            static /*bool */ TryGetRangeLength(/*StringSegment*/ input, /*ref int*/ current, /*out int*/ fromLength, /*out int*/ toStartIndex, /*out int*/ toLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683921523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                fromLength.$v = 0;
                toStartIndex.$v = 0;
                toLength.$v = 0;
                if (input.get_Item(current.$v) === /***/ 42)
                {
                    current.$v++;
                }
                else 
                {
                    fromLength.$v = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((fromLength.$v === 0) || (fromLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + fromLength.$v) | 0);
                    current.$v = ((current.$v + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                    if ((current.$v === input.Length) || (input.get_Item(current.$v) !== /*-*/ 45))
                    {
                        return false;
                    }
                    current.$v++;
                    current.$v = ((current.$v + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                    if (current.$v === input.Length)
                    {
                        return false;
                    }
                    toStartIndex.$v = current.$v;
                    toLength.$v = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((toLength.$v === 0) || (toLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + toLength.$v) | 0);
                }
                current.$v = ((current.$v + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(184683921523)
            
            //--TRIMMABLE-BOUNDARY-START(176093986931)
            static /*bool */ TryCreateContentRange(/*StringSegment*/ input, /*StringSegment*/ unit, /*int*/ fromStartIndex, /*int*/ fromLength, /*int*/ toStartIndex, /*int*/ toLength, /*int*/ lengthStartIndex, /*int*/ lengthLength, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093986931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parsedValue.$v = null;
                /*long*/ let $from = 0n;
                if ((fromLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(fromStartIndex, fromLength), $.$ref(() => $from, ($v) => $from = $v, $.$$.System.Int64)))
                {
                    return false;
                }
                /*long*/ let to = 0n;
                if ((toLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(toStartIndex, toLength), $.$ref(() => to, ($v) => to = $v, $.$$.System.Int64)))
                {
                    return false;
                }
                if ((fromLength > 0) && (toLength > 0) && ($from > to))
                {
                    return false;
                }
                /*long*/ let length = 0n;
                if ((lengthLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(lengthStartIndex, lengthLength), $.$ref(() => length, ($v) => length = $v, $.$$.System.Int64)))
                {
                    return false;
                }
                if ((toLength > 0) && (lengthLength > 0) && (to >= length))
                {
                    return false;
                }
                /*var*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue().$ctor$1();
                result._unit = unit;
                if (fromLength > 0)
                {
                    result.From = $from;
                    result.To = to;
                }
                if (lengthLength > 0)
                {
                    result.Length = length;
                }
                parsedValue.$v = result;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(176093986931)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295295091)
                this._unit = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(4295295091)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8590262387)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(128849346675)
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.GetContentRangeLength));
                    //--TRIMMABLE-BOUNDARY-END(128849346675)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590262387)
            
            static $h = 327795;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(193273856115),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784575603,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209085043,
        "f": 83886081
      },
      "n": "Unit",
      "d": 327795,
      "h": 193273856115,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193273856115),
//--TRIMMABLE-BOUNDARY-START(47244968051),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902643,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439281267,
        "f": 83886082
      },
      "n": "From",
      "d": 327795,
      "h": 47244968051,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244968051),
//--TRIMMABLE-BOUNDARY-START(167504052339),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194641011,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619150451,
        "f": 83886082
      },
      "n": "To",
      "d": 327795,
      "h": 167504052339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504052339),
//--TRIMMABLE-BOUNDARY-START(120259412083),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604706419,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029215859,
        "f": 83886082
      },
      "n": "Length",
      "d": 327795,
      "h": 120259412083,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259412083),
//--TRIMMABLE-BOUNDARY-START(111669477491),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837235,
        "f": 50331649
      },
      "n": "HasLength",
      "d": 327795,
      "h": 111669477491,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669477491),
//--TRIMMABLE-BOUNDARY-START(115964444787),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014771827,
        "f": 50331649
      },
      "n": "HasRange",
      "d": 327795,
      "h": 115964444787,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964444787)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 42950000755, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 327795,
      "h": 42950000755,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42950000755, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 107374510195, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 327795,
      "h": 107374510195,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 107374510195, 184683724801),
//--TRIMMABLE-BOUNDARY-START(ALL, 171799019635, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 327795,
      "h": 171799019635,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 171799019635, 330712612865),
//--TRIMMABLE-BOUNDARY-START(124554379379),
    {
      "r": 327795,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 327795,
      "h": 124554379379,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124554379379),
//--TRIMMABLE-BOUNDARY-START(188978888819),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 327795,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 327795,
      "h": 188978888819,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188978888819),
//--TRIMMABLE-BOUNDARY-START(103079542899),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 327795,
          "f": 2
        }
      ],
      "n": "GetContentRangeLength",
      "d": 327795,
      "h": 103079542899,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079542899),
//--TRIMMABLE-BOUNDARY-START(180388954227),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "current",
          "p": 655361,
          "f": 4
        },
        {
          "n": "lengthLength",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetLengthLength",
      "d": 327795,
      "h": 180388954227,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(180388954227),
//--TRIMMABLE-BOUNDARY-START(184683921523),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "current",
          "p": 655361,
          "f": 4
        },
        {
          "n": "fromLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "toStartIndex",
          "p": 655361,
          "f": 2
        },
        {
          "n": "toLength",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetRangeLength",
      "d": 327795,
      "h": 184683921523,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(184683921523),
//--TRIMMABLE-BOUNDARY-START(176093986931),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "unit",
          "p": 852053
        },
        {
          "n": "fromStartIndex",
          "p": 655361
        },
        {
          "n": "fromLength",
          "p": 655361
        },
        {
          "n": "toStartIndex",
          "p": 655361
        },
        {
          "n": "toLength",
          "p": 655361
        },
        {
          "n": "lengthStartIndex",
          "p": 655361
        },
        {
          "n": "lengthLength",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 327795,
          "f": 2
        }
      ],
      "n": "TryCreateContentRange",
      "d": 327795,
      "h": 176093986931,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176093986931)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128849346675),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue).$h,
      "n": "Parser",
      "d": 327795,
      "h": 128849346675,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128849346675),
//--TRIMMABLE-BOUNDARY-START(4295295091),
    {
      "t": 852053,
      "n": "_unit",
      "d": 327795,
      "h": 4295295091,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885229683),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327795,
      "h": 12885229683,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885229683),
//--TRIMMABLE-BOUNDARY-START(17180196979),
    {
      "p": [
        {
          "n": "from",
          "p": 917505
        },
        {
          "n": "to",
          "p": 917505
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327795,
      "h": 17180196979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196979),
//--TRIMMABLE-BOUNDARY-START(21475164275),
    {
      "p": [
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 327795,
      "h": 21475164275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164275),
//--TRIMMABLE-BOUNDARY-START(25770131571),
    {
      "p": [
        {
          "n": "from",
          "p": 917505
        },
        {
          "n": "to",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327795,
      "h": 25770131571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131571)
  ],
  "h": 327795
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ContentRangeHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327795)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507443)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue", ($self) => class RangeHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60131049587)
            /*HttpHeaderParser<RangeHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(60131049587)
            
            //--TRIMMABLE-BOUNDARY-START(8591442035)
            /*StringSegment*/ _unit;
            //--TRIMMABLE-BOUNDARY-END(8591442035)
            
            //--TRIMMABLE-BOUNDARY-START(4296474739)
            /*ICollection<RangeItemHeaderValue>?*/ _ranges = null;
            //--TRIMMABLE-BOUNDARY-END(4296474739)
            
            //--TRIMMABLE-BOUNDARY-START(17181376627)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376627)
            
            //--TRIMMABLE-BOUNDARY-START(21476343923)
            $ctor$2(/*long?*/ $from, /*long?*/ to)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                    this.Ranges.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue().$ctor$1($from, to), [$.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue]);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343923)
            
            //--TRIMMABLE-BOUNDARY-START(85900853363)
            /*StringSegment */ get Unit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._unit;
            }
            /*StringSegment */ set Unit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(value, "value");
                this._unit = value;
            }
            //--TRIMMABLE-BOUNDARY-END(85900853363)
            
            //--TRIMMABLE-BOUNDARY-START(64426016883)
            /*ICollection<RangeItemHeaderValue> */ get Ranges()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._ranges === null)
                {
                    this._ranges = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue))().$ctor$3();
                }
                return this._ranges;
            }
            //--TRIMMABLE-BOUNDARY-END(64426016883)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 77310918771, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310918771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                sb.Append$15(this._unit.AsSpan());
                sb.Append$3(/*=*/ 61);
                /*var*/ let first = true;
                var $en2 = this.Ranges.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var range = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (first)
                        {
                            first = false;
                        }
                        else 
                        {
                            sb.Append$19(", ");
                        }
                        sb.Append$13($.$box(range.From, $.$$.System.Nullable$$($.$$.System.Int64)));
                        sb.Append$3(/*-*/ 45);
                        sb.Append$13($.$box(range.To, $.$$.System.Nullable$$($.$$.System.Int64)));
                    }
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 77310918771, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25771311219, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._unit, other._unit, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections$1($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue, this.Ranges, other.Ranges);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25771311219, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47246147699, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._unit);
                var $en2 = this.Ranges.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var range = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        result = result ^ $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.GetHashCode.call(range);
                    }
                }
                return result;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47246147699, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(55836082291)
            static /*RangeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(55836082291)
            
            //--TRIMMABLE-BOUNDARY-START(81605886067)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out RangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605886067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(81605886067)
            
            //--TRIMMABLE-BOUNDARY-START(51541114995)
            static /*int */ GetRangeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let unitLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (unitLength === 0)
                {
                    return 0;
                }
                /*RangeHeaderValue*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue().$ctor$1();
                result._unit = input.Subsegment(startIndex, unitLength);
                /*var*/ let current = ((startIndex + unitLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*=*/ 61))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let rangesLength = $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.GetRangeItemListLength(input, current, result.Ranges);
                if (rangesLength === 0)
                {
                    return 0;
                }
                current = ((current + rangesLength) | 0);
                $.$$.System.Diagnostics.Contracts.Contract.Assert(current === input.Length, "GetRangeItemListLength() should consume the whole string or fail.");
                parsedValue.$v = result;
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(51541114995)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591442035)
                this._unit = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591442035)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886409331)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(60131049587)
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.GetRangeLength));
                    //--TRIMMABLE-BOUNDARY-END(60131049587)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886409331)
            
            static $h = 1507443;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900853363),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951180403,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015951475,
        "f": 83886081
      },
      "n": "Unit",
      "d": 1507443,
      "h": 85900853363,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900853363),
//--TRIMMABLE-BOUNDARY-START(64426016883),
    {
      "p": $.$$.System.Collections.Generic.ICollection$$($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361245811,
        "f": 50331649
      },
      "n": "Ranges",
      "d": 1507443,
      "h": 64426016883,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426016883)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 77310918771, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1507443,
      "h": 77310918771,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 77310918771, 330712612865),
//--TRIMMABLE-BOUNDARY-START(ALL, 25771311219, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1507443,
      "h": 25771311219,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771311219, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 47246147699, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1507443,
      "h": 47246147699,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47246147699, 184683724801),
//--TRIMMABLE-BOUNDARY-START(55836082291),
    {
      "r": 1507443,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1507443,
      "h": 55836082291,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836082291),
//--TRIMMABLE-BOUNDARY-START(81605886067),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1507443,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1507443,
      "h": 81605886067,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605886067),
//--TRIMMABLE-BOUNDARY-START(51541114995),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1507443,
          "f": 2
        }
      ],
      "n": "GetRangeLength",
      "d": 1507443,
      "h": 51541114995,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51541114995)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60131049587),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue).$h,
      "n": "Parser",
      "d": 1507443,
      "h": 60131049587,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131049587),
//--TRIMMABLE-BOUNDARY-START(8591442035),
    {
      "t": 852053,
      "n": "_unit",
      "d": 1507443,
      "h": 8591442035,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442035),
//--TRIMMABLE-BOUNDARY-START(4296474739),
    {
      "t": $.$$.System.Collections.Generic.ICollection$$($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue).$h,
      "n": "_ranges",
      "d": 1507443,
      "h": 4296474739,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181376627),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507443,
      "h": 17181376627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376627),
//--TRIMMABLE-BOUNDARY-START(21476343923),
    {
      "p": [
        {
          "n": "from",
          "p": $.$typeNullable($.$$.System.Int64).$h
        },
        {
          "n": "to",
          "p": $.$typeNullable($.$$.System.Int64).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507443,
      "h": 21476343923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343923)
  ],
  "h": 1507443
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RangeHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507443)
        
        
        //--TRIMMABLE-BOUNDARY-START(196723)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue", ($self) => class ContentDispositionHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81604575347)
            /*string*/ static FileNameString = null;
            //--TRIMMABLE-BOUNDARY-END(81604575347)
            
            //--TRIMMABLE-BOUNDARY-START(249108299891)
            /*string*/ static NameString = null;
            //--TRIMMABLE-BOUNDARY-END(249108299891)
            
            //--TRIMMABLE-BOUNDARY-START(77309608051)
            /*string*/ static FileNameStarString = null;
            //--TRIMMABLE-BOUNDARY-END(77309608051)
            
            //--TRIMMABLE-BOUNDARY-START(34359935091)
            /*string*/ static CreationDateString = null;
            //--TRIMMABLE-BOUNDARY-END(34359935091)
            
            //--TRIMMABLE-BOUNDARY-START(240518365299)
            /*string*/ static ModificationDateString = null;
            //--TRIMMABLE-BOUNDARY-END(240518365299)
            
            //--TRIMMABLE-BOUNDARY-START(274878103667)
            /*string*/ static ReadDateString = null;
            //--TRIMMABLE-BOUNDARY-END(274878103667)
            
            //--TRIMMABLE-BOUNDARY-START(386547253363)
            /*string*/ static SizeString = null;
            //--TRIMMABLE-BOUNDARY-END(386547253363)
            
            //--TRIMMABLE-BOUNDARY-START(223338496115)
            /*int*/ static MaxStackAllocSizeBytes = 256;
            //--TRIMMABLE-BOUNDARY-END(223338496115)
            
            //--TRIMMABLE-BOUNDARY-START(266288169075)
            /*char[]*/ static QuestionMark = null;
            //--TRIMMABLE-BOUNDARY-END(266288169075)
            
            //--TRIMMABLE-BOUNDARY-START(377957318771)
            /*char[]*/ static SingleQuote = null;
            //--TRIMMABLE-BOUNDARY-END(377957318771)
            
            //--TRIMMABLE-BOUNDARY-START(64424706163)
            /*char[]*/ static EscapeChars = null;
            //--TRIMMABLE-BOUNDARY-END(64424706163)
            
            //--TRIMMABLE-BOUNDARY-START(227633463411)
            static /*ReadOnlySpan<byte> */ get MimePrefix()
            {
                return this.$cacheMimePrefix ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([34, 61, 63, 117, 116, 102, 45, 56, 63, 66, 63]);
            }
            //--TRIMMABLE-BOUNDARY-END(227633463411)
            
            //--TRIMMABLE-BOUNDARY-START(231928430707)
            static /*ReadOnlySpan<byte> */ get MimeSuffix()
            {
                return this.$cacheMimeSuffix ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([63, 61, 34]);
            }
            //--TRIMMABLE-BOUNDARY-END(231928430707)
            
            //--TRIMMABLE-BOUNDARY-START(283468038259)
            /*SearchValues<char>*/ static Rfc5987AttrChar = null;
            //--TRIMMABLE-BOUNDARY-END(283468038259)
            
            //--TRIMMABLE-BOUNDARY-START(261993201779)
            /*HttpHeaderParser<ContentDispositionHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(261993201779)
            
            //--TRIMMABLE-BOUNDARY-START(8590131315)
            /*ObjectCollection<NameValueHeaderValue>?*/ _parameters = null;
            //--TRIMMABLE-BOUNDARY-END(8590131315)
            
            //--TRIMMABLE-BOUNDARY-START(4295164019)
            /*StringSegment*/ _dispositionType;
            //--TRIMMABLE-BOUNDARY-END(4295164019)
            
            //--TRIMMABLE-BOUNDARY-START(17180065907)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065907)
            
            //--TRIMMABLE-BOUNDARY-START(21475033203)
            $ctor$2(/*StringSegment*/ dispositionType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475033203);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.CheckDispositionTypeFormat(dispositionType, "dispositionType");
                    this._dispositionType = dispositionType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475033203)
            
            //--TRIMMABLE-BOUNDARY-START(38654902387)
            /*StringSegment */ get DispositionType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784444531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._dispositionType;
            }
            /*StringSegment */ set DispositionType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942874739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.CheckDispositionTypeFormat(value, "value");
                this._dispositionType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38654902387)
            
            //--TRIMMABLE-BOUNDARY-START(253403267187)
            /*IList<NameValueHeaderValue> */ get Parameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913986675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._parameters === null)
                {
                    this._parameters = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3();
                }
                return this._parameters;
            }
            //--TRIMMABLE-BOUNDARY-END(253403267187)
            
            //--TRIMMABLE-BOUNDARY-START(244813332595)
            /*StringSegment */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324052083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetName("name"/*NameString*/);
            }
            /*StringSegment */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302613107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetName($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("name"/*NameString*/), value);
            }
            //--TRIMMABLE-BOUNDARY-END(244813332595)
            
            //--TRIMMABLE-BOUNDARY-START(68719673459)
            /*StringSegment */ get FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374379123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetName("filename"/*FileNameString*/);
            }
            /*StringSegment */ set FileName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532809331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetName($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("filename"/*FileNameString*/), value);
            }
            //--TRIMMABLE-BOUNDARY-END(68719673459)
            
            //--TRIMMABLE-BOUNDARY-START(73014640755)
            /*StringSegment */ get FileNameStar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetName("filename*"/*FileNameStarString*/);
            }
            /*StringSegment */ set FileNameStar(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122743923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetName($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("filename*"/*FileNameStarString*/), value);
            }
            //--TRIMMABLE-BOUNDARY-END(73014640755)
            
            //--TRIMMABLE-BOUNDARY-START(30064967795)
            /*DateTimeOffset? */ get CreationDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194509939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDate("creation-date"/*CreationDateString*/);
            }
            /*DateTimeOffset? */ set CreationDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296352940147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetDate("creation-date"/*CreationDateString*/, value?.Clone() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(30064967795)
            
            //--TRIMMABLE-BOUNDARY-START(236223398003)
            /*DateTimeOffset? */ get ModificationDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734117491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDate("modification-date"/*ModificationDateString*/);
            }
            /*DateTimeOffset? */ set ModificationDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712678515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetDate("modification-date"/*ModificationDateString*/, value?.Clone() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(236223398003)
            
            //--TRIMMABLE-BOUNDARY-START(270583136371)
            /*DateTimeOffset? */ get ReadDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503921267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDate("read-date"/*ReadDateString*/);
            }
            /*DateTimeOffset? */ set ReadDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892547699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetDate("read-date"/*ReadDateString*/, value?.Clone() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(270583136371)
            
            //--TRIMMABLE-BOUNDARY-START(382252286067)
            /*long? */ get Size()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093855859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sizeParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("size"/*SizeString*/));
                if (sizeParameter !== null)
                {
                    /*var*/ let sizeString = sizeParameter.Value;
                    /*var*/ let value;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(sizeString, $.$ref(() => value, ($v) => value = $v, $.$$.System.Int64)))
                    {
                        return value;
                    }
                }
                return null;
            }
            /*long? */ set Size(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482482291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sizeParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("size"/*SizeString*/));
                if (value === null)
                {
                    if (sizeParameter !== null)
                    {
                        this._parameters.Remove(sizeParameter);
                    }
                }
                else if (value < 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                else if (sizeParameter !== null)
                {
                    sizeParameter.Value = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(value), $.$$.System.Globalization.CultureInfo.InvariantCulture));
                }
                else 
                {
                    /*var*/ let sizeString = $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(value), $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("size"/*SizeString*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(sizeString)), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(382252286067)
            
            //--TRIMMABLE-BOUNDARY-START(365072416883)
            /*void */ SetHttpFileName(/*StringSegment*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072416883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(fileName))
                {
                    this.FileName = $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Sanitize(fileName);
                }
                else 
                {
                    this.FileName = fileName;
                }
                this.FileNameStar = fileName;
            }
            //--TRIMMABLE-BOUNDARY-END(365072416883)
            
            //--TRIMMABLE-BOUNDARY-START(369367384179)
            /*void */ SetMimeFileName(/*StringSegment*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367384179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FileNameStar = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                this.FileName = fileName;
            }
            //--TRIMMABLE-BOUNDARY-END(369367384179)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 390842220659, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842220659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._dispositionType) + $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString$2(this._parameters, /*;*/ 59, true);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 390842220659, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60129738867, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return this._dispositionType.Equals$4(other._dispositionType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._parameters, other._parameters);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60129738867, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 193273725043, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273725043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._dispositionType) ^ $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode$1(this._parameters);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 193273725043, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(257698234483)
            static /*ContentDispositionHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698234483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(257698234483)
            
            //--TRIMMABLE-BOUNDARY-START(403727122547)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out ContentDispositionHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727122547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(403727122547)
            
            //--TRIMMABLE-BOUNDARY-START(188978757747)
            static /*int */ GetDispositionTypeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out ContentDispositionHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978757747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let dispositionType;
                /*var*/ let dispositionTypeLength = $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.GetDispositionTypeExpressionLength(input, startIndex, $.$ref(() => dispositionType, ($v) => dispositionType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                if (dispositionTypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + dispositionTypeLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let contentDispositionHeader = new $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue().$ctor$1();
                contentDispositionHeader._dispositionType = dispositionType;
                if ((current < input.Length) && (input.get_Item(current) === /*;*/ 59))
                {
                    current++;
                    /*int*/ let parameterLength = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueListLength(input, current, /*;*/ 59, contentDispositionHeader.Parameters);
                    parsedValue.$v = contentDispositionHeader;
                    return ((((current + parameterLength) | 0) - startIndex) | 0);
                }
                parsedValue.$v = contentDispositionHeader;
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(188978757747)
            
            //--TRIMMABLE-BOUNDARY-START(184683790451)
            static /*int */ GetDispositionTypeExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringSegment*/ dispositionType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683790451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                dispositionType.$v = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                /*var*/ let typeLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (typeLength === 0)
                {
                    return 0;
                }
                dispositionType.$v = input.Subsegment(startIndex, typeLength);
                return typeLength;
            }
            //--TRIMMABLE-BOUNDARY-END(184683790451)
            
            //--TRIMMABLE-BOUNDARY-START(25770000499)
            static /*void */ CheckDispositionTypeFormat(/*StringSegment*/ dispositionType, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(dispositionType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                /*var*/ let tempDispositionType;
                /*var*/ let dispositionTypeLength = $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.GetDispositionTypeExpressionLength(dispositionType, 0, $.$ref(() => tempDispositionType, ($v) => tempDispositionType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                if ((dispositionTypeLength === 0) || (tempDispositionType.Length !== dispositionType.Length))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "Invalid disposition type '{0}'.", dispositionType));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770000499)
            
            //--TRIMMABLE-BOUNDARY-START(180388823155)
            /*DateTimeOffset? */ GetDate(/*string*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388823155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dateParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(parameter));
                if (dateParameter !== null)
                {
                    /*var*/ let dateString = dateParameter.Value;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsQuoted(dateString))
                    {
                        dateString = dateString.Subsegment(1, ((dateString.Length - 2) | 0));
                    }
                    /*DateTimeOffset*/ let date;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TryStringToDate(dateString, $.$ref(() => date, ($v) => date = $v, $.$$.System.DateTimeOffset)))
                    {
                        return date;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(180388823155)
            
            //--TRIMMABLE-BOUNDARY-START(360777449587)
            /*void */ SetDate(/*string*/ parameter, /*DateTimeOffset?*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777449587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dateParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(parameter));
                if (date === null)
                {
                    if (dateParameter !== null)
                    {
                        this._parameters.Remove(dateParameter);
                    }
                }
                else 
                {
                    /*var*/ let dateString = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatDate($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(date), true);
                    if (dateParameter !== null)
                    {
                        dateParameter.Value = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(dateString);
                    }
                    else 
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(parameter), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(dateString)), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(360777449587)
            
            //--TRIMMABLE-BOUNDARY-START(197568692339)
            /*StringSegment */ GetName(/*string*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568692339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nameParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(parameter));
                if (nameParameter !== null)
                {
                    /*string?*/ let result;
                    if ($.$$.System.String.EndsWith.call(parameter, /***/ 42))
                    {
                        if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.TryDecode5987(nameParameter.Value, $.$ref(() => result, ($v) => result = $v, $.$$.System.String)))
                        {
                            return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(result);
                        }
                        return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                    }
                    if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.TryDecodeMime(nameParameter.Value, $.$ref(() => result, ($v) => result = $v, $.$$.System.String)))
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(result);
                    }
                    return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(nameParameter.Value);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
            }
            //--TRIMMABLE-BOUNDARY-END(197568692339)
            
            //--TRIMMABLE-BOUNDARY-START(373662351475)
            /*void */ SetName(/*StringSegment*/ parameter, /*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662351475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nameParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, parameter);
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value))
                {
                    if (nameParameter !== null)
                    {
                        this._parameters.Remove(nameParameter);
                    }
                }
                else 
                {
                    /*StringSegment*/ let processedValue;
                    if (parameter.EndsWith("*", 4/*StringComparison.Ordinal*/))
                    {
                        processedValue = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Encode5987(value));
                    }
                    else 
                    {
                        processedValue = this.EncodeAndQuoteMime(value);
                    }
                    if (nameParameter !== null)
                    {
                        nameParameter.Value = processedValue;
                    }
                    else 
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2(parameter, processedValue), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(373662351475)
            
            //--TRIMMABLE-BOUNDARY-START(47244836979)
            /*StringSegment */ EncodeAndQuoteMime(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = input;
                /*var*/ let needsQuotes = false;
                if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsQuoted(result))
                {
                    result = result.Subsegment(1, ((result.Length - 2) | 0));
                    needsQuotes = true;
                }
                if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.RequiresEncoding(result))
                {
                    needsQuotes = false;
                    result = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(this.EncodeMimeWithQuotes(result));
                }
                else if (!needsQuotes && $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(result, 0) !== result.Length)
                {
                    needsQuotes = true;
                }
                if (needsQuotes)
                {
                    if (result.IndexOfAny$2($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.EscapeChars) !== -1)
                    {
                        result = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Replace$3.call($.$$.System.String.Replace$3.call($.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(result), "\\", "\\\\"), "\"", "\\\""));
                    }
                    result = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "\"{0}\"", result));
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(47244836979)
            
            //--TRIMMABLE-BOUNDARY-START(287763005555)
            static /*StringSegment */ Sanitize(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763005555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = input;
                if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.RequiresEncoding(result))
                {
                    /*var*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$4(result.Length);
                    for(/*int*/ let i = 0; i < result.Length; i++)
                    {
                        /*var*/ let c = result.get_Item(i);
                        if ($.$cast(c, $.$$.System.Int32) >= 127 || $.$cast(c, $.$$.System.Int32) < 32)
                        {
                            c = /*_*/ 95;
                        }
                        builder.Append$3(c);
                    }
                    result = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.Text.StringBuilder.ToString.call(builder));
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(287763005555)
            
            //--TRIMMABLE-BOUNDARY-START(219043528819)
            static /*bool */ IsQuoted(/*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043528819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)));
                return value.Length > 1 && value.StartsWith("\"", 4/*StringComparison.Ordinal*/) && value.EndsWith("\"", 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(219043528819)
            
            //--TRIMMABLE-BOUNDARY-START(279173070963)
            static /*bool */ RequiresEncoding(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173070963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(input, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)));
                return $.$$.System.MemoryExtensions.IndexOfAnyExceptInRange($.$$.System.Char, input.AsSpan(), 32, 126) >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(279173070963)
            
            //--TRIMMABLE-BOUNDARY-START(51539804275)
            /*string */ EncodeMimeWithQuotes(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let requiredLength = (((($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimePrefix.Length + $.$$.System.Buffers.Text.Base64.GetMaxEncodedToUtf8Length($.$$.System.Text.Encoding.UTF8.GetByteCount$4(input.AsSpan()))) | 0) + $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimeSuffix.Length) | 0);
                /*byte[]?*/ let bufferFromPool = null;
                /*Span<byte>*/ let buffer = requiredLength <= 256/*MaxStackAllocSizeBytes*/ ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 256/*MaxStackAllocSizeBytes*/, null) : $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(bufferFromPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(requiredLength));
                let $t1 = buffer;
                buffer = $t1.Slice(0, requiredLength);
                $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimePrefix.CopyTo(buffer);
                /*var*/ let bufferContent = buffer.Slice$1($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimePrefix.Length);
                /*var*/ let contentLength = $.$$.System.Text.Encoding.UTF8.GetBytes$5(input.AsSpan(), bufferContent);
                /*var*/ let base64ContentLength;
                $.$$.System.Buffers.Text.Base64.EncodeToUtf8InPlace(bufferContent, contentLength, $.$ref(() => base64ContentLength, ($v) => base64ContentLength = $v, $.$$.System.Int32));
                $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimeSuffix.CopyTo(bufferContent.Slice$1(base64ContentLength));
                /*var*/ let result = $.$$.System.Text.Encoding.UTF8.GetString$3($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer.Slice(0, (((($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimePrefix.Length + base64ContentLength) | 0) + $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimeSuffix.Length) | 0))));
                if (!(bufferFromPool === null))
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(bufferFromPool, false);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804275)
            
            //--TRIMMABLE-BOUNDARY-START(399432155251)
            static /*bool */ TryDecodeMime(/*StringSegment*/ input, /*out string?*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432155251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(input, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)));
                output.$v = null;
                /*var*/ let processedInput = input;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsQuoted(processedInput) || processedInput.Length < 10)
                {
                    return false;
                }
                /*var*/ let parts = $.$sl.System.Linq.Enumerable.ToArray($.$mep.Microsoft.Extensions.Primitives.StringSegment, processedInput.Split($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.QuestionMark));
                if (parts.length !== 5 || $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality($.$$.System.Array.$ReadT1.call(parts, 0), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("\"=")) || $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality($.$$.System.Array.$ReadT1.call(parts, 4), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("=\"")) || !$.$$.System.Array.$ReadT1.call(parts, 2).Equals$2("b", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                try
                {
                    /*var*/ let encoding = $.$$.System.Text.Encoding.GetEncoding$3($.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$$.System.Array.$ReadT1.call(parts, 1)));
                    /*var*/ let bytes = $.$$.System.Convert.FromBase64String($.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$$.System.Array.$ReadT1.call(parts, 3)));
                    output.$v = encoding.GetString(bytes, 0, bytes.length);
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.ArgumentException)
                    {
                    }
                    else if ($e instanceof $.$$.System.FormatException)
                    {
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(399432155251)
            
            //--TRIMMABLE-BOUNDARY-START(42949869683)
            static /*string */ Encode5987(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$8("UTF-8''");
                /*var*/ let remaining = input.AsSpan();
                while(remaining.Length > 0)
                {
                    /*var*/ let length = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, remaining, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Rfc5987AttrChar);
                    if (length < 0)
                    {
                        length = remaining.Length;
                    }
                    let $t1 = remaining;
                    builder.Append$15($t1.Slice(0, length));
                    remaining = remaining.Slice$1(length);
                    if (remaining.Length === 0)
                    {
                        break;
                    }
                    length = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, remaining, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Rfc5987AttrChar);
                    if (length < 0)
                    {
                        length = remaining.Length;
                    }
                    for(/*var*/ let i = 0; i < length; )
                    {
                        /*Rune*/ let rune;
                        /*var*/ let runeLength;
                        $.$$.System.Text.Rune.DecodeFromUtf16(remaining.Slice$1(i), $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune), $.$ref(() => runeLength, ($v) => runeLength = $v, $.$$.System.Int32));
                        $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.EncodeToUtf8Hex(rune, builder);
                        i += runeLength;
                    }
                    remaining = remaining.Slice$1(length);
                }
                return $.$$.System.Text.StringBuilder.ToString.call(builder);
            }
            //--TRIMMABLE-BOUNDARY-END(42949869683)
            
            //--TRIMMABLE-BOUNDARY-START(206158626931)
            /*char[]*/ static HexUpperChars = null;
            //--TRIMMABLE-BOUNDARY-END(206158626931)
            
            //--TRIMMABLE-BOUNDARY-START(55834771571)
            static /*void */ EncodeToUtf8Hex(/*Rune*/ rune, /*StringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let value = (rune.Value >>> 0);
                if (rune.IsAscii)
                {
                    /*var*/ let byteValue = $.$cast(value, $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                }
                else if (BigInt(rune.Value) <= 2047n)
                {
                    /*var*/ let byteValue = $.$cast(((((value + ((6 << 11) >>> 0)) >>> 0)) >>> 6), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast(((((value & 63) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                }
                else if (BigInt(rune.Value) <= 65535n)
                {
                    /*var*/ let byteValue = $.$cast(((value + (14 << 16)) >>> 12), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast((((((value & ((63 << 6) >>> 0)) >>> 6) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast(((((value & 63) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                }
                else 
                {
                    /*var*/ let byteValue = $.$cast(((value + (30 << 21)) >>> 18), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast((((((value & ((63 << 12) >>> 0)) >>> 12) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast((((((value & ((63 << 6) >>> 0)) >>> 6) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast(((((value & 63) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834771571)
            
            //--TRIMMABLE-BOUNDARY-START(395137187955)
            static /*bool */ TryDecode5987(/*StringSegment*/ input, /*out string?*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137187955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                output.$v = null;
                /*var*/ let parts = $.$sl.System.Linq.Enumerable.ToArray($.$mep.Microsoft.Extensions.Primitives.StringSegment, input.Split($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.SingleQuote));
                if (parts.length !== 3)
                {
                    return false;
                }
                /*var*/ let decoded = new $.$$.System.Text.StringBuilder().$ctor$1();
                /*byte[]?*/ let unescapedBytes = null;
                try
                {
                    /*var*/ let encoding = $.$$.System.Text.Encoding.GetEncoding$3($.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$$.System.Array.$ReadT1.call(parts, 0)));
                    /*var*/ let dataString = $.$$.System.Array.$ReadT1.call(parts, 2);
                    unescapedBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(dataString.Length);
                    /*var*/ let unescapedBytesCount = 0;
                    for(/*var*/ let index = 0; index < dataString.Length; index++)
                    {
                        if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsHexEncoding(dataString, index))
                        {
                            $.$$.System.Array.$WriteT1.call(unescapedBytes, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUnescape(dataString, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32)), unescapedBytesCount++);
                            index--;
                        }
                        else 
                        {
                            if (unescapedBytesCount > 0)
                            {
                                decoded.Append$19(encoding.GetString(unescapedBytes, 0, unescapedBytesCount));
                                unescapedBytesCount = 0;
                            }
                            decoded.Append$3(dataString.get_Item(index));
                        }
                    }
                    if (unescapedBytesCount > 0)
                    {
                        decoded.Append$19(encoding.GetString(unescapedBytes, 0, unescapedBytesCount));
                    }
                }
                catch($e)
                {
                    return false;
                }
                finally
                {
                    {
                        if (unescapedBytes !== null)
                        {
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(unescapedBytes, false);
                        }
                    }
                }
                output.$v = $.$$.System.Text.StringBuilder.ToString.call(decoded);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(395137187955)
            
            //--TRIMMABLE-BOUNDARY-START(214748561523)
            static /*bool */ IsHexEncoding(/*StringSegment*/ pattern, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748561523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((((pattern.Length - index) | 0)) < 3)
                {
                    return false;
                }
                if ((pattern.get_Item(index) === /*%*/ 37) && $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsEscapedAscii(pattern.get_Item(((index + 1) | 0)), pattern.get_Item(((index + 2) | 0))))
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(214748561523)
            
            //--TRIMMABLE-BOUNDARY-START(210453594227)
            static /*bool */ IsEscapedAscii(/*char*/ digit, /*char*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453594227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(((digit >= /*0*/ 48) && (digit <= /*9*/ 57)) || ((digit >= /*A*/ 65) && (digit <= /*F*/ 70)) || ((digit >= /*a*/ 97) && (digit <= /*f*/ 102))))
                {
                    return false;
                }
                if (!(((next >= /*0*/ 48) && (next <= /*9*/ 57)) || ((next >= /*A*/ 65) && (next <= /*F*/ 70)) || ((next >= /*a*/ 97) && (next <= /*f*/ 102))))
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(210453594227)
            
            //--TRIMMABLE-BOUNDARY-START(201863659635)
            static /*byte */ HexUnescape(/*StringSegment*/ pattern, /*ref int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863659635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((index.$v < 0) || (index.$v >= pattern.Length))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
                }
                if ((pattern.get_Item(index.$v) === /*%*/ 37) && (((pattern.Length - index.$v) | 0) >= 3))
                {
                    /*var*/ let ret = $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.UnEscapeAscii(pattern.get_Item(((index.$v + 1) | 0)), pattern.get_Item(((index.$v + 2) | 0)));
                    index.$v += 3;
                    return ret;
                }
                return $.$cast(pattern.get_Item(index.$v++), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(201863659635)
            
            //--TRIMMABLE-BOUNDARY-START(408022089843)
            static /*byte */ UnEscapeAscii(/*char*/ digit, /*char*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022089843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(((digit >= /*0*/ 48) && (digit <= /*9*/ 57)) || ((digit >= /*A*/ 65) && (digit <= /*F*/ 70)) || ((digit >= /*a*/ 97) && (digit <= /*f*/ 102))))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("digit");
                }
                /*var*/ let res = (digit <= /*9*/ 57) ? ((($.$cast(digit, $.$$.System.Int32) - /*0*/ 48) | 0)) : (((((digit <= /*F*/ 70) ? ((($.$cast(digit, $.$$.System.Int32) - /*A*/ 65) | 0)) : ((($.$cast(digit, $.$$.System.Int32) - /*a*/ 97) | 0))) + 10) | 0));
                if (!(((next >= /*0*/ 48) && (next <= /*9*/ 57)) || ((next >= /*A*/ 65) && (next <= /*F*/ 70)) || ((next >= /*a*/ 97) && (next <= /*f*/ 102))))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("next");
                }
                return $.$cast(((((res << 4) + ((next <= /*9*/ 57) ? ((($.$cast(next, $.$$.System.Int32) - /*0*/ 48) | 0)) : (((((next <= /*F*/ 70) ? ((($.$cast(next, $.$$.System.Int32) - /*A*/ 65) | 0)) : ((($.$cast(next, $.$$.System.Int32) - /*a*/ 97) | 0))) + 10) | 0)))) | 0)), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(408022089843)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295164019)
                this._dispositionType = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(4295164019)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885098611)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(81604575347)
                    this.FileNameString = "filename";
                    //--TRIMMABLE-BOUNDARY-END(81604575347)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108299891)
                    this.NameString = "name";
                    //--TRIMMABLE-BOUNDARY-END(249108299891)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309608051)
                    this.FileNameStarString = "filename*";
                    //--TRIMMABLE-BOUNDARY-END(77309608051)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359935091)
                    this.CreationDateString = "creation-date";
                    //--TRIMMABLE-BOUNDARY-END(34359935091)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518365299)
                    this.ModificationDateString = "modification-date";
                    //--TRIMMABLE-BOUNDARY-END(240518365299)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878103667)
                    this.ReadDateString = "read-date";
                    //--TRIMMABLE-BOUNDARY-END(274878103667)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547253363)
                    this.SizeString = "size";
                    //--TRIMMABLE-BOUNDARY-END(386547253363)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288169075)
                    this.QuestionMark = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*?*/ 63], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(266288169075)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957318771)
                    this.SingleQuote = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*'*/ 39], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(377957318771)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424706163)
                    this.EscapeChars = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*\\*/ 92, /*\"*/ 34], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(64424706163)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468038259)
                    this.Rfc5987AttrChar = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!#$&+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"));
                    //--TRIMMABLE-BOUNDARY-END(283468038259)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993201779)
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.GetDispositionTypeLength));
                    //--TRIMMABLE-BOUNDARY-END(261993201779)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158626931)
                    this.HexUpperChars = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*0*/ 48, /*1*/ 49, /*2*/ 50, /*3*/ 51, /*4*/ 52, /*5*/ 53, /*6*/ 54, /*7*/ 55, /*8*/ 56, /*9*/ 57, /*A*/ 65, /*B*/ 66, /*C*/ 67, /*D*/ 68, /*E*/ 69, /*F*/ 70], null, null);
                    //--TRIMMABLE-BOUNDARY-END(206158626931)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885098611)
            
            static $h = 196723;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(227633463411),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554248307,
        "f": 50331682
      },
      "n": "MimePrefix",
      "d": 196723,
      "h": 227633463411,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(227633463411),
//--TRIMMABLE-BOUNDARY-START(231928430707),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144182899,
        "f": 50331682
      },
      "n": "MimeSuffix",
      "d": 196723,
      "h": 231928430707,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(231928430707),
//--TRIMMABLE-BOUNDARY-START(38654902387),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784444531,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304942874739,
        "f": 83886081
      },
      "n": "DispositionType",
      "d": 196723,
      "h": 38654902387,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654902387),
//--TRIMMABLE-BOUNDARY-START(253403267187),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913986675,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 196723,
      "h": 253403267187,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403267187),
//--TRIMMABLE-BOUNDARY-START(244813332595),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324052083,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339302613107,
        "f": 83886081
      },
      "n": "Name",
      "d": 196723,
      "h": 244813332595,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244813332595),
//--TRIMMABLE-BOUNDARY-START(68719673459),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374379123,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313532809331,
        "f": 83886081
      },
      "n": "FileName",
      "d": 196723,
      "h": 68719673459,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719673459),
//--TRIMMABLE-BOUNDARY-START(73014640755),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964313715,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322122743923,
        "f": 83886081
      },
      "n": "FileNameStar",
      "d": 196723,
      "h": 73014640755,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014640755),
//--TRIMMABLE-BOUNDARY-START(30064967795),
    {
      "p": $.$typeNullable($.$$.System.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194509939,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296352940147,
        "f": 83886081
      },
      "n": "CreationDate",
      "d": 196723,
      "h": 30064967795,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064967795),
//--TRIMMABLE-BOUNDARY-START(236223398003),
    {
      "p": $.$typeNullable($.$$.System.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734117491,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330712678515,
        "f": 83886081
      },
      "n": "ModificationDate",
      "d": 196723,
      "h": 236223398003,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236223398003),
//--TRIMMABLE-BOUNDARY-START(270583136371),
    {
      "p": $.$typeNullable($.$$.System.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503921267,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347892547699,
        "f": 83886081
      },
      "n": "ReadDate",
      "d": 196723,
      "h": 270583136371,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583136371),
//--TRIMMABLE-BOUNDARY-START(382252286067),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093855859,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356482482291,
        "f": 83886081
      },
      "n": "Size",
      "d": 196723,
      "h": 382252286067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(382252286067)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(365072416883),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 852053
        }
      ],
      "n": "SetHttpFileName",
      "d": 196723,
      "h": 365072416883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(365072416883),
//--TRIMMABLE-BOUNDARY-START(369367384179),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 852053
        }
      ],
      "n": "SetMimeFileName",
      "d": 196723,
      "h": 369367384179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(369367384179),
//--TRIMMABLE-BOUNDARY-START(ALL, 390842220659, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 196723,
      "h": 390842220659,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 390842220659, 330712612865),
//--TRIMMABLE-BOUNDARY-START(ALL, 60129738867, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 196723,
      "h": 60129738867,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60129738867, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 193273725043, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 196723,
      "h": 193273725043,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 193273725043, 184683724801),
//--TRIMMABLE-BOUNDARY-START(257698234483),
    {
      "r": 196723,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 196723,
      "h": 257698234483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257698234483),
//--TRIMMABLE-BOUNDARY-START(403727122547),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 196723,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 196723,
      "h": 403727122547,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(403727122547),
//--TRIMMABLE-BOUNDARY-START(188978757747),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 196723,
          "f": 2
        }
      ],
      "n": "GetDispositionTypeLength",
      "d": 196723,
      "h": 188978757747,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(188978757747),
//--TRIMMABLE-BOUNDARY-START(184683790451),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "dispositionType",
          "p": 852053,
          "f": 2
        }
      ],
      "n": "GetDispositionTypeExpressionLength",
      "d": 196723,
      "h": 184683790451,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(184683790451),
//--TRIMMABLE-BOUNDARY-START(25770000499),
    {
      "r": 65537,
      "p": [
        {
          "n": "dispositionType",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckDispositionTypeFormat",
      "d": 196723,
      "h": 25770000499,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770000499),
//--TRIMMABLE-BOUNDARY-START(180388823155),
    {
      "r": $.$typeNullable($.$$.System.DateTimeOffset).$h,
      "p": [
        {
          "n": "parameter",
          "p": 1310721
        }
      ],
      "n": "GetDate",
      "d": 196723,
      "h": 180388823155,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180388823155),
//--TRIMMABLE-BOUNDARY-START(360777449587),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameter",
          "p": 1310721
        },
        {
          "n": "date",
          "p": $.$typeNullable($.$$.System.DateTimeOffset).$h
        }
      ],
      "n": "SetDate",
      "d": 196723,
      "h": 360777449587,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(360777449587),
//--TRIMMABLE-BOUNDARY-START(197568692339),
    {
      "r": 852053,
      "p": [
        {
          "n": "parameter",
          "p": 1310721
        }
      ],
      "n": "GetName",
      "d": 196723,
      "h": 197568692339,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197568692339),
//--TRIMMABLE-BOUNDARY-START(373662351475),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameter",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "SetName",
      "d": 196723,
      "h": 373662351475,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(373662351475),
//--TRIMMABLE-BOUNDARY-START(47244836979),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "EncodeAndQuoteMime",
      "d": 196723,
      "h": 47244836979,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244836979),
//--TRIMMABLE-BOUNDARY-START(287763005555),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Sanitize",
      "d": 196723,
      "h": 287763005555,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(287763005555),
//--TRIMMABLE-BOUNDARY-START(219043528819),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "IsQuoted",
      "d": 196723,
      "h": 219043528819,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(219043528819),
//--TRIMMABLE-BOUNDARY-START(279173070963),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "RequiresEncoding",
      "d": 196723,
      "h": 279173070963,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(279173070963),
//--TRIMMABLE-BOUNDARY-START(51539804275),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "EncodeMimeWithQuotes",
      "d": 196723,
      "h": 51539804275,
      "f": 16777218,
      "a": [
        {
          "t": 132841473,
          "c": 4427808769
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539804275),
//--TRIMMABLE-BOUNDARY-START(399432155251),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "output",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryDecodeMime",
      "d": 196723,
      "h": 399432155251,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(399432155251),
//--TRIMMABLE-BOUNDARY-START(42949869683),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Encode5987",
      "d": 196723,
      "h": 42949869683,
      "f": 16777250,
      "a": [
        {
          "t": 132841473,
          "c": 4427808769
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949869683),
//--TRIMMABLE-BOUNDARY-START(55834771571),
    {
      "r": 65537,
      "p": [
        {
          "n": "rune",
          "p": 166723585
        },
        {
          "n": "builder",
          "p": 166920193
        }
      ],
      "n": "EncodeToUtf8Hex",
      "d": 196723,
      "h": 55834771571,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834771571),
//--TRIMMABLE-BOUNDARY-START(395137187955),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "output",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryDecode5987",
      "d": 196723,
      "h": 395137187955,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(395137187955),
//--TRIMMABLE-BOUNDARY-START(214748561523),
    {
      "r": 262145,
      "p": [
        {
          "n": "pattern",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "IsHexEncoding",
      "d": 196723,
      "h": 214748561523,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(214748561523),
//--TRIMMABLE-BOUNDARY-START(210453594227),
    {
      "r": 262145,
      "p": [
        {
          "n": "digit",
          "p": 458753
        },
        {
          "n": "next",
          "p": 458753
        }
      ],
      "n": "IsEscapedAscii",
      "d": 196723,
      "h": 210453594227,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(210453594227),
//--TRIMMABLE-BOUNDARY-START(201863659635),
    {
      "r": 393217,
      "p": [
        {
          "n": "pattern",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "HexUnescape",
      "d": 196723,
      "h": 201863659635,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201863659635),
//--TRIMMABLE-BOUNDARY-START(408022089843),
    {
      "r": 393217,
      "p": [
        {
          "n": "digit",
          "p": 458753
        },
        {
          "n": "next",
          "p": 458753
        }
      ],
      "n": "UnEscapeAscii",
      "d": 196723,
      "h": 408022089843,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(408022089843)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81604575347),
    {
      "t": 1310721,
      "n": "FileNameString",
      "d": 196723,
      "h": 81604575347,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81604575347),
//--TRIMMABLE-BOUNDARY-START(249108299891),
    {
      "t": 1310721,
      "n": "NameString",
      "d": 196723,
      "h": 249108299891,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(249108299891),
//--TRIMMABLE-BOUNDARY-START(77309608051),
    {
      "t": 1310721,
      "n": "FileNameStarString",
      "d": 196723,
      "h": 77309608051,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77309608051),
//--TRIMMABLE-BOUNDARY-START(34359935091),
    {
      "t": 1310721,
      "n": "CreationDateString",
      "d": 196723,
      "h": 34359935091,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359935091),
//--TRIMMABLE-BOUNDARY-START(240518365299),
    {
      "t": 1310721,
      "n": "ModificationDateString",
      "d": 196723,
      "h": 240518365299,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(240518365299),
//--TRIMMABLE-BOUNDARY-START(274878103667),
    {
      "t": 1310721,
      "n": "ReadDateString",
      "d": 196723,
      "h": 274878103667,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(274878103667),
//--TRIMMABLE-BOUNDARY-START(386547253363),
    {
      "t": 1310721,
      "n": "SizeString",
      "d": 196723,
      "h": 386547253363,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(386547253363),
//--TRIMMABLE-BOUNDARY-START(223338496115),
    {
      "t": 655361,
      "n": "MaxStackAllocSizeBytes",
      "d": 196723,
      "h": 223338496115,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(223338496115),
//--TRIMMABLE-BOUNDARY-START(266288169075),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "QuestionMark",
      "d": 196723,
      "h": 266288169075,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(266288169075),
//--TRIMMABLE-BOUNDARY-START(377957318771),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "SingleQuote",
      "d": 196723,
      "h": 377957318771,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(377957318771),
//--TRIMMABLE-BOUNDARY-START(64424706163),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "EscapeChars",
      "d": 196723,
      "h": 64424706163,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64424706163),
//--TRIMMABLE-BOUNDARY-START(283468038259),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "Rfc5987AttrChar",
      "d": 196723,
      "h": 283468038259,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(283468038259),
//--TRIMMABLE-BOUNDARY-START(261993201779),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue).$h,
      "n": "Parser",
      "d": 196723,
      "h": 261993201779,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(261993201779),
//--TRIMMABLE-BOUNDARY-START(8590131315),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "n": "_parameters",
      "d": 196723,
      "h": 8590131315,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131315),
//--TRIMMABLE-BOUNDARY-START(4295164019),
    {
      "t": 852053,
      "n": "_dispositionType",
      "d": 196723,
      "h": 4295164019,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295164019),
//--TRIMMABLE-BOUNDARY-START(206158626931),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "HexUpperChars",
      "d": 196723,
      "h": 206158626931,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(206158626931)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065907),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196723,
      "h": 17180065907,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180065907),
//--TRIMMABLE-BOUNDARY-START(21475033203),
    {
      "p": [
        {
          "n": "dispositionType",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196723,
      "h": 21475033203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033203)
  ],
  "h": 196723
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ContentDispositionHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196723)
        
        
        //--TRIMMABLE-BOUNDARY-START(131187)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue", ($self) => class CacheControlHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(369367318643)
            /*string*/ static PublicString = null;
            //--TRIMMABLE-BOUNDARY-END(369367318643)
            
            //--TRIMMABLE-BOUNDARY-START(352187449459)
            /*string*/ static PrivateString = null;
            //--TRIMMABLE-BOUNDARY-END(352187449459)
            
            //--TRIMMABLE-BOUNDARY-START(261993136243)
            /*string*/ static MaxAgeString = null;
            //--TRIMMABLE-BOUNDARY-END(261993136243)
            
            //--TRIMMABLE-BOUNDARY-START(489626402931)
            /*string*/ static SharedMaxAgeString = null;
            //--TRIMMABLE-BOUNDARY-END(489626402931)
            
            //--TRIMMABLE-BOUNDARY-START(304942809203)
            /*string*/ static NoCacheString = null;
            //--TRIMMABLE-BOUNDARY-END(304942809203)
            
            //--TRIMMABLE-BOUNDARY-START(313532743795)
            /*string*/ static NoStoreString = null;
            //--TRIMMABLE-BOUNDARY-END(313532743795)
            
            //--TRIMMABLE-BOUNDARY-START(274878038131)
            /*string*/ static MaxStaleString = null;
            //--TRIMMABLE-BOUNDARY-END(274878038131)
            
            //--TRIMMABLE-BOUNDARY-START(283467972723)
            /*string*/ static MinFreshString = null;
            //--TRIMMABLE-BOUNDARY-END(283467972723)
            
            //--TRIMMABLE-BOUNDARY-START(322122678387)
            /*string*/ static NoTransformString = null;
            //--TRIMMABLE-BOUNDARY-END(322122678387)
            
            //--TRIMMABLE-BOUNDARY-START(330712612979)
            /*string*/ static OnlyIfCachedString = null;
            //--TRIMMABLE-BOUNDARY-END(330712612979)
            
            //--TRIMMABLE-BOUNDARY-START(292057907315)
            /*string*/ static MustRevalidateString = null;
            //--TRIMMABLE-BOUNDARY-END(292057907315)
            
            //--TRIMMABLE-BOUNDARY-START(360777384051)
            /*string*/ static ProxyRevalidateString = null;
            //--TRIMMABLE-BOUNDARY-END(360777384051)
            
            //--TRIMMABLE-BOUNDARY-START(339302547571)
            /*HttpHeaderParser<CacheControlHeaderValue>*/ static Parser = null;
            //--TRIMMABLE-BOUNDARY-END(339302547571)
            
            //--TRIMMABLE-BOUNDARY-START(98784378995)
            /*Action<StringSegment>*/ static CheckIsValidTokenAction = null;
            //--TRIMMABLE-BOUNDARY-END(98784378995)
            
            //--TRIMMABLE-BOUNDARY-START(30064902259)
            /*bool*/ _noCache = false;
            //--TRIMMABLE-BOUNDARY-END(30064902259)
            
            //--TRIMMABLE-BOUNDARY-START(34359869555)
            /*ICollection<StringSegment>?*/ _noCacheHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(34359869555)
            
            //--TRIMMABLE-BOUNDARY-START(38654836851)
            /*bool*/ _noStore = false;
            //--TRIMMABLE-BOUNDARY-END(38654836851)
            
            //--TRIMMABLE-BOUNDARY-START(8590065779)
            /*TimeSpan?*/ _maxAge = null;
            //--TRIMMABLE-BOUNDARY-END(8590065779)
            
            //--TRIMMABLE-BOUNDARY-START(68719607923)
            /*TimeSpan?*/ _sharedMaxAge = null;
            //--TRIMMABLE-BOUNDARY-END(68719607923)
            
            //--TRIMMABLE-BOUNDARY-START(12885033075)
            /*bool*/ _maxStale = false;
            //--TRIMMABLE-BOUNDARY-END(12885033075)
            
            //--TRIMMABLE-BOUNDARY-START(17180000371)
            /*TimeSpan?*/ _maxStaleLimit = null;
            //--TRIMMABLE-BOUNDARY-END(17180000371)
            
            //--TRIMMABLE-BOUNDARY-START(21474967667)
            /*TimeSpan?*/ _minFresh = null;
            //--TRIMMABLE-BOUNDARY-END(21474967667)
            
            //--TRIMMABLE-BOUNDARY-START(42949804147)
            /*bool*/ _noTransform = false;
            //--TRIMMABLE-BOUNDARY-END(42949804147)
            
            //--TRIMMABLE-BOUNDARY-START(47244771443)
            /*bool*/ _onlyIfCached = false;
            //--TRIMMABLE-BOUNDARY-END(47244771443)
            
            //--TRIMMABLE-BOUNDARY-START(64424640627)
            /*bool*/ _public = false;
            //--TRIMMABLE-BOUNDARY-END(64424640627)
            
            //--TRIMMABLE-BOUNDARY-START(51539738739)
            /*bool*/ _private = false;
            //--TRIMMABLE-BOUNDARY-END(51539738739)
            
            //--TRIMMABLE-BOUNDARY-START(55834706035)
            /*ICollection<StringSegment>?*/ _privateHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(55834706035)
            
            //--TRIMMABLE-BOUNDARY-START(25769934963)
            /*bool*/ _mustRevalidate = false;
            //--TRIMMABLE-BOUNDARY-END(25769934963)
            
            //--TRIMMABLE-BOUNDARY-START(60129673331)
            /*bool*/ _proxyRevalidate = false;
            //--TRIMMABLE-BOUNDARY-END(60129673331)
            
            //--TRIMMABLE-BOUNDARY-START(4295098483)
            /*IList<NameValueHeaderValue>?*/ _extensions = null;
            //--TRIMMABLE-BOUNDARY-END(4295098483)
            
            //--TRIMMABLE-BOUNDARY-START(77309542515)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309542515);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309542515)
            
            //--TRIMMABLE-BOUNDARY-START(296352874611)
            /*bool */ get NoCache()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503855731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._noCache;
            }
            /*bool */ set NoCache(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420906926195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._noCache = value;
            }
            //--TRIMMABLE-BOUNDARY-END(296352874611)
            
            //--TRIMMABLE-BOUNDARY-START(300647841907)
            /*ICollection<StringSegment> */ get NoCacheHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093790323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._noCacheHeaders === null)
                {
                    this._noCacheHeaders = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                }
                return this._noCacheHeaders;
            }
            //--TRIMMABLE-BOUNDARY-END(300647841907)
            
            //--TRIMMABLE-BOUNDARY-START(309237776499)
            /*bool */ get NoStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683724915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._noStore;
            }
            /*bool */ set NoStore(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429496860787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._noStore = value;
            }
            //--TRIMMABLE-BOUNDARY-END(309237776499)
            
            //--TRIMMABLE-BOUNDARY-START(257698168947)
            /*TimeSpan? */ get MaxAge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554182771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._maxAge;
            }
            /*TimeSpan? */ set MaxAge(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957253235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._maxAge = value?.Clone() ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(257698168947)
            
            //--TRIMMABLE-BOUNDARY-START(485331435635)
            /*TimeSpan? */ get SharedMaxAge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813267059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._sharedMaxAge;
            }
            /*TimeSpan? */ set SharedMaxAge(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036468339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._sharedMaxAge = value?.Clone() ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(485331435635)
            
            //--TRIMMABLE-BOUNDARY-START(266288103539)
            /*bool */ get MaxStale()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144117363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._maxStale;
            }
            /*bool */ set MaxStale(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547187827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._maxStale = value;
            }
            //--TRIMMABLE-BOUNDARY-END(266288103539)
            
            //--TRIMMABLE-BOUNDARY-START(270583070835)
            /*TimeSpan? */ get MaxStaleLimit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734051955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._maxStaleLimit;
            }
            /*TimeSpan? */ set MaxStaleLimit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137122419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._maxStaleLimit = value?.Clone() ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(270583070835)
            
            //--TRIMMABLE-BOUNDARY-START(279173005427)
            /*TimeSpan? */ get MinFresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323986547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._minFresh;
            }
            /*TimeSpan? */ set MinFresh(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727057011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._minFresh = value?.Clone() ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(279173005427)
            
            //--TRIMMABLE-BOUNDARY-START(317827711091)
            /*bool */ get NoTransform()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273659507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._noTransform;
            }
            /*bool */ set NoTransform(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438086795379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._noTransform = value;
            }
            //--TRIMMABLE-BOUNDARY-END(317827711091)
            
            //--TRIMMABLE-BOUNDARY-START(326417645683)
            /*bool */ get OnlyIfCached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863594099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._onlyIfCached;
            }
            /*bool */ set OnlyIfCached(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446676729971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._onlyIfCached = value;
            }
            //--TRIMMABLE-BOUNDARY-END(326417645683)
            
            //--TRIMMABLE-BOUNDARY-START(365072351347)
            /*bool */ get Public()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223332467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._public;
            }
            /*bool */ set Public(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472446533747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._public = value;
            }
            //--TRIMMABLE-BOUNDARY-END(365072351347)
            
            //--TRIMMABLE-BOUNDARY-START(343597514867)
            /*bool */ get Private()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453528691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._private;
            }
            /*bool */ set Private(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455266664563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._private = value;
            }
            //--TRIMMABLE-BOUNDARY-END(343597514867)
            
            //--TRIMMABLE-BOUNDARY-START(347892482163)
            /*ICollection<StringSegment> */ get PrivateHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043463283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._privateHeaders === null)
                {
                    this._privateHeaders = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                }
                return this._privateHeaders;
            }
            //--TRIMMABLE-BOUNDARY-END(347892482163)
            
            //--TRIMMABLE-BOUNDARY-START(287762940019)
            /*bool */ get MustRevalidate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913921139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mustRevalidate;
            }
            /*bool */ set MustRevalidate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412316991603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._mustRevalidate = value;
            }
            //--TRIMMABLE-BOUNDARY-END(287762940019)
            
            //--TRIMMABLE-BOUNDARY-START(356482416755)
            /*bool */ get ProxyRevalidate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633397875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._proxyRevalidate;
            }
            /*bool */ set ProxyRevalidate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463856599155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._proxyRevalidate = value;
            }
            //--TRIMMABLE-BOUNDARY-END(356482416755)
            
            //--TRIMMABLE-BOUNDARY-START(107374313587)
            /*IList<NameValueHeaderValue> */ get Extensions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964248179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._extensions === null)
                {
                    this._extensions = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3();
                }
                return this._extensions;
            }
            //--TRIMMABLE-BOUNDARY-END(107374313587)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 493921370227, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493921370227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._noStore, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoStoreString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._noTransform, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoTransformString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._onlyIfCached, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.OnlyIfCachedString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._public, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.PublicString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._mustRevalidate, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MustRevalidateString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._proxyRevalidate, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.ProxyRevalidateString);
                if (this._noCache)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoCacheString);
                    if ((this._noCacheHeaders !== null) && (this._noCacheHeaders.System$Collections$Generic$ICollection$$$Count > 0))
                    {
                        sb.Append$19("=\"");
                        $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValues(sb, this._noCacheHeaders);
                        sb.Append$3(/*\"*/ 34);
                    }
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._maxAge))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MaxAgeString);
                    sb.Append$3(/*=*/ 61);
                    sb.Append$19($.$$.System.Int32.ToString$1.call(($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._maxAge).TotalSeconds, $.$$.System.Int32)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._sharedMaxAge))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.SharedMaxAgeString);
                    sb.Append$3(/*=*/ 61);
                    sb.Append$19($.$$.System.Int32.ToString$1.call(($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._sharedMaxAge).TotalSeconds, $.$$.System.Int32)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                if (this._maxStale)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MaxStaleString);
                    if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._maxStaleLimit))
                    {
                        sb.Append$3(/*=*/ 61);
                        sb.Append$19($.$$.System.Int32.ToString$1.call(($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._maxStaleLimit).TotalSeconds, $.$$.System.Int32)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                    }
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._minFresh))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MinFreshString);
                    sb.Append$3(/*=*/ 61);
                    sb.Append$19($.$$.System.Int32.ToString$1.call(($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._minFresh).TotalSeconds, $.$$.System.Int32)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                if (this._private)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.PrivateString);
                    if ((this._privateHeaders !== null) && (this._privateHeaders.System$Collections$Generic$ICollection$$$Count > 0))
                    {
                        sb.Append$19("=\"");
                        $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValues(sb, this._privateHeaders);
                        sb.Append$3(/*\"*/ 34);
                    }
                }
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString$1(this._extensions, /*,*/ 44, false, sb);
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 493921370227, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 103079346291, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if ((this._noCache !== other._noCache) || (this._noStore !== other._noStore) || (this._maxAge !== other._maxAge) || (this._sharedMaxAge !== other._sharedMaxAge) || (this._maxStale !== other._maxStale) || (this._maxStaleLimit !== other._maxStaleLimit) || (this._minFresh !== other._minFresh) || (this._noTransform !== other._noTransform) || (this._onlyIfCached !== other._onlyIfCached) || (this._public !== other._public) || (this._private !== other._private) || (this._mustRevalidate !== other._mustRevalidate) || (this._proxyRevalidate !== other._proxyRevalidate))
                {
                    return false;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections($.$mep.Microsoft.Extensions.Primitives.StringSegment, this._noCacheHeaders, other._noCacheHeaders, $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase))
                {
                    return false;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections($.$mep.Microsoft.Extensions.Primitives.StringSegment, this._privateHeaders, other._privateHeaders, $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase))
                {
                    return false;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._extensions, other._extensions))
                {
                    return false;
                }
                return true;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 103079346291, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 253403201651, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403201651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let result = $.$$.System.Boolean.GetHashCode.call(this._noCache) ^ ($.$$.System.Boolean.GetHashCode.call(this._noStore) << 1) ^ ($.$$.System.Boolean.GetHashCode.call(this._maxStale) << 2) ^ ($.$$.System.Boolean.GetHashCode.call(this._noTransform) << 3) ^ ($.$$.System.Boolean.GetHashCode.call(this._onlyIfCached) << 4) ^ ($.$$.System.Boolean.GetHashCode.call(this._public) << 5) ^ ($.$$.System.Boolean.GetHashCode.call(this._private) << 6) ^ ($.$$.System.Boolean.GetHashCode.call(this._mustRevalidate) << 7) ^ ($.$$.System.Boolean.GetHashCode.call(this._proxyRevalidate) << 8);
                result = result ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._maxAge) ? $.$$.System.TimeSpan.GetHashCode.call($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._maxAge)) ^ 1 : 0) ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._sharedMaxAge) ? $.$$.System.TimeSpan.GetHashCode.call($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._sharedMaxAge)) ^ 2 : 0) ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._maxStaleLimit) ? $.$$.System.TimeSpan.GetHashCode.call($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._maxStaleLimit)) ^ 4 : 0) ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._minFresh) ? $.$$.System.TimeSpan.GetHashCode.call($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._minFresh)) ^ 8 : 0);
                if ((this._noCacheHeaders !== null) && (this._noCacheHeaders.System$Collections$Generic$ICollection$$$Count > 0))
                {
                    var $en3 = this._noCacheHeaders.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var noCacheHeader = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result = result ^ $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(noCacheHeader);
                        }
                    }
                }
                if ((this._privateHeaders !== null) && (this._privateHeaders.System$Collections$Generic$ICollection$$$Count > 0))
                {
                    var $en3 = this._privateHeaders.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var privateHeader = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result = result ^ $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(privateHeader);
                        }
                    }
                }
                if ((this._extensions !== null) && (this._extensions.System$Collections$Generic$ICollection$$$Count > 0))
                {
                    var $en3 = this._extensions.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var extension = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result = result ^ $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode.call(extension);
                        }
                    }
                }
                return result;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 253403201651, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(335007580275)
            static /*CacheControlHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007580275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                /*var*/ let result = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
                if (result === null)
                {
                    throw new $.$$.System.FormatException().$ctor$12("No cache directives found.");
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(335007580275)
            
            //--TRIMMABLE-BOUNDARY-START(498216337523)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out CacheControlHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216337523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                if ($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue) && parsedValue.$v !== null)
                {
                    return true;
                }
                parsedValue.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(498216337523)
            
            //--TRIMMABLE-BOUNDARY-START(249108234355)
            static /*int */ GetCacheControlLength(/*StringSegment*/ input, /*int*/ startIndex, /*out CacheControlHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108234355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*var*/ let nameValueList = new ($.$$.System.Collections.Generic.List$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$1();
                while(current < input.Length)
                {
                    /*var*/ let nameValue;
                    if (!$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.TryParseValue(input, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => nameValue, ($v) => nameValue = $v, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue)))
                    {
                        return 0;
                    }
                    if (nameValue !== null)
                    {
                        nameValueList.Add(nameValue);
                    }
                }
                /*var*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue().$ctor$1();
                if (!$.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetCacheControlValues(result, nameValueList))
                {
                    return 0;
                }
                parsedValue.$v = result;
                return ((input.Length - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(249108234355)
            
            //--TRIMMABLE-BOUNDARY-START(502511304819)
            static /*bool */ TrySetCacheControlValues(/*CacheControlHeaderValue*/ cc, /*List<NameValueHeaderValue>*/ nameValueList)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511304819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = 0; i < nameValueList.Count; i++)
                {
                    /*var*/ let nameValue = nameValueList.get_Item(i);
                    /*var*/ let name = nameValue.Name;
                    /*var*/ let success = true;
                    let $switchJumpState1;
                    $switchJumpStart1: while(true)
                    {
                        let $switch1 = $switchJumpState1 ?? (name.Length);
                        switch($switch1)
                        {
                            case 6:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.PublicString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._public, ($v) => cc._public = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 7:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MaxAgeString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.TimeSpan), () => cc._maxAge, ($v) => cc._maxAge = $v, null));
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.PrivateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetOptionalTokenList(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._private, ($v) => cc._private = $v, null), $.$ref(() => cc._privateHeaders, ($v) => cc._privateHeaders = $v, $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment)));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 8:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoCacheString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetOptionalTokenList(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._noCache, ($v) => cc._noCache = $v, null), $.$ref(() => cc._noCacheHeaders, ($v) => cc._noCacheHeaders = $v, $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment)));
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoStoreString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._noStore, ($v) => cc._noStore = $v, null));
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.SharedMaxAgeString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.TimeSpan), () => cc._sharedMaxAge, ($v) => cc._sharedMaxAge = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 9:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MaxStaleString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = (($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(nameValue.Value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null))) || $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.TimeSpan), () => cc._maxStaleLimit, ($v) => cc._maxStaleLimit = $v, null)));
                                if (success)
                                {
                                    cc._maxStale = true;
                                }
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MinFreshString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.TimeSpan), () => cc._minFresh, ($v) => cc._minFresh = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 12:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoTransformString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._noTransform, ($v) => cc._noTransform = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 14:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.OnlyIfCachedString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._onlyIfCached, ($v) => cc._onlyIfCached = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 15:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MustRevalidateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._mustRevalidate, ($v) => cc._mustRevalidate = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 16:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.ProxyRevalidateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._proxyRevalidate, ($v) => cc._proxyRevalidate = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            default:
                            cc.Extensions.System$Collections$Generic$ICollection$$$Add(nameValue, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                            break;
                        }
                        break;
                    }
                    if (!success)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(502511304819)
            
            //--TRIMMABLE-BOUNDARY-START(515396206707)
            static /*bool */ TrySetTokenOnlyValue(/*NameValueHeaderValue*/ nameValue, /*ref bool*/ boolField)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396206707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(nameValue.Value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    return false;
                }
                boolField.$v = true;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(515396206707)
            
            //--TRIMMABLE-BOUNDARY-START(506806272115)
            static /*bool */ TrySetOptionalTokenList(/*NameValueHeaderValue*/ nameValue, /*ref bool*/ boolField, /*ref ICollection<StringSegment>?*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506806272115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(nameValue.Value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    boolField.$v = true;
                    return true;
                }
                /*var*/ let valueString = nameValue.Value;
                if ((valueString.Length < 3) || (valueString.get_Item(0) !== /*\"*/ 34) || (valueString.get_Item(((valueString.Length - 1) | 0)) !== /*\"*/ 34))
                {
                    return false;
                }
                /*var*/ let current = 1;
                /*var*/ let maxLength = ((valueString.Length - 1) | 0);
                /*var*/ let originalValueCount = destination.$v === null ? 0 : destination.$v.System$Collections$Generic$ICollection$$$Count;
                while(current < maxLength)
                {
                    /*var*/ let separatorFound;
                    current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(valueString, current, true, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                    if (current === maxLength)
                    {
                        break;
                    }
                    /*var*/ let tokenLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(valueString, current);
                    if (tokenLength === 0)
                    {
                        return false;
                    }
                    if (destination.$v === null)
                    {
                        destination.$v = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                    }
                    destination.$v.System$Collections$Generic$ICollection$$$Add(valueString.Subsegment(current, tokenLength), [$.$mep.Microsoft.Extensions.Primitives.StringSegment]);
                    current = ((current + tokenLength) | 0);
                }
                if ((destination.$v !== null) && (destination.$v.System$Collections$Generic$ICollection$$$Count > originalValueCount))
                {
                    boolField.$v = true;
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(506806272115)
            
            //--TRIMMABLE-BOUNDARY-START(511101239411)
            static /*bool */ TrySetTimeSpan(/*NameValueHeaderValue*/ nameValue, /*ref TimeSpan?*/ timeSpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101239411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(nameValue.Value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    return false;
                }
                /*int*/ let seconds;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt32(nameValue.Value, $.$ref(() => seconds, ($v) => seconds = $v, $.$$.System.Int32)))
                {
                    return false;
                }
                timeSpan.$v = new $.$$.System.TimeSpan().$ctor$6(0, 0, seconds);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(511101239411)
            
            //--TRIMMABLE-BOUNDARY-START(81604509811)
            static /*void */ AppendValueIfRequired(/*StringBuilder*/ sb, /*bool*/ appendValue, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604509811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (appendValue)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604509811)
            
            //--TRIMMABLE-BOUNDARY-START(90194444403)
            static /*void */ AppendValueWithSeparatorIfRequired(/*StringBuilder*/ sb, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194444403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sb.Length > 0)
                {
                    sb.Append$19(", ");
                }
                sb.Append$19(value);
            }
            //--TRIMMABLE-BOUNDARY-END(90194444403)
            
            //--TRIMMABLE-BOUNDARY-START(85899477107)
            static /*void */ AppendValues(/*StringBuilder*/ sb, /*IEnumerable<StringSegment>*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899477107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let first = true;
                var $en2 = values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var value = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (first)
                        {
                            first = false;
                        }
                        else 
                        {
                            sb.Append$19(", ");
                        }
                        sb.Append$15(value.AsSpan());
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899477107)
            
            //--TRIMMABLE-BOUNDARY-START(94489411699)
            static /*void */ CheckIsValidToken(/*StringSegment*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489411699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(item, "item");
            }
            //--TRIMMABLE-BOUNDARY-END(94489411699)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590065779)
                this._maxAge = null;
                //--TRIMMABLE-BOUNDARY-END(8590065779)
                
                //--TRIMMABLE-BOUNDARY-START(68719607923)
                this._sharedMaxAge = null;
                //--TRIMMABLE-BOUNDARY-END(68719607923)
                
                //--TRIMMABLE-BOUNDARY-START(17180000371)
                this._maxStaleLimit = null;
                //--TRIMMABLE-BOUNDARY-END(17180000371)
                
                //--TRIMMABLE-BOUNDARY-START(21474967667)
                this._minFresh = null;
                //--TRIMMABLE-BOUNDARY-END(21474967667)
                
            }
            //--TRIMMABLE-BOUNDARY-START(73014575219)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(369367318643)
                    this.PublicString = "public";
                    //--TRIMMABLE-BOUNDARY-END(369367318643)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187449459)
                    this.PrivateString = "private";
                    //--TRIMMABLE-BOUNDARY-END(352187449459)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993136243)
                    this.MaxAgeString = "max-age";
                    //--TRIMMABLE-BOUNDARY-END(261993136243)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626402931)
                    this.SharedMaxAgeString = "s-maxage";
                    //--TRIMMABLE-BOUNDARY-END(489626402931)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942809203)
                    this.NoCacheString = "no-cache";
                    //--TRIMMABLE-BOUNDARY-END(304942809203)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532743795)
                    this.NoStoreString = "no-store";
                    //--TRIMMABLE-BOUNDARY-END(313532743795)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878038131)
                    this.MaxStaleString = "max-stale";
                    //--TRIMMABLE-BOUNDARY-END(274878038131)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283467972723)
                    this.MinFreshString = "min-fresh";
                    //--TRIMMABLE-BOUNDARY-END(283467972723)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122678387)
                    this.NoTransformString = "no-transform";
                    //--TRIMMABLE-BOUNDARY-END(322122678387)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712612979)
                    this.OnlyIfCachedString = "only-if-cached";
                    //--TRIMMABLE-BOUNDARY-END(330712612979)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057907315)
                    this.MustRevalidateString = "must-revalidate";
                    //--TRIMMABLE-BOUNDARY-END(292057907315)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777384051)
                    this.ProxyRevalidateString = "proxy-revalidate";
                    //--TRIMMABLE-BOUNDARY-END(360777384051)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302547571)
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.GetCacheControlLength));
                    //--TRIMMABLE-BOUNDARY-END(339302547571)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784378995)
                    this.CheckIsValidTokenAction = new ($.$$.System.Action$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.CheckIsValidToken);
                    //--TRIMMABLE-BOUNDARY-END(98784378995)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014575219)
            
            static $h = 131187;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(296352874611),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503855731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 420906926195,
        "f": 83886081
      },
      "n": "NoCache",
      "d": 131187,
      "h": 296352874611,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296352874611),
//--TRIMMABLE-BOUNDARY-START(300647841907),
    {
      "p": $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093790323,
        "f": 50331649
      },
      "n": "NoCacheHeaders",
      "d": 131187,
      "h": 300647841907,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300647841907),
//--TRIMMABLE-BOUNDARY-START(309237776499),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683724915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429496860787,
        "f": 83886081
      },
      "n": "NoStore",
      "d": 131187,
      "h": 309237776499,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309237776499),
//--TRIMMABLE-BOUNDARY-START(257698168947),
    {
      "p": $.$typeNullable($.$$.System.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554182771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377957253235,
        "f": 83886081
      },
      "n": "MaxAge",
      "d": 131187,
      "h": 257698168947,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698168947),
//--TRIMMABLE-BOUNDARY-START(485331435635),
    {
      "p": $.$typeNullable($.$$.System.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813267059,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 481036468339,
        "f": 83886081
      },
      "n": "SharedMaxAge",
      "d": 131187,
      "h": 485331435635,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(485331435635),
//--TRIMMABLE-BOUNDARY-START(266288103539),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144117363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386547187827,
        "f": 83886081
      },
      "n": "MaxStale",
      "d": 131187,
      "h": 266288103539,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266288103539),
//--TRIMMABLE-BOUNDARY-START(270583070835),
    {
      "p": $.$typeNullable($.$$.System.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734051955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 395137122419,
        "f": 83886081
      },
      "n": "MaxStaleLimit",
      "d": 131187,
      "h": 270583070835,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583070835),
//--TRIMMABLE-BOUNDARY-START(279173005427),
    {
      "p": $.$typeNullable($.$$.System.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150323986547,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 403727057011,
        "f": 83886081
      },
      "n": "MinFresh",
      "d": 131187,
      "h": 279173005427,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173005427),
//--TRIMMABLE-BOUNDARY-START(317827711091),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273659507,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 438086795379,
        "f": 83886081
      },
      "n": "NoTransform",
      "d": 131187,
      "h": 317827711091,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317827711091),
//--TRIMMABLE-BOUNDARY-START(326417645683),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863594099,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 446676729971,
        "f": 83886081
      },
      "n": "OnlyIfCached",
      "d": 131187,
      "h": 326417645683,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326417645683),
//--TRIMMABLE-BOUNDARY-START(365072351347),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223332467,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 472446533747,
        "f": 83886081
      },
      "n": "Public",
      "d": 131187,
      "h": 365072351347,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(365072351347),
//--TRIMMABLE-BOUNDARY-START(343597514867),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453528691,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 455266664563,
        "f": 83886081
      },
      "n": "Private",
      "d": 131187,
      "h": 343597514867,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343597514867),
//--TRIMMABLE-BOUNDARY-START(347892482163),
    {
      "p": $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043463283,
        "f": 50331649
      },
      "n": "PrivateHeaders",
      "d": 131187,
      "h": 347892482163,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(347892482163),
//--TRIMMABLE-BOUNDARY-START(287762940019),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913921139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 412316991603,
        "f": 83886081
      },
      "n": "MustRevalidate",
      "d": 131187,
      "h": 287762940019,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287762940019),
//--TRIMMABLE-BOUNDARY-START(356482416755),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633397875,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 463856599155,
        "f": 83886081
      },
      "n": "ProxyRevalidate",
      "d": 131187,
      "h": 356482416755,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356482416755),
//--TRIMMABLE-BOUNDARY-START(107374313587),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964248179,
        "f": 50331649
      },
      "n": "Extensions",
      "d": 131187,
      "h": 107374313587,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374313587)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 493921370227, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 131187,
      "h": 493921370227,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 493921370227, 330712612865),
//--TRIMMABLE-BOUNDARY-START(ALL, 103079346291, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 131187,
      "h": 103079346291,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 103079346291, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 253403201651, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 131187,
      "h": 253403201651,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 253403201651, 184683724801),
//--TRIMMABLE-BOUNDARY-START(335007580275),
    {
      "r": 131187,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 131187,
      "h": 335007580275,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(335007580275),
//--TRIMMABLE-BOUNDARY-START(498216337523),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 131187,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 131187,
      "h": 498216337523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(498216337523),
//--TRIMMABLE-BOUNDARY-START(249108234355),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 131187,
          "f": 2
        }
      ],
      "n": "GetCacheControlLength",
      "d": 131187,
      "h": 249108234355,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(249108234355),
//--TRIMMABLE-BOUNDARY-START(502511304819),
    {
      "r": 262145,
      "p": [
        {
          "n": "cc",
          "p": 131187
        },
        {
          "n": "nameValueList",
          "p": $.$$.System.Collections.Generic.List$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h
        }
      ],
      "n": "TrySetCacheControlValues",
      "d": 131187,
      "h": 502511304819,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(502511304819),
//--TRIMMABLE-BOUNDARY-START(515396206707),
    {
      "r": 262145,
      "p": [
        {
          "n": "nameValue",
          "p": 1310835
        },
        {
          "n": "boolField",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "TrySetTokenOnlyValue",
      "d": 131187,
      "h": 515396206707,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(515396206707),
//--TRIMMABLE-BOUNDARY-START(506806272115),
    {
      "r": 262145,
      "p": [
        {
          "n": "nameValue",
          "p": 1310835
        },
        {
          "n": "boolField",
          "p": 262145,
          "f": 4
        },
        {
          "n": "destination",
          "p": $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
          "f": 4
        }
      ],
      "n": "TrySetOptionalTokenList",
      "d": 131187,
      "h": 506806272115,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(506806272115),
//--TRIMMABLE-BOUNDARY-START(511101239411),
    {
      "r": 262145,
      "p": [
        {
          "n": "nameValue",
          "p": 1310835
        },
        {
          "n": "timeSpan",
          "p": $.$typeNullable($.$$.System.TimeSpan).$h,
          "f": 4
        }
      ],
      "n": "TrySetTimeSpan",
      "d": 131187,
      "h": 511101239411,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(511101239411),
//--TRIMMABLE-BOUNDARY-START(81604509811),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 166920193
        },
        {
          "n": "appendValue",
          "p": 262145
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AppendValueIfRequired",
      "d": 131187,
      "h": 81604509811,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604509811),
//--TRIMMABLE-BOUNDARY-START(90194444403),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 166920193
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AppendValueWithSeparatorIfRequired",
      "d": 131187,
      "h": 90194444403,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90194444403),
//--TRIMMABLE-BOUNDARY-START(85899477107),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 166920193
        },
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h
        }
      ],
      "n": "AppendValues",
      "d": 131187,
      "h": 85899477107,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899477107),
//--TRIMMABLE-BOUNDARY-START(94489411699),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": 852053
        }
      ],
      "n": "CheckIsValidToken",
      "d": 131187,
      "h": 94489411699,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489411699)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(369367318643),
    {
      "t": 1310721,
      "n": "PublicString",
      "d": 131187,
      "h": 369367318643,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369367318643),
//--TRIMMABLE-BOUNDARY-START(352187449459),
    {
      "t": 1310721,
      "n": "PrivateString",
      "d": 131187,
      "h": 352187449459,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352187449459),
//--TRIMMABLE-BOUNDARY-START(261993136243),
    {
      "t": 1310721,
      "n": "MaxAgeString",
      "d": 131187,
      "h": 261993136243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993136243),
//--TRIMMABLE-BOUNDARY-START(489626402931),
    {
      "t": 1310721,
      "n": "SharedMaxAgeString",
      "d": 131187,
      "h": 489626402931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(489626402931),
//--TRIMMABLE-BOUNDARY-START(304942809203),
    {
      "t": 1310721,
      "n": "NoCacheString",
      "d": 131187,
      "h": 304942809203,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304942809203),
//--TRIMMABLE-BOUNDARY-START(313532743795),
    {
      "t": 1310721,
      "n": "NoStoreString",
      "d": 131187,
      "h": 313532743795,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313532743795),
//--TRIMMABLE-BOUNDARY-START(274878038131),
    {
      "t": 1310721,
      "n": "MaxStaleString",
      "d": 131187,
      "h": 274878038131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274878038131),
//--TRIMMABLE-BOUNDARY-START(283467972723),
    {
      "t": 1310721,
      "n": "MinFreshString",
      "d": 131187,
      "h": 283467972723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283467972723),
//--TRIMMABLE-BOUNDARY-START(322122678387),
    {
      "t": 1310721,
      "n": "NoTransformString",
      "d": 131187,
      "h": 322122678387,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322122678387),
//--TRIMMABLE-BOUNDARY-START(330712612979),
    {
      "t": 1310721,
      "n": "OnlyIfCachedString",
      "d": 131187,
      "h": 330712612979,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330712612979),
//--TRIMMABLE-BOUNDARY-START(292057907315),
    {
      "t": 1310721,
      "n": "MustRevalidateString",
      "d": 131187,
      "h": 292057907315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292057907315),
//--TRIMMABLE-BOUNDARY-START(360777384051),
    {
      "t": 1310721,
      "n": "ProxyRevalidateString",
      "d": 131187,
      "h": 360777384051,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360777384051),
//--TRIMMABLE-BOUNDARY-START(339302547571),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue).$h,
      "n": "Parser",
      "d": 131187,
      "h": 339302547571,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(339302547571),
//--TRIMMABLE-BOUNDARY-START(98784378995),
    {
      "t": $.$$.System.Action$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
      "n": "CheckIsValidTokenAction",
      "d": 131187,
      "h": 98784378995,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(98784378995),
//--TRIMMABLE-BOUNDARY-START(30064902259),
    {
      "t": 262145,
      "n": "_noCache",
      "d": 131187,
      "h": 30064902259,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064902259),
//--TRIMMABLE-BOUNDARY-START(34359869555),
    {
      "t": $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
      "n": "_noCacheHeaders",
      "d": 131187,
      "h": 34359869555,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359869555),
//--TRIMMABLE-BOUNDARY-START(38654836851),
    {
      "t": 262145,
      "n": "_noStore",
      "d": 131187,
      "h": 38654836851,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654836851),
//--TRIMMABLE-BOUNDARY-START(8590065779),
    {
      "t": $.$typeNullable($.$$.System.TimeSpan).$h,
      "n": "_maxAge",
      "d": 131187,
      "h": 8590065779,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065779),
//--TRIMMABLE-BOUNDARY-START(68719607923),
    {
      "t": $.$typeNullable($.$$.System.TimeSpan).$h,
      "n": "_sharedMaxAge",
      "d": 131187,
      "h": 68719607923,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68719607923),
//--TRIMMABLE-BOUNDARY-START(12885033075),
    {
      "t": 262145,
      "n": "_maxStale",
      "d": 131187,
      "h": 12885033075,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033075),
//--TRIMMABLE-BOUNDARY-START(17180000371),
    {
      "t": $.$typeNullable($.$$.System.TimeSpan).$h,
      "n": "_maxStaleLimit",
      "d": 131187,
      "h": 17180000371,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180000371),
//--TRIMMABLE-BOUNDARY-START(21474967667),
    {
      "t": $.$typeNullable($.$$.System.TimeSpan).$h,
      "n": "_minFresh",
      "d": 131187,
      "h": 21474967667,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474967667),
//--TRIMMABLE-BOUNDARY-START(42949804147),
    {
      "t": 262145,
      "n": "_noTransform",
      "d": 131187,
      "h": 42949804147,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949804147),
//--TRIMMABLE-BOUNDARY-START(47244771443),
    {
      "t": 262145,
      "n": "_onlyIfCached",
      "d": 131187,
      "h": 47244771443,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47244771443),
//--TRIMMABLE-BOUNDARY-START(64424640627),
    {
      "t": 262145,
      "n": "_public",
      "d": 131187,
      "h": 64424640627,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64424640627),
//--TRIMMABLE-BOUNDARY-START(51539738739),
    {
      "t": 262145,
      "n": "_private",
      "d": 131187,
      "h": 51539738739,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51539738739),
//--TRIMMABLE-BOUNDARY-START(55834706035),
    {
      "t": $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
      "n": "_privateHeaders",
      "d": 131187,
      "h": 55834706035,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834706035),
//--TRIMMABLE-BOUNDARY-START(25769934963),
    {
      "t": 262145,
      "n": "_mustRevalidate",
      "d": 131187,
      "h": 25769934963,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769934963),
//--TRIMMABLE-BOUNDARY-START(60129673331),
    {
      "t": 262145,
      "n": "_proxyRevalidate",
      "d": 131187,
      "h": 60129673331,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60129673331),
//--TRIMMABLE-BOUNDARY-START(4295098483),
    {
      "t": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "n": "_extensions",
      "d": 131187,
      "h": 4295098483,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(77309542515),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131187,
      "h": 77309542515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309542515)
  ],
  "h": 131187
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `CacheControlHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131187)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179763)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue", ($self) => class MediaTypeHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655885427)
            /*string*/ static BoundaryString = null;
            //--TRIMMABLE-BOUNDARY-END(38655885427)
            
            //--TRIMMABLE-BOUNDARY-START(47245820019)
            /*string*/ static CharsetString = null;
            //--TRIMMABLE-BOUNDARY-END(47245820019)
            
            //--TRIMMABLE-BOUNDARY-START(231929413747)
            /*string*/ static MatchesAllString = null;
            //--TRIMMABLE-BOUNDARY-END(231929413747)
            
            //--TRIMMABLE-BOUNDARY-START(343598563443)
            /*string*/ static QualityString = null;
            //--TRIMMABLE-BOUNDARY-END(343598563443)
            
            //--TRIMMABLE-BOUNDARY-START(429497909363)
            /*string*/ static WildcardString = null;
            //--TRIMMABLE-BOUNDARY-END(429497909363)
            
            //--TRIMMABLE-BOUNDARY-START(77310591091)
            /*char*/ static ForwardSlashCharacter = /*/*/ 47;
            //--TRIMMABLE-BOUNDARY-END(77310591091)
            
            //--TRIMMABLE-BOUNDARY-START(326418694259)
            /*char*/ static PeriodCharacter = /*.*/ 46;
            //--TRIMMABLE-BOUNDARY-END(326418694259)
            
            //--TRIMMABLE-BOUNDARY-START(335008628851)
            /*char*/ static PlusCharacter = /*+*/ 43;
            //--TRIMMABLE-BOUNDARY-END(335008628851)
            
            //--TRIMMABLE-BOUNDARY-START(330713661555)
            /*char[]*/ static PeriodCharacterArray = null;
            //--TRIMMABLE-BOUNDARY-END(330713661555)
            
            //--TRIMMABLE-BOUNDARY-START(390843203699)
            /*HttpHeaderParser<MediaTypeHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(390843203699)
            
            //--TRIMMABLE-BOUNDARY-START(304943857779)
            /*HttpHeaderParser<MediaTypeHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(304943857779)
            
            //--TRIMMABLE-BOUNDARY-START(12886081651)
            /*ObjectCollection<NameValueHeaderValue>?*/ _parameters = null;
            //--TRIMMABLE-BOUNDARY-END(12886081651)
            
            //--TRIMMABLE-BOUNDARY-START(8591114355)
            /*StringSegment*/ _mediaType;
            //--TRIMMABLE-BOUNDARY-END(8591114355)
            
            //--TRIMMABLE-BOUNDARY-START(4296147059)
            /*bool*/ _isReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(4296147059)
            
            //--TRIMMABLE-BOUNDARY-START(21476016243)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476016243);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016243)
            
            //--TRIMMABLE-BOUNDARY-START(25770983539)
            $ctor$3(/*StringSegment*/ mediaType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770983539);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.CheckMediaTypeFormat(mediaType, "mediaType");
                    this._mediaType = mediaType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983539)
            
            //--TRIMMABLE-BOUNDARY-START(30065950835)
            $ctor$2(/*StringSegment*/ mediaType, /*double*/ quality)
            {
                this.$ctor$3(mediaType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065950835);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Quality = quality;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065950835)
            
            //--TRIMMABLE-BOUNDARY-START(42950852723)
            /*StringSegment */ get Charset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490460275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("charset"/*CharsetString*/))?.Value ?? null) ?? new $.$mep.Microsoft.Extensions.Primitives.StringSegment();
            }
            /*StringSegment */ set Charset(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778432627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                /*var*/ let charsetParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("charset"/*CharsetString*/));
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value))
                {
                    if (charsetParameter !== null)
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Remove(charsetParameter, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
                else 
                {
                    if (charsetParameter !== null)
                    {
                        charsetParameter.Value = value;
                    }
                    else 
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("charset"/*CharsetString*/), value), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950852723)
            
            //--TRIMMABLE-BOUNDARY-START(64425689203)
            /*Encoding? */ get Encoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080394867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let charset = this.Charset;
                if (charset.HasValue && !$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(charset))
                {
                    try
                    {
                        return $.$$.System.Text.Encoding.GetEncoding$3(charset.Value);
                    }
                    catch($e)
                    {
                    }
                }
                return null;
            }
            /*Encoding? */ set Encoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368367219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                if (value === null)
                {
                    this.Charset = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                }
                else 
                {
                    this.Charset = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(value.WebName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425689203)
            
            //--TRIMMABLE-BOUNDARY-START(34360918131)
            /*StringSegment */ get Boundary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900525683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/))?.Value ?? null) ?? $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            /*StringSegment */ set Boundary(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188498035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                /*var*/ let boundaryParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/));
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value))
                {
                    if (boundaryParameter !== null)
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Remove(boundaryParameter, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
                else 
                {
                    if (boundaryParameter !== null)
                    {
                        boundaryParameter.Value = value;
                    }
                    else 
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/), value), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360918131)
            
            //--TRIMMABLE-BOUNDARY-START(309238825075)
            /*IList<NameValueHeaderValue> */ get Parameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209937011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._parameters === null)
                {
                    if (this.IsReadOnly)
                    {
                        this._parameters = $.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).EmptyReadOnlyCollection;
                    }
                    else 
                    {
                        this._parameters = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3();
                    }
                }
                return this._parameters;
            }
            //--TRIMMABLE-BOUNDARY-END(309238825075)
            
            //--TRIMMABLE-BOUNDARY-START(339303596147)
            /*double? */ get Quality()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799871603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetQuality(this._parameters);
            }
            /*double? */ set Quality(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548236403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.SetQuality(this.Parameters, value);
            }
            //--TRIMMABLE-BOUNDARY-END(339303596147)
            
            //--TRIMMABLE-BOUNDARY-START(300648890483)
            /*StringSegment */ get MediaType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620002419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mediaType;
            }
            /*StringSegment */ set MediaType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958301811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.CheckMediaTypeFormat(value, "value");
                this._mediaType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(300648890483)
            
            //--TRIMMABLE-BOUNDARY-START(425202942067)
            /*StringSegment */ get Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159609971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mediaType.Subsegment(0, this._mediaType.IndexOf$2(/*/*/ 47));
            }
            //--TRIMMABLE-BOUNDARY-END(425202942067)
            
            //--TRIMMABLE-BOUNDARY-START(395138170995)
            /*StringSegment */ get SubType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389806195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mediaType.Subsegment$1(((this._mediaType.IndexOf$2(/*/*/ 47) + 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(395138170995)
            
            //--TRIMMABLE-BOUNDARY-START(399433138291)
            /*StringSegment */ get SubTypeWithoutSuffix()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979740787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let subType = this.SubType;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    return subType;
                }
                else 
                {
                    return subType.Subsegment(0, startOfSuffix);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(399433138291)
            
            //--TRIMMABLE-BOUNDARY-START(403728105587)
            /*StringSegment */ get Suffix()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569675379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let subType = this.SubType;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    return $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                }
                else 
                {
                    return subType.Subsegment$1(((startOfSuffix + 1) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(403728105587)
            
            //--TRIMMABLE-BOUNDARY-START(73015623795)
            /*IEnumerable<StringSegment> */ get Facets()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670329459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubTypeWithoutSuffix.Split($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.PeriodCharacterArray);
            }
            //--TRIMMABLE-BOUNDARY-END(73015623795)
            
            //--TRIMMABLE-BOUNDARY-START(244814315635)
            /*bool */ get MatchesAllTypes()
            {
                return this.MediaType.Equals$2("*/*"/*MatchesAllString*/, 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(244814315635)
            
            //--TRIMMABLE-BOUNDARY-START(236224381043)
            /*bool */ get MatchesAllSubTypes()
            {
                return this.SubType.Equals$2("*"/*WildcardString*/, 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(236224381043)
            
            //--TRIMMABLE-BOUNDARY-START(240519348339)
            /*bool */ get MatchesAllSubTypesWithoutSuffix()
            {
                return this.SubTypeWithoutSuffix.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(240519348339)
            
            //--TRIMMABLE-BOUNDARY-START(223339479155)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260264051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._isReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(223339479155)
            
            //--TRIMMABLE-BOUNDARY-START(227634446451)
            /*bool */ IsSubsetOf(/*MediaTypeHeaderValue*/ otherMediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634446451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (otherMediaType === null)
                {
                    return false;
                }
                return this.MatchesType$1(otherMediaType) && this.MatchesSubtype$1(otherMediaType) && this.MatchesParameters(otherMediaType);
            }
            //--TRIMMABLE-BOUNDARY-END(227634446451)
            
            //--TRIMMABLE-BOUNDARY-START(55835754611)
            /*MediaTypeHeaderValue */ Copy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835754611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue().$ctor$1();
                other._mediaType = this._mediaType;
                if (this._parameters !== null)
                {
                    other._parameters = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$5($.$sl.System.Linq.Enumerable.Select$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._parameters, new ($.$$.System.Func$$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor(this,  (/*item*/ item) =>
                    {
                        return item.Copy();
                    }, {
  "r": 1310835,
  "p": [
    {
      "n": "item",
      "p": 1310835
    }
  ],
  "n": "",
  "d": 1179763,
  "h": 0,
  "f": 17825794
})), false);
                }
                return other;
            }
            //--TRIMMABLE-BOUNDARY-END(55835754611)
            
            //--TRIMMABLE-BOUNDARY-START(60130721907)
            /*MediaTypeHeaderValue */ CopyAsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130721907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    return this;
                }
                /*var*/ let other = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue().$ctor$1();
                other._mediaType = this._mediaType;
                if (this._parameters !== null)
                {
                    other._parameters = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$5($.$sl.System.Linq.Enumerable.Select$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._parameters, new ($.$$.System.Func$$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor(this,  (/*item*/ item) =>
                    {
                        return item.CopyAsReadOnly();
                    }, {
  "r": 1310835,
  "p": [
    {
      "n": "item",
      "p": 1310835
    }
  ],
  "n": "",
  "d": 1179763,
  "h": 0,
  "f": 17825794
})), true);
                }
                other._isReadOnly = true;
                return other;
            }
            //--TRIMMABLE-BOUNDARY-END(60130721907)
            
            //--TRIMMABLE-BOUNDARY-START(257699217523)
            /*bool */ MatchesMediaType(/*StringSegment*/ otherMediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699217523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(otherMediaType))
                {
                    return false;
                }
                /*var*/ let mediaType;
                $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeExpressionLength(otherMediaType, 0, $.$ref(() => mediaType, ($v) => mediaType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                return this.MatchesType(mediaType) && this.MatchesSubtype(mediaType);
            }
            //--TRIMMABLE-BOUNDARY-END(257699217523)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 408023072883, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023072883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$1();
                builder.Append$15(this._mediaType.AsSpan());
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString$1(this._parameters, /*;*/ 59, true, builder);
                return $.$$.System.Text.StringBuilder.ToString.call(builder);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 408023072883, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 68720656499, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720656499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return this._mediaType.Equals$4(other._mediaType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._parameters, other._parameters);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 68720656499, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 210454577267, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454577267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._mediaType) ^ $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode$1(this._parameters);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 210454577267, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(313533792371)
            static /*MediaTypeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533792371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(313533792371)
            
            //--TRIMMABLE-BOUNDARY-START(412318040179)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out MediaTypeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318040179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(412318040179)
            
            //--TRIMMABLE-BOUNDARY-START(317828759667)
            static /*IList<MediaTypeHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828759667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(317828759667)
            
            //--TRIMMABLE-BOUNDARY-START(322123726963)
            static /*IList<MediaTypeHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123726963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(322123726963)
            
            //--TRIMMABLE-BOUNDARY-START(416613007475)
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<MediaTypeHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613007475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.MultipleValueParser.TryParseValues$1(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(416613007475)
            
            //--TRIMMABLE-BOUNDARY-START(420907974771)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<MediaTypeHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907974771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(420907974771)
            
            //--TRIMMABLE-BOUNDARY-START(219044511859)
            static /*int */ GetMediaTypeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out MediaTypeHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044511859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let mediaType;
                /*var*/ let mediaTypeLength = $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeExpressionLength(input, startIndex, $.$ref(() => mediaType, ($v) => mediaType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                if (mediaTypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + mediaTypeLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*MediaTypeHeaderValue?*/ let mediaTypeHeader;
                if ((current < input.Length) && (input.get_Item(current) === /*;*/ 59))
                {
                    mediaTypeHeader = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue().$ctor$1();
                    mediaTypeHeader._mediaType = mediaType;
                    current++;
                    /*var*/ let parameterLength = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueListLength(input, current, /*;*/ 59, mediaTypeHeader.Parameters);
                    parsedValue.$v = mediaTypeHeader;
                    return ((((current + parameterLength) | 0) - startIndex) | 0);
                }
                mediaTypeHeader = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue().$ctor$1();
                mediaTypeHeader._mediaType = mediaType;
                parsedValue.$v = mediaTypeHeader;
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(219044511859)
            
            //--TRIMMABLE-BOUNDARY-START(214749544563)
            static /*int */ GetMediaTypeExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringSegment*/ mediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749544563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                mediaType.$v = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                /*var*/ let typeLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (typeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + typeLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current >= input.Length) || (input.get_Item(current) !== /*/*/ 47))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let subtypeLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, current);
                if (subtypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let mediaTypeLength = ((((current + subtypeLength) | 0) - startIndex) | 0);
                if (((((typeLength + subtypeLength) | 0) + 1) | 0) === mediaTypeLength)
                {
                    mediaType.$v = input.Subsegment(startIndex, mediaTypeLength);
                }
                else 
                {
                    mediaType.$v = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Concat$7(input.AsSpan().Slice(startIndex, typeLength), $.$$.System.String.op_Implicit("/"), input.AsSpan().Slice(current, subtypeLength)));
                }
                return mediaTypeLength;
            }
            //--TRIMMABLE-BOUNDARY-END(214749544563)
            
            //--TRIMMABLE-BOUNDARY-START(51540787315)
            static /*void */ CheckMediaTypeFormat(/*StringSegment*/ mediaType, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540787315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(mediaType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                /*var*/ let tempMediaType;
                /*var*/ let mediaTypeLength = $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeExpressionLength(mediaType, 0, $.$ref(() => tempMediaType, ($v) => tempMediaType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                if ((mediaTypeLength === 0) || (tempMediaType.Length !== mediaType.Length))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "Invalid media type '{0}'.", mediaType));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540787315)
            
            //--TRIMMABLE-BOUNDARY-START(292058955891)
            /*bool */ MatchesType$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058955891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return set.MatchesAllTypes || set.Type.Equals$4(this.Type, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(292058955891)
            
            //--TRIMMABLE-BOUNDARY-START(296353923187)
            /*bool */ MatchesType(/*StringSegment*/ mediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353923187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = mediaType.Subsegment(0, mediaType.IndexOf$2(/*/*/ 47));
                return this.MatchesAllTypes || this.Type.Equals$4(type, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(296353923187)
            
            //--TRIMMABLE-BOUNDARY-START(266289152115)
            /*bool */ MatchesSubtype$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289152115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (set.MatchesAllSubTypes)
                {
                    return true;
                }
                if (set.Suffix.HasValue)
                {
                    if (this.Suffix.HasValue)
                    {
                        return this.MatchesSubtypeWithoutSuffix$1(set) && this.MatchesSubtypeSuffix$1(set);
                    }
                    else 
                    {
                        return false;
                    }
                }
                else 
                {
                    return this.MatchesEitherSubtypeOrSuffix$1(set);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266289152115)
            
            //--TRIMMABLE-BOUNDARY-START(270584119411)
            /*bool */ MatchesSubtype(/*StringSegment*/ mediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584119411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.MatchesAllSubTypes)
                {
                    return true;
                }
                /*var*/ let subType = mediaType.Subsegment$1(((mediaType.IndexOf$2(/*/*/ 47) + 1) | 0));
                /*StringSegment*/ let suffix;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    suffix = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                }
                else 
                {
                    suffix = subType.Subsegment$1(((startOfSuffix + 1) | 0));
                }
                if (this.Suffix.HasValue)
                {
                    if (suffix.HasValue)
                    {
                        return this.MatchesSubtypeWithoutSuffix(subType, startOfSuffix) && this.MatchesSubtypeSuffix(suffix);
                    }
                    else 
                    {
                        return false;
                    }
                }
                else 
                {
                    return this.MatchesEitherSubtypeOrSuffix(subType, suffix);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270584119411)
            
            //--TRIMMABLE-BOUNDARY-START(283469021299)
            /*bool */ MatchesSubtypeWithoutSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469021299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return set.MatchesAllSubTypesWithoutSuffix || set.SubTypeWithoutSuffix.Equals$4(this.SubTypeWithoutSuffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(283469021299)
            
            //--TRIMMABLE-BOUNDARY-START(287763988595)
            /*bool */ MatchesSubtypeWithoutSuffix(/*StringSegment*/ subType, /*int*/ startOfSuffix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763988595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StringSegment*/ let subTypeWithoutSuffix;
                if (startOfSuffix === -1)
                {
                    subTypeWithoutSuffix = subType;
                }
                else 
                {
                    subTypeWithoutSuffix = subType.Subsegment(0, startOfSuffix);
                }
                return this.SubTypeWithoutSuffix.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/) || this.SubTypeWithoutSuffix.Equals$4(subTypeWithoutSuffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(287763988595)
            
            //--TRIMMABLE-BOUNDARY-START(249109282931)
            /*bool */ MatchesEitherSubtypeOrSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109282931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return set.SubType.Equals$4(this.SubType, 5/*StringComparison.OrdinalIgnoreCase*/) || set.SubType.Equals$4(this.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(249109282931)
            
            //--TRIMMABLE-BOUNDARY-START(253404250227)
            /*bool */ MatchesEitherSubtypeOrSuffix(/*StringSegment*/ subType, /*StringSegment*/ suffix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404250227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return subType.Equals$4(this.SubType, 5/*StringComparison.OrdinalIgnoreCase*/) || this.SubType.Equals$4(suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(253404250227)
            
            //--TRIMMABLE-BOUNDARY-START(261994184819)
            /*bool */ MatchesParameters(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994184819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (set._parameters !== null && set._parameters.Count !== 0)
                {
                    var $en3 = set._parameters.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var parameter = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (parameter.Name.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                continue;
                            }
                            if (parameter.Name.Equals$2("q"/*QualityString*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                break;
                            }
                            /*var*/ let localParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, parameter.Name);
                            if (localParameter === null)
                            {
                                return false;
                            }
                            if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(parameter.Value, localParameter.Value, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(261994184819)
            
            //--TRIMMABLE-BOUNDARY-START(274879086707)
            /*bool */ MatchesSubtypeSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879086707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return set.Suffix.Equals$4(this.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(274879086707)
            
            //--TRIMMABLE-BOUNDARY-START(279174054003)
            /*bool */ MatchesSubtypeSuffix(/*StringSegment*/ suffix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174054003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Suffix.Equals$4(suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(279174054003)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591114355)
                this._mediaType = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591114355)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17181048947)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(38655885427)
                    this.BoundaryString = "boundary";
                    //--TRIMMABLE-BOUNDARY-END(38655885427)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245820019)
                    this.CharsetString = "charset";
                    //--TRIMMABLE-BOUNDARY-END(47245820019)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929413747)
                    this.MatchesAllString = "*/*";
                    //--TRIMMABLE-BOUNDARY-END(231929413747)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598563443)
                    this.QualityString = "q";
                    //--TRIMMABLE-BOUNDARY-END(343598563443)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429497909363)
                    this.WildcardString = "*";
                    //--TRIMMABLE-BOUNDARY-END(429497909363)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713661555)
                    this.PeriodCharacterArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.Char.$type, [ /*.*/ 46 ], null, null);
                    //--TRIMMABLE-BOUNDARY-END(330713661555)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390843203699)
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeLength));
                    //--TRIMMABLE-BOUNDARY-END(390843203699)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943857779)
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeLength));
                    //--TRIMMABLE-BOUNDARY-END(304943857779)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181048947)
            
            static $h = 1179763;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950852723),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490460275,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360778432627,
        "f": 83886081
      },
      "n": "Charset",
      "d": 1179763,
      "h": 42950852723,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950852723),
//--TRIMMABLE-BOUNDARY-START(64425689203),
    {
      "p": 165806081,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080394867,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369368367219,
        "f": 83886081
      },
      "n": "Encoding",
      "d": 1179763,
      "h": 64425689203,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425689203),
//--TRIMMABLE-BOUNDARY-START(34360918131),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900525683,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352188498035,
        "f": 83886081
      },
      "n": "Boundary",
      "d": 1179763,
      "h": 34360918131,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360918131),
//--TRIMMABLE-BOUNDARY-START(309238825075),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209937011,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 1179763,
      "h": 309238825075,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309238825075),
//--TRIMMABLE-BOUNDARY-START(339303596147),
    {
      "p": $.$typeNullable($.$$.System.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799871603,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386548236403,
        "f": 83886081
      },
      "n": "Quality",
      "d": 1179763,
      "h": 339303596147,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339303596147),
//--TRIMMABLE-BOUNDARY-START(300648890483),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620002419,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377958301811,
        "f": 83886081
      },
      "n": "MediaType",
      "d": 1179763,
      "h": 300648890483,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300648890483),
//--TRIMMABLE-BOUNDARY-START(425202942067),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159609971,
        "f": 50331649
      },
      "n": "Type",
      "d": 1179763,
      "h": 425202942067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(425202942067),
//--TRIMMABLE-BOUNDARY-START(395138170995),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389806195,
        "f": 50331649
      },
      "n": "SubType",
      "d": 1179763,
      "h": 395138170995,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(395138170995),
//--TRIMMABLE-BOUNDARY-START(399433138291),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979740787,
        "f": 50331649
      },
      "n": "SubTypeWithoutSuffix",
      "d": 1179763,
      "h": 399433138291,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399433138291),
//--TRIMMABLE-BOUNDARY-START(403728105587),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569675379,
        "f": 50331649
      },
      "n": "Suffix",
      "d": 1179763,
      "h": 403728105587,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403728105587),
//--TRIMMABLE-BOUNDARY-START(73015623795),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670329459,
        "f": 50331649
      },
      "n": "Facets",
      "d": 1179763,
      "h": 73015623795,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015623795),
//--TRIMMABLE-BOUNDARY-START(244814315635),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030067827,
        "f": 50331649
      },
      "n": "MatchesAllTypes",
      "d": 1179763,
      "h": 244814315635,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244814315635),
//--TRIMMABLE-BOUNDARY-START(236224381043),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850198643,
        "f": 50331649
      },
      "n": "MatchesAllSubTypes",
      "d": 1179763,
      "h": 236224381043,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224381043),
//--TRIMMABLE-BOUNDARY-START(240519348339),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440133235,
        "f": 50331649
      },
      "n": "MatchesAllSubTypesWithoutSuffix",
      "d": 1179763,
      "h": 240519348339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519348339),
//--TRIMMABLE-BOUNDARY-START(223339479155),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260264051,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1179763,
      "h": 223339479155,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223339479155)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(227634446451),
    {
      "r": 262145,
      "p": [
        {
          "n": "otherMediaType",
          "p": 1179763
        }
      ],
      "n": "IsSubsetOf",
      "d": 1179763,
      "h": 227634446451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227634446451),
//--TRIMMABLE-BOUNDARY-START(55835754611),
    {
      "r": 1179763,
      "n": "Copy",
      "d": 1179763,
      "h": 55835754611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835754611),
//--TRIMMABLE-BOUNDARY-START(60130721907),
    {
      "r": 1179763,
      "n": "CopyAsReadOnly",
      "d": 1179763,
      "h": 60130721907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130721907),
//--TRIMMABLE-BOUNDARY-START(257699217523),
    {
      "r": 262145,
      "p": [
        {
          "n": "otherMediaType",
          "p": 852053
        }
      ],
      "n": "MatchesMediaType",
      "d": 1179763,
      "h": 257699217523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257699217523),
//--TRIMMABLE-BOUNDARY-START(ALL, 408023072883, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1179763,
      "h": 408023072883,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 408023072883, 330712612865),
//--TRIMMABLE-BOUNDARY-START(ALL, 68720656499, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1179763,
      "h": 68720656499,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 68720656499, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 210454577267, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1179763,
      "h": 210454577267,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 210454577267, 184683724801),
//--TRIMMABLE-BOUNDARY-START(313533792371),
    {
      "r": 1179763,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1179763,
      "h": 313533792371,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313533792371),
//--TRIMMABLE-BOUNDARY-START(412318040179),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1179763,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1179763,
      "h": 412318040179,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(412318040179),
//--TRIMMABLE-BOUNDARY-START(317828759667),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseList",
      "d": 1179763,
      "h": 317828759667,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(317828759667),
//--TRIMMABLE-BOUNDARY-START(322123726963),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 1179763,
      "h": 322123726963,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(322123726963),
//--TRIMMABLE-BOUNDARY-START(416613007475),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 1179763,
      "h": 416613007475,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(416613007475),
//--TRIMMABLE-BOUNDARY-START(420907974771),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 1179763,
      "h": 420907974771,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(420907974771),
//--TRIMMABLE-BOUNDARY-START(219044511859),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1179763,
          "f": 2
        }
      ],
      "n": "GetMediaTypeLength",
      "d": 1179763,
      "h": 219044511859,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(219044511859),
//--TRIMMABLE-BOUNDARY-START(214749544563),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "mediaType",
          "p": 852053,
          "f": 2
        }
      ],
      "n": "GetMediaTypeExpressionLength",
      "d": 1179763,
      "h": 214749544563,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(214749544563),
//--TRIMMABLE-BOUNDARY-START(51540787315),
    {
      "r": 65537,
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckMediaTypeFormat",
      "d": 1179763,
      "h": 51540787315,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51540787315),
//--TRIMMABLE-BOUNDARY-START(292058955891),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179763
        }
      ],
      "n": "MatchesType",
      "o": "@$1",
      "d": 1179763,
      "h": 292058955891,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(292058955891),
//--TRIMMABLE-BOUNDARY-START(296353923187),
    {
      "r": 262145,
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        }
      ],
      "n": "MatchesType",
      "d": 1179763,
      "h": 296353923187,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(296353923187),
//--TRIMMABLE-BOUNDARY-START(266289152115),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179763
        }
      ],
      "n": "MatchesSubtype",
      "o": "@$1",
      "d": 1179763,
      "h": 266289152115,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(266289152115),
//--TRIMMABLE-BOUNDARY-START(270584119411),
    {
      "r": 262145,
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        }
      ],
      "n": "MatchesSubtype",
      "d": 1179763,
      "h": 270584119411,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(270584119411),
//--TRIMMABLE-BOUNDARY-START(283469021299),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179763
        }
      ],
      "n": "MatchesSubtypeWithoutSuffix",
      "o": "@$1",
      "d": 1179763,
      "h": 283469021299,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283469021299),
//--TRIMMABLE-BOUNDARY-START(287763988595),
    {
      "r": 262145,
      "p": [
        {
          "n": "subType",
          "p": 852053
        },
        {
          "n": "startOfSuffix",
          "p": 655361
        }
      ],
      "n": "MatchesSubtypeWithoutSuffix",
      "d": 1179763,
      "h": 287763988595,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(287763988595),
//--TRIMMABLE-BOUNDARY-START(249109282931),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179763
        }
      ],
      "n": "MatchesEitherSubtypeOrSuffix",
      "o": "@$1",
      "d": 1179763,
      "h": 249109282931,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249109282931),
//--TRIMMABLE-BOUNDARY-START(253404250227),
    {
      "r": 262145,
      "p": [
        {
          "n": "subType",
          "p": 852053
        },
        {
          "n": "suffix",
          "p": 852053
        }
      ],
      "n": "MatchesEitherSubtypeOrSuffix",
      "d": 1179763,
      "h": 253404250227,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253404250227),
//--TRIMMABLE-BOUNDARY-START(261994184819),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179763
        }
      ],
      "n": "MatchesParameters",
      "d": 1179763,
      "h": 261994184819,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261994184819),
//--TRIMMABLE-BOUNDARY-START(274879086707),
    {
      "r": 262145,
      "p": [
        {
          "n": "set",
          "p": 1179763
        }
      ],
      "n": "MatchesSubtypeSuffix",
      "o": "@$1",
      "d": 1179763,
      "h": 274879086707,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(274879086707),
//--TRIMMABLE-BOUNDARY-START(279174054003),
    {
      "r": 262145,
      "p": [
        {
          "n": "suffix",
          "p": 852053
        }
      ],
      "n": "MatchesSubtypeSuffix",
      "d": 1179763,
      "h": 279174054003,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279174054003)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655885427),
    {
      "t": 1310721,
      "n": "BoundaryString",
      "d": 1179763,
      "h": 38655885427,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655885427),
//--TRIMMABLE-BOUNDARY-START(47245820019),
    {
      "t": 1310721,
      "n": "CharsetString",
      "d": 1179763,
      "h": 47245820019,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245820019),
//--TRIMMABLE-BOUNDARY-START(231929413747),
    {
      "t": 1310721,
      "n": "MatchesAllString",
      "d": 1179763,
      "h": 231929413747,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(231929413747),
//--TRIMMABLE-BOUNDARY-START(343598563443),
    {
      "t": 1310721,
      "n": "QualityString",
      "d": 1179763,
      "h": 343598563443,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(343598563443),
//--TRIMMABLE-BOUNDARY-START(429497909363),
    {
      "t": 1310721,
      "n": "WildcardString",
      "d": 1179763,
      "h": 429497909363,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(429497909363),
//--TRIMMABLE-BOUNDARY-START(77310591091),
    {
      "t": 458753,
      "n": "ForwardSlashCharacter",
      "d": 1179763,
      "h": 77310591091,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310591091),
//--TRIMMABLE-BOUNDARY-START(326418694259),
    {
      "t": 458753,
      "n": "PeriodCharacter",
      "d": 1179763,
      "h": 326418694259,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(326418694259),
//--TRIMMABLE-BOUNDARY-START(335008628851),
    {
      "t": 458753,
      "n": "PlusCharacter",
      "d": 1179763,
      "h": 335008628851,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(335008628851),
//--TRIMMABLE-BOUNDARY-START(330713661555),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "PeriodCharacterArray",
      "d": 1179763,
      "h": 330713661555,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(330713661555),
//--TRIMMABLE-BOUNDARY-START(390843203699),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 1179763,
      "h": 390843203699,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(390843203699),
//--TRIMMABLE-BOUNDARY-START(304943857779),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 1179763,
      "h": 304943857779,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(304943857779),
//--TRIMMABLE-BOUNDARY-START(12886081651),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "n": "_parameters",
      "d": 1179763,
      "h": 12886081651,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081651),
//--TRIMMABLE-BOUNDARY-START(8591114355),
    {
      "t": 852053,
      "n": "_mediaType",
      "d": 1179763,
      "h": 8591114355,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114355),
//--TRIMMABLE-BOUNDARY-START(4296147059),
    {
      "t": 262145,
      "n": "_isReadOnly",
      "d": 1179763,
      "h": 4296147059,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476016243),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179763,
      "h": 21476016243,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476016243),
//--TRIMMABLE-BOUNDARY-START(25770983539),
    {
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179763,
      "h": 25770983539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770983539),
//--TRIMMABLE-BOUNDARY-START(30065950835),
    {
      "p": [
        {
          "n": "mediaType",
          "p": 852053
        },
        {
          "n": "quality",
          "p": 1179649
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179763,
      "h": 30065950835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065950835)
  ],
  "h": 1179763
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MediaTypeHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179763)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704051)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue", ($self) => class SetCookieHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(111670853747)
            /*string*/ static ExpiresToken = null;
            //--TRIMMABLE-BOUNDARY-END(111670853747)
            
            //--TRIMMABLE-BOUNDARY-START(227634970739)
            /*string*/ static MaxAgeToken = null;
            //--TRIMMABLE-BOUNDARY-END(227634970739)
            
            //--TRIMMABLE-BOUNDARY-START(85901049971)
            /*string*/ static DomainToken = null;
            //--TRIMMABLE-BOUNDARY-END(85901049971)
            
            //--TRIMMABLE-BOUNDARY-START(257699741811)
            /*string*/ static PathToken = null;
            //--TRIMMABLE-BOUNDARY-END(257699741811)
            
            //--TRIMMABLE-BOUNDARY-START(296354447475)
            /*string*/ static SecureToken = null;
            //--TRIMMABLE-BOUNDARY-END(296354447475)
            
            //--TRIMMABLE-BOUNDARY-START(287764512883)
            /*string*/ static SameSiteToken = null;
            //--TRIMMABLE-BOUNDARY-END(287764512883)
            
            //--TRIMMABLE-BOUNDARY-START(279174578291)
            /*string*/ static SameSiteNoneToken = null;
            //--TRIMMABLE-BOUNDARY-END(279174578291)
            
            //--TRIMMABLE-BOUNDARY-START(274879610995)
            /*string*/ static SameSiteLaxToken = null;
            //--TRIMMABLE-BOUNDARY-END(274879610995)
            
            //--TRIMMABLE-BOUNDARY-START(283469545587)
            /*string*/ static SameSiteStrictToken = null;
            //--TRIMMABLE-BOUNDARY-END(283469545587)
            
            //--TRIMMABLE-BOUNDARY-START(219045036147)
            /*string*/ static HttpOnlyToken = null;
            //--TRIMMABLE-BOUNDARY-END(219045036147)
            
            //--TRIMMABLE-BOUNDARY-START(300649414771)
            /*string*/ static SeparatorToken = null;
            //--TRIMMABLE-BOUNDARY-END(300649414771)
            
            //--TRIMMABLE-BOUNDARY-START(94490984563)
            /*string*/ static EqualsToken = null;
            //--TRIMMABLE-BOUNDARY-END(94490984563)
            
            //--TRIMMABLE-BOUNDARY-START(107375886451)
            /*int*/ static ExpiresDateLength = 29;
            //--TRIMMABLE-BOUNDARY-END(107375886451)
            
            //--TRIMMABLE-BOUNDARY-START(103080919155)
            /*string*/ static ExpiresDateFormat = null;
            //--TRIMMABLE-BOUNDARY-END(103080919155)
            
            //--TRIMMABLE-BOUNDARY-START(382253793395)
            /*HttpHeaderParser<SetCookieHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(382253793395)
            
            //--TRIMMABLE-BOUNDARY-START(231929938035)
            /*HttpHeaderParser<SetCookieHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(231929938035)
            
            //--TRIMMABLE-BOUNDARY-START(8591638643)
            /*StringSegment*/ _name;
            //--TRIMMABLE-BOUNDARY-END(8591638643)
            
            //--TRIMMABLE-BOUNDARY-START(12886605939)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(12886605939)
            
            //--TRIMMABLE-BOUNDARY-START(4296671347)
            /*List<StringSegment>?*/ _extensions = null;
            //--TRIMMABLE-BOUNDARY-END(4296671347)
            
            //--TRIMMABLE-BOUNDARY-START(21476540531)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476540531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476540531)
            
            //--TRIMMABLE-BOUNDARY-START(25771507827)
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771507827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771507827)
            
            //--TRIMMABLE-BOUNDARY-START(30066475123)
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066475123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("name");
                    }
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("value");
                    }
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066475123)
            
            //--TRIMMABLE-BOUNDARY-START(236224905331)
            /*StringSegment */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505428595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*StringSegment */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599087731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.CheckNameFormat(value, "value");
                this._name = value;
            }
            //--TRIMMABLE-BOUNDARY-END(236224905331)
            
            //--TRIMMABLE-BOUNDARY-START(403728629875)
            /*StringSegment */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865166963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958826099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.CheckValueFormat(value, "value");
                this._value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(403728629875)
            
            //--TRIMMABLE-BOUNDARY-START(98785951859)
            /*DateTimeOffset?*/ Expires = null;
            //--TRIMMABLE-BOUNDARY-END(98785951859)
            
            //--TRIMMABLE-BOUNDARY-START(223340003443)
            /*TimeSpan?*/ MaxAge = null;
            //--TRIMMABLE-BOUNDARY-END(223340003443)
            
            //--TRIMMABLE-BOUNDARY-START(81606082675)
            /*StringSegment*/ Domain;
            //--TRIMMABLE-BOUNDARY-END(81606082675)
            
            //--TRIMMABLE-BOUNDARY-START(253404774515)
            /*StringSegment*/ Path;
            //--TRIMMABLE-BOUNDARY-END(253404774515)
            
            //--TRIMMABLE-BOUNDARY-START(292059480179)
            /*bool*/ Secure = false;
            //--TRIMMABLE-BOUNDARY-END(292059480179)
            
            //--TRIMMABLE-BOUNDARY-START(270584643699)
            /*SameSiteMode*/ SameSite = 0;
            //--TRIMMABLE-BOUNDARY-END(270584643699)
            
            //--TRIMMABLE-BOUNDARY-START(214750068851)
            /*bool*/ HttpOnly = false;
            //--TRIMMABLE-BOUNDARY-END(214750068851)
            
            //--TRIMMABLE-BOUNDARY-START(115965821043)
            /*IList<StringSegment> */ get Extensions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735624819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._extensions ??= new ($.$$.System.Collections.Generic.List$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(115965821043)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 386548760691, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548760691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let length = ((((this._name.Length + "="/*EqualsToken*/.length) | 0) + this._value.Length) | 0);
                /*string?*/ let maxAge = null;
                /*string?*/ let sameSite = null;
                if ($.$$.System.Nullable$$($.$$.System.DateTimeOffset).HasValue$get.call(this.Expires))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "expires"/*ExpiresToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + 29/*ExpiresDateLength*/) | 0);
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this.MaxAge))
                {
                    maxAge = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatInt64($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this.MaxAge).TotalSeconds, $.$$.System.Int64));
                    length += (((((("; "/*SeparatorToken*/.length + "max-age"/*MaxAgeToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + maxAge.length) | 0);
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Domain, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "domain"/*DomainToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + this.Domain.Length) | 0);
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Path, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "path"/*PathToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + this.Path.Length) | 0);
                }
                if (this.Secure)
                {
                    length += (("; "/*SeparatorToken*/.length + "secure"/*SecureToken*/.length) | 0);
                }
                if (this.SameSite === 0/*SameSiteMode.None*/)
                {
                    sameSite = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteNoneToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                else if (this.SameSite === 1/*SameSiteMode.Lax*/)
                {
                    sameSite = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteLaxToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                else if (this.SameSite === 2/*SameSiteMode.Strict*/)
                {
                    sameSite = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteStrictToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                if (this.HttpOnly)
                {
                    length += (("; "/*SeparatorToken*/.length + "httponly"/*HttpOnlyToken*/.length) | 0);
                }
                if ($.$$.System.Int32.op_GreaterThan$1((this._extensions?.Count ?? null), 0))
                {
                    var $en3 = this._extensions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var extension = $en3.Current;
                        {
                            length += (("; "/*SeparatorToken*/.length + extension.Length) | 0);
                        }
                    }
                }
                return $.$$.System.String.Create$10($.$$.System.ValueTuple$$$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$$.System.String, $.$$.System.String), length, new ($.$$.System.ValueTuple$$$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$$.System.String, $.$$.System.String))().$ctor$3(this, maxAge, sameSite), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.ValueTuple$$$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$$.System.String, $.$$.System.String)))().$ctor(this,  (/*span*/ span, /*tuple*/ tuple) =>
                {
                    /*var*/ let  [ headerValue, maxAgeValue, sameSite ] = $.$destructure(tuple);
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$1(headerValue._name));
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$$.System.String.op_Implicit("="/*EqualsToken*/));
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$1(headerValue._value));
                    let expiresValue;
                    if ($.$is(headerValue.Expires, $.$$.System.DateTimeOffset, { set $v(v){ expiresValue = v; } }))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$$.System.String.op_Implicit("; "/*SeparatorToken*/));
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$$.System.String.op_Implicit("expires"/*ExpiresToken*/));
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$$.System.String.op_Implicit("="/*EqualsToken*/));
                        /*var*/ let charsWritten;
                        /*var*/ let formatted = expiresValue.TryFormat$1(span, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit("r"/*ExpiresDateFormat*/), $.$$.System.Globalization.CultureInfo.InvariantCulture);
                        span = span.Slice$1(charsWritten);
                        $.$$.System.Diagnostics.Debug.Assert$2(formatted, "formatted");
                    }
                    if ($.$$.System.String.op_Inequality(maxAgeValue, null))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(maxAgeValue));
                    }
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(headerValue.Domain, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("domain"/*DomainToken*/), headerValue.Domain);
                    }
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(headerValue.Path, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("path"/*PathToken*/), headerValue.Path);
                    }
                    if (headerValue.Secure)
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("secure"/*SecureToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                    }
                    if ($.$$.System.String.op_Inequality(sameSite, null))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(sameSite));
                    }
                    if (headerValue.HttpOnly)
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                    }
                    if ($.$$.System.Int32.op_GreaterThan$1((this._extensions?.Count ?? null), 0))
                    {
                        var $en4 = this._extensions.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var extension = $en4.Current;
                            {
                                $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), extension, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                            }
                        }
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "span",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "tuple",
      "p": $.$$.System.ValueTuple$$$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$$.System.String, $.$$.System.String).$h
    }
  ],
  "n": "",
  "d": 1704051,
  "h": 0,
  "f": 17825794
}));
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 386548760691, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(68721180787)
            static /*void */ AppendSegment$1(/*ref Span<char>*/ span, /*StringSegment*/ name, /*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721180787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append(span, $.$$.System.String.op_Implicit("; "/*SeparatorToken*/));
                $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append(span, name.AsSpan());
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append(span, $.$$.System.String.op_Implicit("="/*EqualsToken*/));
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append(span, value.AsSpan());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721180787)
            
            //--TRIMMABLE-BOUNDARY-START(64426213491)
            static /*void */ Append(/*ref Span<char>*/ span, /*ReadOnlySpan<char>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426213491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                other.CopyTo(span.$v);
                span.$v = span.$v.Slice$1(other.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(64426213491)
            
            //--TRIMMABLE-BOUNDARY-START(77311115379)
            /*void */ AppendToStringBuilder(/*StringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311115379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.Append$15(this._name.AsSpan());
                builder.Append$3(/*=*/ 61);
                builder.Append$15(this._value.AsSpan());
                if ($.$$.System.Nullable$$($.$$.System.DateTimeOffset).HasValue$get.call(this.Expires))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("expires"/*ExpiresToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatDate$1($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(this.Expires))));
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this.MaxAge))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatInt64($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this.MaxAge).TotalSeconds, $.$$.System.Int64))));
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Domain, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("domain"/*DomainToken*/), this.Domain);
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Path, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("path"/*PathToken*/), this.Path);
                }
                if (this.Secure)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("secure"/*SecureToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                }
                if (this.SameSite === 0/*SameSiteMode.None*/)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteNoneToken));
                }
                else if (this.SameSite === 1/*SameSiteMode.Lax*/)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteLaxToken));
                }
                else if (this.SameSite === 2/*SameSiteMode.Strict*/)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteStrictToken));
                }
                if (this.HttpOnly)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                }
                if ($.$$.System.Int32.op_GreaterThan$1((this._extensions?.Count ?? null), 0))
                {
                    var $en3 = this._extensions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var extension = $en3.Current;
                        {
                            $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, extension, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311115379)
            
            //--TRIMMABLE-BOUNDARY-START(73016148083)
            static /*void */ AppendSegment(/*StringBuilder*/ builder, /*StringSegment*/ name, /*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016148083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.Append$19("; ");
                builder.Append$15(name.AsSpan());
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    builder.Append$3(/*=*/ 61);
                    builder.Append$15(value.AsSpan());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016148083)
            
            //--TRIMMABLE-BOUNDARY-START(240519872627)
            static /*SetCookieHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519872627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(240519872627)
            
            //--TRIMMABLE-BOUNDARY-START(390843727987)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out SetCookieHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843727987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(390843727987)
            
            //--TRIMMABLE-BOUNDARY-START(244814839923)
            static /*IList<SetCookieHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814839923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(244814839923)
            
            //--TRIMMABLE-BOUNDARY-START(249109807219)
            static /*IList<SetCookieHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109807219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            //--TRIMMABLE-BOUNDARY-END(249109807219)
            
            //--TRIMMABLE-BOUNDARY-START(395138695283)
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<SetCookieHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138695283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.MultipleValueParser.TryParseValues$1(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(395138695283)
            
            //--TRIMMABLE-BOUNDARY-START(399433662579)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<SetCookieHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433662579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(399433662579)
            
            //--TRIMMABLE-BOUNDARY-START(210455101555)
            static /*int */ GetSetCookieLength(/*StringSegment*/ input, /*int*/ startIndex, /*out SetCookieHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455101555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                /*var*/ let offset = startIndex;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (offset >= input.Length))
                {
                    return 0;
                }
                /*var*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue().$ctor$1();
                /*var*/ let itemLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, offset);
                if (itemLength === 0)
                {
                    return 0;
                }
                result._name = input.Subsegment(offset, itemLength);
                offset += itemLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                {
                    return 0;
                }
                result._value = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetCookieValue(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32));
                while(offset < input.Length)
                {
                    if (input.get_Item(offset) === /*,*/ 44)
                    {
                        break;
                    }
                    if (input.get_Item(offset) !== /*;*/ 59)
                    {
                        return 0;
                    }
                    offset++;
                    offset += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, offset);
                    itemLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, offset);
                    if (itemLength === 0)
                    {
                        break;
                    }
                    /*var*/ let token = input.Subsegment(offset, itemLength);
                    offset += itemLength;
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("expires"/*ExpiresToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            return 0;
                        }
                        /*var*/ let dateString = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), false);
                        /*DateTimeOffset*/ let expirationDate;
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TryStringToDate(dateString, $.$ref(() => expirationDate, ($v) => expirationDate = $v, $.$$.System.DateTimeOffset)))
                        {
                            return 0;
                        }
                        result.Expires = expirationDate;
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            return 0;
                        }
                        /*var*/ let isNegative = false;
                        if (input.get_Item(offset) === /*-*/ 45)
                        {
                            isNegative = true;
                            offset++;
                        }
                        itemLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, offset, false);
                        if (itemLength === 0)
                        {
                            return 0;
                        }
                        /*var*/ let numberString = input.Subsegment(offset, itemLength);
                        /*long*/ let maxAge;
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(numberString, $.$ref(() => maxAge, ($v) => maxAge = $v, $.$$.System.Int64)))
                        {
                            return 0;
                        }
                        if (isNegative)
                        {
                            maxAge = -maxAge;
                        }
                        result.MaxAge = $.$$.System.TimeSpan.FromSeconds$2(maxAge);
                        offset += itemLength;
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("domain"/*DomainToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            return 0;
                        }
                        result.Domain = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), true);
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("path"/*PathToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            return 0;
                        }
                        result.Path = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), true);
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("secure"/*SecureToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        result.Secure = true;
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            result.SameSite = -1/*SameSiteMode.Unspecified*/;
                        }
                        else 
                        {
                            /*var*/ let enforcementMode = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), true);
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(enforcementMode, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteStrictToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 2/*SameSiteMode.Strict*/;
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(enforcementMode, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteLaxToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 1/*SameSiteMode.Lax*/;
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(enforcementMode, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteNoneToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 0/*SameSiteMode.None*/;
                            }
                            else 
                            {
                                result.SameSite = -1/*SameSiteMode.Unspecified*/;
                            }
                        }
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        result.HttpOnly = true;
                    }
                    else 
                    {
                        /*var*/ let tokenStart = ((offset - itemLength) | 0);
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), true);
                        result.Extensions.System$Collections$Generic$ICollection$$$Add(input.Subsegment(tokenStart, ((offset - tokenStart) | 0)), [$.$mep.Microsoft.Extensions.Primitives.StringSegment]);
                    }
                }
                parsedValue.$v = result;
                return ((offset - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(210455101555)
            
            //--TRIMMABLE-BOUNDARY-START(261994709107)
            static /*bool */ ReadEqualsSign(/*StringSegment*/ input, /*ref int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994709107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset.$v >= input.Length || input.get_Item(offset.$v) !== /*=*/ 61)
                {
                    return false;
                }
                offset.$v++;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(261994709107)
            
            //--TRIMMABLE-BOUNDARY-START(266289676403)
            static /*StringSegment */ ReadToSemicolonOrEnd(/*StringSegment*/ input, /*ref int*/ offset, /*bool*/ includeComma)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289676403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let end = input.IndexOf$1(/*;*/ 59, offset.$v);
                if (end < 0)
                {
                    if (includeComma)
                    {
                        end = input.IndexOf$1(/*,*/ 44, offset.$v);
                    }
                }
                else if (includeComma)
                {
                    /*var*/ let commaPosition = input.IndexOf$1(/*,*/ 44, offset.$v);
                    if (commaPosition >= 0 && commaPosition < end)
                    {
                        end = commaPosition;
                    }
                }
                if (end < 0)
                {
                    end = input.Length;
                }
                /*var*/ let itemLength = ((end - offset.$v) | 0);
                /*var*/ let result = input.Subsegment(offset.$v, itemLength);
                offset.$v += itemLength;
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(266289676403)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 90196017267, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196017267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._name, other._name, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.System.Nullable$$($.$$.System.DateTimeOffset).Equals$1.call(this.Expires, other.Expires) && $.$$.System.Nullable$$($.$$.System.TimeSpan).Equals$1.call(this.MaxAge, other.MaxAge) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Domain, other.Domain, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Path, other.Path, 5/*StringComparison.OrdinalIgnoreCase*/) && this.Secure === other.Secure && this.SameSite === other.SameSite && this.HttpOnly === other.HttpOnly && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections($.$mep.Microsoft.Extensions.Primitives.StringSegment, this._extensions, other._extensions, $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 90196017267, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 206160134259, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160134259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hash = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._name) ^ $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value) ^ ($.$$.System.Nullable$$($.$$.System.DateTimeOffset).HasValue$get.call(this.Expires) ? $.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetHashCode.call(this.Expires) : 0) ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this.MaxAge) ? $.$$.System.Nullable$$($.$$.System.TimeSpan).GetHashCode.call(this.MaxAge) : 0) ^ ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Domain, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)) ? $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Domain) : 0) ^ ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Path, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)) ? $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Path) : 0) ^ $.$$.System.Boolean.GetHashCode.call(this.Secure) ^ this.SameSite ^ $.$$.System.Boolean.GetHashCode.call(this.HttpOnly);
                if ($.$$.System.Int32.op_GreaterThan$1((this._extensions?.Count ?? null), 0))
                {
                    var $en3 = this._extensions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var extension = $en3.Current;
                        {
                            hash ^= $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(extension);
                        }
                    }
                }
                return hash;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 206160134259, 184683724801)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591638643)
                this._name = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591638643)
                
                //--TRIMMABLE-BOUNDARY-START(12886605939)
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(12886605939)
                
                this.Expires = null;
                this.MaxAge = null;
                this.Domain = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this.Path = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this.SameSite = -1;
            }
            //--TRIMMABLE-BOUNDARY-START(17181573235)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(111670853747)
                    this.ExpiresToken = "expires";
                    //--TRIMMABLE-BOUNDARY-END(111670853747)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227634970739)
                    this.MaxAgeToken = "max-age";
                    //--TRIMMABLE-BOUNDARY-END(227634970739)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85901049971)
                    this.DomainToken = "domain";
                    //--TRIMMABLE-BOUNDARY-END(85901049971)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257699741811)
                    this.PathToken = "path";
                    //--TRIMMABLE-BOUNDARY-END(257699741811)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296354447475)
                    this.SecureToken = "secure";
                    //--TRIMMABLE-BOUNDARY-END(296354447475)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287764512883)
                    this.SameSiteToken = "samesite";
                    //--TRIMMABLE-BOUNDARY-END(287764512883)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279174578291)
                    this.SameSiteNoneToken = $.$$.System.String.ToLowerInvariant.call("None");
                    //--TRIMMABLE-BOUNDARY-END(279174578291)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274879610995)
                    this.SameSiteLaxToken = $.$$.System.String.ToLowerInvariant.call("Lax");
                    //--TRIMMABLE-BOUNDARY-END(274879610995)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283469545587)
                    this.SameSiteStrictToken = $.$$.System.String.ToLowerInvariant.call("Strict");
                    //--TRIMMABLE-BOUNDARY-END(283469545587)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219045036147)
                    this.HttpOnlyToken = "httponly";
                    //--TRIMMABLE-BOUNDARY-END(219045036147)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300649414771)
                    this.SeparatorToken = "; ";
                    //--TRIMMABLE-BOUNDARY-END(300649414771)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490984563)
                    this.EqualsToken = "=";
                    //--TRIMMABLE-BOUNDARY-END(94490984563)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080919155)
                    this.ExpiresDateFormat = "r";
                    //--TRIMMABLE-BOUNDARY-END(103080919155)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(382253793395)
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.GetSetCookieLength));
                    //--TRIMMABLE-BOUNDARY-END(382253793395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929938035)
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.GetSetCookieLength));
                    //--TRIMMABLE-BOUNDARY-END(231929938035)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181573235)
            
            static $h = 1704051;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(236224905331),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505428595,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343599087731,
        "f": 83886081
      },
      "n": "Name",
      "d": 1704051,
      "h": 236224905331,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224905331),
//--TRIMMABLE-BOUNDARY-START(403728629875),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865166963,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377958826099,
        "f": 83886081
      },
      "n": "Value",
      "d": 1704051,
      "h": 403728629875,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403728629875),
//--TRIMMABLE-BOUNDARY-START(98785951859),
    {
      "p": $.$typeNullable($.$$.System.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145690227,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317829283955,
        "f": 83886081
      },
      "n": "Expires",
      "d": 1704051,
      "h": 98785951859,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785951859),
//--TRIMMABLE-BOUNDARY-START(223340003443),
    {
      "p": $.$typeNullable($.$$.System.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915494003,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335009153139,
        "f": 83886081
      },
      "n": "MaxAge",
      "d": 1704051,
      "h": 223340003443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223340003443),
//--TRIMMABLE-BOUNDARY-START(81606082675),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555755635,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309239349363,
        "f": 83886081
      },
      "n": "Domain",
      "d": 1704051,
      "h": 81606082675,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606082675),
//--TRIMMABLE-BOUNDARY-START(253404774515),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095363187,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352189022323,
        "f": 83886081
      },
      "n": "Path",
      "d": 1704051,
      "h": 253404774515,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253404774515),
//--TRIMMABLE-BOUNDARY-START(292059480179),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275232371,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369368891507,
        "f": 83886081
      },
      "n": "Secure",
      "d": 1704051,
      "h": 292059480179,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292059480179),
//--TRIMMABLE-BOUNDARY-START(270584643699),
    {
      "p": 1638515,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685297779,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360778956915,
        "f": 83886081
      },
      "n": "SameSite",
      "d": 1704051,
      "h": 270584643699,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270584643699),
//--TRIMMABLE-BOUNDARY-START(214750068851),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325559411,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326419218547,
        "f": 83886081
      },
      "n": "HttpOnly",
      "d": 1704051,
      "h": 214750068851,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214750068851),
//--TRIMMABLE-BOUNDARY-START(115965821043),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735624819,
        "f": 50331649
      },
      "n": "Extensions",
      "d": 1704051,
      "h": 115965821043,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965821043)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 386548760691, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1704051,
      "h": 386548760691,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 386548760691, 330712612865),
//--TRIMMABLE-BOUNDARY-START(68721180787),
    {
      "r": 65537,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.Span$$($.$$.System.Char).$h,
          "f": 4
        },
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "AppendSegment",
      "o": "@$1",
      "d": 1704051,
      "h": 68721180787,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68721180787),
//--TRIMMABLE-BOUNDARY-START(64426213491),
    {
      "r": 65537,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.Span$$($.$$.System.Char).$h,
          "f": 4
        },
        {
          "n": "other",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Append",
      "d": 1704051,
      "h": 64426213491,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64426213491),
//--TRIMMABLE-BOUNDARY-START(77311115379),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 166920193
        }
      ],
      "n": "AppendToStringBuilder",
      "d": 1704051,
      "h": 77311115379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311115379),
//--TRIMMABLE-BOUNDARY-START(73016148083),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 166920193
        },
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "AppendSegment",
      "d": 1704051,
      "h": 73016148083,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73016148083),
//--TRIMMABLE-BOUNDARY-START(240519872627),
    {
      "r": 1704051,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1704051,
      "h": 240519872627,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(240519872627),
//--TRIMMABLE-BOUNDARY-START(390843727987),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1704051,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1704051,
      "h": 390843727987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(390843727987),
//--TRIMMABLE-BOUNDARY-START(244814839923),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseList",
      "d": 1704051,
      "h": 244814839923,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(244814839923),
//--TRIMMABLE-BOUNDARY-START(249109807219),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 1704051,
      "h": 249109807219,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(249109807219),
//--TRIMMABLE-BOUNDARY-START(395138695283),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 1704051,
      "h": 395138695283,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(395138695283),
//--TRIMMABLE-BOUNDARY-START(399433662579),
    {
      "r": 262145,
      "p": [
        {
          "n": "inputs",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 1704051,
      "h": 399433662579,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(399433662579),
//--TRIMMABLE-BOUNDARY-START(210455101555),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1704051,
          "f": 2
        }
      ],
      "n": "GetSetCookieLength",
      "d": 1704051,
      "h": 210455101555,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(210455101555),
//--TRIMMABLE-BOUNDARY-START(261994709107),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "ReadEqualsSign",
      "d": 1704051,
      "h": 261994709107,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(261994709107),
//--TRIMMABLE-BOUNDARY-START(266289676403),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 4
        },
        {
          "n": "includeComma",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "ReadToSemicolonOrEnd",
      "d": 1704051,
      "h": 266289676403,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(266289676403),
//--TRIMMABLE-BOUNDARY-START(ALL, 90196017267, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1704051,
      "h": 90196017267,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 90196017267, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 206160134259, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1704051,
      "h": 206160134259,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 206160134259, 184683724801)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(111670853747),
    {
      "t": 1310721,
      "n": "ExpiresToken",
      "d": 1704051,
      "h": 111670853747,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(111670853747),
//--TRIMMABLE-BOUNDARY-START(227634970739),
    {
      "t": 1310721,
      "n": "MaxAgeToken",
      "d": 1704051,
      "h": 227634970739,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(227634970739),
//--TRIMMABLE-BOUNDARY-START(85901049971),
    {
      "t": 1310721,
      "n": "DomainToken",
      "d": 1704051,
      "h": 85901049971,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85901049971),
//--TRIMMABLE-BOUNDARY-START(257699741811),
    {
      "t": 1310721,
      "n": "PathToken",
      "d": 1704051,
      "h": 257699741811,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(257699741811),
//--TRIMMABLE-BOUNDARY-START(296354447475),
    {
      "t": 1310721,
      "n": "SecureToken",
      "d": 1704051,
      "h": 296354447475,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(296354447475),
//--TRIMMABLE-BOUNDARY-START(287764512883),
    {
      "t": 1310721,
      "n": "SameSiteToken",
      "d": 1704051,
      "h": 287764512883,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(287764512883),
//--TRIMMABLE-BOUNDARY-START(279174578291),
    {
      "t": 1310721,
      "n": "SameSiteNoneToken",
      "d": 1704051,
      "h": 279174578291,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(279174578291),
//--TRIMMABLE-BOUNDARY-START(274879610995),
    {
      "t": 1310721,
      "n": "SameSiteLaxToken",
      "d": 1704051,
      "h": 274879610995,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(274879610995),
//--TRIMMABLE-BOUNDARY-START(283469545587),
    {
      "t": 1310721,
      "n": "SameSiteStrictToken",
      "d": 1704051,
      "h": 283469545587,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(283469545587),
//--TRIMMABLE-BOUNDARY-START(219045036147),
    {
      "t": 1310721,
      "n": "HttpOnlyToken",
      "d": 1704051,
      "h": 219045036147,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(219045036147),
//--TRIMMABLE-BOUNDARY-START(300649414771),
    {
      "t": 1310721,
      "n": "SeparatorToken",
      "d": 1704051,
      "h": 300649414771,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(300649414771),
//--TRIMMABLE-BOUNDARY-START(94490984563),
    {
      "t": 1310721,
      "n": "EqualsToken",
      "d": 1704051,
      "h": 94490984563,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(94490984563),
//--TRIMMABLE-BOUNDARY-START(107375886451),
    {
      "t": 655361,
      "n": "ExpiresDateLength",
      "d": 1704051,
      "h": 107375886451,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(107375886451),
//--TRIMMABLE-BOUNDARY-START(103080919155),
    {
      "t": 1310721,
      "n": "ExpiresDateFormat",
      "d": 1704051,
      "h": 103080919155,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103080919155),
//--TRIMMABLE-BOUNDARY-START(382253793395),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 1704051,
      "h": 382253793395,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(382253793395),
//--TRIMMABLE-BOUNDARY-START(231929938035),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 1704051,
      "h": 231929938035,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(231929938035),
//--TRIMMABLE-BOUNDARY-START(8591638643),
    {
      "t": 852053,
      "n": "_name",
      "d": 1704051,
      "h": 8591638643,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638643),
//--TRIMMABLE-BOUNDARY-START(12886605939),
    {
      "t": 852053,
      "n": "_value",
      "d": 1704051,
      "h": 12886605939,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886605939),
//--TRIMMABLE-BOUNDARY-START(4296671347),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,
      "n": "_extensions",
      "d": 1704051,
      "h": 4296671347,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671347)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476540531),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1704051,
      "h": 21476540531,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476540531),
//--TRIMMABLE-BOUNDARY-START(25771507827),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704051,
      "h": 25771507827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771507827),
//--TRIMMABLE-BOUNDARY-START(30066475123),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1704051,
      "h": 30066475123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066475123)
  ],
  "h": 1704051
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `SetCookieHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704051)
        
        
        //--TRIMMABLE-BOUNDARY-START(917619)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities", ($self) => class HeaderUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(4295884915)
            /*int*/ static _qualityValueMaxCharCount = 10;
            //--TRIMMABLE-BOUNDARY-END(4295884915)
            
            //--TRIMMABLE-BOUNDARY-START(77310328947)
            /*string*/ static QualityName = null;
            //--TRIMMABLE-BOUNDARY-END(77310328947)
            
            //--TRIMMABLE-BOUNDARY-START(21475754099)
            /*string*/ static BytesUnit = null;
            //--TRIMMABLE-BOUNDARY-END(21475754099)
            
            //--TRIMMABLE-BOUNDARY-START(85900263539)
            static /*void */ SetQuality(/*IList<NameValueHeaderValue>*/ parameters, /*double?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900263539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let qualityParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("q"/*QualityName*/));
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(value))
                {
                    if ((value < 0) || (value > 1))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                    }
                    /*var*/ let qualityString = $.$$.System.Double.ToString$2.call(($.$cast(value, $.$$.System.Double)), "0.0##", $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                    if (qualityParameter !== null)
                    {
                        qualityParameter.Value = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(qualityString);
                    }
                    else 
                    {
                        parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("q"/*QualityName*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(qualityString)), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
                else 
                {
                    if (qualityParameter !== null)
                    {
                        parameters.System$Collections$Generic$ICollection$$$Remove(qualityParameter, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900263539)
            
            //--TRIMMABLE-BOUNDARY-START(68720394355)
            static /*double? */ GetQuality(/*IList<NameValueHeaderValue>?*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720394355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let qualityParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("q"/*QualityName*/));
                if (qualityParameter !== null)
                {
                    /*var*/ let qualityValue;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseQualityDouble(qualityParameter.Value, 0, $.$ref(() => qualityValue, ($v) => qualityValue = $v, $.$$.System.Double), $.$discardRef()))
                    {
                        return qualityValue;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(68720394355)
            
            //--TRIMMABLE-BOUNDARY-START(25770721395)
            static /*void */ CheckValidToken(/*StringSegment*/ value, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(value, 0) !== value.Length)
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "Invalid token '{0}'.", value));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721395)
            
            //--TRIMMABLE-BOUNDARY-START(12885819507)
            static /*bool */ AreEqualCollections$1(T, /*ICollection<T>?*/ x, /*ICollection<T>?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections(T, x, y, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819507)
            
            //--TRIMMABLE-BOUNDARY-START(17180786803)
            static /*bool */ AreEqualCollections(T, /*ICollection<T>?*/ x, /*ICollection<T>?*/ y, /*IEqualityComparer<T>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180786803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (x === null)
                {
                    return (y === null) || (y.System$Collections$Generic$ICollection$$$Count === 0);
                }
                if (y === null)
                {
                    return (x.System$Collections$Generic$ICollection$$$Count === 0);
                }
                if (x.System$Collections$Generic$ICollection$$$Count !== y.System$Collections$Generic$ICollection$$$Count)
                {
                    return false;
                }
                if (x.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    return true;
                }
                /*var*/ let alreadyFound = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Boolean), null, [x.System$Collections$Generic$ICollection$$$Count], null);
                /*var*/ let i = 0;
                var $en2 = x.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var xItem = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$box(xItem, T) !== null);
                        i = 0;
                        /*var*/ let found = false;
                        var $en4 = y.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var yItem = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (!$.$$.System.Array.$ReadT1.call(alreadyFound, i))
                                {
                                    if (((comparer === null) && $.$$.System.Object.Equals$1.call(xItem, $.$box(yItem, T))) || ((comparer !== null) && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(xItem, yItem, [T])))
                                    {
                                        $.$$.System.Array.$WriteT1.call(alreadyFound, true, i);
                                        found = true;
                                        break;
                                    }
                                }
                                i++;
                            }
                        }
                        if (!found)
                        {
                            return false;
                        }
                    }
                }
                $.$$.System.Diagnostics.Contracts.Contract.Assert($.$$.System.Diagnostics.Contracts.Contract.ForAll$1($.$$.System.Boolean, alreadyFound, new ($.$$.System.Predicate$$($.$$.System.Boolean))().$ctor(this,  (/*value*/ value) =>
                {
                    return value;
                }, {
  "r": 262145,
  "p": [
    {
      "n": "value",
      "p": 262145
    }
  ],
  "n": "",
  "d": 917619,
  "h": 0,
  "f": 17825794
})), "Expected all values in 'alreadyFound' to be true since collections are considered equal.");
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786803)
            
            //--TRIMMABLE-BOUNDARY-START(64425427059)
            static /*int */ GetNextNonEmptyOrWhitespaceIndex(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ skipEmptyValues, /*out bool*/ separatorFound)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425427059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                separatorFound.$v = false;
                /*var*/ let current = ((startIndex + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*,*/ 44))
                {
                    return current;
                }
                separatorFound.$v = true;
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (skipEmptyValues)
                {
                    while((current < input.Length) && (input.get_Item(current) === /*,*/ 44))
                    {
                        current++;
                        current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                }
                return current;
            }
            //--TRIMMABLE-BOUNDARY-END(64425427059)
            
            //--TRIMMABLE-BOUNDARY-START(8590852211)
            static /*int */ AdvanceCacheDirectiveIndex(/*int*/ current, /*string*/ headerValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                current += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), current);
                if (current < headerValue.length && $.$$.System.String.get_Chars.call(headerValue, current) === /*=*/ 61)
                {
                    current++;
                    current += $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetValueLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), current);
                }
                current = $.$$.System.String.IndexOf$1.call(headerValue, /*,*/ 44, current);
                if (current === -1)
                {
                    return headerValue.length;
                }
                current++;
                current += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), current);
                return current;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852211)
            
            //--TRIMMABLE-BOUNDARY-START(115965034611)
            static /*bool */ TryParseSeconds(/*StringValues*/ headerValues, /*string*/ targetValue, /*out TimeSpan?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965034611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringValues.IsNullOrEmpty(headerValues) || $.$$.System.String.IsNullOrEmpty(targetValue))
                {
                    value.$v = null;
                    return false;
                }
                for(/*var*/ let i = 0; i < headerValues.Count; i++)
                {
                    /*var*/ let segment = headerValues.get_Item(i) ?? $.$$.System.String.Empty;
                    /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(segment), 0);
                    while(current < segment.length)
                    {
                        /*long*/ let seconds;
                        /*var*/ let initial = current;
                        /*var*/ let tokenLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValues.get_Item(i)), current);
                        if (tokenLength === targetValue.length && $.$$.System.String.Compare$3(headerValues.get_Item(i), current, targetValue, 0, tokenLength, 5/*StringComparison.OrdinalIgnoreCase*/) === 0 && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64FromHeaderValue(((current + tokenLength) | 0), segment, $.$ref(() => seconds, ($v) => seconds = $v, $.$$.System.Int64)))
                        {
                            value.$v = $.$$.System.TimeSpan.FromSeconds$2(seconds);
                            return true;
                        }
                        current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AdvanceCacheDirectiveIndex(((current + tokenLength) | 0), segment);
                        if (current <= initial)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(false, `Index '${"current"}' not advanced, this is a bug.`);
                            value.$v = null;
                            return false;
                        }
                    }
                }
                value.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(115965034611)
            
            //--TRIMMABLE-BOUNDARY-START(30065688691)
            static /*bool */ ContainsCacheDirective(/*StringValues*/ cacheControlDirectives, /*string*/ targetDirectives)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065688691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mep.Microsoft.Extensions.Primitives.StringValues.IsNullOrEmpty(cacheControlDirectives) || $.$$.System.String.IsNullOrEmpty(targetDirectives))
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < cacheControlDirectives.Count; i++)
                {
                    /*var*/ let segment = cacheControlDirectives.get_Item(i) ?? $.$$.System.String.Empty;
                    /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(segment), 0);
                    while(current < segment.length)
                    {
                        /*var*/ let initial = current;
                        /*var*/ let tokenLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(segment), current);
                        if (tokenLength === targetDirectives.length && $.$$.System.String.Compare$3(segment, current, targetDirectives, 0, tokenLength, 5/*StringComparison.OrdinalIgnoreCase*/) === 0)
                        {
                            return true;
                        }
                        current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AdvanceCacheDirectiveIndex(((current + tokenLength) | 0), segment);
                        if (current <= initial)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(false, `Index '${"current"}' not advanced, this is a bug.`);
                            return false;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30065688691)
            
            //--TRIMMABLE-BOUNDARY-START(107375100019)
            static /*bool */ TryParseNonNegativeInt64FromHeaderValue(/*int*/ startIndex, /*string*/ headerValue, /*out long*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375100019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                startIndex += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), startIndex);
                if (startIndex >= ((headerValue.length - 1) | 0) || $.$$.System.String.get_Chars.call(headerValue, startIndex) !== /*=*/ 61)
                {
                    result.$v = 0n;
                    return false;
                }
                startIndex++;
                startIndex += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), startIndex);
                if ($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(new $.$mep.Microsoft.Extensions.Primitives.StringSegment().$ctor$3(headerValue, startIndex, $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), startIndex, false)), result))
                {
                    return true;
                }
                result.$v = 0n;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(107375100019)
            
            //--TRIMMABLE-BOUNDARY-START(98785165427)
            static /*bool */ TryParseNonNegativeInt32(/*StringSegment*/ value, /*out int*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785165427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(value.Buffer) || value.Length === 0)
                {
                    result.$v = 0;
                    return false;
                }
                return $.$$.System.Int32.TryParse$3(value.AsSpan(), 0/*NumberStyles.None*/, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo, result);
            }
            //--TRIMMABLE-BOUNDARY-END(98785165427)
            
            //--TRIMMABLE-BOUNDARY-START(103080132723)
            static /*bool */ TryParseNonNegativeInt64(/*StringSegment*/ value, /*out long*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080132723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(value.Buffer) || value.Length === 0)
                {
                    result.$v = 0n;
                    return false;
                }
                return $.$$.System.Int64.TryParse$3(value.AsSpan(), 0/*NumberStyles.None*/, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo, result);
            }
            //--TRIMMABLE-BOUNDARY-END(103080132723)
            
            //--TRIMMABLE-BOUNDARY-START(111670067315)
            static /*bool */ TryParseQualityDouble(/*StringSegment*/ input, /*int*/ startIndex, /*out double*/ quality, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670067315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                quality.$v = 0;
                length.$v = 0;
                /*var*/ let inputLength = input.Length;
                /*var*/ let current = startIndex;
                /*var*/ let limit = ((startIndex + 10/*_qualityValueMaxCharCount*/) | 0);
                /*var*/ let decPart = 0;
                /*var*/ let decPow = 1;
                if (current >= inputLength)
                {
                    return false;
                }
                /*var*/ let ch = input.get_Item(current);
                /*int*/ let intPart;
                if (ch >= /*0*/ 48 && ch <= /*1*/ 49)
                {
                    intPart = ch - /*0*/ 48;
                    current++;
                }
                else 
                {
                    return false;
                }
                if (current < inputLength)
                {
                    ch = input.get_Item(current);
                    if (ch >= /*0*/ 48 && ch <= /*9*/ 57)
                    {
                        return false;
                    }
                    if (ch === /*.*/ 46)
                    {
                        current++;
                        while(current < inputLength)
                        {
                            ch = input.get_Item(current);
                            if (ch >= /*0*/ 48 && ch <= /*9*/ 57)
                            {
                                if (current >= limit)
                                {
                                    return false;
                                }
                                decPart = ((((((decPart * 10) | 0) + ch) | 0) - /*0*/ 48) | 0);
                                decPow *= 10;
                                current++;
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                }
                if (decPart !== 0)
                {
                    quality.$v = intPart + decPart / $.$cast(decPow, $.$$.System.Double);
                }
                else 
                {
                    quality.$v = intPart;
                }
                if (quality.$v > 1)
                {
                    quality.$v = 0;
                    return false;
                }
                length.$v = ((current - startIndex) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(111670067315)
            
            //--TRIMMABLE-BOUNDARY-START(60130459763)
            static /*string */ FormatNonNegativeInt64(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130459763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int64), "The value to be formatted must be non-negative.");
                }
                if (value === 0n)
                {
                    return "0";
                }
                return $.$$.System.UInt64.ToString$1.call(($.$cast(value, $.$$.System.UInt64)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(60130459763)
            
            //--TRIMMABLE-BOUNDARY-START(55835492467)
            static /*string */ FormatInt64(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835492467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    if (value === 0n)
                    {
                        return "0";
                    }
                    if (value === 1n)
                    {
                        return "1";
                    }
                    if (value === BigInt(-1))
                    {
                        return "-1";
                    }
                    return $.$$.System.Int64.ToString$1.call(value, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(55835492467)
            
            //--TRIMMABLE-BOUNDARY-START(94490198131)
            static /*bool */ TryParseDate(/*StringSegment*/ input, /*out DateTimeOffset*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490198131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TryStringToDate(input, result);
            }
            //--TRIMMABLE-BOUNDARY-END(94490198131)
            
            //--TRIMMABLE-BOUNDARY-START(47245557875)
            static /*string */ FormatDate$1(/*DateTimeOffset*/ dateTime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatDate(dateTime, false);
            }
            //--TRIMMABLE-BOUNDARY-END(47245557875)
            
            //--TRIMMABLE-BOUNDARY-START(51540525171)
            static /*string */ FormatDate(/*DateTimeOffset*/ dateTime, /*bool*/ quoted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (quoted)
                {
                    return $.$$.System.String.Create$10($.$$.System.DateTimeOffset, 31, dateTime, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.DateTimeOffset))().$ctor(this,  (/*span*/ span, /*dt*/ dt) =>
                    {
                        span.get_Item(0).$v = span.get_Item(30).$v = /*\"*/ 34;
                        dt.TryFormat$1(span.Slice$1(1), $.$discardRef(), $.$$.System.String.op_Implicit("r"), $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "span",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "dt",
      "p": 65339393
    }
  ],
  "n": "",
  "d": 917619,
  "h": 0,
  "f": 17825794
}));
                }
                return dateTime.ToString$2("r", $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(51540525171)
            
            //--TRIMMABLE-BOUNDARY-START(81605296243)
            static /*StringSegment */ RemoveQuotes(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.IsQuoted(input))
                {
                    input = input.Subsegment(1, ((input.Length - 2) | 0));
                }
                return input;
            }
            //--TRIMMABLE-BOUNDARY-END(81605296243)
            
            //--TRIMMABLE-BOUNDARY-START(73015361651)
            static /*bool */ IsQuoted(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) && input.Length >= 2 && input.get_Item(0) === /*\"*/ 34 && input.get_Item(((input.Length - 1) | 0)) === /*\"*/ 34;
            }
            //--TRIMMABLE-BOUNDARY-END(73015361651)
            
            //--TRIMMABLE-BOUNDARY-START(120260001907)
            static /*StringSegment */ UnescapeAsQuotedString(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260001907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                input = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(input);
                /*var*/ let backSlashCount = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CountBackslashesForDecodingQuotedString(input);
                if (backSlashCount === 0)
                {
                    return input;
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Create$10($.$mep.Microsoft.Extensions.Primitives.StringSegment, ((input.Length - backSlashCount) | 0), input, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor(this,  (/*span*/ span, /*segment*/ segment) =>
                {
                    /*var*/ let spanIndex = 0;
                    /*var*/ let spanLength = span.Length;
                    for(/*var*/ let i = 0; i < segment.Length && (spanIndex >>> 0) < (spanLength >>> 0); i++)
                    {
                        /*int*/ let nextIndex = ((i + 1) | 0);
                        if ((nextIndex >>> 0) < (segment.Length >>> 0) && segment.get_Item(i) === /*\\*/ 92)
                        {
                            span.get_Item(spanIndex).$v = segment.get_Item(nextIndex);
                            i++;
                        }
                        else 
                        {
                            span.get_Item(spanIndex).$v = segment.get_Item(i);
                        }
                        spanIndex++;
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "span",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "segment",
      "p": 852053
    }
  ],
  "n": "",
  "d": 917619,
  "h": 0,
  "f": 17825794
})));
            }
            //--TRIMMABLE-BOUNDARY-END(120260001907)
            
            //--TRIMMABLE-BOUNDARY-START(38655623283)
            static /*int */ CountBackslashesForDecodingQuotedString(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let numberBackSlashes = 0;
                for(/*var*/ let i = 0; i < input.Length; i++)
                {
                    if (i < ((input.Length - 1) | 0) && input.get_Item(i) === /*\\*/ 92)
                    {
                        if (input.get_Item(((i + 1) | 0)) === /*\\*/ 92)
                        {
                            i++;
                        }
                        numberBackSlashes++;
                    }
                }
                return numberBackSlashes;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623283)
            
            //--TRIMMABLE-BOUNDARY-START(42950590579)
            static /*StringSegment */ EscapeAsQuotedString(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let backSlashCount = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CountAndCheckCharactersNeedingBackslashesWhenEncoding(input);
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Create$10($.$mep.Microsoft.Extensions.Primitives.StringSegment, ((((input.Length + backSlashCount) | 0) + 2) | 0), input, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor(this,  (/*span*/ span, /*segment*/ segment) =>
                {
                    span.get_Item(((span.Length - 1) | 0)).$v = span.get_Item(0).$v = /*\"*/ 34;
                    /*var*/ let spanIndex = 1;
                    for(/*var*/ let i = 0; i < segment.Length; i++)
                    {
                        if (segment.get_Item(i) === /*\\*/ 92 || segment.get_Item(i) === /*\"*/ 34)
                        {
                            span.get_Item(spanIndex++).$v = /*\\*/ 92;
                        }
                        else if ((segment.get_Item(i) <= 31 || segment.get_Item(i) === 127) && segment.get_Item(i) !== 9)
                        {
                            throw new $.$$.System.FormatException().$ctor$12(`Invalid control character '${$.$$.System.Char.ToString.call(segment.get_Item(i))}' in input.`);
                        }
                        span.get_Item(spanIndex++).$v = segment.get_Item(i);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "span",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "segment",
      "p": 852053
    }
  ],
  "n": "",
  "d": 917619,
  "h": 0,
  "f": 17825794
})));
            }
            //--TRIMMABLE-BOUNDARY-END(42950590579)
            
            //--TRIMMABLE-BOUNDARY-START(34360655987)
            static /*int */ CountAndCheckCharactersNeedingBackslashesWhenEncoding(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360655987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let numberOfCharactersNeedingEscaping = 0;
                for(/*var*/ let i = 0; i < input.Length; i++)
                {
                    if (input.get_Item(i) === /*\\*/ 92 || input.get_Item(i) === /*\"*/ 34)
                    {
                        numberOfCharactersNeedingEscaping++;
                    }
                }
                return numberOfCharactersNeedingEscaping;
            }
            //--TRIMMABLE-BOUNDARY-END(34360655987)
            
            //--TRIMMABLE-BOUNDARY-START(90195230835)
            static /*void */ ThrowIfReadOnly(/*bool*/ isReadOnly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195230835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isReadOnly)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("The object cannot be modified because it is read-only.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195230835)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(77310328947)
                    this.QualityName = "q";
                    //--TRIMMABLE-BOUNDARY-END(77310328947)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475754099)
                    this.BytesUnit = "bytes";
                    //--TRIMMABLE-BOUNDARY-END(21475754099)
                    
                }
            }
            static $h = 917619;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900263539),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h
        },
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Double).$h
        }
      ],
      "n": "SetQuality",
      "d": 917619,
      "h": 85900263539,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(85900263539),
//--TRIMMABLE-BOUNDARY-START(68720394355),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h
        }
      ],
      "n": "GetQuality",
      "d": 917619,
      "h": 68720394355,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(68720394355),
//--TRIMMABLE-BOUNDARY-START(25770721395),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "CheckValidToken",
      "d": 917619,
      "h": 25770721395,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770721395),
//--TRIMMABLE-BOUNDARY-START(12885819507),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": (T) => $.$$.System.Collections.Generic.ICollection$$(T).$h
        },
        {
          "n": "y",
          "p": (T) => $.$$.System.Collections.Generic.ICollection$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AreEqualCollections",
      "o": "@$1",
      "d": 917619,
      "h": 12885819507,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(12885819507),
//--TRIMMABLE-BOUNDARY-START(17180786803),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": (T) => $.$$.System.Collections.Generic.ICollection$$(T).$h
        },
        {
          "n": "y",
          "p": (T) => $.$$.System.Collections.Generic.ICollection$$(T).$h
        },
        {
          "n": "comparer",
          "p": (T) => $.$$.System.Collections.Generic.IEqualityComparer$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AreEqualCollections",
      "d": 917619,
      "h": 17180786803,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(17180786803),
//--TRIMMABLE-BOUNDARY-START(64425427059),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "skipEmptyValues",
          "p": 262145
        },
        {
          "n": "separatorFound",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "GetNextNonEmptyOrWhitespaceIndex",
      "d": 917619,
      "h": 64425427059,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64425427059),
//--TRIMMABLE-BOUNDARY-START(8590852211),
    {
      "r": 655361,
      "p": [
        {
          "n": "current",
          "p": 655361
        },
        {
          "n": "headerValue",
          "p": 1310721
        }
      ],
      "n": "AdvanceCacheDirectiveIndex",
      "d": 917619,
      "h": 8590852211,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590852211),
//--TRIMMABLE-BOUNDARY-START(115965034611),
    {
      "r": 262145,
      "p": [
        {
          "n": "headerValues",
          "p": 1114197
        },
        {
          "n": "targetValue",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.TimeSpan).$h,
          "f": 2
        }
      ],
      "n": "TryParseSeconds",
      "d": 917619,
      "h": 115965034611,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115965034611),
//--TRIMMABLE-BOUNDARY-START(30065688691),
    {
      "r": 262145,
      "p": [
        {
          "n": "cacheControlDirectives",
          "p": 1114197
        },
        {
          "n": "targetDirectives",
          "p": 1310721
        }
      ],
      "n": "ContainsCacheDirective",
      "d": 917619,
      "h": 30065688691,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065688691),
//--TRIMMABLE-BOUNDARY-START(107375100019),
    {
      "r": 262145,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "headerValue",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryParseNonNegativeInt64FromHeaderValue",
      "d": 917619,
      "h": 107375100019,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375100019),
//--TRIMMABLE-BOUNDARY-START(98785165427),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "result",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryParseNonNegativeInt32",
      "d": 917619,
      "h": 98785165427,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98785165427),
//--TRIMMABLE-BOUNDARY-START(103080132723),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "result",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryParseNonNegativeInt64",
      "d": 917619,
      "h": 103080132723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103080132723),
//--TRIMMABLE-BOUNDARY-START(111670067315),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "quality",
          "p": 1179649,
          "f": 2
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryParseQualityDouble",
      "d": 917619,
      "h": 111670067315,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(111670067315),
//--TRIMMABLE-BOUNDARY-START(60130459763),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "FormatNonNegativeInt64",
      "d": 917619,
      "h": 60130459763,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130459763),
//--TRIMMABLE-BOUNDARY-START(55835492467),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "FormatInt64",
      "d": 917619,
      "h": 55835492467,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835492467),
//--TRIMMABLE-BOUNDARY-START(94490198131),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "result",
          "p": 65339393,
          "f": 2
        }
      ],
      "n": "TryParseDate",
      "d": 917619,
      "h": 94490198131,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94490198131),
//--TRIMMABLE-BOUNDARY-START(47245557875),
    {
      "r": 1310721,
      "p": [
        {
          "n": "dateTime",
          "p": 65339393
        }
      ],
      "n": "FormatDate",
      "o": "@$1",
      "d": 917619,
      "h": 47245557875,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245557875),
//--TRIMMABLE-BOUNDARY-START(51540525171),
    {
      "r": 1310721,
      "p": [
        {
          "n": "dateTime",
          "p": 65339393
        },
        {
          "n": "quoted",
          "p": 262145
        }
      ],
      "n": "FormatDate",
      "d": 917619,
      "h": 51540525171,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540525171),
//--TRIMMABLE-BOUNDARY-START(81605296243),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "RemoveQuotes",
      "d": 917619,
      "h": 81605296243,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605296243),
//--TRIMMABLE-BOUNDARY-START(73015361651),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "IsQuoted",
      "d": 917619,
      "h": 73015361651,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015361651),
//--TRIMMABLE-BOUNDARY-START(120260001907),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "UnescapeAsQuotedString",
      "d": 917619,
      "h": 120260001907,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120260001907),
//--TRIMMABLE-BOUNDARY-START(38655623283),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "CountBackslashesForDecodingQuotedString",
      "d": 917619,
      "h": 38655623283,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655623283),
//--TRIMMABLE-BOUNDARY-START(42950590579),
    {
      "r": 852053,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "EscapeAsQuotedString",
      "d": 917619,
      "h": 42950590579,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950590579),
//--TRIMMABLE-BOUNDARY-START(34360655987),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "CountAndCheckCharactersNeedingBackslashesWhenEncoding",
      "d": 917619,
      "h": 34360655987,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360655987),
//--TRIMMABLE-BOUNDARY-START(90195230835),
    {
      "r": 65537,
      "p": [
        {
          "n": "isReadOnly",
          "p": 262145
        }
      ],
      "n": "ThrowIfReadOnly",
      "d": 917619,
      "h": 90195230835,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90195230835)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884915),
    {
      "t": 655361,
      "n": "_qualityValueMaxCharCount",
      "d": 917619,
      "h": 4295884915,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295884915),
//--TRIMMABLE-BOUNDARY-START(77310328947),
    {
      "t": 1310721,
      "n": "QualityName",
      "d": 917619,
      "h": 77310328947,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310328947),
//--TRIMMABLE-BOUNDARY-START(21475754099),
    {
      "t": 1310721,
      "n": "BytesUnit",
      "d": 917619,
      "h": 21475754099,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475754099)
  ],
  "h": 917619
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HeaderUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917619)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310835)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue", ($self) => class NameValueHeaderValue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(150325166195)
            /*HttpHeaderParser<NameValueHeaderValue>*/ static SingleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(150325166195)
            
            //--TRIMMABLE-BOUNDARY-START(115965427827)
            /*HttpHeaderParser<NameValueHeaderValue>*/ static MultipleValueParser = null;
            //--TRIMMABLE-BOUNDARY-END(115965427827)
            
            //--TRIMMABLE-BOUNDARY-START(8591245427)
            /*StringSegment*/ _name;
            //--TRIMMABLE-BOUNDARY-END(8591245427)
            
            //--TRIMMABLE-BOUNDARY-START(12886212723)
            /*StringSegment*/ _value;
            //--TRIMMABLE-BOUNDARY-END(12886212723)
            
            //--TRIMMABLE-BOUNDARY-START(4296278131)
            /*bool*/ _isReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(4296278131)
            
            //--TRIMMABLE-BOUNDARY-START(21476147315)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476147315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476147315)
            
            //--TRIMMABLE-BOUNDARY-START(25771114611)
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771114611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771114611)
            
            //--TRIMMABLE-BOUNDARY-START(30066081907)
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066081907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.CheckNameValueFormat(name, value);
                    this._name = name;
                    this._value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066081907)
            
            //--TRIMMABLE-BOUNDARY-START(120260395123)
            /*StringSegment */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015754867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            //--TRIMMABLE-BOUNDARY-END(120260395123)
            
            //--TRIMMABLE-BOUNDARY-START(180389937267)
            /*StringSegment */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605689459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735231603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.CheckValueFormat(value);
                this._value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(180389937267)
            
            //--TRIMMABLE-BOUNDARY-START(111670460531)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425820275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._isReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(111670460531)
            
            //--TRIMMABLE-BOUNDARY-START(42950983795)
            /*NameValueHeaderValue */ Copy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue()
                    const $t1 = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1._name = this._name;
                    $i1._value = this._value;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(42950983795)
            
            //--TRIMMABLE-BOUNDARY-START(47245951091)
            /*NameValueHeaderValue */ CopyAsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245951091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    return this;
                }
                return (() =>
                {
                    //new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue()
                    const $t1 = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1._name = this._name;
                    $i1._value = this._value;
                    $i1._isReadOnly = true;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(47245951091)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 85900656755, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900656755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this._name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)));
                /*var*/ let nameHashCode = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._name);
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(this._value))
                {
                    if (this._value.get_Item(0) === /*\"*/ 34)
                    {
                        return nameHashCode ^ $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(this._value);
                    }
                    return nameHashCode ^ $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value);
                }
                return nameHashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 85900656755, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51540918387, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (!this._name.Equals$4(other._name, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(this._value))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(other._value);
                }
                if (this._value.get_Item(0) === /*\"*/ 34)
                {
                    return (this._value.Equals$4(other._value, 4/*StringComparison.Ordinal*/));
                }
                else 
                {
                    return (this._value.Equals$4(other._value, 5/*StringComparison.OrdinalIgnoreCase*/));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51540918387, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(103080525939)
            /*StringSegment */ GetUnescapedValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080525939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.IsQuoted(this._value))
                {
                    return this._value;
                }
                return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.UnescapeAsQuotedString(this._value);
            }
            //--TRIMMABLE-BOUNDARY-END(103080525939)
            
            //--TRIMMABLE-BOUNDARY-START(146030198899)
            /*void */ SetAndEscapeValue(/*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030198899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value) || ($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetValueLength(value, 0) === value.Length))
                {
                    this._value = value;
                }
                else 
                {
                    this.Value = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.EscapeAsQuotedString(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030198899)
            
            //--TRIMMABLE-BOUNDARY-START(124555362419)
            static /*NameValueHeaderValue */ Parse(/*StringSegment*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555362419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(124555362419)
            
            //--TRIMMABLE-BOUNDARY-START(167505035379)
            static /*bool */ TryParse(/*StringSegment*/ input, /*out NameValueHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505035379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(167505035379)
            
            //--TRIMMABLE-BOUNDARY-START(128850329715)
            static /*IList<NameValueHeaderValue> */ ParseList(/*IList<string>?*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850329715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.ParseValues$1(input);
            }
            //--TRIMMABLE-BOUNDARY-END(128850329715)
            
            //--TRIMMABLE-BOUNDARY-START(133145297011)
            static /*IList<NameValueHeaderValue> */ ParseStrictList(/*IList<string>?*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145297011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.ParseStrictValues(input);
            }
            //--TRIMMABLE-BOUNDARY-END(133145297011)
            
            //--TRIMMABLE-BOUNDARY-START(171800002675)
            static /*bool */ TryParseList(/*IList<string>?*/ input, /*out IList<NameValueHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800002675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.TryParseValues$1(input, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(171800002675)
            
            //--TRIMMABLE-BOUNDARY-START(176094969971)
            static /*bool */ TryParseStrictList(/*IList<string>?*/ input, /*out IList<NameValueHeaderValue>?*/ parsedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094969971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.TryParseStrictValues(input, parsedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(176094969971)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 154620133491, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620133491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(this._value))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._name) + "=" + $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._value);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._name);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 154620133491, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(158915100787)
            static /*void */ ToString$1(/*IList<NameValueHeaderValue>?*/ values, /*char*/ separator, /*bool*/ leadingSeparator, /*StringBuilder*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915100787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1(destination !== null);
                if ((values === null) || (values.System$Collections$Generic$ICollection$$$Count === 0))
                {
                    return;
                }
                for(/*var*/ let i = 0; i < values.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    if (leadingSeparator || (destination.Length > 0))
                    {
                        destination.Append$3(separator);
                        destination.Append$3(/* */ 32);
                    }
                    destination.Append$15(values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]).Name.AsSpan());
                    if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]).Value))
                    {
                        destination.Append$3(/*=*/ 61);
                        destination.Append$15(values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]).Value.AsSpan());
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915100787)
            
            //--TRIMMABLE-BOUNDARY-START(163210068083)
            static /*string? */ ToString$2(/*IList<NameValueHeaderValue>?*/ values, /*char*/ separator, /*bool*/ leadingSeparator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210068083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((values === null) || (values.System$Collections$Generic$ICollection$$$Count === 0))
                {
                    return null;
                }
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString$1(values, separator, leadingSeparator, sb);
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //--TRIMMABLE-BOUNDARY-END(163210068083)
            
            //--TRIMMABLE-BOUNDARY-START(90195624051)
            static /*int */ GetHashCode$1(/*IList<NameValueHeaderValue>?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195624051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((values === null) || (values.System$Collections$Generic$ICollection$$$Count === 0))
                {
                    return 0;
                }
                /*var*/ let result = 0;
                for(/*var*/ let i = 0; i < values.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    result = result ^ $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode.call(values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]));
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(90195624051)
            
            //--TRIMMABLE-BOUNDARY-START(94490591347)
            static /*int */ GetNameValueLength(/*StringSegment*/ input, /*int*/ startIndex, /*out NameValueHeaderValue?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490591347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let nameLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (nameLength === 0)
                {
                    return 0;
                }
                /*var*/ let name = input.Subsegment(startIndex, nameLength);
                /*var*/ let current = ((startIndex + nameLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*=*/ 61))
                {
                    parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$1();
                    parsedValue.$v._name = name;
                    current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    return ((current - startIndex) | 0);
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*int*/ let valueLength = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetValueLength(input, current);
                parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$1();
                parsedValue.$v._name = name;
                parsedValue.$v._value = input.Subsegment(current, valueLength);
                current = ((current + valueLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                return ((current - startIndex) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(94490591347)
            
            //--TRIMMABLE-BOUNDARY-START(98785558643)
            static /*int */ GetNameValueListLength(/*StringSegment*/ input, /*int*/ startIndex, /*char*/ delimiter, /*IList<NameValueHeaderValue>*/ nameValueCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785558643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if (($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input)) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                while(true)
                {
                    /*var*/ let parameter;
                    /*var*/ let nameValueLength = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueLength(input, current, $.$ref(() => parameter, ($v) => parameter = $v, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue));
                    if (nameValueLength === 0)
                    {
                        return ((current - startIndex) | 0);
                    }
                    nameValueCollection.System$Collections$Generic$ICollection$$$Add(parameter, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    current = ((current + nameValueLength) | 0);
                    current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    if ((current === input.Length) || (input.get_Item(current) !== delimiter))
                    {
                        return ((current - startIndex) | 0);
                    }
                    current++;
                    current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785558643)
            
            //--TRIMMABLE-BOUNDARY-START(55835885683)
            static /*NameValueHeaderValue? */ Find(/*IList<NameValueHeaderValue>?*/ values, /*StringSegment*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835885683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                if ((values === null) || (values.System$Collections$Generic$ICollection$$$Count === 0))
                {
                    return null;
                }
                for(/*var*/ let i = 0; i < values.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*var*/ let value = values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    if (value.Name.Equals$4(name, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return value;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(55835885683)
            
            //--TRIMMABLE-BOUNDARY-START(107375493235)
            static /*int */ GetValueLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375493235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let valueLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (valueLength === 0)
                {
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetQuotedStringLength(input, startIndex, $.$ref(() => valueLength, ($v) => valueLength = $v, $.$$.System.Int32)) !== 0/*HttpParseResult.Parsed*/)
                    {
                        return 0;
                    }
                }
                return valueLength;
            }
            //--TRIMMABLE-BOUNDARY-END(107375493235)
            
            //--TRIMMABLE-BOUNDARY-START(34361049203)
            static /*void */ CheckNameValueFormat(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(name, "name");
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.CheckValueFormat(value);
            }
            //--TRIMMABLE-BOUNDARY-END(34361049203)
            
            //--TRIMMABLE-BOUNDARY-START(38656016499)
            static /*void */ CheckValueFormat(/*StringSegment*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656016499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value) || ($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetValueLength(value, 0) === value.Length)))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "The header value is invalid: '{0}'", value));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656016499)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591245427)
                this._name = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(8591245427)
                
                //--TRIMMABLE-BOUNDARY-START(12886212723)
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                //--TRIMMABLE-BOUNDARY-END(12886212723)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17181180019)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(150325166195)
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueLength));
                    //--TRIMMABLE-BOUNDARY-END(150325166195)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115965427827)
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueLength));
                    //--TRIMMABLE-BOUNDARY-END(115965427827)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181180019)
            
            static $h = 1310835;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260395123),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015754867,
        "f": 50331649
      },
      "n": "Name",
      "d": 1310835,
      "h": 120260395123,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260395123),
//--TRIMMABLE-BOUNDARY-START(180389937267),
    {
      "p": 852053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605689459,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735231603,
        "f": 83886081
      },
      "n": "Value",
      "d": 1310835,
      "h": 180389937267,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389937267),
//--TRIMMABLE-BOUNDARY-START(111670460531),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425820275,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1310835,
      "h": 111670460531,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670460531)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950983795),
    {
      "r": 1310835,
      "n": "Copy",
      "d": 1310835,
      "h": 42950983795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950983795),
//--TRIMMABLE-BOUNDARY-START(47245951091),
    {
      "r": 1310835,
      "n": "CopyAsReadOnly",
      "d": 1310835,
      "h": 47245951091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245951091),
//--TRIMMABLE-BOUNDARY-START(ALL, 85900656755, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1310835,
      "h": 85900656755,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 85900656755, 184683724801),
//--TRIMMABLE-BOUNDARY-START(ALL, 51540918387, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1310835,
      "h": 51540918387,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51540918387, 34359869441),
//--TRIMMABLE-BOUNDARY-START(103080525939),
    {
      "r": 852053,
      "n": "GetUnescapedValue",
      "d": 1310835,
      "h": 103080525939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080525939),
//--TRIMMABLE-BOUNDARY-START(146030198899),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "SetAndEscapeValue",
      "d": 1310835,
      "h": 146030198899,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030198899),
//--TRIMMABLE-BOUNDARY-START(124555362419),
    {
      "r": 1310835,
      "p": [
        {
          "n": "input",
          "p": 852053
        }
      ],
      "n": "Parse",
      "d": 1310835,
      "h": 124555362419,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124555362419),
//--TRIMMABLE-BOUNDARY-START(167505035379),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "parsedValue",
          "p": 1310835,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1310835,
      "h": 167505035379,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167505035379),
//--TRIMMABLE-BOUNDARY-START(128850329715),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseList",
      "d": 1310835,
      "h": 128850329715,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128850329715),
//--TRIMMABLE-BOUNDARY-START(133145297011),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        }
      ],
      "n": "ParseStrictList",
      "d": 1310835,
      "h": 133145297011,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133145297011),
//--TRIMMABLE-BOUNDARY-START(171800002675),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseList",
      "d": 1310835,
      "h": 171800002675,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171800002675),
//--TRIMMABLE-BOUNDARY-START(176094969971),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "parsedValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
          "f": 2
        }
      ],
      "n": "TryParseStrictList",
      "d": 1310835,
      "h": 176094969971,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(176094969971),
//--TRIMMABLE-BOUNDARY-START(ALL, 154620133491, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1310835,
      "h": 154620133491,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 154620133491, 330712612865),
//--TRIMMABLE-BOUNDARY-START(158915100787),
    {
      "r": 65537,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h
        },
        {
          "n": "separator",
          "p": 458753
        },
        {
          "n": "leadingSeparator",
          "p": 262145
        },
        {
          "n": "destination",
          "p": 166920193
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 1310835,
      "h": 158915100787,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(158915100787),
//--TRIMMABLE-BOUNDARY-START(163210068083),
    {
      "r": 1310721,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h
        },
        {
          "n": "separator",
          "p": 458753
        },
        {
          "n": "leadingSeparator",
          "p": 262145
        }
      ],
      "n": "ToString",
      "o": "@$2",
      "d": 1310835,
      "h": 163210068083,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(163210068083),
//--TRIMMABLE-BOUNDARY-START(90195624051),
    {
      "r": 655361,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 1310835,
      "h": 90195624051,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90195624051),
//--TRIMMABLE-BOUNDARY-START(94490591347),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": 1310835,
          "f": 2
        }
      ],
      "n": "GetNameValueLength",
      "d": 1310835,
      "h": 94490591347,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94490591347),
//--TRIMMABLE-BOUNDARY-START(98785558643),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "delimiter",
          "p": 458753
        },
        {
          "n": "nameValueCollection",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h
        }
      ],
      "n": "GetNameValueListLength",
      "d": 1310835,
      "h": 98785558643,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(98785558643),
//--TRIMMABLE-BOUNDARY-START(55835885683),
    {
      "r": 1310835,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h
        },
        {
          "n": "name",
          "p": 852053
        }
      ],
      "n": "Find",
      "d": 1310835,
      "h": 55835885683,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835885683),
//--TRIMMABLE-BOUNDARY-START(107375493235),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "GetValueLength",
      "d": 1310835,
      "h": 107375493235,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107375493235),
//--TRIMMABLE-BOUNDARY-START(34361049203),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "CheckNameValueFormat",
      "d": 1310835,
      "h": 34361049203,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361049203),
//--TRIMMABLE-BOUNDARY-START(38656016499),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": "CheckValueFormat",
      "d": 1310835,
      "h": 38656016499,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656016499)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(150325166195),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "n": "SingleValueParser",
      "d": 1310835,
      "h": 150325166195,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(150325166195),
//--TRIMMABLE-BOUNDARY-START(115965427827),
    {
      "t": $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,
      "n": "MultipleValueParser",
      "d": 1310835,
      "h": 115965427827,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115965427827),
//--TRIMMABLE-BOUNDARY-START(8591245427),
    {
      "t": 852053,
      "n": "_name",
      "d": 1310835,
      "h": 8591245427,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245427),
//--TRIMMABLE-BOUNDARY-START(12886212723),
    {
      "t": 852053,
      "n": "_value",
      "d": 1310835,
      "h": 12886212723,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886212723),
//--TRIMMABLE-BOUNDARY-START(4296278131),
    {
      "t": 262145,
      "n": "_isReadOnly",
      "d": 1310835,
      "h": 4296278131,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278131)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476147315),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310835,
      "h": 21476147315,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476147315),
//--TRIMMABLE-BOUNDARY-START(25771114611),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310835,
      "h": 25771114611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771114611),
//--TRIMMABLE-BOUNDARY-START(30066081907),
    {
      "p": [
        {
          "n": "name",
          "p": 852053
        },
        {
          "n": "value",
          "p": 852053
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310835,
      "h": 30066081907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066081907)
  ],
  "h": 1310835
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `NameValueHeaderValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310835)
        
        
        //--TRIMMABLE-BOUNDARY-START(655475)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser<>", (T) => $asm.$gt("$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser<>", [T], ($self) => class GenericHeaderParser$$ extends $.$mnhh.Microsoft.Net.Http.Headers.BaseHeaderParser$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(721011)
            static $_GetParsedValueLengthDelegate;
            static get GetParsedValueLengthDelegate()
            {
                let $cls = $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$(T);
                return $cls.$_GetParsedValueLengthDelegate ??= $asm.$ncls("$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$.GetParsedValueLengthDelegate", ($self) => class GetParsedValueLengthDelegate extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*int*/ Invoke(/**/ value, /*$.$$.System.Int32*/ startIndex, /**/ parsedValue)
                    {
                        return this.$nativeFunction.call(this.$target, value, startIndex, parsedValue);
                    }
                    static $h = 721011;
                    static $f = 0b10000000011000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 98828289,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590195),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "Invoke",
      "d": 721011,
      "h": Number(BigInt(721011)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180590195),
//--TRIMMABLE-BOUNDARY-START(8590655603),
    {
      "r": 89653249,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "callback",
          "p": 45154305
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 721011,
      "h": Number(BigInt(721011)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590655603),
//--TRIMMABLE-BOUNDARY-START(12885622899),
    {
      "r": 655361,
      "p": [
        {
          "n": "parsedValue",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "result",
          "p": 89653249
        }
      ],
      "n": "EndInvoke",
      "d": 721011,
      "h": Number(BigInt(721011)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885622899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688307),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 721011,
      "h": Number(BigInt(721011)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688307)
  ],
  "i": [89849857,157351937
  ],
  "d": $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$(T).$h,
  "h": 721011
}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `GenericHeaderParser<${T?.$fullName}>.GetParsedValueLengthDelegate`; }
                }, $cls, ($v) => $cls.$_GetParsedValueLengthDelegate = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(721011)
            
            //--TRIMMABLE-BOUNDARY-START(4295622771)
            /*GetParsedValueLengthDelegate*/ _getParsedValueLength = null;
            //--TRIMMABLE-BOUNDARY-END(4295622771)
            
            //--TRIMMABLE-BOUNDARY-START(8590590067)
            $ctor$3(/*bool*/ supportsMultipleValues, /*GetParsedValueLengthDelegate*/ getParsedValueLength)
            {
                super.$ctor$2(supportsMultipleValues);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590067);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(getParsedValueLength, "getParsedValueLength");
                    this._getParsedValueLength = getParsedValueLength;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590067)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12885557363, 8590000243)
            /*int */ GetParsedValueLength(/*StringSegment*/ value, /*int*/ startIndex, /*out T?*/ parsedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._getParsedValueLength.Invoke(value, startIndex, parsedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12885557363, 8590000243)
            
            static $h = 655475;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12885557363, 8590000243),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "parsedValue",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "GetParsedValueLength",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12885557363, 8590000243)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622771),
    {
      "t": 721011,
      "n": "_getParsedValueLength",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590067),
    {
      "p": [
        {
          "n": "supportsMultipleValues",
          "p": 262145
        },
        {
          "n": "getParsedValueLength",
          "p": 721011
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590590067)
  ],
  "g": [T?.$h??1507328
  ],
  "j": [721011
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$mnhh.Microsoft.Net.Http.Headers.BaseHeaderParser$$(T); }
            static get $fullName() { return `GenericHeaderParser<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(655475)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048691)
        $asm.$str("$mnhh.Microsoft.Net.Http.Headers.HttpParseResult", ($self) => class HttpParseResult extends $.$$.System.Enum
        {
            static Parsed = 0;
            static NotParsed = 1;
            static InvalidFormat = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Parsed": 0n,
                    "NotParsed": 1n,
                    "InvalidFormat": 2n
                };
            }
            static $h = 1048691;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180917875),
    {
      "t": 1048691,
      "n": "Parsed",
      "d": 1048691,
      "h": 17180917875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180917875),
//--TRIMMABLE-BOUNDARY-START(12885950579),
    {
      "t": 1048691,
      "n": "NotParsed",
      "d": 1048691,
      "h": 12885950579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950579),
//--TRIMMABLE-BOUNDARY-START(8590983283),
    {
      "t": 1048691,
      "n": "InvalidFormat",
      "d": 1048691,
      "h": 8590983283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590983283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015987),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048691,
      "h": 4296015987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015987)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1048691
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `HttpParseResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048691)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638515)
        $asm.$str("$mnhh.Microsoft.Net.Http.Headers.SameSiteMode", ($self) => class SameSiteMode extends $.$$.System.Enum
        {
            static Unspecified = -1;
            static None = 0;
            static Lax = 1;
            static Strict = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "None": 0n,
                    "Lax": 1n,
                    "Strict": 2n
                };
            }
            static $h = 1638515;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476474995),
    {
      "t": 1638515,
      "n": "Unspecified",
      "d": 1638515,
      "h": 21476474995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476474995),
//--TRIMMABLE-BOUNDARY-START(12886540403),
    {
      "t": 1638515,
      "n": "None",
      "d": 1638515,
      "h": 12886540403,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886540403),
//--TRIMMABLE-BOUNDARY-START(8591573107),
    {
      "t": 1638515,
      "n": "Lax",
      "d": 1638515,
      "h": 8591573107,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591573107),
//--TRIMMABLE-BOUNDARY-START(17181507699),
    {
      "t": 1638515,
      "n": "Strict",
      "d": 1638515,
      "h": 17181507699,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181507699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605811),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638515,
      "h": 4296605811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605811)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1638515
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `SameSiteMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638515)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245299)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValueComparer", ($self) => class MediaTypeHeaderValueComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591179891)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179891)
            
            //--TRIMMABLE-BOUNDARY-START(34360983667)
            /*MediaTypeHeaderValueComparer*/ static QualityComparer = null;
            //--TRIMMABLE-BOUNDARY-END(34360983667)
            
            //--TRIMMABLE-BOUNDARY-START(17181114483)
            /*int */ Compare(/*MediaTypeHeaderValue?*/ mediaType1, /*MediaTypeHeaderValue?*/ mediaType2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals(mediaType1, mediaType2))
                {
                    return 0;
                }
                if (mediaType1 === null)
                {
                    return -1;
                }
                if (mediaType2 === null)
                {
                    return 1;
                }
                /*var*/ let returnValue = $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValueComparer.CompareBasedOnQualityFactor(mediaType1, mediaType2);
                if (returnValue === 0)
                {
                    if (!mediaType1.Type.Equals$4(mediaType2.Type, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllTypes)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypes && !mediaType2.MatchesAllSubTypes)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypes && mediaType2.MatchesAllSubTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypesWithoutSuffix && !mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypesWithoutSuffix && mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                    else if (!mediaType1.SubType.Equals$4(mediaType2.SubType, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllSubTypes)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllSubTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypesWithoutSuffix && !mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypesWithoutSuffix && mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                    else if (!mediaType1.Suffix.Equals$4(mediaType2.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                }
                return returnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(17181114483)
            
            //--TRIMMABLE-BOUNDARY-START(21476081779)
            static /*int */ CompareBasedOnQualityFactor(/*MediaTypeHeaderValue*/ mediaType1, /*MediaTypeHeaderValue*/ mediaType2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let mediaType1Quality = mediaType1.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let mediaType2Quality = mediaType2.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let qualityDifference = mediaType1Quality - mediaType2Quality;
                if (qualityDifference < 0)
                {
                    return -1;
                }
                else if (qualityDifference > 0)
                {
                    return 1;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(21476081779)
            
            //--TRIMMABLE-BOUNDARY-START(4354277377)
            //Generated interface implemetation for System.Collections.Generic.IComparer<Microsoft.Net.Http.Headers.MediaTypeHeaderValue>.Compare(Microsoft.Net.Http.Headers.MediaTypeHeaderValue?, Microsoft.Net.Http.Headers.MediaTypeHeaderValue?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354277377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354277377)
            
            //--TRIMMABLE-BOUNDARY-START(4296212595)
            //Static Initializer
            static $sinit()
            {
                {
                    this.QualityComparer = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValueComparer().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296212595)
            
            static $h = 1245299;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360983667),
    {
      "p": 1245299,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066016371,
        "f": 50331681
      },
      "n": "QualityComparer",
      "d": 1245299,
      "h": 34360983667,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360983667)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181114483),
    {
      "r": 655361,
      "p": [
        {
          "n": "mediaType1",
          "p": 1179763
        },
        {
          "n": "mediaType2",
          "p": 1179763
        }
      ],
      "n": "Compare",
      "d": 1245299,
      "h": 17181114483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181114483),
//--TRIMMABLE-BOUNDARY-START(21476081779),
    {
      "r": 655361,
      "p": [
        {
          "n": "mediaType1",
          "p": 1179763
        },
        {
          "n": "mediaType2",
          "p": 1179763
        }
      ],
      "n": "CompareBasedOnQualityFactor",
      "d": 1245299,
      "h": 21476081779,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476081779)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179891),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245299,
      "h": 8591179891,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8591179891)
  ],
  "i": [$.$$.System.Collections.Generic.IComparer$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h
  ],
  "h": 1245299
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue) ]; }
            static get $fullName() { return `MediaTypeHeaderValueComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245299)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835123)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer", ($self) => class StringWithQualityHeaderValueComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181704307)
            /*StringSegment*/ static Any;
            //--TRIMMABLE-BOUNDARY-END(17181704307)
            
            //--TRIMMABLE-BOUNDARY-START(8591769715)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591769715);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591769715)
            
            //--TRIMMABLE-BOUNDARY-START(34361573491)
            /*StringWithQualityHeaderValueComparer*/ static QualityComparer = null;
            //--TRIMMABLE-BOUNDARY-END(34361573491)
            
            //--TRIMMABLE-BOUNDARY-START(21476671603)
            /*int */ Compare(/*StringWithQualityHeaderValue?*/ stringWithQuality1, /*StringWithQualityHeaderValue?*/ stringWithQuality2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476671603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stringWithQuality1, "stringWithQuality1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stringWithQuality2, "stringWithQuality2");
                /*var*/ let quality1 = stringWithQuality1.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let quality2 = stringWithQuality2.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let qualityDifference = quality1 - quality2;
                if (qualityDifference < 0)
                {
                    return -1;
                }
                else if (qualityDifference > 0)
                {
                    return 1;
                }
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(stringWithQuality1.Value, stringWithQuality2.Value, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(stringWithQuality1.Value, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer.Any, 4/*StringComparison.Ordinal*/))
                    {
                        return -1;
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(stringWithQuality2.Value, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer.Any, 4/*StringComparison.Ordinal*/))
                    {
                        return 1;
                    }
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(21476671603)
            
            //--TRIMMABLE-BOUNDARY-START(4354277377)
            //Generated interface implemetation for System.Collections.Generic.IComparer<Microsoft.Net.Http.Headers.StringWithQualityHeaderValue>.Compare(Microsoft.Net.Http.Headers.StringWithQualityHeaderValue?, Microsoft.Net.Http.Headers.StringWithQualityHeaderValue?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354277377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354277377)
            
            //--TRIMMABLE-BOUNDARY-START(4296802419)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17181704307)
                    this.Any = new $.$mep.Microsoft.Extensions.Primitives.StringSegment().$ctor$4("*");
                    //--TRIMMABLE-BOUNDARY-END(17181704307)
                    
                }
                {
                    this.QualityComparer = new $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296802419)
            
            static $h = 1835123;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361573491),
    {
      "p": 1835123,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066606195,
        "f": 50331681
      },
      "n": "QualityComparer",
      "d": 1835123,
      "h": 34361573491,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34361573491)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476671603),
    {
      "r": 655361,
      "p": [
        {
          "n": "stringWithQuality1",
          "p": 1769587
        },
        {
          "n": "stringWithQuality2",
          "p": 1769587
        }
      ],
      "n": "Compare",
      "d": 1835123,
      "h": 21476671603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476671603)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181704307),
    {
      "t": 852053,
      "n": "Any",
      "d": 1835123,
      "h": 17181704307,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181704307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591769715),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1835123,
      "h": 8591769715,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8591769715)
  ],
  "i": [$.$$.System.Collections.Generic.IComparer$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h
  ],
  "h": 1835123
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue) ]; }
            static get $fullName() { return `StringWithQualityHeaderValueComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835123)
        
        
        //--TRIMMABLE-BOUNDARY-START(393331)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParser", ($self) => class CookieHeaderParser extends $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue)
        {
            //--TRIMMABLE-BOUNDARY-START(4295360627)
            $ctor$2(/*bool*/ supportsMultipleValues)
            {
                super.$ctor$1(supportsMultipleValues);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360627)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590327923, 51540590707)
            /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*out CookieHeaderValue?*/ cookieValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cookieValue.$v = null;
                /*var*/ let parsedName;
                /*var*/ let parsedValue;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.TryParseValue(value, index, this.SupportsMultipleValues, $.$ref(() => parsedName, ($v) => parsedName = $v, $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment)), $.$ref(() => parsedValue, ($v) => parsedValue = $v, $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment))))
                {
                    return false;
                }
                if (parsedName === null || parsedValue === null)
                {
                    return true;
                }
                cookieValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue().$ctor$2($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedName), $.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedValue));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590327923, 51540590707)
            
            static $h = 393331;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8590327923, 51540590707),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 852053
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "cookieValue",
          "p": 524403,
          "f": 2
        }
      ],
      "n": "TryParseValue",
      "d": 393331,
      "h": 8590327923,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590327923, 51540590707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360627),
    {
      "p": [
        {
          "n": "supportsMultipleValues",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393331,
      "h": 4295360627,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295360627)
  ],
  "h": 393331
}; }
            static get $b() { return $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue); }
            static get $fullName() { return `CookieHeaderParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393331)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376371)
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.ObjectCollection<>", (T) => $asm.$gt("$mnhh.Microsoft.Net.Http.Headers.ObjectCollection<>", [T], ($self) => class ObjectCollection$$ extends $.$$.System.Collections.ObjectModel.Collection$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(34361114739)
            /*Action<T>*/ static DefaultValidator = null;
            //--TRIMMABLE-BOUNDARY-END(34361114739)
            
            //--TRIMMABLE-BOUNDARY-START(38656082035)
            /*ObjectCollection<T>*/ static EmptyReadOnlyCollection = null;
            //--TRIMMABLE-BOUNDARY-END(38656082035)
            
            //--TRIMMABLE-BOUNDARY-START(4296343667)
            /*Action<T>*/ _validator = null;
            //--TRIMMABLE-BOUNDARY-END(4296343667)
            
            //--TRIMMABLE-BOUNDARY-START(30066147443)
            static /*IList<T> */ CreateInnerList(/*bool*/ isReadOnly, /*IEnumerable<T>?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066147443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let list = other === null ? new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1() : new ($.$$.System.Collections.Generic.List$$(T))().$ctor$2(other);
                if (isReadOnly)
                {
                    return new ($.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(T))().$ctor$1(list);
                }
                else 
                {
                    return list;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066147443)
            
            //--TRIMMABLE-BOUNDARY-START(12886278259)
            $ctor$3()
            {
                this.$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).DefaultValidator, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886278259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278259)
            
            //--TRIMMABLE-BOUNDARY-START(17181245555)
            $ctor$4(/*Action<T>*/ validator, /*bool*/ isReadOnly)
            {
                super.$ctor$2($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).CreateInnerList(isReadOnly, null));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181245555);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._validator = validator;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181245555)
            
            //--TRIMMABLE-BOUNDARY-START(21476212851)
            $ctor$5(/*IEnumerable<T>*/ other, /*bool*/ isReadOnly)
            {
                super.$ctor$2($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).CreateInnerList(isReadOnly, other));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476212851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._validator = $.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).DefaultValidator;
                    var $en3 = this.Items.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this._validator.Invoke(item);
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476212851)
            
            //--TRIMMABLE-BOUNDARY-START(55835951219)
            /*bool */ get IsReadOnly()
            {
                return (this).System$Collections$Generic$ICollection$$$IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(55835951219)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51540983923, 77372850177)
            /*void */ InsertItem(/*int*/ index, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540983923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validator.Invoke(item);
                super.InsertItem(index, item);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51540983923, 77372850177)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60130918515, 116027555841)
            /*void */ SetItem(/*int*/ index, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130918515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._validator.Invoke(item);
                super.SetItem(index, item);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60130918515, 116027555841)
            
            //--TRIMMABLE-BOUNDARY-START(25771180147)
            static /*void */ CheckNotNull(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$box(item, T) === null)
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("item");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771180147)
            
            //--TRIMMABLE-BOUNDARY-START(8591310963)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(34361114739)
                    this.DefaultValidator = new ($.$$.System.Action$$(T))().$ctor($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T), $.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).CheckNotNull);
                    //--TRIMMABLE-BOUNDARY-END(34361114739)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38656082035)
                    this.EmptyReadOnlyCollection = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T))().$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).DefaultValidator, true);
                    //--TRIMMABLE-BOUNDARY-END(38656082035)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591310963)
            
            static $h = 1376371;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835951219),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835951219)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066147443),
    {
      "r": $.$$.System.Collections.Generic.IList$$(T).$h,
      "p": [
        {
          "n": "isReadOnly",
          "p": 262145
        },
        {
          "n": "other",
          "p": $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
          "f": 65
        }
      ],
      "n": "CreateInnerList",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066147443),
//--TRIMMABLE-BOUNDARY-START(ALL, 51540983923, 77372850177),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "InsertItem",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51540983923, 77372850177),
//--TRIMMABLE-BOUNDARY-START(ALL, 60130918515, 116027555841),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "SetItem",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60130918515, 116027555841),
//--TRIMMABLE-BOUNDARY-START(25771180147),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "CheckNotNull",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771180147)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361114739),
    {
      "t": $.$$.System.Action$$(T).$h,
      "n": "DefaultValidator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34361114739),
//--TRIMMABLE-BOUNDARY-START(38656082035),
    {
      "t": this.$h,
      "n": "EmptyReadOnlyCollection",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38656082035),
//--TRIMMABLE-BOUNDARY-START(4296343667),
    {
      "t": $.$$.System.Action$$(T).$h,
      "n": "_validator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343667)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886278259),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886278259),
//--TRIMMABLE-BOUNDARY-START(17181245555),
    {
      "p": [
        {
          "n": "validator",
          "p": $.$$.System.Action$$(T).$h
        },
        {
          "n": "isReadOnly",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181245555),
//--TRIMMABLE-BOUNDARY-START(21476212851),
    {
      "p": [
        {
          "n": "other",
          "p": $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "isReadOnly",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476212851)
  ],
  "i": [$.$$.System.Collections.Generic.IList$$(T).$h,$.$$.System.Collections.Generic.ICollection$$(T).$h,62849025,62259201,$.$$.System.Collections.Generic.IReadOnlyList$$(T).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,62521345
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Collections.ObjectModel.Collection$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyList$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `ObjectCollection<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1376371)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http"))
//--TRIMMABLE-BOUNDARY-END(115)
