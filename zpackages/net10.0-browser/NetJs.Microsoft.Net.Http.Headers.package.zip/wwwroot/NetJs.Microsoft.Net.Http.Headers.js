
(function ($global, $, $$, $sm, $mep, $mwp, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Net.Http.Headers", 
    {"h":35537,"f":"Microsoft.Net.Http.Headers","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"HTTP header parser implementations.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Net.Http.Headers","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Net.Http.Headers","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.Net.Http.Headers.Tests","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser<>", (T) => $asm.$gt("$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser<>", [T], ($self) => class HttpHeaderParser$$ extends $.$$.System.Object
        {
            /*bool*/ _supportsMultipleValues = false;
            $ctor$1(/*bool*/ supportsMultipleValues)
            {
                super.$ctor();
                {
                    this._supportsMultipleValues = supportsMultipleValues;
                }
                return this;
            }
            /*bool */ get SupportsMultipleValues()
            {
                return this._supportsMultipleValues;
            }
            /*T? */ ParseValue(/*StringSegment*/ value, /*ref int*/ index)
            {
                ;
                /*var*/ let result;
                if (!this.TryParseValue(value, index, $.$ref(() => result, ($v) => result = $v, T)))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "The header contains invalid values at index {0}: '{1}'", $.$box(index.$v, $.$$.System.Int32), value.Value ?? "<null>"));
                }
                return result;
            }
            /*bool */ TryParseValues$1(/*IList<string>?*/ values, /*out IList<T>?*/ parsedValues)
            {
                return this.TryParseValues(values, false, parsedValues);
            }
            /*bool */ TryParseStrictValues(/*IList<string>?*/ values, /*out IList<T>?*/ parsedValues)
            {
                return this.TryParseValues(values, true, parsedValues);
            }
            /*bool */ TryParseValues(/*IList<string>?*/ values, /*bool*/ strict, /*out IList<T>?*/ parsedValues)
            {
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1(this._supportsMultipleValues);
                parsedValues.$v = null;
                /*List<T>?*/ let results = null;
                if (values === null)
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < values.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*var*/ let value = values.System$Collections$Generic$IList$$$get_Item(i, [$.$$.System.String]);
                    /*var*/ let index = 0;
                    while(!$.$$.System.String.IsNullOrEmpty(value) && index < value.length)
                    {
                        /*var*/ let output;
                        if (this.TryParseValue($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => output, ($v) => output = $v, T)))
                        {
                            if ($.$box(output, T) !== null)
                            {
                                if (results === null)
                                {
                                    results = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                                }
                                results.Add(output);
                            }
                        }
                        else if (strict)
                        {
                            return false;
                        }
                        else 
                        {
                            index++;
                        }
                    }
                }
                if (results !== null)
                {
                    parsedValues.$v = results;
                    return true;
                }
                return false;
            }
            /*IList<T> */ ParseValues$1(/*IList<string>?*/ values)
            {
                return this.ParseValues(values, false);
            }
            /*IList<T> */ ParseStrictValues(/*IList<string>?*/ values)
            {
                return this.ParseValues(values, true);
            }
            /*IList<T> */ ParseValues(/*IList<string>?*/ values, /*bool*/ strict)
            {
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1(this._supportsMultipleValues);
                /*var*/ let parsedValues = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                if (values === null)
                {
                    return parsedValues;
                }
                var $en2 = values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var value = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*int*/ let index = 0;
                        while(!$.$$.System.String.IsNullOrEmpty(value) && index < value.length)
                        {
                            /*var*/ let output;
                            if (this.TryParseValue($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => output, ($v) => output = $v, T)))
                            {
                                if ($.$box(output, T) !== null)
                                {
                                    parsedValues.Add(output);
                                }
                            }
                            else if (strict)
                            {
                                throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.InvariantCulture, "The header contains invalid values at index {0}: '{1}'", $.$box(index, $.$$.System.Int32), value));
                            }
                            else 
                            {
                                index++;
                            }
                        }
                    }
                }
                return parsedValues;
            }
            /*string */ ToString$1(/*object*/ value)
            {
                return $.$$.System.Object.ToString.call(value);
            }
            static $h = 1018577;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"SupportsMultipleValues","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153}],"m":[{"r":262145,"p":[{"n":"value","p":851970},{"n":"index","p":655361,"f":4},{"n":"parsedValue","p":T?.$h??1507328,"f":2}],"n":"TryParseValue","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777473},{"r":T?.$h??1507328,"p":[{"n":"value","p":851970},{"n":"index","p":655361,"f":4}],"n":"ParseValue","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217},{"r":262145,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$(T).$h,"f":2}],"n":"TryParseValues","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777345},{"r":262145,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$(T).$h,"f":2}],"n":"TryParseStrictValues","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777345},{"r":262145,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"strict","p":262145},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$(T).$h,"f":2}],"n":"TryParseValues","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777348},{"r":$.$$.System.Collections.Generic.IList$$(T).$h,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseValues","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16777345},{"r":$.$$.System.Collections.Generic.IList$$(T).$h,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseStrictValues","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777345},{"r":$.$$.System.Collections.Generic.IList$$(T).$h,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"strict","p":262145}],"n":"ParseValues","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777348},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"ToString","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777345}],"l":[{"t":262145,"n":"_supportsMultipleValues","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"supportsMultipleValues","p":262145}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777220}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HttpHeaderParser<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.BaseHeaderParser<>", (T) => $asm.$gt("$mnhh.Microsoft.Net.Http.Headers.BaseHeaderParser<>", [T], ($self) => class BaseHeaderParser$$ extends $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$(T)
        {
            $ctor$2(/*bool*/ supportsMultipleValues)
            {
                super.$ctor$1(supportsMultipleValues);
                {
                }
                return this;
            }
            /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*out T?*/ parsedValue)
            {
                parsedValue.$v = $.$default(T);
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value) || (index.$v === value.Length))
                {
                    return this.SupportsMultipleValues;
                }
                /*var*/ let separatorFound;
                /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(value, index.$v, this.SupportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                if (separatorFound && !this.SupportsMultipleValues)
                {
                    return false;
                }
                if (current === value.Length)
                {
                    if (this.SupportsMultipleValues)
                    {
                        index.$v = current;
                    }
                    return this.SupportsMultipleValues;
                }
                /*var*/ let result;
                /*var*/ let length = this.GetParsedValueLength(value, current, $.$ref(() => result, ($v) => result = $v, T));
                if (length === 0)
                {
                    return false;
                }
                current = ((current + length) | 0);
                current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(value, current, this.SupportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                if ((separatorFound && !this.SupportsMultipleValues) || (!separatorFound && (current < value.Length)))
                {
                    return false;
                }
                index.$v = current;
                parsedValue.$v = result;
                return true;
            }
            static $h = 101073;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"value","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":T?.$h??1507328,"f":2}],"n":"GetParsedValueLength","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777476},{"r":262145,"p":[{"n":"value","p":851970},{"n":"index","p":655361,"f":4},{"n":"parsedValue","p":T?.$h??1507328,"f":2}],"n":"TryParseValue","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16875521}],"c":[{"p":[{"n":"supportsMultipleValues","p":262145}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777220}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$(T); }
            static get $fullName() { return `BaseHeaderParser<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue", ($self) => class CacheControlHeaderValue extends $.$$.System.Object
        {
            /*string*/ static PublicString = null;
            /*string*/ static PrivateString = null;
            /*string*/ static MaxAgeString = null;
            /*string*/ static SharedMaxAgeString = null;
            /*string*/ static NoCacheString = null;
            /*string*/ static NoStoreString = null;
            /*string*/ static MaxStaleString = null;
            /*string*/ static MinFreshString = null;
            /*string*/ static NoTransformString = null;
            /*string*/ static OnlyIfCachedString = null;
            /*string*/ static MustRevalidateString = null;
            /*string*/ static ProxyRevalidateString = null;
            /*HttpHeaderParser<CacheControlHeaderValue>*/ static Parser = null;
            /*Action<StringSegment>*/ static CheckIsValidTokenAction = null;
            /*bool*/ _noCache = false;
            /*ICollection<StringSegment>?*/ _noCacheHeaders = null;
            /*bool*/ _noStore = false;
            /*TimeSpan?*/ _maxAge = null;
            /*TimeSpan?*/ _sharedMaxAge = null;
            /*bool*/ _maxStale = false;
            /*TimeSpan?*/ _maxStaleLimit = null;
            /*TimeSpan?*/ _minFresh = null;
            /*bool*/ _noTransform = false;
            /*bool*/ _onlyIfCached = false;
            /*bool*/ _public = false;
            /*bool*/ _private = false;
            /*ICollection<StringSegment>?*/ _privateHeaders = null;
            /*bool*/ _mustRevalidate = false;
            /*bool*/ _proxyRevalidate = false;
            /*IList<NameValueHeaderValue>?*/ _extensions = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get NoCache()
            {
                return this._noCache;
            }
            /*bool */ set NoCache(value)
            {
                this._noCache = value;
            }
            /*ICollection<StringSegment> */ get NoCacheHeaders()
            {
                if (this._noCacheHeaders === null)
                {
                    this._noCacheHeaders = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                }
                return this._noCacheHeaders;
            }
            /*bool */ get NoStore()
            {
                return this._noStore;
            }
            /*bool */ set NoStore(value)
            {
                this._noStore = value;
            }
            /*TimeSpan? */ get MaxAge()
            {
                return this._maxAge;
            }
            /*TimeSpan? */ set MaxAge(value)
            {
                this._maxAge = value?.Clone() ?? null;
            }
            /*TimeSpan? */ get SharedMaxAge()
            {
                return this._sharedMaxAge;
            }
            /*TimeSpan? */ set SharedMaxAge(value)
            {
                this._sharedMaxAge = value?.Clone() ?? null;
            }
            /*bool */ get MaxStale()
            {
                return this._maxStale;
            }
            /*bool */ set MaxStale(value)
            {
                this._maxStale = value;
            }
            /*TimeSpan? */ get MaxStaleLimit()
            {
                return this._maxStaleLimit;
            }
            /*TimeSpan? */ set MaxStaleLimit(value)
            {
                this._maxStaleLimit = value?.Clone() ?? null;
            }
            /*TimeSpan? */ get MinFresh()
            {
                return this._minFresh;
            }
            /*TimeSpan? */ set MinFresh(value)
            {
                this._minFresh = value?.Clone() ?? null;
            }
            /*bool */ get NoTransform()
            {
                return this._noTransform;
            }
            /*bool */ set NoTransform(value)
            {
                this._noTransform = value;
            }
            /*bool */ get OnlyIfCached()
            {
                return this._onlyIfCached;
            }
            /*bool */ set OnlyIfCached(value)
            {
                this._onlyIfCached = value;
            }
            /*bool */ get Public()
            {
                return this._public;
            }
            /*bool */ set Public(value)
            {
                this._public = value;
            }
            /*bool */ get Private()
            {
                return this._private;
            }
            /*bool */ set Private(value)
            {
                this._private = value;
            }
            /*ICollection<StringSegment> */ get PrivateHeaders()
            {
                if (this._privateHeaders === null)
                {
                    this._privateHeaders = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                }
                return this._privateHeaders;
            }
            /*bool */ get MustRevalidate()
            {
                return this._mustRevalidate;
            }
            /*bool */ set MustRevalidate(value)
            {
                this._mustRevalidate = value;
            }
            /*bool */ get ProxyRevalidate()
            {
                return this._proxyRevalidate;
            }
            /*bool */ set ProxyRevalidate(value)
            {
                this._proxyRevalidate = value;
            }
            /*IList<NameValueHeaderValue> */ get Extensions()
            {
                if (this._extensions === null)
                {
                    this._extensions = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3();
                }
                return this._extensions;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._noStore, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoStoreString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._noTransform, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoTransformString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._onlyIfCached, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.OnlyIfCachedString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._public, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.PublicString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._mustRevalidate, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MustRevalidateString);
                $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueIfRequired(sb, this._proxyRevalidate, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.ProxyRevalidateString);
                if (this._noCache)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoCacheString);
                    if ((this._noCacheHeaders !== null) && (this._noCacheHeaders.System$Collections$Generic$ICollection$$$Count > 0))
                    {
                        sb.Append$19("=\"");
                        $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValues(sb, this._noCacheHeaders);
                        sb.Append$3(/*\"*/ 34);
                    }
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._maxAge))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MaxAgeString);
                    sb.Append$3(/*=*/ 61);
                    sb.Append$19($.$$.System.Int32.ToString$1.call(($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._maxAge).TotalSeconds, $.$$.System.Int32)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._sharedMaxAge))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.SharedMaxAgeString);
                    sb.Append$3(/*=*/ 61);
                    sb.Append$19($.$$.System.Int32.ToString$1.call(($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._sharedMaxAge).TotalSeconds, $.$$.System.Int32)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                if (this._maxStale)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MaxStaleString);
                    if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._maxStaleLimit))
                    {
                        sb.Append$3(/*=*/ 61);
                        sb.Append$19($.$$.System.Int32.ToString$1.call(($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._maxStaleLimit).TotalSeconds, $.$$.System.Int32)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                    }
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._minFresh))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MinFreshString);
                    sb.Append$3(/*=*/ 61);
                    sb.Append$19($.$$.System.Int32.ToString$1.call(($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._minFresh).TotalSeconds, $.$$.System.Int32)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                if (this._private)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.PrivateString);
                    if ((this._privateHeaders !== null) && (this._privateHeaders.System$Collections$Generic$ICollection$$$Count > 0))
                    {
                        sb.Append$19("=\"");
                        $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValues(sb, this._privateHeaders);
                        sb.Append$3(/*\"*/ 34);
                    }
                }
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString$1(this._extensions, /*,*/ 44, false, sb);
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.ToString.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if ((this._noCache !== other._noCache) || (this._noStore !== other._noStore) || (this._maxAge !== other._maxAge) || (this._sharedMaxAge !== other._sharedMaxAge) || (this._maxStale !== other._maxStale) || (this._maxStaleLimit !== other._maxStaleLimit) || (this._minFresh !== other._minFresh) || (this._noTransform !== other._noTransform) || (this._onlyIfCached !== other._onlyIfCached) || (this._public !== other._public) || (this._private !== other._private) || (this._mustRevalidate !== other._mustRevalidate) || (this._proxyRevalidate !== other._proxyRevalidate))
                {
                    return false;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections($.$mep.Microsoft.Extensions.Primitives.StringSegment, this._noCacheHeaders, other._noCacheHeaders, $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase))
                {
                    return false;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections($.$mep.Microsoft.Extensions.Primitives.StringSegment, this._privateHeaders, other._privateHeaders, $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase))
                {
                    return false;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._extensions, other._extensions))
                {
                    return false;
                }
                return true;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*int*/ let result = $.$$.System.Boolean.GetHashCode.call(this._noCache) ^ ($.$$.System.Boolean.GetHashCode.call(this._noStore) << 1) ^ ($.$$.System.Boolean.GetHashCode.call(this._maxStale) << 2) ^ ($.$$.System.Boolean.GetHashCode.call(this._noTransform) << 3) ^ ($.$$.System.Boolean.GetHashCode.call(this._onlyIfCached) << 4) ^ ($.$$.System.Boolean.GetHashCode.call(this._public) << 5) ^ ($.$$.System.Boolean.GetHashCode.call(this._private) << 6) ^ ($.$$.System.Boolean.GetHashCode.call(this._mustRevalidate) << 7) ^ ($.$$.System.Boolean.GetHashCode.call(this._proxyRevalidate) << 8);
                result = result ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._maxAge) ? $.$$.System.TimeSpan.GetHashCode.call($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._maxAge)) ^ 1 : 0) ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._sharedMaxAge) ? $.$$.System.TimeSpan.GetHashCode.call($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._sharedMaxAge)) ^ 2 : 0) ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._maxStaleLimit) ? $.$$.System.TimeSpan.GetHashCode.call($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._maxStaleLimit)) ^ 4 : 0) ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this._minFresh) ? $.$$.System.TimeSpan.GetHashCode.call($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this._minFresh)) ^ 8 : 0);
                if ((this._noCacheHeaders !== null) && (this._noCacheHeaders.System$Collections$Generic$ICollection$$$Count > 0))
                {
                    var $en3 = this._noCacheHeaders.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var noCacheHeader = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result = result ^ $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(noCacheHeader);
                        }
                    }
                }
                if ((this._privateHeaders !== null) && (this._privateHeaders.System$Collections$Generic$ICollection$$$Count > 0))
                {
                    var $en3 = this._privateHeaders.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var privateHeader = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result = result ^ $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(privateHeader);
                        }
                    }
                }
                if ((this._extensions !== null) && (this._extensions.System$Collections$Generic$ICollection$$$Count > 0))
                {
                    var $en3 = this._extensions.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var extension = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result = result ^ $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode.call(extension);
                        }
                    }
                }
                return result;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.GetHashCode.apply(this, arguments); }
            static /*CacheControlHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                /*var*/ let result = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
                if (result === null)
                {
                    throw new $.$$.System.FormatException().$ctor$12("No cache directives found.");
                }
                return result;
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out CacheControlHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                if ($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue) && parsedValue.$v !== null)
                {
                    return true;
                }
                parsedValue.$v = null;
                return false;
            }
            static /*int */ GetCacheControlLength(/*StringSegment*/ input, /*int*/ startIndex, /*out CacheControlHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*var*/ let nameValueList = new ($.$$.System.Collections.Generic.List$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$1();
                while(current < input.Length)
                {
                    /*var*/ let nameValue;
                    if (!$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.TryParseValue(input, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => nameValue, ($v) => nameValue = $v, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue)))
                    {
                        return 0;
                    }
                    if (nameValue !== null)
                    {
                        nameValueList.Add(nameValue);
                    }
                }
                /*var*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue().$ctor$1();
                if (!$.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetCacheControlValues(result, nameValueList))
                {
                    return 0;
                }
                parsedValue.$v = result;
                return ((input.Length - startIndex) | 0);
            }
            static /*bool */ TrySetCacheControlValues(/*CacheControlHeaderValue*/ cc, /*List<NameValueHeaderValue>*/ nameValueList)
            {
                for(/*var*/ let i = 0; i < nameValueList.Count; i++)
                {
                    /*var*/ let nameValue = nameValueList.get_Item(i);
                    /*var*/ let name = nameValue.Name;
                    /*var*/ let success = true;
                    let $switchJumpState1;
                    $switchJumpStart1: while(true)
                    {
                        let $switch1 = $switchJumpState1 ?? (name.Length);
                        switch($switch1)
                        {
                            case 6:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.PublicString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._public, ($v) => cc._public = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 7:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MaxAgeString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.TimeSpan), () => cc._maxAge, ($v) => cc._maxAge = $v, null));
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.PrivateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetOptionalTokenList(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._private, ($v) => cc._private = $v, null), $.$ref(() => cc._privateHeaders, ($v) => cc._privateHeaders = $v, $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment)));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 8:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoCacheString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetOptionalTokenList(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._noCache, ($v) => cc._noCache = $v, null), $.$ref(() => cc._noCacheHeaders, ($v) => cc._noCacheHeaders = $v, $.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment)));
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoStoreString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._noStore, ($v) => cc._noStore = $v, null));
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.SharedMaxAgeString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.TimeSpan), () => cc._sharedMaxAge, ($v) => cc._sharedMaxAge = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 9:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MaxStaleString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = (($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(nameValue.Value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null))) || $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.TimeSpan), () => cc._maxStaleLimit, ($v) => cc._maxStaleLimit = $v, null)));
                                if (success)
                                {
                                    cc._maxStale = true;
                                }
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MinFreshString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTimeSpan(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.TimeSpan), () => cc._minFresh, ($v) => cc._minFresh = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 12:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.NoTransformString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._noTransform, ($v) => cc._noTransform = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 14:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.OnlyIfCachedString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._onlyIfCached, ($v) => cc._onlyIfCached = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 15:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.MustRevalidateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._mustRevalidate, ($v) => cc._mustRevalidate = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 16:
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.ProxyRevalidateString), name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                success = $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.TrySetTokenOnlyValue(nameValue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => cc._proxyRevalidate, ($v) => cc._proxyRevalidate = $v, null));
                            }
                            else 
                            {
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                            }
                            break;
                            default:
                            cc.Extensions.System$Collections$Generic$ICollection$$$Add(nameValue, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                            break;
                        }
                        break;
                    }
                    if (!success)
                    {
                        return false;
                    }
                }
                return true;
            }
            static /*bool */ TrySetTokenOnlyValue(/*NameValueHeaderValue*/ nameValue, /*ref bool*/ boolField)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(nameValue.Value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    return false;
                }
                boolField.$v = true;
                return true;
            }
            static /*bool */ TrySetOptionalTokenList(/*NameValueHeaderValue*/ nameValue, /*ref bool*/ boolField, /*ref ICollection<StringSegment>?*/ destination)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(nameValue.Value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    boolField.$v = true;
                    return true;
                }
                /*var*/ let valueString = nameValue.Value;
                if ((valueString.Length < 3) || (valueString.get_Item(0) !== /*\"*/ 34) || (valueString.get_Item(((valueString.Length - 1) | 0)) !== /*\"*/ 34))
                {
                    return false;
                }
                /*var*/ let current = 1;
                /*var*/ let maxLength = ((valueString.Length - 1) | 0);
                /*var*/ let originalValueCount = destination.$v === null ? 0 : destination.$v.System$Collections$Generic$ICollection$$$Count;
                while(current < maxLength)
                {
                    /*var*/ let separatorFound;
                    current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(valueString, current, true, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                    if (current === maxLength)
                    {
                        break;
                    }
                    /*var*/ let tokenLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(valueString, current);
                    if (tokenLength === 0)
                    {
                        return false;
                    }
                    if (destination.$v === null)
                    {
                        destination.$v = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.CheckIsValidTokenAction, false);
                    }
                    destination.$v.System$Collections$Generic$ICollection$$$Add(valueString.Subsegment(current, tokenLength), [$.$mep.Microsoft.Extensions.Primitives.StringSegment]);
                    current = ((current + tokenLength) | 0);
                }
                if ((destination.$v !== null) && (destination.$v.System$Collections$Generic$ICollection$$$Count > originalValueCount))
                {
                    boolField.$v = true;
                    return true;
                }
                return false;
            }
            static /*bool */ TrySetTimeSpan(/*NameValueHeaderValue*/ nameValue, /*ref TimeSpan?*/ timeSpan)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(nameValue.Value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    return false;
                }
                /*int*/ let seconds;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt32(nameValue.Value, $.$ref(() => seconds, ($v) => seconds = $v, $.$$.System.Int32)))
                {
                    return false;
                }
                timeSpan.$v = new $.$$.System.TimeSpan().$ctor$6(0, 0, seconds);
                return true;
            }
            static /*void */ AppendValueIfRequired(/*StringBuilder*/ sb, /*bool*/ appendValue, /*string*/ value)
            {
                if (appendValue)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.AppendValueWithSeparatorIfRequired(sb, value);
                }
            }
            static /*void */ AppendValueWithSeparatorIfRequired(/*StringBuilder*/ sb, /*string*/ value)
            {
                if (sb.Length > 0)
                {
                    sb.Append$19(", ");
                }
                sb.Append$19(value);
            }
            static /*void */ AppendValues(/*StringBuilder*/ sb, /*IEnumerable<StringSegment>*/ values)
            {
                /*var*/ let first = true;
                var $en2 = values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var value = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (first)
                        {
                            first = false;
                        }
                        else 
                        {
                            sb.Append$19(", ");
                        }
                        sb.Append$15(value.AsSpan());
                    }
                }
            }
            static /*void */ CheckIsValidToken(/*StringSegment*/ item)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(item, "item");
            }
            //default member initializer
            constructor()
            {
                super();
                this._maxAge = null;
                this._sharedMaxAge = null;
                this._maxStaleLimit = null;
                this._minFresh = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PublicString = "public";
                }
                {
                    this.PrivateString = "private";
                }
                {
                    this.MaxAgeString = "max-age";
                }
                {
                    this.SharedMaxAgeString = "s-maxage";
                }
                {
                    this.NoCacheString = "no-cache";
                }
                {
                    this.NoStoreString = "no-store";
                }
                {
                    this.MaxStaleString = "max-stale";
                }
                {
                    this.MinFreshString = "min-fresh";
                }
                {
                    this.NoTransformString = "no-transform";
                }
                {
                    this.OnlyIfCachedString = "only-if-cached";
                }
                {
                    this.MustRevalidateString = "must-revalidate";
                }
                {
                    this.ProxyRevalidateString = "proxy-revalidate";
                }
                {
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.GetCacheControlLength));
                }
                {
                    this.CheckIsValidTokenAction = new ($.$$.System.Action$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue.CheckIsValidToken);
                }
            }
            static $h = 166609;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":141734087377,"f":50331649},"s":{"r":0,"d":0,"h":146029054673,"f":83886081},"n":"NoCache","d":166609,"h":137439120081,"f":2097153},{"p":$.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"g":{"r":0,"d":0,"h":154618989265,"f":50331649},"n":"NoCacheHeaders","d":166609,"h":150324021969,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":163208923857,"f":50331649},"s":{"r":0,"d":0,"h":167503891153,"f":83886081},"n":"NoStore","d":166609,"h":158913956561,"f":2097153},{"p":$.$typeNullable($.$$.System.TimeSpan).$h,"g":{"r":0,"d":0,"h":176093825745,"f":50331649},"s":{"r":0,"d":0,"h":180388793041,"f":83886081},"n":"MaxAge","d":166609,"h":171798858449,"f":2097153},{"p":$.$typeNullable($.$$.System.TimeSpan).$h,"g":{"r":0,"d":0,"h":188978727633,"f":50331649},"s":{"r":0,"d":0,"h":193273694929,"f":83886081},"n":"SharedMaxAge","d":166609,"h":184683760337,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":201863629521,"f":50331649},"s":{"r":0,"d":0,"h":206158596817,"f":83886081},"n":"MaxStale","d":166609,"h":197568662225,"f":2097153},{"p":$.$typeNullable($.$$.System.TimeSpan).$h,"g":{"r":0,"d":0,"h":214748531409,"f":50331649},"s":{"r":0,"d":0,"h":219043498705,"f":83886081},"n":"MaxStaleLimit","d":166609,"h":210453564113,"f":2097153},{"p":$.$typeNullable($.$$.System.TimeSpan).$h,"g":{"r":0,"d":0,"h":227633433297,"f":50331649},"s":{"r":0,"d":0,"h":231928400593,"f":83886081},"n":"MinFresh","d":166609,"h":223338466001,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":240518335185,"f":50331649},"s":{"r":0,"d":0,"h":244813302481,"f":83886081},"n":"NoTransform","d":166609,"h":236223367889,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":253403237073,"f":50331649},"s":{"r":0,"d":0,"h":257698204369,"f":83886081},"n":"OnlyIfCached","d":166609,"h":249108269777,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":266288138961,"f":50331649},"s":{"r":0,"d":0,"h":270583106257,"f":83886081},"n":"Public","d":166609,"h":261993171665,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":279173040849,"f":50331649},"s":{"r":0,"d":0,"h":283468008145,"f":83886081},"n":"Private","d":166609,"h":274878073553,"f":2097153},{"p":$.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"g":{"r":0,"d":0,"h":292057942737,"f":50331649},"n":"PrivateHeaders","d":166609,"h":287762975441,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":300647877329,"f":50331649},"s":{"r":0,"d":0,"h":304942844625,"f":83886081},"n":"MustRevalidate","d":166609,"h":296352910033,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":313532779217,"f":50331649},"s":{"r":0,"d":0,"h":317827746513,"f":83886081},"n":"ProxyRevalidate","d":166609,"h":309237811921,"f":2097153},{"p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"g":{"r":0,"d":0,"h":326417681105,"f":50331649},"n":"Extensions","d":166609,"h":322122713809,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":166609,"h":330712648401,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":166609,"h":335007615697,"f":16809985},{"r":655361,"n":"GetHashCode","d":166609,"h":339302582993,"f":16809985},{"r":166609,"p":[{"n":"input","p":851970}],"n":"Parse","d":166609,"h":343597550289,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":166609,"f":2}],"n":"TryParse","d":166609,"h":347892517585,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":166609,"f":2}],"n":"GetCacheControlLength","d":166609,"h":352187484881,"f":16777250},{"r":262145,"p":[{"n":"cc","p":166609},{"n":"nameValueList","p":$.$$.System.Collections.Generic.List$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h}],"n":"TrySetCacheControlValues","d":166609,"h":356482452177,"f":16777250},{"r":262145,"p":[{"n":"nameValue","p":1346257},{"n":"boolField","p":262145,"f":4}],"n":"TrySetTokenOnlyValue","d":166609,"h":360777419473,"f":16777250},{"r":262145,"p":[{"n":"nameValue","p":1346257},{"n":"boolField","p":262145,"f":4},{"n":"destination","p":$.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"f":4}],"n":"TrySetOptionalTokenList","d":166609,"h":365072386769,"f":16777250},{"r":262145,"p":[{"n":"nameValue","p":1346257},{"n":"timeSpan","p":$.$typeNullable($.$$.System.TimeSpan).$h,"f":4}],"n":"TrySetTimeSpan","d":166609,"h":369367354065,"f":16777250},{"r":65537,"p":[{"n":"sb","p":122814465},{"n":"appendValue","p":262145},{"n":"value","p":1310721}],"n":"AppendValueIfRequired","d":166609,"h":373662321361,"f":16777250},{"r":65537,"p":[{"n":"sb","p":122814465},{"n":"value","p":1310721}],"n":"AppendValueWithSeparatorIfRequired","d":166609,"h":377957288657,"f":16777250},{"r":65537,"p":[{"n":"sb","p":122814465},{"n":"values","p":$.$$.System.Collections.Generic.IEnumerable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h}],"n":"AppendValues","d":166609,"h":382252255953,"f":16777250},{"r":65537,"p":[{"n":"item","p":851970}],"n":"CheckIsValidToken","d":166609,"h":386547223249,"f":16777250}],"l":[{"t":1310721,"n":"PublicString","d":166609,"h":4295133905,"f":4194337},{"t":1310721,"n":"PrivateString","d":166609,"h":8590101201,"f":4194337},{"t":1310721,"n":"MaxAgeString","d":166609,"h":12885068497,"f":4194337},{"t":1310721,"n":"SharedMaxAgeString","d":166609,"h":17180035793,"f":4194337},{"t":1310721,"n":"NoCacheString","d":166609,"h":21475003089,"f":4194337},{"t":1310721,"n":"NoStoreString","d":166609,"h":25769970385,"f":4194337},{"t":1310721,"n":"MaxStaleString","d":166609,"h":30064937681,"f":4194337},{"t":1310721,"n":"MinFreshString","d":166609,"h":34359904977,"f":4194337},{"t":1310721,"n":"NoTransformString","d":166609,"h":38654872273,"f":4194337},{"t":1310721,"n":"OnlyIfCachedString","d":166609,"h":42949839569,"f":4194337},{"t":1310721,"n":"MustRevalidateString","d":166609,"h":47244806865,"f":4194337},{"t":1310721,"n":"ProxyRevalidateString","d":166609,"h":51539774161,"f":4194337},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CacheControlHeaderValue).$h,"n":"Parser","d":166609,"h":55834741457,"f":4194338},{"t":$.$$.System.Action$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"n":"CheckIsValidTokenAction","d":166609,"h":60129708753,"f":4194338},{"t":262145,"n":"_noCache","d":166609,"h":64424676049,"f":4194306},{"t":$.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"n":"_noCacheHeaders","d":166609,"h":68719643345,"f":4194306},{"t":262145,"n":"_noStore","d":166609,"h":73014610641,"f":4194306},{"t":$.$typeNullable($.$$.System.TimeSpan).$h,"n":"_maxAge","d":166609,"h":77309577937,"f":4194306},{"t":$.$typeNullable($.$$.System.TimeSpan).$h,"n":"_sharedMaxAge","d":166609,"h":81604545233,"f":4194306},{"t":262145,"n":"_maxStale","d":166609,"h":85899512529,"f":4194306},{"t":$.$typeNullable($.$$.System.TimeSpan).$h,"n":"_maxStaleLimit","d":166609,"h":90194479825,"f":4194306},{"t":$.$typeNullable($.$$.System.TimeSpan).$h,"n":"_minFresh","d":166609,"h":94489447121,"f":4194306},{"t":262145,"n":"_noTransform","d":166609,"h":98784414417,"f":4194306},{"t":262145,"n":"_onlyIfCached","d":166609,"h":103079381713,"f":4194306},{"t":262145,"n":"_public","d":166609,"h":107374349009,"f":4194306},{"t":262145,"n":"_private","d":166609,"h":111669316305,"f":4194306},{"t":$.$$.System.Collections.Generic.ICollection$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"n":"_privateHeaders","d":166609,"h":115964283601,"f":4194306},{"t":262145,"n":"_mustRevalidate","d":166609,"h":120259250897,"f":4194306},{"t":262145,"n":"_proxyRevalidate","d":166609,"h":124554218193,"f":4194306},{"t":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"n":"_extensions","d":166609,"h":128849185489,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":166609,"h":133144152785,"f":16777217}],"h":166609}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `CacheControlHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue", ($self) => class RangeConditionHeaderValue extends $.$$.System.Object
        {
            /*HttpHeaderParser<RangeConditionHeaderValue>*/ static Parser = null;
            /*DateTimeOffset?*/ _lastModified = null;
            /*EntityTagHeaderValue?*/ _entityTag = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*DateTimeOffset*/ lastModified)
            {
                super.$ctor();
                {
                    this._lastModified = lastModified;
                }
                return this;
            }
            $ctor$4(/*EntityTagHeaderValue*/ entityTag)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(entityTag, "entityTag");
                    this._entityTag = entityTag;
                }
                return this;
            }
            $ctor$3(/*string?*/ entityTag)
            {
                this.$ctor$4(new $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue().$ctor$3($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(entityTag)));
                {
                }
                return this;
            }
            /*DateTimeOffset? */ get LastModified()
            {
                return this._lastModified;
            }
            /*EntityTagHeaderValue? */ get EntityTag()
            {
                return this._entityTag;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this._entityTag === null)
                {
                    return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatDate$1($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(this._lastModified));
                }
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.ToString.call(this._entityTag);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.ToString.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (this._entityTag === null)
                {
                    return (other._lastModified !== null) && ($.$$.System.DateTimeOffset.op_Equality($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(this._lastModified), $.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(other._lastModified)));
                }
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.Equals$1.call(this._entityTag, other._entityTag);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if (this._entityTag === null)
                {
                    return $.$$.System.DateTimeOffset.GetHashCode.call($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(this._lastModified));
                }
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetHashCode.call(this._entityTag);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.GetHashCode.apply(this, arguments); }
            static /*RangeConditionHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out RangeConditionHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*int */ GetRangeConditionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeConditionHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (((startIndex + 1) | 0) >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*DateTimeOffset*/ let date = $.$$.System.DateTimeOffset.MinValue;
                /*EntityTagHeaderValue?*/ let entityTag = null;
                /*var*/ let firstChar = input.get_Item(current);
                /*var*/ let secondChar = input.get_Item(((current + 1) | 0));
                if ((firstChar === /*\"*/ 34) || (((firstChar === /*w*/ 119) || (firstChar === /*W*/ 87)) && (secondChar === /*/*/ 47)))
                {
                    /*var*/ let entityTagLength = $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetEntityTagLength(input, current, $.$ref(() => entityTag, ($v) => entityTag = $v, $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue));
                    if (entityTagLength === 0)
                    {
                        return 0;
                    }
                    current = ((current + entityTagLength) | 0);
                    if (current !== input.Length)
                    {
                        return 0;
                    }
                }
                else 
                {
                    if (!$.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TryStringToDate(input.Subsegment$1(current), $.$ref(() => date, ($v) => date = $v, $.$$.System.DateTimeOffset)))
                    {
                        return 0;
                    }
                    current = input.Length;
                }
                parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue().$ctor$1();
                if (entityTag === null)
                {
                    parsedValue.$v._lastModified = date;
                }
                else 
                {
                    parsedValue.$v._entityTag = entityTag;
                }
                return ((current - startIndex) | 0);
            }
            //default member initializer
            constructor()
            {
                super();
                this._lastModified = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue.GetRangeConditionLength));
                }
            }
            static $h = 1477329;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeNullable($.$$.System.DateTimeOffset).$h,"g":{"r":0,"d":0,"h":38656182993,"f":50331649},"n":"LastModified","d":1477329,"h":34361215697,"f":2097153},{"p":625361,"g":{"r":0,"d":0,"h":47246117585,"f":50331649},"n":"EntityTag","d":1477329,"h":42951150289,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":1477329,"h":51541084881,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1477329,"h":55836052177,"f":16809985},{"r":655361,"n":"GetHashCode","d":1477329,"h":60131019473,"f":16809985},{"r":1477329,"p":[{"n":"input","p":851970}],"n":"Parse","d":1477329,"h":64425986769,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":1477329,"f":2}],"n":"TryParse","d":1477329,"h":68720954065,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":1477329,"f":2}],"n":"GetRangeConditionLength","d":1477329,"h":73015921361,"f":16777250}],"l":[{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeConditionHeaderValue).$h,"n":"Parser","d":1477329,"h":4296444625,"f":4194338},{"t":$.$typeNullable($.$$.System.DateTimeOffset).$h,"n":"_lastModified","d":1477329,"h":8591411921,"f":4194306},{"t":625361,"n":"_entityTag","d":1477329,"h":12886379217,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1477329,"h":17181346513,"f":16777218},{"p":[{"n":"lastModified","p":34471937}],"n":".ctor","o":"$ctor$2","d":1477329,"h":21476313809,"f":16777217},{"p":[{"n":"entityTag","p":625361}],"n":".ctor","o":"$ctor$4","d":1477329,"h":25771281105,"f":16777217},{"p":[{"n":"entityTag","p":1310721}],"n":".ctor","o":"$ctor$3","d":1477329,"h":30066248401,"f":16777217}],"h":1477329}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RangeConditionHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HeaderQuality", ($self) => class HeaderQuality
        {
            /*double*/ static Match = 1;
            /*double*/ static NoMatch = 0;
            static $h = 887505;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1179649,"n":"Match","d":887505,"h":4295854801,"f":4194337},{"t":1179649,"n":"NoMatch","d":887505,"h":8590822097,"f":4194337}],"h":887505}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HeaderQuality`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HeaderNames", ($self) => class HeaderNames
        {
            /*string*/ static PseudoHeaderNamesObsoletionMessage = null;
            /*string*/ static Accept = null;
            /*string*/ static AcceptCharset = null;
            /*string*/ static AcceptEncoding = null;
            /*string*/ static AcceptLanguage = null;
            /*string*/ static AcceptRanges = null;
            /*string*/ static AccessControlAllowCredentials = null;
            /*string*/ static AccessControlAllowHeaders = null;
            /*string*/ static AccessControlAllowMethods = null;
            /*string*/ static AccessControlAllowOrigin = null;
            /*string*/ static AccessControlExposeHeaders = null;
            /*string*/ static AccessControlMaxAge = null;
            /*string*/ static AccessControlRequestHeaders = null;
            /*string*/ static AccessControlRequestMethod = null;
            /*string*/ static Age = null;
            /*string*/ static Allow = null;
            /*string*/ static AltSvc = null;
            /*string*/ static Authority = null;
            /*string*/ static Authorization = null;
            /*string*/ static Baggage = null;
            /*string*/ static CacheControl = null;
            /*string*/ static Connection = null;
            /*string*/ static ContentDisposition = null;
            /*string*/ static ContentEncoding = null;
            /*string*/ static ContentLanguage = null;
            /*string*/ static ContentLength = null;
            /*string*/ static ContentLocation = null;
            /*string*/ static ContentMD5 = null;
            /*string*/ static ContentRange = null;
            /*string*/ static ContentSecurityPolicy = null;
            /*string*/ static ContentSecurityPolicyReportOnly = null;
            /*string*/ static ContentType = null;
            /*string*/ static CorrelationContext = null;
            /*string*/ static Cookie = null;
            /*string*/ static Date = null;
            /*string*/ static DNT = null;
            /*string*/ static ETag = null;
            /*string*/ static Expires = null;
            /*string*/ static Expect = null;
            /*string*/ static From = null;
            /*string*/ static GrpcAcceptEncoding = null;
            /*string*/ static GrpcEncoding = null;
            /*string*/ static GrpcMessage = null;
            /*string*/ static GrpcStatus = null;
            /*string*/ static GrpcTimeout = null;
            /*string*/ static Host = null;
            /*string*/ static KeepAlive = null;
            /*string*/ static IfMatch = null;
            /*string*/ static IfModifiedSince = null;
            /*string*/ static IfNoneMatch = null;
            /*string*/ static IfRange = null;
            /*string*/ static IfUnmodifiedSince = null;
            /*string*/ static LastModified = null;
            /*string*/ static Link = null;
            /*string*/ static Location = null;
            /*string*/ static MaxForwards = null;
            /*string*/ static Method = null;
            /*string*/ static Origin = null;
            /*string*/ static Path = null;
            /*string*/ static Pragma = null;
            /*string*/ static ProxyAuthenticate = null;
            /*string*/ static ProxyAuthorization = null;
            /*string*/ static ProxyConnection = null;
            /*string*/ static Range = null;
            /*string*/ static Referer = null;
            /*string*/ static RetryAfter = null;
            /*string*/ static RequestId = null;
            /*string*/ static Scheme = null;
            /*string*/ static SecWebSocketAccept = null;
            /*string*/ static SecWebSocketKey = null;
            /*string*/ static SecWebSocketProtocol = null;
            /*string*/ static SecWebSocketVersion = null;
            /*string*/ static SecWebSocketExtensions = null;
            /*string*/ static Server = null;
            /*string*/ static SetCookie = null;
            /*string*/ static Status = null;
            /*string*/ static StrictTransportSecurity = null;
            /*string*/ static TE = null;
            /*string*/ static Trailer = null;
            /*string*/ static TransferEncoding = null;
            /*string*/ static Translate = null;
            /*string*/ static TraceParent = null;
            /*string*/ static TraceState = null;
            /*string*/ static Upgrade = null;
            /*string*/ static UpgradeInsecureRequests = null;
            /*string*/ static UserAgent = null;
            /*string*/ static Vary = null;
            /*string*/ static Via = null;
            /*string*/ static Warning = null;
            /*string*/ static WebSocketSubProtocols = null;
            /*string*/ static WWWAuthenticate = null;
            /*string*/ static XContentTypeOptions = null;
            /*string*/ static XFrameOptions = null;
            /*string*/ static XPoweredBy = null;
            /*string*/ static XRequestedWith = null;
            /*string*/ static XUACompatible = null;
            /*string*/ static XXSSProtection = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.PseudoHeaderNamesObsoletionMessage = "This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.";
                }
                {
                    this.Accept = "Accept";
                }
                {
                    this.AcceptCharset = "Accept-Charset";
                }
                {
                    this.AcceptEncoding = "Accept-Encoding";
                }
                {
                    this.AcceptLanguage = "Accept-Language";
                }
                {
                    this.AcceptRanges = "Accept-Ranges";
                }
                {
                    this.AccessControlAllowCredentials = "Access-Control-Allow-Credentials";
                }
                {
                    this.AccessControlAllowHeaders = "Access-Control-Allow-Headers";
                }
                {
                    this.AccessControlAllowMethods = "Access-Control-Allow-Methods";
                }
                {
                    this.AccessControlAllowOrigin = "Access-Control-Allow-Origin";
                }
                {
                    this.AccessControlExposeHeaders = "Access-Control-Expose-Headers";
                }
                {
                    this.AccessControlMaxAge = "Access-Control-Max-Age";
                }
                {
                    this.AccessControlRequestHeaders = "Access-Control-Request-Headers";
                }
                {
                    this.AccessControlRequestMethod = "Access-Control-Request-Method";
                }
                {
                    this.Age = "Age";
                }
                {
                    this.Allow = "Allow";
                }
                {
                    this.AltSvc = "Alt-Svc";
                }
                {
                    this.Authority = ":authority";
                }
                {
                    this.Authorization = "Authorization";
                }
                {
                    this.Baggage = "baggage";
                }
                {
                    this.CacheControl = "Cache-Control";
                }
                {
                    this.Connection = "Connection";
                }
                {
                    this.ContentDisposition = "Content-Disposition";
                }
                {
                    this.ContentEncoding = "Content-Encoding";
                }
                {
                    this.ContentLanguage = "Content-Language";
                }
                {
                    this.ContentLength = "Content-Length";
                }
                {
                    this.ContentLocation = "Content-Location";
                }
                {
                    this.ContentMD5 = "Content-MD5";
                }
                {
                    this.ContentRange = "Content-Range";
                }
                {
                    this.ContentSecurityPolicy = "Content-Security-Policy";
                }
                {
                    this.ContentSecurityPolicyReportOnly = "Content-Security-Policy-Report-Only";
                }
                {
                    this.ContentType = "Content-Type";
                }
                {
                    this.CorrelationContext = "Correlation-Context";
                }
                {
                    this.Cookie = "Cookie";
                }
                {
                    this.Date = "Date";
                }
                {
                    this.DNT = "DNT";
                }
                {
                    this.ETag = "ETag";
                }
                {
                    this.Expires = "Expires";
                }
                {
                    this.Expect = "Expect";
                }
                {
                    this.From = "From";
                }
                {
                    this.GrpcAcceptEncoding = "Grpc-Accept-Encoding";
                }
                {
                    this.GrpcEncoding = "Grpc-Encoding";
                }
                {
                    this.GrpcMessage = "Grpc-Message";
                }
                {
                    this.GrpcStatus = "Grpc-Status";
                }
                {
                    this.GrpcTimeout = "Grpc-Timeout";
                }
                {
                    this.Host = "Host";
                }
                {
                    this.KeepAlive = "Keep-Alive";
                }
                {
                    this.IfMatch = "If-Match";
                }
                {
                    this.IfModifiedSince = "If-Modified-Since";
                }
                {
                    this.IfNoneMatch = "If-None-Match";
                }
                {
                    this.IfRange = "If-Range";
                }
                {
                    this.IfUnmodifiedSince = "If-Unmodified-Since";
                }
                {
                    this.LastModified = "Last-Modified";
                }
                {
                    this.Link = "Link";
                }
                {
                    this.Location = "Location";
                }
                {
                    this.MaxForwards = "Max-Forwards";
                }
                {
                    this.Method = ":method";
                }
                {
                    this.Origin = "Origin";
                }
                {
                    this.Path = ":path";
                }
                {
                    this.Pragma = "Pragma";
                }
                {
                    this.ProxyAuthenticate = "Proxy-Authenticate";
                }
                {
                    this.ProxyAuthorization = "Proxy-Authorization";
                }
                {
                    this.ProxyConnection = "Proxy-Connection";
                }
                {
                    this.Range = "Range";
                }
                {
                    this.Referer = "Referer";
                }
                {
                    this.RetryAfter = "Retry-After";
                }
                {
                    this.RequestId = "Request-Id";
                }
                {
                    this.Scheme = ":scheme";
                }
                {
                    this.SecWebSocketAccept = "Sec-WebSocket-Accept";
                }
                {
                    this.SecWebSocketKey = "Sec-WebSocket-Key";
                }
                {
                    this.SecWebSocketProtocol = "Sec-WebSocket-Protocol";
                }
                {
                    this.SecWebSocketVersion = "Sec-WebSocket-Version";
                }
                {
                    this.SecWebSocketExtensions = "Sec-WebSocket-Extensions";
                }
                {
                    this.Server = "Server";
                }
                {
                    this.SetCookie = "Set-Cookie";
                }
                {
                    this.Status = ":status";
                }
                {
                    this.StrictTransportSecurity = "Strict-Transport-Security";
                }
                {
                    this.TE = "TE";
                }
                {
                    this.Trailer = "Trailer";
                }
                {
                    this.TransferEncoding = "Transfer-Encoding";
                }
                {
                    this.Translate = "Translate";
                }
                {
                    this.TraceParent = "traceparent";
                }
                {
                    this.TraceState = "tracestate";
                }
                {
                    this.Upgrade = "Upgrade";
                }
                {
                    this.UpgradeInsecureRequests = "Upgrade-Insecure-Requests";
                }
                {
                    this.UserAgent = "User-Agent";
                }
                {
                    this.Vary = "Vary";
                }
                {
                    this.Via = "Via";
                }
                {
                    this.Warning = "Warning";
                }
                {
                    this.WebSocketSubProtocols = "Sec-WebSocket-Protocol";
                }
                {
                    this.WWWAuthenticate = "WWW-Authenticate";
                }
                {
                    this.XContentTypeOptions = "X-Content-Type-Options";
                }
                {
                    this.XFrameOptions = "X-Frame-Options";
                }
                {
                    this.XPoweredBy = "X-Powered-By";
                }
                {
                    this.XRequestedWith = "X-Requested-With";
                }
                {
                    this.XUACompatible = "X-UA-Compatible";
                }
                {
                    this.XXSSProtection = "X-XSS-Protection";
                }
            }
            static $h = 821969;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"PseudoHeaderNamesObsoletionMessage","d":821969,"h":4295789265,"f":4194338},{"t":1310721,"n":"Accept","d":821969,"h":8590756561,"f":4194337},{"t":1310721,"n":"AcceptCharset","d":821969,"h":12885723857,"f":4194337},{"t":1310721,"n":"AcceptEncoding","d":821969,"h":17180691153,"f":4194337},{"t":1310721,"n":"AcceptLanguage","d":821969,"h":21475658449,"f":4194337},{"t":1310721,"n":"AcceptRanges","d":821969,"h":25770625745,"f":4194337},{"t":1310721,"n":"AccessControlAllowCredentials","d":821969,"h":30065593041,"f":4194337},{"t":1310721,"n":"AccessControlAllowHeaders","d":821969,"h":34360560337,"f":4194337},{"t":1310721,"n":"AccessControlAllowMethods","d":821969,"h":38655527633,"f":4194337},{"t":1310721,"n":"AccessControlAllowOrigin","d":821969,"h":42950494929,"f":4194337},{"t":1310721,"n":"AccessControlExposeHeaders","d":821969,"h":47245462225,"f":4194337},{"t":1310721,"n":"AccessControlMaxAge","d":821969,"h":51540429521,"f":4194337},{"t":1310721,"n":"AccessControlRequestHeaders","d":821969,"h":55835396817,"f":4194337},{"t":1310721,"n":"AccessControlRequestMethod","d":821969,"h":60130364113,"f":4194337},{"t":1310721,"n":"Age","d":821969,"h":64425331409,"f":4194337},{"t":1310721,"n":"Allow","d":821969,"h":68720298705,"f":4194337},{"t":1310721,"n":"AltSvc","d":821969,"h":73015266001,"f":4194337},{"t":1310721,"n":"Authority","d":821969,"h":77310233297,"f":4194337,"a":[{"t":70909953,"c":12955811841,"a":[{"v":"This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.","t":1310721},{"v":false,"t":262145}]}]},{"t":1310721,"n":"Authorization","d":821969,"h":81605200593,"f":4194337},{"t":1310721,"n":"Baggage","d":821969,"h":85900167889,"f":4194337},{"t":1310721,"n":"CacheControl","d":821969,"h":90195135185,"f":4194337},{"t":1310721,"n":"Connection","d":821969,"h":94490102481,"f":4194337},{"t":1310721,"n":"ContentDisposition","d":821969,"h":98785069777,"f":4194337},{"t":1310721,"n":"ContentEncoding","d":821969,"h":103080037073,"f":4194337},{"t":1310721,"n":"ContentLanguage","d":821969,"h":107375004369,"f":4194337},{"t":1310721,"n":"ContentLength","d":821969,"h":111669971665,"f":4194337},{"t":1310721,"n":"ContentLocation","d":821969,"h":115964938961,"f":4194337},{"t":1310721,"n":"ContentMD5","d":821969,"h":120259906257,"f":4194337},{"t":1310721,"n":"ContentRange","d":821969,"h":124554873553,"f":4194337},{"t":1310721,"n":"ContentSecurityPolicy","d":821969,"h":128849840849,"f":4194337},{"t":1310721,"n":"ContentSecurityPolicyReportOnly","d":821969,"h":133144808145,"f":4194337},{"t":1310721,"n":"ContentType","d":821969,"h":137439775441,"f":4194337},{"t":1310721,"n":"CorrelationContext","d":821969,"h":141734742737,"f":4194337},{"t":1310721,"n":"Cookie","d":821969,"h":146029710033,"f":4194337},{"t":1310721,"n":"Date","d":821969,"h":150324677329,"f":4194337},{"t":1310721,"n":"DNT","d":821969,"h":154619644625,"f":4194337},{"t":1310721,"n":"ETag","d":821969,"h":158914611921,"f":4194337},{"t":1310721,"n":"Expires","d":821969,"h":163209579217,"f":4194337},{"t":1310721,"n":"Expect","d":821969,"h":167504546513,"f":4194337},{"t":1310721,"n":"From","d":821969,"h":171799513809,"f":4194337},{"t":1310721,"n":"GrpcAcceptEncoding","d":821969,"h":176094481105,"f":4194337},{"t":1310721,"n":"GrpcEncoding","d":821969,"h":180389448401,"f":4194337},{"t":1310721,"n":"GrpcMessage","d":821969,"h":184684415697,"f":4194337},{"t":1310721,"n":"GrpcStatus","d":821969,"h":188979382993,"f":4194337},{"t":1310721,"n":"GrpcTimeout","d":821969,"h":193274350289,"f":4194337},{"t":1310721,"n":"Host","d":821969,"h":197569317585,"f":4194337},{"t":1310721,"n":"KeepAlive","d":821969,"h":201864284881,"f":4194337},{"t":1310721,"n":"IfMatch","d":821969,"h":206159252177,"f":4194337},{"t":1310721,"n":"IfModifiedSince","d":821969,"h":210454219473,"f":4194337},{"t":1310721,"n":"IfNoneMatch","d":821969,"h":214749186769,"f":4194337},{"t":1310721,"n":"IfRange","d":821969,"h":219044154065,"f":4194337},{"t":1310721,"n":"IfUnmodifiedSince","d":821969,"h":223339121361,"f":4194337},{"t":1310721,"n":"LastModified","d":821969,"h":227634088657,"f":4194337},{"t":1310721,"n":"Link","d":821969,"h":231929055953,"f":4194337},{"t":1310721,"n":"Location","d":821969,"h":236224023249,"f":4194337},{"t":1310721,"n":"MaxForwards","d":821969,"h":240518990545,"f":4194337},{"t":1310721,"n":"Method","d":821969,"h":244813957841,"f":4194337,"a":[{"t":70909953,"c":12955811841,"a":[{"v":"This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.","t":1310721},{"v":false,"t":262145}]}]},{"t":1310721,"n":"Origin","d":821969,"h":249108925137,"f":4194337},{"t":1310721,"n":"Path","d":821969,"h":253403892433,"f":4194337,"a":[{"t":70909953,"c":12955811841,"a":[{"v":"This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.","t":1310721},{"v":false,"t":262145}]}]},{"t":1310721,"n":"Pragma","d":821969,"h":257698859729,"f":4194337},{"t":1310721,"n":"ProxyAuthenticate","d":821969,"h":261993827025,"f":4194337},{"t":1310721,"n":"ProxyAuthorization","d":821969,"h":266288794321,"f":4194337},{"t":1310721,"n":"ProxyConnection","d":821969,"h":270583761617,"f":4194337},{"t":1310721,"n":"Range","d":821969,"h":274878728913,"f":4194337},{"t":1310721,"n":"Referer","d":821969,"h":279173696209,"f":4194337},{"t":1310721,"n":"RetryAfter","d":821969,"h":283468663505,"f":4194337},{"t":1310721,"n":"RequestId","d":821969,"h":287763630801,"f":4194337},{"t":1310721,"n":"Scheme","d":821969,"h":292058598097,"f":4194337,"a":[{"t":70909953,"c":12955811841,"a":[{"v":"This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.","t":1310721},{"v":false,"t":262145}]}]},{"t":1310721,"n":"SecWebSocketAccept","d":821969,"h":296353565393,"f":4194337},{"t":1310721,"n":"SecWebSocketKey","d":821969,"h":300648532689,"f":4194337},{"t":1310721,"n":"SecWebSocketProtocol","d":821969,"h":304943499985,"f":4194337},{"t":1310721,"n":"SecWebSocketVersion","d":821969,"h":309238467281,"f":4194337},{"t":1310721,"n":"SecWebSocketExtensions","d":821969,"h":313533434577,"f":4194337},{"t":1310721,"n":"Server","d":821969,"h":317828401873,"f":4194337},{"t":1310721,"n":"SetCookie","d":821969,"h":322123369169,"f":4194337},{"t":1310721,"n":"Status","d":821969,"h":326418336465,"f":4194337,"a":[{"t":70909953,"c":12955811841,"a":[{"v":"This is obsolete and will be removed in a future version. Header dictionaries do not contain this key.","t":1310721},{"v":false,"t":262145}]}]},{"t":1310721,"n":"StrictTransportSecurity","d":821969,"h":330713303761,"f":4194337},{"t":1310721,"n":"TE","d":821969,"h":335008271057,"f":4194337},{"t":1310721,"n":"Trailer","d":821969,"h":339303238353,"f":4194337},{"t":1310721,"n":"TransferEncoding","d":821969,"h":343598205649,"f":4194337},{"t":1310721,"n":"Translate","d":821969,"h":347893172945,"f":4194337},{"t":1310721,"n":"TraceParent","d":821969,"h":352188140241,"f":4194337},{"t":1310721,"n":"TraceState","d":821969,"h":356483107537,"f":4194337},{"t":1310721,"n":"Upgrade","d":821969,"h":360778074833,"f":4194337},{"t":1310721,"n":"UpgradeInsecureRequests","d":821969,"h":365073042129,"f":4194337},{"t":1310721,"n":"UserAgent","d":821969,"h":369368009425,"f":4194337},{"t":1310721,"n":"Vary","d":821969,"h":373662976721,"f":4194337},{"t":1310721,"n":"Via","d":821969,"h":377957944017,"f":4194337},{"t":1310721,"n":"Warning","d":821969,"h":382252911313,"f":4194337},{"t":1310721,"n":"WebSocketSubProtocols","d":821969,"h":386547878609,"f":4194337},{"t":1310721,"n":"WWWAuthenticate","d":821969,"h":390842845905,"f":4194337},{"t":1310721,"n":"XContentTypeOptions","d":821969,"h":395137813201,"f":4194337},{"t":1310721,"n":"XFrameOptions","d":821969,"h":399432780497,"f":4194337},{"t":1310721,"n":"XPoweredBy","d":821969,"h":403727747793,"f":4194337},{"t":1310721,"n":"XRequestedWith","d":821969,"h":408022715089,"f":4194337},{"t":1310721,"n":"XUACompatible","d":821969,"h":412317682385,"f":4194337},{"t":1310721,"n":"XXSSProtection","d":821969,"h":416612649681,"f":4194337}],"h":821969}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HeaderNames`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue", ($self) => class CookieHeaderValue extends $.$$.System.Object
        {
            /*CookieHeaderParser*/ static SingleValueParser = null;
            /*CookieHeaderParser*/ static MultipleValueParser = null;
            /*StringSegment*/ _name;
            /*StringSegment*/ _value;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty);
                {
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("name");
                    }
                }
                return this;
            }
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("name");
                    }
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("value");
                    }
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            /*StringSegment */ get Name()
            {
                return this._name;
            }
            /*StringSegment */ set Name(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.CheckNameFormat(value, "value");
                this._name = value;
            }
            /*StringSegment */ get Value()
            {
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.CheckValueFormat(value, "value");
                this._value = value;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let header = new $.$$.System.Text.StringBuilder().$ctor$1();
                header.Append$15(this._name.AsSpan());
                header.Append$3(/*=*/ 61);
                header.Append$15(this._value.AsSpan());
                return $.$$.System.Text.StringBuilder.ToString.call(header);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.ToString.apply(this, arguments); }
            static /*CookieHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out CookieHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*IList<CookieHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            static /*IList<CookieHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<CookieHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.MultipleValueParser.TryParseValues$1(inputs, parsedValues);
            }
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<CookieHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            static /*void */ CheckNameFormat(/*StringSegment*/ name, /*string*/ parameterName)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("name");
                }
                if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(name, 0) !== name.Length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("Invalid cookie name: " + $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(name), parameterName);
                }
            }
            static /*void */ CheckValueFormat(/*StringSegment*/ value, /*string*/ parameterName)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("value");
                }
                /*var*/ let offset = 0;
                /*var*/ let result = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetCookieValue(value, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32));
                if (result.Length !== value.Length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("Invalid cookie value: " + $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(value), parameterName);
                }
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._name, other._name, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(this._name) ^ $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(this._value);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.GetHashCode.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._name = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SingleValueParser = new $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParser().$ctor$2(false);
                }
                {
                    this.MultipleValueParser = new $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParser().$ctor$2(true);
                }
            }
            static $h = 559825;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851970,"g":{"r":0,"d":0,"h":38655265489,"f":50331649},"s":{"r":0,"d":0,"h":42950232785,"f":83886081},"n":"Name","d":559825,"h":34360298193,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":51540167377,"f":50331649},"s":{"r":0,"d":0,"h":55835134673,"f":83886081},"n":"Value","d":559825,"h":47245200081,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":559825,"h":60130101969,"f":16809985},{"r":559825,"p":[{"n":"input","p":851970}],"n":"Parse","d":559825,"h":64425069265,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":559825,"f":2}],"n":"TryParse","d":559825,"h":68720036561,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue).$h,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseList","d":559825,"h":73015003857,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue).$h,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseStrictList","d":559825,"h":77309971153,"f":16777249},{"r":262145,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue).$h,"f":2}],"n":"TryParseList","d":559825,"h":81604938449,"f":16777249},{"r":262145,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue).$h,"f":2}],"n":"TryParseStrictList","d":559825,"h":85899905745,"f":16777249},{"r":65537,"p":[{"n":"name","p":851970},{"n":"parameterName","p":1310721}],"n":"CheckNameFormat","d":559825,"h":90194873041,"f":16777256},{"r":65537,"p":[{"n":"value","p":851970},{"n":"parameterName","p":1310721}],"n":"CheckValueFormat","d":559825,"h":94489840337,"f":16777256},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":559825,"h":98784807633,"f":16809985},{"r":655361,"n":"GetHashCode","d":559825,"h":103079774929,"f":16809985}],"l":[{"t":428753,"n":"SingleValueParser","d":559825,"h":4295527121,"f":4194338},{"t":428753,"n":"MultipleValueParser","d":559825,"h":8590494417,"f":4194338},{"t":851970,"n":"_name","d":559825,"h":12885461713,"f":4194306},{"t":851970,"n":"_value","d":559825,"h":17180429009,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":559825,"h":21475396305,"f":16777218},{"p":[{"n":"name","p":851970}],"n":".ctor","o":"$ctor$3","d":559825,"h":25770363601,"f":16777217},{"p":[{"n":"name","p":851970},{"n":"value","p":851970}],"n":".ctor","o":"$ctor$2","d":559825,"h":30065330897,"f":16777217}],"h":559825}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `CookieHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue", ($self) => class NameValueHeaderValue extends $.$$.System.Object
        {
            /*HttpHeaderParser<NameValueHeaderValue>*/ static SingleValueParser = null;
            /*HttpHeaderParser<NameValueHeaderValue>*/ static MultipleValueParser = null;
            /*StringSegment*/ _name;
            /*StringSegment*/ _value;
            /*bool*/ _isReadOnly = false;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                {
                }
                return this;
            }
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.CheckNameValueFormat(name, value);
                    this._name = name;
                    this._value = value;
                }
                return this;
            }
            /*StringSegment */ get Name()
            {
                return this._name;
            }
            /*StringSegment */ get Value()
            {
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.CheckValueFormat(value);
                this._value = value;
            }
            /*bool */ get IsReadOnly()
            {
                return this._isReadOnly;
            }
            /*NameValueHeaderValue */ Copy()
            {
                return (() =>
                {
                    //new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue()
                    const $t1 = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1._name = this._name;
                    $i1._value = this._value;
                    return $i1;
                })();
            }
            /*NameValueHeaderValue */ CopyAsReadOnly()
            {
                if (this.IsReadOnly)
                {
                    return this;
                }
                return (() =>
                {
                    //new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue()
                    const $t1 = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1._name = this._name;
                    $i1._value = this._value;
                    $i1._isReadOnly = true;
                    return $i1;
                })();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this._name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)));
                /*var*/ let nameHashCode = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._name);
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(this._value))
                {
                    if (this._value.get_Item(0) === /*\"*/ 34)
                    {
                        return nameHashCode ^ $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(this._value);
                    }
                    return nameHashCode ^ $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value);
                }
                return nameHashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (!this._name.Equals$4(other._name, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(this._value))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(other._value);
                }
                if (this._value.get_Item(0) === /*\"*/ 34)
                {
                    return (this._value.Equals$4(other._value, 4/*StringComparison.Ordinal*/));
                }
                else 
                {
                    return (this._value.Equals$4(other._value, 5/*StringComparison.OrdinalIgnoreCase*/));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Equals$1.apply(this, arguments); }
            /*StringSegment */ GetUnescapedValue()
            {
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.IsQuoted(this._value))
                {
                    return this._value;
                }
                return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.UnescapeAsQuotedString(this._value);
            }
            /*void */ SetAndEscapeValue(/*StringSegment*/ value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value) || ($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetValueLength(value, 0) === value.Length))
                {
                    this._value = value;
                }
                else 
                {
                    this.Value = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.EscapeAsQuotedString(value);
                }
            }
            static /*NameValueHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out NameValueHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*IList<NameValueHeaderValue> */ ParseList(/*IList<string>?*/ input)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.ParseValues$1(input);
            }
            static /*IList<NameValueHeaderValue> */ ParseStrictList(/*IList<string>?*/ input)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.ParseStrictValues(input);
            }
            static /*bool */ TryParseList(/*IList<string>?*/ input, /*out IList<NameValueHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.TryParseValues$1(input, parsedValues);
            }
            static /*bool */ TryParseStrictList(/*IList<string>?*/ input, /*out IList<NameValueHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.MultipleValueParser.TryParseStrictValues(input, parsedValues);
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(this._value))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._name) + "=" + $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._value);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._name);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString.apply(this, arguments); }
            static /*void */ ToString$1(/*IList<NameValueHeaderValue>?*/ values, /*char*/ separator, /*bool*/ leadingSeparator, /*StringBuilder*/ destination)
            {
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1(destination !== null);
                if ((values === null) || (values.System$Collections$Generic$ICollection$$$Count === 0))
                {
                    return;
                }
                for(/*var*/ let i = 0; i < values.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    if (leadingSeparator || (destination.Length > 0))
                    {
                        destination.Append$3(separator);
                        destination.Append$3(/* */ 32);
                    }
                    destination.Append$15(values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]).Name.AsSpan());
                    if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]).Value))
                    {
                        destination.Append$3(/*=*/ 61);
                        destination.Append$15(values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]).Value.AsSpan());
                    }
                }
            }
            static /*string? */ ToString$2(/*IList<NameValueHeaderValue>?*/ values, /*char*/ separator, /*bool*/ leadingSeparator)
            {
                if ((values === null) || (values.System$Collections$Generic$ICollection$$$Count === 0))
                {
                    return null;
                }
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString$1(values, separator, leadingSeparator, sb);
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            static /*int */ GetHashCode$1(/*IList<NameValueHeaderValue>?*/ values)
            {
                if ((values === null) || (values.System$Collections$Generic$ICollection$$$Count === 0))
                {
                    return 0;
                }
                /*var*/ let result = 0;
                for(/*var*/ let i = 0; i < values.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    result = result ^ $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode.call(values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]));
                }
                return result;
            }
            static /*int */ GetNameValueLength(/*StringSegment*/ input, /*int*/ startIndex, /*out NameValueHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let nameLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (nameLength === 0)
                {
                    return 0;
                }
                /*var*/ let name = input.Subsegment(startIndex, nameLength);
                /*var*/ let current = ((startIndex + nameLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*=*/ 61))
                {
                    parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$1();
                    parsedValue.$v._name = name;
                    current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    return ((current - startIndex) | 0);
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*int*/ let valueLength = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetValueLength(input, current);
                parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$1();
                parsedValue.$v._name = name;
                parsedValue.$v._value = input.Subsegment(current, valueLength);
                current = ((current + valueLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                return ((current - startIndex) | 0);
            }
            static /*int */ GetNameValueListLength(/*StringSegment*/ input, /*int*/ startIndex, /*char*/ delimiter, /*IList<NameValueHeaderValue>*/ nameValueCollection)
            {
                ;
                if (($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input)) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                while(true)
                {
                    /*var*/ let parameter;
                    /*var*/ let nameValueLength = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueLength(input, current, $.$ref(() => parameter, ($v) => parameter = $v, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue));
                    if (nameValueLength === 0)
                    {
                        return ((current - startIndex) | 0);
                    }
                    nameValueCollection.System$Collections$Generic$ICollection$$$Add(parameter, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    current = ((current + nameValueLength) | 0);
                    current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    if ((current === input.Length) || (input.get_Item(current) !== delimiter))
                    {
                        return ((current - startIndex) | 0);
                    }
                    current++;
                    current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                }
            }
            static /*NameValueHeaderValue? */ Find(/*IList<NameValueHeaderValue>?*/ values, /*StringSegment*/ name)
            {
                ;
                if ((values === null) || (values.System$Collections$Generic$ICollection$$$Count === 0))
                {
                    return null;
                }
                for(/*var*/ let i = 0; i < values.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*var*/ let value = values.System$Collections$Generic$IList$$$get_Item(i, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    if (value.Name.Equals$4(name, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return value;
                    }
                }
                return null;
            }
            static /*int */ GetValueLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let valueLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (valueLength === 0)
                {
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetQuotedStringLength(input, startIndex, $.$ref(() => valueLength, ($v) => valueLength = $v, $.$$.System.Int32)) !== 0/*HttpParseResult.Parsed*/)
                    {
                        return 0;
                    }
                }
                return valueLength;
            }
            static /*void */ CheckNameValueFormat(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(name, "name");
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.CheckValueFormat(value);
            }
            static /*void */ CheckValueFormat(/*StringSegment*/ value)
            {
                if (!($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value) || ($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetValueLength(value, 0) === value.Length)))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "The header value is invalid: '{0}'", value));
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._name = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueLength));
                }
                {
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueLength));
                }
            }
            static $h = 1346257;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851970,"g":{"r":0,"d":0,"h":42951019217,"f":50331649},"n":"Name","d":1346257,"h":38656051921,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":51540953809,"f":50331649},"s":{"r":0,"d":0,"h":55835921105,"f":83886081},"n":"Value","d":1346257,"h":47245986513,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":64425855697,"f":50331649},"n":"IsReadOnly","d":1346257,"h":60130888401,"f":2097153}],"m":[{"r":1346257,"n":"Copy","d":1346257,"h":68720822993,"f":16777217},{"r":1346257,"n":"CopyAsReadOnly","d":1346257,"h":73015790289,"f":16777217},{"r":655361,"n":"GetHashCode","d":1346257,"h":77310757585,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1346257,"h":81605724881,"f":16809985},{"r":851970,"n":"GetUnescapedValue","d":1346257,"h":85900692177,"f":16777217},{"r":65537,"p":[{"n":"value","p":851970}],"n":"SetAndEscapeValue","d":1346257,"h":90195659473,"f":16777217},{"r":1346257,"p":[{"n":"input","p":851970}],"n":"Parse","d":1346257,"h":94490626769,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":1346257,"f":2}],"n":"TryParse","d":1346257,"h":98785594065,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"p":[{"n":"input","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseList","d":1346257,"h":103080561361,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"p":[{"n":"input","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseStrictList","d":1346257,"h":107375528657,"f":16777249},{"r":262145,"p":[{"n":"input","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"f":2}],"n":"TryParseList","d":1346257,"h":111670495953,"f":16777249},{"r":262145,"p":[{"n":"input","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"f":2}],"n":"TryParseStrictList","d":1346257,"h":115965463249,"f":16777249},{"r":1310721,"n":"ToString","d":1346257,"h":120260430545,"f":16809985},{"r":65537,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h},{"n":"separator","p":458753},{"n":"leadingSeparator","p":262145},{"n":"destination","p":122814465}],"n":"ToString","o":"@$1","d":1346257,"h":124555397841,"f":16777256},{"r":1310721,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h},{"n":"separator","p":458753},{"n":"leadingSeparator","p":262145}],"n":"ToString","o":"@$2","d":1346257,"h":128850365137,"f":16777256},{"r":655361,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h}],"n":"GetHashCode","o":"@$1","d":1346257,"h":133145332433,"f":16777256},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":1346257,"f":2}],"n":"GetNameValueLength","d":1346257,"h":137440299729,"f":16777250},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"delimiter","p":458753},{"n":"nameValueCollection","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h}],"n":"GetNameValueListLength","d":1346257,"h":141735267025,"f":16777256},{"r":1346257,"p":[{"n":"values","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h},{"n":"name","p":851970}],"n":"Find","d":1346257,"h":146030234321,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361}],"n":"GetValueLength","d":1346257,"h":150325201617,"f":16777256},{"r":65537,"p":[{"n":"name","p":851970},{"n":"value","p":851970}],"n":"CheckNameValueFormat","d":1346257,"h":154620168913,"f":16777250},{"r":65537,"p":[{"n":"value","p":851970}],"n":"CheckValueFormat","d":1346257,"h":158915136209,"f":16777250}],"l":[{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"n":"SingleValueParser","d":1346257,"h":4296313553,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"n":"MultipleValueParser","d":1346257,"h":8591280849,"f":4194344},{"t":851970,"n":"_name","d":1346257,"h":12886248145,"f":4194306},{"t":851970,"n":"_value","d":1346257,"h":17181215441,"f":4194306},{"t":262145,"n":"_isReadOnly","d":1346257,"h":21476182737,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1346257,"h":25771150033,"f":16777218},{"p":[{"n":"name","p":851970}],"n":".ctor","o":"$ctor$3","d":1346257,"h":30066117329,"f":16777217},{"p":[{"n":"name","p":851970},{"n":"value","p":851970}],"n":".ctor","o":"$ctor$2","d":1346257,"h":34361084625,"f":16777217}],"h":1346257}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `NameValueHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser", ($self) => class HttpRuleParser
        {
            /*SearchValues<char>*/ static TokenChars = null;
            /*int*/ static MaxNestedCount = 5;
            /*string[]*/ static DateFormats = null;
            /*char*/ static CR = /*\r*/ 13;
            /*char*/ static LF = /*\n*/ 10;
            /*char*/ static SP = /* */ 32;
            /*char*/ static Tab = /*\t*/ 9;
            /*int*/ static MaxInt64Digits = 19;
            /*int*/ static MaxInt32Digits = 10;
            /*Encoding*/ static DefaultHttpEncoding = null;
            static /*int */ GetTokenLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                ;
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let subspan = input.AsSpan$2(startIndex);
                /*var*/ let firstNonTokenCharIdx = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, subspan, $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TokenChars);
                return (firstNonTokenCharIdx === -1) ? subspan.Length : firstNonTokenCharIdx;
            }
            static /*int */ GetWhitespaceLength(/*StringSegment*/ input, /*int*/ startIndex)
            {
                ;
                if (startIndex >= input.Length)
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*char*/ let c;
                while(current < input.Length)
                {
                    c = input.get_Item(current);
                    if ((c === /* */ 32) || (c === /*\t*/ 9))
                    {
                        current++;
                        continue;
                    }
                    if (c === /*\r*/ 13)
                    {
                        if ((((current + 2) | 0) < input.Length) && (input.get_Item(((current + 1) | 0)) === /*\n*/ 10))
                        {
                            /*var*/ let spaceOrTab = input.get_Item(((current + 2) | 0));
                            if ((spaceOrTab === /* */ 32) || (spaceOrTab === /*\t*/ 9))
                            {
                                current += 3;
                                continue;
                            }
                        }
                    }
                    return ((current - startIndex) | 0);
                }
                return ((input.Length - startIndex) | 0);
            }
            static /*int */ GetNumberLength(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ allowDecimal)
            {
                ;
                ;
                /*var*/ let current = startIndex;
                /*char*/ let c;
                /*var*/ let haveDot = !allowDecimal;
                if (input.get_Item(current) === /*.*/ 46)
                {
                    return 0;
                }
                while(current < input.Length)
                {
                    c = input.get_Item(current);
                    if ((c >= /*0*/ 48) && (c <= /*9*/ 57))
                    {
                        current++;
                    }
                    else if (!haveDot && (c === /*.*/ 46))
                    {
                        haveDot = true;
                        current++;
                    }
                    else 
                    {
                        break;
                    }
                }
                return ((current - startIndex) | 0);
            }
            static /*HttpParseResult */ GetQuotedStringLength(/*StringSegment*/ input, /*int*/ startIndex, /*out int*/ length)
            {
                /*var*/ let nestedCount = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetExpressionLength(input, startIndex, /*\"*/ 34, /*\"*/ 34, false, $.$ref(() => nestedCount, ($v) => nestedCount = $v, $.$$.System.Int32), length);
            }
            static /*HttpParseResult */ GetQuotedPairLength(/*StringSegment*/ input, /*int*/ startIndex, /*out int*/ length)
            {
                ;
                length.$v = 0;
                if (input.get_Item(startIndex) !== /*\\*/ 92)
                {
                    return 1/*HttpParseResult.NotParsed*/;
                }
                if ((((startIndex + 2) | 0) > input.Length) || (input.get_Item(((startIndex + 1) | 0)) > 127))
                {
                    return 2/*HttpParseResult.InvalidFormat*/;
                }
                length.$v = 2;
                return 0/*HttpParseResult.Parsed*/;
            }
            static /*bool */ TryStringToDate(/*StringSegment*/ input, /*out DateTimeOffset*/ result)
            {
                /*ReadOnlySpan<char>*/ let inputSpan = input.AsSpan();
                /*DateTimeFormatInfo*/ let invariant = $.$$.System.Globalization.DateTimeFormatInfo.InvariantInfo;
                return $.$$.System.DateTimeOffset.TryParseExact(inputSpan, $.$$.System.String.op_Implicit("r"), invariant, 0/*DateTimeStyles.None*/, result) || $.$$.System.DateTimeOffset.TryParseExact$1(inputSpan, $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.DateFormats, invariant, 7/*DateTimeStyles.AllowWhiteSpaces*/ | 64/*DateTimeStyles.AssumeUniversal*/, result);
            }
            static /*HttpParseResult */ GetExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*char*/ openChar, /*char*/ closeChar, /*bool*/ supportsNesting, /*ref int*/ nestedCount, /*out int*/ length)
            {
                ;
                ;
                length.$v = 0;
                if (input.get_Item(startIndex) !== openChar)
                {
                    return 1/*HttpParseResult.NotParsed*/;
                }
                /*var*/ let current = ((startIndex + 1) | 0);
                while(current < input.Length)
                {
                    /*var*/ let quotedPairLength;
                    if ((((current + 2) | 0) < input.Length) && ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetQuotedPairLength(input, current, $.$ref(() => quotedPairLength, ($v) => quotedPairLength = $v, $.$$.System.Int32)) === 0/*HttpParseResult.Parsed*/))
                    {
                        current = ((current + quotedPairLength) | 0);
                        continue;
                    }
                    if (supportsNesting && (input.get_Item(current) === openChar))
                    {
                        nestedCount.$v++;
                        try
                        {
                            if (nestedCount.$v > 5/*MaxNestedCount*/)
                            {
                                return 2/*HttpParseResult.InvalidFormat*/;
                            }
                            /*var*/ let nestedLength = 0;
                            /*var*/ let nestedResult = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetExpressionLength(input, current, openChar, closeChar, supportsNesting, nestedCount, $.$ref(() => nestedLength, ($v) => nestedLength = $v, $.$$.System.Int32));
                            switch(nestedResult)
                            {
                                case 0/*HttpParseResult.Parsed*/:
                                current += nestedLength;
                                break;
                                case 1/*HttpParseResult.NotParsed*/:
                                $.$$.System.Diagnostics.Contracts.Contract.Assert(false, "'NotParsed' is unexpected: We started nested expression " + "parsing, because we found the open-char. So either it's a valid nested " + "expression or it has invalid format.");
                                break;
                                case 2/*HttpParseResult.InvalidFormat*/:
                                return 2/*HttpParseResult.InvalidFormat*/;
                                default:
                                $.$$.System.Diagnostics.Contracts.Contract.Assert(false, "Unknown enum result: " + $.$$.System.Enum.ToString.call(nestedResult));
                                break;
                            }
                        }
                        finally
                        {
                            {
                                nestedCount.$v--;
                            }
                        }
                    }
                    if (input.get_Item(current) === closeChar)
                    {
                        length.$v = ((((current - startIndex) | 0) + 1) | 0);
                        return 0/*HttpParseResult.Parsed*/;
                    }
                    current++;
                }
                return 2/*HttpParseResult.InvalidFormat*/;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TokenChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!#$%&'*+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"));
                }
                {
                    this.DateFormats = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), ["ddd, d MMM yyyy H:m:s 'GMT'", "ddd, d MMM yyyy H:m:s", "d MMM yyyy H:m:s 'GMT'", "d MMM yyyy H:m:s", "ddd, d MMM yy H:m:s 'GMT'", "ddd, d MMM yy H:m:s", "d MMM yy H:m:s 'GMT'", "d MMM yy H:m:s", "dddd, d'-'MMM'-'yy H:m:s 'GMT'", "dddd, d'-'MMM'-'yy H:m:s", "ddd, d'-'MMM'-'yyyy H:m:s 'GMT'", "ddd MMM d H:m:s yyyy", "ddd, d MMM yyyy H:m:s zzz", "ddd, d MMM yyyy H:m:s", "d MMM yyyy H:m:s zzz", "d MMM yyyy H:m:s"], [-1], null);
                }
                {
                    this.DefaultHttpEncoding = $.$$.System.Text.Encoding.GetEncoding$3("iso-8859-1");
                }
            }
            static $h = 1149649;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361}],"n":"GetTokenLength","d":1149649,"h":47245789905,"f":16777256,"a":[{"t":36962305,"c":4331929601}]},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361}],"n":"GetWhitespaceLength","d":1149649,"h":51540757201,"f":16777256},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"allowDecimal","p":262145}],"n":"GetNumberLength","d":1149649,"h":55835724497,"f":16777256},{"r":1084113,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"length","p":655361,"f":2}],"n":"GetQuotedStringLength","d":1149649,"h":60130691793,"f":16777256},{"r":1084113,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"length","p":655361,"f":2}],"n":"GetQuotedPairLength","d":1149649,"h":64425659089,"f":16777256},{"r":262145,"p":[{"n":"input","p":851970},{"n":"result","p":34471937,"f":2}],"n":"TryStringToDate","d":1149649,"h":68720626385,"f":16777256},{"r":1084113,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"openChar","p":458753},{"n":"closeChar","p":458753},{"n":"supportsNesting","p":262145},{"n":"nestedCount","p":655361,"f":4},{"n":"length","p":655361,"f":2}],"n":"GetExpressionLength","d":1149649,"h":73015593681,"f":16777250}],"l":[{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"TokenChars","d":1149649,"h":4296116945,"f":4194338},{"t":655361,"n":"MaxNestedCount","d":1149649,"h":8591084241,"f":4194338},{"t":$.$typeArray($.$$.System.String).$h,"n":"DateFormats","d":1149649,"h":12886051537,"f":4194338},{"t":458753,"n":"CR","d":1149649,"h":17181018833,"f":4194344},{"t":458753,"n":"LF","d":1149649,"h":21475986129,"f":4194344},{"t":458753,"n":"SP","d":1149649,"h":25770953425,"f":4194344},{"t":458753,"n":"Tab","d":1149649,"h":30065920721,"f":4194344},{"t":655361,"n":"MaxInt64Digits","d":1149649,"h":34360888017,"f":4194344},{"t":655361,"n":"MaxInt32Digits","d":1149649,"h":38655855313,"f":4194344},{"t":121700353,"n":"DefaultHttpEncoding","d":1149649,"h":42950822609,"f":4194344}],"h":1149649}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HttpRuleParser`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValueIdentityExtensions", ($self) => class ContentDispositionHeaderValueIdentityExtensions
        {
            static /*bool */ IsFileDisposition(/*this ContentDispositionHeaderValue*/ header)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(header, "header");
                return header.DispositionType.Equals$3("form-data") && (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(header.FileName) || !$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(header.FileNameStar));
            }
            static /*bool */ IsFormDisposition(/*this ContentDispositionHeaderValue*/ header)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(header, "header");
                return header.DispositionType.Equals$3("form-data") && $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(header.FileName) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(header.FileNameStar);
            }
            static $h = 297681;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"header","p":232145}],"n":"IsFileDisposition","d":297681,"h":4295264977,"f":16777249},{"r":262145,"p":[{"n":"header","p":232145}],"n":"IsFormDisposition","d":297681,"h":8590232273,"f":16777249}],"h":297681}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ContentDispositionHeaderValueIdentityExtensions`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue", ($self) => class ContentRangeHeaderValue extends $.$$.System.Object
        {
            /*HttpHeaderParser<ContentRangeHeaderValue>*/ static Parser = null;
            /*StringSegment*/ _unit;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*long*/ $from, /*long*/ to, /*long*/ length)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, length, "length");
                    if ((to < 0n) || (length <= to))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("to");
                    }
                    if (($from < 0n) || ($from > to))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this.From = $from;
                    this.To = to;
                    this.Length = length;
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            $ctor$4(/*long*/ length)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, length, "length");
                    this.Length = length;
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            $ctor$3(/*long*/ $from, /*long*/ to)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, to, "to");
                    if (($from < 0n) || ($from > to))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this.From = $from;
                    this.To = to;
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            /*StringSegment */ get Unit()
            {
                return this._unit;
            }
            /*StringSegment */ set Unit(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(value, "value");
                this._unit = value;
            }
            /*long?*/ From = null;
            /*long?*/ To = null;
            /*long?*/ Length = null;
            /*bool */ get HasLength()
            {
                return this.Length !== null;
            }
            /*bool */ get HasRange()
            {
                return this.From !== null && this.To !== null;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return ((this.From === other.From) && (this.To === other.To) && (this.Length === other.Length) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Unit, other.Unit, 5/*StringComparison.OrdinalIgnoreCase*/));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*var*/ let result = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Unit);
                if (this.HasRange)
                {
                    result = result ^ $.$$.System.Nullable$$($.$$.System.Int64).GetHashCode.call(this.From) ^ $.$$.System.Nullable$$($.$$.System.Int64).GetHashCode.call(this.To);
                }
                if (this.HasLength)
                {
                    result = result ^ $.$$.System.Nullable$$($.$$.System.Int64).GetHashCode.call(this.Length);
                }
                return result;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                sb.Append$15(this.Unit.AsSpan());
                sb.Append$3(/* */ 32);
                if (this.HasRange)
                {
                    sb.Append$19($.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this.From), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                    sb.Append$3(/*-*/ 45);
                    sb.Append$19($.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this.To), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                else 
                {
                    sb.Append$3(/***/ 42);
                }
                sb.Append$3(/*/*/ 47);
                if (this.HasLength)
                {
                    sb.Append$19($.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this.Length), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo));
                }
                else 
                {
                    sb.Append$3(/***/ 42);
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.ToString.apply(this, arguments); }
            static /*ContentRangeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*int */ GetContentRangeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let unitLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (unitLength === 0)
                {
                    return 0;
                }
                /*var*/ let unit = input.Subsegment(startIndex, unitLength);
                /*var*/ let current = ((startIndex + unitLength) | 0);
                /*var*/ let separatorLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current);
                if (separatorLength === 0)
                {
                    return 0;
                }
                current = ((current + separatorLength) | 0);
                if (current === input.Length)
                {
                    return 0;
                }
                /*var*/ let fromStartIndex = current;
                /*var*/ let fromLength;
                /*var*/ let toStartIndex;
                /*var*/ let toLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.TryGetRangeLength(input, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => fromLength, ($v) => fromLength = $v, $.$$.System.Int32), $.$ref(() => toStartIndex, ($v) => toStartIndex = $v, $.$$.System.Int32), $.$ref(() => toLength, ($v) => toLength = $v, $.$$.System.Int32)))
                {
                    return 0;
                }
                if ((current === input.Length) || (input.get_Item(current) !== /*/*/ 47))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (current === input.Length)
                {
                    return 0;
                }
                /*var*/ let lengthStartIndex = current;
                /*var*/ let lengthLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.TryGetLengthLength(input, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.System.Int32)))
                {
                    return 0;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.TryCreateContentRange(input, unit, fromStartIndex, fromLength, toStartIndex, toLength, lengthStartIndex, lengthLength, parsedValue))
                {
                    return 0;
                }
                return ((current - startIndex) | 0);
            }
            static /*bool */ TryGetLengthLength(/*StringSegment*/ input, /*ref int*/ current, /*out int*/ lengthLength)
            {
                lengthLength.$v = 0;
                if (input.get_Item(current.$v) === /***/ 42)
                {
                    current.$v++;
                }
                else 
                {
                    lengthLength.$v = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((lengthLength.$v === 0) || (lengthLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + lengthLength.$v) | 0);
                }
                current.$v = ((current.$v + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                return true;
            }
            static /*bool */ TryGetRangeLength(/*StringSegment*/ input, /*ref int*/ current, /*out int*/ fromLength, /*out int*/ toStartIndex, /*out int*/ toLength)
            {
                fromLength.$v = 0;
                toStartIndex.$v = 0;
                toLength.$v = 0;
                if (input.get_Item(current.$v) === /***/ 42)
                {
                    current.$v++;
                }
                else 
                {
                    fromLength.$v = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((fromLength.$v === 0) || (fromLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + fromLength.$v) | 0);
                    current.$v = ((current.$v + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                    if ((current.$v === input.Length) || (input.get_Item(current.$v) !== /*-*/ 45))
                    {
                        return false;
                    }
                    current.$v++;
                    current.$v = ((current.$v + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                    if (current.$v === input.Length)
                    {
                        return false;
                    }
                    toStartIndex.$v = current.$v;
                    toLength.$v = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current.$v, false);
                    if ((toLength.$v === 0) || (toLength.$v > 19/*HttpRuleParser.MaxInt64Digits*/))
                    {
                        return false;
                    }
                    current.$v = ((current.$v + toLength.$v) | 0);
                }
                current.$v = ((current.$v + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current.$v)) | 0);
                return true;
            }
            static /*bool */ TryCreateContentRange(/*StringSegment*/ input, /*StringSegment*/ unit, /*int*/ fromStartIndex, /*int*/ fromLength, /*int*/ toStartIndex, /*int*/ toLength, /*int*/ lengthStartIndex, /*int*/ lengthLength, /*out ContentRangeHeaderValue?*/ parsedValue)
            {
                parsedValue.$v = null;
                /*long*/ let $from = 0n;
                if ((fromLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(fromStartIndex, fromLength), $.$ref(() => $from, ($v) => $from = $v, $.$$.System.Int64)))
                {
                    return false;
                }
                /*long*/ let to = 0n;
                if ((toLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(toStartIndex, toLength), $.$ref(() => to, ($v) => to = $v, $.$$.System.Int64)))
                {
                    return false;
                }
                if ((fromLength > 0) && (toLength > 0) && ($from > to))
                {
                    return false;
                }
                /*long*/ let length = 0n;
                if ((lengthLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(lengthStartIndex, lengthLength), $.$ref(() => length, ($v) => length = $v, $.$$.System.Int64)))
                {
                    return false;
                }
                if ((toLength > 0) && (lengthLength > 0) && (to >= length))
                {
                    return false;
                }
                /*var*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue().$ctor$1();
                result._unit = unit;
                if (fromLength > 0)
                {
                    result.From = $from;
                    result.To = to;
                }
                if (lengthLength > 0)
                {
                    result.Length = length;
                }
                parsedValue.$v = result;
                return true;
            }
            //default member initializer
            constructor()
            {
                super();
                this._unit = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this.From = null;
                this.To = null;
                this.Length = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue.GetContentRangeLength));
                }
            }
            static $h = 363217;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851970,"g":{"r":0,"d":0,"h":34360101585,"f":50331649},"s":{"r":0,"d":0,"h":38655068881,"f":83886081},"n":"Unit","d":363217,"h":30065134289,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":51539970769,"f":50331649},"s":{"r":0,"d":0,"h":55834938065,"f":83886082},"n":"From","d":363217,"h":47245003473,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":68719839953,"f":50331649},"s":{"r":0,"d":0,"h":73014807249,"f":83886082},"n":"To","d":363217,"h":64424872657,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":85899709137,"f":50331649},"s":{"r":0,"d":0,"h":90194676433,"f":83886082},"n":"Length","d":363217,"h":81604741841,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":98784611025,"f":50331649},"n":"HasLength","d":363217,"h":94489643729,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":107374545617,"f":50331649},"n":"HasRange","d":363217,"h":103079578321,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":363217,"h":111669512913,"f":16809985},{"r":655361,"n":"GetHashCode","d":363217,"h":115964480209,"f":16809985},{"r":1310721,"n":"ToString","d":363217,"h":120259447505,"f":16809985},{"r":363217,"p":[{"n":"input","p":851970}],"n":"Parse","d":363217,"h":124554414801,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":363217,"f":2}],"n":"TryParse","d":363217,"h":128849382097,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":363217,"f":2}],"n":"GetContentRangeLength","d":363217,"h":133144349393,"f":16777250},{"r":262145,"p":[{"n":"input","p":851970},{"n":"current","p":655361,"f":4},{"n":"lengthLength","p":655361,"f":2}],"n":"TryGetLengthLength","d":363217,"h":137439316689,"f":16777250},{"r":262145,"p":[{"n":"input","p":851970},{"n":"current","p":655361,"f":4},{"n":"fromLength","p":655361,"f":2},{"n":"toStartIndex","p":655361,"f":2},{"n":"toLength","p":655361,"f":2}],"n":"TryGetRangeLength","d":363217,"h":141734283985,"f":16777250},{"r":262145,"p":[{"n":"input","p":851970},{"n":"unit","p":851970},{"n":"fromStartIndex","p":655361},{"n":"fromLength","p":655361},{"n":"toStartIndex","p":655361},{"n":"toLength","p":655361},{"n":"lengthStartIndex","p":655361},{"n":"lengthLength","p":655361},{"n":"parsedValue","p":363217,"f":2}],"n":"TryCreateContentRange","d":363217,"h":146029251281,"f":16777250}],"l":[{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentRangeHeaderValue).$h,"n":"Parser","d":363217,"h":4295330513,"f":4194338},{"t":851970,"n":"_unit","d":363217,"h":8590297809,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":363217,"h":12885265105,"f":16777218},{"p":[{"n":"from","p":917505},{"n":"to","p":917505},{"n":"length","p":917505}],"n":".ctor","o":"$ctor$2","d":363217,"h":17180232401,"f":16777217},{"p":[{"n":"length","p":917505}],"n":".ctor","o":"$ctor$4","d":363217,"h":21475199697,"f":16777217},{"p":[{"n":"from","p":917505},{"n":"to","p":917505}],"n":".ctor","o":"$ctor$3","d":363217,"h":25770166993,"f":16777217}],"h":363217}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ContentRangeHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue", ($self) => class RangeItemHeaderValue extends $.$$.System.Object
        {
            /*long?*/ _from = null;
            /*long?*/ _to = null;
            $ctor$1(/*long?*/ $from, /*long?*/ to)
            {
                super.$ctor();
                {
                    if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call($from) && !$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(to))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14("Invalid header range.");
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call($from) && ($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call($from) < 0n))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(to) && ($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(to) < 0n))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("to");
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call($from) && $.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(to) && ($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call($from) > $.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(to)))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("from");
                    }
                    this._from = $from;
                    this._to = to;
                }
                return this;
            }
            /*long? */ get From()
            {
                return this._from;
            }
            /*long? */ get To()
            {
                return this._to;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._from))
                {
                    return "-" + $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._to), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                }
                else if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._to))
                {
                    return $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._from), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo) + "-";
                }
                return $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._from), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo) + "-" + $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._to), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.ToString.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue, { set $v(v){ other = v; } }) && ((this._from === other._from) && (this._to === other._to));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._from))
                {
                    return $.$$.System.Int64.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._to));
                }
                else if (!$.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._to))
                {
                    return $.$$.System.Int64.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._from));
                }
                return $.$$.System.Int64.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._from)) ^ $.$$.System.Int64.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this._to));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.GetHashCode.apply(this, arguments); }
            static /*int */ GetRangeItemListLength(/*StringSegment*/ input, /*int*/ startIndex, /*ICollection<RangeItemHeaderValue>*/ rangeCollection)
            {
                ;
                ;
                if (($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input)) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(input, startIndex, true, $.$discardRef());
                if (current === input.Length)
                {
                    return 0;
                }
                while(true)
                {
                    /*var*/ let range;
                    /*var*/ let rangeLength = $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.GetRangeItemLength(input, current, $.$ref(() => range, ($v) => range = $v, $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue));
                    if (rangeLength === 0)
                    {
                        return 0;
                    }
                    rangeCollection.System$Collections$Generic$ICollection$$$Add(range, [$.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue]);
                    current = ((current + rangeLength) | 0);
                    /*var*/ let separatorFound;
                    current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetNextNonEmptyOrWhitespaceIndex(input, current, true, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                    if ((current < input.Length) && !separatorFound)
                    {
                        return 0;
                    }
                    if (current === input.Length)
                    {
                        return ((current - startIndex) | 0);
                    }
                }
            }
            static /*int */ GetRangeItemLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeItemHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let current = startIndex;
                /*var*/ let fromStartIndex = current;
                /*var*/ let fromLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current, false);
                if (fromLength > 19/*HttpRuleParser.MaxInt64Digits*/)
                {
                    return 0;
                }
                current = ((current + fromLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*-*/ 45))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let toStartIndex = current;
                /*var*/ let toLength = 0;
                if (current < input.Length)
                {
                    toLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, current, false);
                    if (toLength > 19/*HttpRuleParser.MaxInt64Digits*/)
                    {
                        return 0;
                    }
                    current = ((current + toLength) | 0);
                    current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                }
                if ((fromLength === 0) && (toLength === 0))
                {
                    return 0;
                }
                /*long*/ let $from = 0n;
                if ((fromLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(fromStartIndex, fromLength), $.$ref(() => $from, ($v) => $from = $v, $.$$.System.Int64)))
                {
                    return 0;
                }
                /*long*/ let to = 0n;
                if ((toLength > 0) && !$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(input.Subsegment(toStartIndex, toLength), $.$ref(() => to, ($v) => to = $v, $.$$.System.Int64)))
                {
                    return 0;
                }
                if ((fromLength > 0) && (toLength > 0) && ($from > to))
                {
                    return 0;
                }
                parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue().$ctor$1((fromLength === 0 ? null : $.$cast($from, $.$$.System.Nullable$$($.$$.System.Int64))), (toLength === 0 ? null : $.$cast(to, $.$$.System.Nullable$$($.$$.System.Int64))));
                return ((current - startIndex) | 0);
            }
            static $h = 1608401;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":21476444881,"f":50331649},"n":"From","d":1608401,"h":17181477585,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":30066379473,"f":50331649},"n":"To","d":1608401,"h":25771412177,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":1608401,"h":34361346769,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1608401,"h":38656314065,"f":16809985},{"r":655361,"n":"GetHashCode","d":1608401,"h":42951281361,"f":16809985},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"rangeCollection","p":$.$$.System.Collections.Generic.ICollection$$($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue).$h}],"n":"GetRangeItemListLength","d":1608401,"h":47246248657,"f":16777256},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":1608401,"f":2}],"n":"GetRangeItemLength","d":1608401,"h":51541215953,"f":16777256}],"l":[{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_from","d":1608401,"h":4296575697,"f":4194306},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_to","d":1608401,"h":8591542993,"f":4194306}],"c":[{"p":[{"n":"from","p":$.$typeNullable($.$$.System.Int64).$h},{"n":"to","p":$.$typeNullable($.$$.System.Int64).$h}],"n":".ctor","o":"$ctor$1","d":1608401,"h":12886510289,"f":16777217}],"h":1608401}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RangeItemHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue", ($self) => class EntityTagHeaderValue extends $.$$.System.Object
        {
            /*HttpHeaderParser<EntityTagHeaderValue>*/ static SingleValueParser = null;
            /*HttpHeaderParser<EntityTagHeaderValue>*/ static MultipleValueParser = null;
            /*StringSegment*/ _tag;
            /*bool*/ _isWeak = false;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*StringSegment*/ tag)
            {
                this.$ctor$2(tag, false);
                {
                }
                return this;
            }
            $ctor$2(/*StringSegment*/ tag, /*bool*/ isWeak)
            {
                super.$ctor();
                {
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(tag))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("An empty string is not allowed.", "tag");
                    }
                    /*var*/ let length;
                    if (!isWeak && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(tag, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("*"), 4/*StringComparison.Ordinal*/))
                    {
                        this._tag = tag;
                    }
                    else if (($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetQuotedStringLength(tag, 0, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)) !== 0/*HttpParseResult.Parsed*/) || (length !== tag.Length))
                    {
                        throw new $.$$.System.FormatException().$ctor$12("Invalid ETag name");
                    }
                    this._tag = tag;
                    this._isWeak = isWeak;
                }
                return this;
            }
            /*EntityTagHeaderValue*/ static Any = null;
            /*StringSegment */ get Tag()
            {
                return this._tag;
            }
            /*bool */ get IsWeak()
            {
                return this._isWeak;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this._isWeak)
                {
                    return "W/" + $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._tag);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._tag);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.ToString.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue, { set $v(v){ other = v; } }) && this._isWeak === other._isWeak && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._tag, other._tag, 4/*StringComparison.Ordinal*/);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(this._tag) ^ $.$$.System.Boolean.GetHashCode.call(this._isWeak);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetHashCode.apply(this, arguments); }
            /*bool */ Compare(/*EntityTagHeaderValue?*/ other, /*bool*/ useStrongComparison)
            {
                if (other === null)
                {
                    return false;
                }
                if (useStrongComparison)
                {
                    return !this.IsWeak && !other.IsWeak && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Tag, other.Tag, 4/*StringComparison.Ordinal*/);
                }
                else 
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Tag, other.Tag, 4/*StringComparison.Ordinal*/);
                }
            }
            static /*EntityTagHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out EntityTagHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*IList<EntityTagHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            static /*IList<EntityTagHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<EntityTagHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.MultipleValueParser.TryParseValues$1(inputs, parsedValues);
            }
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<EntityTagHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            static /*int */ GetEntityTagLength(/*StringSegment*/ input, /*int*/ startIndex, /*out EntityTagHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let isWeak = false;
                /*var*/ let current = startIndex;
                /*var*/ let firstChar = input.get_Item(startIndex);
                if (firstChar === /***/ 42)
                {
                    parsedValue.$v = $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.Any;
                    current++;
                }
                else 
                {
                    if ((firstChar === /*W*/ 87) || (firstChar === /*w*/ 119))
                    {
                        current++;
                        if ((((current + 2) | 0) >= input.Length) || (input.get_Item(current) !== /*/*/ 47))
                        {
                            return 0;
                        }
                        isWeak = true;
                        current++;
                        current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                    /*var*/ let tagStartIndex = current;
                    /*var*/ let tagLength;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetQuotedStringLength(input, current, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.System.Int32)) !== 0/*HttpParseResult.Parsed*/)
                    {
                        return 0;
                    }
                    parsedValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue().$ctor$1();
                    if (tagLength === input.Length)
                    {
                        $.$$.System.Diagnostics.Contracts.Contract.Assert$1(startIndex === 0);
                        $.$$.System.Diagnostics.Contracts.Contract.Assert$1(!isWeak);
                        parsedValue.$v._tag = input;
                        parsedValue.$v._isWeak = false;
                    }
                    else 
                    {
                        parsedValue.$v._tag = input.Subsegment(tagStartIndex, tagLength);
                        parsedValue.$v._isWeak = isWeak;
                    }
                    current = ((current + tagLength) | 0);
                }
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                return ((current - startIndex) | 0);
            }
            //default member initializer
            constructor()
            {
                super();
                this._tag = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetEntityTagLength));
                }
                {
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue.GetEntityTagLength));
                }
                {
                    this.Any = new $.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("*"), false);
                }
            }
            static $h = 625361;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":625361,"g":{"r":0,"d":0,"h":42950298321,"f":50331681},"n":"Any","d":625361,"h":38655331025,"f":2097185},{"p":851970,"g":{"r":0,"d":0,"h":51540232913,"f":50331649},"n":"Tag","d":625361,"h":47245265617,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60130167505,"f":50331649},"n":"IsWeak","d":625361,"h":55835200209,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":625361,"h":64425134801,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":625361,"h":68720102097,"f":16809985},{"r":655361,"n":"GetHashCode","d":625361,"h":73015069393,"f":16809985},{"r":262145,"p":[{"n":"other","p":625361},{"n":"useStrongComparison","p":262145}],"n":"Compare","d":625361,"h":77310036689,"f":16777217},{"r":625361,"p":[{"n":"input","p":851970}],"n":"Parse","d":625361,"h":81605003985,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":625361,"f":2}],"n":"TryParse","d":625361,"h":85899971281,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseList","d":625361,"h":90194938577,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseStrictList","d":625361,"h":94489905873,"f":16777249},{"r":262145,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,"f":2}],"n":"TryParseList","d":625361,"h":98784873169,"f":16777249},{"r":262145,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,"f":2}],"n":"TryParseStrictList","d":625361,"h":103079840465,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":625361,"f":2}],"n":"GetEntityTagLength","d":625361,"h":107374807761,"f":16777256}],"l":[{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,"n":"SingleValueParser","d":625361,"h":4295592657,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.EntityTagHeaderValue).$h,"n":"MultipleValueParser","d":625361,"h":8590559953,"f":4194338},{"t":851970,"n":"_tag","d":625361,"h":12885527249,"f":4194306},{"t":262145,"n":"_isWeak","d":625361,"h":17180494545,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":625361,"h":21475461841,"f":16777218},{"p":[{"n":"tag","p":851970}],"n":".ctor","o":"$ctor$3","d":625361,"h":25770429137,"f":16777217},{"p":[{"n":"tag","p":851970},{"n":"isWeak","p":262145}],"n":".ctor","o":"$ctor$2","d":625361,"h":30065396433,"f":16777217}],"h":625361}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EntityTagHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue", ($self) => class ContentDispositionHeaderValue extends $.$$.System.Object
        {
            /*string*/ static FileNameString = null;
            /*string*/ static NameString = null;
            /*string*/ static FileNameStarString = null;
            /*string*/ static CreationDateString = null;
            /*string*/ static ModificationDateString = null;
            /*string*/ static ReadDateString = null;
            /*string*/ static SizeString = null;
            /*int*/ static MaxStackAllocSizeBytes = 256;
            /*char[]*/ static QuestionMark = null;
            /*char[]*/ static SingleQuote = null;
            /*char[]*/ static EscapeChars = null;
            static /*ReadOnlySpan<byte> */ get MimePrefix()
            {
                return this.$cacheMimePrefix ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([34, 61, 63, 117, 116, 102, 45, 56, 63, 66, 63]);
            }
            static /*ReadOnlySpan<byte> */ get MimeSuffix()
            {
                return this.$cacheMimeSuffix ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([63, 61, 34]);
            }
            /*SearchValues<char>*/ static Rfc5987AttrChar = null;
            /*HttpHeaderParser<ContentDispositionHeaderValue>*/ static Parser = null;
            /*ObjectCollection<NameValueHeaderValue>?*/ _parameters = null;
            /*StringSegment*/ _dispositionType;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*StringSegment*/ dispositionType)
            {
                super.$ctor();
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.CheckDispositionTypeFormat(dispositionType, "dispositionType");
                    this._dispositionType = dispositionType;
                }
                return this;
            }
            /*StringSegment */ get DispositionType()
            {
                return this._dispositionType;
            }
            /*StringSegment */ set DispositionType(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.CheckDispositionTypeFormat(value, "value");
                this._dispositionType = value;
            }
            /*IList<NameValueHeaderValue> */ get Parameters()
            {
                if (this._parameters === null)
                {
                    this._parameters = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3();
                }
                return this._parameters;
            }
            /*StringSegment */ get Name()
            {
                return this.GetName("name"/*NameString*/);
            }
            /*StringSegment */ set Name(value)
            {
                this.SetName($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("name"/*NameString*/), value);
            }
            /*StringSegment */ get FileName()
            {
                return this.GetName("filename"/*FileNameString*/);
            }
            /*StringSegment */ set FileName(value)
            {
                this.SetName($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("filename"/*FileNameString*/), value);
            }
            /*StringSegment */ get FileNameStar()
            {
                return this.GetName("filename*"/*FileNameStarString*/);
            }
            /*StringSegment */ set FileNameStar(value)
            {
                this.SetName($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("filename*"/*FileNameStarString*/), value);
            }
            /*DateTimeOffset? */ get CreationDate()
            {
                return this.GetDate("creation-date"/*CreationDateString*/);
            }
            /*DateTimeOffset? */ set CreationDate(value)
            {
                this.SetDate("creation-date"/*CreationDateString*/, value?.Clone() ?? null);
            }
            /*DateTimeOffset? */ get ModificationDate()
            {
                return this.GetDate("modification-date"/*ModificationDateString*/);
            }
            /*DateTimeOffset? */ set ModificationDate(value)
            {
                this.SetDate("modification-date"/*ModificationDateString*/, value?.Clone() ?? null);
            }
            /*DateTimeOffset? */ get ReadDate()
            {
                return this.GetDate("read-date"/*ReadDateString*/);
            }
            /*DateTimeOffset? */ set ReadDate(value)
            {
                this.SetDate("read-date"/*ReadDateString*/, value?.Clone() ?? null);
            }
            /*long? */ get Size()
            {
                /*var*/ let sizeParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("size"/*SizeString*/));
                if (sizeParameter !== null)
                {
                    /*var*/ let sizeString = sizeParameter.Value;
                    /*var*/ let value;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(sizeString, $.$ref(() => value, ($v) => value = $v, $.$$.System.Int64)))
                    {
                        return value;
                    }
                }
                return null;
            }
            /*long? */ set Size(value)
            {
                /*var*/ let sizeParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("size"/*SizeString*/));
                if (value === null)
                {
                    if (sizeParameter !== null)
                    {
                        this._parameters.Remove(sizeParameter);
                    }
                }
                else if (value < 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                else if (sizeParameter !== null)
                {
                    sizeParameter.Value = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(value), $.$$.System.Globalization.CultureInfo.InvariantCulture));
                }
                else 
                {
                    /*var*/ let sizeString = $.$$.System.Int64.ToString$1.call($.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(value), $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("size"/*SizeString*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(sizeString)), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                }
            }
            /*void */ SetHttpFileName(/*StringSegment*/ fileName)
            {
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(fileName))
                {
                    this.FileName = $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Sanitize(fileName);
                }
                else 
                {
                    this.FileName = fileName;
                }
                this.FileNameStar = fileName;
            }
            /*void */ SetMimeFileName(/*StringSegment*/ fileName)
            {
                this.FileNameStar = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                this.FileName = fileName;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._dispositionType) + $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString$2(this._parameters, /*;*/ 59, true);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.ToString.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return this._dispositionType.Equals$4(other._dispositionType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._parameters, other._parameters);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._dispositionType) ^ $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode$1(this._parameters);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.GetHashCode.apply(this, arguments); }
            static /*ContentDispositionHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out ContentDispositionHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*int */ GetDispositionTypeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out ContentDispositionHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let dispositionType;
                /*var*/ let dispositionTypeLength = $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.GetDispositionTypeExpressionLength(input, startIndex, $.$ref(() => dispositionType, ($v) => dispositionType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                if (dispositionTypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + dispositionTypeLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let contentDispositionHeader = new $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue().$ctor$1();
                contentDispositionHeader._dispositionType = dispositionType;
                if ((current < input.Length) && (input.get_Item(current) === /*;*/ 59))
                {
                    current++;
                    /*int*/ let parameterLength = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueListLength(input, current, /*;*/ 59, contentDispositionHeader.Parameters);
                    parsedValue.$v = contentDispositionHeader;
                    return ((((current + parameterLength) | 0) - startIndex) | 0);
                }
                parsedValue.$v = contentDispositionHeader;
                return ((current - startIndex) | 0);
            }
            static /*int */ GetDispositionTypeExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringSegment*/ dispositionType)
            {
                ;
                dispositionType.$v = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                /*var*/ let typeLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (typeLength === 0)
                {
                    return 0;
                }
                dispositionType.$v = input.Subsegment(startIndex, typeLength);
                return typeLength;
            }
            static /*void */ CheckDispositionTypeFormat(/*StringSegment*/ dispositionType, /*string*/ parameterName)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(dispositionType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                /*var*/ let tempDispositionType;
                /*var*/ let dispositionTypeLength = $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.GetDispositionTypeExpressionLength(dispositionType, 0, $.$ref(() => tempDispositionType, ($v) => tempDispositionType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                if ((dispositionTypeLength === 0) || (tempDispositionType.Length !== dispositionType.Length))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "Invalid disposition type '{0}'.", dispositionType));
                }
            }
            /*DateTimeOffset? */ GetDate(/*string*/ parameter)
            {
                /*var*/ let dateParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(parameter));
                if (dateParameter !== null)
                {
                    /*var*/ let dateString = dateParameter.Value;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsQuoted(dateString))
                    {
                        dateString = dateString.Subsegment(1, ((dateString.Length - 2) | 0));
                    }
                    /*DateTimeOffset*/ let date;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TryStringToDate(dateString, $.$ref(() => date, ($v) => date = $v, $.$$.System.DateTimeOffset)))
                    {
                        return date;
                    }
                }
                return null;
            }
            /*void */ SetDate(/*string*/ parameter, /*DateTimeOffset?*/ date)
            {
                /*var*/ let dateParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(parameter));
                if (date === null)
                {
                    if (dateParameter !== null)
                    {
                        this._parameters.Remove(dateParameter);
                    }
                }
                else 
                {
                    /*var*/ let dateString = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatDate($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(date), true);
                    if (dateParameter !== null)
                    {
                        dateParameter.Value = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(dateString);
                    }
                    else 
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(parameter), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(dateString)), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            /*StringSegment */ GetName(/*string*/ parameter)
            {
                /*var*/ let nameParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(parameter));
                if (nameParameter !== null)
                {
                    /*string?*/ let result;
                    if ($.$$.System.String.EndsWith.call(parameter, /***/ 42))
                    {
                        if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.TryDecode5987(nameParameter.Value, $.$ref(() => result, ($v) => result = $v, $.$$.System.String)))
                        {
                            return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(result);
                        }
                        return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                    }
                    if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.TryDecodeMime(nameParameter.Value, $.$ref(() => result, ($v) => result = $v, $.$$.System.String)))
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(result);
                    }
                    return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(nameParameter.Value);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
            }
            /*void */ SetName(/*StringSegment*/ parameter, /*StringSegment*/ value)
            {
                /*var*/ let nameParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, parameter);
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value))
                {
                    if (nameParameter !== null)
                    {
                        this._parameters.Remove(nameParameter);
                    }
                }
                else 
                {
                    /*StringSegment*/ let processedValue;
                    if (parameter.EndsWith("*", 4/*StringComparison.Ordinal*/))
                    {
                        processedValue = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Encode5987(value));
                    }
                    else 
                    {
                        processedValue = this.EncodeAndQuoteMime(value);
                    }
                    if (nameParameter !== null)
                    {
                        nameParameter.Value = processedValue;
                    }
                    else 
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2(parameter, processedValue), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            /*StringSegment */ EncodeAndQuoteMime(/*StringSegment*/ input)
            {
                /*var*/ let result = input;
                /*var*/ let needsQuotes = false;
                if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsQuoted(result))
                {
                    result = result.Subsegment(1, ((result.Length - 2) | 0));
                    needsQuotes = true;
                }
                if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.RequiresEncoding(result))
                {
                    needsQuotes = false;
                    result = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(this.EncodeMimeWithQuotes(result));
                }
                else if (!needsQuotes && $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(result, 0) !== result.Length)
                {
                    needsQuotes = true;
                }
                if (needsQuotes)
                {
                    if (result.IndexOfAny$2($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.EscapeChars) !== -1)
                    {
                        result = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Replace$3.call($.$$.System.String.Replace$3.call($.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(result), "\\", "\\\\"), "\"", "\\\""));
                    }
                    result = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "\"{0}\"", result));
                }
                return result;
            }
            static /*StringSegment */ Sanitize(/*StringSegment*/ input)
            {
                /*var*/ let result = input;
                if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.RequiresEncoding(result))
                {
                    /*var*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$4(result.Length);
                    for(/*int*/ let i = 0; i < result.Length; i++)
                    {
                        /*var*/ let c = result.get_Item(i);
                        if ($.$cast(c, $.$$.System.Int32) >= 127 || $.$cast(c, $.$$.System.Int32) < 32)
                        {
                            c = /*_*/ 95;
                        }
                        builder.Append$3(c);
                    }
                    result = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.Text.StringBuilder.ToString.call(builder));
                }
                return result;
            }
            static /*bool */ IsQuoted(/*StringSegment*/ value)
            {
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)));
                return value.Length > 1 && value.StartsWith("\"", 4/*StringComparison.Ordinal*/) && value.EndsWith("\"", 4/*StringComparison.Ordinal*/);
            }
            static /*bool */ RequiresEncoding(/*StringSegment*/ input)
            {
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(input, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)));
                return $.$$.System.MemoryExtensions.IndexOfAnyExceptInRange($.$$.System.Char, input.AsSpan(), 32, 126) >= 0;
            }
            /*string */ EncodeMimeWithQuotes(/*StringSegment*/ input)
            {
                /*var*/ let requiredLength = (((($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimePrefix.Length + $.$$.System.Buffers.Text.Base64.GetMaxEncodedToUtf8Length($.$$.System.Text.Encoding.UTF8.GetByteCount$4(input.AsSpan()))) | 0) + $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimeSuffix.Length) | 0);
                /*byte[]?*/ let bufferFromPool = null;
                /*Span<byte>*/ let buffer = requiredLength <= 256/*MaxStackAllocSizeBytes*/ ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 256/*MaxStackAllocSizeBytes*/, null) : $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(bufferFromPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(requiredLength));
                let $t1 = buffer;
                buffer = $t1.Slice(0, requiredLength);
                $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimePrefix.CopyTo(buffer);
                /*var*/ let bufferContent = buffer.Slice$1($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimePrefix.Length);
                /*var*/ let contentLength = $.$$.System.Text.Encoding.UTF8.GetBytes$5(input.AsSpan(), bufferContent);
                /*var*/ let base64ContentLength;
                $.$$.System.Buffers.Text.Base64.EncodeToUtf8InPlace(bufferContent, contentLength, $.$ref(() => base64ContentLength, ($v) => base64ContentLength = $v, $.$$.System.Int32));
                $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimeSuffix.CopyTo(bufferContent.Slice$1(base64ContentLength));
                /*var*/ let result = $.$$.System.Text.Encoding.UTF8.GetString$3($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer.Slice(0, (((($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimePrefix.Length + base64ContentLength) | 0) + $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.MimeSuffix.Length) | 0))));
                if (!(bufferFromPool === null))
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(bufferFromPool, false);
                }
                return result;
            }
            static /*bool */ TryDecodeMime(/*StringSegment*/ input, /*out string?*/ output)
            {
                $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(input, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)));
                output.$v = null;
                /*var*/ let processedInput = input;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsQuoted(processedInput) || processedInput.Length < 10)
                {
                    return false;
                }
                /*var*/ let parts = $.$sl.System.Linq.Enumerable.ToArray($.$mep.Microsoft.Extensions.Primitives.StringSegment, processedInput.Split($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.QuestionMark));
                if (parts.length !== 5 || $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality($.$$.System.Array.$ReadT1.call(parts, 0), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("\"=")) || $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality($.$$.System.Array.$ReadT1.call(parts, 4), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("=\"")) || !$.$$.System.Array.$ReadT1.call(parts, 2).Equals$2("b", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                try
                {
                    /*var*/ let encoding = $.$$.System.Text.Encoding.GetEncoding$3($.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$$.System.Array.$ReadT1.call(parts, 1)));
                    /*var*/ let bytes = $.$$.System.Convert.FromBase64String($.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$$.System.Array.$ReadT1.call(parts, 3)));
                    output.$v = encoding.GetString(bytes, 0, bytes.length);
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.ArgumentException)
                    {
                    }
                    else if ($e instanceof $.$$.System.FormatException)
                    {
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return false;
            }
            static /*string */ Encode5987(/*StringSegment*/ input)
            {
                /*var*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$8("UTF-8''");
                /*var*/ let remaining = input.AsSpan();
                while(remaining.Length > 0)
                {
                    /*var*/ let length = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, remaining, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Rfc5987AttrChar);
                    if (length < 0)
                    {
                        length = remaining.Length;
                    }
                    let $t1 = remaining;
                    builder.Append$15($t1.Slice(0, length));
                    remaining = remaining.Slice$1(length);
                    if (remaining.Length === 0)
                    {
                        break;
                    }
                    length = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, remaining, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.Rfc5987AttrChar);
                    if (length < 0)
                    {
                        length = remaining.Length;
                    }
                    for(/*var*/ let i = 0; i < length; )
                    {
                        /*Rune*/ let rune;
                        /*var*/ let runeLength;
                        $.$$.System.Text.Rune.DecodeFromUtf16(remaining.Slice$1(i), $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune), $.$ref(() => runeLength, ($v) => runeLength = $v, $.$$.System.Int32));
                        $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.EncodeToUtf8Hex(rune, builder);
                        i += runeLength;
                    }
                    remaining = remaining.Slice$1(length);
                }
                return $.$$.System.Text.StringBuilder.ToString.call(builder);
            }
            /*char[]*/ static HexUpperChars = null;
            static /*void */ EncodeToUtf8Hex(/*Rune*/ rune, /*StringBuilder*/ builder)
            {
                /*var*/ let value = (rune.Value >>> 0);
                if (rune.IsAscii)
                {
                    /*var*/ let byteValue = $.$cast(value, $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                }
                else if (BigInt(rune.Value) <= 2047n)
                {
                    /*var*/ let byteValue = $.$cast(((((value + ((6 << 11) >>> 0)) >>> 0)) >>> 6), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast(((((value & 63) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                }
                else if (BigInt(rune.Value) <= 65535n)
                {
                    /*var*/ let byteValue = $.$cast(((value + (14 << 16)) >>> 12), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast((((((value & ((63 << 6) >>> 0)) >>> 6) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast(((((value & 63) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                }
                else 
                {
                    /*var*/ let byteValue = $.$cast(((value + (30 << 21)) >>> 18), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast((((((value & ((63 << 12) >>> 0)) >>> 12) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast((((((value & ((63 << 6) >>> 0)) >>> 6) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                    byteValue = $.$cast(((((value & 63) + 128) >>> 0)), $.$$.System.Byte);
                    builder.Append$9($.$$.System.Globalization.CultureInfo.InvariantCulture, `%${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, (byteValue & 240) >> 4))}${$.$$.System.Char.ToString.call($.$$.System.Array.$ReadT1.call($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUpperChars, byteValue & 15))}`);
                }
            }
            static /*bool */ TryDecode5987(/*StringSegment*/ input, /*out string?*/ output)
            {
                output.$v = null;
                /*var*/ let parts = $.$sl.System.Linq.Enumerable.ToArray($.$mep.Microsoft.Extensions.Primitives.StringSegment, input.Split($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.SingleQuote));
                if (parts.length !== 3)
                {
                    return false;
                }
                /*var*/ let decoded = new $.$$.System.Text.StringBuilder().$ctor$1();
                /*byte[]?*/ let unescapedBytes = null;
                try
                {
                    /*var*/ let encoding = $.$$.System.Text.Encoding.GetEncoding$3($.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$$.System.Array.$ReadT1.call(parts, 0)));
                    /*var*/ let dataString = $.$$.System.Array.$ReadT1.call(parts, 2);
                    unescapedBytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(dataString.Length);
                    /*var*/ let unescapedBytesCount = 0;
                    for(/*var*/ let index = 0; index < dataString.Length; index++)
                    {
                        if ($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsHexEncoding(dataString, index))
                        {
                            $.$$.System.Array.$WriteT1.call(unescapedBytes, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.HexUnescape(dataString, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32)), unescapedBytesCount++);
                            index--;
                        }
                        else 
                        {
                            if (unescapedBytesCount > 0)
                            {
                                decoded.Append$19(encoding.GetString(unescapedBytes, 0, unescapedBytesCount));
                                unescapedBytesCount = 0;
                            }
                            decoded.Append$3(dataString.get_Item(index));
                        }
                    }
                    if (unescapedBytesCount > 0)
                    {
                        decoded.Append$19(encoding.GetString(unescapedBytes, 0, unescapedBytesCount));
                    }
                }
                catch($e)
                {
                    return false;
                }
                finally
                {
                    {
                        if (unescapedBytes !== null)
                        {
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(unescapedBytes, false);
                        }
                    }
                }
                output.$v = $.$$.System.Text.StringBuilder.ToString.call(decoded);
                return true;
            }
            static /*bool */ IsHexEncoding(/*StringSegment*/ pattern, /*int*/ index)
            {
                if ((((pattern.Length - index) | 0)) < 3)
                {
                    return false;
                }
                if ((pattern.get_Item(index) === /*%*/ 37) && $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.IsEscapedAscii(pattern.get_Item(((index + 1) | 0)), pattern.get_Item(((index + 2) | 0))))
                {
                    return true;
                }
                return false;
            }
            static /*bool */ IsEscapedAscii(/*char*/ digit, /*char*/ next)
            {
                if (!(((digit >= /*0*/ 48) && (digit <= /*9*/ 57)) || ((digit >= /*A*/ 65) && (digit <= /*F*/ 70)) || ((digit >= /*a*/ 97) && (digit <= /*f*/ 102))))
                {
                    return false;
                }
                if (!(((next >= /*0*/ 48) && (next <= /*9*/ 57)) || ((next >= /*A*/ 65) && (next <= /*F*/ 70)) || ((next >= /*a*/ 97) && (next <= /*f*/ 102))))
                {
                    return false;
                }
                return true;
            }
            static /*byte */ HexUnescape(/*StringSegment*/ pattern, /*ref int*/ index)
            {
                if ((index.$v < 0) || (index.$v >= pattern.Length))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
                }
                if ((pattern.get_Item(index.$v) === /*%*/ 37) && (((pattern.Length - index.$v) | 0) >= 3))
                {
                    /*var*/ let ret = $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.UnEscapeAscii(pattern.get_Item(((index.$v + 1) | 0)), pattern.get_Item(((index.$v + 2) | 0)));
                    index.$v += 3;
                    return ret;
                }
                return $.$cast(pattern.get_Item(index.$v++), $.$$.System.Byte);
            }
            static /*byte */ UnEscapeAscii(/*char*/ digit, /*char*/ next)
            {
                if (!(((digit >= /*0*/ 48) && (digit <= /*9*/ 57)) || ((digit >= /*A*/ 65) && (digit <= /*F*/ 70)) || ((digit >= /*a*/ 97) && (digit <= /*f*/ 102))))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("digit");
                }
                /*var*/ let res = (digit <= /*9*/ 57) ? ((($.$cast(digit, $.$$.System.Int32) - /*0*/ 48) | 0)) : (((((digit <= /*F*/ 70) ? ((($.$cast(digit, $.$$.System.Int32) - /*A*/ 65) | 0)) : ((($.$cast(digit, $.$$.System.Int32) - /*a*/ 97) | 0))) + 10) | 0));
                if (!(((next >= /*0*/ 48) && (next <= /*9*/ 57)) || ((next >= /*A*/ 65) && (next <= /*F*/ 70)) || ((next >= /*a*/ 97) && (next <= /*f*/ 102))))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("next");
                }
                return $.$cast(((((res << 4) + ((next <= /*9*/ 57) ? ((($.$cast(next, $.$$.System.Int32) - /*0*/ 48) | 0)) : (((((next <= /*F*/ 70) ? ((($.$cast(next, $.$$.System.Int32) - /*A*/ 65) | 0)) : ((($.$cast(next, $.$$.System.Int32) - /*a*/ 97) | 0))) + 10) | 0)))) | 0)), $.$$.System.Byte);
            }
            //default member initializer
            constructor()
            {
                super();
                this._dispositionType = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.FileNameString = "filename";
                }
                {
                    this.NameString = "name";
                }
                {
                    this.FileNameStarString = "filename*";
                }
                {
                    this.CreationDateString = "creation-date";
                }
                {
                    this.ModificationDateString = "modification-date";
                }
                {
                    this.ReadDateString = "read-date";
                }
                {
                    this.SizeString = "size";
                }
                {
                    this.QuestionMark = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*?*/ 63], [-1], null);
                }
                {
                    this.SingleQuote = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*'*/ 39], [-1], null);
                }
                {
                    this.EscapeChars = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*\\*/ 92, /*\"*/ 34], [-1], null);
                }
                {
                    this.Rfc5987AttrChar = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!#$&+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"));
                }
                {
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.GetDispositionTypeLength));
                }
                {
                    this.HexUpperChars = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*0*/ 48, /*1*/ 49, /*2*/ 50, /*3*/ 51, /*4*/ 52, /*5*/ 53, /*6*/ 54, /*7*/ 55, /*8*/ 56, /*9*/ 57, /*A*/ 65, /*B*/ 66, /*C*/ 67, /*D*/ 68, /*E*/ 69, /*F*/ 70], null, null);
                }
            }
            static $h = 232145;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":55834806993,"f":50331682},"n":"MimePrefix","d":232145,"h":51539839697,"f":2097186},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":64424741585,"f":50331682},"n":"MimeSuffix","d":232145,"h":60129774289,"f":2097186},{"p":851970,"g":{"r":0,"d":0,"h":98784479953,"f":50331649},"s":{"r":0,"d":0,"h":103079447249,"f":83886081},"n":"DispositionType","d":232145,"h":94489512657,"f":2097153},{"p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"g":{"r":0,"d":0,"h":111669381841,"f":50331649},"n":"Parameters","d":232145,"h":107374414545,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":120259316433,"f":50331649},"s":{"r":0,"d":0,"h":124554283729,"f":83886081},"n":"Name","d":232145,"h":115964349137,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":133144218321,"f":50331649},"s":{"r":0,"d":0,"h":137439185617,"f":83886081},"n":"FileName","d":232145,"h":128849251025,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":146029120209,"f":50331649},"s":{"r":0,"d":0,"h":150324087505,"f":83886081},"n":"FileNameStar","d":232145,"h":141734152913,"f":2097153},{"p":$.$typeNullable($.$$.System.DateTimeOffset).$h,"g":{"r":0,"d":0,"h":158914022097,"f":50331649},"s":{"r":0,"d":0,"h":163208989393,"f":83886081},"n":"CreationDate","d":232145,"h":154619054801,"f":2097153},{"p":$.$typeNullable($.$$.System.DateTimeOffset).$h,"g":{"r":0,"d":0,"h":171798923985,"f":50331649},"s":{"r":0,"d":0,"h":176093891281,"f":83886081},"n":"ModificationDate","d":232145,"h":167503956689,"f":2097153},{"p":$.$typeNullable($.$$.System.DateTimeOffset).$h,"g":{"r":0,"d":0,"h":184683825873,"f":50331649},"s":{"r":0,"d":0,"h":188978793169,"f":83886081},"n":"ReadDate","d":232145,"h":180388858577,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":197568727761,"f":50331649},"s":{"r":0,"d":0,"h":201863695057,"f":83886081},"n":"Size","d":232145,"h":193273760465,"f":2097153}],"m":[{"r":65537,"p":[{"n":"fileName","p":851970}],"n":"SetHttpFileName","d":232145,"h":206158662353,"f":16777217},{"r":65537,"p":[{"n":"fileName","p":851970}],"n":"SetMimeFileName","d":232145,"h":210453629649,"f":16777217},{"r":1310721,"n":"ToString","d":232145,"h":214748596945,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":232145,"h":219043564241,"f":16809985},{"r":655361,"n":"GetHashCode","d":232145,"h":223338531537,"f":16809985},{"r":232145,"p":[{"n":"input","p":851970}],"n":"Parse","d":232145,"h":227633498833,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":232145,"f":2}],"n":"TryParse","d":232145,"h":231928466129,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":232145,"f":2}],"n":"GetDispositionTypeLength","d":232145,"h":236223433425,"f":16777250},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"dispositionType","p":851970,"f":2}],"n":"GetDispositionTypeExpressionLength","d":232145,"h":240518400721,"f":16777250},{"r":65537,"p":[{"n":"dispositionType","p":851970},{"n":"parameterName","p":1310721}],"n":"CheckDispositionTypeFormat","d":232145,"h":244813368017,"f":16777250},{"r":$.$typeNullable($.$$.System.DateTimeOffset).$h,"p":[{"n":"parameter","p":1310721}],"n":"GetDate","d":232145,"h":249108335313,"f":16777218},{"r":65537,"p":[{"n":"parameter","p":1310721},{"n":"date","p":$.$typeNullable($.$$.System.DateTimeOffset).$h}],"n":"SetDate","d":232145,"h":253403302609,"f":16777218},{"r":851970,"p":[{"n":"parameter","p":1310721}],"n":"GetName","d":232145,"h":257698269905,"f":16777218},{"r":65537,"p":[{"n":"parameter","p":851970},{"n":"value","p":851970}],"n":"SetName","d":232145,"h":261993237201,"f":16777218},{"r":851970,"p":[{"n":"input","p":851970}],"n":"EncodeAndQuoteMime","d":232145,"h":266288204497,"f":16777218},{"r":851970,"p":[{"n":"input","p":851970}],"n":"Sanitize","d":232145,"h":270583171793,"f":16777250},{"r":262145,"p":[{"n":"value","p":851970}],"n":"IsQuoted","d":232145,"h":274878139089,"f":16777250},{"r":262145,"p":[{"n":"input","p":851970}],"n":"RequiresEncoding","d":232145,"h":279173106385,"f":16777250},{"r":1310721,"p":[{"n":"input","p":851970}],"n":"EncodeMimeWithQuotes","d":232145,"h":283468073681,"f":16777218,"a":[{"t":95354881,"c":4390322177}]},{"r":262145,"p":[{"n":"input","p":851970},{"n":"output","p":1310721,"f":2}],"n":"TryDecodeMime","d":232145,"h":287763040977,"f":16777250},{"r":1310721,"p":[{"n":"input","p":851970}],"n":"Encode5987","d":232145,"h":292058008273,"f":16777250,"a":[{"t":95354881,"c":4390322177}]},{"r":65537,"p":[{"n":"rune","p":122617857},{"n":"builder","p":122814465}],"n":"EncodeToUtf8Hex","d":232145,"h":300647942865,"f":16777250},{"r":262145,"p":[{"n":"input","p":851970},{"n":"output","p":1310721,"f":2}],"n":"TryDecode5987","d":232145,"h":304942910161,"f":16777250},{"r":262145,"p":[{"n":"pattern","p":851970},{"n":"index","p":655361}],"n":"IsHexEncoding","d":232145,"h":309237877457,"f":16777250},{"r":262145,"p":[{"n":"digit","p":458753},{"n":"next","p":458753}],"n":"IsEscapedAscii","d":232145,"h":313532844753,"f":16777250},{"r":393217,"p":[{"n":"pattern","p":851970},{"n":"index","p":655361,"f":4}],"n":"HexUnescape","d":232145,"h":317827812049,"f":16777250},{"r":393217,"p":[{"n":"digit","p":458753},{"n":"next","p":458753}],"n":"UnEscapeAscii","d":232145,"h":322122779345,"f":16777256}],"l":[{"t":1310721,"n":"FileNameString","d":232145,"h":4295199441,"f":4194338},{"t":1310721,"n":"NameString","d":232145,"h":8590166737,"f":4194338},{"t":1310721,"n":"FileNameStarString","d":232145,"h":12885134033,"f":4194338},{"t":1310721,"n":"CreationDateString","d":232145,"h":17180101329,"f":4194338},{"t":1310721,"n":"ModificationDateString","d":232145,"h":21475068625,"f":4194338},{"t":1310721,"n":"ReadDateString","d":232145,"h":25770035921,"f":4194338},{"t":1310721,"n":"SizeString","d":232145,"h":30065003217,"f":4194338},{"t":655361,"n":"MaxStackAllocSizeBytes","d":232145,"h":34359970513,"f":4194338},{"t":$.$typeArray($.$$.System.Char).$h,"n":"QuestionMark","d":232145,"h":38654937809,"f":4194338},{"t":$.$typeArray($.$$.System.Char).$h,"n":"SingleQuote","d":232145,"h":42949905105,"f":4194338},{"t":$.$typeArray($.$$.System.Char).$h,"n":"EscapeChars","d":232145,"h":47244872401,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"Rfc5987AttrChar","d":232145,"h":68719708881,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue).$h,"n":"Parser","d":232145,"h":73014676177,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"n":"_parameters","d":232145,"h":77309643473,"f":4194306},{"t":851970,"n":"_dispositionType","d":232145,"h":81604610769,"f":4194306},{"t":$.$typeArray($.$$.System.Char).$h,"n":"HexUpperChars","d":232145,"h":296352975569,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":232145,"h":85899578065,"f":16777218},{"p":[{"n":"dispositionType","p":851970}],"n":".ctor","o":"$ctor$2","d":232145,"h":90194545361,"f":16777217}],"h":232145}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ContentDispositionHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue", ($self) => class StringWithQualityHeaderValue extends $.$$.System.Object
        {
            /*HttpHeaderParser<StringWithQualityHeaderValue>*/ static SingleValueParser = null;
            /*HttpHeaderParser<StringWithQualityHeaderValue>*/ static MultipleValueParser = null;
            /*StringSegment*/ _value;
            /*double?*/ _quality = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*StringSegment*/ value)
            {
                super.$ctor();
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(value, "value");
                    this._value = value;
                }
                return this;
            }
            $ctor$2(/*StringSegment*/ value, /*double*/ quality)
            {
                super.$ctor();
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(value, "value");
                    if ((quality < 0) || (quality > 1))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("quality");
                    }
                    this._value = value;
                    this._quality = quality;
                }
                return this;
            }
            /*StringSegment */ get Value()
            {
                return this._value;
            }
            /*double? */ get Quality()
            {
                return this._quality;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(this._quality))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._value) + "; q=" + $.$$.System.Double.ToString$2.call($.$$.System.Nullable$$($.$$.System.Double).GetValueOrDefault.call(this._quality), "0.0##", $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call(this._value);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.ToString.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue);
                if (other === null)
                {
                    return false;
                }
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(this._quality))
                {
                    return $.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(other._quality) && ($.$$.System.Nullable$$($.$$.System.Double).GetValueOrDefault.call(this._quality) === $.$$.System.Nullable$$($.$$.System.Double).Value$get.call(other._quality));
                }
                return !$.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(other._quality);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*var*/ let result = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value);
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(this._quality))
                {
                    result = result ^ $.$$.System.Double.GetHashCode.call($.$$.System.Nullable$$($.$$.System.Double).GetValueOrDefault.call(this._quality));
                }
                return result;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.GetHashCode.apply(this, arguments); }
            static /*StringWithQualityHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out StringWithQualityHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*IList<StringWithQualityHeaderValue> */ ParseList(/*IList<string>?*/ input)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.MultipleValueParser.ParseValues$1(input);
            }
            static /*IList<StringWithQualityHeaderValue> */ ParseStrictList(/*IList<string>?*/ input)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.MultipleValueParser.ParseStrictValues(input);
            }
            static /*bool */ TryParseList(/*IList<string>?*/ input, /*out IList<StringWithQualityHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.MultipleValueParser.TryParseValues$1(input, parsedValues);
            }
            static /*bool */ TryParseStrictList(/*IList<string>?*/ input, /*out IList<StringWithQualityHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.MultipleValueParser.TryParseStrictValues(input, parsedValues);
            }
            static /*int */ GetStringWithQualityLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringWithQualityHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let valueLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (valueLength === 0)
                {
                    return 0;
                }
                /*StringWithQualityHeaderValue*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue().$ctor$1();
                result._value = input.Subsegment(startIndex, valueLength);
                /*var*/ let current = ((startIndex + valueLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*;*/ 59))
                {
                    parsedValue.$v = result;
                    return ((current - startIndex) | 0);
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (!$.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.TryReadQuality(input, result, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32)))
                {
                    return 0;
                }
                parsedValue.$v = result;
                return ((current - startIndex) | 0);
            }
            static /*bool */ TryReadQuality(/*StringSegment*/ input, /*StringWithQualityHeaderValue*/ result, /*ref int*/ index)
            {
                /*var*/ let current = index.$v;
                if ((current === input.Length) || ((input.get_Item(current) !== /*q*/ 113) && (input.get_Item(current) !== /*Q*/ 81)))
                {
                    return false;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*=*/ 61))
                {
                    return false;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (current === input.Length)
                {
                    return false;
                }
                /*var*/ let quality;
                /*var*/ let qualityLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseQualityDouble(input, current, $.$ref(() => quality, ($v) => quality = $v, $.$$.System.Double), $.$ref(() => qualityLength, ($v) => qualityLength = $v, $.$$.System.Int32)))
                {
                    return false;
                }
                result._quality = quality;
                current = ((current + qualityLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                index.$v = current;
                return true;
            }
            //default member initializer
            constructor()
            {
                super();
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.GetStringWithQualityLength));
                }
                {
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue.GetStringWithQualityLength));
                }
            }
            static $h = 1805009;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851970,"g":{"r":0,"d":0,"h":38656510673,"f":50331649},"n":"Value","d":1805009,"h":34361543377,"f":2097153},{"p":$.$typeNullable($.$$.System.Double).$h,"g":{"r":0,"d":0,"h":47246445265,"f":50331649},"n":"Quality","d":1805009,"h":42951477969,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":1805009,"h":51541412561,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1805009,"h":55836379857,"f":16809985},{"r":655361,"n":"GetHashCode","d":1805009,"h":60131347153,"f":16809985},{"r":1805009,"p":[{"n":"input","p":851970}],"n":"Parse","d":1805009,"h":64426314449,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":1805009,"f":2}],"n":"TryParse","d":1805009,"h":68721281745,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,"p":[{"n":"input","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseList","d":1805009,"h":73016249041,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,"p":[{"n":"input","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseStrictList","d":1805009,"h":77311216337,"f":16777249},{"r":262145,"p":[{"n":"input","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,"f":2}],"n":"TryParseList","d":1805009,"h":81606183633,"f":16777249},{"r":262145,"p":[{"n":"input","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,"f":2}],"n":"TryParseStrictList","d":1805009,"h":85901150929,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":1805009,"f":2}],"n":"GetStringWithQualityLength","d":1805009,"h":90196118225,"f":16777250},{"r":262145,"p":[{"n":"input","p":851970},{"n":"result","p":1805009},{"n":"index","p":655361,"f":4}],"n":"TryReadQuality","d":1805009,"h":94491085521,"f":16777250}],"l":[{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,"n":"SingleValueParser","d":1805009,"h":4296772305,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h,"n":"MultipleValueParser","d":1805009,"h":8591739601,"f":4194338},{"t":851970,"n":"_value","d":1805009,"h":12886706897,"f":4194306},{"t":$.$typeNullable($.$$.System.Double).$h,"n":"_quality","d":1805009,"h":17181674193,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1805009,"h":21476641489,"f":16777218},{"p":[{"n":"value","p":851970}],"n":".ctor","o":"$ctor$3","d":1805009,"h":25771608785,"f":16777217},{"p":[{"n":"value","p":851970},{"n":"quality","p":1179649}],"n":".ctor","o":"$ctor$2","d":1805009,"h":30066576081,"f":16777217}],"h":1805009}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `StringWithQualityHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue", ($self) => class MediaTypeHeaderValue extends $.$$.System.Object
        {
            /*string*/ static BoundaryString = null;
            /*string*/ static CharsetString = null;
            /*string*/ static MatchesAllString = null;
            /*string*/ static QualityString = null;
            /*string*/ static WildcardString = null;
            /*char*/ static ForwardSlashCharacter = /*/*/ 47;
            /*char*/ static PeriodCharacter = /*.*/ 46;
            /*char*/ static PlusCharacter = /*+*/ 43;
            /*char[]*/ static PeriodCharacterArray = null;
            /*HttpHeaderParser<MediaTypeHeaderValue>*/ static SingleValueParser = null;
            /*HttpHeaderParser<MediaTypeHeaderValue>*/ static MultipleValueParser = null;
            /*ObjectCollection<NameValueHeaderValue>?*/ _parameters = null;
            /*StringSegment*/ _mediaType;
            /*bool*/ _isReadOnly = false;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*StringSegment*/ mediaType)
            {
                super.$ctor();
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.CheckMediaTypeFormat(mediaType, "mediaType");
                    this._mediaType = mediaType;
                }
                return this;
            }
            $ctor$2(/*StringSegment*/ mediaType, /*double*/ quality)
            {
                this.$ctor$3(mediaType);
                {
                    this.Quality = quality;
                }
                return this;
            }
            /*StringSegment */ get Charset()
            {
                return ($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("charset"/*CharsetString*/))?.Value ?? null) ?? new $.$mep.Microsoft.Extensions.Primitives.StringSegment();
            }
            /*StringSegment */ set Charset(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                /*var*/ let charsetParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("charset"/*CharsetString*/));
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value))
                {
                    if (charsetParameter !== null)
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Remove(charsetParameter, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
                else 
                {
                    if (charsetParameter !== null)
                    {
                        charsetParameter.Value = value;
                    }
                    else 
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("charset"/*CharsetString*/), value), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            /*Encoding? */ get Encoding()
            {
                /*var*/ let charset = this.Charset;
                if (charset.HasValue && !$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(charset))
                {
                    try
                    {
                        return $.$$.System.Text.Encoding.GetEncoding$3(charset.Value);
                    }
                    catch($e)
                    {
                    }
                }
                return null;
            }
            /*Encoding? */ set Encoding(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                if (value === null)
                {
                    this.Charset = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                }
                else 
                {
                    this.Charset = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(value.WebName);
                }
            }
            /*StringSegment */ get Boundary()
            {
                return ($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/))?.Value ?? null) ?? $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            /*StringSegment */ set Boundary(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                /*var*/ let boundaryParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/));
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value))
                {
                    if (boundaryParameter !== null)
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Remove(boundaryParameter, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
                else 
                {
                    if (boundaryParameter !== null)
                    {
                        boundaryParameter.Value = value;
                    }
                    else 
                    {
                        this.Parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("boundary"/*BoundaryString*/), value), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            /*IList<NameValueHeaderValue> */ get Parameters()
            {
                if (this._parameters === null)
                {
                    if (this.IsReadOnly)
                    {
                        this._parameters = $.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).EmptyReadOnlyCollection;
                    }
                    else 
                    {
                        this._parameters = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$3();
                    }
                }
                return this._parameters;
            }
            /*double? */ get Quality()
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.GetQuality(this._parameters);
            }
            /*double? */ set Quality(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.SetQuality(this.Parameters, value);
            }
            /*StringSegment */ get MediaType()
            {
                return this._mediaType;
            }
            /*StringSegment */ set MediaType(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.ThrowIfReadOnly(this.IsReadOnly);
                $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.CheckMediaTypeFormat(value, "value");
                this._mediaType = value;
            }
            /*StringSegment */ get Type()
            {
                return this._mediaType.Subsegment(0, this._mediaType.IndexOf$2(/*/*/ 47));
            }
            /*StringSegment */ get SubType()
            {
                return this._mediaType.Subsegment$1(((this._mediaType.IndexOf$2(/*/*/ 47) + 1) | 0));
            }
            /*StringSegment */ get SubTypeWithoutSuffix()
            {
                /*var*/ let subType = this.SubType;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    return subType;
                }
                else 
                {
                    return subType.Subsegment(0, startOfSuffix);
                }
            }
            /*StringSegment */ get Suffix()
            {
                /*var*/ let subType = this.SubType;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    return $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                }
                else 
                {
                    return subType.Subsegment$1(((startOfSuffix + 1) | 0));
                }
            }
            /*IEnumerable<StringSegment> */ get Facets()
            {
                return this.SubTypeWithoutSuffix.Split($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.PeriodCharacterArray);
            }
            /*bool */ get MatchesAllTypes()
            {
                return this.MediaType.Equals$2("*/*"/*MatchesAllString*/, 4/*StringComparison.Ordinal*/);
            }
            /*bool */ get MatchesAllSubTypes()
            {
                return this.SubType.Equals$2("*"/*WildcardString*/, 4/*StringComparison.Ordinal*/);
            }
            /*bool */ get MatchesAllSubTypesWithoutSuffix()
            {
                return this.SubTypeWithoutSuffix.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*bool */ get IsReadOnly()
            {
                return this._isReadOnly;
            }
            /*bool */ IsSubsetOf(/*MediaTypeHeaderValue*/ otherMediaType)
            {
                if (otherMediaType === null)
                {
                    return false;
                }
                return this.MatchesType$1(otherMediaType) && this.MatchesSubtype$1(otherMediaType) && this.MatchesParameters(otherMediaType);
            }
            /*MediaTypeHeaderValue */ Copy()
            {
                /*var*/ let other = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue().$ctor$1();
                other._mediaType = this._mediaType;
                if (this._parameters !== null)
                {
                    other._parameters = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$5($.$sl.System.Linq.Enumerable.Select$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._parameters, new ($.$$.System.Func$$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor(this,  (/*item*/ item) =>
                    {
                        return item.Copy();
                    }, {"r":1346257,"p":[{"n":"item","p":1346257}],"n":"","d":1215185,"h":0,"f":17825794})), false);
                }
                return other;
            }
            /*MediaTypeHeaderValue */ CopyAsReadOnly()
            {
                if (this.IsReadOnly)
                {
                    return this;
                }
                /*var*/ let other = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue().$ctor$1();
                other._mediaType = this._mediaType;
                if (this._parameters !== null)
                {
                    other._parameters = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor$5($.$sl.System.Linq.Enumerable.Select$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._parameters, new ($.$$.System.Func$$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue))().$ctor(this,  (/*item*/ item) =>
                    {
                        return item.CopyAsReadOnly();
                    }, {"r":1346257,"p":[{"n":"item","p":1346257}],"n":"","d":1215185,"h":0,"f":17825794})), true);
                }
                other._isReadOnly = true;
                return other;
            }
            /*bool */ MatchesMediaType(/*StringSegment*/ otherMediaType)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(otherMediaType))
                {
                    return false;
                }
                /*var*/ let mediaType;
                $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeExpressionLength(otherMediaType, 0, $.$ref(() => mediaType, ($v) => mediaType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                return this.MatchesType(mediaType) && this.MatchesSubtype(mediaType);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$1();
                builder.Append$15(this._mediaType.AsSpan());
                $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.ToString$1(this._parameters, /*;*/ 59, true, builder);
                return $.$$.System.Text.StringBuilder.ToString.call(builder);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.ToString.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return this._mediaType.Equals$4(other._mediaType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections$1($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue, this._parameters, other._parameters);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._mediaType) ^ $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetHashCode$1(this._parameters);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetHashCode.apply(this, arguments); }
            static /*MediaTypeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out MediaTypeHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*IList<MediaTypeHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            static /*IList<MediaTypeHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<MediaTypeHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.MultipleValueParser.TryParseValues$1(inputs, parsedValues);
            }
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<MediaTypeHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            static /*int */ GetMediaTypeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out MediaTypeHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let mediaType;
                /*var*/ let mediaTypeLength = $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeExpressionLength(input, startIndex, $.$ref(() => mediaType, ($v) => mediaType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                if (mediaTypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + mediaTypeLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*MediaTypeHeaderValue?*/ let mediaTypeHeader;
                if ((current < input.Length) && (input.get_Item(current) === /*;*/ 59))
                {
                    mediaTypeHeader = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue().$ctor$1();
                    mediaTypeHeader._mediaType = mediaType;
                    current++;
                    /*var*/ let parameterLength = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetNameValueListLength(input, current, /*;*/ 59, mediaTypeHeader.Parameters);
                    parsedValue.$v = mediaTypeHeader;
                    return ((((current + parameterLength) | 0) - startIndex) | 0);
                }
                mediaTypeHeader = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue().$ctor$1();
                mediaTypeHeader._mediaType = mediaType;
                parsedValue.$v = mediaTypeHeader;
                return ((current - startIndex) | 0);
            }
            static /*int */ GetMediaTypeExpressionLength(/*StringSegment*/ input, /*int*/ startIndex, /*out StringSegment*/ mediaType)
            {
                ;
                mediaType.$v = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null);
                /*var*/ let typeLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (typeLength === 0)
                {
                    return 0;
                }
                /*var*/ let current = ((startIndex + typeLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current >= input.Length) || (input.get_Item(current) !== /*/*/ 47))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let subtypeLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, current);
                if (subtypeLength === 0)
                {
                    return 0;
                }
                /*var*/ let mediaTypeLength = ((((current + subtypeLength) | 0) - startIndex) | 0);
                if (((((typeLength + subtypeLength) | 0) + 1) | 0) === mediaTypeLength)
                {
                    mediaType.$v = input.Subsegment(startIndex, mediaTypeLength);
                }
                else 
                {
                    mediaType.$v = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Concat$7(input.AsSpan().Slice(startIndex, typeLength), $.$$.System.String.op_Implicit("/"), input.AsSpan().Slice(current, subtypeLength)));
                }
                return mediaTypeLength;
            }
            static /*void */ CheckMediaTypeFormat(/*StringSegment*/ mediaType, /*string*/ parameterName)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(mediaType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                /*var*/ let tempMediaType;
                /*var*/ let mediaTypeLength = $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeExpressionLength(mediaType, 0, $.$ref(() => tempMediaType, ($v) => tempMediaType = $v, $.$mep.Microsoft.Extensions.Primitives.StringSegment));
                if ((mediaTypeLength === 0) || (tempMediaType.Length !== mediaType.Length))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "Invalid media type '{0}'.", mediaType));
                }
            }
            /*bool */ MatchesType$1(/*MediaTypeHeaderValue*/ set)
            {
                return set.MatchesAllTypes || set.Type.Equals$4(this.Type, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*bool */ MatchesType(/*StringSegment*/ mediaType)
            {
                /*var*/ let type = mediaType.Subsegment(0, mediaType.IndexOf$2(/*/*/ 47));
                return this.MatchesAllTypes || this.Type.Equals$4(type, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*bool */ MatchesSubtype$1(/*MediaTypeHeaderValue*/ set)
            {
                if (set.MatchesAllSubTypes)
                {
                    return true;
                }
                if (set.Suffix.HasValue)
                {
                    if (this.Suffix.HasValue)
                    {
                        return this.MatchesSubtypeWithoutSuffix$1(set) && this.MatchesSubtypeSuffix$1(set);
                    }
                    else 
                    {
                        return false;
                    }
                }
                else 
                {
                    return this.MatchesEitherSubtypeOrSuffix$1(set);
                }
            }
            /*bool */ MatchesSubtype(/*StringSegment*/ mediaType)
            {
                if (this.MatchesAllSubTypes)
                {
                    return true;
                }
                /*var*/ let subType = mediaType.Subsegment$1(((mediaType.IndexOf$2(/*/*/ 47) + 1) | 0));
                /*StringSegment*/ let suffix;
                /*var*/ let startOfSuffix = subType.LastIndexOf(/*+*/ 43);
                if (startOfSuffix === -1)
                {
                    suffix = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                }
                else 
                {
                    suffix = subType.Subsegment$1(((startOfSuffix + 1) | 0));
                }
                if (this.Suffix.HasValue)
                {
                    if (suffix.HasValue)
                    {
                        return this.MatchesSubtypeWithoutSuffix(subType, startOfSuffix) && this.MatchesSubtypeSuffix(suffix);
                    }
                    else 
                    {
                        return false;
                    }
                }
                else 
                {
                    return this.MatchesEitherSubtypeOrSuffix(subType, suffix);
                }
            }
            /*bool */ MatchesSubtypeWithoutSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                return set.MatchesAllSubTypesWithoutSuffix || set.SubTypeWithoutSuffix.Equals$4(this.SubTypeWithoutSuffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*bool */ MatchesSubtypeWithoutSuffix(/*StringSegment*/ subType, /*int*/ startOfSuffix)
            {
                /*StringSegment*/ let subTypeWithoutSuffix;
                if (startOfSuffix === -1)
                {
                    subTypeWithoutSuffix = subType;
                }
                else 
                {
                    subTypeWithoutSuffix = subType.Subsegment(0, startOfSuffix);
                }
                return this.SubTypeWithoutSuffix.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/) || this.SubTypeWithoutSuffix.Equals$4(subTypeWithoutSuffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*bool */ MatchesEitherSubtypeOrSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                return set.SubType.Equals$4(this.SubType, 5/*StringComparison.OrdinalIgnoreCase*/) || set.SubType.Equals$4(this.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*bool */ MatchesEitherSubtypeOrSuffix(/*StringSegment*/ subType, /*StringSegment*/ suffix)
            {
                return subType.Equals$4(this.SubType, 5/*StringComparison.OrdinalIgnoreCase*/) || this.SubType.Equals$4(suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*bool */ MatchesParameters(/*MediaTypeHeaderValue*/ set)
            {
                if (set._parameters !== null && set._parameters.Count !== 0)
                {
                    var $en3 = set._parameters.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var parameter = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (parameter.Name.Equals$2("*"/*WildcardString*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                continue;
                            }
                            if (parameter.Name.Equals$2("q"/*QualityString*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                break;
                            }
                            /*var*/ let localParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(this._parameters, parameter.Name);
                            if (localParameter === null)
                            {
                                return false;
                            }
                            if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(parameter.Value, localParameter.Value, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            /*bool */ MatchesSubtypeSuffix$1(/*MediaTypeHeaderValue*/ set)
            {
                return set.Suffix.Equals$4(this.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*bool */ MatchesSubtypeSuffix(/*StringSegment*/ suffix)
            {
                return this.Suffix.Equals$4(suffix, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //default member initializer
            constructor()
            {
                super();
                this._mediaType = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.BoundaryString = "boundary";
                }
                {
                    this.CharsetString = "charset";
                }
                {
                    this.MatchesAllString = "*/*";
                }
                {
                    this.QualityString = "q";
                }
                {
                    this.WildcardString = "*";
                }
                {
                    this.PeriodCharacterArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.Char.$type, [ /*.*/ 46 ], null, null);
                }
                {
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeLength));
                }
                {
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.GetMediaTypeLength));
                }
            }
            static $h = 1215185;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851970,"g":{"r":0,"d":0,"h":81605593809,"f":50331649},"s":{"r":0,"d":0,"h":85900561105,"f":83886081},"n":"Charset","d":1215185,"h":77310626513,"f":2097153},{"p":121700353,"g":{"r":0,"d":0,"h":94490495697,"f":50331649},"s":{"r":0,"d":0,"h":98785462993,"f":83886081},"n":"Encoding","d":1215185,"h":90195528401,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":107375397585,"f":50331649},"s":{"r":0,"d":0,"h":111670364881,"f":83886081},"n":"Boundary","d":1215185,"h":103080430289,"f":2097153},{"p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"g":{"r":0,"d":0,"h":120260299473,"f":50331649},"n":"Parameters","d":1215185,"h":115965332177,"f":2097153},{"p":$.$typeNullable($.$$.System.Double).$h,"g":{"r":0,"d":0,"h":128850234065,"f":50331649},"s":{"r":0,"d":0,"h":133145201361,"f":83886081},"n":"Quality","d":1215185,"h":124555266769,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":141735135953,"f":50331649},"s":{"r":0,"d":0,"h":146030103249,"f":83886081},"n":"MediaType","d":1215185,"h":137440168657,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":154620037841,"f":50331649},"n":"Type","d":1215185,"h":150325070545,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":163209972433,"f":50331649},"n":"SubType","d":1215185,"h":158915005137,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":171799907025,"f":50331649},"n":"SubTypeWithoutSuffix","d":1215185,"h":167504939729,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":180389841617,"f":50331649},"n":"Suffix","d":1215185,"h":176094874321,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"g":{"r":0,"d":0,"h":188979776209,"f":50331649},"n":"Facets","d":1215185,"h":184684808913,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":197569710801,"f":50331649},"n":"MatchesAllTypes","d":1215185,"h":193274743505,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":206159645393,"f":50331649},"n":"MatchesAllSubTypes","d":1215185,"h":201864678097,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":214749579985,"f":50331649},"n":"MatchesAllSubTypesWithoutSuffix","d":1215185,"h":210454612689,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":223339514577,"f":50331649},"n":"IsReadOnly","d":1215185,"h":219044547281,"f":2097153}],"m":[{"r":262145,"p":[{"n":"otherMediaType","p":1215185}],"n":"IsSubsetOf","d":1215185,"h":227634481873,"f":16777217},{"r":1215185,"n":"Copy","d":1215185,"h":231929449169,"f":16777217},{"r":1215185,"n":"CopyAsReadOnly","d":1215185,"h":236224416465,"f":16777217},{"r":262145,"p":[{"n":"otherMediaType","p":851970}],"n":"MatchesMediaType","d":1215185,"h":240519383761,"f":16777217},{"r":1310721,"n":"ToString","d":1215185,"h":244814351057,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1215185,"h":249109318353,"f":16809985},{"r":655361,"n":"GetHashCode","d":1215185,"h":253404285649,"f":16809985},{"r":1215185,"p":[{"n":"input","p":851970}],"n":"Parse","d":1215185,"h":257699252945,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":1215185,"f":2}],"n":"TryParse","d":1215185,"h":261994220241,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseList","d":1215185,"h":266289187537,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseStrictList","d":1215185,"h":270584154833,"f":16777249},{"r":262145,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,"f":2}],"n":"TryParseList","d":1215185,"h":274879122129,"f":16777249},{"r":262145,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,"f":2}],"n":"TryParseStrictList","d":1215185,"h":279174089425,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":1215185,"f":2}],"n":"GetMediaTypeLength","d":1215185,"h":283469056721,"f":16777250},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"mediaType","p":851970,"f":2}],"n":"GetMediaTypeExpressionLength","d":1215185,"h":287764024017,"f":16777250},{"r":65537,"p":[{"n":"mediaType","p":851970},{"n":"parameterName","p":1310721}],"n":"CheckMediaTypeFormat","d":1215185,"h":292058991313,"f":16777250},{"r":262145,"p":[{"n":"set","p":1215185}],"n":"MatchesType","o":"@$1","d":1215185,"h":296353958609,"f":16777218},{"r":262145,"p":[{"n":"mediaType","p":851970}],"n":"MatchesType","d":1215185,"h":300648925905,"f":16777218},{"r":262145,"p":[{"n":"set","p":1215185}],"n":"MatchesSubtype","o":"@$1","d":1215185,"h":304943893201,"f":16777218},{"r":262145,"p":[{"n":"mediaType","p":851970}],"n":"MatchesSubtype","d":1215185,"h":309238860497,"f":16777218},{"r":262145,"p":[{"n":"set","p":1215185}],"n":"MatchesSubtypeWithoutSuffix","o":"@$1","d":1215185,"h":313533827793,"f":16777218},{"r":262145,"p":[{"n":"subType","p":851970},{"n":"startOfSuffix","p":655361}],"n":"MatchesSubtypeWithoutSuffix","d":1215185,"h":317828795089,"f":16777218},{"r":262145,"p":[{"n":"set","p":1215185}],"n":"MatchesEitherSubtypeOrSuffix","o":"@$1","d":1215185,"h":322123762385,"f":16777218},{"r":262145,"p":[{"n":"subType","p":851970},{"n":"suffix","p":851970}],"n":"MatchesEitherSubtypeOrSuffix","d":1215185,"h":326418729681,"f":16777218},{"r":262145,"p":[{"n":"set","p":1215185}],"n":"MatchesParameters","d":1215185,"h":330713696977,"f":16777218},{"r":262145,"p":[{"n":"set","p":1215185}],"n":"MatchesSubtypeSuffix","o":"@$1","d":1215185,"h":335008664273,"f":16777218},{"r":262145,"p":[{"n":"suffix","p":851970}],"n":"MatchesSubtypeSuffix","d":1215185,"h":339303631569,"f":16777218}],"l":[{"t":1310721,"n":"BoundaryString","d":1215185,"h":4296182481,"f":4194338},{"t":1310721,"n":"CharsetString","d":1215185,"h":8591149777,"f":4194338},{"t":1310721,"n":"MatchesAllString","d":1215185,"h":12886117073,"f":4194338},{"t":1310721,"n":"QualityString","d":1215185,"h":17181084369,"f":4194338},{"t":1310721,"n":"WildcardString","d":1215185,"h":21476051665,"f":4194338},{"t":458753,"n":"ForwardSlashCharacter","d":1215185,"h":25771018961,"f":4194338},{"t":458753,"n":"PeriodCharacter","d":1215185,"h":30065986257,"f":4194338},{"t":458753,"n":"PlusCharacter","d":1215185,"h":34360953553,"f":4194338},{"t":$.$typeArray($.$$.System.Char).$h,"n":"PeriodCharacterArray","d":1215185,"h":38655920849,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,"n":"SingleValueParser","d":1215185,"h":42950888145,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h,"n":"MultipleValueParser","d":1215185,"h":47245855441,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h,"n":"_parameters","d":1215185,"h":51540822737,"f":4194306},{"t":851970,"n":"_mediaType","d":1215185,"h":55835790033,"f":4194306},{"t":262145,"n":"_isReadOnly","d":1215185,"h":60130757329,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1215185,"h":64425724625,"f":16777218},{"p":[{"n":"mediaType","p":851970}],"n":".ctor","o":"$ctor$3","d":1215185,"h":68720691921,"f":16777217},{"p":[{"n":"mediaType","p":851970},{"n":"quality","p":1179649}],"n":".ctor","o":"$ctor$2","d":1215185,"h":73015659217,"f":16777217}],"h":1215185}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MediaTypeHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue", ($self) => class SetCookieHeaderValue extends $.$$.System.Object
        {
            /*string*/ static ExpiresToken = null;
            /*string*/ static MaxAgeToken = null;
            /*string*/ static DomainToken = null;
            /*string*/ static PathToken = null;
            /*string*/ static SecureToken = null;
            /*string*/ static SameSiteToken = null;
            /*string*/ static SameSiteNoneToken = null;
            /*string*/ static SameSiteLaxToken = null;
            /*string*/ static SameSiteStrictToken = null;
            /*string*/ static HttpOnlyToken = null;
            /*string*/ static SeparatorToken = null;
            /*string*/ static EqualsToken = null;
            /*int*/ static ExpiresDateLength = 29;
            /*string*/ static ExpiresDateFormat = null;
            /*HttpHeaderParser<SetCookieHeaderValue>*/ static SingleValueParser = null;
            /*HttpHeaderParser<SetCookieHeaderValue>*/ static MultipleValueParser = null;
            /*StringSegment*/ _name;
            /*StringSegment*/ _value;
            /*List<StringSegment>?*/ _extensions = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*StringSegment*/ name)
            {
                this.$ctor$2(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty);
                {
                }
                return this;
            }
            $ctor$2(/*StringSegment*/ name, /*StringSegment*/ value)
            {
                super.$ctor();
                {
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(name, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("name");
                    }
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Equality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("value");
                    }
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            /*StringSegment */ get Name()
            {
                return this._name;
            }
            /*StringSegment */ set Name(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.CheckNameFormat(value, "value");
                this._name = value;
            }
            /*StringSegment */ get Value()
            {
                return this._value;
            }
            /*StringSegment */ set Value(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue.CheckValueFormat(value, "value");
                this._value = value;
            }
            /*DateTimeOffset?*/ Expires = null;
            /*TimeSpan?*/ MaxAge = null;
            /*StringSegment*/ Domain;
            /*StringSegment*/ Path;
            /*bool*/ Secure = false;
            /*SameSiteMode*/ SameSite = 0;
            /*bool*/ HttpOnly = false;
            /*IList<StringSegment> */ get Extensions()
            {
                return this._extensions ??= new ($.$$.System.Collections.Generic.List$$($.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor$1();
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let length = ((((this._name.Length + "="/*EqualsToken*/.length) | 0) + this._value.Length) | 0);
                /*string?*/ let maxAge = null;
                /*string?*/ let sameSite = null;
                if ($.$$.System.Nullable$$($.$$.System.DateTimeOffset).HasValue$get.call(this.Expires))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "expires"/*ExpiresToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + 29/*ExpiresDateLength*/) | 0);
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this.MaxAge))
                {
                    maxAge = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatInt64($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this.MaxAge).TotalSeconds, $.$$.System.Int64));
                    length += (((((("; "/*SeparatorToken*/.length + "max-age"/*MaxAgeToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + maxAge.length) | 0);
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Domain, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "domain"/*DomainToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + this.Domain.Length) | 0);
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Path, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    length += (((((("; "/*SeparatorToken*/.length + "path"/*PathToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + this.Path.Length) | 0);
                }
                if (this.Secure)
                {
                    length += (("; "/*SeparatorToken*/.length + "secure"/*SecureToken*/.length) | 0);
                }
                if (this.SameSite === 0/*SameSiteMode.None*/)
                {
                    sameSite = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteNoneToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                else if (this.SameSite === 1/*SameSiteMode.Lax*/)
                {
                    sameSite = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteLaxToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                else if (this.SameSite === 2/*SameSiteMode.Strict*/)
                {
                    sameSite = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteStrictToken;
                    length += (((((("; "/*SeparatorToken*/.length + "samesite"/*SameSiteToken*/.length) | 0) + "="/*EqualsToken*/.length) | 0) + sameSite.length) | 0);
                }
                if (this.HttpOnly)
                {
                    length += (("; "/*SeparatorToken*/.length + "httponly"/*HttpOnlyToken*/.length) | 0);
                }
                if ($.$$.System.Int32.op_GreaterThan$1((this._extensions?.Count ?? null), 0))
                {
                    var $en3 = this._extensions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var extension = $en3.Current;
                        {
                            length += (("; "/*SeparatorToken*/.length + extension.Length) | 0);
                        }
                    }
                }
                return $.$$.System.String.Create$10($.$$.System.ValueTuple$$$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$$.System.String, $.$$.System.String), length, new ($.$$.System.ValueTuple$$$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$$.System.String, $.$$.System.String))().$ctor$3(this, maxAge, sameSite), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.ValueTuple$$$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$$.System.String, $.$$.System.String)))().$ctor(this,  (/**/ span, /*tuple*/ tuple) =>
                {
                    /*var*/ let  [ headerValue, maxAgeValue, sameSite ] = $.$destructure(tuple);
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$1(headerValue._name));
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$$.System.String.op_Implicit("="/*EqualsToken*/));
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$1(headerValue._value));
                    let expiresValue;
                    if ($.$is(headerValue.Expires, $.$$.System.DateTimeOffset, { set $v(v){ expiresValue = v; } }))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$$.System.String.op_Implicit("; "/*SeparatorToken*/));
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$$.System.String.op_Implicit("expires"/*ExpiresToken*/));
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$$.System.String.op_Implicit("="/*EqualsToken*/));
                        /*var*/ let charsWritten;
                        /*var*/ let formatted = expiresValue.TryFormat$1(span, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit("r"/*ExpiresDateFormat*/), $.$$.System.Globalization.CultureInfo.InvariantCulture);
                        span = span.Slice$1(charsWritten);
                        $.$$.System.Diagnostics.Debug.Assert$2(formatted, "formatted");
                    }
                    if ($.$$.System.String.op_Inequality(maxAgeValue, null))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(maxAgeValue));
                    }
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(headerValue.Domain, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("domain"/*DomainToken*/), headerValue.Domain);
                    }
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(headerValue.Path, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("path"/*PathToken*/), headerValue.Path);
                    }
                    if (headerValue.Secure)
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("secure"/*SecureToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                    }
                    if ($.$$.System.String.op_Inequality(sameSite, null))
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(sameSite));
                    }
                    if (headerValue.HttpOnly)
                    {
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                    }
                    if ($.$$.System.Int32.op_GreaterThan$1((this._extensions?.Count ?? null), 0))
                    {
                        var $en4 = this._extensions.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var extension = $en4.Current;
                            {
                                $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Char), () => span, ($v) => span = $v, null), extension, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                            }
                        }
                    }
                }, {"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"tuple","p":$.$$.System.ValueTuple$$$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$$.System.String, $.$$.System.String).$h}],"n":"","d":1739473,"h":0,"f":17825794}));
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ToString.apply(this, arguments); }
            static /*void */ AppendSegment$1(/*ref Span<char>*/ span, /*StringSegment*/ name, /*StringSegment*/ value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append(span, $.$$.System.String.op_Implicit("; "/*SeparatorToken*/));
                $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append(span, name.AsSpan());
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append(span, $.$$.System.String.op_Implicit("="/*EqualsToken*/));
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Append(span, value.AsSpan());
                }
            }
            static /*void */ Append(/*ref Span<char>*/ span, /*ReadOnlySpan<char>*/ other)
            {
                other.CopyTo(span.$v);
                span.$v = span.$v.Slice$1(other.Length);
            }
            /*void */ AppendToStringBuilder(/*StringBuilder*/ builder)
            {
                builder.Append$15(this._name.AsSpan());
                builder.Append$3(/*=*/ 61);
                builder.Append$15(this._value.AsSpan());
                if ($.$$.System.Nullable$$($.$$.System.DateTimeOffset).HasValue$get.call(this.Expires))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("expires"/*ExpiresToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatDate$1($.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetValueOrDefault.call(this.Expires))));
                }
                if ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this.MaxAge))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatInt64($.$cast($.$$.System.Nullable$$($.$$.System.TimeSpan).GetValueOrDefault.call(this.MaxAge).TotalSeconds, $.$$.System.Int64))));
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Domain, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("domain"/*DomainToken*/), this.Domain);
                }
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Path, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("path"/*PathToken*/), this.Path);
                }
                if (this.Secure)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("secure"/*SecureToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                }
                if (this.SameSite === 0/*SameSiteMode.None*/)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteNoneToken));
                }
                else if (this.SameSite === 1/*SameSiteMode.Lax*/)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteLaxToken));
                }
                else if (this.SameSite === 2/*SameSiteMode.Strict*/)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteStrictToken));
                }
                if (this.HttpOnly)
                {
                    $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                }
                if ($.$$.System.Int32.op_GreaterThan$1((this._extensions?.Count ?? null), 0))
                {
                    var $en3 = this._extensions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var extension = $en3.Current;
                        {
                            $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.AppendSegment(builder, extension, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null));
                        }
                    }
                }
            }
            static /*void */ AppendSegment(/*StringBuilder*/ builder, /*StringSegment*/ name, /*StringSegment*/ value)
            {
                builder.Append$19("; ");
                builder.Append$15(name.AsSpan());
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(value, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)))
                {
                    builder.Append$3(/*=*/ 61);
                    builder.Append$15(value.AsSpan());
                }
            }
            static /*SetCookieHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SingleValueParser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out SetCookieHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SingleValueParser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*IList<SetCookieHeaderValue> */ ParseList(/*IList<string>?*/ inputs)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.MultipleValueParser.ParseValues$1(inputs);
            }
            static /*IList<SetCookieHeaderValue> */ ParseStrictList(/*IList<string>?*/ inputs)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.MultipleValueParser.ParseStrictValues(inputs);
            }
            static /*bool */ TryParseList(/*IList<string>?*/ inputs, /*out IList<SetCookieHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.MultipleValueParser.TryParseValues$1(inputs, parsedValues);
            }
            static /*bool */ TryParseStrictList(/*IList<string>?*/ inputs, /*out IList<SetCookieHeaderValue>?*/ parsedValues)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.MultipleValueParser.TryParseStrictValues(inputs, parsedValues);
            }
            static /*int */ GetSetCookieLength(/*StringSegment*/ input, /*int*/ startIndex, /*out SetCookieHeaderValue?*/ parsedValue)
            {
                ;
                /*var*/ let offset = startIndex;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (offset >= input.Length))
                {
                    return 0;
                }
                /*var*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue().$ctor$1();
                /*var*/ let itemLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, offset);
                if (itemLength === 0)
                {
                    return 0;
                }
                result._name = input.Subsegment(offset, itemLength);
                offset += itemLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                {
                    return 0;
                }
                result._value = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetCookieValue(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32));
                while(offset < input.Length)
                {
                    if (input.get_Item(offset) === /*,*/ 44)
                    {
                        break;
                    }
                    if (input.get_Item(offset) !== /*;*/ 59)
                    {
                        return 0;
                    }
                    offset++;
                    offset += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, offset);
                    itemLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, offset);
                    if (itemLength === 0)
                    {
                        break;
                    }
                    /*var*/ let token = input.Subsegment(offset, itemLength);
                    offset += itemLength;
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("expires"/*ExpiresToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            return 0;
                        }
                        /*var*/ let dateString = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), false);
                        /*DateTimeOffset*/ let expirationDate;
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TryStringToDate(dateString, $.$ref(() => expirationDate, ($v) => expirationDate = $v, $.$$.System.DateTimeOffset)))
                        {
                            return 0;
                        }
                        result.Expires = expirationDate;
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("max-age"/*MaxAgeToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            return 0;
                        }
                        /*var*/ let isNegative = false;
                        if (input.get_Item(offset) === /*-*/ 45)
                        {
                            isNegative = true;
                            offset++;
                        }
                        itemLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength(input, offset, false);
                        if (itemLength === 0)
                        {
                            return 0;
                        }
                        /*var*/ let numberString = input.Subsegment(offset, itemLength);
                        /*long*/ let maxAge;
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(numberString, $.$ref(() => maxAge, ($v) => maxAge = $v, $.$$.System.Int64)))
                        {
                            return 0;
                        }
                        if (isNegative)
                        {
                            maxAge = -maxAge;
                        }
                        result.MaxAge = $.$$.System.TimeSpan.FromSeconds$2(maxAge);
                        offset += itemLength;
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("domain"/*DomainToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            return 0;
                        }
                        result.Domain = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), true);
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("path"/*PathToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            return 0;
                        }
                        result.Path = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), true);
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("secure"/*SecureToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        result.Secure = true;
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("samesite"/*SameSiteToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (!$.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadEqualsSign(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                        {
                            result.SameSite = -1/*SameSiteMode.Unspecified*/;
                        }
                        else 
                        {
                            /*var*/ let enforcementMode = $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), true);
                            if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(enforcementMode, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteStrictToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 2/*SameSiteMode.Strict*/;
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(enforcementMode, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteLaxToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 1/*SameSiteMode.Lax*/;
                            }
                            else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(enforcementMode, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.SameSiteNoneToken), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                result.SameSite = 0/*SameSiteMode.None*/;
                            }
                            else 
                            {
                                result.SameSite = -1/*SameSiteMode.Unspecified*/;
                            }
                        }
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(token, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("httponly"/*HttpOnlyToken*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        result.HttpOnly = true;
                    }
                    else 
                    {
                        /*var*/ let tokenStart = ((offset - itemLength) | 0);
                        $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.ReadToSemicolonOrEnd(input, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32), true);
                        result.Extensions.System$Collections$Generic$ICollection$$$Add(input.Subsegment(tokenStart, ((offset - tokenStart) | 0)), [$.$mep.Microsoft.Extensions.Primitives.StringSegment]);
                    }
                }
                parsedValue.$v = result;
                return ((offset - startIndex) | 0);
            }
            static /*bool */ ReadEqualsSign(/*StringSegment*/ input, /*ref int*/ offset)
            {
                if (offset.$v >= input.Length || input.get_Item(offset.$v) !== /*=*/ 61)
                {
                    return false;
                }
                offset.$v++;
                return true;
            }
            static /*StringSegment */ ReadToSemicolonOrEnd(/*StringSegment*/ input, /*ref int*/ offset, /*bool*/ includeComma)
            {
                /*var*/ let end = input.IndexOf$1(/*;*/ 59, offset.$v);
                if (end < 0)
                {
                    if (includeComma)
                    {
                        end = input.IndexOf$1(/*,*/ 44, offset.$v);
                    }
                }
                else if (includeComma)
                {
                    /*var*/ let commaPosition = input.IndexOf$1(/*,*/ 44, offset.$v);
                    if (commaPosition >= 0 && commaPosition < end)
                    {
                        end = commaPosition;
                    }
                }
                if (end < 0)
                {
                    end = input.Length;
                }
                /*var*/ let itemLength = ((end - offset.$v) | 0);
                /*var*/ let result = input.Subsegment(offset.$v, itemLength);
                offset.$v += itemLength;
                return result;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._name, other._name, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._value, other._value, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.System.Nullable$$($.$$.System.DateTimeOffset).Equals$1.call(this.Expires, other.Expires) && $.$$.System.Nullable$$($.$$.System.TimeSpan).Equals$1.call(this.MaxAge, other.MaxAge) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Domain, other.Domain, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this.Path, other.Path, 5/*StringComparison.OrdinalIgnoreCase*/) && this.Secure === other.Secure && this.SameSite === other.SameSite && this.HttpOnly === other.HttpOnly && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections($.$mep.Microsoft.Extensions.Primitives.StringSegment, this._extensions, other._extensions, $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*var*/ let hash = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._name) ^ $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._value) ^ ($.$$.System.Nullable$$($.$$.System.DateTimeOffset).HasValue$get.call(this.Expires) ? $.$$.System.Nullable$$($.$$.System.DateTimeOffset).GetHashCode.call(this.Expires) : 0) ^ ($.$$.System.Nullable$$($.$$.System.TimeSpan).HasValue$get.call(this.MaxAge) ? $.$$.System.Nullable$$($.$$.System.TimeSpan).GetHashCode.call(this.MaxAge) : 0) ^ ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Domain, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)) ? $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Domain) : 0) ^ ($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Inequality(this.Path, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(null)) ? $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this.Path) : 0) ^ $.$$.System.Boolean.GetHashCode.call(this.Secure) ^ this.SameSite ^ $.$$.System.Boolean.GetHashCode.call(this.HttpOnly);
                if ($.$$.System.Int32.op_GreaterThan$1((this._extensions?.Count ?? null), 0))
                {
                    var $en3 = this._extensions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var extension = $en3.Current;
                        {
                            hash ^= $.$mep.Microsoft.Extensions.Primitives.StringSegment.GetHashCode.call(extension);
                        }
                    }
                }
                return hash;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.GetHashCode.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._name = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this._value = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this.Expires = null;
                this.MaxAge = null;
                this.Domain = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this.Path = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
                this.Secure = false;
                this.SameSite = -1;
                this.HttpOnly = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ExpiresToken = "expires";
                }
                {
                    this.MaxAgeToken = "max-age";
                }
                {
                    this.DomainToken = "domain";
                }
                {
                    this.PathToken = "path";
                }
                {
                    this.SecureToken = "secure";
                }
                {
                    this.SameSiteToken = "samesite";
                }
                {
                    this.SameSiteNoneToken = $.$$.System.String.ToLowerInvariant.call("None");
                }
                {
                    this.SameSiteLaxToken = $.$$.System.String.ToLowerInvariant.call("Lax");
                }
                {
                    this.SameSiteStrictToken = $.$$.System.String.ToLowerInvariant.call("Strict");
                }
                {
                    this.HttpOnlyToken = "httponly";
                }
                {
                    this.SeparatorToken = "; ";
                }
                {
                    this.EqualsToken = "=";
                }
                {
                    this.ExpiresDateFormat = "r";
                }
                {
                    this.SingleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.GetSetCookieLength));
                }
                {
                    this.MultipleValueParser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue))().$ctor$3(true, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue.GetSetCookieLength));
                }
            }
            static $h = 1739473;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851970,"g":{"r":0,"d":0,"h":103080954577,"f":50331649},"s":{"r":0,"d":0,"h":107375921873,"f":83886081},"n":"Name","d":1739473,"h":98785987281,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":115965856465,"f":50331649},"s":{"r":0,"d":0,"h":120260823761,"f":83886081},"n":"Value","d":1739473,"h":111670889169,"f":2097153},{"p":$.$typeNullable($.$$.System.DateTimeOffset).$h,"g":{"r":0,"d":0,"h":133145725649,"f":50331649},"s":{"r":0,"d":0,"h":137440692945,"f":83886081},"n":"Expires","d":1739473,"h":128850758353,"f":2097153},{"p":$.$typeNullable($.$$.System.TimeSpan).$h,"g":{"r":0,"d":0,"h":150325594833,"f":50331649},"s":{"r":0,"d":0,"h":154620562129,"f":83886081},"n":"MaxAge","d":1739473,"h":146030627537,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":167505464017,"f":50331649},"s":{"r":0,"d":0,"h":171800431313,"f":83886081},"n":"Domain","d":1739473,"h":163210496721,"f":2097153},{"p":851970,"g":{"r":0,"d":0,"h":184685333201,"f":50331649},"s":{"r":0,"d":0,"h":188980300497,"f":83886081},"n":"Path","d":1739473,"h":180390365905,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":201865202385,"f":50331649},"s":{"r":0,"d":0,"h":206160169681,"f":83886081},"n":"Secure","d":1739473,"h":197570235089,"f":2097153},{"p":1673937,"g":{"r":0,"d":0,"h":219045071569,"f":50331649},"s":{"r":0,"d":0,"h":223340038865,"f":83886081},"n":"SameSite","d":1739473,"h":214750104273,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":236224940753,"f":50331649},"s":{"r":0,"d":0,"h":240519908049,"f":83886081},"n":"HttpOnly","d":1739473,"h":231929973457,"f":2097153},{"p":$.$$.System.Collections.Generic.IList$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"g":{"r":0,"d":0,"h":249109842641,"f":50331649},"n":"Extensions","d":1739473,"h":244814875345,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":1739473,"h":253404809937,"f":16809985},{"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h,"f":4},{"n":"name","p":851970},{"n":"value","p":851970}],"n":"AppendSegment","o":"@$1","d":1739473,"h":257699777233,"f":16777250},{"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h,"f":4},{"n":"other","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Append","d":1739473,"h":261994744529,"f":16777250},{"r":65537,"p":[{"n":"builder","p":122814465}],"n":"AppendToStringBuilder","d":1739473,"h":266289711825,"f":16777217},{"r":65537,"p":[{"n":"builder","p":122814465},{"n":"name","p":851970},{"n":"value","p":851970}],"n":"AppendSegment","d":1739473,"h":270584679121,"f":16777250},{"r":1739473,"p":[{"n":"input","p":851970}],"n":"Parse","d":1739473,"h":274879646417,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":1739473,"f":2}],"n":"TryParse","d":1739473,"h":279174613713,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseList","d":1739473,"h":283469581009,"f":16777249},{"r":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h}],"n":"ParseStrictList","d":1739473,"h":287764548305,"f":16777249},{"r":262145,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,"f":2}],"n":"TryParseList","d":1739473,"h":292059515601,"f":16777249},{"r":262145,"p":[{"n":"inputs","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"parsedValues","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,"f":2}],"n":"TryParseStrictList","d":1739473,"h":296354482897,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":1739473,"f":2}],"n":"GetSetCookieLength","d":1739473,"h":300649450193,"f":16777250},{"r":262145,"p":[{"n":"input","p":851970},{"n":"offset","p":655361,"f":4}],"n":"ReadEqualsSign","d":1739473,"h":304944417489,"f":16777250},{"r":851970,"p":[{"n":"input","p":851970},{"n":"offset","p":655361,"f":4},{"n":"includeComma","p":262145,"f":65,"v":true}],"n":"ReadToSemicolonOrEnd","d":1739473,"h":309239384785,"f":16777250},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1739473,"h":313534352081,"f":16809985},{"r":655361,"n":"GetHashCode","d":1739473,"h":317829319377,"f":16809985}],"l":[{"t":1310721,"n":"ExpiresToken","d":1739473,"h":4296706769,"f":4194338},{"t":1310721,"n":"MaxAgeToken","d":1739473,"h":8591674065,"f":4194338},{"t":1310721,"n":"DomainToken","d":1739473,"h":12886641361,"f":4194338},{"t":1310721,"n":"PathToken","d":1739473,"h":17181608657,"f":4194338},{"t":1310721,"n":"SecureToken","d":1739473,"h":21476575953,"f":4194338},{"t":1310721,"n":"SameSiteToken","d":1739473,"h":25771543249,"f":4194338},{"t":1310721,"n":"SameSiteNoneToken","d":1739473,"h":30066510545,"f":4194338},{"t":1310721,"n":"SameSiteLaxToken","d":1739473,"h":34361477841,"f":4194338},{"t":1310721,"n":"SameSiteStrictToken","d":1739473,"h":38656445137,"f":4194338},{"t":1310721,"n":"HttpOnlyToken","d":1739473,"h":42951412433,"f":4194338},{"t":1310721,"n":"SeparatorToken","d":1739473,"h":47246379729,"f":4194338},{"t":1310721,"n":"EqualsToken","d":1739473,"h":51541347025,"f":4194338},{"t":655361,"n":"ExpiresDateLength","d":1739473,"h":55836314321,"f":4194338},{"t":1310721,"n":"ExpiresDateFormat","d":1739473,"h":60131281617,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,"n":"SingleValueParser","d":1739473,"h":64426248913,"f":4194338},{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.SetCookieHeaderValue).$h,"n":"MultipleValueParser","d":1739473,"h":68721216209,"f":4194338},{"t":851970,"n":"_name","d":1739473,"h":73016183505,"f":4194306},{"t":851970,"n":"_value","d":1739473,"h":77311150801,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"n":"_extensions","d":1739473,"h":81606118097,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1739473,"h":85901085393,"f":16777218},{"p":[{"n":"name","p":851970}],"n":".ctor","o":"$ctor$3","d":1739473,"h":90196052689,"f":16777217},{"p":[{"n":"name","p":851970},{"n":"value","p":851970}],"n":".ctor","o":"$ctor$2","d":1739473,"h":94491019985,"f":16777217}],"h":1739473}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `SetCookieHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities", ($self) => class HeaderUtilities
        {
            /*int*/ static _qualityValueMaxCharCount = 10;
            /*string*/ static QualityName = null;
            /*string*/ static BytesUnit = null;
            static /*void */ SetQuality(/*IList<NameValueHeaderValue>*/ parameters, /*double?*/ value)
            {
                /*var*/ let qualityParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("q"/*QualityName*/));
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(value))
                {
                    if ((value < 0) || (value > 1))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                    }
                    /*var*/ let qualityString = $.$$.System.Double.ToString$2.call(($.$cast(value, $.$$.System.Double)), "0.0##", $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                    if (qualityParameter !== null)
                    {
                        qualityParameter.Value = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(qualityString);
                    }
                    else 
                    {
                        parameters.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue().$ctor$2($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("q"/*QualityName*/), $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(qualityString)), [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
                else 
                {
                    if (qualityParameter !== null)
                    {
                        parameters.System$Collections$Generic$ICollection$$$Remove(qualityParameter, [$.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue]);
                    }
                }
            }
            static /*double? */ GetQuality(/*IList<NameValueHeaderValue>?*/ parameters)
            {
                /*var*/ let qualityParameter = $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.Find(parameters, $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("q"/*QualityName*/));
                if (qualityParameter !== null)
                {
                    /*var*/ let qualityValue;
                    if ($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseQualityDouble(qualityParameter.Value, 0, $.$ref(() => qualityValue, ($v) => qualityValue = $v, $.$$.System.Double), $.$discardRef()))
                    {
                        return qualityValue;
                    }
                }
                return null;
            }
            static /*void */ CheckValidToken(/*StringSegment*/ value, /*string*/ parameterName)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("An empty string is not allowed.", parameterName);
                }
                if ($.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(value, 0) !== value.Length)
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, "Invalid token '{0}'.", value));
                }
            }
            static /*bool */ AreEqualCollections$1(T, /*ICollection<T>?*/ x, /*ICollection<T>?*/ y)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections(T, x, y, null);
            }
            static /*bool */ AreEqualCollections(T, /*ICollection<T>?*/ x, /*ICollection<T>?*/ y, /*IEqualityComparer<T>?*/ comparer)
            {
                if (x === null)
                {
                    return (y === null) || (y.System$Collections$Generic$ICollection$$$Count === 0);
                }
                if (y === null)
                {
                    return (x.System$Collections$Generic$ICollection$$$Count === 0);
                }
                if (x.System$Collections$Generic$ICollection$$$Count !== y.System$Collections$Generic$ICollection$$$Count)
                {
                    return false;
                }
                if (x.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    return true;
                }
                /*var*/ let alreadyFound = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Boolean), null, [x.System$Collections$Generic$ICollection$$$Count], null);
                /*var*/ let i = 0;
                var $en2 = x.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var xItem = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$$.System.Diagnostics.Contracts.Contract.Assert$1($.$box(xItem, T) !== null);
                        i = 0;
                        /*var*/ let found = false;
                        var $en4 = y.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var yItem = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (!$.$$.System.Array.$ReadT1.call(alreadyFound, i))
                                {
                                    if (((comparer === null) && $.$$.System.Object.Equals$1.call(xItem, $.$box(yItem, T))) || ((comparer !== null) && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(xItem, yItem, [T])))
                                    {
                                        $.$$.System.Array.$WriteT1.call(alreadyFound, true, i);
                                        found = true;
                                        break;
                                    }
                                }
                                i++;
                            }
                        }
                        if (!found)
                        {
                            return false;
                        }
                    }
                }
                $.$$.System.Diagnostics.Contracts.Contract.Assert($.$$.System.Diagnostics.Contracts.Contract.ForAll$1($.$$.System.Boolean, alreadyFound, new ($.$$.System.Predicate$$($.$$.System.Boolean))().$ctor(this,  (/*value*/ value) =>
                {
                    return value;
                }, {"r":262145,"p":[{"n":"value","p":262145}],"n":"","d":953041,"h":0,"f":17825794})), "Expected all values in 'alreadyFound' to be true since collections are considered equal.");
                return true;
            }
            static /*int */ GetNextNonEmptyOrWhitespaceIndex(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ skipEmptyValues, /*out bool*/ separatorFound)
            {
                ;
                separatorFound.$v = false;
                /*var*/ let current = ((startIndex + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*,*/ 44))
                {
                    return current;
                }
                separatorFound.$v = true;
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (skipEmptyValues)
                {
                    while((current < input.Length) && (input.get_Item(current) === /*,*/ 44))
                    {
                        current++;
                        current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                }
                return current;
            }
            static /*int */ AdvanceCacheDirectiveIndex(/*int*/ current, /*string*/ headerValue)
            {
                current += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), current);
                if (current < headerValue.length && $.$$.System.String.get_Chars.call(headerValue, current) === /*=*/ 61)
                {
                    current++;
                    current += $.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue.GetValueLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), current);
                }
                current = $.$$.System.String.IndexOf$1.call(headerValue, /*,*/ 44, current);
                if (current === -1)
                {
                    return headerValue.length;
                }
                current++;
                current += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), current);
                return current;
            }
            static /*bool */ TryParseSeconds(/*StringValues*/ headerValues, /*string*/ targetValue, /*out TimeSpan?*/ value)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringValues.IsNullOrEmpty(headerValues) || $.$$.System.String.IsNullOrEmpty(targetValue))
                {
                    value.$v = null;
                    return false;
                }
                for(/*var*/ let i = 0; i < headerValues.Count; i++)
                {
                    /*var*/ let segment = headerValues.get_Item(i) ?? $.$$.System.String.Empty;
                    /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(segment), 0);
                    while(current < segment.length)
                    {
                        /*long*/ let seconds;
                        /*var*/ let initial = current;
                        /*var*/ let tokenLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValues.get_Item(i)), current);
                        if (tokenLength === targetValue.length && $.$$.System.String.Compare$3(headerValues.get_Item(i), current, targetValue, 0, tokenLength, 5/*StringComparison.OrdinalIgnoreCase*/) === 0 && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64FromHeaderValue(((current + tokenLength) | 0), segment, $.$ref(() => seconds, ($v) => seconds = $v, $.$$.System.Int64)))
                        {
                            value.$v = $.$$.System.TimeSpan.FromSeconds$2(seconds);
                            return true;
                        }
                        current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AdvanceCacheDirectiveIndex(((current + tokenLength) | 0), segment);
                        if (current <= initial)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(false, `Index '${"current"}' not advanced, this is a bug.`);
                            value.$v = null;
                            return false;
                        }
                    }
                }
                value.$v = null;
                return false;
            }
            static /*bool */ ContainsCacheDirective(/*StringValues*/ cacheControlDirectives, /*string*/ targetDirectives)
            {
                if ($.$mep.Microsoft.Extensions.Primitives.StringValues.IsNullOrEmpty(cacheControlDirectives) || $.$$.System.String.IsNullOrEmpty(targetDirectives))
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < cacheControlDirectives.Count; i++)
                {
                    /*var*/ let segment = cacheControlDirectives.get_Item(i) ?? $.$$.System.String.Empty;
                    /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(segment), 0);
                    while(current < segment.length)
                    {
                        /*var*/ let initial = current;
                        /*var*/ let tokenLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(segment), current);
                        if (tokenLength === targetDirectives.length && $.$$.System.String.Compare$3(segment, current, targetDirectives, 0, tokenLength, 5/*StringComparison.OrdinalIgnoreCase*/) === 0)
                        {
                            return true;
                        }
                        current = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AdvanceCacheDirectiveIndex(((current + tokenLength) | 0), segment);
                        if (current <= initial)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(false, `Index '${"current"}' not advanced, this is a bug.`);
                            return false;
                        }
                    }
                }
                return false;
            }
            static /*bool */ TryParseNonNegativeInt64FromHeaderValue(/*int*/ startIndex, /*string*/ headerValue, /*out long*/ result)
            {
                startIndex += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), startIndex);
                if (startIndex >= ((headerValue.length - 1) | 0) || $.$$.System.String.get_Chars.call(headerValue, startIndex) !== /*=*/ 61)
                {
                    result.$v = 0n;
                    return false;
                }
                startIndex++;
                startIndex += $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), startIndex);
                if ($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.TryParseNonNegativeInt64(new $.$mep.Microsoft.Extensions.Primitives.StringSegment().$ctor$3(headerValue, startIndex, $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetNumberLength($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(headerValue), startIndex, false)), result))
                {
                    return true;
                }
                result.$v = 0n;
                return false;
            }
            static /*bool */ TryParseNonNegativeInt32(/*StringSegment*/ value, /*out int*/ result)
            {
                if ($.$$.System.String.IsNullOrEmpty(value.Buffer) || value.Length === 0)
                {
                    result.$v = 0;
                    return false;
                }
                return $.$$.System.Int32.TryParse$3(value.AsSpan(), 0/*NumberStyles.None*/, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo, result);
            }
            static /*bool */ TryParseNonNegativeInt64(/*StringSegment*/ value, /*out long*/ result)
            {
                if ($.$$.System.String.IsNullOrEmpty(value.Buffer) || value.Length === 0)
                {
                    result.$v = 0n;
                    return false;
                }
                return $.$$.System.Int64.TryParse$3(value.AsSpan(), 0/*NumberStyles.None*/, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo, result);
            }
            static /*bool */ TryParseQualityDouble(/*StringSegment*/ input, /*int*/ startIndex, /*out double*/ quality, /*out int*/ length)
            {
                quality.$v = 0;
                length.$v = 0;
                /*var*/ let inputLength = input.Length;
                /*var*/ let current = startIndex;
                /*var*/ let limit = ((startIndex + 10/*_qualityValueMaxCharCount*/) | 0);
                /*var*/ let decPart = 0;
                /*var*/ let decPow = 1;
                if (current >= inputLength)
                {
                    return false;
                }
                /*var*/ let ch = input.get_Item(current);
                /*int*/ let intPart;
                if (ch >= /*0*/ 48 && ch <= /*1*/ 49)
                {
                    intPart = ch - /*0*/ 48;
                    current++;
                }
                else 
                {
                    return false;
                }
                if (current < inputLength)
                {
                    ch = input.get_Item(current);
                    if (ch >= /*0*/ 48 && ch <= /*9*/ 57)
                    {
                        return false;
                    }
                    if (ch === /*.*/ 46)
                    {
                        current++;
                        while(current < inputLength)
                        {
                            ch = input.get_Item(current);
                            if (ch >= /*0*/ 48 && ch <= /*9*/ 57)
                            {
                                if (current >= limit)
                                {
                                    return false;
                                }
                                decPart = ((((((decPart * 10) | 0) + ch) | 0) - /*0*/ 48) | 0);
                                decPow *= 10;
                                current++;
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                }
                if (decPart !== 0)
                {
                    quality.$v = intPart + decPart / $.$cast(decPow, $.$$.System.Double);
                }
                else 
                {
                    quality.$v = intPart;
                }
                if (quality.$v > 1)
                {
                    quality.$v = 0;
                    return false;
                }
                length.$v = ((current - startIndex) | 0);
                return true;
            }
            static /*string */ FormatNonNegativeInt64(/*long*/ value)
            {
                if (value < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int64), "The value to be formatted must be non-negative.");
                }
                if (value === 0n)
                {
                    return "0";
                }
                return $.$$.System.UInt64.ToString$1.call(($.$cast(value, $.$$.System.UInt64)), $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
            }
            static /*string */ FormatInt64(/*long*/ value)
            {
                return (() =>
                {
                    if (value === 0n)
                    {
                        return "0";
                    }
                    if (value === 1n)
                    {
                        return "1";
                    }
                    if (value === BigInt(-1))
                    {
                        return "-1";
                    }
                    return $.$$.System.Int64.ToString$1.call(value, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                })();
            }
            static /*bool */ TryParseDate(/*StringSegment*/ input, /*out DateTimeOffset*/ result)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.TryStringToDate(input, result);
            }
            static /*string */ FormatDate$1(/*DateTimeOffset*/ dateTime)
            {
                return $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.FormatDate(dateTime, false);
            }
            static /*string */ FormatDate(/*DateTimeOffset*/ dateTime, /*bool*/ quoted)
            {
                if (quoted)
                {
                    return $.$$.System.String.Create$10($.$$.System.DateTimeOffset, 31, dateTime, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.DateTimeOffset))().$ctor(this,  (/*span*/ span, /*dt*/ dt) =>
                    {
                        span.get_Item(0).$v = span.get_Item(30).$v = /*\"*/ 34;
                        dt.TryFormat$1(span.Slice$1(1), $.$discardRef(), $.$$.System.String.op_Implicit("r"), $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }, {"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"dt","p":34471937}],"n":"","d":953041,"h":0,"f":17825794}));
                }
                return dateTime.ToString$2("r", $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            static /*StringSegment */ RemoveQuotes(/*StringSegment*/ input)
            {
                if ($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.IsQuoted(input))
                {
                    input = input.Subsegment(1, ((input.Length - 2) | 0));
                }
                return input;
            }
            static /*bool */ IsQuoted(/*StringSegment*/ input)
            {
                return !$.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) && input.Length >= 2 && input.get_Item(0) === /*\"*/ 34 && input.get_Item(((input.Length - 1) | 0)) === /*\"*/ 34;
            }
            static /*StringSegment */ UnescapeAsQuotedString(/*StringSegment*/ input)
            {
                input = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(input);
                /*var*/ let backSlashCount = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CountBackslashesForDecodingQuotedString(input);
                if (backSlashCount === 0)
                {
                    return input;
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Create$10($.$mep.Microsoft.Extensions.Primitives.StringSegment, ((input.Length - backSlashCount) | 0), input, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor(this,  (/**/ span, /*segment*/ segment) =>
                {
                    /*var*/ let spanIndex = 0;
                    /*var*/ let spanLength = span.Length;
                    for(/*var*/ let i = 0; i < segment.Length && (spanIndex >>> 0) < (spanLength >>> 0); i++)
                    {
                        /*int*/ let nextIndex = ((i + 1) | 0);
                        if ((nextIndex >>> 0) < (segment.Length >>> 0) && segment.get_Item(i) === /*\\*/ 92)
                        {
                            span.get_Item(spanIndex).$v = segment.get_Item(nextIndex);
                            i++;
                        }
                        else 
                        {
                            span.get_Item(spanIndex).$v = segment.get_Item(i);
                        }
                        spanIndex++;
                    }
                }, {"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"segment","p":851970}],"n":"","d":953041,"h":0,"f":17825794})));
            }
            static /*int */ CountBackslashesForDecodingQuotedString(/*StringSegment*/ input)
            {
                /*var*/ let numberBackSlashes = 0;
                for(/*var*/ let i = 0; i < input.Length; i++)
                {
                    if (i < ((input.Length - 1) | 0) && input.get_Item(i) === /*\\*/ 92)
                    {
                        if (input.get_Item(((i + 1) | 0)) === /*\\*/ 92)
                        {
                            i++;
                        }
                        numberBackSlashes++;
                    }
                }
                return numberBackSlashes;
            }
            static /*StringSegment */ EscapeAsQuotedString(/*StringSegment*/ input)
            {
                /*var*/ let backSlashCount = $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CountAndCheckCharactersNeedingBackslashesWhenEncoding(input);
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2($.$$.System.String.Create$10($.$mep.Microsoft.Extensions.Primitives.StringSegment, ((((input.Length + backSlashCount) | 0) + 2) | 0), input, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$mep.Microsoft.Extensions.Primitives.StringSegment))().$ctor(this,  (/*span*/ span, /*segment*/ segment) =>
                {
                    span.get_Item(((span.Length - 1) | 0)).$v = span.get_Item(0).$v = /*\"*/ 34;
                    /*var*/ let spanIndex = 1;
                    for(/*var*/ let i = 0; i < segment.Length; i++)
                    {
                        if (segment.get_Item(i) === /*\\*/ 92 || segment.get_Item(i) === /*\"*/ 34)
                        {
                            span.get_Item(spanIndex++).$v = /*\\*/ 92;
                        }
                        else if ((segment.get_Item(i) <= 31 || segment.get_Item(i) === 127) && segment.get_Item(i) !== 9)
                        {
                            throw new $.$$.System.FormatException().$ctor$12(`Invalid control character '${$.$$.System.Char.ToString.call(segment.get_Item(i))}' in input.`);
                        }
                        span.get_Item(spanIndex++).$v = segment.get_Item(i);
                    }
                }, {"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"segment","p":851970}],"n":"","d":953041,"h":0,"f":17825794})));
            }
            static /*int */ CountAndCheckCharactersNeedingBackslashesWhenEncoding(/*StringSegment*/ input)
            {
                /*var*/ let numberOfCharactersNeedingEscaping = 0;
                for(/*var*/ let i = 0; i < input.Length; i++)
                {
                    if (input.get_Item(i) === /*\\*/ 92 || input.get_Item(i) === /*\"*/ 34)
                    {
                        numberOfCharactersNeedingEscaping++;
                    }
                }
                return numberOfCharactersNeedingEscaping;
            }
            static /*void */ ThrowIfReadOnly(/*bool*/ isReadOnly)
            {
                if (isReadOnly)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("The object cannot be modified because it is read-only.");
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.QualityName = "q";
                }
                {
                    this.BytesUnit = "bytes";
                }
            }
            static $h = 953041;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"parameters","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h},{"n":"value","p":$.$typeNullable($.$$.System.Double).$h}],"n":"SetQuality","d":953041,"h":17180822225,"f":16777256},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"parameters","p":$.$$.System.Collections.Generic.IList$$($.$mnhh.Microsoft.Net.Http.Headers.NameValueHeaderValue).$h}],"n":"GetQuality","d":953041,"h":21475789521,"f":16777256},{"r":65537,"p":[{"n":"value","p":851970},{"n":"parameterName","p":1310721}],"n":"CheckValidToken","d":953041,"h":25770756817,"f":16777256},{"r":262145,"p":[{"n":"x","p":(T) => $.$$.System.Collections.Generic.ICollection$$(T).$h},{"n":"y","p":(T) => $.$$.System.Collections.Generic.ICollection$$(T).$h}],"g":["T"],"n":"AreEqualCollections","o":"@$1","d":953041,"h":30065724113,"f":16908328},{"r":262145,"p":[{"n":"x","p":(T) => $.$$.System.Collections.Generic.ICollection$$(T).$h},{"n":"y","p":(T) => $.$$.System.Collections.Generic.ICollection$$(T).$h},{"n":"comparer","p":(T) => $.$$.System.Collections.Generic.IEqualityComparer$$(T).$h}],"g":["T"],"n":"AreEqualCollections","d":953041,"h":34360691409,"f":16908328},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"skipEmptyValues","p":262145},{"n":"separatorFound","p":262145,"f":2}],"n":"GetNextNonEmptyOrWhitespaceIndex","d":953041,"h":38655658705,"f":16777256},{"r":655361,"p":[{"n":"current","p":655361},{"n":"headerValue","p":1310721}],"n":"AdvanceCacheDirectiveIndex","d":953041,"h":42950626001,"f":16777250},{"r":262145,"p":[{"n":"headerValues","p":1114114},{"n":"targetValue","p":1310721},{"n":"value","p":$.$typeNullable($.$$.System.TimeSpan).$h,"f":2}],"n":"TryParseSeconds","d":953041,"h":47245593297,"f":16777249},{"r":262145,"p":[{"n":"cacheControlDirectives","p":1114114},{"n":"targetDirectives","p":1310721}],"n":"ContainsCacheDirective","d":953041,"h":51540560593,"f":16777249},{"r":262145,"p":[{"n":"startIndex","p":655361},{"n":"headerValue","p":1310721},{"n":"result","p":917505,"f":2}],"n":"TryParseNonNegativeInt64FromHeaderValue","d":953041,"h":55835527889,"f":16777250},{"r":262145,"p":[{"n":"value","p":851970},{"n":"result","p":655361,"f":2}],"n":"TryParseNonNegativeInt32","d":953041,"h":60130495185,"f":16777249},{"r":262145,"p":[{"n":"value","p":851970},{"n":"result","p":917505,"f":2}],"n":"TryParseNonNegativeInt64","d":953041,"h":64425462481,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"quality","p":1179649,"f":2},{"n":"length","p":655361,"f":2}],"n":"TryParseQualityDouble","d":953041,"h":68720429777,"f":16777256},{"r":1310721,"p":[{"n":"value","p":917505}],"n":"FormatNonNegativeInt64","d":953041,"h":73015397073,"f":16777249},{"r":1310721,"p":[{"n":"value","p":917505}],"n":"FormatInt64","d":953041,"h":77310364369,"f":16777256},{"r":262145,"p":[{"n":"input","p":851970},{"n":"result","p":34471937,"f":2}],"n":"TryParseDate","d":953041,"h":81605331665,"f":16777249},{"r":1310721,"p":[{"n":"dateTime","p":34471937}],"n":"FormatDate","o":"@$1","d":953041,"h":85900298961,"f":16777249},{"r":1310721,"p":[{"n":"dateTime","p":34471937},{"n":"quoted","p":262145}],"n":"FormatDate","d":953041,"h":90195266257,"f":16777249},{"r":851970,"p":[{"n":"input","p":851970}],"n":"RemoveQuotes","d":953041,"h":94490233553,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970}],"n":"IsQuoted","d":953041,"h":98785200849,"f":16777249},{"r":851970,"p":[{"n":"input","p":851970}],"n":"UnescapeAsQuotedString","d":953041,"h":103080168145,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970}],"n":"CountBackslashesForDecodingQuotedString","d":953041,"h":107375135441,"f":16777250},{"r":851970,"p":[{"n":"input","p":851970}],"n":"EscapeAsQuotedString","d":953041,"h":111670102737,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970}],"n":"CountAndCheckCharactersNeedingBackslashesWhenEncoding","d":953041,"h":115965070033,"f":16777250},{"r":65537,"p":[{"n":"isReadOnly","p":262145}],"n":"ThrowIfReadOnly","d":953041,"h":120260037329,"f":16777256}],"l":[{"t":655361,"n":"_qualityValueMaxCharCount","d":953041,"h":4295920337,"f":4194338},{"t":1310721,"n":"QualityName","d":953041,"h":8590887633,"f":4194338},{"t":1310721,"n":"BytesUnit","d":953041,"h":12885854929,"f":4194344}],"h":953041}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HeaderUtilities`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue", ($self) => class RangeHeaderValue extends $.$$.System.Object
        {
            /*HttpHeaderParser<RangeHeaderValue>*/ static Parser = null;
            /*StringSegment*/ _unit;
            /*ICollection<RangeItemHeaderValue>?*/ _ranges = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                }
                return this;
            }
            $ctor$2(/*long?*/ $from, /*long?*/ to)
            {
                super.$ctor();
                {
                    this._unit = $.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2("bytes"/*HeaderUtilities.BytesUnit*/);
                    this.Ranges.System$Collections$Generic$ICollection$$$Add(new $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue().$ctor$1($from, to), [$.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue]);
                }
                return this;
            }
            /*StringSegment */ get Unit()
            {
                return this._unit;
            }
            /*StringSegment */ set Unit(value)
            {
                $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.CheckValidToken(value, "value");
                this._unit = value;
            }
            /*ICollection<RangeItemHeaderValue> */ get Ranges()
            {
                if (this._ranges === null)
                {
                    this._ranges = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue))().$ctor$3();
                }
                return this._ranges;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                sb.Append$15(this._unit.AsSpan());
                sb.Append$3(/*=*/ 61);
                /*var*/ let first = true;
                var $en2 = this.Ranges.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var range = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (first)
                        {
                            first = false;
                        }
                        else 
                        {
                            sb.Append$19(", ");
                        }
                        sb.Append$13($.$box(range.From, $.$$.System.Nullable$$($.$$.System.Int64)));
                        sb.Append$3(/*-*/ 45);
                        sb.Append$13($.$box(range.To, $.$$.System.Nullable$$($.$$.System.Int64)));
                    }
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.ToString.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*var*/ let other = $.$as(obj, $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue);
                if (other === null)
                {
                    return false;
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(this._unit, other._unit, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.AreEqualCollections$1($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue, this.Ranges, other.Ranges);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*var*/ let result = $.$mep.Microsoft.Extensions.Primitives.StringSegmentComparer.OrdinalIgnoreCase.GetHashCode$1(this._unit);
                var $en2 = this.Ranges.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var range = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        result = result ^ $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.GetHashCode.call(range);
                    }
                }
                return result;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.GetHashCode.apply(this, arguments); }
            static /*RangeHeaderValue */ Parse(/*StringSegment*/ input)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.Parser.ParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32));
            }
            static /*bool */ TryParse(/*StringSegment*/ input, /*out RangeHeaderValue?*/ parsedValue)
            {
                /*var*/ let index = 0;
                return $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.Parser.TryParseValue(input, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), parsedValue);
            }
            static /*int */ GetRangeLength(/*StringSegment*/ input, /*int*/ startIndex, /*out RangeHeaderValue?*/ parsedValue)
            {
                ;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (startIndex >= input.Length))
                {
                    return 0;
                }
                /*var*/ let unitLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, startIndex);
                if (unitLength === 0)
                {
                    return 0;
                }
                /*RangeHeaderValue*/ let result = new $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue().$ctor$1();
                result._unit = input.Subsegment(startIndex, unitLength);
                /*var*/ let current = ((startIndex + unitLength) | 0);
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if ((current === input.Length) || (input.get_Item(current) !== /*=*/ 61))
                {
                    return 0;
                }
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                /*var*/ let rangesLength = $.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue.GetRangeItemListLength(input, current, result.Ranges);
                if (rangesLength === 0)
                {
                    return 0;
                }
                current = ((current + rangesLength) | 0);
                $.$$.System.Diagnostics.Contracts.Contract.Assert(current === input.Length, "GetRangeItemListLength() should consume the whole string or fail.");
                parsedValue.$v = result;
                return ((current - startIndex) | 0);
            }
            //default member initializer
            constructor()
            {
                super();
                this._unit = $.$default($.$mep.Microsoft.Extensions.Primitives.StringSegment);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Parser = new ($.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue))().$ctor$3(false, new $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue).GetParsedValueLengthDelegate().$ctor($.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue, $.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue.GetRangeLength));
                }
            }
            static $h = 1542865;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851970,"g":{"r":0,"d":0,"h":30066313937,"f":50331649},"s":{"r":0,"d":0,"h":34361281233,"f":83886081},"n":"Unit","d":1542865,"h":25771346641,"f":2097153},{"p":$.$$.System.Collections.Generic.ICollection$$($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue).$h,"g":{"r":0,"d":0,"h":42951215825,"f":50331649},"n":"Ranges","d":1542865,"h":38656248529,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":1542865,"h":47246183121,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1542865,"h":51541150417,"f":16809985},{"r":655361,"n":"GetHashCode","d":1542865,"h":55836117713,"f":16809985},{"r":1542865,"p":[{"n":"input","p":851970}],"n":"Parse","d":1542865,"h":60131085009,"f":16777249},{"r":262145,"p":[{"n":"input","p":851970},{"n":"parsedValue","p":1542865,"f":2}],"n":"TryParse","d":1542865,"h":64426052305,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":1542865,"f":2}],"n":"GetRangeLength","d":1542865,"h":68721019601,"f":16777250}],"l":[{"t":$.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.RangeHeaderValue).$h,"n":"Parser","d":1542865,"h":4296510161,"f":4194338},{"t":851970,"n":"_unit","d":1542865,"h":8591477457,"f":4194306},{"t":$.$$.System.Collections.Generic.ICollection$$($.$mnhh.Microsoft.Net.Http.Headers.RangeItemHeaderValue).$h,"n":"_ranges","d":1542865,"h":12886444753,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1542865,"h":17181412049,"f":16777217},{"p":[{"n":"from","p":$.$typeNullable($.$$.System.Int64).$h},{"n":"to","p":$.$typeNullable($.$$.System.Int64).$h}],"n":".ctor","o":"$ctor$2","d":1542865,"h":21476379345,"f":16777217}],"h":1542865}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RangeHeaderValue`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared", ($self) => class CookieHeaderParserShared
        {
            /*SearchValues<char>*/ static CookieValueChar = null;
            static /*bool */ TryParseValues(/*StringValues*/ values, /*IDictionary<string, string>*/ store, /*bool*/ supportsMultipleValues)
            {
                if (values.Count === 0)
                {
                    return false;
                }
                /*var*/ let hasFoundValue = false;
                for(/*var*/ let i = 0; i < values.Count; i++)
                {
                    /*var*/ let value = values.get_Item(i);
                    /*var*/ let index = 0;
                    while(!$.$$.System.String.IsNullOrEmpty(value) && index < value.length)
                    {
                        /*var*/ let parsedName;
                        /*var*/ let parsedValue;
                        if ($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.TryParseValue($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(value), $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), supportsMultipleValues, $.$ref(() => parsedName, ($v) => parsedName = $v, $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment)), $.$ref(() => parsedValue, ($v) => parsedValue = $v, $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment))))
                        {
                            if (parsedName === null || $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedName)) || parsedValue === null || $.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedValue)))
                            {
                                continue;
                            }
                            store.System$Collections$Generic$IDictionary$$$$set_Item($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedName).Value, $.$spu.System.Uri.UnescapeDataString$2($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedValue).Value), [$.$$.System.String, $.$$.System.String]);
                            hasFoundValue = true;
                        }
                        else 
                        {
                            index++;
                        }
                    }
                }
                return hasFoundValue;
            }
            static /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*bool*/ supportsMultipleValues, /*out StringSegment?*/ parsedName, /*out StringSegment?*/ parsedValue)
            {
                parsedName.$v = null;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(value) || (index.$v === value.Length))
                {
                    return supportsMultipleValues;
                }
                /*var*/ let separatorFound;
                /*var*/ let current = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetNextNonEmptyOrWhitespaceIndex(value, index.$v, supportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                if (separatorFound && !supportsMultipleValues)
                {
                    return false;
                }
                if (current === value.Length)
                {
                    if (supportsMultipleValues)
                    {
                        index.$v = current;
                    }
                    return supportsMultipleValues;
                }
                if (!$.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.TryGetCookieLength(value, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), parsedName, parsedValue))
                {
                    /*var*/ let separatorIndex = value.IndexOf$1(/*;*/ 59, current);
                    if (separatorIndex > 0)
                    {
                        index.$v = separatorIndex;
                    }
                    else 
                    {
                        index.$v = value.Length;
                    }
                    return false;
                }
                current = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetNextNonEmptyOrWhitespaceIndex(value, current, supportsMultipleValues, $.$ref(() => separatorFound, ($v) => separatorFound = $v, $.$$.System.Boolean));
                if ((separatorFound && !supportsMultipleValues) || (!separatorFound && (current < value.Length)))
                {
                    /*var*/ let separatorIndex = value.IndexOf$1(/*;*/ 59, current);
                    if (separatorIndex > 0)
                    {
                        index.$v = separatorIndex;
                    }
                    else 
                    {
                        index.$v = value.Length;
                    }
                    return false;
                }
                index.$v = current;
                return true;
            }
            static /*int */ GetNextNonEmptyOrWhitespaceIndex(/*StringSegment*/ input, /*int*/ startIndex, /*bool*/ skipEmptyValues, /*out bool*/ separatorFound)
            {
                ;
                separatorFound.$v = false;
                /*var*/ let current = ((startIndex + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, startIndex)) | 0);
                if (current === input.Length || input.get_Item(current) !== /*;*/ 59)
                {
                    return current;
                }
                separatorFound.$v = true;
                current++;
                current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                if (skipEmptyValues)
                {
                    while(current < input.Length && input.get_Item(current) === /*;*/ 59)
                    {
                        current++;
                        current = ((current + $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetWhitespaceLength(input, current)) | 0);
                    }
                }
                return current;
            }
            static /*bool */ TryGetCookieLength(/*StringSegment*/ input, /*ref int*/ offset, /*out StringSegment?*/ parsedName, /*out StringSegment?*/ parsedValue)
            {
                ;
                parsedName.$v = null;
                parsedValue.$v = null;
                if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.IsNullOrEmpty(input) || (offset.$v >= input.Length))
                {
                    return false;
                }
                /*var*/ let itemLength = $.$mnhh.Microsoft.Net.Http.Headers.HttpRuleParser.GetTokenLength(input, offset.$v);
                if (itemLength === 0)
                {
                    return false;
                }
                parsedName.$v = input.Subsegment(offset.$v, itemLength);
                offset.$v += itemLength;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.ReadEqualsSign(input, offset))
                {
                    return false;
                }
                parsedValue.$v = $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.GetCookieValue(input, offset);
                return true;
            }
            static /*StringSegment */ GetCookieValue(/*StringSegment*/ input, /*ref int*/ offset)
            {
                ;
                ;
                /*var*/ let startIndex = offset.$v;
                if (offset.$v >= input.Length)
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty;
                }
                /*var*/ let inQuotes = false;
                if (input.get_Item(offset.$v) === /*\"*/ 34)
                {
                    inQuotes = true;
                    offset.$v++;
                }
                /*var*/ let delta = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, input.AsSpan$2(offset.$v), $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.CookieValueChar);
                if (delta < 0)
                {
                    offset.$v = input.Length;
                }
                else 
                {
                    offset.$v += delta;
                }
                if (inQuotes)
                {
                    if (offset.$v === input.Length || input.get_Item(offset.$v) !== /*\"*/ 34)
                    {
                        return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty;
                    }
                    offset.$v++;
                }
                /*var*/ let length = ((offset.$v - startIndex) | 0);
                if (offset.$v > startIndex)
                {
                    return input.Subsegment(startIndex, length);
                }
                return $.$mep.Microsoft.Extensions.Primitives.StringSegment.Empty;
            }
            static /*bool */ ReadEqualsSign(/*StringSegment*/ input, /*ref int*/ offset)
            {
                if (offset.$v >= input.Length || input.get_Item(offset.$v) !== /*=*/ 61)
                {
                    return false;
                }
                offset.$v++;
                return true;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.CookieValueChar = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!#$%&'()*+-./0123456789:<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
                }
            }
            static $h = 494289;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"values","p":1114114},{"n":"store","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h},{"n":"supportsMultipleValues","p":262145}],"n":"TryParseValues","d":494289,"h":8590428881,"f":16777249},{"r":262145,"p":[{"n":"value","p":851970},{"n":"index","p":655361,"f":4},{"n":"supportsMultipleValues","p":262145},{"n":"parsedName","p":$.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"f":2},{"n":"parsedValue","p":$.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"f":2}],"n":"TryParseValue","d":494289,"h":12885396177,"f":16777249},{"r":655361,"p":[{"n":"input","p":851970},{"n":"startIndex","p":655361},{"n":"skipEmptyValues","p":262145},{"n":"separatorFound","p":262145,"f":2}],"n":"GetNextNonEmptyOrWhitespaceIndex","d":494289,"h":17180363473,"f":16777250},{"r":262145,"p":[{"n":"input","p":851970},{"n":"offset","p":655361,"f":4},{"n":"parsedName","p":$.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"f":2},{"n":"parsedValue","p":$.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment).$h,"f":2}],"n":"TryGetCookieLength","d":494289,"h":21475330769,"f":16777256},{"r":851970,"p":[{"n":"input","p":851970},{"n":"offset","p":655361,"f":4}],"n":"GetCookieValue","d":494289,"h":25770298065,"f":16777256},{"r":262145,"p":[{"n":"input","p":851970},{"n":"offset","p":655361,"f":4}],"n":"ReadEqualsSign","d":494289,"h":30065265361,"f":16777250}],"l":[{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"CookieValueChar","d":494289,"h":4295461585,"f":4194338}],"h":494289}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `CookieHeaderParserShared`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser<>", (T) => $asm.$gt("$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser<>", [T], ($self) => class GenericHeaderParser$$ extends $.$mnhh.Microsoft.Net.Http.Headers.BaseHeaderParser$$(T)
        {
            static $_GetParsedValueLengthDelegate;
            static get GetParsedValueLengthDelegate()
            {
                let $cls = $.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$(T);
                return $cls.$_GetParsedValueLengthDelegate ??= $asm.$ncls("$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$.GetParsedValueLengthDelegate", ($self) => class GetParsedValueLengthDelegate extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*int*/ Invoke(/**/ value, /*$.$$.System.Int32*/ startIndex, /**/ parsedValue)
                    {
                        return this.$nativeFunction.call(this.$target, value, startIndex, parsedValue);
                    }
                    static $h = 756433;
                    static $f = 0b10000000011000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":655361,"p":[{"n":"value","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":T?.$h??1507328,"f":2}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777345},{"r":57016321,"p":[{"n":"value","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":T?.$h??1507328,"f":2},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777345},{"r":655361,"p":[{"n":"parsedValue","p":T?.$h??1507328,"f":2},{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[57212929,113246209],"d":$.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `GenericHeaderParser<${T?.$fullName}>.GetParsedValueLengthDelegate`; }
                }, $cls, ($v) => $cls.$_GetParsedValueLengthDelegate = $v);
            }
            /*GetParsedValueLengthDelegate*/ _getParsedValueLength = null;
            $ctor$3(/*bool*/ supportsMultipleValues, /*GetParsedValueLengthDelegate*/ getParsedValueLength)
            {
                super.$ctor$2(supportsMultipleValues);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(getParsedValueLength, "getParsedValueLength");
                    this._getParsedValueLength = getParsedValueLength;
                }
                return this;
            }
            /*int */ GetParsedValueLength(/*StringSegment*/ value, /*int*/ startIndex, /*out T?*/ parsedValue)
            {
                return this._getParsedValueLength.Invoke(value, startIndex, parsedValue);
            }
            static $h = 690897;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"value","p":851970},{"n":"startIndex","p":655361},{"n":"parsedValue","p":T?.$h??1507328,"f":2}],"n":"GetParsedValueLength","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16809988}],"l":[{"t":$.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$(T).GetParsedValueLengthDelegate.$h,"n":"_getParsedValueLength","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"supportsMultipleValues","p":262145},{"n":"getParsedValueLength","p":$.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$(T).GetParsedValueLengthDelegate.$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777224}],"g":[T?.$h??1507328],"j":[$.$mnhh.Microsoft.Net.Http.Headers.GenericHeaderParser$$(T).GetParsedValueLengthDelegate.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$mnhh.Microsoft.Net.Http.Headers.BaseHeaderParser$$(T); }
            static get $fullName() { return `GenericHeaderParser<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$mnhh.Microsoft.Net.Http.Headers.HttpParseResult", ($self) => class HttpParseResult extends $.$$.System.Enum
        {
            static Parsed = 0;
            static NotParsed = 1;
            static InvalidFormat = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Parsed": 0n,
                    "NotParsed": 1n,
                    "InvalidFormat": 2n
                };
            }
            static $h = 1084113;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1084113,"n":"Parsed","d":1084113,"h":4296051409,"f":4194337},{"t":1084113,"n":"NotParsed","d":1084113,"h":8591018705,"f":4194337},{"t":1084113,"n":"InvalidFormat","d":1084113,"h":12885986001,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1084113,"h":17180953297,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1084113}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `HttpParseResult`; }
        });
        
        $asm.$str("$mnhh.Microsoft.Net.Http.Headers.SameSiteMode", ($self) => class SameSiteMode extends $.$$.System.Enum
        {
            static Unspecified = -1;
            static None = 0;
            static Lax = 1;
            static Strict = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "None": 0n,
                    "Lax": 1n,
                    "Strict": 2n
                };
            }
            static $h = 1673937;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1673937,"n":"Unspecified","d":1673937,"h":4296641233,"f":4194337},{"t":1673937,"n":"None","d":1673937,"h":8591608529,"f":4194337},{"t":1673937,"n":"Lax","d":1673937,"h":12886575825,"f":4194337},{"t":1673937,"n":"Strict","d":1673937,"h":17181543121,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1673937,"h":21476510417,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1673937}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `SameSiteMode`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValueComparer", ($self) => class MediaTypeHeaderValueComparer extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*MediaTypeHeaderValueComparer*/ static QualityComparer = null;
            /*int */ Compare(/*MediaTypeHeaderValue?*/ mediaType1, /*MediaTypeHeaderValue?*/ mediaType2)
            {
                if ($.$$.System.Object.ReferenceEquals(mediaType1, mediaType2))
                {
                    return 0;
                }
                if (mediaType1 === null)
                {
                    return -1;
                }
                if (mediaType2 === null)
                {
                    return 1;
                }
                /*var*/ let returnValue = $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValueComparer.CompareBasedOnQualityFactor(mediaType1, mediaType2);
                if (returnValue === 0)
                {
                    if (!mediaType1.Type.Equals$4(mediaType2.Type, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllTypes)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypes && !mediaType2.MatchesAllSubTypes)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypes && mediaType2.MatchesAllSubTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypesWithoutSuffix && !mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypesWithoutSuffix && mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                    else if (!mediaType1.SubType.Equals$4(mediaType2.SubType, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllSubTypes)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllSubTypes)
                        {
                            return 1;
                        }
                        else if (mediaType1.MatchesAllSubTypesWithoutSuffix && !mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (!mediaType1.MatchesAllSubTypesWithoutSuffix && mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                    else if (!mediaType1.Suffix.Equals$4(mediaType2.Suffix, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        if (mediaType1.MatchesAllSubTypesWithoutSuffix)
                        {
                            return -1;
                        }
                        else if (mediaType2.MatchesAllSubTypesWithoutSuffix)
                        {
                            return 1;
                        }
                    }
                }
                return returnValue;
            }
            static /*int */ CompareBasedOnQualityFactor(/*MediaTypeHeaderValue*/ mediaType1, /*MediaTypeHeaderValue*/ mediaType2)
            {
                /*var*/ let mediaType1Quality = mediaType1.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let mediaType2Quality = mediaType2.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let qualityDifference = mediaType1Quality - mediaType2Quality;
                if (qualityDifference < 0)
                {
                    return -1;
                }
                else if (qualityDifference > 0)
                {
                    return 1;
                }
                return 0;
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<Microsoft.Net.Http.Headers.MediaTypeHeaderValue>.Compare(Microsoft.Net.Http.Headers.MediaTypeHeaderValue?, Microsoft.Net.Http.Headers.MediaTypeHeaderValue?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.QualityComparer = new $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValueComparer().$ctor$1();
                }
            }
            static $h = 1280721;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1280721,"g":{"r":0,"d":0,"h":17181149905,"f":50331681},"n":"QualityComparer","d":1280721,"h":12886182609,"f":2097185}],"m":[{"r":655361,"p":[{"n":"mediaType1","p":1215185},{"n":"mediaType2","p":1215185}],"n":"Compare","d":1280721,"h":21476117201,"f":16777217},{"r":655361,"p":[{"n":"mediaType1","p":1215185},{"n":"mediaType2","p":1215185}],"n":"CompareBasedOnQualityFactor","d":1280721,"h":25771084497,"f":16777250}],"c":[{"n":".ctor","o":"$ctor$1","d":1280721,"h":4296248017,"f":16777218}],"i":[$.$$.System.Collections.Generic.IComparer$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue).$h],"h":1280721}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue) ]; }
            static get $fullName() { return `MediaTypeHeaderValueComparer`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer", ($self) => class StringWithQualityHeaderValueComparer extends $.$$.System.Object
        {
            /*StringSegment*/ static Any;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*StringWithQualityHeaderValueComparer*/ static QualityComparer = null;
            /*int */ Compare(/*StringWithQualityHeaderValue?*/ stringWithQuality1, /*StringWithQualityHeaderValue?*/ stringWithQuality2)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stringWithQuality1, "stringWithQuality1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stringWithQuality2, "stringWithQuality2");
                /*var*/ let quality1 = stringWithQuality1.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let quality2 = stringWithQuality2.Quality ?? 1/*HeaderQuality.Match*/;
                /*var*/ let qualityDifference = quality1 - quality2;
                if (qualityDifference < 0)
                {
                    return -1;
                }
                else if (qualityDifference > 0)
                {
                    return 1;
                }
                if (!$.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(stringWithQuality1.Value, stringWithQuality2.Value, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(stringWithQuality1.Value, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer.Any, 4/*StringComparison.Ordinal*/))
                    {
                        return -1;
                    }
                    else if ($.$mep.Microsoft.Extensions.Primitives.StringSegment.Equals$5(stringWithQuality2.Value, $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer.Any, 4/*StringComparison.Ordinal*/))
                    {
                        return 1;
                    }
                }
                return 0;
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<Microsoft.Net.Http.Headers.StringWithQualityHeaderValue>.Compare(Microsoft.Net.Http.Headers.StringWithQualityHeaderValue?, Microsoft.Net.Http.Headers.StringWithQualityHeaderValue?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Any = new $.$mep.Microsoft.Extensions.Primitives.StringSegment().$ctor$4("*");
                }
                {
                    this.QualityComparer = new $.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValueComparer().$ctor$1();
                }
            }
            static $h = 1870545;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1870545,"g":{"r":0,"d":0,"h":21476707025,"f":50331681},"n":"QualityComparer","d":1870545,"h":17181739729,"f":2097185}],"m":[{"r":655361,"p":[{"n":"stringWithQuality1","p":1805009},{"n":"stringWithQuality2","p":1805009}],"n":"Compare","d":1870545,"h":25771674321,"f":16777217}],"l":[{"t":851970,"n":"Any","d":1870545,"h":4296837841,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":1870545,"h":8591805137,"f":16777218}],"i":[$.$$.System.Collections.Generic.IComparer$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue).$h],"h":1870545}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$mnhh.Microsoft.Net.Http.Headers.StringWithQualityHeaderValue) ]; }
            static get $fullName() { return `StringWithQualityHeaderValueComparer`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParser", ($self) => class CookieHeaderParser extends $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue)
        {
            $ctor$2(/*bool*/ supportsMultipleValues)
            {
                super.$ctor$1(supportsMultipleValues);
                {
                }
                return this;
            }
            /*bool */ TryParseValue(/*StringSegment*/ value, /*ref int*/ index, /*out CookieHeaderValue?*/ cookieValue)
            {
                cookieValue.$v = null;
                /*var*/ let parsedName;
                /*var*/ let parsedValue;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderParserShared.TryParseValue(value, index, this.SupportsMultipleValues, $.$ref(() => parsedName, ($v) => parsedName = $v, $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment)), $.$ref(() => parsedValue, ($v) => parsedValue = $v, $.$typeNullable($.$mep.Microsoft.Extensions.Primitives.StringSegment))))
                {
                    return false;
                }
                if (parsedName === null || parsedValue === null)
                {
                    return true;
                }
                cookieValue.$v = new $.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue().$ctor$2($.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedName), $.$$.System.Nullable$$($.$mep.Microsoft.Extensions.Primitives.StringSegment).Value$get.call(parsedValue));
                return true;
            }
            static $h = 428753;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"value","p":851970},{"n":"index","p":655361,"f":4},{"n":"cookieValue","p":559825,"f":2}],"n":"TryParseValue","d":428753,"h":8590363345,"f":16809985}],"c":[{"p":[{"n":"supportsMultipleValues","p":262145}],"n":".ctor","o":"$ctor$2","d":428753,"h":4295396049,"f":16777224}],"h":428753}; }
            static get $b() { return $.$mnhh.Microsoft.Net.Http.Headers.HttpHeaderParser$$($.$mnhh.Microsoft.Net.Http.Headers.CookieHeaderValue); }
            static get $fullName() { return `CookieHeaderParser`; }
        });
        
        $asm.$cls("$mnhh.Microsoft.Net.Http.Headers.ObjectCollection<>", (T) => $asm.$gt("$mnhh.Microsoft.Net.Http.Headers.ObjectCollection<>", [T], ($self) => class ObjectCollection$$ extends $.$$.System.Collections.ObjectModel.Collection$$(T)
        {
            /*Action<T>*/ static DefaultValidator = null;
            /*ObjectCollection<T>*/ static EmptyReadOnlyCollection = null;
            /*Action<T>*/ _validator = null;
            static /*IList<T> */ CreateInnerList(/*bool*/ isReadOnly, /*IEnumerable<T>?*/ other)
            {
                /*var*/ let list = other === null ? new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1() : new ($.$$.System.Collections.Generic.List$$(T))().$ctor$2(other);
                if (isReadOnly)
                {
                    return new ($.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(T))().$ctor$1(list);
                }
                else 
                {
                    return list;
                }
            }
            $ctor$3()
            {
                this.$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).DefaultValidator, false);
                {
                }
                return this;
            }
            $ctor$4(/*Action<T>*/ validator, /*bool*/ isReadOnly)
            {
                super.$ctor$2($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).CreateInnerList(isReadOnly, null));
                {
                    this._validator = validator;
                }
                return this;
            }
            $ctor$5(/*IEnumerable<T>*/ other, /*bool*/ isReadOnly)
            {
                super.$ctor$2($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).CreateInnerList(isReadOnly, other));
                {
                    this._validator = $.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).DefaultValidator;
                    var $en3 = this.Items.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this._validator.Invoke(item);
                        }
                    }
                }
                return this;
            }
            /*bool */ get IsReadOnly()
            {
                return (this).System$Collections$Generic$ICollection$$$IsReadOnly;
            }
            /*void */ InsertItem(/*int*/ index, /*T*/ item)
            {
                this._validator.Invoke(item);
                super.InsertItem(index, item);
            }
            /*void */ SetItem(/*int*/ index, /*T*/ item)
            {
                this._validator.Invoke(item);
                super.SetItem(index, item);
            }
            static /*void */ CheckNotNull(/*T*/ item)
            {
                if ($.$box(item, T) === null)
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("item");
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultValidator = new ($.$$.System.Action$$(T))().$ctor($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T), $.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).CheckNotNull);
                }
                {
                    this.EmptyReadOnlyCollection = new ($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T))().$ctor$4($.$mnhh.Microsoft.Net.Http.Headers.ObjectCollection$$(T).DefaultValidator, true);
                }
            }
            static $h = 1411793;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":50331649},"n":"IsReadOnly","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2097153}],"m":[{"r":$.$$.System.Collections.Generic.IList$$(T).$h,"p":[{"n":"isReadOnly","p":262145},{"n":"other","p":$.$$.System.Collections.Generic.IEnumerable$$(T).$h,"f":65}],"n":"CreateInnerList","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777250},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":T?.$h??1507328}],"n":"InsertItem","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16809988},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":T?.$h??1507328}],"n":"SetItem","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16809988},{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"CheckNotNull","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777250}],"l":[{"t":$.$$.System.Action$$(T).$h,"n":"DefaultValidator","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194344},{"t":this.$h,"n":"EmptyReadOnlyCollection","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194344},{"t":$.$$.System.Action$$(T).$h,"n":"_validator","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217},{"p":[{"n":"validator","p":$.$$.System.Action$$(T).$h},{"n":"isReadOnly","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217},{"p":[{"n":"other","p":$.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"isReadOnly","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217}],"i":[$.$$.System.Collections.Generic.IList$$(T).$h,$.$$.System.Collections.Generic.ICollection$$(T).$h,32047105,31457281,$.$$.System.Collections.Generic.IReadOnlyList$$(T).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,31719425],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Collections.ObjectModel.Collection$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyList$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `ObjectCollection<${T?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http"))