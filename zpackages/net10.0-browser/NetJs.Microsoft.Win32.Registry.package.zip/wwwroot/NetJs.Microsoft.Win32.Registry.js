
//--TRIMMABLE-BOUNDARY-START(77)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw, $ssa) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.Microsoft.Win32.Registry", 
    {
  "h": 77,
  "f": "Microsoft.Win32.Registry",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Win32.Registry",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Win32.Registry",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65613)
        $asm.$cls(`$mwr.MW.Registry`, ($self) => class Registry
        {
            //--TRIMMABLE-BOUNDARY-START(4295032909)
            /*Microsoft.Win32.RegistryKey*/ static ClassesRoot = null;
            //--TRIMMABLE-BOUNDARY-END(4295032909)
            
            //--TRIMMABLE-BOUNDARY-START(8590000205)
            /*Microsoft.Win32.RegistryKey*/ static CurrentConfig = null;
            //--TRIMMABLE-BOUNDARY-END(8590000205)
            
            //--TRIMMABLE-BOUNDARY-START(12884967501)
            /*Microsoft.Win32.RegistryKey*/ static CurrentUser = null;
            //--TRIMMABLE-BOUNDARY-END(12884967501)
            
            //--TRIMMABLE-BOUNDARY-START(21474902093)
            /*Microsoft.Win32.RegistryKey*/ static LocalMachine = null;
            //--TRIMMABLE-BOUNDARY-END(21474902093)
            
            //--TRIMMABLE-BOUNDARY-START(25769869389)
            /*Microsoft.Win32.RegistryKey*/ static PerformanceData = null;
            //--TRIMMABLE-BOUNDARY-END(25769869389)
            
            //--TRIMMABLE-BOUNDARY-START(38654771277)
            /*Microsoft.Win32.RegistryKey*/ static Users = null;
            //--TRIMMABLE-BOUNDARY-END(38654771277)
            
            //--TRIMMABLE-BOUNDARY-START(17179934797)
            static /*object? */ GetValue(/*string*/ keyName, /*string?*/ valueName, /*object?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17179934797)
            
            //--TRIMMABLE-BOUNDARY-START(34359803981)
            static /*void */ SetValue$1(/*string*/ keyName, /*string?*/ valueName, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34359803981)
            
            //--TRIMMABLE-BOUNDARY-START(30064836685)
            static /*void */ SetValue(/*string*/ keyName, /*string?*/ valueName, /*object*/ value, /*Microsoft.Win32.RegistryValueKind*/ valueKind)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30064836685)
            
            static $h = 65613;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934797),
    {
      "r": 131073,
      "p": [
        {
          "n": "keyName",
          "p": 1310721
        },
        {
          "n": "valueName",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": 131073
        }
      ],
      "n": "GetValue",
      "d": 65613,
      "h": 17179934797,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17179934797),
//--TRIMMABLE-BOUNDARY-START(34359803981),
    {
      "r": 65537,
      "p": [
        {
          "n": "keyName",
          "p": 1310721
        },
        {
          "n": "valueName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "o": "@$1",
      "d": 65613,
      "h": 34359803981,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359803981),
//--TRIMMABLE-BOUNDARY-START(30064836685),
    {
      "r": 65537,
      "p": [
        {
          "n": "keyName",
          "p": 1310721
        },
        {
          "n": "valueName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "valueKind",
          "p": 393293
        }
      ],
      "n": "SetValue",
      "d": 65613,
      "h": 30064836685,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064836685)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032909),
    {
      "t": 196685,
      "n": "ClassesRoot",
      "d": 65613,
      "h": 4295032909,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295032909),
//--TRIMMABLE-BOUNDARY-START(8590000205),
    {
      "t": 196685,
      "n": "CurrentConfig",
      "d": 65613,
      "h": 8590000205,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000205),
//--TRIMMABLE-BOUNDARY-START(12884967501),
    {
      "t": 196685,
      "n": "CurrentUser",
      "d": 65613,
      "h": 12884967501,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967501),
//--TRIMMABLE-BOUNDARY-START(21474902093),
    {
      "t": 196685,
      "n": "LocalMachine",
      "d": 65613,
      "h": 21474902093,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474902093),
//--TRIMMABLE-BOUNDARY-START(25769869389),
    {
      "t": 196685,
      "n": "PerformanceData",
      "d": 65613,
      "h": 25769869389,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769869389),
//--TRIMMABLE-BOUNDARY-START(38654771277),
    {
      "t": 196685,
      "n": "Users",
      "d": 65613,
      "h": 38654771277,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654771277)
  ],
  "h": 65613
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.Registry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}Registry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65613)
        
        

        //--TRIMMABLE-BOUNDARY-START(196685)
        $asm.$cls(`$mwr.MW.RegistryKey`, ($self) => class RegistryKey extends $.$$.S.MarshalByRefObject
        {
            //--TRIMMABLE-BOUNDARY-START(4295163981)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163981);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163981)
            
            //--TRIMMABLE-BOUNDARY-START(163208953933)
            /*Microsoft.Win32.SafeHandles.SafeRegistryHandle */ get Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194509901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(163208953933)
            
            //--TRIMMABLE-BOUNDARY-START(167503921229)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784444493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(167503921229)
            
            //--TRIMMABLE-BOUNDARY-START(219043528781)
            /*int */ get SubKeyCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374379085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(219043528781)
            
            //--TRIMMABLE-BOUNDARY-START(227633463373)
            /*int */ get ValueCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(227633463373)
            
            //--TRIMMABLE-BOUNDARY-START(231928430669)
            /*Microsoft.Win32.RegistryView */ get View()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554248269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231928430669)
            
            //--TRIMMABLE-BOUNDARY-START(8590131277)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590131277)
            
            //--TRIMMABLE-BOUNDARY-START(38654902349)
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$6(/*string*/ subkey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38654902349)
            
            //--TRIMMABLE-BOUNDARY-START(25770000461)
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$3(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770000461)
            
            //--TRIMMABLE-BOUNDARY-START(17180065869)
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$1(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*Microsoft.Win32.RegistryOptions*/ registryOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180065869)
            
            //--TRIMMABLE-BOUNDARY-START(12885098573)
            /*Microsoft.Win32.RegistryKey */ CreateSubKey(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*Microsoft.Win32.RegistryOptions*/ registryOptions, /*System.Security.AccessControl.RegistrySecurity?*/ registrySecurity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885098573)
            
            //--TRIMMABLE-BOUNDARY-START(21475033165)
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$2(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*System.Security.AccessControl.RegistrySecurity?*/ registrySecurity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475033165)
            
            //--TRIMMABLE-BOUNDARY-START(34359935053)
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$5(/*string*/ subkey, /*bool*/ writable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34359935053)
            
            //--TRIMMABLE-BOUNDARY-START(30064967757)
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$4(/*string*/ subkey, /*bool*/ writable, /*Microsoft.Win32.RegistryOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30064967757)
            
            //--TRIMMABLE-BOUNDARY-START(47244836941)
            /*void */ DeleteSubKey$1(/*string*/ subkey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47244836941)
            
            //--TRIMMABLE-BOUNDARY-START(42949869645)
            /*void */ DeleteSubKey(/*string*/ subkey, /*bool*/ throwOnMissingSubKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42949869645)
            
            //--TRIMMABLE-BOUNDARY-START(55834771533)
            /*void */ DeleteSubKeyTree$1(/*string*/ subkey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55834771533)
            
            //--TRIMMABLE-BOUNDARY-START(51539804237)
            /*void */ DeleteSubKeyTree(/*string*/ subkey, /*bool*/ throwOnMissingSubKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51539804237)
            
            //--TRIMMABLE-BOUNDARY-START(64424706125)
            /*void */ DeleteValue$1(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64424706125)
            
            //--TRIMMABLE-BOUNDARY-START(60129738829)
            /*void */ DeleteValue(/*string*/ name, /*bool*/ throwOnMissingValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60129738829)
            
            //--TRIMMABLE-BOUNDARY-START(68719673421)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719673421)
            
            //--TRIMMABLE-BOUNDARY-START(73014640717)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73014640717)
            
            //--TRIMMABLE-BOUNDARY-START(81604575309)
            static /*Microsoft.Win32.RegistryKey */ FromHandle$1(/*Microsoft.Win32.SafeHandles.SafeRegistryHandle*/ handle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604575309)
            
            //--TRIMMABLE-BOUNDARY-START(77309608013)
            static /*Microsoft.Win32.RegistryKey */ FromHandle(/*Microsoft.Win32.SafeHandles.SafeRegistryHandle*/ handle, /*Microsoft.Win32.RegistryView*/ view)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309608013)
            
            //--TRIMMABLE-BOUNDARY-START(128849215565)
            /*System.Security.AccessControl.RegistrySecurity */ GetAccessControl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849215565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849215565)
            
            //--TRIMMABLE-BOUNDARY-START(133144182861)
            /*System.Security.AccessControl.RegistrySecurity */ GetAccessControl$1(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144182861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144182861)
            
            //--TRIMMABLE-BOUNDARY-START(137439150157)
            /*string[] */ GetSubKeyNames()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439150157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439150157)
            
            //--TRIMMABLE-BOUNDARY-START(150324052045)
            /*object? */ GetValue$2(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324052045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150324052045)
            
            //--TRIMMABLE-BOUNDARY-START(146029084749)
            /*object? */ GetValue$1(/*string?*/ name, /*object?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029084749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(146029084749)
            
            //--TRIMMABLE-BOUNDARY-START(141734117453)
            /*object? */ GetValue(/*string?*/ name, /*object?*/ defaultValue, /*Microsoft.Win32.RegistryValueOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734117453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141734117453)
            
            //--TRIMMABLE-BOUNDARY-START(154619019341)
            /*Microsoft.Win32.RegistryValueKind */ GetValueKind(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619019341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154619019341)
            
            //--TRIMMABLE-BOUNDARY-START(158913986637)
            /*string[] */ GetValueNames()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913986637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158913986637)
            
            //--TRIMMABLE-BOUNDARY-START(171798888525)
            static /*Microsoft.Win32.RegistryKey */ OpenBaseKey(/*Microsoft.Win32.RegistryHive*/ hKey, /*Microsoft.Win32.RegistryView*/ view)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798888525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(171798888525)
            
            //--TRIMMABLE-BOUNDARY-START(180388823117)
            static /*Microsoft.Win32.RegistryKey */ OpenRemoteBaseKey$1(/*Microsoft.Win32.RegistryHive*/ hKey, /*string*/ machineName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388823117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(180388823117)
            
            //--TRIMMABLE-BOUNDARY-START(176093855821)
            static /*Microsoft.Win32.RegistryKey */ OpenRemoteBaseKey(/*Microsoft.Win32.RegistryHive*/ hKey, /*string*/ machineName, /*Microsoft.Win32.RegistryView*/ view)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093855821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(176093855821)
            
            //--TRIMMABLE-BOUNDARY-START(201863659597)
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$4(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863659597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201863659597)
            
            //--TRIMMABLE-BOUNDARY-START(188978757709)
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$1(/*string*/ name, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978757709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188978757709)
            
            //--TRIMMABLE-BOUNDARY-START(184683790413)
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey(/*string*/ name, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*System.Security.AccessControl.RegistryRights*/ rights)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683790413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184683790413)
            
            //--TRIMMABLE-BOUNDARY-START(193273725005)
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$2(/*string*/ name, /*bool*/ writable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273725005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193273725005)
            
            //--TRIMMABLE-BOUNDARY-START(197568692301)
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$3(/*string*/ name, /*System.Security.AccessControl.RegistryRights*/ rights)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568692301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197568692301)
            
            //--TRIMMABLE-BOUNDARY-START(206158626893)
            /*void */ SetAccessControl(/*System.Security.AccessControl.RegistrySecurity*/ registrySecurity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158626893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(206158626893)
            
            //--TRIMMABLE-BOUNDARY-START(214748561485)
            /*void */ SetValue$1(/*string?*/ name, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748561485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(214748561485)
            
            //--TRIMMABLE-BOUNDARY-START(210453594189)
            /*void */ SetValue(/*string?*/ name, /*object*/ value, /*Microsoft.Win32.RegistryValueKind*/ valueKind)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453594189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(210453594189)
            
            //--TRIMMABLE-BOUNDARY-START(223338496077)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338496077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223338496077)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4295163981)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163981)
            
            static $h = 196685;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MarshalByRefObject; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163208953933),
    {
      "p": 589901,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194509901,
        "f": 50331649
      },
      "n": "Handle",
      "d": 196685,
      "h": 163208953933,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163208953933),
//--TRIMMABLE-BOUNDARY-START(167503921229),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784444493,
        "f": 50331649
      },
      "n": "Name",
      "d": 196685,
      "h": 167503921229,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167503921229),
//--TRIMMABLE-BOUNDARY-START(219043528781),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374379085,
        "f": 50331649
      },
      "n": "SubKeyCount",
      "d": 196685,
      "h": 219043528781,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219043528781),
//--TRIMMABLE-BOUNDARY-START(227633463373),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964313677,
        "f": 50331649
      },
      "n": "ValueCount",
      "d": 196685,
      "h": 227633463373,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227633463373),
//--TRIMMABLE-BOUNDARY-START(231928430669),
    {
      "p": 524365,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554248269,
        "f": 50331649
      },
      "n": "View",
      "d": 196685,
      "h": 231928430669,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231928430669)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131277),
    {
      "r": 65537,
      "n": "Close",
      "d": 196685,
      "h": 8590131277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131277),
//--TRIMMABLE-BOUNDARY-START(38654902349),
    {
      "r": 196685,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        }
      ],
      "n": "CreateSubKey",
      "o": "@$6",
      "d": 196685,
      "h": 38654902349,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654902349),
//--TRIMMABLE-BOUNDARY-START(25770000461),
    {
      "r": 196685,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        },
        {
          "n": "permissionCheck",
          "p": 262221
        }
      ],
      "n": "CreateSubKey",
      "o": "@$3",
      "d": 196685,
      "h": 25770000461,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000461),
//--TRIMMABLE-BOUNDARY-START(17180065869),
    {
      "r": 196685,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        },
        {
          "n": "permissionCheck",
          "p": 262221
        },
        {
          "n": "registryOptions",
          "p": 327757
        }
      ],
      "n": "CreateSubKey",
      "o": "@$1",
      "d": 196685,
      "h": 17180065869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065869),
//--TRIMMABLE-BOUNDARY-START(12885098573),
    {
      "r": 196685,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        },
        {
          "n": "permissionCheck",
          "p": 262221
        },
        {
          "n": "registryOptions",
          "p": 327757
        },
        {
          "n": "registrySecurity",
          "p": 852045
        }
      ],
      "n": "CreateSubKey",
      "d": 196685,
      "h": 12885098573,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098573),
//--TRIMMABLE-BOUNDARY-START(21475033165),
    {
      "r": 196685,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        },
        {
          "n": "permissionCheck",
          "p": 262221
        },
        {
          "n": "registrySecurity",
          "p": 852045
        }
      ],
      "n": "CreateSubKey",
      "o": "@$2",
      "d": 196685,
      "h": 21475033165,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033165),
//--TRIMMABLE-BOUNDARY-START(34359935053),
    {
      "r": 196685,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        },
        {
          "n": "writable",
          "p": 262145
        }
      ],
      "n": "CreateSubKey",
      "o": "@$5",
      "d": 196685,
      "h": 34359935053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359935053),
//--TRIMMABLE-BOUNDARY-START(30064967757),
    {
      "r": 196685,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        },
        {
          "n": "writable",
          "p": 262145
        },
        {
          "n": "options",
          "p": 327757
        }
      ],
      "n": "CreateSubKey",
      "o": "@$4",
      "d": 196685,
      "h": 30064967757,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064967757),
//--TRIMMABLE-BOUNDARY-START(47244836941),
    {
      "r": 65537,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        }
      ],
      "n": "DeleteSubKey",
      "o": "@$1",
      "d": 196685,
      "h": 47244836941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244836941),
//--TRIMMABLE-BOUNDARY-START(42949869645),
    {
      "r": 65537,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        },
        {
          "n": "throwOnMissingSubKey",
          "p": 262145
        }
      ],
      "n": "DeleteSubKey",
      "d": 196685,
      "h": 42949869645,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949869645),
//--TRIMMABLE-BOUNDARY-START(55834771533),
    {
      "r": 65537,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        }
      ],
      "n": "DeleteSubKeyTree",
      "o": "@$1",
      "d": 196685,
      "h": 55834771533,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834771533),
//--TRIMMABLE-BOUNDARY-START(51539804237),
    {
      "r": 65537,
      "p": [
        {
          "n": "subkey",
          "p": 1310721
        },
        {
          "n": "throwOnMissingSubKey",
          "p": 262145
        }
      ],
      "n": "DeleteSubKeyTree",
      "d": 196685,
      "h": 51539804237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539804237),
//--TRIMMABLE-BOUNDARY-START(64424706125),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "DeleteValue",
      "o": "@$1",
      "d": 196685,
      "h": 64424706125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424706125),
//--TRIMMABLE-BOUNDARY-START(60129738829),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "throwOnMissingValue",
          "p": 262145
        }
      ],
      "n": "DeleteValue",
      "d": 196685,
      "h": 60129738829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129738829),
//--TRIMMABLE-BOUNDARY-START(68719673421),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 196685,
      "h": 68719673421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719673421),
//--TRIMMABLE-BOUNDARY-START(73014640717),
    {
      "r": 65537,
      "n": "Flush",
      "d": 196685,
      "h": 73014640717,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014640717),
//--TRIMMABLE-BOUNDARY-START(81604575309),
    {
      "r": 196685,
      "p": [
        {
          "n": "handle",
          "p": 589901
        }
      ],
      "n": "FromHandle",
      "o": "@$1",
      "d": 196685,
      "h": 81604575309,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604575309),
//--TRIMMABLE-BOUNDARY-START(77309608013),
    {
      "r": 196685,
      "p": [
        {
          "n": "handle",
          "p": 589901
        },
        {
          "n": "view",
          "p": 524365
        }
      ],
      "n": "FromHandle",
      "d": 196685,
      "h": 77309608013,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309608013),
//--TRIMMABLE-BOUNDARY-START(128849215565),
    {
      "r": 852045,
      "n": "GetAccessControl",
      "d": 196685,
      "h": 128849215565,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849215565),
//--TRIMMABLE-BOUNDARY-START(133144182861),
    {
      "r": 852045,
      "p": [
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "GetAccessControl",
      "o": "@$1",
      "d": 196685,
      "h": 133144182861,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144182861),
//--TRIMMABLE-BOUNDARY-START(137439150157),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "n": "GetSubKeyNames",
      "d": 196685,
      "h": 137439150157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439150157),
//--TRIMMABLE-BOUNDARY-START(150324052045),
    {
      "r": 131073,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetValue",
      "o": "@$2",
      "d": 196685,
      "h": 150324052045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324052045),
//--TRIMMABLE-BOUNDARY-START(146029084749),
    {
      "r": 131073,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": 131073
        }
      ],
      "n": "GetValue",
      "o": "@$1",
      "d": 196685,
      "h": 146029084749,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029084749),
//--TRIMMABLE-BOUNDARY-START(141734117453),
    {
      "r": 131073,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": 131073
        },
        {
          "n": "options",
          "p": 458829
        }
      ],
      "n": "GetValue",
      "d": 196685,
      "h": 141734117453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734117453),
//--TRIMMABLE-BOUNDARY-START(154619019341),
    {
      "r": 393293,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetValueKind",
      "d": 196685,
      "h": 154619019341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619019341),
//--TRIMMABLE-BOUNDARY-START(158913986637),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "n": "GetValueNames",
      "d": 196685,
      "h": 158913986637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158913986637),
//--TRIMMABLE-BOUNDARY-START(171798888525),
    {
      "r": 196685,
      "p": [
        {
          "n": "hKey",
          "p": 131149
        },
        {
          "n": "view",
          "p": 524365
        }
      ],
      "n": "OpenBaseKey",
      "d": 196685,
      "h": 171798888525,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171798888525),
//--TRIMMABLE-BOUNDARY-START(180388823117),
    {
      "r": 196685,
      "p": [
        {
          "n": "hKey",
          "p": 131149
        },
        {
          "n": "machineName",
          "p": 1310721
        }
      ],
      "n": "OpenRemoteBaseKey",
      "o": "@$1",
      "d": 196685,
      "h": 180388823117,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(180388823117),
//--TRIMMABLE-BOUNDARY-START(176093855821),
    {
      "r": 196685,
      "p": [
        {
          "n": "hKey",
          "p": 131149
        },
        {
          "n": "machineName",
          "p": 1310721
        },
        {
          "n": "view",
          "p": 524365
        }
      ],
      "n": "OpenRemoteBaseKey",
      "d": 196685,
      "h": 176093855821,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(176093855821),
//--TRIMMABLE-BOUNDARY-START(201863659597),
    {
      "r": 196685,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "OpenSubKey",
      "o": "@$4",
      "d": 196685,
      "h": 201863659597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201863659597),
//--TRIMMABLE-BOUNDARY-START(188978757709),
    {
      "r": 196685,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "permissionCheck",
          "p": 262221
        }
      ],
      "n": "OpenSubKey",
      "o": "@$1",
      "d": 196685,
      "h": 188978757709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188978757709),
//--TRIMMABLE-BOUNDARY-START(184683790413),
    {
      "r": 196685,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "permissionCheck",
          "p": 262221
        },
        {
          "n": "rights",
          "p": 786509
        }
      ],
      "n": "OpenSubKey",
      "d": 196685,
      "h": 184683790413,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184683790413),
//--TRIMMABLE-BOUNDARY-START(193273725005),
    {
      "r": 196685,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "writable",
          "p": 262145
        }
      ],
      "n": "OpenSubKey",
      "o": "@$2",
      "d": 196685,
      "h": 193273725005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193273725005),
//--TRIMMABLE-BOUNDARY-START(197568692301),
    {
      "r": 196685,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "rights",
          "p": 786509
        }
      ],
      "n": "OpenSubKey",
      "o": "@$3",
      "d": 196685,
      "h": 197568692301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197568692301),
//--TRIMMABLE-BOUNDARY-START(206158626893),
    {
      "r": 65537,
      "p": [
        {
          "n": "registrySecurity",
          "p": 852045
        }
      ],
      "n": "SetAccessControl",
      "d": 196685,
      "h": 206158626893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206158626893),
//--TRIMMABLE-BOUNDARY-START(214748561485),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "o": "@$1",
      "d": 196685,
      "h": 214748561485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214748561485),
//--TRIMMABLE-BOUNDARY-START(210453594189),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "valueKind",
          "p": 393293
        }
      ],
      "n": "SetValue",
      "d": 196685,
      "h": 210453594189,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210453594189),
//--TRIMMABLE-BOUNDARY-START(223338496077),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 196685,
      "h": 223338496077,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(223338496077)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163981),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196685,
      "h": 4295163981,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295163981)
  ],
  "h": 196685
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.RegistryKey`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}RegistryKey`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196685)
        
        

        //--TRIMMABLE-BOUNDARY-START(655437)
        $asm.$cls(`$mwr.SSA.RegistryAccessRule`, ($self) => class RegistryAccessRule extends $.$ssa.SSA.AccessRule
        {
            //--TRIMMABLE-BOUNDARY-START(4295622733)
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295622733);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622733)
            
            //--TRIMMABLE-BOUNDARY-START(8590590029)
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590029);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590029)
            
            //--TRIMMABLE-BOUNDARY-START(12885557325)
            $ctor$5(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557325);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557325)
            
            //--TRIMMABLE-BOUNDARY-START(17180524621)
            $ctor$6(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180524621);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180524621)
            
            //--TRIMMABLE-BOUNDARY-START(30065426509)
            /*System.Security.AccessControl.RegistryRights */ get RegistryRights()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065426509)
            
            static $h = 655437;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.AccessRule; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065426509),
    {
      "p": 786509,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459213,
        "f": 50331649
      },
      "n": "RegistryRights",
      "d": 655437,
      "h": 30065426509,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065426509)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622733),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "registryRights",
          "p": 786509
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655437,
      "h": 4295622733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622733),
//--TRIMMABLE-BOUNDARY-START(8590590029),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "registryRights",
          "p": 786509
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 655437,
      "h": 8590590029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590590029),
//--TRIMMABLE-BOUNDARY-START(12885557325),
    {
      "p": [
        {
          "n": "identity",
          "p": 1310721
        },
        {
          "n": "registryRights",
          "p": 786509
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 655437,
      "h": 12885557325,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557325),
//--TRIMMABLE-BOUNDARY-START(17180524621),
    {
      "p": [
        {
          "n": "identity",
          "p": 1310721
        },
        {
          "n": "registryRights",
          "p": 786509
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 655437,
      "h": 17180524621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180524621)
  ],
  "h": 655437
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.RegistryAccessRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}RegistryAccessRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655437)
        
        

        //--TRIMMABLE-BOUNDARY-START(720973)
        $asm.$cls(`$mwr.SSA.RegistryAuditRule`, ($self) => class RegistryAuditRule extends $.$ssa.SSA.AuditRule
        {
            //--TRIMMABLE-BOUNDARY-START(4295688269)
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688269);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688269)
            
            //--TRIMMABLE-BOUNDARY-START(8590655565)
            $ctor$4(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590655565);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590655565)
            
            //--TRIMMABLE-BOUNDARY-START(21475557453)
            /*System.Security.AccessControl.RegistryRights */ get RegistryRights()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475557453)
            
            static $h = 720973;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.AuditRule; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475557453),
    {
      "p": 786509,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180590157,
        "f": 50331649
      },
      "n": "RegistryRights",
      "d": 720973,
      "h": 21475557453,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475557453)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688269),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "registryRights",
          "p": 786509
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720973,
      "h": 4295688269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688269),
//--TRIMMABLE-BOUNDARY-START(8590655565),
    {
      "p": [
        {
          "n": "identity",
          "p": 1310721
        },
        {
          "n": "registryRights",
          "p": 786509
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 720973,
      "h": 8590655565,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590655565)
  ],
  "h": 720973
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.RegistryAuditRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}RegistryAuditRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720973)
        
        

        //--TRIMMABLE-BOUNDARY-START(131149)
        $asm.$str(`$mwr.MW.RegistryHive`, ($self) => class RegistryHive extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static ClassesRoot = -2147483648;
            static CurrentUser = -2147483647;
            static LocalMachine = -2147483646;
            static Users = -2147483645;
            static PerformanceData = -2147483644;
            static CurrentConfig = -2147483643;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ClassesRoot": 2147483648n,
                    "CurrentUser": 2147483649n,
                    "LocalMachine": 2147483650n,
                    "Users": 2147483651n,
                    "PerformanceData": 2147483652n,
                    "CurrentConfig": 2147483653n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295098445)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098445)
            
            //--TRIMMABLE-BOUNDARY-START(4295098445)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098445)
            
            static $h = 131149;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065741),
    {
      "t": 131149,
      "n": "ClassesRoot",
      "d": 131149,
      "h": 8590065741,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065741),
//--TRIMMABLE-BOUNDARY-START(17180000333),
    {
      "t": 131149,
      "n": "CurrentUser",
      "d": 131149,
      "h": 17180000333,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180000333),
//--TRIMMABLE-BOUNDARY-START(21474967629),
    {
      "t": 131149,
      "n": "LocalMachine",
      "d": 131149,
      "h": 21474967629,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474967629),
//--TRIMMABLE-BOUNDARY-START(30064902221),
    {
      "t": 131149,
      "n": "Users",
      "d": 131149,
      "h": 30064902221,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064902221),
//--TRIMMABLE-BOUNDARY-START(25769934925),
    {
      "t": 131149,
      "n": "PerformanceData",
      "d": 131149,
      "h": 25769934925,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769934925),
//--TRIMMABLE-BOUNDARY-START(12885033037),
    {
      "t": 131149,
      "n": "CurrentConfig",
      "d": 131149,
      "h": 12885033037,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885033037)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098445),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131149,
      "h": 4295098445,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098445)
  ],
  "h": 131149
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.RegistryHive`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}RegistryHive`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131149)
        
        

        //--TRIMMABLE-BOUNDARY-START(262221)
        $asm.$str(`$mwr.MW.RegistryKeyPermissionCheck`, ($self) => class RegistryKeyPermissionCheck extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Default = 0;
            static ReadSubTree = 1;
            static ReadWriteSubTree = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "ReadSubTree": 1n,
                    "ReadWriteSubTree": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295229517)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229517)
            
            //--TRIMMABLE-BOUNDARY-START(4295229517)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229517)
            
            static $h = 262221;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196813),
    {
      "t": 262221,
      "n": "Default",
      "d": 262221,
      "h": 8590196813,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196813),
//--TRIMMABLE-BOUNDARY-START(12885164109),
    {
      "t": 262221,
      "n": "ReadSubTree",
      "d": 262221,
      "h": 12885164109,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164109),
//--TRIMMABLE-BOUNDARY-START(17180131405),
    {
      "t": 262221,
      "n": "ReadWriteSubTree",
      "d": 262221,
      "h": 17180131405,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180131405)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229517),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262221,
      "h": 4295229517,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229517)
  ],
  "h": 262221
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.RegistryKeyPermissionCheck`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}RegistryKeyPermissionCheck`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262221)
        
        

        //--TRIMMABLE-BOUNDARY-START(327757)
        $asm.$str(`$mwr.MW.RegistryOptions`, ($self) => class RegistryOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Volatile = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Volatile": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295295053)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295053)
            
            //--TRIMMABLE-BOUNDARY-START(4295295053)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295053)
            
            static $h = 327757;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590262349),
    {
      "t": 327757,
      "n": "None",
      "d": 327757,
      "h": 8590262349,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262349),
//--TRIMMABLE-BOUNDARY-START(12885229645),
    {
      "t": 327757,
      "n": "Volatile",
      "d": 327757,
      "h": 12885229645,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229645)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295053),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327757,
      "h": 4295295053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295053)
  ],
  "h": 327757,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.RegistryOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}RegistryOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327757)
        
        

        //--TRIMMABLE-BOUNDARY-START(393293)
        $asm.$str(`$mwr.MW.RegistryValueKind`, ($self) => class RegistryValueKind extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = -1;
            static Unknown = 0;
            static String = 1;
            static ExpandString = 2;
            static Binary = 3;
            static DWord = 4;
            static MultiString = 7;
            static QWord = 11;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 4294967295n,
                    "Unknown": 0n,
                    "String": 1n,
                    "ExpandString": 2n,
                    "Binary": 3n,
                    "DWord": 4n,
                    "MultiString": 7n,
                    "QWord": 11n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295360589)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360589)
            
            //--TRIMMABLE-BOUNDARY-START(4295360589)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360589)
            
            static $h = 393293;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770197069),
    {
      "t": 393293,
      "n": "None",
      "d": 393293,
      "h": 25770197069,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770197069),
//--TRIMMABLE-BOUNDARY-START(38655098957),
    {
      "t": 393293,
      "n": "Unknown",
      "d": 393293,
      "h": 38655098957,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655098957),
//--TRIMMABLE-BOUNDARY-START(34360131661),
    {
      "t": 393293,
      "n": "String",
      "d": 393293,
      "h": 34360131661,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360131661),
//--TRIMMABLE-BOUNDARY-START(17180262477),
    {
      "t": 393293,
      "n": "ExpandString",
      "d": 393293,
      "h": 17180262477,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262477),
//--TRIMMABLE-BOUNDARY-START(8590327885),
    {
      "t": 393293,
      "n": "Binary",
      "d": 393293,
      "h": 8590327885,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327885),
//--TRIMMABLE-BOUNDARY-START(12885295181),
    {
      "t": 393293,
      "n": "DWord",
      "d": 393293,
      "h": 12885295181,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295181),
//--TRIMMABLE-BOUNDARY-START(21475229773),
    {
      "t": 393293,
      "n": "MultiString",
      "d": 393293,
      "h": 21475229773,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229773),
//--TRIMMABLE-BOUNDARY-START(30065164365),
    {
      "t": 393293,
      "n": "QWord",
      "d": 393293,
      "h": 30065164365,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065164365)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360589),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393293,
      "h": 4295360589,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360589)
  ],
  "h": 393293
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.RegistryValueKind`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}RegistryValueKind`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393293)
        
        

        //--TRIMMABLE-BOUNDARY-START(458829)
        $asm.$str(`$mwr.MW.RegistryValueOptions`, ($self) => class RegistryValueOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static DoNotExpandEnvironmentNames = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "DoNotExpandEnvironmentNames": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295426125)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426125)
            
            //--TRIMMABLE-BOUNDARY-START(4295426125)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426125)
            
            static $h = 458829;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885360717),
    {
      "t": 458829,
      "n": "None",
      "d": 458829,
      "h": 12885360717,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360717),
//--TRIMMABLE-BOUNDARY-START(8590393421),
    {
      "t": 458829,
      "n": "DoNotExpandEnvironmentNames",
      "d": 458829,
      "h": 8590393421,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393421)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426125),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458829,
      "h": 4295426125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426125)
  ],
  "h": 458829,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.RegistryValueOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}RegistryValueOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458829)
        
        

        //--TRIMMABLE-BOUNDARY-START(524365)
        $asm.$str(`$mwr.MW.RegistryView`, ($self) => class RegistryView extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Default = 0;
            static Registry64 = 256;
            static Registry32 = 512;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Registry64": 256n,
                    "Registry32": 512n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295491661)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491661)
            
            //--TRIMMABLE-BOUNDARY-START(4295491661)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491661)
            
            static $h = 524365;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590458957),
    {
      "t": 524365,
      "n": "Default",
      "d": 524365,
      "h": 8590458957,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458957),
//--TRIMMABLE-BOUNDARY-START(17180393549),
    {
      "t": 524365,
      "n": "Registry64",
      "d": 524365,
      "h": 17180393549,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393549),
//--TRIMMABLE-BOUNDARY-START(12885426253),
    {
      "t": 524365,
      "n": "Registry32",
      "d": 524365,
      "h": 12885426253,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426253)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491661),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524365,
      "h": 4295491661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491661)
  ],
  "h": 524365
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.RegistryView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}RegistryView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524365)
        
        

        //--TRIMMABLE-BOUNDARY-START(786509)
        $asm.$str(`$mwr.SSA.RegistryRights`, ($self) => class RegistryRights extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static QueryValues = 1;
            static SetValue = 2;
            static CreateSubKey = 4;
            static EnumerateSubKeys = 8;
            static Notify = 16;
            static CreateLink = 32;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static WriteKey = 131078;
            static ExecuteKey = 131097;
            static ReadKey = 131097;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static FullControl = 983103;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "QueryValues": 1n,
                    "SetValue": 2n,
                    "CreateSubKey": 4n,
                    "EnumerateSubKeys": 8n,
                    "Notify": 16n,
                    "CreateLink": 32n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "WriteKey": 131078n,
                    "ExecuteKey": 131097n,
                    "ReadKey": 131097n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "FullControl": 983103n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295753805)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753805)
            
            //--TRIMMABLE-BOUNDARY-START(4295753805)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295753805)
            
            static $h = 786509;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950459469),
    {
      "t": 786509,
      "n": "QueryValues",
      "d": 786509,
      "h": 42950459469,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950459469),
//--TRIMMABLE-BOUNDARY-START(55835361357),
    {
      "t": 786509,
      "n": "SetValue",
      "d": 786509,
      "h": 55835361357,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835361357),
//--TRIMMABLE-BOUNDARY-START(17180655693),
    {
      "t": 786509,
      "n": "CreateSubKey",
      "d": 786509,
      "h": 17180655693,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180655693),
//--TRIMMABLE-BOUNDARY-START(25770590285),
    {
      "t": 786509,
      "n": "EnumerateSubKeys",
      "d": 786509,
      "h": 25770590285,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770590285),
//--TRIMMABLE-BOUNDARY-START(38655492173),
    {
      "t": 786509,
      "n": "Notify",
      "d": 786509,
      "h": 38655492173,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655492173),
//--TRIMMABLE-BOUNDARY-START(12885688397),
    {
      "t": 786509,
      "n": "CreateLink",
      "d": 786509,
      "h": 12885688397,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688397),
//--TRIMMABLE-BOUNDARY-START(21475622989),
    {
      "t": 786509,
      "n": "Delete",
      "d": 786509,
      "h": 21475622989,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475622989),
//--TRIMMABLE-BOUNDARY-START(51540394061),
    {
      "t": 786509,
      "n": "ReadPermissions",
      "d": 786509,
      "h": 51540394061,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540394061),
//--TRIMMABLE-BOUNDARY-START(64425295949),
    {
      "t": 786509,
      "n": "WriteKey",
      "d": 786509,
      "h": 64425295949,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425295949),
//--TRIMMABLE-BOUNDARY-START(30065557581),
    {
      "t": 786509,
      "n": "ExecuteKey",
      "d": 786509,
      "h": 30065557581,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065557581),
//--TRIMMABLE-BOUNDARY-START(47245426765),
    {
      "t": 786509,
      "n": "ReadKey",
      "d": 786509,
      "h": 47245426765,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245426765),
//--TRIMMABLE-BOUNDARY-START(8590721101),
    {
      "t": 786509,
      "n": "ChangePermissions",
      "d": 786509,
      "h": 8590721101,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721101),
//--TRIMMABLE-BOUNDARY-START(60130328653),
    {
      "t": 786509,
      "n": "TakeOwnership",
      "d": 786509,
      "h": 60130328653,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130328653),
//--TRIMMABLE-BOUNDARY-START(34360524877),
    {
      "t": 786509,
      "n": "FullControl",
      "d": 786509,
      "h": 34360524877,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360524877)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753805),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786509,
      "h": 4295753805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753805)
  ],
  "h": 786509,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.RegistryRights`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}RegistryRights`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786509)
        
        

        //--TRIMMABLE-BOUNDARY-START(852045)
        $asm.$cls(`$mwr.SSA.RegistrySecurity`, ($self) => class RegistrySecurity extends $.$ssa.SSA.NativeObjectSecurity
        {
            //--TRIMMABLE-BOUNDARY-START(4295819341)
            $ctor$11()
            {
                super.$ctor$10(false, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295819341);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295819341)
            
            //--TRIMMABLE-BOUNDARY-START(8590786637)
            /*System.Type */ get AccessRightType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950525005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590786637)
            
            //--TRIMMABLE-BOUNDARY-START(17180721229)
            /*System.Type */ get AccessRuleType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540459597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180721229)
            
            //--TRIMMABLE-BOUNDARY-START(34360590413)
            /*System.Type */ get AuditRuleType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360590413)
            
            //--TRIMMABLE-BOUNDARY-START(12885753933)
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885753933)
            
            //--TRIMMABLE-BOUNDARY-START(21475688525)
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475688525)
            
            //--TRIMMABLE-BOUNDARY-START(25770655821)
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770655821)
            
            //--TRIMMABLE-BOUNDARY-START(30065623117)
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065623117)
            
            //--TRIMMABLE-BOUNDARY-START(64425361485)
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425361485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425361485)
            
            //--TRIMMABLE-BOUNDARY-START(68720328781)
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68720328781)
            
            //--TRIMMABLE-BOUNDARY-START(73015296077)
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015296077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73015296077)
            
            //--TRIMMABLE-BOUNDARY-START(77310263373)
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77310263373)
            
            //--TRIMMABLE-BOUNDARY-START(81605230669)
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(81605230669)
            
            //--TRIMMABLE-BOUNDARY-START(85900197965)
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900197965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(85900197965)
            
            //--TRIMMABLE-BOUNDARY-START(90195165261)
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(90195165261)
            
            //--TRIMMABLE-BOUNDARY-START(94490132557)
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(94490132557)
            
            //--TRIMMABLE-BOUNDARY-START(98785099853)
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785099853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(98785099853)
            
            //--TRIMMABLE-BOUNDARY-START(4295819341)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$11();
            }
            //--TRIMMABLE-BOUNDARY-END(4295819341)
            
            static $h = 852045;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.NativeObjectSecurity; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590786637),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950525005,
        "f": 50364417
      },
      "n": "AccessRightType",
      "d": 852045,
      "h": 8590786637,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590786637),
//--TRIMMABLE-BOUNDARY-START(17180721229),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540459597,
        "f": 50364417
      },
      "n": "AccessRuleType",
      "d": 852045,
      "h": 17180721229,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180721229),
//--TRIMMABLE-BOUNDARY-START(34360590413),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130394189,
        "f": 50364417
      },
      "n": "AuditRuleType",
      "d": 852045,
      "h": 34360590413,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360590413)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753933),
    {
      "r": 327763,
      "p": [
        {
          "n": "identityReference",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": "AccessRuleFactory",
      "d": 852045,
      "h": 12885753933,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885753933),
//--TRIMMABLE-BOUNDARY-START(21475688525),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 655437
        }
      ],
      "n": "AddAccessRule",
      "o": "@$1",
      "d": 852045,
      "h": 21475688525,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688525),
//--TRIMMABLE-BOUNDARY-START(25770655821),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 720973
        }
      ],
      "n": "AddAuditRule",
      "o": "@$1",
      "d": 852045,
      "h": 25770655821,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770655821),
//--TRIMMABLE-BOUNDARY-START(30065623117),
    {
      "r": 786515,
      "p": [
        {
          "n": "identityReference",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": "AuditRuleFactory",
      "d": 852045,
      "h": 30065623117,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065623117),
//--TRIMMABLE-BOUNDARY-START(64425361485),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": 655437
        }
      ],
      "n": "RemoveAccessRule",
      "o": "@$1",
      "d": 852045,
      "h": 64425361485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425361485),
//--TRIMMABLE-BOUNDARY-START(68720328781),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 655437
        }
      ],
      "n": "RemoveAccessRuleAll",
      "o": "@$1",
      "d": 852045,
      "h": 68720328781,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720328781),
//--TRIMMABLE-BOUNDARY-START(73015296077),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 655437
        }
      ],
      "n": "RemoveAccessRuleSpecific",
      "o": "@$1",
      "d": 852045,
      "h": 73015296077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015296077),
//--TRIMMABLE-BOUNDARY-START(77310263373),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": 720973
        }
      ],
      "n": "RemoveAuditRule",
      "o": "@$1",
      "d": 852045,
      "h": 77310263373,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310263373),
//--TRIMMABLE-BOUNDARY-START(81605230669),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 720973
        }
      ],
      "n": "RemoveAuditRuleAll",
      "o": "@$1",
      "d": 852045,
      "h": 81605230669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605230669),
//--TRIMMABLE-BOUNDARY-START(85900197965),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 720973
        }
      ],
      "n": "RemoveAuditRuleSpecific",
      "o": "@$1",
      "d": 852045,
      "h": 85900197965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900197965),
//--TRIMMABLE-BOUNDARY-START(90195165261),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 655437
        }
      ],
      "n": "ResetAccessRule",
      "o": "@$1",
      "d": 852045,
      "h": 90195165261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195165261),
//--TRIMMABLE-BOUNDARY-START(94490132557),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 655437
        }
      ],
      "n": "SetAccessRule",
      "o": "@$1",
      "d": 852045,
      "h": 94490132557,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490132557),
//--TRIMMABLE-BOUNDARY-START(98785099853),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 720973
        }
      ],
      "n": "SetAuditRule",
      "o": "@$1",
      "d": 852045,
      "h": 98785099853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785099853)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819341),
    {
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 852045,
      "h": 4295819341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819341)
  ],
  "h": 852045
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.RegistrySecurity`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}RegistrySecurity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852045)
        
        

        //--TRIMMABLE-BOUNDARY-START(589901)
        $asm.$cls(`$mwr.MWS.SafeRegistryHandle`, ($self) => class SafeRegistryHandle extends $.$$.MWS.SafeHandleZeroOrMinusOneIsInvalid
        {
            //--TRIMMABLE-BOUNDARY-START(4295557197)
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295557197);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557197)
            
            //--TRIMMABLE-BOUNDARY-START(8590524493)
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590524493);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524493)
            
            //--TRIMMABLE-BOUNDARY-START(12885491789)
            /*bool */ ReleaseHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885491789)
            
            //--TRIMMABLE-BOUNDARY-START(4295557197)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557197)
            
            static $h = 589901;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.MWS.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885491789),
    {
      "r": 262145,
      "n": "ReleaseHandle",
      "d": 589901,
      "h": 12885491789,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885491789)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557197),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 589901,
      "h": 4295557197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557197),
//--TRIMMABLE-BOUNDARY-START(8590524493),
    {
      "p": [
        {
          "n": "preexistingHandle",
          "p": 786433
        },
        {
          "n": "ownsHandle",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 589901,
      "h": 8590524493,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590524493)
  ],
  "h": 589901
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.SafeHandles.SafeRegistryHandle`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}SafeHandles${separator}SafeRegistryHandle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589901)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl"));
})();
//--TRIMMABLE-BOUNDARY-END(77)
