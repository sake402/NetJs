
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw, $ssa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Win32.Registry", 
    {"h":33,"f":"Microsoft.Win32.Registry","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Win32.Registry","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Win32.Registry","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mwr.Microsoft.Win32.Registry", ($self) => class Registry
        {
            /*Microsoft.Win32.RegistryKey*/ static ClassesRoot = null;
            /*Microsoft.Win32.RegistryKey*/ static CurrentConfig = null;
            /*Microsoft.Win32.RegistryKey*/ static CurrentUser = null;
            /*Microsoft.Win32.RegistryKey*/ static LocalMachine = null;
            /*Microsoft.Win32.RegistryKey*/ static PerformanceData = null;
            /*Microsoft.Win32.RegistryKey*/ static Users = null;
            static /*object? */ GetValue(/*string*/ keyName, /*string?*/ valueName, /*object?*/ defaultValue)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ SetValue$1(/*string*/ keyName, /*string?*/ valueName, /*object*/ value)
            {
            }
            static /*void */ SetValue(/*string*/ keyName, /*string?*/ valueName, /*object*/ value, /*Microsoft.Win32.RegistryValueKind*/ valueKind)
            {
            }
            static $h = 65569;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"keyName","p":1310721},{"n":"valueName","p":1310721},{"n":"defaultValue","p":131073}],"n":"GetValue","d":65569,"h":30064836641,"f":16777249},{"r":65537,"p":[{"n":"keyName","p":1310721},{"n":"valueName","p":1310721},{"n":"value","p":131073}],"n":"SetValue","o":"@$1","d":65569,"h":34359803937,"f":16777249},{"r":65537,"p":[{"n":"keyName","p":1310721},{"n":"valueName","p":1310721},{"n":"value","p":131073},{"n":"valueKind","p":393249}],"n":"SetValue","d":65569,"h":38654771233,"f":16777249}],"l":[{"t":196641,"n":"ClassesRoot","d":65569,"h":4295032865,"f":4194337},{"t":196641,"n":"CurrentConfig","d":65569,"h":8590000161,"f":4194337},{"t":196641,"n":"CurrentUser","d":65569,"h":12884967457,"f":4194337},{"t":196641,"n":"LocalMachine","d":65569,"h":17179934753,"f":4194337},{"t":196641,"n":"PerformanceData","d":65569,"h":21474902049,"f":4194337},{"t":196641,"n":"Users","d":65569,"h":25769869345,"f":4194337}],"h":65569}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Win32.Registry`; }
        });
        
        $asm.$cls("$mwr.Microsoft.Win32.RegistryKey", ($self) => class RegistryKey extends $.$$.System.MarshalByRefObject
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeRegistryHandle */ get Handle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SubKeyCount()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ValueCount()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryView */ get View()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$6(/*string*/ subkey)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$5(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$3(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*Microsoft.Win32.RegistryOptions*/ registryOptions)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$2(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*Microsoft.Win32.RegistryOptions*/ registryOptions, /*System.Security.AccessControl.RegistrySecurity?*/ registrySecurity)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$4(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*System.Security.AccessControl.RegistrySecurity?*/ registrySecurity)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$1(/*string*/ subkey, /*bool*/ writable)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey(/*string*/ subkey, /*bool*/ writable, /*Microsoft.Win32.RegistryOptions*/ options)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ DeleteSubKey$1(/*string*/ subkey)
            {
            }
            /*void */ DeleteSubKey(/*string*/ subkey, /*bool*/ throwOnMissingSubKey)
            {
            }
            /*void */ DeleteSubKeyTree$1(/*string*/ subkey)
            {
            }
            /*void */ DeleteSubKeyTree(/*string*/ subkey, /*bool*/ throwOnMissingSubKey)
            {
            }
            /*void */ DeleteValue$1(/*string*/ name)
            {
            }
            /*void */ DeleteValue(/*string*/ name, /*bool*/ throwOnMissingValue)
            {
            }
            /*void */ Dispose()
            {
            }
            /*void */ Flush()
            {
            }
            static /*Microsoft.Win32.RegistryKey */ FromHandle$1(/*Microsoft.Win32.SafeHandles.SafeRegistryHandle*/ handle)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Microsoft.Win32.RegistryKey */ FromHandle(/*Microsoft.Win32.SafeHandles.SafeRegistryHandle*/ handle, /*Microsoft.Win32.RegistryView*/ view)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RegistrySecurity */ GetAccessControl()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RegistrySecurity */ GetAccessControl$1(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ GetSubKeyNames()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetValue$2(/*string?*/ name)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetValue$1(/*string?*/ name, /*object?*/ defaultValue)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetValue(/*string?*/ name, /*object?*/ defaultValue, /*Microsoft.Win32.RegistryValueOptions*/ options)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryValueKind */ GetValueKind(/*string?*/ name)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ GetValueNames()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Microsoft.Win32.RegistryKey */ OpenBaseKey(/*Microsoft.Win32.RegistryHive*/ hKey, /*Microsoft.Win32.RegistryView*/ view)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Microsoft.Win32.RegistryKey */ OpenRemoteBaseKey$1(/*Microsoft.Win32.RegistryHive*/ hKey, /*string*/ machineName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Microsoft.Win32.RegistryKey */ OpenRemoteBaseKey(/*Microsoft.Win32.RegistryHive*/ hKey, /*string*/ machineName, /*Microsoft.Win32.RegistryView*/ view)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$4(/*string*/ name)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$2(/*string*/ name, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$1(/*string*/ name, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*System.Security.AccessControl.RegistryRights*/ rights)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey(/*string*/ name, /*bool*/ writable)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$3(/*string*/ name, /*System.Security.AccessControl.RegistryRights*/ rights)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetAccessControl(/*System.Security.AccessControl.RegistrySecurity*/ registrySecurity)
            {
            }
            /*void */ SetValue$1(/*string?*/ name, /*object*/ value)
            {
            }
            /*void */ SetValue(/*string?*/ name, /*object*/ value, /*Microsoft.Win32.RegistryValueKind*/ valueKind)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mwr.Microsoft.Win32.RegistryKey.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 196641;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":65011713,"p":[{"p":589857,"g":{"r":0,"d":0,"h":12885098529,"f":50331649},"n":"Handle","d":196641,"h":8590131233,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":21475033121,"f":50331649},"n":"Name","d":196641,"h":17180065825,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30064967713,"f":50331649},"n":"SubKeyCount","d":196641,"h":25770000417,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":38654902305,"f":50331649},"n":"ValueCount","d":196641,"h":34359935009,"f":2097153},{"p":524321,"g":{"r":0,"d":0,"h":47244836897,"f":50331649},"n":"View","d":196641,"h":42949869601,"f":2097153}],"m":[{"r":65537,"n":"Close","d":196641,"h":51539804193,"f":16777217},{"r":196641,"p":[{"n":"subkey","p":1310721}],"n":"CreateSubKey","o":"@$6","d":196641,"h":55834771489,"f":16777217},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"permissionCheck","p":262177}],"n":"CreateSubKey","o":"@$5","d":196641,"h":60129738785,"f":16777217},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"permissionCheck","p":262177},{"n":"registryOptions","p":327713}],"n":"CreateSubKey","o":"@$3","d":196641,"h":64424706081,"f":16777217},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"permissionCheck","p":262177},{"n":"registryOptions","p":327713},{"n":"registrySecurity","p":852001}],"n":"CreateSubKey","o":"@$2","d":196641,"h":68719673377,"f":16777217},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"permissionCheck","p":262177},{"n":"registrySecurity","p":852001}],"n":"CreateSubKey","o":"@$4","d":196641,"h":73014640673,"f":16777217},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"writable","p":262145}],"n":"CreateSubKey","o":"@$1","d":196641,"h":77309607969,"f":16777217},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"writable","p":262145},{"n":"options","p":327713}],"n":"CreateSubKey","d":196641,"h":81604575265,"f":16777217},{"r":65537,"p":[{"n":"subkey","p":1310721}],"n":"DeleteSubKey","o":"@$1","d":196641,"h":85899542561,"f":16777217},{"r":65537,"p":[{"n":"subkey","p":1310721},{"n":"throwOnMissingSubKey","p":262145}],"n":"DeleteSubKey","d":196641,"h":90194509857,"f":16777217},{"r":65537,"p":[{"n":"subkey","p":1310721}],"n":"DeleteSubKeyTree","o":"@$1","d":196641,"h":94489477153,"f":16777217},{"r":65537,"p":[{"n":"subkey","p":1310721},{"n":"throwOnMissingSubKey","p":262145}],"n":"DeleteSubKeyTree","d":196641,"h":98784444449,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"DeleteValue","o":"@$1","d":196641,"h":103079411745,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"throwOnMissingValue","p":262145}],"n":"DeleteValue","d":196641,"h":107374379041,"f":16777217},{"r":65537,"n":"Dispose","d":196641,"h":111669346337,"f":16777217},{"r":65537,"n":"Flush","d":196641,"h":115964313633,"f":16777217},{"r":196641,"p":[{"n":"handle","p":589857}],"n":"FromHandle","o":"@$1","d":196641,"h":120259280929,"f":16777249},{"r":196641,"p":[{"n":"handle","p":589857},{"n":"view","p":524321}],"n":"FromHandle","d":196641,"h":124554248225,"f":16777249},{"r":852001,"n":"GetAccessControl","d":196641,"h":128849215521,"f":16777217},{"r":852001,"p":[{"n":"includeSections","p":252210}],"n":"GetAccessControl","o":"@$1","d":196641,"h":133144182817,"f":16777217},{"r":$.$typeArray($.$$.System.String).$h,"n":"GetSubKeyNames","d":196641,"h":137439150113,"f":16777217},{"r":131073,"p":[{"n":"name","p":1310721}],"n":"GetValue","o":"@$2","d":196641,"h":141734117409,"f":16777217},{"r":131073,"p":[{"n":"name","p":1310721},{"n":"defaultValue","p":131073}],"n":"GetValue","o":"@$1","d":196641,"h":146029084705,"f":16777217},{"r":131073,"p":[{"n":"name","p":1310721},{"n":"defaultValue","p":131073},{"n":"options","p":458785}],"n":"GetValue","d":196641,"h":150324052001,"f":16777217},{"r":393249,"p":[{"n":"name","p":1310721}],"n":"GetValueKind","d":196641,"h":154619019297,"f":16777217},{"r":$.$typeArray($.$$.System.String).$h,"n":"GetValueNames","d":196641,"h":158913986593,"f":16777217},{"r":196641,"p":[{"n":"hKey","p":131105},{"n":"view","p":524321}],"n":"OpenBaseKey","d":196641,"h":163208953889,"f":16777249},{"r":196641,"p":[{"n":"hKey","p":131105},{"n":"machineName","p":1310721}],"n":"OpenRemoteBaseKey","o":"@$1","d":196641,"h":167503921185,"f":16777249},{"r":196641,"p":[{"n":"hKey","p":131105},{"n":"machineName","p":1310721},{"n":"view","p":524321}],"n":"OpenRemoteBaseKey","d":196641,"h":171798888481,"f":16777249},{"r":196641,"p":[{"n":"name","p":1310721}],"n":"OpenSubKey","o":"@$4","d":196641,"h":176093855777,"f":16777217},{"r":196641,"p":[{"n":"name","p":1310721},{"n":"permissionCheck","p":262177}],"n":"OpenSubKey","o":"@$2","d":196641,"h":180388823073,"f":16777217},{"r":196641,"p":[{"n":"name","p":1310721},{"n":"permissionCheck","p":262177},{"n":"rights","p":786465}],"n":"OpenSubKey","o":"@$1","d":196641,"h":184683790369,"f":16777217},{"r":196641,"p":[{"n":"name","p":1310721},{"n":"writable","p":262145}],"n":"OpenSubKey","d":196641,"h":188978757665,"f":16777217},{"r":196641,"p":[{"n":"name","p":1310721},{"n":"rights","p":786465}],"n":"OpenSubKey","o":"@$3","d":196641,"h":193273724961,"f":16777217},{"r":65537,"p":[{"n":"registrySecurity","p":852001}],"n":"SetAccessControl","d":196641,"h":197568692257,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"SetValue","o":"@$1","d":196641,"h":201863659553,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073},{"n":"valueKind","p":393249}],"n":"SetValue","d":196641,"h":206158626849,"f":16777217},{"r":1310721,"n":"ToString","d":196641,"h":210453594145,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$2","d":196641,"h":4295163937,"f":16777224}],"i":[57540609],"h":196641}; }
            static get $b() { return $.$$.System.MarshalByRefObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryKey`; }
        });
        
        $asm.$cls("$mwr.System.Security.AccessControl.RegistryAccessRule", ($self) => class RegistryAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$5(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.RegistryRights */ get RegistryRights()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 655393;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":383282,"p":[{"p":786465,"g":{"r":0,"d":0,"h":25770459169,"f":50331649},"n":"RegistryRights","d":655393,"h":21475491873,"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"registryRights","p":786465},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$5","d":655393,"h":4295622689,"f":16777217},{"p":[{"n":"identity","p":248526},{"n":"registryRights","p":786465},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$6","d":655393,"h":8590589985,"f":16777217},{"p":[{"n":"identity","p":1310721},{"n":"registryRights","p":786465},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$3","d":655393,"h":12885557281,"f":16777217},{"p":[{"n":"identity","p":1310721},{"n":"registryRights","p":786465},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$4","d":655393,"h":17180524577,"f":16777217}],"h":655393}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.RegistryAccessRule`; }
        });
        
        $asm.$cls("$mwr.System.Security.AccessControl.RegistryAuditRule", ($self) => class RegistryAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.RegistryRights */ get RegistryRights()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 720929;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":842034,"p":[{"p":786465,"g":{"r":0,"d":0,"h":17180590113,"f":50331649},"n":"RegistryRights","d":720929,"h":12885622817,"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"registryRights","p":786465},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"flags","p":776498}],"n":".ctor","o":"$ctor$4","d":720929,"h":4295688225,"f":16777217},{"p":[{"n":"identity","p":1310721},{"n":"registryRights","p":786465},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"flags","p":776498}],"n":".ctor","o":"$ctor$3","d":720929,"h":8590655521,"f":16777217}],"h":720929}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.RegistryAuditRule`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryHive", ($self) => class RegistryHive extends $.$$.System.Enum
        {
            static ClassesRoot = -2147483648;
            static CurrentUser = -2147483647;
            static LocalMachine = -2147483646;
            static Users = -2147483645;
            static PerformanceData = -2147483644;
            static CurrentConfig = -2147483643;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ClassesRoot": -2147483648n,
                    "CurrentUser": -2147483647n,
                    "LocalMachine": -2147483646n,
                    "Users": -2147483645n,
                    "PerformanceData": -2147483644n,
                    "CurrentConfig": -2147483643n
                };
            }
            static $h = 131105;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":131105,"n":"ClassesRoot","d":131105,"h":4295098401,"f":4194337},{"t":131105,"n":"CurrentUser","d":131105,"h":8590065697,"f":4194337},{"t":131105,"n":"LocalMachine","d":131105,"h":12885032993,"f":4194337},{"t":131105,"n":"Users","d":131105,"h":17180000289,"f":4194337},{"t":131105,"n":"PerformanceData","d":131105,"h":21474967585,"f":4194337},{"t":131105,"n":"CurrentConfig","d":131105,"h":25769934881,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":131105,"h":30064902177,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":131105}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryHive`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryKeyPermissionCheck", ($self) => class RegistryKeyPermissionCheck extends $.$$.System.Enum
        {
            static Default = 0;
            static ReadSubTree = 1;
            static ReadWriteSubTree = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "ReadSubTree": 1n,
                    "ReadWriteSubTree": 2n
                };
            }
            static $h = 262177;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":262177,"n":"Default","d":262177,"h":4295229473,"f":4194337},{"t":262177,"n":"ReadSubTree","d":262177,"h":8590196769,"f":4194337},{"t":262177,"n":"ReadWriteSubTree","d":262177,"h":12885164065,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":262177,"h":17180131361,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":262177}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryKeyPermissionCheck`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryOptions", ($self) => class RegistryOptions extends $.$$.System.Enum
        {
            static None = 0;
            static Volatile = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Volatile": 1n
                };
            }
            static $h = 327713;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":327713,"n":"None","d":327713,"h":4295295009,"f":4194337},{"t":327713,"n":"Volatile","d":327713,"h":8590262305,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":327713,"h":12885229601,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":327713,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryOptions`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryValueKind", ($self) => class RegistryValueKind extends $.$$.System.Enum
        {
            static None = -1;
            static Unknown = 0;
            static String = 1;
            static ExpandString = 2;
            static Binary = 3;
            static DWord = 4;
            static MultiString = 7;
            static QWord = 11;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": -1n,
                    "Unknown": 0n,
                    "String": 1n,
                    "ExpandString": 2n,
                    "Binary": 3n,
                    "DWord": 4n,
                    "MultiString": 7n,
                    "QWord": 11n
                };
            }
            static $h = 393249;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":393249,"n":"None","d":393249,"h":4295360545,"f":4194337},{"t":393249,"n":"Unknown","d":393249,"h":8590327841,"f":4194337},{"t":393249,"n":"String","d":393249,"h":12885295137,"f":4194337},{"t":393249,"n":"ExpandString","d":393249,"h":17180262433,"f":4194337},{"t":393249,"n":"Binary","d":393249,"h":21475229729,"f":4194337},{"t":393249,"n":"DWord","d":393249,"h":25770197025,"f":4194337},{"t":393249,"n":"MultiString","d":393249,"h":30065164321,"f":4194337},{"t":393249,"n":"QWord","d":393249,"h":34360131617,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":393249,"h":38655098913,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":393249}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryValueKind`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryValueOptions", ($self) => class RegistryValueOptions extends $.$$.System.Enum
        {
            static None = 0;
            static DoNotExpandEnvironmentNames = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DoNotExpandEnvironmentNames": 1n
                };
            }
            static $h = 458785;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":458785,"n":"None","d":458785,"h":4295426081,"f":4194337},{"t":458785,"n":"DoNotExpandEnvironmentNames","d":458785,"h":8590393377,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":458785,"h":12885360673,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":458785,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryValueOptions`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryView", ($self) => class RegistryView extends $.$$.System.Enum
        {
            static Default = 0;
            static Registry64 = 256;
            static Registry32 = 512;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Registry64": 256n,
                    "Registry32": 512n
                };
            }
            static $h = 524321;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":524321,"n":"Default","d":524321,"h":4295491617,"f":4194337},{"t":524321,"n":"Registry64","d":524321,"h":8590458913,"f":4194337},{"t":524321,"n":"Registry32","d":524321,"h":12885426209,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":524321,"h":17180393505,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":524321}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryView`; }
        });
        
        $asm.$str("$mwr.System.Security.AccessControl.RegistryRights", ($self) => class RegistryRights extends $.$$.System.Enum
        {
            static QueryValues = 1;
            static SetValue = 2;
            static CreateSubKey = 4;
            static EnumerateSubKeys = 8;
            static Notify = 16;
            static CreateLink = 32;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static WriteKey = 131078;
            static ExecuteKey = 131097;
            static ReadKey = 131097;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static FullControl = 983103;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "QueryValues": 1n,
                    "SetValue": 2n,
                    "CreateSubKey": 4n,
                    "EnumerateSubKeys": 8n,
                    "Notify": 16n,
                    "CreateLink": 32n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "WriteKey": 131078n,
                    "ExecuteKey": 131097n,
                    "ReadKey": 131097n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "FullControl": 983103n
                };
            }
            static $h = 786465;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":786465,"n":"QueryValues","d":786465,"h":4295753761,"f":4194337},{"t":786465,"n":"SetValue","d":786465,"h":8590721057,"f":4194337},{"t":786465,"n":"CreateSubKey","d":786465,"h":12885688353,"f":4194337},{"t":786465,"n":"EnumerateSubKeys","d":786465,"h":17180655649,"f":4194337},{"t":786465,"n":"Notify","d":786465,"h":21475622945,"f":4194337},{"t":786465,"n":"CreateLink","d":786465,"h":25770590241,"f":4194337},{"t":786465,"n":"Delete","d":786465,"h":30065557537,"f":4194337},{"t":786465,"n":"ReadPermissions","d":786465,"h":34360524833,"f":4194337},{"t":786465,"n":"WriteKey","d":786465,"h":38655492129,"f":4194337},{"t":786465,"n":"ExecuteKey","d":786465,"h":42950459425,"f":4194337},{"t":786465,"n":"ReadKey","d":786465,"h":47245426721,"f":4194337},{"t":786465,"n":"ChangePermissions","d":786465,"h":51540394017,"f":4194337},{"t":786465,"n":"TakeOwnership","d":786465,"h":55835361313,"f":4194337},{"t":786465,"n":"FullControl","d":786465,"h":60130328609,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":786465,"h":64425295905,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":786465,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.RegistryRights`; }
        });
        
        $asm.$cls("$mwr.System.Security.AccessControl.RegistrySecurity", ($self) => class RegistrySecurity extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$11()
            {
                super.$ctor$10(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
            }
            static $h = 852001;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2021682,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":12885753889,"f":50364417},"n":"AccessRightType","d":852001,"h":8590786593,"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":21475688481,"f":50364417},"n":"AccessRuleType","d":852001,"h":17180721185,"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":30065623073,"f":50364417},"n":"AuditRuleType","d":852001,"h":25770655777,"f":2129921}],"m":[{"r":383282,"p":[{"n":"identityReference","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"type","p":317746}],"n":"AccessRuleFactory","d":852001,"h":34360590369,"f":16809985},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"AddAccessRule","o":"@$1","d":852001,"h":38655557665,"f":16777217},{"r":65537,"p":[{"n":"rule","p":720929}],"n":"AddAuditRule","o":"@$1","d":852001,"h":42950524961,"f":16777217},{"r":842034,"p":[{"n":"identityReference","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"flags","p":776498}],"n":"AuditRuleFactory","d":852001,"h":47245492257,"f":16809985},{"r":262145,"p":[{"n":"rule","p":655393}],"n":"RemoveAccessRule","o":"@$1","d":852001,"h":51540459553,"f":16777217},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"RemoveAccessRuleAll","o":"@$1","d":852001,"h":55835426849,"f":16777217},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":852001,"h":60130394145,"f":16777217},{"r":262145,"p":[{"n":"rule","p":720929}],"n":"RemoveAuditRule","o":"@$1","d":852001,"h":64425361441,"f":16777217},{"r":65537,"p":[{"n":"rule","p":720929}],"n":"RemoveAuditRuleAll","o":"@$1","d":852001,"h":68720328737,"f":16777217},{"r":65537,"p":[{"n":"rule","p":720929}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":852001,"h":73015296033,"f":16777217},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"ResetAccessRule","o":"@$1","d":852001,"h":77310263329,"f":16777217},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"SetAccessRule","o":"@$1","d":852001,"h":81605230625,"f":16777217},{"r":65537,"p":[{"n":"rule","p":720929}],"n":"SetAuditRule","o":"@$1","d":852001,"h":85900197921,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$11","d":852001,"h":4295819297,"f":16777217}],"h":852001}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.RegistrySecurity`; }
        });
        
        $asm.$cls("$mwr.Microsoft.Win32.SafeHandles.SafeRegistryHandle", ($self) => class SafeRegistryHandle extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 589857;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"m":[{"r":262145,"n":"ReleaseHandle","d":589857,"h":12885491745,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$4","d":589857,"h":4295557153,"f":16777217},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":589857,"h":8590524449,"f":16777217}],"i":[57540609],"h":589857}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeRegistryHandle`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl"))