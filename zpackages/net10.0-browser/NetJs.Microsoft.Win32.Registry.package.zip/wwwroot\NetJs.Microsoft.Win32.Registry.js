
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw, $ssa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Win32.Registry", 
    {"h":33,"f":"Microsoft.Win32.Registry","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Win32.Registry","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Win32.Registry","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mwr.Microsoft.Win32.Registry", ($self) => class Registry
        {
            /*Microsoft.Win32.RegistryKey*/ static ClassesRoot = null;
            /*Microsoft.Win32.RegistryKey*/ static CurrentConfig = null;
            /*Microsoft.Win32.RegistryKey*/ static CurrentUser = null;
            /*Microsoft.Win32.RegistryKey*/ static LocalMachine = null;
            /*Microsoft.Win32.RegistryKey*/ static PerformanceData = null;
            /*Microsoft.Win32.RegistryKey*/ static Users = null;
            static /*object? */ GetValue(/*string*/ keyName, /*string?*/ valueName, /*object?*/ defaultValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ SetValue(/*string*/ keyName, /*string?*/ valueName, /*object*/ value)
            {
            }
            static /*void */ SetValue$1(/*string*/ keyName, /*string?*/ valueName, /*object*/ value, /*Microsoft.Win32.RegistryValueKind*/ valueKind)
            {
            }
            static $h = 65569;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"keyName","p":1310721},{"n":"valueName","p":1310721},{"n":"defaultValue","p":131073}],"n":"GetValue","d":65569,"h":30064836641,"f":33},{"r":65537,"p":[{"n":"keyName","p":1310721},{"n":"valueName","p":1310721},{"n":"value","p":131073}],"n":"SetValue","d":65569,"h":34359803937,"f":33},{"r":65537,"p":[{"n":"keyName","p":1310721},{"n":"valueName","p":1310721},{"n":"value","p":131073},{"n":"valueKind","p":393249}],"n":"SetValue","o":"@$1","d":65569,"h":38654771233,"f":33}],"l":[{"t":196641,"n":"ClassesRoot","d":65569,"h":4295032865,"f":33},{"t":196641,"n":"CurrentConfig","d":65569,"h":8590000161,"f":33},{"t":196641,"n":"CurrentUser","d":65569,"h":12884967457,"f":33},{"t":196641,"n":"LocalMachine","d":65569,"h":17179934753,"f":33},{"t":196641,"n":"PerformanceData","d":65569,"h":21474902049,"f":33},{"t":196641,"n":"Users","d":65569,"h":25769869345,"f":33}],"h":65569}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Win32.Registry`; }
        });
        
        $asm.$cls("$mwr.Microsoft.Win32.RegistryKey", ($self) => class RegistryKey extends $.$spc.System.MarshalByRefObject
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeRegistryHandle */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SubKeyCount()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ValueCount()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryView */ get View()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey(/*string*/ subkey)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$1(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$2(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*Microsoft.Win32.RegistryOptions*/ registryOptions)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$3(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*Microsoft.Win32.RegistryOptions*/ registryOptions, /*System.Security.AccessControl.RegistrySecurity?*/ registrySecurity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$4(/*string*/ subkey, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*System.Security.AccessControl.RegistrySecurity?*/ registrySecurity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$5(/*string*/ subkey, /*bool*/ writable)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey */ CreateSubKey$6(/*string*/ subkey, /*bool*/ writable, /*Microsoft.Win32.RegistryOptions*/ options)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ DeleteSubKey(/*string*/ subkey)
            {
            }
            /*void */ DeleteSubKey$1(/*string*/ subkey, /*bool*/ throwOnMissingSubKey)
            {
            }
            /*void */ DeleteSubKeyTree(/*string*/ subkey)
            {
            }
            /*void */ DeleteSubKeyTree$1(/*string*/ subkey, /*bool*/ throwOnMissingSubKey)
            {
            }
            /*void */ DeleteValue(/*string*/ name)
            {
            }
            /*void */ DeleteValue$1(/*string*/ name, /*bool*/ throwOnMissingValue)
            {
            }
            /*void */ Dispose()
            {
            }
            /*void */ Flush()
            {
            }
            static /*Microsoft.Win32.RegistryKey */ FromHandle(/*Microsoft.Win32.SafeHandles.SafeRegistryHandle*/ handle)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Microsoft.Win32.RegistryKey */ FromHandle$1(/*Microsoft.Win32.SafeHandles.SafeRegistryHandle*/ handle, /*Microsoft.Win32.RegistryView*/ view)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RegistrySecurity */ GetAccessControl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RegistrySecurity */ GetAccessControl$1(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ GetSubKeyNames()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetValue(/*string?*/ name)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetValue$1(/*string?*/ name, /*object?*/ defaultValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetValue$2(/*string?*/ name, /*object?*/ defaultValue, /*Microsoft.Win32.RegistryValueOptions*/ options)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryValueKind */ GetValueKind(/*string?*/ name)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ GetValueNames()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Microsoft.Win32.RegistryKey */ OpenBaseKey(/*Microsoft.Win32.RegistryHive*/ hKey, /*Microsoft.Win32.RegistryView*/ view)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Microsoft.Win32.RegistryKey */ OpenRemoteBaseKey(/*Microsoft.Win32.RegistryHive*/ hKey, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Microsoft.Win32.RegistryKey */ OpenRemoteBaseKey$1(/*Microsoft.Win32.RegistryHive*/ hKey, /*string*/ machineName, /*Microsoft.Win32.RegistryView*/ view)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey(/*string*/ name)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$1(/*string*/ name, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$2(/*string*/ name, /*Microsoft.Win32.RegistryKeyPermissionCheck*/ permissionCheck, /*System.Security.AccessControl.RegistryRights*/ rights)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$3(/*string*/ name, /*bool*/ writable)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.RegistryKey? */ OpenSubKey$4(/*string*/ name, /*System.Security.AccessControl.RegistryRights*/ rights)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetAccessControl(/*System.Security.AccessControl.RegistrySecurity*/ registrySecurity)
            {
            }
            /*void */ SetValue(/*string?*/ name, /*object*/ value)
            {
            }
            /*void */ SetValue$1(/*string?*/ name, /*object*/ value, /*Microsoft.Win32.RegistryValueKind*/ valueKind)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mwr.Microsoft.Win32.RegistryKey.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 196641;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":65011713,"p":[{"p":589857,"g":{"r":0,"d":0,"h":12885098529,"f":1},"n":"Handle","d":196641,"h":8590131233,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475033121,"f":1},"n":"Name","d":196641,"h":17180065825,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30064967713,"f":1},"n":"SubKeyCount","d":196641,"h":25770000417,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38654902305,"f":1},"n":"ValueCount","d":196641,"h":34359935009,"f":1},{"p":524321,"g":{"r":0,"d":0,"h":47244836897,"f":1},"n":"View","d":196641,"h":42949869601,"f":1}],"m":[{"r":65537,"n":"Close","d":196641,"h":51539804193,"f":1},{"r":196641,"p":[{"n":"subkey","p":1310721}],"n":"CreateSubKey","d":196641,"h":55834771489,"f":1},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"permissionCheck","p":262177}],"n":"CreateSubKey","o":"@$1","d":196641,"h":60129738785,"f":1},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"permissionCheck","p":262177},{"n":"registryOptions","p":327713}],"n":"CreateSubKey","o":"@$2","d":196641,"h":64424706081,"f":1},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"permissionCheck","p":262177},{"n":"registryOptions","p":327713},{"n":"registrySecurity","p":852001}],"n":"CreateSubKey","o":"@$3","d":196641,"h":68719673377,"f":1},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"permissionCheck","p":262177},{"n":"registrySecurity","p":852001}],"n":"CreateSubKey","o":"@$4","d":196641,"h":73014640673,"f":1},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"writable","p":262145}],"n":"CreateSubKey","o":"@$5","d":196641,"h":77309607969,"f":1},{"r":196641,"p":[{"n":"subkey","p":1310721},{"n":"writable","p":262145},{"n":"options","p":327713}],"n":"CreateSubKey","o":"@$6","d":196641,"h":81604575265,"f":1},{"r":65537,"p":[{"n":"subkey","p":1310721}],"n":"DeleteSubKey","d":196641,"h":85899542561,"f":1},{"r":65537,"p":[{"n":"subkey","p":1310721},{"n":"throwOnMissingSubKey","p":262145}],"n":"DeleteSubKey","o":"@$1","d":196641,"h":90194509857,"f":1},{"r":65537,"p":[{"n":"subkey","p":1310721}],"n":"DeleteSubKeyTree","d":196641,"h":94489477153,"f":1},{"r":65537,"p":[{"n":"subkey","p":1310721},{"n":"throwOnMissingSubKey","p":262145}],"n":"DeleteSubKeyTree","o":"@$1","d":196641,"h":98784444449,"f":1},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"DeleteValue","d":196641,"h":103079411745,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"throwOnMissingValue","p":262145}],"n":"DeleteValue","o":"@$1","d":196641,"h":107374379041,"f":1},{"r":65537,"n":"Dispose","d":196641,"h":111669346337,"f":1},{"r":65537,"n":"Flush","d":196641,"h":115964313633,"f":1},{"r":196641,"p":[{"n":"handle","p":589857}],"n":"FromHandle","d":196641,"h":120259280929,"f":33},{"r":196641,"p":[{"n":"handle","p":589857},{"n":"view","p":524321}],"n":"FromHandle","o":"@$1","d":196641,"h":124554248225,"f":33},{"r":852001,"n":"GetAccessControl","d":196641,"h":128849215521,"f":1},{"r":852001,"p":[{"n":"includeSections","p":252247}],"n":"GetAccessControl","o":"@$1","d":196641,"h":133144182817,"f":1},{"r":0,"n":"GetSubKeyNames","d":196641,"h":137439150113,"f":1},{"r":131073,"p":[{"n":"name","p":1310721}],"n":"GetValue","d":196641,"h":141734117409,"f":1},{"r":131073,"p":[{"n":"name","p":1310721},{"n":"defaultValue","p":131073}],"n":"GetValue","o":"@$1","d":196641,"h":146029084705,"f":1},{"r":131073,"p":[{"n":"name","p":1310721},{"n":"defaultValue","p":131073},{"n":"options","p":458785}],"n":"GetValue","o":"@$2","d":196641,"h":150324052001,"f":1},{"r":393249,"p":[{"n":"name","p":1310721}],"n":"GetValueKind","d":196641,"h":154619019297,"f":1},{"r":0,"n":"GetValueNames","d":196641,"h":158913986593,"f":1},{"r":196641,"p":[{"n":"hKey","p":131105},{"n":"view","p":524321}],"n":"OpenBaseKey","d":196641,"h":163208953889,"f":33},{"r":196641,"p":[{"n":"hKey","p":131105},{"n":"machineName","p":1310721}],"n":"OpenRemoteBaseKey","d":196641,"h":167503921185,"f":33},{"r":196641,"p":[{"n":"hKey","p":131105},{"n":"machineName","p":1310721},{"n":"view","p":524321}],"n":"OpenRemoteBaseKey","o":"@$1","d":196641,"h":171798888481,"f":33},{"r":196641,"p":[{"n":"name","p":1310721}],"n":"OpenSubKey","d":196641,"h":176093855777,"f":1},{"r":196641,"p":[{"n":"name","p":1310721},{"n":"permissionCheck","p":262177}],"n":"OpenSubKey","o":"@$1","d":196641,"h":180388823073,"f":1},{"r":196641,"p":[{"n":"name","p":1310721},{"n":"permissionCheck","p":262177},{"n":"rights","p":786465}],"n":"OpenSubKey","o":"@$2","d":196641,"h":184683790369,"f":1},{"r":196641,"p":[{"n":"name","p":1310721},{"n":"writable","p":262145}],"n":"OpenSubKey","o":"@$3","d":196641,"h":188978757665,"f":1},{"r":196641,"p":[{"n":"name","p":1310721},{"n":"rights","p":786465}],"n":"OpenSubKey","o":"@$4","d":196641,"h":193273724961,"f":1},{"r":65537,"p":[{"n":"registrySecurity","p":852001}],"n":"SetAccessControl","d":196641,"h":197568692257,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"SetValue","d":196641,"h":201863659553,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073},{"n":"valueKind","p":393249}],"n":"SetValue","o":"@$1","d":196641,"h":206158626849,"f":1},{"r":1310721,"n":"ToString","d":196641,"h":210453594145,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":196641,"h":4295163937,"f":8}],"i":[57475073],"h":196641}; }
            static get $b() { return $.$spc.System.MarshalByRefObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryKey`; }
        });
        
        $asm.$cls("$mwr.System.Security.AccessControl.RegistryAccessRule", ($self) => class RegistryAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.RegistryRights */ get RegistryRights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 655393;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":383319,"p":[{"p":786465,"g":{"r":0,"d":0,"h":25770459169,"f":1},"n":"RegistryRights","d":655393,"h":21475491873,"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"registryRights","p":786465},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$3","d":655393,"h":4295622689,"f":1},{"p":[{"n":"identity","p":247007},{"n":"registryRights","p":786465},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$4","d":655393,"h":8590589985,"f":1},{"p":[{"n":"identity","p":1310721},{"n":"registryRights","p":786465},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$5","d":655393,"h":12885557281,"f":1},{"p":[{"n":"identity","p":1310721},{"n":"registryRights","p":786465},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$6","d":655393,"h":17180524577,"f":1}],"h":655393}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.RegistryAccessRule`; }
        });
        
        $asm.$cls("$mwr.System.Security.AccessControl.RegistryAuditRule", ($self) => class RegistryAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ identity, /*System.Security.AccessControl.RegistryRights*/ registryRights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.RegistryRights */ get RegistryRights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 720929;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":842071,"p":[{"p":786465,"g":{"r":0,"d":0,"h":17180590113,"f":1},"n":"RegistryRights","d":720929,"h":12885622817,"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"registryRights","p":786465},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"flags","p":776535}],"n":".ctor","o":"$ctor$3","d":720929,"h":4295688225,"f":1},{"p":[{"n":"identity","p":1310721},{"n":"registryRights","p":786465},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"flags","p":776535}],"n":".ctor","o":"$ctor$4","d":720929,"h":8590655521,"f":1}],"h":720929}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.RegistryAuditRule`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryHive", ($self) => class RegistryHive extends $.$spc.System.Enum
        {
            static ClassesRoot = -2147483648;
            static CurrentUser = -2147483647;
            static LocalMachine = -2147483646;
            static Users = -2147483645;
            static PerformanceData = -2147483644;
            static CurrentConfig = -2147483643;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ClassesRoot": -2147483648n,
                    "CurrentUser": -2147483647n,
                    "LocalMachine": -2147483646n,
                    "Users": -2147483645n,
                    "PerformanceData": -2147483644n,
                    "CurrentConfig": -2147483643n
                };
            }
            static $h = 131105;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":131105,"n":"ClassesRoot","d":131105,"h":4295098401,"f":33},{"t":131105,"n":"CurrentUser","d":131105,"h":8590065697,"f":33},{"t":131105,"n":"LocalMachine","d":131105,"h":12885032993,"f":33},{"t":131105,"n":"Users","d":131105,"h":17180000289,"f":33},{"t":131105,"n":"PerformanceData","d":131105,"h":21474967585,"f":33},{"t":131105,"n":"CurrentConfig","d":131105,"h":25769934881,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":131105,"h":30064902177,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":131105}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryHive`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryKeyPermissionCheck", ($self) => class RegistryKeyPermissionCheck extends $.$spc.System.Enum
        {
            static Default = 0;
            static ReadSubTree = 1;
            static ReadWriteSubTree = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "ReadSubTree": 1n,
                    "ReadWriteSubTree": 2n
                };
            }
            static $h = 262177;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":262177,"n":"Default","d":262177,"h":4295229473,"f":33},{"t":262177,"n":"ReadSubTree","d":262177,"h":8590196769,"f":33},{"t":262177,"n":"ReadWriteSubTree","d":262177,"h":12885164065,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":262177,"h":17180131361,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":262177}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryKeyPermissionCheck`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryOptions", ($self) => class RegistryOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static Volatile = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Volatile": 1n
                };
            }
            static $h = 327713;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":327713,"n":"None","d":327713,"h":4295295009,"f":33},{"t":327713,"n":"Volatile","d":327713,"h":8590262305,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":327713,"h":12885229601,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":327713,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryOptions`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryValueKind", ($self) => class RegistryValueKind extends $.$spc.System.Enum
        {
            static None = -1;
            static Unknown = 0;
            static String = 1;
            static ExpandString = 2;
            static Binary = 3;
            static DWord = 4;
            static MultiString = 7;
            static QWord = 11;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": -1n,
                    "Unknown": 0n,
                    "String": 1n,
                    "ExpandString": 2n,
                    "Binary": 3n,
                    "DWord": 4n,
                    "MultiString": 7n,
                    "QWord": 11n
                };
            }
            static $h = 393249;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":393249,"n":"None","d":393249,"h":4295360545,"f":33},{"t":393249,"n":"Unknown","d":393249,"h":8590327841,"f":33},{"t":393249,"n":"String","d":393249,"h":12885295137,"f":33},{"t":393249,"n":"ExpandString","d":393249,"h":17180262433,"f":33},{"t":393249,"n":"Binary","d":393249,"h":21475229729,"f":33},{"t":393249,"n":"DWord","d":393249,"h":25770197025,"f":33},{"t":393249,"n":"MultiString","d":393249,"h":30065164321,"f":33},{"t":393249,"n":"QWord","d":393249,"h":34360131617,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":393249,"h":38655098913,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":393249}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryValueKind`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryValueOptions", ($self) => class RegistryValueOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static DoNotExpandEnvironmentNames = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DoNotExpandEnvironmentNames": 1n
                };
            }
            static $h = 458785;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":458785,"n":"None","d":458785,"h":4295426081,"f":33},{"t":458785,"n":"DoNotExpandEnvironmentNames","d":458785,"h":8590393377,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":458785,"h":12885360673,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":458785,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryValueOptions`; }
        });
        
        $asm.$str("$mwr.Microsoft.Win32.RegistryView", ($self) => class RegistryView extends $.$spc.System.Enum
        {
            static Default = 0;
            static Registry64 = 256;
            static Registry32 = 512;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Registry64": 256n,
                    "Registry32": 512n
                };
            }
            static $h = 524321;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":524321,"n":"Default","d":524321,"h":4295491617,"f":33},{"t":524321,"n":"Registry64","d":524321,"h":8590458913,"f":33},{"t":524321,"n":"Registry32","d":524321,"h":12885426209,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":524321,"h":17180393505,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":524321}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Win32.RegistryView`; }
        });
        
        $asm.$str("$mwr.System.Security.AccessControl.RegistryRights", ($self) => class RegistryRights extends $.$spc.System.Enum
        {
            static QueryValues = 1;
            static SetValue = 2;
            static CreateSubKey = 4;
            static EnumerateSubKeys = 8;
            static Notify = 16;
            static CreateLink = 32;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static WriteKey = 131078;
            static ExecuteKey = 131097;
            static ReadKey = 131097;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static FullControl = 983103;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "QueryValues": 1n,
                    "SetValue": 2n,
                    "CreateSubKey": 4n,
                    "EnumerateSubKeys": 8n,
                    "Notify": 16n,
                    "CreateLink": 32n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "WriteKey": 131078n,
                    "ExecuteKey": 131097n,
                    "ReadKey": 131097n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "FullControl": 983103n
                };
            }
            static $h = 786465;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":786465,"n":"QueryValues","d":786465,"h":4295753761,"f":33},{"t":786465,"n":"SetValue","d":786465,"h":8590721057,"f":33},{"t":786465,"n":"CreateSubKey","d":786465,"h":12885688353,"f":33},{"t":786465,"n":"EnumerateSubKeys","d":786465,"h":17180655649,"f":33},{"t":786465,"n":"Notify","d":786465,"h":21475622945,"f":33},{"t":786465,"n":"CreateLink","d":786465,"h":25770590241,"f":33},{"t":786465,"n":"Delete","d":786465,"h":30065557537,"f":33},{"t":786465,"n":"ReadPermissions","d":786465,"h":34360524833,"f":33},{"t":786465,"n":"WriteKey","d":786465,"h":38655492129,"f":33},{"t":786465,"n":"ExecuteKey","d":786465,"h":42950459425,"f":33},{"t":786465,"n":"ReadKey","d":786465,"h":47245426721,"f":33},{"t":786465,"n":"ChangePermissions","d":786465,"h":51540394017,"f":33},{"t":786465,"n":"TakeOwnership","d":786465,"h":55835361313,"f":33},{"t":786465,"n":"FullControl","d":786465,"h":60130328609,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":786465,"h":64425295905,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":786465,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.RegistryRights`; }
        });
        
        $asm.$cls("$mwr.System.Security.AccessControl.RegistrySecurity", ($self) => class RegistrySecurity extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$11()
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.RegistryAccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.RegistryAuditRule*/ rule)
            {
            }
            static $h = 852001;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2021719,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":12885753889,"f":32769},"n":"AccessRightType","d":852001,"h":8590786593,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":21475688481,"f":32769},"n":"AccessRuleType","d":852001,"h":17180721185,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":30065623073,"f":32769},"n":"AuditRuleType","d":852001,"h":25770655777,"f":32769}],"m":[{"r":383319,"p":[{"n":"identityReference","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"type","p":317783}],"n":"AccessRuleFactory","d":852001,"h":34360590369,"f":32769},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"AddAccessRule","o":"@$1","d":852001,"h":38655557665,"f":1},{"r":65537,"p":[{"n":"rule","p":720929}],"n":"AddAuditRule","o":"@$1","d":852001,"h":42950524961,"f":1},{"r":842071,"p":[{"n":"identityReference","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"flags","p":776535}],"n":"AuditRuleFactory","d":852001,"h":47245492257,"f":32769},{"r":262145,"p":[{"n":"rule","p":655393}],"n":"RemoveAccessRule","o":"@$1","d":852001,"h":51540459553,"f":1},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"RemoveAccessRuleAll","o":"@$1","d":852001,"h":55835426849,"f":1},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":852001,"h":60130394145,"f":1},{"r":262145,"p":[{"n":"rule","p":720929}],"n":"RemoveAuditRule","o":"@$1","d":852001,"h":64425361441,"f":1},{"r":65537,"p":[{"n":"rule","p":720929}],"n":"RemoveAuditRuleAll","o":"@$1","d":852001,"h":68720328737,"f":1},{"r":65537,"p":[{"n":"rule","p":720929}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":852001,"h":73015296033,"f":1},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"ResetAccessRule","o":"@$1","d":852001,"h":77310263329,"f":1},{"r":65537,"p":[{"n":"rule","p":655393}],"n":"SetAccessRule","o":"@$1","d":852001,"h":81605230625,"f":1},{"r":65537,"p":[{"n":"rule","p":720929}],"n":"SetAuditRule","o":"@$1","d":852001,"h":85900197921,"f":1}],"c":[{"n":".ctor","o":"$ctor$11","d":852001,"h":4295819297,"f":1}],"h":852001}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.RegistrySecurity`; }
        });
        
        $asm.$cls("$mwr.Microsoft.Win32.SafeHandles.SafeRegistryHandle", ($self) => class SafeRegistryHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 589857;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"m":[{"r":262145,"n":"ReleaseHandle","d":589857,"h":12885491745,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":589857,"h":4295557153,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":589857,"h":8590524449,"f":1}],"i":[57475073],"h":589857}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeRegistryHandle`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl"))