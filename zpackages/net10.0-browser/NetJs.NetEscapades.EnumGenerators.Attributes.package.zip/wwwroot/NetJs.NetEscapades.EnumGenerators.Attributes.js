
//--TRIMMABLE-BOUNDARY-START(59379)
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.NetEscapades.EnumGenerators.Attributes", 
    {
  "h": 59379,
  "f": "NetEscapades.EnumGenerators.Attributes",
  "v": "1.0.0.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "Andrew Lock",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106627073,
      "c": 8696561665,
      "a": [
        {
          "v": "Copyright \u00A9 AndrewLock",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.0-beta21\u002Bd3995b8fa8854357c902e2d2b4495ed16c5f8546",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetEscapades.EnumGenerators.Attributes",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetEscapades.EnumGenerators.Attributes",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 122617857,
      "c": 17302487041,
      "a": [
        {
          "v": "en-GB",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(124915)
        $asm.$cls("$rTZV.NE.EnumExtensionsAttribute", ($self) => class EnumExtensionsAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(34359863283)
            /*string?*/ ExtensionClassNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(34359863283)
            
            //--TRIMMABLE-BOUNDARY-START(30064895987)
            /*string?*/ ExtensionClassName = null;
            //--TRIMMABLE-BOUNDARY-END(30064895987)
            
            //--TRIMMABLE-BOUNDARY-START(90194438131)
            /*MetadataSource*/ MetadataSource = 0;
            //--TRIMMABLE-BOUNDARY-END(90194438131)
            
            //--TRIMMABLE-BOUNDARY-START(81604503539)
            /*bool*/ IsInterceptable = false;
            //--TRIMMABLE-BOUNDARY-END(81604503539)
            
            //--TRIMMABLE-BOUNDARY-START(85899470835)
            /*bool*/ IsInternal = false;
            //--TRIMMABLE-BOUNDARY-END(85899470835)
            
            //--TRIMMABLE-BOUNDARY-START(25769928691)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769928691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769928691)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(90194438131)
                this.MetadataSource = 3;
                //--TRIMMABLE-BOUNDARY-END(90194438131)
                
                //--TRIMMABLE-BOUNDARY-START(81604503539)
                this.IsInterceptable = true;
                //--TRIMMABLE-BOUNDARY-END(81604503539)
                
            }
            static $h = 124915;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359863283),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539732467,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374307315,
        "f": 83886081
      },
      "n": "ExtensionClassNamespace",
      "d": 124915,
      "h": 34359863283,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359863283),
//--TRIMMABLE-BOUNDARY-START(30064895987),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949797875,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784372723,
        "f": 83886081
      },
      "n": "ExtensionClassName",
      "d": 124915,
      "h": 30064895987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064895987),
//--TRIMMABLE-BOUNDARY-START(90194438131),
    {
      "p": 255987,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309536243,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144111091,
        "f": 83886081
      },
      "n": "MetadataSource",
      "d": 124915,
      "h": 90194438131,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194438131),
//--TRIMMABLE-BOUNDARY-START(81604503539),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129667059,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964241907,
        "f": 83886081
      },
      "n": "IsInterceptable",
      "d": 124915,
      "h": 81604503539,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604503539),
//--TRIMMABLE-BOUNDARY-START(85899470835),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719601651,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554176499,
        "f": 83886081
      },
      "n": "IsInternal",
      "d": 124915,
      "h": 85899470835,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899470835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769928691),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 124915,
      "h": 25769928691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769928691)
  ],
  "h": 124915,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 16,
          "t": 45416449
        }
      ]
    },
    {
      "t": 68747265,
      "c": 8658681857,
      "a": [
        {
          "v": "NETESCAPADES_ENUMGENERATORS_USAGES",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.S.Attribute; }
            static get $fullName() { return `NetEscapades.EnumGenerators.EnumExtensionsAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(124915)
        
        
        //--TRIMMABLE-BOUNDARY-START(190451)
        $asm.$cls("$rTZV.NE.EnumExtensionsAttribute<>", (T) => $asm.$gt("$rTZV.NE.EnumExtensionsAttribute<>", [T], ($self) => class EnumExtensionsAttribute$$ extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(34359928819)
            /*string?*/ ExtensionClassNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(34359928819)
            
            //--TRIMMABLE-BOUNDARY-START(30064961523)
            /*string?*/ ExtensionClassName = null;
            //--TRIMMABLE-BOUNDARY-END(30064961523)
            
            //--TRIMMABLE-BOUNDARY-START(90194503667)
            /*MetadataSource*/ MetadataSource = 0;
            //--TRIMMABLE-BOUNDARY-END(90194503667)
            
            //--TRIMMABLE-BOUNDARY-START(81604569075)
            /*bool*/ IsInterceptable = false;
            //--TRIMMABLE-BOUNDARY-END(81604569075)
            
            //--TRIMMABLE-BOUNDARY-START(85899536371)
            /*bool*/ IsInternal = false;
            //--TRIMMABLE-BOUNDARY-END(85899536371)
            
            //--TRIMMABLE-BOUNDARY-START(25769994227)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769994227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769994227)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(90194503667)
                this.MetadataSource = 3;
                //--TRIMMABLE-BOUNDARY-END(90194503667)
                
                //--TRIMMABLE-BOUNDARY-START(81604569075)
                this.IsInterceptable = true;
                //--TRIMMABLE-BOUNDARY-END(81604569075)
                
            }
            static $h = 190451;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359928819),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 83886081
      },
      "n": "ExtensionClassNamespace",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359928819),
//--TRIMMABLE-BOUNDARY-START(30064961523),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 83886081
      },
      "n": "ExtensionClassName",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064961523),
//--TRIMMABLE-BOUNDARY-START(90194503667),
    {
      "p": 255987,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 83886081
      },
      "n": "MetadataSource",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194503667),
//--TRIMMABLE-BOUNDARY-START(81604569075),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 83886081
      },
      "n": "IsInterceptable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604569075),
//--TRIMMABLE-BOUNDARY-START(85899536371),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 83886081
      },
      "n": "IsInternal",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899536371)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769994227),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769994227)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 1,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 68747265,
      "c": 8658681857,
      "a": [
        {
          "v": "NETESCAPADES_ENUMGENERATORS_USAGES",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.S.Attribute; }
            static get $fullName() { return `NetEscapades.EnumGenerators.EnumExtensionsAttribute<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(190451)
        
        
        //--TRIMMABLE-BOUNDARY-START(255987)
        $asm.$str("$rTZV.NE.MetadataSource", ($self) => class MetadataSource extends $.$$.S.Enum
        {
            static None = 0;
            static DisplayAttribute = 1;
            static DescriptionAttribute = 2;
            static EnumMemberAttribute = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(255987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "DisplayAttribute": 1n,
                    "DescriptionAttribute": 2n,
                    "EnumMemberAttribute": 3n
                };
            }
            static $h = 255987;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475092467),
    {
      "t": 255987,
      "n": "None",
      "d": 255987,
      "h": 21475092467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475092467),
//--TRIMMABLE-BOUNDARY-START(12885157875),
    {
      "t": 255987,
      "n": "DisplayAttribute",
      "d": 255987,
      "h": 12885157875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885157875),
//--TRIMMABLE-BOUNDARY-START(8590190579),
    {
      "t": 255987,
      "n": "DescriptionAttribute",
      "d": 255987,
      "h": 8590190579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590190579),
//--TRIMMABLE-BOUNDARY-START(17180125171),
    {
      "t": 255987,
      "n": "EnumMemberAttribute",
      "d": 255987,
      "h": 17180125171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180125171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295223283),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 255987,
      "h": 4295223283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295223283)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 255987
}; }
            static get $b() { return $.$$.S.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static get $fullName() { return `NetEscapades.EnumGenerators.MetadataSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(255987)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq"))
//--TRIMMABLE-BOUNDARY-END(59379)
