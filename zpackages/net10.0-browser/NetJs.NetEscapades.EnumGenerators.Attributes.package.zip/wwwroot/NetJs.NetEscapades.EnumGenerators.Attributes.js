
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.NetEscapades.EnumGenerators.Attributes", 
    {"h":56046,"f":"NetEscapades.EnumGenerators.Attributes","v":"0.0.0.0","m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$nea.NetEscapades.EnumGenerators.EnumExtensionsAttribute", ($self) => class EnumExtensionsAttribute extends $.$$.System.Attribute
        {
            /*string?*/ ExtensionClassNamespace = null;
            /*string?*/ ExtensionClassName = null;
            /*MetadataSource*/ MetadataSource = 0;
            /*bool*/ IsInterceptable = false;
            /*bool*/ IsInternal = false;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataSource = 3;
                this.IsInterceptable = true;
                this.IsInternal = false;
            }
            static $h = 121582;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885023470,"f":50331649},"s":{"r":0,"d":0,"h":17179990766,"f":83886081},"n":"ExtensionClassNamespace","d":121582,"h":8590056174,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30064892654,"f":50331649},"s":{"r":0,"d":0,"h":34359859950,"f":83886081},"n":"ExtensionClassName","d":121582,"h":25769925358,"f":2097153},{"p":252654,"g":{"r":0,"d":0,"h":47244761838,"f":50331649},"s":{"r":0,"d":0,"h":51539729134,"f":83886081},"n":"MetadataSource","d":121582,"h":42949794542,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":64424631022,"f":50331649},"s":{"r":0,"d":0,"h":68719598318,"f":83886081},"n":"IsInterceptable","d":121582,"h":60129663726,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":81604500206,"f":50331649},"s":{"r":0,"d":0,"h":85899467502,"f":83886081},"n":"IsInternal","d":121582,"h":77309532910,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":121582,"h":90194434798,"f":16777217}],"h":121582,"a":[{"t":14745601,"c":21489582081,"a":[{"v":16,"t":14680065}]},{"t":35979265,"c":4330946561,"a":[{"v":"NETESCAPADES_ENUMGENERATORS_USAGES","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `NetEscapades.EnumGenerators.EnumExtensionsAttribute`; }
        });
        
        $asm.$cls("$nea.NetEscapades.EnumGenerators.EnumExtensionsAttribute<>", (T) => $asm.$gt("$nea.NetEscapades.EnumGenerators.EnumExtensionsAttribute<>", [T], ($self) => class EnumExtensionsAttribute$$ extends $.$$.System.Attribute
        {
            /*string?*/ ExtensionClassNamespace = null;
            /*string?*/ ExtensionClassName = null;
            /*MetadataSource*/ MetadataSource = 0;
            /*bool*/ IsInterceptable = false;
            /*bool*/ IsInternal = false;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataSource = 3;
                this.IsInterceptable = true;
                this.IsInternal = false;
            }
            static $h = 187118;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":83886081},"n":"ExtensionClassNamespace","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":83886081},"n":"ExtensionClassName","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":252654,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":83886081},"n":"MetadataSource","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":83886081},"n":"IsInterceptable","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":83886081},"n":"IsInternal","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1,"t":14680065}],"n":[{"n":"AllowMultiple","v":true,"t":262145}]},{"t":35979265,"c":4330946561,"a":[{"v":"NETESCAPADES_ENUMGENERATORS_USAGES","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `NetEscapades.EnumGenerators.EnumExtensionsAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$nea.NetEscapades.EnumGenerators.MetadataSource", ($self) => class MetadataSource extends $.$$.System.Enum
        {
            static None = 0;
            static DisplayAttribute = 1;
            static DescriptionAttribute = 2;
            static EnumMemberAttribute = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DisplayAttribute": 1n,
                    "DescriptionAttribute": 2n,
                    "EnumMemberAttribute": 3n
                };
            }
            static $h = 252654;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":252654,"n":"None","d":252654,"h":4295219950,"f":4194337},{"t":252654,"n":"DisplayAttribute","d":252654,"h":8590187246,"f":4194337},{"t":252654,"n":"DescriptionAttribute","d":252654,"h":12885154542,"f":4194337},{"t":252654,"n":"EnumMemberAttribute","d":252654,"h":17180121838,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":252654,"h":21475089134,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":252654}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `NetEscapades.EnumGenerators.MetadataSource`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq"))