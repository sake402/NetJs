
(function ($global, $, $spc, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.NetEscapades.EnumGenerators.Attributes", 
    {"h":64439,"f":"NetEscapades.EnumGenerators.Attributes","v":"0.0.0.0","m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$nea.NetEscapades.EnumGenerators.EnumExtensionsAttribute", ($self) => class EnumExtensionsAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ ExtensionClassNamespace = null;
            /*string?*/ ExtensionClassName = null;
            /*MetadataSource*/ MetadataSource = 0;
            /*bool*/ IsInterceptable = false;
            /*bool*/ IsInternal = false;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataSource = 3;
                this.IsInterceptable = true;
                this.IsInternal = false;
            }
            static $h = 129975;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885031863,"f":1},"s":{"r":0,"d":0,"h":17179999159,"f":1},"n":"ExtensionClassNamespace","d":129975,"h":8590064567,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30064901047,"f":1},"s":{"r":0,"d":0,"h":34359868343,"f":1},"n":"ExtensionClassName","d":129975,"h":25769933751,"f":1},{"p":261047,"g":{"r":0,"d":0,"h":47244770231,"f":1},"s":{"r":0,"d":0,"h":51539737527,"f":1},"n":"MetadataSource","d":129975,"h":42949802935,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424639415,"f":1},"s":{"r":0,"d":0,"h":68719606711,"f":1},"n":"IsInterceptable","d":129975,"h":60129672119,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81604508599,"f":1},"s":{"r":0,"d":0,"h":85899475895,"f":1},"n":"IsInternal","d":129975,"h":77309541303,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":129975,"h":90194443191,"f":1}],"h":129975,"a":[{"t":14680065,"c":21489516545,"a":[{"v":16,"t":14614529}]},{"t":35979265,"c":4330946561,"a":[{"v":"NETESCAPADES_ENUMGENERATORS_USAGES","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `NetEscapades.EnumGenerators.EnumExtensionsAttribute`; }
        });
        
        $asm.$cls("$nea.NetEscapades.EnumGenerators.EnumExtensionsAttribute<>", (T) => $asm.$gt("$nea.NetEscapades.EnumGenerators.EnumExtensionsAttribute<>", [T], ($self) => class EnumExtensionsAttribute$$ extends $.$spc.System.Attribute
        {
            /*string?*/ ExtensionClassNamespace = null;
            /*string?*/ ExtensionClassName = null;
            /*MetadataSource*/ MetadataSource = 0;
            /*bool*/ IsInterceptable = false;
            /*bool*/ IsInternal = false;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataSource = 3;
                this.IsInterceptable = true;
                this.IsInternal = false;
            }
            static $h = 195511;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"n":"ExtensionClassNamespace","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},"n":"ExtensionClassName","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"p":261047,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},"n":"MetadataSource","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1},"n":"IsInterceptable","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":1},"n":"IsInternal","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14680065,"c":21489516545,"a":[{"v":1,"t":14614529}],"n":[{"n":"AllowMultiple","v":true,"t":262145}]},{"t":35979265,"c":4330946561,"a":[{"v":"NETESCAPADES_ENUMGENERATORS_USAGES","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `NetEscapades.EnumGenerators.EnumExtensionsAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$nea.NetEscapades.EnumGenerators.MetadataSource", ($self) => class MetadataSource extends $.$spc.System.Enum
        {
            static None = 0;
            static DisplayAttribute = 1;
            static DescriptionAttribute = 2;
            static EnumMemberAttribute = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DisplayAttribute": 1n,
                    "DescriptionAttribute": 2n,
                    "EnumMemberAttribute": 3n
                };
            }
            static $h = 261047;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":261047,"n":"None","d":261047,"h":4295228343,"f":33},{"t":261047,"n":"DisplayAttribute","d":261047,"h":8590195639,"f":33},{"t":261047,"n":"DescriptionAttribute","d":261047,"h":12885162935,"f":33},{"t":261047,"n":"EnumMemberAttribute","d":261047,"h":17180130231,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":261047,"h":21475097527,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":261047}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `NetEscapades.EnumGenerators.MetadataSource`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq"))