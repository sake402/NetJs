
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mam, $mep, $meca, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela, $maa, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sipl, $stew, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw, $macwa, $mc, $slq, $snhj, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJsBlazorDemo", 
    {"g":1,"h":55925,"f":"NetJsBlazorDemo","v":"1.0.0.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"NetJsBlazorDemo","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.0","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJsBlazorDemo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJsBlazorDemo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.0.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$n.Program", ($self) => class Program
        {
            static async $$$(args)
            {
                /*var*/ let builder = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder.CreateDefault(args);
                builder.RootComponents.Add$3($.$n.NetJsBlazorDemo.App, "#app");
                builder.RootComponents.Add$3($.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet, "head::after");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$5($.$snh.System.Net.Http.HttpClient, builder.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$snh.System.Net.Http.HttpClient))().$ctor(this,  (/**/ sp) =>
                {
                    return (() =>
                    {
                        //new $.$snh.System.Net.Http.HttpClient()
                        const $t1 = $.$snh.System.Net.Http.HttpClient;
                        const $i1 = new $t1();
                        $i1.$ctor$3();
                        $i1.BaseAddress = new $.$spu.System.Uri().$ctor$5(builder.HostEnvironment.Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$BaseAddress);
                        return $i1;
                    })();
                }, {"r":6422573,"p":[{"n":"sp","p":327717}],"n":"","d":842357,"h":0,"f":17825794}));
                await builder.Build().RunAsync();
            }
            static $h = 842357;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"args","p":$.$typeArray($.$$.System.String).$h}],"n":"\u003CMain\u003E$","o":"$$$","d":842357,"h":4295809653,"f":16781346}],"c":[{"n":".ctor","o":"$ctor$1","d":842357,"h":8590776949,"f":16777217}],"h":842357}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Program`; }
        });
        
        $asm.$cls("$n.NetJsBlazorDemo._Imports", ($self) => class _Imports extends $.$$.System.Object
        {
            /*void */ Execute()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 252533;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":252533,"h":4295219829,"f":16777220}],"c":[{"n":".ctor","o":"$ctor$1","d":252533,"h":8590187125,"f":16777217}],"h":252533}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `NetJsBlazorDemo._Imports`; }
        });
        
        $asm.$cls("$n.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 186997;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":186997,"h":4295154293,"f":16777217}],"h":186997,"a":[{"t":121461,"c":4295088757},{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$cls("$n.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 121461;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":121461,"h":4295088757,"f":16777217}],"h":121461}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$n.NetJsBlazorDemo.App", ($self) => class App extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.Routing.Router, 0);
                __builder.AddComponentParameter(1, "AppAssembly", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Reflection.Assembly, $.$n.NetJsBlazorDemo.App.$type.Assembly));
                __builder.AddComponentParameter(2, "NotFoundPage", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Type, $.$n.NetJsBlazorDemo.Pages.NotFound.$type));
                __builder.AddAttribute$1(3, "Found", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$mac.Microsoft.AspNetCore.Components.RouteData))().$ctor(this, ( (/*routeData*/ routeData) =>
                {
                    return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.RouteView, 4);
                        __builder2.AddComponentParameter(5, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(6, "DefaultLayout", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Type, $.$n.NetJsBlazorDemo.Layout.MainLayout.$type));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(7, "\r\n        ");
                        __builder2.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate, 8);
                        __builder2.AddComponentParameter(9, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(10, "Selector", "h1");
                        __builder2.CloseComponent();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":318069,"h":0,"f":17825794});
                })));
                __builder.CloseComponent();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 318069;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":318069,"h":4295285365,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":318069,"h":8590252661,"f":16777217}],"i":[2752520,3145736,3080200],"h":318069}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJsBlazorDemo.App`; }
        });
        
        $asm.$cls("$n.NetJsBlazorDemo.Layout.NavMenu", ($self) => class NavMenu extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$3(1, "class", "top-row ps-3 navbar navbar-dark");
                __builder.AddAttribute$5(2, "b-nndwi09png");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$3(4, "class", "container-fluid");
                __builder.AddAttribute$5(5, "b-nndwi09png");
                __builder.AddMarkupContent(6, "<a class=\"navbar-brand\" href b-nndwi09png>NetJsBlazorDemo</a>\r\n        ");
                __builder.OpenElement(7, "button");
                __builder.AddAttribute$3(8, "title", "Navigation menu");
                __builder.AddAttribute$3(9, "class", "navbar-toggler");
                __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 10, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$$.System.Action().$ctor(this, this.ToggleNavMenu)));
                __builder.AddAttribute$5(11, "b-nndwi09png");
                __builder.AddMarkupContent(12, "<span class=\"navbar-toggler-icon\" b-nndwi09png></span>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n\r\n");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$3(15, "class", (this.NavMenuCssClass) + " nav-scrollable");
                __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 16, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$$.System.Action().$ctor(this, this.ToggleNavMenu)));
                __builder.AddAttribute$5(17, "b-nndwi09png");
                __builder.OpenElement(18, "nav");
                __builder.AddAttribute$3(19, "class", "nav flex-column");
                __builder.AddAttribute$5(20, "b-nndwi09png");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$3(22, "class", "nav-item px-3");
                __builder.AddAttribute$5(23, "b-nndwi09png");
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 24);
                __builder.AddComponentParameter(25, "class", "nav-link");
                __builder.AddComponentParameter(26, "href", "");
                __builder.AddComponentParameter(27, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$1(28, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(29, "<span class=\"bi bi-house-door-fill-nav-menu\" aria-hidden=\"true\" b-nndwi09png></span> Home\r\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(30, "\r\n        ");
                __builder.OpenElement(31, "div");
                __builder.AddAttribute$3(32, "class", "nav-item px-3");
                __builder.AddAttribute$5(33, "b-nndwi09png");
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 34);
                __builder.AddComponentParameter(35, "class", "nav-link");
                __builder.AddComponentParameter(36, "href", "counter");
                __builder.AddAttribute$1(37, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(38, "<span class=\"bi bi-plus-square-fill-nav-menu\" aria-hidden=\"true\" b-nndwi09png></span> Counter\r\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(39, "\r\n        ");
                __builder.OpenElement(40, "div");
                __builder.AddAttribute$3(41, "class", "nav-item px-3");
                __builder.AddAttribute$5(42, "b-nndwi09png");
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 43);
                __builder.AddComponentParameter(44, "class", "nav-link");
                __builder.AddComponentParameter(45, "href", "weather");
                __builder.AddAttribute$1(46, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(47, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-nndwi09png></span> Weather\r\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*bool*/ collapseNavMenu = true;
            /*string? */ get NavMenuCssClass()
            {
                return this.collapseNavMenu ? "collapse" : null;
            }
            /*void */ ToggleNavMenu()
            {
                this.collapseNavMenu = !this.collapseNavMenu;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 449141;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180318325,"f":50331650},"n":"NavMenuCssClass","d":449141,"h":12885351029,"f":2097154}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":449141,"h":4295416437,"f":16809988},{"r":65537,"n":"ToggleNavMenu","d":449141,"h":21475285621,"f":16777218}],"l":[{"t":262145,"n":"collapseNavMenu","d":449141,"h":8590383733,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":449141,"h":25770252917,"f":16777217}],"i":[2752520,3145736,3080200],"h":449141}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJsBlazorDemo.Layout.NavMenu`; }
        });
        
        $asm.$cls("$n.NetJsBlazorDemo.Pages.NotFound", ($self) => class NotFound extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AddMarkupContent(0, "<h3>Not Found</h3>\r\n");
                __builder.AddMarkupContent(1, "<p>Sorry, the content you are looking for does not exist.</p>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 645749;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":645749,"h":4295613045,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":645749,"h":8590580341,"f":16777217}],"i":[2752520,3145736,3080200],"h":645749,"a":[{"t":4587528,"c":4299554824,"a":[{"v":383605,"t":142475265}]},{"t":9895944,"c":4304863240,"a":[{"v":"/not-found","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJsBlazorDemo.Pages.NotFound`; }
        });
        
        $asm.$cls("$n.NetJsBlazorDemo.Pages.Counter", ($self) => class Counter extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Web.PageTitle, 0);
                __builder.AddAttribute$1(1, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$2(2, "Counter");
                })));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.AddMarkupContent(4, "<h1>Counter</h1>\r\n\r\n");
                __builder.OpenElement(5, "p");
                __builder.AddAttribute$3(6, "role", "status");
                __builder.AddContent$2(7, "Current count: ");
                __builder.AddContent$1(8, $.$box(this.currentCount, $.$$.System.Int32));
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\r\n\r\n");
                __builder.OpenElement(10, "button");
                __builder.AddAttribute$3(11, "class", "btn btn-primary");
                __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 12, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$$.System.Action().$ctor(this, this.IncrementCount)));
                __builder.AddContent$2(13, "Click me");
                __builder.CloseElement();
            }
            /*int*/ currentCount = 0;
            /*void */ IncrementCount()
            {
                this.currentCount++;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 514677;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":514677,"h":4295481973,"f":16809988},{"r":65537,"n":"IncrementCount","d":514677,"h":12885416565,"f":16777218}],"l":[{"t":655361,"n":"currentCount","d":514677,"h":8590449269,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":514677,"h":17180383861,"f":16777217}],"i":[2752520,3145736,3080200],"h":514677,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/counter","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJsBlazorDemo.Pages.Counter`; }
        });
        
        $asm.$cls("$n.NetJsBlazorDemo.Pages.Home", ($self) => class Home extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Web.PageTitle, 0);
                __builder.AddAttribute$1(1, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$2(2, "Home");
                })));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.AddMarkupContent(4, "<h1>Hello, world!</h1>\r\n\r\nWelcome to your new app.\r\n");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 580213;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":580213,"h":4295547509,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":580213,"h":8590514805,"f":16777217}],"i":[2752520,3145736,3080200],"h":580213,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJsBlazorDemo.Pages.Home`; }
        });
        
        $asm.$cls("$n.NetJsBlazorDemo.Pages.Weather", ($self) => class Weather extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Web.PageTitle, 0);
                __builder.AddAttribute$1(1, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$2(2, "Weather");
                })));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.AddMarkupContent(4, "<h1>Weather</h1>\r\n\r\n");
                __builder.AddMarkupContent(5, "<p>This component demonstrates fetching data from the server.</p>");
                if (this.forecasts === null)
                {
                    __builder.AddMarkupContent(6, "<p><em>Loading...</em></p>");
                }
                else 
                {
                    __builder.OpenElement(7, "table");
                    __builder.AddAttribute$3(8, "class", "table");
                    __builder.AddMarkupContent(9, "<thead><tr><th>Date</th>\r\n                <th aria-label=\"Temperature in Celsius\">Temp. (C)</th>\r\n                <th aria-label=\"Temperature in Fahrenheit\">Temp. (F)</th>\r\n                <th>Summary</th></tr></thead>\r\n        ");
                    __builder.OpenElement(10, "tbody");
                    let $i1 = 0;
                    let $arr1 = this.forecasts;
                    while ($i1 < $arr1.length)
                    {
                        let forecast = $arr1[$i1++];
                        __builder.OpenElement(11, "tr");
                        __builder.OpenElement(12, "td");
                        __builder.AddContent$2(13, forecast.Date.ToShortDateString());
                        __builder.CloseElement();
                        __builder.AddMarkupContent(14, "\r\n                    ");
                        __builder.OpenElement(15, "td");
                        __builder.AddContent$1(16, $.$box(forecast.TemperatureC, $.$$.System.Int32));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(17, "\r\n                    ");
                        __builder.OpenElement(18, "td");
                        __builder.AddContent$1(19, $.$box(forecast.TemperatureF, $.$$.System.Int32));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(20, "\r\n                    ");
                        __builder.OpenElement(21, "td");
                        __builder.AddContent$2(22, forecast.Summary);
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            /*WeatherForecast[]?*/ forecasts = null;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.forecasts = await $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$6($.$typeArray($.$n.NetJsBlazorDemo.Pages.Weather.WeatherForecast), this.Http, "sample-data/weather.json", new $.$$.System.Threading.CancellationToken());
                });
            }
            static $_WeatherForecast;
            static get WeatherForecast()
            {
                let $cls = $.$n.NetJsBlazorDemo.Pages.Weather;
                return $cls.$_WeatherForecast ??= $asm.$ncls("$n.NetJsBlazorDemo.Pages.Weather.WeatherForecast", ($self) => class WeatherForecast extends $.$$.System.Object
                {
                    /*DateOnly*/ Date;
                    /*int*/ TemperatureC = 0;
                    /*string?*/ Summary = null;
                    /*int */ get TemperatureF()
                    {
                        return ((32 + $.$cast((this.TemperatureC / 0.5556), $.$$.System.Int32)) | 0);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Date = $.$default($.$$.System.DateOnly);
                    }
                    static $h = 776821;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":34209793,"g":{"r":0,"d":0,"h":12885678709,"f":50331649},"s":{"r":0,"d":0,"h":17180646005,"f":83886081},"n":"Date","d":776821,"h":8590711413,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30065547893,"f":50331649},"s":{"r":0,"d":0,"h":34360515189,"f":83886081},"n":"TemperatureC","d":776821,"h":25770580597,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47245417077,"f":50331649},"s":{"r":0,"d":0,"h":51540384373,"f":83886081},"n":"Summary","d":776821,"h":42950449781,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":60130318965,"f":50331649},"n":"TemperatureF","d":776821,"h":55835351669,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":776821,"h":64425286261,"f":16777217}],"d":711285,"h":776821}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `NetJsBlazorDemo.Pages.Weather.WeatherForecast`; }
                }, $cls, ($v) => $cls.$_WeatherForecast = $v);
            }
            /*HttpClient*/ Http = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Http = null;
            }
            static $h = 711285;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":6422573,"g":{"r":0,"d":0,"h":30065482357,"f":50331650},"s":{"r":0,"d":0,"h":34360449653,"f":83886082},"n":"Http","d":711285,"h":25770515061,"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":711285,"h":4295678581,"f":16809988},{"r":133169153,"n":"OnInitializedAsync","d":711285,"h":12885613173,"f":16814084}],"l":[{"t":$.$typeArray($.$n.NetJsBlazorDemo.Pages.Weather.WeatherForecast).$h,"n":"forecasts","d":711285,"h":8590645877,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":711285,"h":38655416949,"f":16777217}],"i":[2752520,3145736,3080200],"j":[776821],"h":711285,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/weather","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJsBlazorDemo.Pages.Weather`; }
        });
        
        $asm.$cls("$n.NetJsBlazorDemo.Layout.MainLayout", ($self) => class MainLayout extends $.$mac.Microsoft.AspNetCore.Components.LayoutComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$3(1, "class", "page");
                __builder.AddAttribute$5(2, "b-d90ig1dsad");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$3(4, "class", "sidebar");
                __builder.AddAttribute$5(5, "b-d90ig1dsad");
                __builder.OpenComponent$1($.$n.NetJsBlazorDemo.Layout.NavMenu, 6);
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n\r\n    ");
                __builder.OpenElement(8, "main");
                __builder.AddAttribute$5(9, "b-d90ig1dsad");
                __builder.AddMarkupContent(10, "<div class=\"top-row px-4\" b-d90ig1dsad><a href=\"https://learn.microsoft.com/aspnet/core/\" target=\"_blank\" b-d90ig1dsad>About</a></div>\r\n\r\n        ");
                __builder.OpenElement(11, "article");
                __builder.AddAttribute$3(12, "class", "content px-4");
                __builder.AddAttribute$5(13, "b-d90ig1dsad");
                __builder.AddContent$4(14, this.Body);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 383605;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4653064,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":383605,"h":4295350901,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":383605,"h":8590318197,"f":16777217}],"i":[2752520,3145736,3080200],"h":383605}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.LayoutComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJsBlazorDemo.Layout.MainLayout`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.CSharp", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"))