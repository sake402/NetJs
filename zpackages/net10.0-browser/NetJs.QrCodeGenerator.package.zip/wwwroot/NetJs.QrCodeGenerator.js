
//--TRIMMABLE-BOUNDARY-START(29535)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $sih, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $sri, $srsp, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    let _5a9aab29_5545_411e_9ab4_c6597d80cff7;
    let _8cf506c2_4bd9_4204_8373_cf3ed4850496;
    let _22b0abcd_17d5_4678_948b_03ea8b7e1bd4;
    let _b5577f2a_7821_4434_880c_85fda49e702c;
    let _4eea157b_3dce_4c93_8882_7c0d799cf880;
    let _cd828388_541b_4998_ba40_3ac743b98f36;
    let _74f09a91_b9b5_458b_81a1_a91d40df5f81;
    let _c4a14f61_36b2_42cc_a90b_187a58687bed;
    let _31ca7455_3394_429b_b9ed_de2c2db0554d;
    let _3e43b860_7ab5_48f8_aefc_9f1c32d4ce2c;
    let _74642940_ec41_4ffe_aa54_ee3b35612c55;
    let _e5aaf3e4_b213_4d3e_bfe7_1966d64f8333;
    let _95273c83_a1e9_428b_88dc_8611de9eb713;
    let _712f117a_fa32_4dab_b348_5ca52adf43e6;
    let _0aa2bb1b_76df_41fe_adb6_b65128f50900;
    let _9b514fc6_b9a6_453d_b66b_637f78bf7f23;
    let _12da453a_5db2_4716_a58a_1ed64227ffea;
    let _7951e441_828f_4841_a3e8_bbb5ac31c045;
    
    
    
	$.$asm(
    "NetJs.QrCodeGenerator", 
    {
  "h": 29535,
  "f": "QrCodeGenerator",
  "v": "3.2.1.0",
  "a": [
    {
      "t": 129957889,
      "c": 13014859777,
      "a": [
        {
          "v": "QrCodeGeneratorTest, PublicKey=0024000004800000940000000602000000240000525341310004000001000100796d6590d2f29b9af1686cdfdca1e10442f39af2e9b94ec8734f49c64f4c8d2dffc210f2fa4535202fda43da6bf4461f2449b47211c4a56cf54f3201c49eade13efb50c238d4919a1279f62cf17ea008311dddacff4e98ce60fa066ce1364a5bd2dea2a9dfac05f4985dcce4fc97f9857ae38c1c49031aa45ef443dc1ceebccd",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106692609,
      "c": 8696627201,
      "a": [
        {
          "v": "Codecrete",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 8696692737,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "Copyright (c) Manuel Bleichenbacher (MIT License)",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "QR Code Generator for .NET \u2013 simple, compact and with many examples.\n\nCore features:\n- Supports encoding all 40 versions (sizes) and all 4 error correction levels, as per the QR Code Model 2 standard\n- Output formats: List of rectangles, outline polygons, raw modules/pixels of the QR symbol, SVG, XAML path, PNG and BMP files. For other raster bitmap formats, see project home page.\n- Computes optimal segment modes for smallest possible QR code.\n- High speed: 10x faster than most comparable libraries\n- Open source code under the permissive *MIT License*\n- Built for .NET Standard 2.0 and therefore runs on most modern .NET platforms (.NET Core, .NET Framework, Mono etc.).\n- Example code for WinForms, WPF, ASP.NET, ImageSharp, SkiaSharp and many more\n\nAdvanced features:\n- Specify minimum and maximum version number allowed\n- Specify text encoding and use of ECI designators\n- Kanji mode for compact encoding of Japanese text\n- Create data segments manually\n- Split long text into multiple linked QR codes (aka Structured Append)\n- Opt-in encoding diagnostics: per-mask penalty breakdown and chosen segments\n",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "3.3.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107347969,
      "c": 8697282561,
      "a": [
        {
          "v": "3.3.0-dev\u002B8195680e84a3638f1bcf027294fefb5093d81ac6",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "QR Code Generator for .NET",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108331009,
      "c": 8698265601,
      "a": [
        {
          "v": "QrCodeGenerator",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108462081,
      "c": 8698396673,
      "a": [
        {
          "v": "3.2.1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107544577,
      "c": 12992446465,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/manuelbl/QrCodeGenerator",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159514625,
      "c": 13044416513,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(422751)
        $asm.$cls(`$wZnq.NCQ.DataSegment`, ($self) => class DataSegment extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(180389049183)
            /*DataSegmentMode*/ Mode = 0;
            //--TRIMMABLE-BOUNDARY-END(180389049183)
            
            //--TRIMMABLE-BOUNDARY-START(30065193823)
            /*ArraySegment<byte>*/ DataBytes;
            //--TRIMMABLE-BOUNDARY-END(30065193823)
            
            //--TRIMMABLE-BOUNDARY-START(34360161119)
            /*int */ get DataLength()
            {
                return this.DataBytes.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(34360161119)
            
            //--TRIMMABLE-BOUNDARY-START(21475259231)
            /*int */ get CharacterCount()
            {
                return this.DataBytes.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(21475259231)
            
            //--TRIMMABLE-BOUNDARY-START(42950095711)
            /*int*/ EncodedLength = 0;
            //--TRIMMABLE-BOUNDARY-END(42950095711)
            
            //--TRIMMABLE-BOUNDARY-START(158914212703)
            /*int */ GetTotalLength(/*int*/ version)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914212703);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (($.$wZnq.NCQ.DataSegment.GetHeaderLength(this.Mode, version) + this.EncodedLength) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914212703)
            
            //--TRIMMABLE-BOUNDARY-START(38655128415)
            /*ECI */ get EciDesignator()
            {
                return $.$wZnq.NCQ.ECI.None;
            }
            //--TRIMMABLE-BOUNDARY-END(38655128415)
            
            //--TRIMMABLE-BOUNDARY-START(206158852959)
            /*int */ get StructuredAppendPosition()
            {
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(206158852959)
            
            //--TRIMMABLE-BOUNDARY-START(210453820255)
            /*int */ get StructuredAppendTotal()
            {
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(210453820255)
            
            //--TRIMMABLE-BOUNDARY-START(201863885663)
            /*byte */ get StructuredAppendParity()
            {
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(201863885663)
            
            //--TRIMMABLE-BOUNDARY-START(51540030303)
            static /*List<DataSegment> */ FromText(/*string*/ text, /*ECI*/ eci, /*Encoding*/ encoding, /*int*/ version, /*KanjiStrategy*/ kanjiStrategy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540030303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.DataSegment.PrepareText(text, eci, encoding, kanjiStrategy).ToSegments(version);
            }
            //--TRIMMABLE-BOUNDARY-END(51540030303)
            
            //--TRIMMABLE-BOUNDARY-START(188978983775)
            static /*SegmentSource */ PrepareText(/*string*/ text, /*ECI*/ eci, /*Encoding*/ encoding, /*KanjiStrategy*/ kanjiStrategy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978983775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$$.S.String, text, "text");
                eci = eci ?? $.$wZnq.NCQ.ECI.Automatic;
                let $switch1 = eci.Value;
                switch($switch1)
                {
                    case -1/*ECI.AutomaticValue*/:
                    if ($.$wZnq.NCQ.DataSegment.IsLatin1(text))
                    {
                        encoding = $.$wZnq.NCQ.ECI.Latin1.GetEncoding();
                        eci = $.$wZnq.NCQ.ECI.None;
                    }
                    else 
                    {
                        eci = $.$wZnq.NCQ.ECI.UTF8;
                        encoding = $.$wZnq.NCQ.ECI.UTF8.GetEncoding();
                    }
                    break;
                    case -2/*ECI.NoneValue*/:
                    {
                        if (encoding === null)
                        {
                            throw new $.$$.S.ArgumentException().$ctor$13("Encoding must be specified for eci == ECI.None", "encoding");
                        }
                        break;
                    }
                    default:
                    encoding = encoding ?? eci.GetEncoding();
                    break;
                }
                /*var*/ let data = encoding.GetBytes$8(text);
                /*bool*/ let considerKanjiMode;
                switch(kanjiStrategy)
                {
                    case 1/*KanjiStrategy.Enabled*/:
                    considerKanjiMode = true;
                    break;
                    case 2/*KanjiStrategy.Disabled*/:
                    considerKanjiMode = false;
                    break;
                    default:
                    considerKanjiMode = $.$$.S.Object.Equals(eci, $.$wZnq.NCQ.ECI.ShiftJIS);
                    break;
                }
                return new $.$wZnq.NCQ.SegmentSource().$ctor$1(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$4(data), eci, considerKanjiMode);
            }
            //--TRIMMABLE-BOUNDARY-END(188978983775)
            
            //--TRIMMABLE-BOUNDARY-START(163209179999)
            static /*bool */ IsLatin1(/*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209179999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = $.$$.S.String.GetEnumerator.call(text);
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if (c > 255)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(163209179999)
            
            //--TRIMMABLE-BOUNDARY-START(47245063007)
            static /*List<DataSegment> */ FromBinaryData(/*byte[]*/ data, /*ECI*/ eci, /*int*/ version, /*bool*/ considerKanjiMode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245063007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.DataSegment.PrepareBinaryData(data, eci, considerKanjiMode).ToSegments(version);
            }
            //--TRIMMABLE-BOUNDARY-END(47245063007)
            
            //--TRIMMABLE-BOUNDARY-START(184684016479)
            static /*SegmentSource */ PrepareBinaryData(/*byte[]*/ data, /*ECI*/ eci, /*bool*/ considerKanjiMode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684016479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$typeArray($.$$.S.Byte), data, "data");
                return new $.$wZnq.NCQ.SegmentSource().$ctor$1(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$4(data), eci ?? $.$wZnq.NCQ.ECI.BinaryData, considerKanjiMode);
            }
            //--TRIMMABLE-BOUNDARY-END(184684016479)
            
            //--TRIMMABLE-BOUNDARY-START(25770226527)
            static /*BitStream */ CreateBitStream(/*List<DataSegment>*/ segments, /*int*/ version, /*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770226527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bitStream = new $.$wZnq.NCQ.BitStream().$ctor$1(capacity);
                var $en2 = segments.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var segment = $en2.Current;
                    {
                        /*var*/ let modeInfo = $.$wZnq.NCQ.DataSegmentModeInfo.For(segment.Mode);
                        bitStream.AppendBits((modeInfo.ModeIndicator >>> 0), 4);
                        if (modeInfo.HasCountIndicator)
                        {
                            bitStream.AppendBits((segment.CharacterCount >>> 0), modeInfo.GetCountIndicatorLength(version));
                        }
                        segment.WriteToBitStream(bitStream);
                    }
                }
                ;
                /*var*/ let terminatorLength = $.$$.S.Math.Min$4(4, ((((capacity * 8) | 0) - bitStream.Length) | 0));
                if (terminatorLength > 0)
                {
                    bitStream.AppendBits(0, terminatorLength);
                }
                return bitStream;
            }
            //--TRIMMABLE-BOUNDARY-END(25770226527)
            
            //--TRIMMABLE-BOUNDARY-START(150324278111)
            static /*uint */ GetModeIndicator(/*DataSegmentMode*/ mode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324278111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$wZnq.NCQ.DataSegmentModeInfo.For(mode).ModeIndicator >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(150324278111)
            
            //--TRIMMABLE-BOUNDARY-START(17180291935)
            $ctor$1(/*DataSegmentMode*/ mode, /*int*/ encodedLength)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180291935);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Mode = mode;
                    this.EncodedLength = encodedLength;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180291935)
            
            //--TRIMMABLE-BOUNDARY-START(171799114591)
            static /*DataSegment */ MakeSegment(/*DataSegmentMode*/ dataSegmentMode, /*ArraySegment<byte>*/ dataBytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799114591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$typeArray($.$$.S.Byte), dataBytes.Array, "dataBytes.Array");
                /*var*/ let create = $.$wZnq.NCQ.DataSegmentModeInfo.For(dataSegmentMode).Create;
                ;
                return create.Invoke(dataBytes);
            }
            //--TRIMMABLE-BOUNDARY-END(171799114591)
            
            //--TRIMMABLE-BOUNDARY-START(167504147295)
            static /*DataSegment */ MakeECISegment(/*ECI*/ designator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504147295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$wZnq.NCQ.DataSegmentEci().$ctor$2(designator);
            }
            //--TRIMMABLE-BOUNDARY-END(167504147295)
            
            //--TRIMMABLE-BOUNDARY-START(176094081887)
            static /*DataSegment */ MakeStructuredAppend(/*int*/ position, /*int*/ total, /*byte*/ parity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094081887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$wZnq.NCQ.DataSegmentStructuredAppend().$ctor$2(position, total, parity);
            }
            //--TRIMMABLE-BOUNDARY-END(176094081887)
            
            //--TRIMMABLE-BOUNDARY-START(133144408927)
            static /*int */ GetBitLength(/*DataSegmentMode*/ mode, /*int*/ length, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144408927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let info = $.$wZnq.NCQ.DataSegmentModeInfo.For(mode);
                ;
                return ((info.GetHeaderLength(version) + info.EncodedBitLength.Invoke(length)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(133144408927)
            
            //--TRIMMABLE-BOUNDARY-START(137439376223)
            static /*int */ GetBitLength$1(/*IEnumerable<DataSegment>*/ segments, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439376223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Sum$17($.$wZnq.NCQ.DataSegment, segments, new ($.$$.S.Func$$$($.$wZnq.NCQ.DataSegment, $.$$.S.Int32))().$ctor(this,  (/*segment*/ segment) =>
                {
                    return segment.GetTotalLength(version);
                }, _9b514fc6_b9a6_453d_b66b_637f78bf7f23 ??= {"r":655361,"p":[{"n":"segment","p":422751}],"n":"","d":422751,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(137439376223)
            
            //--TRIMMABLE-BOUNDARY-START(141734343519)
            static /*int */ GetByteCount(/*DataSegmentMode*/ mode, /*int*/ bitLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734343519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let info = $.$wZnq.NCQ.DataSegmentModeInfo.For(mode);
                ;
                return info.ByteCount.Invoke(bitLength);
            }
            //--TRIMMABLE-BOUNDARY-END(141734343519)
            
            //--TRIMMABLE-BOUNDARY-START(146029310815)
            static /*int */ GetHeaderLength(/*DataSegmentMode*/ mode, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029310815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.DataSegmentModeInfo.For(mode).GetHeaderLength(version);
            }
            //--TRIMMABLE-BOUNDARY-END(146029310815)
            
            //--TRIMMABLE-BOUNDARY-START(154619245407)
            static /*string */ GetText(/*IEnumerable<DataSegment>*/ segments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619245407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let encoding = $.$wZnq.NCQ.ECI.Latin1.GetEncoding();
                /*var*/ let text = new $.$$.ST.StringBuilder().$ctor$1();
                var $en2 = segments.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var segment = $en2.SCG$IEnumerator$$$Current;
                    {
                        let eci;
                        if ($.$is(segment, $.$wZnq.NCQ.DataSegmentEci, { set $v(v){ eci = v; } }))
                        {
                            encoding = eci.EciDesignator.GetEncoding();
                        }
                        else if ($.$is(segment, $.$wZnq.NCQ.DataSegmentStructuredAppend))
                        {
                        }
                        else 
                        {
                            /*var*/ let dataBytes = segment.DataBytes;
                            ;
                            text.Append$21(encoding.GetString(dataBytes.Array, dataBytes.Offset, dataBytes.Count));
                        }
                    }
                }
                return text.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(154619245407)
            
            //--TRIMMABLE-BOUNDARY-START(214748787551)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748787551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `[Mode: ${$.$$.S.Enum.ToStringT($.$wZnq.NCQ.DataSegmentMode, $.$$.S.UInt32, this.Mode)}; Data length: ${this.DataLength}]`;
            }
            //--TRIMMABLE-BOUNDARY-END(214748787551)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065193823)
                this.DataBytes = $.$default($.$$.S.ArraySegment$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(30065193823)
                
            }
            static $h = 422751;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(180389049183),
    {
      "p": 750431,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079637855,
        "f": 50331649
      },
      "n": "Mode",
      "d": 422751,
      "h": 180389049183,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389049183),
//--TRIMMABLE-BOUNDARY-START(30065193823),
    {
      "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719899487,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197568918367,
        "f": 83886084
      },
      "n": "DataBytes",
      "d": 422751,
      "h": 30065193823,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065193823),
//--TRIMMABLE-BOUNDARY-START(34360161119),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309834079,
        "f": 50331649
      },
      "n": "DataLength",
      "d": 422751,
      "h": 34360161119,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360161119),
//--TRIMMABLE-BOUNDARY-START(21475259231),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129964895,
        "f": 50331784
      },
      "n": "CharacterCount",
      "d": 422751,
      "h": 21475259231,
      "f": 2097288
    },
//--TRIMMABLE-BOUNDARY-END(21475259231),
//--TRIMMABLE-BOUNDARY-START(42950095711),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489703263,
        "f": 50331649
      },
      "n": "EncodedLength",
      "d": 422751,
      "h": 42950095711,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950095711),
//--TRIMMABLE-BOUNDARY-START(38655128415),
    {
      "p": 1078111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899768671,
        "f": 50331777
      },
      "n": "EciDesignator",
      "d": 422751,
      "h": 38655128415,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(38655128415),
//--TRIMMABLE-BOUNDARY-START(206158852959),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259507039,
        "f": 50331777
      },
      "n": "StructuredAppendPosition",
      "d": 422751,
      "h": 206158852959,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(206158852959),
//--TRIMMABLE-BOUNDARY-START(210453820255),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849441631,
        "f": 50331777
      },
      "n": "StructuredAppendTotal",
      "d": 422751,
      "h": 210453820255,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(210453820255),
//--TRIMMABLE-BOUNDARY-START(201863885663),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669572447,
        "f": 50331777
      },
      "n": "StructuredAppendParity",
      "d": 422751,
      "h": 201863885663,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(201863885663)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158914212703),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetTotalLength",
      "d": 422751,
      "h": 158914212703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914212703),
//--TRIMMABLE-BOUNDARY-START(51540030303),
    {
      "r": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "eci",
          "p": 1078111,
          "f": 65
        },
        {
          "n": "encoding",
          "p": 166199297,
          "f": 65
        },
        {
          "n": "version",
          "p": 655361,
          "f": 65,
          "v": 20
        },
        {
          "n": "kanjiStrategy",
          "p": 1340255,
          "f": 65,
          "v": 0
        }
      ],
      "n": "FromText",
      "d": 422751,
      "h": 51540030303,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540030303),
//--TRIMMABLE-BOUNDARY-START(188978983775),
    {
      "r": 2650975,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "eci",
          "p": 1078111
        },
        {
          "n": "encoding",
          "p": 166199297
        },
        {
          "n": "kanjiStrategy",
          "p": 1340255
        }
      ],
      "n": "PrepareText",
      "d": 422751,
      "h": 188978983775,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(188978983775),
//--TRIMMABLE-BOUNDARY-START(163209179999),
    {
      "r": 262145,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "IsLatin1",
      "d": 422751,
      "h": 163209179999,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(163209179999),
//--TRIMMABLE-BOUNDARY-START(47245063007),
    {
      "r": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "eci",
          "p": 1078111,
          "f": 65
        },
        {
          "n": "version",
          "p": 655361,
          "f": 65,
          "v": 20
        },
        {
          "n": "considerKanjiMode",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "FromBinaryData",
      "d": 422751,
      "h": 47245063007,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245063007),
//--TRIMMABLE-BOUNDARY-START(184684016479),
    {
      "r": 2650975,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "eci",
          "p": 1078111
        },
        {
          "n": "considerKanjiMode",
          "p": 262145
        }
      ],
      "n": "PrepareBinaryData",
      "d": 422751,
      "h": 184684016479,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(184684016479),
//--TRIMMABLE-BOUNDARY-START(25770226527),
    {
      "r": 226143,
      "p": [
        {
          "n": "segments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "CreateBitStream",
      "d": 422751,
      "h": 25770226527,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770226527),
//--TRIMMABLE-BOUNDARY-START(219043754847),
    {
      "r": 65537,
      "p": [
        {
          "n": "bitStream",
          "p": 226143
        }
      ],
      "n": "WriteToBitStream",
      "d": 422751,
      "h": 219043754847,
      "f": 16777480
    },
//--TRIMMABLE-BOUNDARY-END(219043754847),
//--TRIMMABLE-BOUNDARY-START(150324278111),
    {
      "r": 720897,
      "p": [
        {
          "n": "mode",
          "p": 750431
        }
      ],
      "n": "GetModeIndicator",
      "d": 422751,
      "h": 150324278111,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(150324278111),
//--TRIMMABLE-BOUNDARY-START(171799114591),
    {
      "r": 422751,
      "p": [
        {
          "n": "dataSegmentMode",
          "p": 750431
        },
        {
          "n": "dataBytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        }
      ],
      "n": "MakeSegment",
      "d": 422751,
      "h": 171799114591,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171799114591),
//--TRIMMABLE-BOUNDARY-START(167504147295),
    {
      "r": 422751,
      "p": [
        {
          "n": "designator",
          "p": 1078111
        }
      ],
      "n": "MakeECISegment",
      "d": 422751,
      "h": 167504147295,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167504147295),
//--TRIMMABLE-BOUNDARY-START(176094081887),
    {
      "r": 422751,
      "p": [
        {
          "n": "position",
          "p": 655361
        },
        {
          "n": "total",
          "p": 655361
        },
        {
          "n": "parity",
          "p": 393217
        }
      ],
      "n": "MakeStructuredAppend",
      "d": 422751,
      "h": 176094081887,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(176094081887),
//--TRIMMABLE-BOUNDARY-START(133144408927),
    {
      "r": 655361,
      "p": [
        {
          "n": "mode",
          "p": 750431
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetBitLength",
      "d": 422751,
      "h": 133144408927,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(133144408927),
//--TRIMMABLE-BOUNDARY-START(137439376223),
    {
      "r": 655361,
      "p": [
        {
          "n": "segments",
          "p": $.$$.SCG.IEnumerable$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetBitLength",
      "o": "@$1",
      "d": 422751,
      "h": 137439376223,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(137439376223),
//--TRIMMABLE-BOUNDARY-START(141734343519),
    {
      "r": 655361,
      "p": [
        {
          "n": "mode",
          "p": 750431
        },
        {
          "n": "bitLength",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "d": 422751,
      "h": 141734343519,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(141734343519),
//--TRIMMABLE-BOUNDARY-START(146029310815),
    {
      "r": 655361,
      "p": [
        {
          "n": "mode",
          "p": 750431
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetHeaderLength",
      "d": 422751,
      "h": 146029310815,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(146029310815),
//--TRIMMABLE-BOUNDARY-START(154619245407),
    {
      "r": 1310721,
      "p": [
        {
          "n": "segments",
          "p": $.$$.SCG.IEnumerable$$($.$wZnq.NCQ.DataSegment).$h
        }
      ],
      "n": "GetText",
      "d": 422751,
      "h": 154619245407,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154619245407),
//--TRIMMABLE-BOUNDARY-START(214748787551),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 422751,
      "h": 214748787551,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214748787551)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180291935),
    {
      "p": [
        {
          "n": "mode",
          "p": 750431
        },
        {
          "n": "encodedLength",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 422751,
      "h": 17180291935,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17180291935)
  ],
  "h": 422751
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(422751)
        
        

        //--TRIMMABLE-BOUNDARY-START(1209183)
        $asm.$cls(`$wZnq.NCQ.EncodingInfo`, ($self) => class EncodingInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835784031)
            /*PenaltyScore[]*/ Penalties = null;
            //--TRIMMABLE-BOUNDARY-END(55835784031)
            
            //--TRIMMABLE-BOUNDARY-START(21476045663)
            /*List<DataSegment>*/ DataSegments = null;
            //--TRIMMABLE-BOUNDARY-END(21476045663)
            
            //--TRIMMABLE-BOUNDARY-START(25771012959)
            /*int*/ ForcedDataMask = 0;
            //--TRIMMABLE-BOUNDARY-END(25771012959)
            
            //--TRIMMABLE-BOUNDARY-START(17181078367)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181078367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181078367)
            
            //--TRIMMABLE-BOUNDARY-START(17181078367)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181078367)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55835784031)
                this.Penalties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$wZnq.NCQ.PenaltyScore), null, [8], null);
                //--TRIMMABLE-BOUNDARY-END(55835784031)
                
                //--TRIMMABLE-BOUNDARY-START(25771012959)
                this.ForcedDataMask = -1;
                //--TRIMMABLE-BOUNDARY-END(25771012959)
                
            }
            static $h = 1209183;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835784031),
    {
      "p": $.$typeArray($.$wZnq.NCQ.PenaltyScore).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540816735,
        "f": 50331649
      },
      "n": "Penalties",
      "d": 1209183,
      "h": 55835784031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835784031),
//--TRIMMABLE-BOUNDARY-START(21476045663),
    {
      "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360947551,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425718623,
        "f": 83886081
      },
      "n": "DataSegments",
      "d": 1209183,
      "h": 21476045663,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476045663),
//--TRIMMABLE-BOUNDARY-START(25771012959),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950882143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015653215,
        "f": 83886081
      },
      "n": "ForcedDataMask",
      "d": 1209183,
      "h": 25771012959,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771012959)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181078367),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1209183,
      "h": 17181078367,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181078367)
  ],
  "h": 1209183
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.EncodingInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}EncodingInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1209183)
        
        

        //--TRIMMABLE-BOUNDARY-START(1536863)
        $asm.$cls(`$wZnq.NCQ.Objects`, ($self) => class Objects
        {
            //--TRIMMABLE-BOUNDARY-START(4296504159)
            static /*void */ RequireNonNull(T, /*T*/ arg, /*string*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296504159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$box(arg, T) === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19(paramName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296504159)
            
            static $h = 1536863;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296504159),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "RequireNonNull",
      "d": 1536863,
      "h": 4296504159,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4296504159)
  ],
  "h": 1536863
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.Objects`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}Objects`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1536863)
        
        

        //--TRIMMABLE-BOUNDARY-START(95071)
        $asm.$cls(`$wZnq.NCQ.ArraySegmentExtensions`, ($self) => class ArraySegmentExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295062367)
            static /*T */ At(T, /*this ArraySegment<T>*/ segment, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295062367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                return $.$$.System.Array.$ReadT1.call(segment.Array, ((segment.Offset + index) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(4295062367)
            
            //--TRIMMABLE-BOUNDARY-START(8590029663)
            static /*ArraySegment<T> */ MakeSlice(T, /*this ArraySegment<T>*/ segment, /*int*/ startIndex, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590029663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                return new ($.$$.S.ArraySegment$$(T))().$ctor$3(segment.Array, ((segment.Offset + startIndex) | 0), length);
            }
            //--TRIMMABLE-BOUNDARY-END(8590029663)
            
            static $h = 95071;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295062367),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "segment",
          "p": (T) => $.$$.S.ArraySegment$$(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": [
        "T"
      ],
      "n": "At",
      "d": 95071,
      "h": 4295062367,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295062367),
//--TRIMMABLE-BOUNDARY-START(8590029663),
    {
      "r": (T) => $.$$.S.ArraySegment$$(T).$h,
      "p": [
        {
          "n": "segment",
          "p": (T) => $.$$.S.ArraySegment$$(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "g": [
        "T"
      ],
      "n": "MakeSlice",
      "d": 95071,
      "h": 8590029663,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(8590029663)
  ],
  "h": 95071
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.ArraySegmentExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}ArraySegmentExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(95071)
        
        

        //--TRIMMABLE-BOUNDARY-START(1995615)
        $asm.$cls(`$wZnq.NCQ.QrCodeBuilder`, ($self) => class QrCodeBuilder
        {
            //--TRIMMABLE-BOUNDARY-START(4296962911)
            static /*QrCode */ Build(/*List<DataSegment>*/ dataSegments, /*int*/ ecc, /*int*/ minVersion, /*int*/ maxVersion, /*bool*/ boostEcc, /*EncodingInfo*/ encodingInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296962911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (encodingInfo !== null)
                {
                    encodingInfo.DataSegments = dataSegments;
                }
                /*var*/ let plan = $.$wZnq.NCQ.VersionPlanner.Plan(dataSegments, ecc, minVersion, maxVersion, boostEcc);
                /*var*/ let codewords = $.$wZnq.NCQ.Codewords.BuildData(dataSegments, plan.Item1, plan.Item2);
                codewords = $.$wZnq.NCQ.Codewords.AddErrorCorrection(codewords, plan.Item1, plan.Item2);
                return $.$wZnq.NCQ.MatrixEncoder.Encode(codewords, plan.Item1, plan.Item2, encodingInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(4296962911)
            
            static $h = 1995615;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296962911),
    {
      "r": 1864543,
      "p": [
        {
          "n": "dataSegments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "minVersion",
          "p": 655361,
          "f": 65,
          "v": 1
        },
        {
          "n": "maxVersion",
          "p": 655361,
          "f": 65,
          "v": 40
        },
        {
          "n": "boostEcc",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "encodingInfo",
          "p": 1209183,
          "f": 65
        }
      ],
      "n": "Build",
      "d": 1995615,
      "h": 4296962911,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296962911)
  ],
  "h": 1995615
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.QrCodeBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}QrCodeBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1995615)
        
        

        //--TRIMMABLE-BOUNDARY-START(357215)
        $asm.$cls(`$wZnq.NCQ.Codewords`, ($self) => class Codewords
        {
            //--TRIMMABLE-BOUNDARY-START(8590291807)
            static /*byte[] */ BuildData(/*List<DataSegment>*/ dataSegments, /*int*/ version, /*int*/ ecc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590291807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let capacity = $.$wZnq.NCQ.QrCodeParameters.GetCodewordDataCapacity(version, ecc);
                /*var*/ let bitStream = $.$wZnq.NCQ.DataSegment.CreateBitStream(dataSegments, version, capacity);
                /*var*/ let bitstreamLength = bitStream.Length;
                /*var*/ let result = bitStream.Buffer;
                for(/*var*/ let index = $.trunc((((bitstreamLength + 7) | 0)) / 8); index < capacity; index += 2)
                {
                    $.$$.System.Array.$WriteT1.call(result, 236, index);
                }
                for(/*var*/ let index = $.trunc((((bitstreamLength + 15) | 0)) / 8); index < capacity; index += 2)
                {
                    $.$$.System.Array.$WriteT1.call(result, 17, index);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(8590291807)
            
            //--TRIMMABLE-BOUNDARY-START(4295324511)
            static /*byte[] */ AddErrorCorrection(/*byte[]*/ codewords, /*int*/ version, /*int*/ ecc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295324511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let numDataCodewords = codewords.length;
                /*var*/ let numBlocks = $.$wZnq.NCQ.QrCodeParameters.GetNumBlocks(version, ecc);
                /*var*/ let smallBlockDataLength = $.trunc(numDataCodewords / numBlocks);
                /*var*/ let eccBlockLength = $.trunc(((($.$wZnq.NCQ.QrCodeParameters.GetCodewordCapacity(version) - numDataCodewords) | 0)) / numBlocks);
                /*var*/ let numLargeBlocks = numDataCodewords % numBlocks;
                /*var*/ let numSmallBlocks = ((numBlocks - numLargeBlocks) | 0);
                /*var*/ let result = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [$.$wZnq.NCQ.QrCodeParameters.GetCodewordCapacity(version)], null);
                /*var*/ let dataOffset = 0;
                /*var*/ let reedSolomon = $.$wZnq.NCQ.ReedSolomon.GeneratorForCapacity(eccBlockLength);
                for(/*var*/ let block = 0; block < numBlocks; block += 1)
                {
                    /*var*/ let dataLength = block < numSmallBlocks ? smallBlockDataLength : ((smallBlockDataLength + 1) | 0);
                    reedSolomon.ComputeErrorCorrection(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(codewords, dataOffset, dataLength), result, ((numDataCodewords + block) | 0), numBlocks);
                    for(/*var*/ let i = 0; i < smallBlockDataLength; i += 1)
                    {
                        $.$$.System.Array.$WriteT1.call(result, $.$$.System.Array.$ReadT1.call(codewords, ((dataOffset + i) | 0)), ((((i * numBlocks) | 0) + block) | 0));
                    }
                    if (block >= numSmallBlocks)
                    {
                        $.$$.System.Array.$WriteT1.call(result, $.$$.System.Array.$ReadT1.call(codewords, ((((dataOffset + dataLength) | 0) - 1) | 0)), ((((((numBlocks * smallBlockDataLength) | 0) + block) | 0) - numSmallBlocks) | 0));
                    }
                    dataOffset += dataLength;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(4295324511)
            
            static $h = 357215;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590291807),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "dataSegments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecc",
          "p": 655361
        }
      ],
      "n": "BuildData",
      "d": 357215,
      "h": 8590291807,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590291807),
//--TRIMMABLE-BOUNDARY-START(4295324511),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "codewords",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecc",
          "p": 655361
        }
      ],
      "n": "AddErrorCorrection",
      "d": 357215,
      "h": 4295324511,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295324511)
  ],
  "h": 357215
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.Codewords`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}Codewords`; }
        });
        //--TRIMMABLE-BOUNDARY-END(357215)
        
        

        //--TRIMMABLE-BOUNDARY-START(2650975)
        $asm.$cls(`$wZnq.NCQ.SegmentSource`, ($self) => class SegmentSource extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592585567)
            /*ArraySegment<byte>*/ _data;
            //--TRIMMABLE-BOUNDARY-END(8592585567)
            
            //--TRIMMABLE-BOUNDARY-START(12887552863)
            /*ECI*/ _eci = null;
            //--TRIMMABLE-BOUNDARY-END(12887552863)
            
            //--TRIMMABLE-BOUNDARY-START(4297618271)
            /*SegmentCompaction.Block[]*/ _blocks = null;
            //--TRIMMABLE-BOUNDARY-END(4297618271)
            
            //--TRIMMABLE-BOUNDARY-START(17182520159)
            $ctor$1(/*ArraySegment<byte>*/ data, /*ECI*/ eci, /*bool*/ considerKanjiMode)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182520159);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._data = data;
                    this._eci = eci;
                    this._blocks = $.$wZnq.NCQ.SegmentCompaction.BuildBlocks(data, considerKanjiMode);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182520159)
            
            //--TRIMMABLE-BOUNDARY-START(30067422047)
            /*int */ get MinBitLength()
            {
                return $.$wZnq.NCQ.SegmentCompaction.MinBitLength(this._blocks);
            }
            //--TRIMMABLE-BOUNDARY-END(30067422047)
            
            //--TRIMMABLE-BOUNDARY-START(34362389343)
            /*List<DataSegment> */ ToSegments(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362389343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let segments = $.$wZnq.NCQ.SegmentCompaction.BuildSegments(this._data, this._blocks, version);
                if (!$.$$.S.Object.Equals(this._eci, $.$wZnq.NCQ.ECI.None))
                {
                    segments.Insert(0, new $.$wZnq.NCQ.DataSegmentEci().$ctor$2(this._eci));
                }
                return segments;
            }
            //--TRIMMABLE-BOUNDARY-END(34362389343)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8592585567)
                this._data = $.$default($.$$.S.ArraySegment$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(8592585567)
                
            }
            static $h = 2650975;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067422047),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772454751,
        "f": 50331656
      },
      "n": "MinBitLength",
      "d": 2650975,
      "h": 30067422047,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(30067422047)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362389343),
    {
      "r": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "ToSegments",
      "d": 2650975,
      "h": 34362389343,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34362389343)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592585567),
    {
      "t": $.$$.S.ArraySegment$$($.$$.S.Byte).$h,
      "n": "_data",
      "d": 2650975,
      "h": 8592585567,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592585567),
//--TRIMMABLE-BOUNDARY-START(12887552863),
    {
      "t": 1078111,
      "n": "_eci",
      "d": 2650975,
      "h": 12887552863,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887552863),
//--TRIMMABLE-BOUNDARY-START(4297618271),
    {
      "t": $.$typeArray($.$wZnq.NCQ.SegmentCompaction.Block).$h,
      "n": "_blocks",
      "d": 2650975,
      "h": 4297618271,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297618271)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182520159),
    {
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "eci",
          "p": 1078111
        },
        {
          "n": "considerKanjiMode",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2650975,
      "h": 17182520159,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17182520159)
  ],
  "h": 2650975
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.SegmentSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}SegmentSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2650975)
        
        

        //--TRIMMABLE-BOUNDARY-START(2323295)
        $asm.$cls(`$wZnq.NCQ.RectangleBuilder`, ($self) => class RectangleBuilder
        {
            //--TRIMMABLE-BOUNDARY-START(4297290591)
            static /*IReadOnlyList<QrRectangle> */ Build(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297290591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let working = modules.Copy();
                /*var*/ let size = working.Size;
                /*var*/ let rectangles = new ($.$$.SCG.List$$($.$wZnq.NCQ.QrRectangle))().$ctor$1();
                for(/*var*/ let y = 0; y < size; y++)
                {
                    for(/*var*/ let x = 0; x < size; x++)
                    {
                        if (working.Get(x, y))
                        {
                            rectangles.Add($.$wZnq.NCQ.RectangleBuilder.ExtractLargestRectangle(working, x, y));
                        }
                    }
                }
                return rectangles;
            }
            //--TRIMMABLE-BOUNDARY-END(4297290591)
            
            //--TRIMMABLE-BOUNDARY-START(12887225183)
            static /*QrRectangle */ ExtractLargestRectangle(/*BitMatrix*/ modules, /*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887225183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = modules.Size;
                /*var*/ let bestW = 1;
                /*var*/ let bestH = 1;
                /*var*/ let maxArea = 1;
                /*var*/ let xLimit = size;
                /*var*/ let iy = y;
                while(iy < size && modules.Get(x, iy))
                {
                    /*var*/ let w = 0;
                    while(((x + w) | 0) < xLimit && modules.Get(((x + w) | 0), iy))
                    {
                        w++;
                    }
                    /*var*/ let area = ((w * (((((iy - y) | 0) + 1) | 0))) | 0);
                    if (area > maxArea)
                    {
                        maxArea = area;
                        bestW = w;
                        bestH = ((((iy - y) | 0) + 1) | 0);
                    }
                    xLimit = ((x + w) | 0);
                    iy++;
                }
                $.$wZnq.NCQ.RectangleBuilder.ClearRectangle(modules, x, y, bestW, bestH);
                return new $.$wZnq.NCQ.QrRectangle().$ctor$3(x, y, bestW, bestH);
            }
            //--TRIMMABLE-BOUNDARY-END(12887225183)
            
            //--TRIMMABLE-BOUNDARY-START(8592257887)
            static /*void */ ClearRectangle(/*BitMatrix*/ modules, /*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592257887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let iy = y; iy < ((y + height) | 0); iy++)
                {
                    for(/*var*/ let ix = x; ix < ((x + width) | 0); ix++)
                    {
                        modules.Set(ix, iy, false);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592257887)
            
            static $h = 2323295;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297290591),
    {
      "r": $.$$.SCG.IReadOnlyList$$($.$wZnq.NCQ.QrRectangle).$h,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "Build",
      "d": 2323295,
      "h": 4297290591,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297290591),
//--TRIMMABLE-BOUNDARY-START(12887225183),
    {
      "r": 2257759,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "ExtractLargestRectangle",
      "d": 2323295,
      "h": 12887225183,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12887225183),
//--TRIMMABLE-BOUNDARY-START(8592257887),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        },
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": "ClearRectangle",
      "d": 2323295,
      "h": 8592257887,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8592257887)
  ],
  "h": 2323295
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.RectangleBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}RectangleBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2323295)
        
        

        //--TRIMMABLE-BOUNDARY-START(226143)
        $asm.$cls(`$wZnq.NCQ.BitStream`, ($self) => class BitStream extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590160735)
            /*byte[]*/ _codewords = null;
            //--TRIMMABLE-BOUNDARY-END(8590160735)
            
            //--TRIMMABLE-BOUNDARY-START(4295193439)
            /*int*/ _capacity = 0;
            //--TRIMMABLE-BOUNDARY-END(4295193439)
            
            //--TRIMMABLE-BOUNDARY-START(17180095327)
            $ctor$1(/*int*/ capacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180095327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Length = 0;
                    this._capacity = capacity;
                    this._codewords = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [capacity], null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180095327)
            
            //--TRIMMABLE-BOUNDARY-START(55834800991)
            /*int*/ Length = 0;
            //--TRIMMABLE-BOUNDARY-END(55834800991)
            
            //--TRIMMABLE-BOUNDARY-START(21475062623)
            /*void */ AppendBits(/*uint*/ value, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475062623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (length <= 0 || length > 32)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("length", "length must be between 1 and 32");
                }
                if (length < 32 && value >>> length !== 0)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("value", "value must be in the range 0 <= value < 2^length");
                }
                /*var*/ let newLength = ((this.Length + length) | 0);
                if (newLength > ((this._capacity * 8) | 0))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("length", "adding the specified length exceeds the capacity");
                }
                /*var*/ let valueMask = (1 << (((length - 1) | 0))) >>> 0;
                for(/*var*/ let i = this.Length; i < newLength; i += 1)
                {
                    if ((value & valueMask) !== 0)
                    {
                        /*var*/ let codewordMask = ((((1 << (((7 - (i & 7)) | 0))) >>> 0) & 0xFF) >>> 0);
                        $.$$.System.Array.$WriteT1.call(this._codewords, $.$$.System.Array.$ReadT1.call(this._codewords, i >> 3) | codewordMask, i >> 3);
                    }
                    valueMask >>= 1;
                }
                this.Length = newLength;
            }
            //--TRIMMABLE-BOUNDARY-END(21475062623)
            
            //--TRIMMABLE-BOUNDARY-START(30064997215)
            /*uint */ ExtractBits(/*int*/ index, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064997215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (length <= 0 || length > 32)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("length", "length must be between 1 and 32");
                }
                if (index < 0 || ((index + length) | 0) > this.Length)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("index", "'index' out of range");
                }
                /*var*/ let result = 0;
                /*var*/ let valueMask = (1 << (((length - 1) | 0))) >>> 0;
                for(/*var*/ let i = index; i < ((index + length) | 0); i += 1)
                {
                    /*var*/ let codewordMask = ((((1 << (((7 - (i & 7)) | 0))) >>> 0) & 0xFF) >>> 0);
                    if (($.$$.System.Array.$ReadT1.call(this._codewords, i >> 3) & codewordMask) !== 0)
                    {
                        result |= valueMask;
                    }
                    valueMask >>= 1;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(30064997215)
            
            //--TRIMMABLE-BOUNDARY-START(51539833695)
            /*byte[] */ GetCodewords()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539833695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resultLength = (((this.Length + 7) | 0)) >> 3;
                /*var*/ let result = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [resultLength], null);
                $.$$.S.Array.Copy(this._codewords, 0, result, 0, resultLength);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(51539833695)
            
            //--TRIMMABLE-BOUNDARY-START(25770029919)
            /*byte[] */ get Buffer()
            {
                return this._codewords;
            }
            //--TRIMMABLE-BOUNDARY-END(25770029919)
            
            static $h = 226143;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834800991),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244866399,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424735583,
        "f": 83886082
      },
      "n": "Length",
      "d": 226143,
      "h": 55834800991,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55834800991),
//--TRIMMABLE-BOUNDARY-START(25770029919),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654931807,
        "f": 50331656
      },
      "n": "Buffer",
      "d": 226143,
      "h": 25770029919,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25770029919)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475062623),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AppendBits",
      "d": 226143,
      "h": 21475062623,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475062623),
//--TRIMMABLE-BOUNDARY-START(30064997215),
    {
      "r": 720897,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "ExtractBits",
      "d": 226143,
      "h": 30064997215,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30064997215),
//--TRIMMABLE-BOUNDARY-START(51539833695),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetCodewords",
      "d": 226143,
      "h": 51539833695,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51539833695)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590160735),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_codewords",
      "d": 226143,
      "h": 8590160735,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590160735),
//--TRIMMABLE-BOUNDARY-START(4295193439),
    {
      "t": 655361,
      "n": "_capacity",
      "d": 226143,
      "h": 4295193439,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295193439)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180095327),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 226143,
      "h": 17180095327,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180095327)
  ],
  "h": 226143
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.BitStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}BitStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(226143)
        
        

        //--TRIMMABLE-BOUNDARY-START(2847583)
        $asm.$cls(`$wZnq.NCQ.VersionPlanner`, ($self) => class VersionPlanner
        {
            //--TRIMMABLE-BOUNDARY-START(17182716767)
            static /*(int Version, int Ecc) */ Plan(/*List<DataSegment>*/ dataSegments, /*int*/ ecc, /*int*/ minVersion, /*int*/ maxVersion, /*bool*/ boostEcc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182716767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let  [ version, bitLength ] = $.$destructure($.$wZnq.NCQ.VersionPlanner.FindSmallestVersion(dataSegments, ecc, minVersion, maxVersion));
                if (boostEcc)
                {
                    while(ecc < 3 && $.$wZnq.NCQ.VersionPlanner.Fits$1(bitLength, version, ((ecc + 1) | 0)))
                    {
                        ecc += 1;
                    }
                }
                return new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(version, ecc);
            }
            //--TRIMMABLE-BOUNDARY-END(17182716767)
            
            //--TRIMMABLE-BOUNDARY-START(8592782175)
            static /*bool */ Fits(/*List<DataSegment>*/ dataSegments, /*int*/ ecc, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592782175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.VersionPlanner.Fits$1($.$wZnq.NCQ.DataSegment.GetBitLength$1(dataSegments, version), version, ecc);
            }
            //--TRIMMABLE-BOUNDARY-END(8592782175)
            
            //--TRIMMABLE-BOUNDARY-START(4297814879)
            static /*(int Version, int BitLength) */ FindSmallestVersion(/*List<DataSegment>*/ dataSegments, /*int*/ ecc, /*int*/ minVersion, /*int*/ maxVersion)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297814879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bitLength = 0;
                /*int*/ let version;
                for(version = minVersion; version <= maxVersion; version += 1)
                {
                    if (version === minVersion || version === 1 || version === 10 || version === 27)
                    {
                        bitLength = $.$wZnq.NCQ.DataSegment.GetBitLength$1(dataSegments, version);
                    }
                    if ($.$wZnq.NCQ.VersionPlanner.Fits$1(bitLength, version, ecc))
                    {
                        break;
                    }
                    if (version === maxVersion)
                    {
                        if (version < 40)
                        {
                            throw new $.$wZnq.NCQ.DataTooLongException().$ctor$15(`Data is too long to fit into a QR code with version ${version} and error correction level ${$.$$.S.Char.ToString.call($.$$.S.String.get_Chars.call("LMQH", ecc))}.`);
                        }
                        throw new $.$wZnq.NCQ.DataTooLongException().$ctor$15(`Data is too long to fit into a QR code with error correction level ${$.$$.S.Char.ToString.call($.$$.S.String.get_Chars.call("LMQH", ecc))}`);
                    }
                }
                return new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(version, bitLength);
            }
            //--TRIMMABLE-BOUNDARY-END(4297814879)
            
            //--TRIMMABLE-BOUNDARY-START(12887749471)
            static /*bool */ Fits$1(/*int*/ bitLength, /*int*/ version, /*int*/ ecc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887749471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return bitLength <= ((8 * $.$wZnq.NCQ.QrCodeParameters.GetCodewordDataCapacity(version, ecc)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(12887749471)
            
            static $h = 2847583;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182716767),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32).$h,
      "p": [
        {
          "n": "dataSegments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "minVersion",
          "p": 655361,
          "f": 65,
          "v": 1
        },
        {
          "n": "maxVersion",
          "p": 655361,
          "f": 65,
          "v": 40
        },
        {
          "n": "boostEcc",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Plan",
      "d": 2847583,
      "h": 17182716767,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17182716767),
//--TRIMMABLE-BOUNDARY-START(8592782175),
    {
      "r": 262145,
      "p": [
        {
          "n": "dataSegments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "Fits",
      "d": 2847583,
      "h": 8592782175,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592782175),
//--TRIMMABLE-BOUNDARY-START(4297814879),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32).$h,
      "p": [
        {
          "n": "dataSegments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "minVersion",
          "p": 655361
        },
        {
          "n": "maxVersion",
          "p": 655361
        }
      ],
      "n": "FindSmallestVersion",
      "d": 2847583,
      "h": 4297814879,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4297814879),
//--TRIMMABLE-BOUNDARY-START(12887749471),
    {
      "r": 262145,
      "p": [
        {
          "n": "bitLength",
          "p": 655361
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecc",
          "p": 655361
        }
      ],
      "n": "Fits",
      "o": "@$1",
      "d": 2847583,
      "h": 12887749471,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12887749471)
  ],
  "h": 2847583
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.VersionPlanner`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}VersionPlanner`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2847583)
        
        

        //--TRIMMABLE-BOUNDARY-START(291679)
        $asm.$cls(`$wZnq.NCQ.BmpBuilder`, ($self) => class BmpBuilder
        {
            //--TRIMMABLE-BOUNDARY-START(4295258975)
            static /*byte[] */ ToImage(/*QrCode*/ qrCode, /*int*/ border, /*int*/ scale, /*int*/ foreground, /*int*/ background)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295258975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (scale < 1)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("scale", $.$box(scale, $.$$.S.Int32), "Scale must be greater than 0.");
                }
                if (border < 0)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("border", $.$box(border, $.$$.S.Int32), "Border must be non-negative.");
                }
                /*var*/ let size = qrCode.Size;
                /*var*/ let dim = (((((size + ((2 * border) | 0)) | 0)) * scale) | 0);
                if (dim > 32767/*short.MaxValue*/)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("scale", "Scale or border too large.");
                }
                /*var*/ let bytesToWrite = ((((((dim - 1) | 0)) >> 3) + 1) | 0);
                /*var*/ let aligned = (((bytesToWrite + 3) | 0)) & ~3;
                /*var*/ let fileSize = ((62 + ((dim * aligned) | 0)) | 0);
                /*var*/ let buf = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [fileSize], null);
                $.$$.System.Array.$WriteT1.call(buf, /*B*/ 66, 0);
                $.$$.System.Array.$WriteT1.call(buf, /*M*/ 77, 1);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast(fileSize, $.$$.S.Byte), 2);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((fileSize >> 8), $.$$.S.Byte), 3);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((fileSize >> 16), $.$$.S.Byte), 4);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((fileSize >> 24), $.$$.S.Byte), 5);
                $.$$.System.Array.$WriteT1.call(buf, 62, 10);
                $.$$.System.Array.$WriteT1.call(buf, 40, 14);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast(dim, $.$$.S.Byte), 18);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((dim >> 8), $.$$.S.Byte), 19);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((dim >> 16), $.$$.S.Byte), 20);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((dim >> 24), $.$$.S.Byte), 21);
                $.$$.System.Array.$WriteT1.call(buf, $.$$.System.Array.$ReadT1.call(buf, 18), 22);
                $.$$.System.Array.$WriteT1.call(buf, $.$$.System.Array.$ReadT1.call(buf, 19), 23);
                $.$$.System.Array.$WriteT1.call(buf, $.$$.System.Array.$ReadT1.call(buf, 20), 24);
                $.$$.System.Array.$WriteT1.call(buf, $.$$.System.Array.$ReadT1.call(buf, 21), 25);
                $.$$.System.Array.$WriteT1.call(buf, 1, 26);
                $.$$.System.Array.$WriteT1.call(buf, 1, 28);
                $.$$.System.Array.$WriteT1.call(buf, 196, 38);
                $.$$.System.Array.$WriteT1.call(buf, 14, 39);
                $.$$.System.Array.$WriteT1.call(buf, $.$$.System.Array.$ReadT1.call(buf, 38), 42);
                $.$$.System.Array.$WriteT1.call(buf, $.$$.System.Array.$ReadT1.call(buf, 39), 43);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast(foreground, $.$$.S.Byte), 54);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((foreground >> 8), $.$$.S.Byte), 55);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((foreground >> 16), $.$$.S.Byte), 56);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast(background, $.$$.S.Byte), 58);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((background >> 8), $.$$.S.Byte), 59);
                $.$$.System.Array.$WriteT1.call(buf, $.$cast((background >> 16), $.$$.S.Byte), 60);
                /*var*/ let scaledBorder = ((border * scale) | 0);
                /*int*/ let i;
                /*int*/ let y;
                /*byte*/ let px;
                if (border > 0)
                {
                    /*var*/ let scaledSize = ((size * scale) | 0);
                    for(i = 0; i < aligned; ++i)
                    {
                        px = 255;
                        if (i === ((bytesToWrite - 1) | 0))
                        {
                            px = $.$cast((255 << ((((bytesToWrite << 3) - dim) | 0))), $.$$.S.Byte);
                        }
                        else if (i >= bytesToWrite)
                        {
                            px = 0;
                        }
                        for(y = 0; y < scaledBorder; ++y)
                        {
                            $.$$.System.Array.$WriteT1.call(buf, px, ((((62 + i) | 0) + ((y * aligned) | 0)) | 0));
                            $.$$.System.Array.$WriteT1.call(buf, px, ((((62 + i) | 0) + (((((((y + scaledSize) | 0) + scaledBorder) | 0)) * aligned) | 0)) | 0));
                        }
                    }
                }
                for(y = 0; y < size; ++y)
                {
                    /*int*/ let j;
                    /*var*/ let yOffset = ((((y * scale) | 0) + scaledBorder) | 0);
                    for(i = 0; i < aligned; ++i)
                    {
                        px = 0;
                        for(j = 0; j < 8; ++j)
                        {
                            /*var*/ let x = $.trunc(((((i << 3) + j) | 0)) / scale);
                            if (x >= dim)
                            {
                                continue;
                            }
                            if (x < border || x >= ((size + border) | 0))
                            {
                                px |= $.$cast((1 << (((7 - j) | 0))), $.$$.S.Byte);
                                continue;
                            }
                            px |= $.$cast((qrCode.GetModule(((x - border) | 0), ((((size - y) | 0) - 1) | 0)) ? 0 : 1 << (((7 - j) | 0))), $.$$.S.Byte);
                        }
                        $.$$.System.Array.$WriteT1.call(buf, px, ((((62 + i) | 0) + ((yOffset * aligned) | 0)) | 0));
                    }
                    for(i = 1; i <= ((scale - 1) | 0); ++i)
                    {
                        for(j = 0; j < aligned; ++j)
                        {
                            $.$$.System.Array.$WriteT1.call(buf, $.$$.System.Array.$ReadT1.call(buf, ((((62 + j) | 0) + ((yOffset * aligned) | 0)) | 0)), ((((62 + j) | 0) + (((((yOffset + i) | 0)) * aligned) | 0)) | 0));
                        }
                    }
                }
                return buf;
            }
            //--TRIMMABLE-BOUNDARY-END(4295258975)
            
            static $h = 291679;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295258975),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "qrCode",
          "p": 1864543
        },
        {
          "n": "border",
          "p": 655361
        },
        {
          "n": "scale",
          "p": 655361
        },
        {
          "n": "foreground",
          "p": 655361
        },
        {
          "n": "background",
          "p": 655361
        }
      ],
      "n": "ToImage",
      "d": 291679,
      "h": 4295258975,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295258975)
  ],
  "h": 291679
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.BmpBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}BmpBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(291679)
        
        

        //--TRIMMABLE-BOUNDARY-START(2782047)
        $asm.$cls(`$wZnq.NCQ.SvgBuilder`, ($self) => class SvgBuilder
        {
            //--TRIMMABLE-BOUNDARY-START(12887683935)
            static /*string */ ToSvgString(/*QrCode*/ qrCode, /*int*/ border, /*string*/ foreground, /*string*/ background)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887683935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (border < 0)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("border", "Border must be non-negative");
                }
                $.$wZnq.NCQ.Objects.RequireNonNull($.$$.S.String, foreground, "foreground");
                /*var*/ let dim = ((qrCode.Size + ((border * 2) | 0)) | 0);
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1().Append$21("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n").Append$21("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\n").Append$1(`<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" viewBox=\"0 0 ${dim} ${dim}\" stroke=\"none\">\n`);
                if ($.$$.S.String.op_Inequality(background, null))
                {
                    sb.Append$1(`\t<rect width=\"100%\" height=\"100%\" fill=\"${background}\"/>\n`);
                }
                sb.Append$21("\t<path d=\"");
                $.$wZnq.NCQ.SvgBuilder.AppendPath(sb, qrCode.ToOutlines(), border);
                return sb.Append$1(`\" fill=\"${foreground}\" shape-rendering=\"crispEdges\"/>\n`).Append$21("</svg>\n").ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(12887683935)
            
            //--TRIMMABLE-BOUNDARY-START(8592716639)
            static /*string */ ToGraphicsPath(/*QrCode*/ qrCode, /*int*/ border)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592716639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (border < 0)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("border", "Border must be non-negative");
                }
                /*var*/ let path = new $.$$.ST.StringBuilder().$ctor$1();
                $.$wZnq.NCQ.SvgBuilder.AppendPath(path, qrCode.ToOutlines(), border);
                return path.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(8592716639)
            
            //--TRIMMABLE-BOUNDARY-START(4297749343)
            static /*void */ AppendPath(/*StringBuilder*/ path, /*IReadOnlyList<QrPolygon>*/ polygons, /*int*/ border)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297749343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = 0; i < polygons.SCG$IReadOnlyCollection$$$Count; i++)
                {
                    /*var*/ let vertices = polygons.SCG$IReadOnlyList$$$get_Item(i).Vertices;
                    if (i !== 0)
                    {
                        path.Append$5(/* */ 32);
                    }
                    /*var*/ let first = vertices.SCG$IReadOnlyList$$$get_Item(0);
                    path.Append$21($.$$.S.FormattableString.Invariant(`M${((first.X + border) | 0)},${((first.Y + border) | 0)}`));
                    for(/*var*/ let j = 1; j < vertices.SCG$IReadOnlyCollection$$$Count; j++)
                    {
                        /*var*/ let $from = vertices.SCG$IReadOnlyList$$$get_Item(((j - 1) | 0));
                        /*var*/ let to = vertices.SCG$IReadOnlyList$$$get_Item(j);
                        if (to.Y === $from.Y)
                        {
                            path.Append$21($.$$.S.FormattableString.Invariant(`h${((to.X - $from.X) | 0)}`));
                        }
                        else 
                        {
                            path.Append$21($.$$.S.FormattableString.Invariant(`v${((to.Y - $from.Y) | 0)}`));
                        }
                    }
                    path.Append$5(/*z*/ 122);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297749343)
            
            static $h = 2782047;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887683935),
    {
      "r": 1310721,
      "p": [
        {
          "n": "qrCode",
          "p": 1864543
        },
        {
          "n": "border",
          "p": 655361
        },
        {
          "n": "foreground",
          "p": 1310721
        },
        {
          "n": "background",
          "p": 1310721
        }
      ],
      "n": "ToSvgString",
      "d": 2782047,
      "h": 12887683935,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12887683935),
//--TRIMMABLE-BOUNDARY-START(8592716639),
    {
      "r": 1310721,
      "p": [
        {
          "n": "qrCode",
          "p": 1864543
        },
        {
          "n": "border",
          "p": 655361
        }
      ],
      "n": "ToGraphicsPath",
      "d": 2782047,
      "h": 8592716639,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592716639),
//--TRIMMABLE-BOUNDARY-START(4297749343),
    {
      "r": 65537,
      "p": [
        {
          "n": "path",
          "p": 167313409
        },
        {
          "n": "polygons",
          "p": $.$$.SCG.IReadOnlyList$$($.$wZnq.NCQ.QrPolygon).$h
        },
        {
          "n": "border",
          "p": 655361
        }
      ],
      "n": "AppendPath",
      "d": 2782047,
      "h": 4297749343,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4297749343)
  ],
  "h": 2782047
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.SvgBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}SvgBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2782047)
        
        

        //--TRIMMABLE-BOUNDARY-START(815967)
        $asm.$cls(`$wZnq.NCQ.DataSegmentModeInfo`, ($self) => class DataSegmentModeInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065587039)
            $ctor$1(/*int*/ modeIndicator, /*int[]*/ countIndicatorWidths, /*Func<int, int>*/ encodedBitLength, /*Func<int, int>*/ byteCount, /*Func<ArraySegment<byte>, DataSegment>*/ create)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065587039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ModeIndicator = modeIndicator;
                    this._countIndicatorWidths = countIndicatorWidths;
                    this.EncodedBitLength = encodedBitLength;
                    this.ByteCount = byteCount;
                    this.Create = create;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065587039)
            
            //--TRIMMABLE-BOUNDARY-START(115964932959)
            /*int*/ ModeIndicator = 0;
            //--TRIMMABLE-BOUNDARY-END(115964932959)
            
            //--TRIMMABLE-BOUNDARY-START(4295783263)
            /*int[]*/ _countIndicatorWidths = null;
            //--TRIMMABLE-BOUNDARY-END(4295783263)
            
            //--TRIMMABLE-BOUNDARY-START(51540423519)
            /*Func<int, int>*/ EncodedBitLength = null;
            //--TRIMMABLE-BOUNDARY-END(51540423519)
            
            //--TRIMMABLE-BOUNDARY-START(42950488927)
            /*Func<int, int>*/ ByteCount = null;
            //--TRIMMABLE-BOUNDARY-END(42950488927)
            
            //--TRIMMABLE-BOUNDARY-START(47245456223)
            /*Func<ArraySegment<byte>, DataSegment>*/ Create = null;
            //--TRIMMABLE-BOUNDARY-END(47245456223)
            
            //--TRIMMABLE-BOUNDARY-START(111669965663)
            /*bool */ get HasCountIndicator()
            {
                return this._countIndicatorWidths !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(111669965663)
            
            //--TRIMMABLE-BOUNDARY-START(103080031071)
            /*int */ GetCountIndicatorLength(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080031071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasCountIndicator ? $.$$.System.Array.$ReadT1.call(this._countIndicatorWidths, $.trunc((((version + 7) | 0)) / 17)) : 0;
            }
            //--TRIMMABLE-BOUNDARY-END(103080031071)
            
            //--TRIMMABLE-BOUNDARY-START(107374998367)
            /*int */ GetHeaderLength(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374998367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((4 + this.GetCountIndicatorLength(version)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(107374998367)
            
            //--TRIMMABLE-BOUNDARY-START(55835390815)
            static /*DataSegmentModeInfo */ For(/*DataSegmentMode*/ mode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835390815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.DataSegmentModeInfo.ByMode, mode);
            }
            //--TRIMMABLE-BOUNDARY-END(55835390815)
            
            //--TRIMMABLE-BOUNDARY-START(38655521631)
            /*DataSegmentModeInfo[]*/ static ByMode = null;
            //--TRIMMABLE-BOUNDARY-END(38655521631)
            
            //--TRIMMABLE-BOUNDARY-START(34360554335)
            static /*DataSegmentModeInfo[] */ BuildTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360554335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let table = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$wZnq.NCQ.DataSegmentModeInfo), null, [7], null);
                $.$$.System.Array.$WriteT1.call(table, new $.$wZnq.NCQ.DataSegmentModeInfo().$ctor$1(1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [10, 12, 14], null, null), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor($.$wZnq.NCQ.DataSegmentNumeric, $.$wZnq.NCQ.DataSegmentNumeric.GetNumericBitLength), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor($.$wZnq.NCQ.DataSegmentNumeric, $.$wZnq.NCQ.DataSegmentNumeric.GetNumericByteCount), new ($.$$.S.Func$$$($.$$.S.ArraySegment$$($.$$.S.Byte), $.$wZnq.NCQ.DataSegment))().$ctor(this,  (/*bytes*/ bytes) =>
                {
                    return new $.$wZnq.NCQ.DataSegmentNumeric().$ctor$2(bytes);
                }, _5a9aab29_5545_411e_9ab4_c6597d80cff7 ??= {"r":422751,"p":[{"n":"bytes","p":$.$$.S.ArraySegment$$($.$$.S.Byte).$h}],"n":"","d":815967,"h":0,"f":17825794})), 1/*DataSegmentMode.Numeric*/);
                $.$$.System.Array.$WriteT1.call(table, new $.$wZnq.NCQ.DataSegmentModeInfo().$ctor$1(2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [9, 11, 13], null, null), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor($.$wZnq.NCQ.DataSegmentAlphanumeric, $.$wZnq.NCQ.DataSegmentAlphanumeric.GetAlphanumericBitLength), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor($.$wZnq.NCQ.DataSegmentAlphanumeric, $.$wZnq.NCQ.DataSegmentAlphanumeric.GetAlphanumericByteCount), new ($.$$.S.Func$$$($.$$.S.ArraySegment$$($.$$.S.Byte), $.$wZnq.NCQ.DataSegment))().$ctor(this,  (/*bytes*/ bytes) =>
                {
                    return new $.$wZnq.NCQ.DataSegmentAlphanumeric().$ctor$2(bytes);
                }, _8cf506c2_4bd9_4204_8373_cf3ed4850496 ??= {"r":422751,"p":[{"n":"bytes","p":$.$$.S.ArraySegment$$($.$$.S.Byte).$h}],"n":"","d":815967,"h":0,"f":17825794})), 2/*DataSegmentMode.Alphanumeric*/);
                $.$$.System.Array.$WriteT1.call(table, new $.$wZnq.NCQ.DataSegmentModeInfo().$ctor$1(8, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [8, 10, 12], null, null), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor($.$wZnq.NCQ.DataSegmentKanji, $.$wZnq.NCQ.DataSegmentKanji.GetKanjiBitLength), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor($.$wZnq.NCQ.DataSegmentKanji, $.$wZnq.NCQ.DataSegmentKanji.GetKanjiByteCount), new ($.$$.S.Func$$$($.$$.S.ArraySegment$$($.$$.S.Byte), $.$wZnq.NCQ.DataSegment))().$ctor(this,  (/*bytes*/ bytes) =>
                {
                    return new $.$wZnq.NCQ.DataSegmentKanji().$ctor$2(bytes);
                }, _22b0abcd_17d5_4678_948b_03ea8b7e1bd4 ??= {"r":422751,"p":[{"n":"bytes","p":$.$$.S.ArraySegment$$($.$$.S.Byte).$h}],"n":"","d":815967,"h":0,"f":17825794})), 3/*DataSegmentMode.Kanji*/);
                $.$$.System.Array.$WriteT1.call(table, new $.$wZnq.NCQ.DataSegmentModeInfo().$ctor$1(4, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [8, 16, 16], null, null), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor($.$wZnq.NCQ.DataSegmentByte, $.$wZnq.NCQ.DataSegmentByte.GetByteBitLength), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor($.$wZnq.NCQ.DataSegmentByte, $.$wZnq.NCQ.DataSegmentByte.GetByteByteCount), new ($.$$.S.Func$$$($.$$.S.ArraySegment$$($.$$.S.Byte), $.$wZnq.NCQ.DataSegment))().$ctor(this,  (/*bytes*/ bytes) =>
                {
                    return new $.$wZnq.NCQ.DataSegmentByte().$ctor$2(bytes);
                }, _b5577f2a_7821_4434_880c_85fda49e702c ??= {"r":422751,"p":[{"n":"bytes","p":$.$$.S.ArraySegment$$($.$$.S.Byte).$h}],"n":"","d":815967,"h":0,"f":17825794})), 4/*DataSegmentMode.Binary*/);
                $.$$.System.Array.$WriteT1.call(table, new $.$wZnq.NCQ.DataSegmentModeInfo().$ctor$1(7, null, null, null, null), 5/*DataSegmentMode.ECI*/);
                $.$$.System.Array.$WriteT1.call(table, new $.$wZnq.NCQ.DataSegmentModeInfo().$ctor$1(3, null, null, null, null), 6/*DataSegmentMode.StructuredAppend*/);
                return table;
            }
            //--TRIMMABLE-BOUNDARY-END(34360554335)
            
            //--TRIMMABLE-BOUNDARY-START(25770619743)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770619743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(38655521631)
                    this.ByMode = $.$wZnq.NCQ.DataSegmentModeInfo.BuildTable();
                    //--TRIMMABLE-BOUNDARY-END(38655521631)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770619743)
            
            static $h = 815967;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964932959),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785063775,
        "f": 50331656
      },
      "n": "ModeIndicator",
      "d": 815967,
      "h": 115964932959,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(115964932959),
//--TRIMMABLE-BOUNDARY-START(51540423519),
    {
      "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605194591,
        "f": 50331656
      },
      "n": "EncodedBitLength",
      "d": 815967,
      "h": 51540423519,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51540423519),
//--TRIMMABLE-BOUNDARY-START(42950488927),
    {
      "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425325407,
        "f": 50331656
      },
      "n": "ByteCount",
      "d": 815967,
      "h": 42950488927,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42950488927),
//--TRIMMABLE-BOUNDARY-START(47245456223),
    {
      "p": $.$$.S.Func$$$($.$$.S.ArraySegment$$($.$$.S.Byte), $.$wZnq.NCQ.DataSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015259999,
        "f": 50331656
      },
      "n": "Create",
      "d": 815967,
      "h": 47245456223,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(47245456223),
//--TRIMMABLE-BOUNDARY-START(111669965663),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195129183,
        "f": 50331656
      },
      "n": "HasCountIndicator",
      "d": 815967,
      "h": 111669965663,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(111669965663)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103080031071),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetCountIndicatorLength",
      "d": 815967,
      "h": 103080031071,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(103080031071),
//--TRIMMABLE-BOUNDARY-START(107374998367),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetHeaderLength",
      "d": 815967,
      "h": 107374998367,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(107374998367),
//--TRIMMABLE-BOUNDARY-START(55835390815),
    {
      "r": 815967,
      "p": [
        {
          "n": "mode",
          "p": 750431
        }
      ],
      "n": "For",
      "d": 815967,
      "h": 55835390815,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835390815),
//--TRIMMABLE-BOUNDARY-START(34360554335),
    {
      "r": $.$typeArray($.$wZnq.NCQ.DataSegmentModeInfo).$h,
      "n": "BuildTable",
      "d": 815967,
      "h": 34360554335,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360554335)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295783263),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "_countIndicatorWidths",
      "d": 815967,
      "h": 4295783263,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295783263),
//--TRIMMABLE-BOUNDARY-START(38655521631),
    {
      "t": $.$typeArray($.$wZnq.NCQ.DataSegmentModeInfo).$h,
      "n": "ByMode",
      "d": 815967,
      "h": 38655521631,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655521631)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065587039),
    {
      "p": [
        {
          "n": "modeIndicator",
          "p": 655361
        },
        {
          "n": "countIndicatorWidths",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "encodedBitLength",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32).$h,
          "f": 65
        },
        {
          "n": "byteCount",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32).$h,
          "f": 65
        },
        {
          "n": "create",
          "p": $.$$.S.Func$$$($.$$.S.ArraySegment$$($.$$.S.Byte), $.$wZnq.NCQ.DataSegment).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 815967,
      "h": 30065587039,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065587039)
  ],
  "h": 815967
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegmentModeInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegmentModeInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(815967)
        
        

        //--TRIMMABLE-BOUNDARY-START(2061151)
        $asm.$cls(`$wZnq.NCQ.QrCodeParameters`, ($self) => class QrCodeParameters
        {
            //--TRIMMABLE-BOUNDARY-START(51541668703)
            static /*int */ GetSize(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541668703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((17 + ((version * 4) | 0)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(51541668703)
            
            //--TRIMMABLE-BOUNDARY-START(34361799519)
            static /*int */ GetCodewordDataCapacity(/*int*/ version, /*int*/ ecc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361799519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.QrCodeParameters.CodewordDataCapacity.$ReadT([ecc, ((version - 1) | 0)]);
            }
            //--TRIMMABLE-BOUNDARY-END(34361799519)
            
            //--TRIMMABLE-BOUNDARY-START(17181930335)
            /*int[,]*/ static CodewordDataCapacity = null;
            //--TRIMMABLE-BOUNDARY-END(17181930335)
            
            //--TRIMMABLE-BOUNDARY-START(47246701407)
            static /*int */ GetNumBlocks(/*int*/ version, /*int*/ ecc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246701407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.QrCodeParameters.NumBlocks.$ReadT([ecc, ((version - 1) | 0)]);
            }
            //--TRIMMABLE-BOUNDARY-END(47246701407)
            
            //--TRIMMABLE-BOUNDARY-START(60131603295)
            /*int[,]*/ static NumBlocks = null;
            //--TRIMMABLE-BOUNDARY-END(60131603295)
            
            //--TRIMMABLE-BOUNDARY-START(30066832223)
            static /*int */ GetCodewordCapacity(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066832223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.QrCodeParameters.CodewordCapacity, ((version - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(30066832223)
            
            //--TRIMMABLE-BOUNDARY-START(12886963039)
            /*int[]*/ static CodewordCapacity = null;
            //--TRIMMABLE-BOUNDARY-END(12886963039)
            
            //--TRIMMABLE-BOUNDARY-START(25771864927)
            static /*int[] */ GetAlignmentPatternPosition(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771864927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.QrCodeParameters.AlignmentPatternPosition, ((version - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(25771864927)
            
            //--TRIMMABLE-BOUNDARY-START(8591995743)
            /*int[][]*/ static AlignmentPatternPosition = null;
            //--TRIMMABLE-BOUNDARY-END(8591995743)
            
            //--TRIMMABLE-BOUNDARY-START(38656766815)
            static /*int */ GetErrorCorrectionLevelBits(/*int*/ level)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656766815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return level ^ 1;
            }
            //--TRIMMABLE-BOUNDARY-END(38656766815)
            
            //--TRIMMABLE-BOUNDARY-START(42951734111)
            static /*int */ GetFormatInformationBits(/*int*/ ecc, /*int*/ pattern)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951734111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.QrCodeParameters.FormatInformationBits, (((ecc << 3) + pattern) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(42951734111)
            
            //--TRIMMABLE-BOUNDARY-START(21476897631)
            /*int[]*/ static FormatInformationBits = null;
            //--TRIMMABLE-BOUNDARY-END(21476897631)
            
            //--TRIMMABLE-BOUNDARY-START(55836635999)
            static /*int */ GetVersionInformationBits(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836635999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.QrCodeParameters.VersionInformationBits, ((version - 7) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(55836635999)
            
            //--TRIMMABLE-BOUNDARY-START(64426570591)
            /*int[]*/ static VersionInformationBits = null;
            //--TRIMMABLE-BOUNDARY-END(64426570591)
            
            //--TRIMMABLE-BOUNDARY-START(4297028447)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297028447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17181930335)
                    this.CodewordDataCapacity = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [19, 34, 55, 80, 108, 136, 156, 194, 232, 274, 324, 370, 428, 461, 523, 589, 647, 721, 795, 861, 932, 1006, 1094, 1174, 1276, 1370, 1468, 1531, 1631, 1735, 1843, 1955, 2071, 2191, 2306, 2434, 2566, 2702, 2812, 2956, 16, 28, 44, 64, 86, 108, 124, 154, 182, 216, 254, 290, 334, 365, 415, 453, 507, 563, 627, 669, 714, 782, 860, 914, 1000, 1062, 1128, 1193, 1267, 1373, 1455, 1541, 1631, 1725, 1812, 1914, 1992, 2102, 2216, 2334, 13, 22, 34, 48, 62, 76, 88, 110, 132, 154, 180, 206, 244, 261, 295, 325, 367, 397, 445, 485, 512, 568, 614, 664, 718, 754, 808, 871, 911, 985, 1033, 1115, 1171, 1231, 1286, 1354, 1426, 1502, 1582, 1666, 9, 16, 26, 36, 46, 60, 66, 86, 100, 122, 140, 158, 180, 197, 223, 253, 283, 313, 341, 385, 406, 442, 464, 514, 538, 596, 628, 661, 701, 745, 793, 845, 901, 961, 986, 1054, 1096, 1142, 1222, 1276], [4, 40], null);
                    //--TRIMMABLE-BOUNDARY-END(17181930335)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60131603295)
                    this.NumBlocks = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81], [4, 40], null);
                    //--TRIMMABLE-BOUNDARY-END(60131603295)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886963039)
                    this.CodewordCapacity = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12886963039)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591995743)
                    this.AlignmentPatternPosition = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$$.S.Int32)), [$.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [0], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 18], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 22], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 34], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 22, 38], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 24, 42], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26, 46], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 28, 50], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 54], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 32, 58], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 34, 62], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26, 46, 66], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26, 48, 70], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26, 50, 74], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 54, 78], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 56, 82], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 58, 86], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 34, 62, 90], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 28, 50, 72, 94], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26, 50, 74, 98], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 54, 78, 102], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 28, 54, 80, 106], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 32, 58, 84, 110], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 58, 86, 114], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 34, 62, 90, 118], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26, 50, 74, 98, 122], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 54, 78, 102, 126], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26, 52, 78, 104, 130], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 56, 82, 108, 134], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 34, 60, 86, 112, 138], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 58, 86, 114, 142], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 34, 62, 90, 118, 146], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 54, 78, 102, 126, 150], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 24, 50, 76, 102, 128, 154], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 28, 54, 80, 106, 132, 158], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 32, 58, 84, 110, 136, 162], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 26, 54, 82, 110, 138, 166], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [6, 30, 58, 86, 114, 142, 170], null, null)], null, null);
                    //--TRIMMABLE-BOUNDARY-END(8591995743)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476897631)
                    this.FormatInformationBits = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [30660, 29427, 32170, 30877, 26159, 25368, 27713, 26998, 21522, 20773, 24188, 23371, 17913, 16590, 20375, 19104, 13663, 12392, 16177, 14854, 9396, 8579, 11994, 11245, 5769, 5054, 7399, 6608, 1890, 597, 3340, 2107], null, null);
                    //--TRIMMABLE-BOUNDARY-END(21476897631)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64426570591)
                    this.VersionInformationBits = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [31892, 34236, 39577, 42195, 48118, 51042, 55367, 58893, 63784, 68472, 70749, 76311, 79154, 84390, 87683, 92361, 96236, 102084, 102881, 110507, 110734, 117786, 119615, 126325, 127568, 133589, 136944, 141498, 145311, 150283, 152622, 158308, 161089, 167017], null, null);
                    //--TRIMMABLE-BOUNDARY-END(64426570591)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297028447)
            
            static $h = 2061151;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541668703),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetSize",
      "d": 2061151,
      "h": 51541668703,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51541668703),
//--TRIMMABLE-BOUNDARY-START(34361799519),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecc",
          "p": 655361
        }
      ],
      "n": "GetCodewordDataCapacity",
      "d": 2061151,
      "h": 34361799519,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34361799519),
//--TRIMMABLE-BOUNDARY-START(47246701407),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecc",
          "p": 655361
        }
      ],
      "n": "GetNumBlocks",
      "d": 2061151,
      "h": 47246701407,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246701407),
//--TRIMMABLE-BOUNDARY-START(30066832223),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetCodewordCapacity",
      "d": 2061151,
      "h": 30066832223,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30066832223),
//--TRIMMABLE-BOUNDARY-START(25771864927),
    {
      "r": $.$typeArray($.$$.S.Int32).$h,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetAlignmentPatternPosition",
      "d": 2061151,
      "h": 25771864927,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25771864927),
//--TRIMMABLE-BOUNDARY-START(38656766815),
    {
      "r": 655361,
      "p": [
        {
          "n": "level",
          "p": 655361
        }
      ],
      "n": "GetErrorCorrectionLevelBits",
      "d": 2061151,
      "h": 38656766815,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38656766815),
//--TRIMMABLE-BOUNDARY-START(42951734111),
    {
      "r": 655361,
      "p": [
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "pattern",
          "p": 655361
        }
      ],
      "n": "GetFormatInformationBits",
      "d": 2061151,
      "h": 42951734111,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42951734111),
//--TRIMMABLE-BOUNDARY-START(55836635999),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetVersionInformationBits",
      "d": 2061151,
      "h": 55836635999,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55836635999)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181930335),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "CodewordDataCapacity",
      "d": 2061151,
      "h": 17181930335,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181930335),
//--TRIMMABLE-BOUNDARY-START(60131603295),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "NumBlocks",
      "d": 2061151,
      "h": 60131603295,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131603295),
//--TRIMMABLE-BOUNDARY-START(12886963039),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "CodewordCapacity",
      "d": 2061151,
      "h": 12886963039,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886963039),
//--TRIMMABLE-BOUNDARY-START(8591995743),
    {
      "t": $.$typeArray($.$typeArray($.$$.S.Int32)).$h,
      "n": "AlignmentPatternPosition",
      "d": 2061151,
      "h": 8591995743,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591995743),
//--TRIMMABLE-BOUNDARY-START(21476897631),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "FormatInformationBits",
      "d": 2061151,
      "h": 21476897631,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21476897631),
//--TRIMMABLE-BOUNDARY-START(64426570591),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "VersionInformationBits",
      "d": 2061151,
      "h": 64426570591,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64426570591)
  ],
  "h": 2061151
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.QrCodeParameters`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}QrCodeParameters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2061151)
        
        

        //--TRIMMABLE-BOUNDARY-START(1602399)
        $asm.$cls(`$wZnq.NCQ.OutlineBuilder`, ($self) => class OutlineBuilder
        {
            //--TRIMMABLE-BOUNDARY-START(30066373471)
            /*int[]*/ static StepX = null;
            //--TRIMMABLE-BOUNDARY-END(30066373471)
            
            //--TRIMMABLE-BOUNDARY-START(34361340767)
            /*int[]*/ static StepY = null;
            //--TRIMMABLE-BOUNDARY-END(34361340767)
            
            //--TRIMMABLE-BOUNDARY-START(12886504287)
            /*int*/ static East = 0;
            //--TRIMMABLE-BOUNDARY-END(12886504287)
            
            //--TRIMMABLE-BOUNDARY-START(25771406175)
            /*int*/ static South = 1;
            //--TRIMMABLE-BOUNDARY-END(25771406175)
            
            //--TRIMMABLE-BOUNDARY-START(47246242655)
            /*int*/ static West = 2;
            //--TRIMMABLE-BOUNDARY-END(47246242655)
            
            //--TRIMMABLE-BOUNDARY-START(8591536991)
            static /*IReadOnlyList<QrPolygon> */ Build(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591536991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = modules.Size;
                /*var*/ let walkedEastEdges = new $.$wZnq.NCQ.BitMatrix().$ctor$3(size);
                /*var*/ let polygons = new ($.$$.SCG.List$$($.$wZnq.NCQ.QrPolygon))().$ctor$1();
                for(/*var*/ let y = 0; y < size; y++)
                {
                    for(/*var*/ let x = 0; x < size; x++)
                    {
                        if (modules.Get(x, y) && !$.$wZnq.NCQ.OutlineBuilder.IsDark(modules, x, ((y - 1) | 0)) && !walkedEastEdges.Get(x, y))
                        {
                            polygons.Add($.$wZnq.NCQ.OutlineBuilder.TraceLoop(modules, walkedEastEdges, x, y));
                        }
                    }
                }
                polygons.Sort$2(new ($.$$.S.Comparison$$($.$wZnq.NCQ.QrPolygon))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                {
                    /*var*/ let startA = a.Vertices.SCG$IReadOnlyList$$$get_Item(0);
                    /*var*/ let startB = b.Vertices.SCG$IReadOnlyList$$$get_Item(0);
                    return startA.Y !== startB.Y ? ((startA.Y - startB.Y) | 0) : ((startA.X - startB.X) | 0);
                }, _4eea157b_3dce_4c93_8882_7c0d799cf880 ??= {"r":655361,"p":[{"n":"a","p":2192223},{"n":"b","p":2192223}],"n":"","d":1602399,"h":0,"f":17825794}));
                return polygons;
            }
            //--TRIMMABLE-BOUNDARY-END(8591536991)
            
            //--TRIMMABLE-BOUNDARY-START(38656308063)
            static /*QrPolygon */ TraceLoop(/*BitMatrix*/ modules, /*BitMatrix*/ walkedEastEdges, /*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656308063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let vertices = new ($.$$.SCG.List$$($.$wZnq.NCQ.QrPoint))().$ctor$1();
                /*var*/ let vx = x;
                /*var*/ let vy = y;
                /*var*/ let direction = 0/*East*/;
                do
                {
                    if (direction === 0/*East*/)
                    {
                        walkedEastEdges.Set(vx, vy, true);
                    }
                    vx += $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.OutlineBuilder.StepX, direction);
                    vy += $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.OutlineBuilder.StepY, direction);
                    /*var*/ let turned = $.$wZnq.NCQ.OutlineBuilder.Turn(modules, vx, vy, direction);
                    if (turned !== direction)
                    {
                        vertices.Add(new $.$wZnq.NCQ.QrPoint().$ctor$3(vx, vy));
                        direction = turned;
                    }
                }
                while(vx !== x || vy !== y || direction !== 0/*East*/);
                return new $.$wZnq.NCQ.QrPolygon().$ctor$1($.$wZnq.NCQ.OutlineBuilder.RotateToTopLeft(vertices));
            }
            //--TRIMMABLE-BOUNDARY-END(38656308063)
            
            //--TRIMMABLE-BOUNDARY-START(42951275359)
            static /*int */ Turn(/*BitMatrix*/ modules, /*int*/ x, /*int*/ y, /*int*/ direction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951275359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let aheadRight;
                /*bool*/ let aheadLeft;
                switch(direction)
                {
                    case 0/*East*/:
                    aheadRight = $.$wZnq.NCQ.OutlineBuilder.IsDark(modules, x, y);
                    aheadLeft = $.$wZnq.NCQ.OutlineBuilder.IsDark(modules, x, ((y - 1) | 0));
                    break;
                    case 1/*South*/:
                    aheadRight = $.$wZnq.NCQ.OutlineBuilder.IsDark(modules, ((x - 1) | 0), y);
                    aheadLeft = $.$wZnq.NCQ.OutlineBuilder.IsDark(modules, x, y);
                    break;
                    case 2/*West*/:
                    aheadRight = $.$wZnq.NCQ.OutlineBuilder.IsDark(modules, ((x - 1) | 0), ((y - 1) | 0));
                    aheadLeft = $.$wZnq.NCQ.OutlineBuilder.IsDark(modules, ((x - 1) | 0), y);
                    break;
                    default:
                    aheadRight = $.$wZnq.NCQ.OutlineBuilder.IsDark(modules, x, ((y - 1) | 0));
                    aheadLeft = $.$wZnq.NCQ.OutlineBuilder.IsDark(modules, ((x - 1) | 0), ((y - 1) | 0));
                    break;
                }
                if (!aheadRight)
                {
                    return (((direction + 1) | 0)) % 4;
                }
                return aheadLeft ? (((direction + 3) | 0)) % 4 : direction;
            }
            //--TRIMMABLE-BOUNDARY-END(42951275359)
            
            //--TRIMMABLE-BOUNDARY-START(17181471583)
            static /*bool */ IsDark(/*BitMatrix*/ modules, /*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181471583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = modules.Size;
                return 0 <= x && x < size && 0 <= y && y < size && modules.Get(x, y);
            }
            //--TRIMMABLE-BOUNDARY-END(17181471583)
            
            //--TRIMMABLE-BOUNDARY-START(21476438879)
            static /*List<QrPoint> */ RotateToTopLeft(/*List<QrPoint>*/ vertices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476438879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let start = 0;
                for(/*var*/ let i = 1; i < vertices.Count; i++)
                {
                    /*var*/ let vertex = vertices.get_Item(i);
                    /*var*/ let best = vertices.get_Item(start);
                    if (vertex.Y < best.Y || (vertex.Y === best.Y && vertex.X < best.X))
                    {
                        start = i;
                    }
                }
                if (start === 0)
                {
                    return vertices;
                }
                /*var*/ let rotated = new ($.$$.SCG.List$$($.$wZnq.NCQ.QrPoint))().$ctor$3(vertices.Count);
                rotated.AddRange(vertices.GetRange(start, ((vertices.Count - start) | 0)));
                rotated.AddRange(vertices.GetRange(0, start));
                return rotated;
            }
            //--TRIMMABLE-BOUNDARY-END(21476438879)
            
            //--TRIMMABLE-BOUNDARY-START(4296569695)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296569695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30066373471)
                    this.StepX = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [1, 0, -1, 0], null, null);
                    //--TRIMMABLE-BOUNDARY-END(30066373471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361340767)
                    this.StepY = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [0, 1, 0, -1], null, null);
                    //--TRIMMABLE-BOUNDARY-END(34361340767)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296569695)
            
            static $h = 1602399;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591536991),
    {
      "r": $.$$.SCG.IReadOnlyList$$($.$wZnq.NCQ.QrPolygon).$h,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "Build",
      "d": 1602399,
      "h": 8591536991,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591536991),
//--TRIMMABLE-BOUNDARY-START(38656308063),
    {
      "r": 2192223,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "walkedEastEdges",
          "p": 160607
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "TraceLoop",
      "d": 1602399,
      "h": 38656308063,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656308063),
//--TRIMMABLE-BOUNDARY-START(42951275359),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        },
        {
          "n": "direction",
          "p": 655361
        }
      ],
      "n": "Turn",
      "d": 1602399,
      "h": 42951275359,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42951275359),
//--TRIMMABLE-BOUNDARY-START(17181471583),
    {
      "r": 262145,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "IsDark",
      "d": 1602399,
      "h": 17181471583,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181471583),
//--TRIMMABLE-BOUNDARY-START(21476438879),
    {
      "r": $.$$.SCG.List$$($.$wZnq.NCQ.QrPoint).$h,
      "p": [
        {
          "n": "vertices",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.QrPoint).$h
        }
      ],
      "n": "RotateToTopLeft",
      "d": 1602399,
      "h": 21476438879,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476438879)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066373471),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "StepX",
      "d": 1602399,
      "h": 30066373471,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30066373471),
//--TRIMMABLE-BOUNDARY-START(34361340767),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "StepY",
      "d": 1602399,
      "h": 34361340767,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34361340767),
//--TRIMMABLE-BOUNDARY-START(12886504287),
    {
      "t": 655361,
      "n": "East",
      "d": 1602399,
      "h": 12886504287,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886504287),
//--TRIMMABLE-BOUNDARY-START(25771406175),
    {
      "t": 655361,
      "n": "South",
      "d": 1602399,
      "h": 25771406175,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771406175),
//--TRIMMABLE-BOUNDARY-START(47246242655),
    {
      "t": 655361,
      "n": "West",
      "d": 1602399,
      "h": 47246242655,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47246242655)
  ],
  "h": 1602399
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.OutlineBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}OutlineBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1602399)
        
        

        //--TRIMMABLE-BOUNDARY-START(1799007)
        $asm.$cls(`$wZnq.NCQ.PngBuilder`, ($self) => class PngBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64426308447)
            /*byte[]*/ static Signature = null;
            //--TRIMMABLE-BOUNDARY-END(64426308447)
            
            //--TRIMMABLE-BOUNDARY-START(25771602783)
            /*uint[]*/ static CrcTable = null;
            //--TRIMMABLE-BOUNDARY-END(25771602783)
            
            //--TRIMMABLE-BOUNDARY-START(51541406559)
            /*byte[]*/ static IHDR = null;
            //--TRIMMABLE-BOUNDARY-END(51541406559)
            
            //--TRIMMABLE-BOUNDARY-START(55836373855)
            /*byte[]*/ static PLTE = null;
            //--TRIMMABLE-BOUNDARY-END(55836373855)
            
            //--TRIMMABLE-BOUNDARY-START(42951471967)
            /*byte[]*/ static IDAT = null;
            //--TRIMMABLE-BOUNDARY-END(42951471967)
            
            //--TRIMMABLE-BOUNDARY-START(47246439263)
            /*byte[]*/ static IEND = null;
            //--TRIMMABLE-BOUNDARY-END(47246439263)
            
            //--TRIMMABLE-BOUNDARY-START(68721275743)
            static /*byte[] */ ToImage(/*QrCode*/ qrCode, /*int*/ scale, /*int*/ border, /*int*/ foreground, /*int*/ background)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721275743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let imageSize = (((((qrCode.Size + ((border * 2) | 0)) | 0)) * scale) | 0);
                /*var*/ let builder = new $.$wZnq.NCQ.PngBuilder().$ctor$1();
                builder.WriteHeader(imageSize, imageSize, 1, 3);
                builder.WritePalette($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [background, foreground], null, null));
                builder.WriteData($.$wZnq.NCQ.PngBuilder.CreateBitmap(qrCode, border, scale));
                builder.WriteEnd();
                return builder.GetBytes();
            }
            //--TRIMMABLE-BOUNDARY-END(68721275743)
            
            //--TRIMMABLE-BOUNDARY-START(30066570079)
            static /*byte[] */ CreateBitmap(/*QrCode*/ qrCode, /*int*/ border, /*int*/ scale)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066570079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = qrCode.Size;
                /*var*/ let imageSize = (((((size + ((border * 2) | 0)) | 0)) * scale) | 0);
                /*var*/ let bytesPerLine = (($.trunc((((imageSize + 7) | 0)) / 8) + 1) | 0);
                /*var*/ let data = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((bytesPerLine * imageSize) | 0)], null);
                for(/*var*/ let y = 0; y < size; y++)
                {
                    /*var*/ let offset = (((((((border + y) | 0)) * scale) | 0) * bytesPerLine) | 0);
                    for(/*var*/ let x = 0; x < size; x++)
                    {
                        if (!qrCode.GetModule(x, y))
                        {
                            continue;
                        }
                        /*var*/ let pos = (((((border + x) | 0)) * scale) | 0);
                        /*var*/ let end = ((pos + scale) | 0);
                        for(; pos < end; pos++)
                        {
                            /*var*/ let index = ((((offset + $.trunc(pos / 8)) | 0) + 1) | 0);
                            $.$$.System.Array.$WriteT1.call(data, $.$$.System.Array.$ReadT1.call(data, index) | (((128 >>> (pos % 8)) & 0xFF) >>> 0), index);
                        }
                    }
                    for(/*var*/ let i = 1; i < scale; i++)
                    {
                        $.$$.S.Array.Copy(data, offset, data, ((offset + ((i * bytesPerLine) | 0)) | 0), bytesPerLine);
                    }
                }
                return data;
            }
            //--TRIMMABLE-BOUNDARY-END(30066570079)
            
            //--TRIMMABLE-BOUNDARY-START(4296766303)
            /*MemoryStream*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(4296766303)
            
            //--TRIMMABLE-BOUNDARY-START(38656504671)
            /*byte[] */ GetBytes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656504671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bytes = this._stream.ToArray();
                $.$wZnq.NCQ.PngBuilder.SetCRC(bytes);
                return bytes;
            }
            //--TRIMMABLE-BOUNDARY-END(38656504671)
            
            //--TRIMMABLE-BOUNDARY-START(90196112223)
            /*void */ WriteHeader(/*int*/ width, /*int*/ height, /*byte*/ bitDepth, /*byte*/ colorType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196112223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stream.Write($.$wZnq.NCQ.PngBuilder.Signature, 0, $.$wZnq.NCQ.PngBuilder.Signature.length);
                this.WriteChunkStart($.$wZnq.NCQ.PngBuilder.IHDR, 13);
                this.WriteIntBigEndian((width >>> 0));
                this.WriteIntBigEndian((height >>> 0));
                this._stream.WriteByte(bitDepth);
                this._stream.WriteByte(colorType);
                this._stream.WriteByte(0);
                this._stream.WriteByte(0);
                this._stream.WriteByte(0);
                this.WriteChunkEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(90196112223)
            
            //--TRIMMABLE-BOUNDARY-START(98786046815)
            /*void */ WritePalette(/*int[]*/ palette)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786046815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteChunkStart($.$wZnq.NCQ.PngBuilder.PLTE, ((palette.length * 3) | 0));
                let $i1 = 0;
                let $arr1 = palette;
                while ($i1 < $arr1.length)
                {
                    let color = $arr1[$i1++];
                    this._stream.WriteByte($.$cast(((color >> 16) & 255), $.$$.S.Byte));
                    this._stream.WriteByte($.$cast(((color >> 8) & 255), $.$$.S.Byte));
                    this._stream.WriteByte($.$cast((color & 255), $.$$.S.Byte));
                }
                this.WriteChunkEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(98786046815)
            
            //--TRIMMABLE-BOUNDARY-START(81606177631)
            /*void */ WriteData(/*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606177631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let compressedData = $.$wZnq.NCQ.PngBuilder.Deflate(data);
                this.WriteChunkStart($.$wZnq.NCQ.PngBuilder.IDAT, ((compressedData.length + 6) | 0));
                this._stream.WriteByte(120);
                this._stream.WriteByte(156);
                this._stream.Write(compressedData, 0, compressedData.length);
                /*var*/ let adler = $.$wZnq.NCQ.PngBuilder.CalcAdler32(data, 0, data.length);
                this.WriteIntBigEndian(adler);
                this.WriteChunkEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(81606177631)
            
            //--TRIMMABLE-BOUNDARY-START(85901144927)
            /*void */ WriteEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901144927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteChunkStart($.$wZnq.NCQ.PngBuilder.IEND, 0);
                this.WriteChunkEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(85901144927)
            
            //--TRIMMABLE-BOUNDARY-START(60131341151)
            static /*void */ SetCRC(/*byte[]*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131341151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let chunkOffset = $.$wZnq.NCQ.PngBuilder.Signature.length;
                while(chunkOffset < bytes.length)
                {
                    /*var*/ let dataLength = (($.$$.System.Array.$ReadT1.call(bytes, chunkOffset) << 24) >>> 0) | (($.$$.System.Array.$ReadT1.call(bytes, ((chunkOffset + 1) | 0)) << 16) >>> 0) | (($.$$.System.Array.$ReadT1.call(bytes, ((chunkOffset + 2) | 0)) << 8) >>> 0) | $.$$.System.Array.$ReadT1.call(bytes, ((chunkOffset + 3) | 0));
                    /*var*/ let crc = $.$wZnq.NCQ.PngBuilder.CalcCrc32(bytes, ((chunkOffset + 4) | 0), ((dataLength + 4) | 0));
                    /*var*/ let crcOffset = ((((chunkOffset + 8) | 0) + dataLength) | 0);
                    $.$$.System.Array.$WriteT1.call(bytes, (((crc >>> 24) & 0xFF) >>> 0), ((crcOffset + 0) | 0));
                    $.$$.System.Array.$WriteT1.call(bytes, (((crc >>> 16) & 0xFF) >>> 0), ((crcOffset + 1) | 0));
                    $.$$.System.Array.$WriteT1.call(bytes, (((crc >>> 8) & 0xFF) >>> 0), ((crcOffset + 2) | 0));
                    $.$$.System.Array.$WriteT1.call(bytes, ((crc & 0xFF) >>> 0), ((crcOffset + 3) | 0));
                    chunkOffset = ((crcOffset + 4) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131341151)
            
            //--TRIMMABLE-BOUNDARY-START(77311210335)
            /*void */ WriteChunkStart(/*byte[]*/ type, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311210335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteIntBigEndian((length >>> 0));
                this._stream.Write(type, 0, 4);
            }
            //--TRIMMABLE-BOUNDARY-END(77311210335)
            
            //--TRIMMABLE-BOUNDARY-START(73016243039)
            /*void */ WriteChunkEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016243039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stream.SetLength(BigInt.asIntN(64, this._stream.Length + 4n));
                this._stream.Position += 4n;
            }
            //--TRIMMABLE-BOUNDARY-END(73016243039)
            
            //--TRIMMABLE-BOUNDARY-START(94491079519)
            /*void */ WriteIntBigEndian(/*uint*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491079519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stream.WriteByte((((value >>> 24) & 0xFF) >>> 0));
                this._stream.WriteByte((((value >>> 16) & 0xFF) >>> 0));
                this._stream.WriteByte((((value >>> 8) & 0xFF) >>> 0));
                this._stream.WriteByte(((value & 0xFF) >>> 0));
            }
            //--TRIMMABLE-BOUNDARY-END(94491079519)
            
            //--TRIMMABLE-BOUNDARY-START(34361537375)
            static /*byte[] */ Deflate(/*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361537375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let output = new $.$$.SI.MemoryStream().$ctor$3();
                let deflater = null;
                try
                {
                    deflater = new $.$sic.SIC.DeflateStream().$ctor$5(output, 0/*CompressionLevel.Optimal*/);
                    deflater.Write(data, 0, data.length);
                }
                finally
                {
                    deflater?.S$IDisposable$Dispose();
                }
                return output.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(34361537375)
            
            //--TRIMMABLE-BOUNDARY-START(17181668191)
            static /*uint */ CalcAdler32(/*byte[]*/ data, /*int*/ index, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181668191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let base = 65521;
                /*uint*/ let s1 = 1;
                /*uint*/ let s2 = 0;
                /*var*/ let end = ((index + length) | 0);
                for(/*var*/ let n = index; n < end; n++)
                {
                    s1 = (((s1 + $.$$.System.Array.$ReadT1.call(data, n)) >>> 0)) % base;
                    s2 = (((s2 + s1) >>> 0)) % base;
                }
                return ((((s2 << 16) >>> 0) + s1) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17181668191)
            
            //--TRIMMABLE-BOUNDARY-START(21476635487)
            static /*uint */ CalcCrc32(/*byte[]*/ data, /*int*/ index, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476635487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let c = 4294967295;
                /*var*/ let end = ((index + length) | 0);
                for(/*var*/ let n = index; n < end; n++)
                {
                    c = $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.PngBuilder.CrcTable, (c ^ $.$$.System.Array.$ReadT1.call(data, n)) & 255) ^ (c >>> 8);
                }
                return c ^ 4294967295;
            }
            //--TRIMMABLE-BOUNDARY-END(21476635487)
            
            //--TRIMMABLE-BOUNDARY-START(12886700895)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886700895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886700895)
            
            //--TRIMMABLE-BOUNDARY-START(12886700895)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886700895)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296766303)
                this._stream = new $.$$.SI.MemoryStream().$ctor$3();
                //--TRIMMABLE-BOUNDARY-END(4296766303)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8591733599)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591733599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(64426308447)
                    this.Signature = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [137, 80, 78, 71, 13, 10, 26, 10], null, null);
                    //--TRIMMABLE-BOUNDARY-END(64426308447)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771602783)
                    this.CrcTable = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.UInt32), [0, 1996959894, 3993919788, 2567524794, 124634137, 1886057615, 3915621685, 2657392035, 249268274, 2044508324, 3772115230, 2547177864, 162941995, 2125561021, 3887607047, 2428444049, 498536548, 1789927666, 4089016648, 2227061214, 450548861, 1843258603, 4107580753, 2211677639, 325883990, 1684777152, 4251122042, 2321926636, 335633487, 1661365465, 4195302755, 2366115317, 997073096, 1281953886, 3579855332, 2724688242, 1006888145, 1258607687, 3524101629, 2768942443, 901097722, 1119000684, 3686517206, 2898065728, 853044451, 1172266101, 3705015759, 2882616665, 651767980, 1373503546, 3369554304, 3218104598, 565507253, 1454621731, 3485111705, 3099436303, 671266974, 1594198024, 3322730930, 2970347812, 795835527, 1483230225, 3244367275, 3060149565, 1994146192, 31158534, 2563907772, 4023717930, 1907459465, 112637215, 2680153253, 3904427059, 2013776290, 251722036, 2517215374, 3775830040, 2137656763, 141376813, 2439277719, 3865271297, 1802195444, 476864866, 2238001368, 4066508878, 1812370925, 453092731, 2181625025, 4111451223, 1706088902, 314042704, 2344532202, 4240017532, 1658658271, 366619977, 2362670323, 4224994405, 1303535960, 984961486, 2747007092, 3569037538, 1256170817, 1037604311, 2765210733, 3554079995, 1131014506, 879679996, 2909243462, 3663771856, 1141124467, 855842277, 2852801631, 3708648649, 1342533948, 654459306, 3188396048, 3373015174, 1466479909, 544179635, 3110523913, 3462522015, 1591671054, 702138776, 2966460450, 3352799412, 1504918807, 783551873, 3082640443, 3233442989, 3988292384, 2596254646, 62317068, 1957810842, 3939845945, 2647816111, 81470997, 1943803523, 3814918930, 2489596804, 225274430, 2053790376, 3826175755, 2466906013, 167816743, 2097651377, 4027552580, 2265490386, 503444072, 1762050814, 4150417245, 2154129355, 426522225, 1852507879, 4275313526, 2312317920, 282753626, 1742555852, 4189708143, 2394877945, 397917763, 1622183637, 3604390888, 2714866558, 953729732, 1340076626, 3518719985, 2797360999, 1068828381, 1219638859, 3624741850, 2936675148, 906185462, 1090812512, 3747672003, 2825379669, 829329135, 1181335161, 3412177804, 3160834842, 628085408, 1382605366, 3423369109, 3138078467, 570562233, 1426400815, 3317316542, 2998733608, 733239954, 1555261956, 3268935591, 3050360625, 752459403, 1541320221, 2607071920, 3965973030, 1969922972, 40735498, 2617837225, 3943577151, 1913087877, 83908371, 2512341634, 3803740692, 2075208622, 213261112, 2463272603, 3855990285, 2094854071, 198958881, 2262029012, 4057260610, 1759359992, 534414190, 2176718541, 4139329115, 1873836001, 414664567, 2282248934, 4279200368, 1711684554, 285281116, 2405801727, 4167216745, 1634467795, 376229701, 2685067896, 3608007406, 1308918612, 956543938, 2808555105, 3495958263, 1231636301, 1047427035, 2932959818, 3654703836, 1088359270, 936918000, 2847714899, 3736837829, 1202900863, 817233897, 3183342108, 3401237130, 1404277552, 615818150, 3134207493, 3453421203, 1423857449, 601450431, 3009837614, 3294710456, 1567103746, 711928724, 3020668471, 3272380065, 1510334235, 755167117], null, null);
                    //--TRIMMABLE-BOUNDARY-END(25771602783)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541406559)
                    this.IHDR = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [73, 72, 68, 82], null, null);
                    //--TRIMMABLE-BOUNDARY-END(51541406559)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55836373855)
                    this.PLTE = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [80, 76, 84, 69], null, null);
                    //--TRIMMABLE-BOUNDARY-END(55836373855)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951471967)
                    this.IDAT = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [73, 68, 65, 84], null, null);
                    //--TRIMMABLE-BOUNDARY-END(42951471967)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246439263)
                    this.IEND = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [73, 69, 78, 68], null, null);
                    //--TRIMMABLE-BOUNDARY-END(47246439263)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591733599)
            
            static $h = 1799007;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721275743),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "qrCode",
          "p": 1864543
        },
        {
          "n": "scale",
          "p": 655361
        },
        {
          "n": "border",
          "p": 655361
        },
        {
          "n": "foreground",
          "p": 655361
        },
        {
          "n": "background",
          "p": 655361
        }
      ],
      "n": "ToImage",
      "d": 1799007,
      "h": 68721275743,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(68721275743),
//--TRIMMABLE-BOUNDARY-START(30066570079),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "qrCode",
          "p": 1864543
        },
        {
          "n": "border",
          "p": 655361
        },
        {
          "n": "scale",
          "p": 655361
        }
      ],
      "n": "CreateBitmap",
      "d": 1799007,
      "h": 30066570079,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066570079),
//--TRIMMABLE-BOUNDARY-START(38656504671),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetBytes",
      "d": 1799007,
      "h": 38656504671,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38656504671),
//--TRIMMABLE-BOUNDARY-START(90196112223),
    {
      "r": 65537,
      "p": [
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        },
        {
          "n": "bitDepth",
          "p": 393217
        },
        {
          "n": "colorType",
          "p": 393217
        }
      ],
      "n": "WriteHeader",
      "d": 1799007,
      "h": 90196112223,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90196112223),
//--TRIMMABLE-BOUNDARY-START(98786046815),
    {
      "r": 65537,
      "p": [
        {
          "n": "palette",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": "WritePalette",
      "d": 1799007,
      "h": 98786046815,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98786046815),
//--TRIMMABLE-BOUNDARY-START(81606177631),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "WriteData",
      "d": 1799007,
      "h": 81606177631,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81606177631),
//--TRIMMABLE-BOUNDARY-START(85901144927),
    {
      "r": 65537,
      "n": "WriteEnd",
      "d": 1799007,
      "h": 85901144927,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901144927),
//--TRIMMABLE-BOUNDARY-START(60131341151),
    {
      "r": 65537,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SetCRC",
      "d": 1799007,
      "h": 60131341151,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60131341151),
//--TRIMMABLE-BOUNDARY-START(77311210335),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "WriteChunkStart",
      "d": 1799007,
      "h": 77311210335,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77311210335),
//--TRIMMABLE-BOUNDARY-START(73016243039),
    {
      "r": 65537,
      "n": "WriteChunkEnd",
      "d": 1799007,
      "h": 73016243039,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73016243039),
//--TRIMMABLE-BOUNDARY-START(94491079519),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "WriteIntBigEndian",
      "d": 1799007,
      "h": 94491079519,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94491079519),
//--TRIMMABLE-BOUNDARY-START(34361537375),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Deflate",
      "d": 1799007,
      "h": 34361537375,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361537375),
//--TRIMMABLE-BOUNDARY-START(17181668191),
    {
      "r": 720897,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CalcAdler32",
      "d": 1799007,
      "h": 17181668191,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181668191),
//--TRIMMABLE-BOUNDARY-START(21476635487),
    {
      "r": 720897,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CalcCrc32",
      "d": 1799007,
      "h": 21476635487,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476635487)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64426308447),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "Signature",
      "d": 1799007,
      "h": 64426308447,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64426308447),
//--TRIMMABLE-BOUNDARY-START(25771602783),
    {
      "t": $.$typeArray($.$$.S.UInt32).$h,
      "n": "CrcTable",
      "d": 1799007,
      "h": 25771602783,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771602783),
//--TRIMMABLE-BOUNDARY-START(51541406559),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "IHDR",
      "d": 1799007,
      "h": 51541406559,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541406559),
//--TRIMMABLE-BOUNDARY-START(55836373855),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "PLTE",
      "d": 1799007,
      "h": 55836373855,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836373855),
//--TRIMMABLE-BOUNDARY-START(42951471967),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "IDAT",
      "d": 1799007,
      "h": 42951471967,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951471967),
//--TRIMMABLE-BOUNDARY-START(47246439263),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "IEND",
      "d": 1799007,
      "h": 47246439263,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47246439263),
//--TRIMMABLE-BOUNDARY-START(4296766303),
    {
      "t": 94044161,
      "n": "_stream",
      "d": 1799007,
      "h": 4296766303,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296766303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886700895),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1799007,
      "h": 12886700895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886700895)
  ],
  "h": 1799007
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.PngBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}PngBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1799007)
        
        

        //--TRIMMABLE-BOUNDARY-START(1274719)
        $asm.$cls(`$wZnq.NCQ.FixedPatterns`, ($self) => class FixedPatterns
        {
            //--TRIMMABLE-BOUNDARY-START(12886176607)
            /*ConcurrentDictionary<int, (BitMatrix Drawn, BitMatrix PayloadAreaMap)>*/ static Cache = null;
            //--TRIMMABLE-BOUNDARY-END(12886176607)
            
            //--TRIMMABLE-BOUNDARY-START(21476111199)
            /*Func<int, (BitMatrix, BitMatrix)>*/ static ComputeCachedFunc = null;
            //--TRIMMABLE-BOUNDARY-END(21476111199)
            
            //--TRIMMABLE-BOUNDARY-START(51540882271)
            static /*(BitMatrix Drawn, BitMatrix PayloadAreaMap) */ GetCached(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540882271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.FixedPatterns.Cache.GetOrAdd(version, $.$wZnq.NCQ.FixedPatterns.ComputeCachedFunc);
            }
            //--TRIMMABLE-BOUNDARY-END(51540882271)
            
            //--TRIMMABLE-BOUNDARY-START(17181143903)
            static /*(BitMatrix Drawn, BitMatrix PayloadAreaMap) */ ComputeCached(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181143903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let  [ drawn, reserved ] = $.$destructure($.$wZnq.NCQ.FixedPatterns.BuildFixedPatterns(version));
                reserved.Invert();
                return new ($.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix))().$ctor$3(drawn, reserved);
            }
            //--TRIMMABLE-BOUNDARY-END(17181143903)
            
            //--TRIMMABLE-BOUNDARY-START(25771078495)
            static /*BitMatrix */ CreateWithFixedPatterns(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771078495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.FixedPatterns.GetCached(version).Item1.Copy();
            }
            //--TRIMMABLE-BOUNDARY-END(25771078495)
            
            //--TRIMMABLE-BOUNDARY-START(55835849567)
            static /*BitMatrix */ GetPayloadAreaMap(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835849567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.FixedPatterns.GetCached(version).Item2;
            }
            //--TRIMMABLE-BOUNDARY-END(55835849567)
            
            //--TRIMMABLE-BOUNDARY-START(8591209311)
            static /*(BitMatrix Drawn, BitMatrix Reserved) */ BuildFixedPatterns(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591209311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = $.$wZnq.NCQ.QrCodeParameters.GetSize(version);
                /*var*/ let drawn = new $.$wZnq.NCQ.BitMatrix().$ctor$3(size);
                /*var*/ let reserved = new $.$wZnq.NCQ.BitMatrix().$ctor$3(size);
                drawn.Set(8, ((size - 8) | 0), true);
                reserved.Set(8, ((size - 8) | 0), true);
                $.$wZnq.NCQ.FixedPatterns.ReserveFormatInformation(reserved);
                $.$wZnq.NCQ.FixedPatterns.DrawVersionInformation(drawn, version);
                $.$wZnq.NCQ.FixedPatterns.ReserveVersionInformation(reserved, version);
                $.$wZnq.NCQ.FixedPatterns.DrawFinderPattern(drawn, 0, 0);
                $.$wZnq.NCQ.FixedPatterns.DrawFinderPattern(drawn, ((size - 7) | 0), 0);
                $.$wZnq.NCQ.FixedPatterns.DrawFinderPattern(drawn, 0, ((size - 7) | 0));
                reserved.FillRect(0, 0, 8, 8);
                reserved.FillRect(((size - 8) | 0), 0, 8, 8);
                reserved.FillRect(0, ((size - 8) | 0), 8, 8);
                $.$wZnq.NCQ.FixedPatterns.DrawTimingPattern(drawn);
                reserved.FillRect(8, 6, ((size - 16) | 0), 1);
                reserved.FillRect(6, 8, 1, ((size - 16) | 0));
                $.$wZnq.NCQ.FixedPatterns.DrawAndReserveAlignmentPatterns(drawn, reserved, version);
                return new ($.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix))().$ctor$3(drawn, reserved);
            }
            //--TRIMMABLE-BOUNDARY-END(8591209311)
            
            //--TRIMMABLE-BOUNDARY-START(38655980383)
            static /*void */ DrawFinderPattern(/*BitMatrix*/ modules, /*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655980383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = 0; i < 7; i += 1)
                {
                    modules.Set(((x + i) | 0), y, true);
                    modules.Set(((x + i) | 0), ((y + 6) | 0), true);
                }
                for(/*var*/ let i = 1; i < 6; i += 1)
                {
                    modules.Set(x, ((y + i) | 0), true);
                    modules.Set(((x + 1) | 0), ((y + i) | 0), false);
                    modules.Set(((x + 5) | 0), ((y + i) | 0), false);
                    modules.Set(((x + 6) | 0), ((y + i) | 0), true);
                }
                for(/*var*/ let i = 2; i < 5; i += 1)
                {
                    modules.Set(((x + i) | 0), ((y + 1) | 0), false);
                    modules.Set(((x + i) | 0), ((y + 5) | 0), false);
                }
                for(/*var*/ let i = 2; i < 5; i += 1)
                {
                    modules.Set(((x + i) | 0), ((y + 2) | 0), true);
                    modules.Set(((x + i) | 0), ((y + 3) | 0), true);
                    modules.Set(((x + i) | 0), ((y + 4) | 0), true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655980383)
            
            //--TRIMMABLE-BOUNDARY-START(34361013087)
            static /*void */ DrawAndReserveAlignmentPatterns(/*BitMatrix*/ drawn, /*BitMatrix*/ reserved, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361013087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (version === 1)
                {
                    return;
                }
                /*var*/ let positions = $.$wZnq.NCQ.QrCodeParameters.GetAlignmentPatternPosition(version);
                /*var*/ let numPositions = positions.length;
                for(/*var*/ let x = 0; x < numPositions; x += 1)
                {
                    for(/*var*/ let y = 0; y < numPositions; y += 1)
                    {
                        if ((x === 0 && y === 0) || (x === ((numPositions - 1) | 0) && y === 0) || (x === 0 && y === ((numPositions - 1) | 0)))
                        {
                            continue;
                        }
                        reserved.FillRect((($.$$.System.Array.$ReadT1.call(positions, x) - 2) | 0), (($.$$.System.Array.$ReadT1.call(positions, y) - 2) | 0), 5, 5);
                        $.$wZnq.NCQ.FixedPatterns.DrawAlignmentPattern(drawn, $.$$.System.Array.$ReadT1.call(positions, x), $.$$.System.Array.$ReadT1.call(positions, y));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361013087)
            
            //--TRIMMABLE-BOUNDARY-START(30066045791)
            static /*void */ DrawAlignmentPattern(/*BitMatrix*/ modules, /*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066045791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = -2; i <= 2; i += 1)
                {
                    modules.Set(((x + i) | 0), ((y - 2) | 0), true);
                    modules.Set(((x + i) | 0), ((y + 2) | 0), true);
                }
                for(/*var*/ let i = -1; i <= 1; i += 1)
                {
                    modules.Set(((x - 2) | 0), ((y + i) | 0), true);
                    modules.Set(((x + 2) | 0), ((y + i) | 0), true);
                }
                modules.Set(x, y, true);
            }
            //--TRIMMABLE-BOUNDARY-END(30066045791)
            
            //--TRIMMABLE-BOUNDARY-START(42950947679)
            static /*void */ DrawTimingPattern(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950947679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = modules.Size;
                for(/*var*/ let x = 8; x < ((size - 8) | 0); x += 1)
                {
                    /*var*/ let isDark = ((((x + 1) | 0)) & 1) !== 0;
                    modules.Set(x, 6, isDark);
                    modules.Set(6, x, isDark);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950947679)
            
            //--TRIMMABLE-BOUNDARY-START(64425784159)
            static /*void */ ReserveVersionInformation(/*BitMatrix*/ reserved, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425784159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (version < 7)
                {
                    return;
                }
                /*var*/ let size = reserved.Size;
                reserved.FillRect(0, ((size - 11) | 0), 6, 3);
                reserved.FillRect(((size - 11) | 0), 0, 3, 6);
            }
            //--TRIMMABLE-BOUNDARY-END(64425784159)
            
            //--TRIMMABLE-BOUNDARY-START(47245914975)
            static /*void */ DrawVersionInformation(/*BitMatrix*/ modules, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245914975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (version < 7)
                {
                    return;
                }
                /*var*/ let size = modules.Size;
                /*var*/ let bits = $.$wZnq.NCQ.QrCodeParameters.GetVersionInformationBits(version);
                for(/*var*/ let bit = 0; bit < 18; bit += 1)
                {
                    /*var*/ let isDark = (bits & (1 << bit)) !== 0;
                    /*var*/ let x = $.trunc(bit / 3);
                    /*var*/ let y = bit % 3;
                    modules.Set(x, ((((size - 11) | 0) + y) | 0), isDark);
                    modules.Set(((((size - 11) | 0) + y) | 0), x, isDark);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245914975)
            
            //--TRIMMABLE-BOUNDARY-START(60130816863)
            static /*void */ ReserveFormatInformation(/*BitMatrix*/ reserved)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130816863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                reserved.FillRect(8, 0, 1, 9);
                reserved.FillRect(0, 8, 8, 1);
                reserved.FillRect(((reserved.Size - 8) | 0), 8, 8, 1);
                reserved.FillRect(8, ((reserved.Size - 7) | 0), 1, 7);
            }
            //--TRIMMABLE-BOUNDARY-END(60130816863)
            
            //--TRIMMABLE-BOUNDARY-START(4296242015)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296242015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12886176607)
                    this.Cache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(12886176607)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476111199)
                    this.ComputeCachedFunc = new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix)))().$ctor($.$wZnq.NCQ.FixedPatterns, $.$wZnq.NCQ.FixedPatterns.ComputeCached);
                    //--TRIMMABLE-BOUNDARY-END(21476111199)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296242015)
            
            static $h = 1274719;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540882271),
    {
      "r": $.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix).$h,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetCached",
      "d": 1274719,
      "h": 51540882271,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51540882271),
//--TRIMMABLE-BOUNDARY-START(17181143903),
    {
      "r": $.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix).$h,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "ComputeCached",
      "d": 1274719,
      "h": 17181143903,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181143903),
//--TRIMMABLE-BOUNDARY-START(25771078495),
    {
      "r": 160607,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "CreateWithFixedPatterns",
      "d": 1274719,
      "h": 25771078495,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25771078495),
//--TRIMMABLE-BOUNDARY-START(55835849567),
    {
      "r": 160607,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetPayloadAreaMap",
      "d": 1274719,
      "h": 55835849567,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835849567),
//--TRIMMABLE-BOUNDARY-START(8591209311),
    {
      "r": $.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix).$h,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "BuildFixedPatterns",
      "d": 1274719,
      "h": 8591209311,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591209311),
//--TRIMMABLE-BOUNDARY-START(38655980383),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "DrawFinderPattern",
      "d": 1274719,
      "h": 38655980383,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655980383),
//--TRIMMABLE-BOUNDARY-START(34361013087),
    {
      "r": 65537,
      "p": [
        {
          "n": "drawn",
          "p": 160607
        },
        {
          "n": "reserved",
          "p": 160607
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "DrawAndReserveAlignmentPatterns",
      "d": 1274719,
      "h": 34361013087,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361013087),
//--TRIMMABLE-BOUNDARY-START(30066045791),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "DrawAlignmentPattern",
      "d": 1274719,
      "h": 30066045791,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066045791),
//--TRIMMABLE-BOUNDARY-START(42950947679),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "DrawTimingPattern",
      "d": 1274719,
      "h": 42950947679,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950947679),
//--TRIMMABLE-BOUNDARY-START(64425784159),
    {
      "r": 65537,
      "p": [
        {
          "n": "reserved",
          "p": 160607
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "ReserveVersionInformation",
      "d": 1274719,
      "h": 64425784159,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425784159),
//--TRIMMABLE-BOUNDARY-START(47245914975),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "DrawVersionInformation",
      "d": 1274719,
      "h": 47245914975,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245914975),
//--TRIMMABLE-BOUNDARY-START(60130816863),
    {
      "r": 65537,
      "p": [
        {
          "n": "reserved",
          "p": 160607
        }
      ],
      "n": "ReserveFormatInformation",
      "d": 1274719,
      "h": 60130816863,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60130816863)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886176607),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix)).$h,
      "n": "Cache",
      "d": 1274719,
      "h": 12886176607,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886176607),
//--TRIMMABLE-BOUNDARY-START(21476111199),
    {
      "t": $.$$.S.Func$$$($.$$.S.Int32, $.$$.S.ValueTuple$$$($.$wZnq.NCQ.BitMatrix, $.$wZnq.NCQ.BitMatrix)).$h,
      "n": "ComputeCachedFunc",
      "d": 1274719,
      "h": 21476111199,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21476111199)
  ],
  "h": 1274719
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.FixedPatterns`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}FixedPatterns`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1274719)
        
        

        //--TRIMMABLE-BOUNDARY-START(2388831)
        $asm.$cls(`$wZnq.NCQ.ReedSolomon`, ($self) => class ReedSolomon extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297356127)
            /*int*/ _capacity = 0;
            //--TRIMMABLE-BOUNDARY-END(4297356127)
            
            //--TRIMMABLE-BOUNDARY-START(12887290719)
            /*int*/ _wordCount = 0;
            //--TRIMMABLE-BOUNDARY-END(12887290719)
            
            //--TRIMMABLE-BOUNDARY-START(8592323423)
            /*ulong[]*/ _products = null;
            //--TRIMMABLE-BOUNDARY-END(8592323423)
            
            //--TRIMMABLE-BOUNDARY-START(73016832863)
            /*int*/ static MaxCapacity = 255;
            //--TRIMMABLE-BOUNDARY-END(73016832863)
            
            //--TRIMMABLE-BOUNDARY-START(55836963679)
            /*ConcurrentDictionary<int, ReedSolomon>*/ static GeneratorCache = null;
            //--TRIMMABLE-BOUNDARY-END(55836963679)
            
            //--TRIMMABLE-BOUNDARY-START(60131930975)
            static /*ReedSolomon */ GeneratorForCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131930975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (capacity < 1 || capacity > 255/*MaxCapacity*/)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("capacity", "Error correction capacity must be between 1 and " + 255/*MaxCapacity*/);
                }
                return $.$wZnq.NCQ.ReedSolomon.GeneratorCache.GetOrAdd(capacity, $.$wZnq.NCQ.ReedSolomon.CreateForCapacityFunc);
            }
            //--TRIMMABLE-BOUNDARY-END(60131930975)
            
            //--TRIMMABLE-BOUNDARY-START(42952061791)
            /*Func<int, ReedSolomon>*/ static CreateForCapacityFunc = null;
            //--TRIMMABLE-BOUNDARY-END(42952061791)
            
            //--TRIMMABLE-BOUNDARY-START(38657094495)
            static /*ReedSolomon */ CreateForCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657094495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$wZnq.NCQ.ReedSolomon().$ctor$1(capacity);
            }
            //--TRIMMABLE-BOUNDARY-END(38657094495)
            
            //--TRIMMABLE-BOUNDARY-START(21477225311)
            $ctor$1(/*int*/ capacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477225311);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._capacity = capacity;
                    this._wordCount = $.trunc((((capacity + 7) | 0)) / 8);
                    this._products = $.$wZnq.NCQ.ReedSolomon.ComputeProducts(capacity, this._wordCount);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477225311)
            
            //--TRIMMABLE-BOUNDARY-START(25772192607)
            /*void */ ComputeErrorCorrection(/*ArraySegment<byte>*/ data, /*byte[]*/ target, /*int*/ offset, /*int*/ stride)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772192607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let remainder = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.UInt64), null, [((this._wordCount + 1) | 0)], null);
                /*var*/ let array = data.Array;
                /*var*/ let end = ((data.Offset + data.Count) | 0);
                for(/*var*/ let index = data.Offset; index < end; index += 1)
                {
                    /*var*/ let row = ((($.$$.System.Array.$ReadT1.call(array, index) ^ $.$cast($.$$.System.Array.$ReadT1.call(remainder, 0), $.$$.S.Byte)) * this._wordCount) | 0);
                    for(/*var*/ let k = 0; k < this._wordCount; k += 1)
                    {
                        $.$$.System.Array.$WriteT1.call(remainder, (($.$$.System.Array.$ReadT1.call(remainder, k) >> 8n) | (BigInt.asUintN(64, $.$$.System.Array.$ReadT1.call(remainder, ((k + 1) | 0)) << 56n))) ^ $.$$.System.Array.$ReadT1.call(this._products, ((row + k) | 0)), k);
                    }
                }
                for(/*var*/ let i = 0; i < this._capacity; i += 1)
                {
                    $.$$.System.Array.$WriteT1.call(target, $.$cast(($.$$.System.Array.$ReadT1.call(remainder, i >> 3) >> BigInt(((((i & 7) * 8) | 0)))), $.$$.S.Byte), ((offset + ((i * stride) | 0)) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772192607)
            
            //--TRIMMABLE-BOUNDARY-START(34362127199)
            static /*ulong[] */ ComputeProducts(/*int*/ capacity, /*int*/ wordCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362127199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let generatorPolynomial = $.$wZnq.NCQ.ReedSolomon.ComputeGeneratorPolynomial(capacity);
                /*var*/ let products = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.UInt64), null, [((256 * wordCount) | 0)], null);
                for(/*var*/ let factor = 1; factor < 256; factor += 1)
                {
                    for(/*var*/ let i = 0; i < capacity; i += 1)
                    {
                        $.$$.System.Array.$WriteT1.call(products, $.$$.System.Array.$ReadT1.call(products, ((((factor * wordCount) | 0) + (i >> 3)) | 0)) | BigInt.asUintN(64, $.$cast($.$wZnq.NCQ.ReedSolomon.GfMultiply(factor, $.$$.System.Array.$ReadT1.call(generatorPolynomial, i)), $.$$.S.UInt64) << BigInt(((((i & 7) * 8) | 0)))), ((((factor * wordCount) | 0) + (i >> 3)) | 0));
                    }
                }
                return products;
            }
            //--TRIMMABLE-BOUNDARY-END(34362127199)
            
            //--TRIMMABLE-BOUNDARY-START(30067159903)
            static /*int[] */ ComputeGeneratorPolynomial(/*int*/ eccCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067159903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let poly = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [((eccCount + 1) | 0)], null);
                $.$$.System.Array.$WriteT1.call(poly, 1, 0);
                for(/*var*/ let i = 0; i < eccCount; i += 1)
                {
                    /*var*/ let alphaI = $.$wZnq.NCQ.ReedSolomon.GfPow(2, i);
                    for(/*var*/ let j = eccCount; j > 0; j--)
                    {
                        $.$$.System.Array.$WriteT1.call(poly, $.$$.System.Array.$ReadT1.call(poly, ((j - 1) | 0)) ^ $.$wZnq.NCQ.ReedSolomon.GfMultiply($.$$.System.Array.$ReadT1.call(poly, j), alphaI), j);
                    }
                    $.$$.System.Array.$WriteT1.call(poly, $.$wZnq.NCQ.ReedSolomon.GfMultiply($.$$.System.Array.$ReadT1.call(poly, 0), alphaI), 0);
                }
                /*var*/ let result = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [eccCount], null);
                for(/*var*/ let i = 0; i < eccCount; i += 1)
                {
                    $.$$.System.Array.$WriteT1.call(result, $.$$.System.Array.$ReadT1.call(poly, ((((eccCount - 1) | 0) - i) | 0)), i);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(30067159903)
            
            //--TRIMMABLE-BOUNDARY-START(64426898271)
            static /*byte */ GfMultiply(/*int*/ a, /*int*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426898271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (a === 0 || b === 0)
                {
                    return 0;
                }
                return $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.ReedSolomon.GaloisFieldExp, ($.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.ReedSolomon.GaloisFieldLog, a) + $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.ReedSolomon.GaloisFieldLog, b)) % 255);
            }
            //--TRIMMABLE-BOUNDARY-END(64426898271)
            
            //--TRIMMABLE-BOUNDARY-START(68721865567)
            static /*int */ GfPow(/*int*/ base, /*int*/ exponent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721865567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (exponent === 0)
                {
                    return 1;
                }
                if (base === 0)
                {
                    return 0;
                }
                return $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.ReedSolomon.GaloisFieldExp, (($.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.ReedSolomon.GaloisFieldLog, base) * exponent) | 0) % 255);
            }
            //--TRIMMABLE-BOUNDARY-END(68721865567)
            
            //--TRIMMABLE-BOUNDARY-START(51541996383)
            /*byte[]*/ static GaloisFieldLog = null;
            //--TRIMMABLE-BOUNDARY-END(51541996383)
            
            //--TRIMMABLE-BOUNDARY-START(47247029087)
            /*byte[]*/ static GaloisFieldExp = null;
            //--TRIMMABLE-BOUNDARY-END(47247029087)
            
            //--TRIMMABLE-BOUNDARY-START(17182258015)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182258015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(55836963679)
                    this.GeneratorCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$wZnq.NCQ.ReedSolomon))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(55836963679)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42952061791)
                    this.CreateForCapacityFunc = new ($.$$.S.Func$$$($.$$.S.Int32, $.$wZnq.NCQ.ReedSolomon))().$ctor($.$wZnq.NCQ.ReedSolomon, $.$wZnq.NCQ.ReedSolomon.CreateForCapacity);
                    //--TRIMMABLE-BOUNDARY-END(42952061791)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541996383)
                    this.GaloisFieldLog = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [0, 0, 1, 25, 2, 50, 26, 198, 3, 223, 51, 238, 27, 104, 199, 75, 4, 100, 224, 14, 52, 141, 239, 129, 28, 193, 105, 248, 200, 8, 76, 113, 5, 138, 101, 47, 225, 36, 15, 33, 53, 147, 142, 218, 240, 18, 130, 69, 29, 181, 194, 125, 106, 39, 249, 185, 201, 154, 9, 120, 77, 228, 114, 166, 6, 191, 139, 98, 102, 221, 48, 253, 226, 152, 37, 179, 16, 145, 34, 136, 54, 208, 148, 206, 143, 150, 219, 189, 241, 210, 19, 92, 131, 56, 70, 64, 30, 66, 182, 163, 195, 72, 126, 110, 107, 58, 40, 84, 250, 133, 186, 61, 202, 94, 155, 159, 10, 21, 121, 43, 78, 212, 229, 172, 115, 243, 167, 87, 7, 112, 192, 247, 140, 128, 99, 13, 103, 74, 222, 237, 49, 197, 254, 24, 227, 165, 153, 119, 38, 184, 180, 124, 17, 68, 146, 217, 35, 32, 137, 46, 55, 63, 209, 91, 149, 188, 207, 205, 144, 135, 151, 178, 220, 252, 190, 97, 242, 86, 211, 171, 20, 42, 93, 158, 132, 60, 57, 83, 71, 109, 65, 162, 31, 45, 67, 216, 183, 123, 164, 118, 196, 23, 73, 236, 127, 12, 111, 246, 108, 161, 59, 82, 41, 157, 85, 170, 251, 96, 134, 177, 187, 204, 62, 90, 203, 89, 95, 176, 156, 169, 160, 81, 11, 245, 22, 235, 122, 117, 44, 215, 79, 174, 213, 233, 230, 231, 173, 232, 116, 214, 244, 234, 168, 80, 88, 175], null, null);
                    //--TRIMMABLE-BOUNDARY-END(51541996383)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47247029087)
                    this.GaloisFieldExp = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [1, 2, 4, 8, 16, 32, 64, 128, 29, 58, 116, 232, 205, 135, 19, 38, 76, 152, 45, 90, 180, 117, 234, 201, 143, 3, 6, 12, 24, 48, 96, 192, 157, 39, 78, 156, 37, 74, 148, 53, 106, 212, 181, 119, 238, 193, 159, 35, 70, 140, 5, 10, 20, 40, 80, 160, 93, 186, 105, 210, 185, 111, 222, 161, 95, 190, 97, 194, 153, 47, 94, 188, 101, 202, 137, 15, 30, 60, 120, 240, 253, 231, 211, 187, 107, 214, 177, 127, 254, 225, 223, 163, 91, 182, 113, 226, 217, 175, 67, 134, 17, 34, 68, 136, 13, 26, 52, 104, 208, 189, 103, 206, 129, 31, 62, 124, 248, 237, 199, 147, 59, 118, 236, 197, 151, 51, 102, 204, 133, 23, 46, 92, 184, 109, 218, 169, 79, 158, 33, 66, 132, 21, 42, 84, 168, 77, 154, 41, 82, 164, 85, 170, 73, 146, 57, 114, 228, 213, 183, 115, 230, 209, 191, 99, 198, 145, 63, 126, 252, 229, 215, 179, 123, 246, 241, 255, 227, 219, 171, 75, 150, 49, 98, 196, 149, 55, 110, 220, 165, 87, 174, 65, 130, 25, 50, 100, 200, 141, 7, 14, 28, 56, 112, 224, 221, 167, 83, 166, 81, 162, 89, 178, 121, 242, 249, 239, 195, 155, 43, 86, 172, 69, 138, 9, 18, 36, 72, 144, 61, 122, 244, 245, 247, 243, 251, 235, 203, 139, 11, 22, 44, 88, 176, 125, 250, 233, 207, 131, 27, 54, 108, 216, 173, 71, 142, 1], null, null);
                    //--TRIMMABLE-BOUNDARY-END(47247029087)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182258015)
            
            static $h = 2388831;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131930975),
    {
      "r": 2388831,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "GeneratorForCapacity",
      "d": 2388831,
      "h": 60131930975,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(60131930975),
//--TRIMMABLE-BOUNDARY-START(38657094495),
    {
      "r": 2388831,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "CreateForCapacity",
      "d": 2388831,
      "h": 38657094495,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38657094495),
//--TRIMMABLE-BOUNDARY-START(25772192607),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "target",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "stride",
          "p": 655361
        }
      ],
      "n": "ComputeErrorCorrection",
      "d": 2388831,
      "h": 25772192607,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25772192607),
//--TRIMMABLE-BOUNDARY-START(34362127199),
    {
      "r": $.$typeArray($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "wordCount",
          "p": 655361
        }
      ],
      "n": "ComputeProducts",
      "d": 2388831,
      "h": 34362127199,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34362127199),
//--TRIMMABLE-BOUNDARY-START(30067159903),
    {
      "r": $.$typeArray($.$$.S.Int32).$h,
      "p": [
        {
          "n": "eccCount",
          "p": 655361
        }
      ],
      "n": "ComputeGeneratorPolynomial",
      "d": 2388831,
      "h": 30067159903,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30067159903),
//--TRIMMABLE-BOUNDARY-START(64426898271),
    {
      "r": 393217,
      "p": [
        {
          "n": "a",
          "p": 655361
        },
        {
          "n": "b",
          "p": 655361
        }
      ],
      "n": "GfMultiply",
      "d": 2388831,
      "h": 64426898271,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64426898271),
//--TRIMMABLE-BOUNDARY-START(68721865567),
    {
      "r": 655361,
      "p": [
        {
          "n": "base",
          "p": 655361
        },
        {
          "n": "exponent",
          "p": 655361
        }
      ],
      "n": "GfPow",
      "d": 2388831,
      "h": 68721865567,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68721865567)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297356127),
    {
      "t": 655361,
      "n": "_capacity",
      "d": 2388831,
      "h": 4297356127,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297356127),
//--TRIMMABLE-BOUNDARY-START(12887290719),
    {
      "t": 655361,
      "n": "_wordCount",
      "d": 2388831,
      "h": 12887290719,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887290719),
//--TRIMMABLE-BOUNDARY-START(8592323423),
    {
      "t": $.$typeArray($.$$.S.UInt64).$h,
      "n": "_products",
      "d": 2388831,
      "h": 8592323423,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592323423),
//--TRIMMABLE-BOUNDARY-START(73016832863),
    {
      "t": 655361,
      "n": "MaxCapacity",
      "d": 2388831,
      "h": 73016832863,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73016832863),
//--TRIMMABLE-BOUNDARY-START(55836963679),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$wZnq.NCQ.ReedSolomon).$h,
      "n": "GeneratorCache",
      "d": 2388831,
      "h": 55836963679,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836963679),
//--TRIMMABLE-BOUNDARY-START(42952061791),
    {
      "t": $.$$.S.Func$$$($.$$.S.Int32, $.$wZnq.NCQ.ReedSolomon).$h,
      "n": "CreateForCapacityFunc",
      "d": 2388831,
      "h": 42952061791,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42952061791),
//--TRIMMABLE-BOUNDARY-START(51541996383),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "GaloisFieldLog",
      "d": 2388831,
      "h": 51541996383,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541996383),
//--TRIMMABLE-BOUNDARY-START(47247029087),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "GaloisFieldExp",
      "d": 2388831,
      "h": 47247029087,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47247029087)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477225311),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2388831,
      "h": 21477225311,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21477225311)
  ],
  "h": 2388831
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.ReedSolomon`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}ReedSolomon`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2388831)
        
        

        //--TRIMMABLE-BOUNDARY-START(1471327)
        $asm.$cls(`$wZnq.NCQ.MatrixEncoder`, ($self) => class MatrixEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(60131013471)
            /*ConcurrentDictionary<(int, int), MaskPair>*/ static MaskPatternCache = null;
            //--TRIMMABLE-BOUNDARY-END(60131013471)
            
            //--TRIMMABLE-BOUNDARY-START(73015915359)
            /*ConcurrentDictionary<int, ushort[]>*/ static PayloadTargetCache = null;
            //--TRIMMABLE-BOUNDARY-END(73015915359)
            
            //--TRIMMABLE-BOUNDARY-START(17181340511)
            /*Func<int, ushort[]>*/ static ComputePayloadTargetsFunc = null;
            //--TRIMMABLE-BOUNDARY-END(17181340511)
            
            //--TRIMMABLE-BOUNDARY-START(25771275103)
            /*Func<(int, int), MaskPair>*/ static CreateMaskPairFunc = null;
            //--TRIMMABLE-BOUNDARY-END(25771275103)
            
            //--TRIMMABLE-BOUNDARY-START(42951144287)
            static /*QrCode */ Encode(/*byte[]*/ codewords, /*int*/ version, /*int*/ ecc, /*EncodingInfo*/ encodingInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951144287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let modules = $.$wZnq.NCQ.FixedPatterns.CreateWithFixedPatterns(version);
                $.$wZnq.NCQ.MatrixEncoder.FillPayload(modules, codewords, version);
                /*var*/ let pattern = $.$wZnq.NCQ.MatrixEncoder.ApplyBestPattern(modules, version, ecc, encodingInfo);
                return new $.$wZnq.NCQ.QrCode().$ctor$1(modules, $.$cast(ecc, $.$wZnq.NCQ.QrCode.Ecc), pattern);
            }
            //--TRIMMABLE-BOUNDARY-END(42951144287)
            
            //--TRIMMABLE-BOUNDARY-START(47246111583)
            static /*void */ FillPayload(/*BitMatrix*/ modules, /*byte[]*/ codewords, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246111583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let targets = $.$wZnq.NCQ.MatrixEncoder.GetPayloadTargets(version);
                /*var*/ let bitCount = $.$$.S.Math.Min$4(((codewords.length * 8) | 0), targets.length);
                for(/*var*/ let i = 0; i < bitCount; i += 1)
                {
                    /*var*/ let bit = ($.$$.System.Array.$ReadT1.call(codewords, i >> 3) >>> (((7 - (i & 7)) | 0))) & 1;
                    modules.OrBit($.$$.System.Array.$ReadT1.call(targets, i), bit);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246111583)
            
            //--TRIMMABLE-BOUNDARY-START(55836046175)
            static /*ushort[] */ GetPayloadTargets(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836046175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.MatrixEncoder.PayloadTargetCache.GetOrAdd(version, $.$wZnq.NCQ.MatrixEncoder.ComputePayloadTargetsFunc);
            }
            //--TRIMMABLE-BOUNDARY-END(55836046175)
            
            //--TRIMMABLE-BOUNDARY-START(12886373215)
            static /*ushort[] */ ComputePayloadTargets(/*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886373215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let payloadArea = $.$wZnq.NCQ.FixedPatterns.GetPayloadAreaMap(version);
                /*var*/ let size = payloadArea.Size;
                /*var*/ let targets = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.UInt16), null, [payloadArea.PopCount()], null);
                /*var*/ let count = 0;
                for(/*var*/ let h = ((size - 1) | 0); h > 0; h -= 2)
                {
                    if (h === 6)
                    {
                        h -= 1;
                    }
                    /*var*/ let upward = ((((((size - h) | 0) - 1) | 0)) & 2) === 0;
                    for(/*var*/ let v = 0; v < size; v += 1)
                    {
                        /*var*/ let y = upward ? ((((size - v) | 0) - 1) | 0) : v;
                        for(/*var*/ let x = h; x > ((h - 2) | 0); x -= 1)
                        {
                            if (payloadArea.Get(x, y))
                            {
                                $.$$.System.Array.$WriteT1.call(targets, payloadArea.Address(x, y), count);
                                count += 1;
                            }
                        }
                    }
                }
                return targets;
            }
            //--TRIMMABLE-BOUNDARY-END(12886373215)
            
            //--TRIMMABLE-BOUNDARY-START(51541078879)
            static /*MaskPair */ GetMaskPair(/*int*/ patternIndex, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541078879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.MatrixEncoder.MaskPatternCache.GetOrAdd(new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(patternIndex, version), $.$wZnq.NCQ.MatrixEncoder.CreateMaskPairFunc);
            }
            //--TRIMMABLE-BOUNDARY-END(51541078879)
            
            //--TRIMMABLE-BOUNDARY-START(21476307807)
            static /*MaskPair */ CreateMaskPair(/*(int patternIndex, int version)*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476307807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rows = $.$wZnq.NCQ.MatrixEncoder.CreatePattern(key.Item1, key.Item2);
                rows.And($.$wZnq.NCQ.FixedPatterns.GetPayloadAreaMap(key.Item2));
                /*var*/ let columns = rows.Copy();
                columns.Transpose();
                return new $.$wZnq.NCQ.MaskPair().$ctor$3(rows, columns);
            }
            //--TRIMMABLE-BOUNDARY-END(21476307807)
            
            //--TRIMMABLE-BOUNDARY-START(30066242399)
            static /*BitMatrix */ CreatePattern(/*int*/ patternIndex, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066242399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let pattern = $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.MatrixEncoder.PatternFunctions, patternIndex);
                /*var*/ let size = $.$wZnq.NCQ.QrCodeParameters.GetSize(version);
                /*var*/ let matrix = new $.$wZnq.NCQ.BitMatrix().$ctor$3(size);
                for(/*var*/ let y = 0; y < 12; y += 1)
                {
                    for(/*var*/ let x = 0; x < size; x += 1)
                    {
                        if (pattern.Invoke(x, y))
                        {
                            matrix.Set(x, y, true);
                        }
                    }
                }
                /*var*/ let bits = matrix.Raw;
                /*var*/ let srcIndex = 0;
                /*var*/ let destIndex = ((matrix.WordsPerRow * 12) | 0);
                while(destIndex < bits.length)
                {
                    $.$$.System.Array.$WriteT1.call(bits, $.$$.System.Array.$ReadT1.call(bits, srcIndex), destIndex);
                    srcIndex += 1;
                    destIndex += 1;
                }
                return matrix;
            }
            //--TRIMMABLE-BOUNDARY-END(30066242399)
            
            //--TRIMMABLE-BOUNDARY-START(64425980767)
            /*int[]*/ static PatternEvaluationOrder = null;
            //--TRIMMABLE-BOUNDARY-END(64425980767)
            
            //--TRIMMABLE-BOUNDARY-START(68720948063)
            /*Func<int, int, bool>[]*/ static PatternFunctions = null;
            //--TRIMMABLE-BOUNDARY-END(68720948063)
            
            //--TRIMMABLE-BOUNDARY-START(8591405919)
            static /*int */ ApplyBestPattern(/*BitMatrix*/ modules, /*int*/ version, /*int*/ ecc, /*EncodingInfo*/ encodingInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591405919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let scoringMatrix = $.$wZnq.NCQ.ScoringMatrix.From(modules);
                /*var*/ let bestPattern = -1;
                /*var*/ let lowestPenalty = 2147483647/*int.MaxValue*/;
                let $i1 = 0;
                let $arr1 = $.$wZnq.NCQ.MatrixEncoder.PatternEvaluationOrder;
                while ($i1 < $arr1.length)
                {
                    let pattern = $arr1[$i1++];
                    $.$wZnq.NCQ.MatrixEncoder.DrawFormatInformation(scoringMatrix, ecc, pattern);
                    /*var*/ let mask = $.$wZnq.NCQ.MatrixEncoder.GetMaskPair(pattern, version);
                    scoringMatrix.Xor(mask);
                    /*var*/ let penalty = encodingInfo === null ? $.$wZnq.NCQ.Penalty.Calculate(scoringMatrix, lowestPenalty) : $.$wZnq.NCQ.Penalty.CalculateFully(scoringMatrix, $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$wZnq.NCQ.PenaltyScore, encodingInfo.Penalties, pattern, false, true));
                    scoringMatrix.Xor(mask);
                    if (penalty < lowestPenalty)
                    {
                        lowestPenalty = penalty;
                        bestPattern = pattern;
                    }
                }
                if (encodingInfo !== null && encodingInfo.ForcedDataMask >= 0)
                {
                    bestPattern = encodingInfo.ForcedDataMask;
                }
                $.$wZnq.NCQ.MatrixEncoder.DrawFormatInformation(scoringMatrix, ecc, bestPattern);
                scoringMatrix.Finish($.$wZnq.NCQ.MatrixEncoder.GetMaskPair(bestPattern, version));
                return bestPattern;
            }
            //--TRIMMABLE-BOUNDARY-END(8591405919)
            
            //--TRIMMABLE-BOUNDARY-START(38656176991)
            static /*void */ DrawFormatInformation(/*ScoringMatrix*/ modules, /*int*/ ecc, /*int*/ pattern)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656176991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.MatrixEncoder.DrawFormatBits(modules, $.$wZnq.NCQ.QrCodeParameters.GetFormatInformationBits(ecc, pattern));
            }
            //--TRIMMABLE-BOUNDARY-END(38656176991)
            
            //--TRIMMABLE-BOUNDARY-START(34361209695)
            static /*void */ DrawFormatBits(/*ScoringMatrix*/ modules, /*int*/ formatBits)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361209695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = modules.Size;
                for(/*var*/ let i = 0; i < 8; i += 1)
                {
                    $.$wZnq.NCQ.MatrixEncoder.SetFormatBit(modules, ((((size - 1) | 0) - i) | 0), 8, formatBits, i);
                }
                for(/*var*/ let i = 8; i < 15; i += 1)
                {
                    $.$wZnq.NCQ.MatrixEncoder.SetFormatBit(modules, 8, ((((size - 15) | 0) + i) | 0), formatBits, i);
                }
                for(/*var*/ let i = 0; i < 6; i += 1)
                {
                    $.$wZnq.NCQ.MatrixEncoder.SetFormatBit(modules, 8, i, formatBits, i);
                }
                $.$wZnq.NCQ.MatrixEncoder.SetFormatBit(modules, 8, 7, formatBits, 6);
                $.$wZnq.NCQ.MatrixEncoder.SetFormatBit(modules, 8, 8, formatBits, 7);
                $.$wZnq.NCQ.MatrixEncoder.SetFormatBit(modules, 7, 8, formatBits, 8);
                for(/*var*/ let i = 9; i < 15; i += 1)
                {
                    $.$wZnq.NCQ.MatrixEncoder.SetFormatBit(modules, ((14 - i) | 0), 8, formatBits, i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361209695)
            
            //--TRIMMABLE-BOUNDARY-START(77310882655)
            static /*void */ SetFormatBit(/*ScoringMatrix*/ modules, /*int*/ x, /*int*/ y, /*int*/ bits, /*int*/ bitIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310882655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                modules.SetFormatBit(x, y, (bits & (1 << bitIndex)) !== 0);
            }
            //--TRIMMABLE-BOUNDARY-END(77310882655)
            
            //--TRIMMABLE-BOUNDARY-START(4296438623)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296438623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(60131013471)
                    this.MaskPatternCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32), $.$wZnq.NCQ.MaskPair))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(60131013471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015915359)
                    this.PayloadTargetCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$typeArray($.$$.S.UInt16)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(73015915359)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181340511)
                    this.ComputePayloadTargetsFunc = new ($.$$.S.Func$$$($.$$.S.Int32, $.$typeArray($.$$.S.UInt16)))().$ctor($.$wZnq.NCQ.MatrixEncoder, $.$wZnq.NCQ.MatrixEncoder.ComputePayloadTargets);
                    //--TRIMMABLE-BOUNDARY-END(17181340511)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771275103)
                    this.CreateMaskPairFunc = new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32), $.$wZnq.NCQ.MaskPair))().$ctor($.$wZnq.NCQ.MatrixEncoder, $.$wZnq.NCQ.MatrixEncoder.CreateMaskPair);
                    //--TRIMMABLE-BOUNDARY-END(25771275103)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425980767)
                    this.PatternEvaluationOrder = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [2, 4, 6, 3, 7, 1, 5, 0], null, null);
                    //--TRIMMABLE-BOUNDARY-END(64425980767)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720948063)
                    this.PatternFunctions = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean)), [new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x, /*y*/ y) =>
                    {
                        return (((x + y) | 0)) % 2 === 0;
                    }, _cd828388_541b_4998_ba40_3ac743b98f36 ??= {"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"","d":1471327,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x, /*y*/ y) =>
                    {
                        return y % 2 === 0;
                    }, _74f09a91_b9b5_458b_81a1_a91d40df5f81 ??= {"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"","d":1471327,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x, /*y*/ y) =>
                    {
                        return x % 3 === 0;
                    }, _c4a14f61_36b2_42cc_a90b_187a58687bed ??= {"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"","d":1471327,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x, /*y*/ y) =>
                    {
                        return (((x + y) | 0)) % 3 === 0;
                    }, _31ca7455_3394_429b_b9ed_de2c2db0554d ??= {"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"","d":1471327,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x, /*y*/ y) =>
                    {
                        return ((($.trunc(x / 3) + $.trunc(y / 2)) | 0)) % 2 === 0;
                    }, _3e43b860_7ab5_48f8_aefc_9f1c32d4ce2c ??= {"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"","d":1471327,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x, /*y*/ y) =>
                    {
                        return ((((x * y) | 0) % 2 + ((x * y) | 0) % 3) | 0) === 0;
                    }, _74642940_ec41_4ffe_aa54_ee3b35612c55 ??= {"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"","d":1471327,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x, /*y*/ y) =>
                    {
                        return (((((x * y) | 0) % 2 + ((x * y) | 0) % 3) | 0)) % 2 === 0;
                    }, _e5aaf3e4_b213_4d3e_bfe7_1966d64f8333 ??= {"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"","d":1471327,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x, /*y*/ y) =>
                    {
                        return ((((((x + y) | 0)) % 2 + ((x * y) | 0) % 3) | 0)) % 2 === 0;
                    }, _95273c83_a1e9_428b_88dc_8611de9eb713 ??= {"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"","d":1471327,"h":0,"f":17825794})], null, null);
                    //--TRIMMABLE-BOUNDARY-END(68720948063)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296438623)
            
            static $h = 1471327;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951144287),
    {
      "r": 1864543,
      "p": [
        {
          "n": "codewords",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "encodingInfo",
          "p": 1209183
        }
      ],
      "n": "Encode",
      "d": 1471327,
      "h": 42951144287,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42951144287),
//--TRIMMABLE-BOUNDARY-START(47246111583),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "codewords",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "FillPayload",
      "d": 1471327,
      "h": 47246111583,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246111583),
//--TRIMMABLE-BOUNDARY-START(55836046175),
    {
      "r": $.$typeArray($.$$.S.UInt16).$h,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetPayloadTargets",
      "d": 1471327,
      "h": 55836046175,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55836046175),
//--TRIMMABLE-BOUNDARY-START(12886373215),
    {
      "r": $.$typeArray($.$$.S.UInt16).$h,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "ComputePayloadTargets",
      "d": 1471327,
      "h": 12886373215,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12886373215),
//--TRIMMABLE-BOUNDARY-START(51541078879),
    {
      "r": 1405791,
      "p": [
        {
          "n": "patternIndex",
          "p": 655361
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetMaskPair",
      "d": 1471327,
      "h": 51541078879,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51541078879),
//--TRIMMABLE-BOUNDARY-START(21476307807),
    {
      "r": 1405791,
      "p": [
        {
          "n": "key",
          "p": $.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32).$h
        }
      ],
      "n": "CreateMaskPair",
      "d": 1471327,
      "h": 21476307807,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476307807),
//--TRIMMABLE-BOUNDARY-START(30066242399),
    {
      "r": 160607,
      "p": [
        {
          "n": "patternIndex",
          "p": 655361
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "CreatePattern",
      "d": 1471327,
      "h": 30066242399,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066242399),
//--TRIMMABLE-BOUNDARY-START(8591405919),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "encodingInfo",
          "p": 1209183,
          "f": 65
        }
      ],
      "n": "ApplyBestPattern",
      "d": 1471327,
      "h": 8591405919,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8591405919),
//--TRIMMABLE-BOUNDARY-START(38656176991),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 2454367
        },
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "pattern",
          "p": 655361
        }
      ],
      "n": "DrawFormatInformation",
      "d": 1471327,
      "h": 38656176991,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38656176991),
//--TRIMMABLE-BOUNDARY-START(34361209695),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 2454367
        },
        {
          "n": "formatBits",
          "p": 655361
        }
      ],
      "n": "DrawFormatBits",
      "d": 1471327,
      "h": 34361209695,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361209695),
//--TRIMMABLE-BOUNDARY-START(77310882655),
    {
      "r": 65537,
      "p": [
        {
          "n": "modules",
          "p": 2454367
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        },
        {
          "n": "bits",
          "p": 655361
        },
        {
          "n": "bitIndex",
          "p": 655361
        }
      ],
      "n": "SetFormatBit",
      "d": 1471327,
      "h": 77310882655,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77310882655)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60131013471),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32), $.$wZnq.NCQ.MaskPair).$h,
      "n": "MaskPatternCache",
      "d": 1471327,
      "h": 60131013471,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131013471),
//--TRIMMABLE-BOUNDARY-START(73015915359),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$typeArray($.$$.S.UInt16)).$h,
      "n": "PayloadTargetCache",
      "d": 1471327,
      "h": 73015915359,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015915359),
//--TRIMMABLE-BOUNDARY-START(17181340511),
    {
      "t": $.$$.S.Func$$$($.$$.S.Int32, $.$typeArray($.$$.S.UInt16)).$h,
      "n": "ComputePayloadTargetsFunc",
      "d": 1471327,
      "h": 17181340511,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181340511),
//--TRIMMABLE-BOUNDARY-START(25771275103),
    {
      "t": $.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32), $.$wZnq.NCQ.MaskPair).$h,
      "n": "CreateMaskPairFunc",
      "d": 1471327,
      "h": 25771275103,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771275103),
//--TRIMMABLE-BOUNDARY-START(64425980767),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "PatternEvaluationOrder",
      "d": 1471327,
      "h": 64425980767,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425980767),
//--TRIMMABLE-BOUNDARY-START(68720948063),
    {
      "t": $.$typeArray($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean)).$h,
      "n": "PatternFunctions",
      "d": 1471327,
      "h": 68720948063,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68720948063)
  ],
  "h": 1471327
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.MatrixEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}MatrixEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1471327)
        
        

        //--TRIMMABLE-BOUNDARY-START(2716511)
        $asm.$cls(`$wZnq.NCQ.StructuredAppend`, ($self) => class StructuredAppend
        {
            //--TRIMMABLE-BOUNDARY-START(30067487583)
            /*int*/ static CompactionVersion = 20;
            //--TRIMMABLE-BOUNDARY-END(30067487583)
            
            //--TRIMMABLE-BOUNDARY-START(17182585695)
            static /*List<List<DataSegment>> */ BuildFromText(/*string*/ text, /*int*/ version, /*QrCode.Ecc*/ ecl)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182585695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$$.S.String, text, "text");
                /*byte[]*/ let data;
                /*ECI*/ let eci;
                /*bool*/ let isUtf8;
                try
                {
                    data = $.$wZnq.NCQ.ECI.Latin1.GetEncoding().GetBytes$8(text);
                    eci = $.$wZnq.NCQ.ECI.None;
                    isUtf8 = false;
                }
                catch($e)
                {
                    data = $.$$.ST.Encoding.UTF8.GetBytes$8(text);
                    eci = $.$wZnq.NCQ.ECI.UTF8;
                    isUtf8 = true;
                }
                return $.$wZnq.NCQ.StructuredAppend.BuildSegments(data, version, ecl, eci, isUtf8);
            }
            //--TRIMMABLE-BOUNDARY-END(17182585695)
            
            //--TRIMMABLE-BOUNDARY-START(21477552991)
            static /*List<List<DataSegment>> */ BuildSegments(/*byte[]*/ data, /*int*/ version, /*QrCode.Ecc*/ ecl, /*ECI*/ eci, /*bool*/ isUtf8)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477552991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                /*var*/ let qrCodes = $.$wZnq.NCQ.StructuredAppend.Split(data, version, ecl, eci, isUtf8);
                $.$wZnq.NCQ.StructuredAppend.AddStructuredAppendHeaders(qrCodes, data, eci);
                return qrCodes;
            }
            //--TRIMMABLE-BOUNDARY-END(21477552991)
            
            //--TRIMMABLE-BOUNDARY-START(8592651103)
            static /*(List<List<DataSegment>> QrCodes, int Version) */ BuildBalancedFromText(/*string*/ text, /*int*/ minVersion, /*int*/ maxVersion, /*QrCode.Ecc*/ ecl)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592651103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$$.S.String, text, "text");
                /*byte[]*/ let data;
                /*ECI*/ let eci;
                /*bool*/ let isUtf8;
                try
                {
                    data = $.$wZnq.NCQ.ECI.Latin1.GetEncoding().GetBytes$8(text);
                    eci = $.$wZnq.NCQ.ECI.None;
                    isUtf8 = false;
                }
                catch($e)
                {
                    data = $.$$.ST.Encoding.UTF8.GetBytes$8(text);
                    eci = $.$wZnq.NCQ.ECI.UTF8;
                    isUtf8 = true;
                }
                return $.$wZnq.NCQ.StructuredAppend.BuildBalancedSegments(data, minVersion, maxVersion, ecl, eci, isUtf8);
            }
            //--TRIMMABLE-BOUNDARY-END(8592651103)
            
            //--TRIMMABLE-BOUNDARY-START(12887618399)
            static /*(List<List<DataSegment>> QrCodes, int Version) */ BuildBalancedSegments(/*byte[]*/ data, /*int*/ minVersion, /*int*/ maxVersion, /*QrCode.Ecc*/ ecl, /*ECI*/ eci, /*bool*/ isUtf8)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887618399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                /*var*/ let segments = $.$wZnq.NCQ.SegmentCompaction.BuildSegments$1(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$4(data), 20/*CompactionVersion*/, false);
                /*var*/ let maxCapacity = $.$wZnq.NCQ.StructuredAppend.FullCapacity(maxVersion, ecl, eci);
                /*var*/ let numQrCodes = $.$wZnq.NCQ.StructuredAppend.Split$1(segments, maxVersion, maxCapacity, isUtf8).Count;
                if (numQrCodes > 16 || !$.$wZnq.NCQ.StructuredAppend.FitsInCodes(segments, maxVersion, maxCapacity, isUtf8, numQrCodes))
                {
                    throw new $.$wZnq.NCQ.DataTooLongException().$ctor$15("The text is too long to fit into 16 QR codes");
                }
                /*var*/ let version = maxVersion;
                for(/*var*/ let v = minVersion; v <= maxVersion; v += 1)
                {
                    if ($.$wZnq.NCQ.StructuredAppend.FitsInCodes(segments, v, $.$wZnq.NCQ.StructuredAppend.FullCapacity(v, ecl, eci), isUtf8, numQrCodes))
                    {
                        version = v;
                        break;
                    }
                }
                /*var*/ let lo = 1;
                /*var*/ let hi = $.$wZnq.NCQ.StructuredAppend.FullCapacity(version, ecl, eci);
                while(lo < hi)
                {
                    /*var*/ let mid = ((lo + $.trunc((((hi - lo) | 0)) / 2)) | 0);
                    if ($.$wZnq.NCQ.StructuredAppend.FitsInCodes(segments, version, mid, isUtf8, numQrCodes))
                    {
                        hi = mid;
                    }
                    else 
                    {
                        lo = ((mid + 1) | 0);
                    }
                }
                /*var*/ let qrCodes = $.$wZnq.NCQ.StructuredAppend.Split$1(segments, version, lo, isUtf8);
                $.$wZnq.NCQ.StructuredAppend.AddStructuredAppendHeaders(qrCodes, data, eci);
                return new ($.$$.S.ValueTuple$$$($.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)), $.$$.S.Int32))().$ctor$3(qrCodes, version);
            }
            //--TRIMMABLE-BOUNDARY-END(12887618399)
            
            //--TRIMMABLE-BOUNDARY-START(34362454879)
            static /*bool */ FitsInCodes(/*List<DataSegment>*/ segments, /*int*/ version, /*int*/ cap, /*bool*/ isUtf8, /*int*/ maxCodes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362454879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let qrCodes = $.$wZnq.NCQ.StructuredAppend.Split$1(segments, version, cap, isUtf8);
                return qrCodes.Count <= maxCodes && $.$sl.SL.Enumerable.All($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment), qrCodes, new ($.$$.S.Func$$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment), $.$$.S.Boolean))().$ctor(this,  (/*code*/ code) =>
                {
                    return $.$wZnq.NCQ.DataSegment.GetBitLength$1(code, version) <= cap;
                }, _712f117a_fa32_4dab_b348_5ca52adf43e6 ??= {"r":262145,"p":[{"n":"code","p":$.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h}],"n":"","d":2716511,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(34362454879)
            
            //--TRIMMABLE-BOUNDARY-START(4297683807)
            static /*void */ AddStructuredAppendHeaders(/*List<List<DataSegment>>*/ qrCodes, /*byte[]*/ data, /*ECI*/ eci)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297683807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parity = $.$wZnq.NCQ.StructuredAppend.CalculateParity(data);
                /*var*/ let eciSegment = !$.$$.S.Object.Equals(eci, $.$wZnq.NCQ.ECI.None) ? new $.$wZnq.NCQ.DataSegmentEci().$ctor$2(eci) : null;
                /*var*/ let numQrCodes = qrCodes.Count;
                for(/*var*/ let i = 0; i < numQrCodes; i += 1)
                {
                    /*var*/ let segments = qrCodes.get_Item(i);
                    segments.Insert(0, new $.$wZnq.NCQ.DataSegmentStructuredAppend().$ctor$2(((i + 1) | 0), numQrCodes, parity));
                    if (eciSegment !== null)
                    {
                        segments.Insert(1, eciSegment);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297683807)
            
            //--TRIMMABLE-BOUNDARY-START(38657422175)
            static /*int */ FullCapacity(/*int*/ version, /*QrCode.Ecc*/ ecl, /*ECI*/ eci)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657422175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let structuredAppendLength = new $.$wZnq.NCQ.DataSegmentStructuredAppend().$ctor$2(1, 10, 0).GetTotalLength(40);
                /*var*/ let eciLength = !eci.Equals$2($.$wZnq.NCQ.ECI.None) ? new $.$wZnq.NCQ.DataSegmentEci().$ctor$2(eci).GetTotalLength(40) : 0;
                return (((((($.$wZnq.NCQ.QrCodeParameters.GetCodewordDataCapacity(version, ecl) * 8) | 0) - structuredAppendLength) | 0) - eciLength) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(38657422175)
            
            //--TRIMMABLE-BOUNDARY-START(42952389471)
            static /*List<List<DataSegment>> */ Split(/*byte[]*/ data, /*int*/ version, /*QrCode.Ecc*/ ecl, /*ECI*/ eci, /*bool*/ isUtf8)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952389471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let segments = $.$wZnq.NCQ.SegmentCompaction.BuildSegments$1(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$4(data), version, false);
                /*var*/ let result = $.$wZnq.NCQ.StructuredAppend.Split$1(segments, version, $.$wZnq.NCQ.StructuredAppend.FullCapacity(version, ecl, eci), isUtf8);
                return result.Count <= 16 ? result : (() =>
                {
        throw new $.$wZnq.NCQ.DataTooLongException().$ctor$15("The text is too long to fit into 16 QR codes")        })();
            }
            //--TRIMMABLE-BOUNDARY-END(42952389471)
            
            //--TRIMMABLE-BOUNDARY-START(47247356767)
            static /*List<List<DataSegment>> */ Split$1(/*List<DataSegment>*/ segments, /*int*/ version, /*int*/ dataCapacity, /*bool*/ isUtf8)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247356767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = new ($.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)))().$ctor$1();
                /*var*/ let current = new ($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment))().$ctor$1();
                /*var*/ let bitLength = 0;
                var $en2 = segments.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var wholeSegment = $en2.Current;
                    {
                        /*var*/ let segment = wholeSegment;
                        while(true)
                        {
                            /*var*/ let segmentLength = segment.GetTotalLength(version);
                            if (((bitLength + segmentLength) | 0) <= dataCapacity)
                            {
                                current.Add(segment);
                                bitLength += segmentLength;
                                break;
                            }
                            /*var*/ let remainingBits = ((dataCapacity - bitLength) | 0);
                            /*var*/ let numBytes = $.$wZnq.NCQ.DataSegment.GetByteCount(segment.Mode, ((remainingBits - $.$wZnq.NCQ.DataSegment.GetHeaderLength(segment.Mode, version)) | 0));
                            if (isUtf8)
                            {
                                /*var*/ let dataBytes = segment.DataBytes;
                                while(numBytes > 0 && ($.$wZnq.NCQ.ArraySegmentExtensions.At($.$$.S.Byte, dataBytes, numBytes) & 192) === 128)
                                {
                                    numBytes -= 1;
                                }
                            }
                            if (numBytes <= 0 && current.Count > 0)
                            {
                                result.Add(current);
                                current = new ($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment))().$ctor$1();
                                bitLength = 0;
                                continue;
                            }
                            if (numBytes <= 0)
                            {
                                numBytes = 1;
                            }
                            /*var*/ let splitSegments = $.$wZnq.NCQ.StructuredAppend.SplitSegment(segment, numBytes);
                            current.Add(splitSegments.Item1);
                            result.Add(current);
                            current = new ($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment))().$ctor$1();
                            bitLength = 0;
                            segment = splitSegments.Item2;
                            if (segment.DataLength === 0)
                            {
                                break;
                            }
                        }
                    }
                }
                result.Add(current);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(47247356767)
            
            //--TRIMMABLE-BOUNDARY-START(51542324063)
            static /*Tuple<DataSegment, DataSegment> */ SplitSegment(/*DataSegment*/ segment, /*int*/ numBytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542324063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$$.S.Tuple$$$($.$wZnq.NCQ.DataSegment, $.$wZnq.NCQ.DataSegment))().$ctor$1($.$wZnq.NCQ.DataSegment.MakeSegment(segment.Mode, $.$wZnq.NCQ.ArraySegmentExtensions.MakeSlice($.$$.S.Byte, segment.DataBytes, 0, numBytes)), $.$wZnq.NCQ.DataSegment.MakeSegment(segment.Mode, $.$wZnq.NCQ.ArraySegmentExtensions.MakeSlice($.$$.S.Byte, segment.DataBytes, numBytes, ((segment.DataLength - numBytes) | 0))));
            }
            //--TRIMMABLE-BOUNDARY-END(51542324063)
            
            //--TRIMMABLE-BOUNDARY-START(25772520287)
            static /*byte */ CalculateParity(/*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772520287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Aggregate$1($.$$.S.Byte, $.$$.S.Byte, data, 0, new ($.$$.S.Func$$$$($.$$.S.Byte, $.$$.S.Byte, $.$$.S.Byte))().$ctor(this,  (/*current*/ current, /*value*/ value) =>
                {
                    return $.$cast((current ^ value), $.$$.S.Byte);
                }, _0aa2bb1b_76df_41fe_adb6_b65128f50900 ??= {"r":393217,"p":[{"n":"current","p":393217},{"n":"value","p":393217}],"n":"","d":2716511,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(25772520287)
            
            static $h = 2716511;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182585695),
    {
      "r": $.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)).$h,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecl",
          "p": 1930079
        }
      ],
      "n": "BuildFromText",
      "d": 2716511,
      "h": 17182585695,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17182585695),
//--TRIMMABLE-BOUNDARY-START(21477552991),
    {
      "r": $.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)).$h,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "eci",
          "p": 1078111
        },
        {
          "n": "isUtf8",
          "p": 262145
        }
      ],
      "n": "BuildSegments",
      "d": 2716511,
      "h": 21477552991,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21477552991),
//--TRIMMABLE-BOUNDARY-START(8592651103),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)), $.$$.S.Int32).$h,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "minVersion",
          "p": 655361
        },
        {
          "n": "maxVersion",
          "p": 655361
        },
        {
          "n": "ecl",
          "p": 1930079
        }
      ],
      "n": "BuildBalancedFromText",
      "d": 2716511,
      "h": 8592651103,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592651103),
//--TRIMMABLE-BOUNDARY-START(12887618399),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)), $.$$.S.Int32).$h,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "minVersion",
          "p": 655361
        },
        {
          "n": "maxVersion",
          "p": 655361
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "eci",
          "p": 1078111
        },
        {
          "n": "isUtf8",
          "p": 262145
        }
      ],
      "n": "BuildBalancedSegments",
      "d": 2716511,
      "h": 12887618399,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12887618399),
//--TRIMMABLE-BOUNDARY-START(34362454879),
    {
      "r": 262145,
      "p": [
        {
          "n": "segments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "cap",
          "p": 655361
        },
        {
          "n": "isUtf8",
          "p": 262145
        },
        {
          "n": "maxCodes",
          "p": 655361
        }
      ],
      "n": "FitsInCodes",
      "d": 2716511,
      "h": 34362454879,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34362454879),
//--TRIMMABLE-BOUNDARY-START(4297683807),
    {
      "r": 65537,
      "p": [
        {
          "n": "qrCodes",
          "p": $.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)).$h
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "eci",
          "p": 1078111
        }
      ],
      "n": "AddStructuredAppendHeaders",
      "d": 2716511,
      "h": 4297683807,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4297683807),
//--TRIMMABLE-BOUNDARY-START(38657422175),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "eci",
          "p": 1078111
        }
      ],
      "n": "FullCapacity",
      "d": 2716511,
      "h": 38657422175,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38657422175),
//--TRIMMABLE-BOUNDARY-START(42952389471),
    {
      "r": $.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)).$h,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "eci",
          "p": 1078111
        },
        {
          "n": "isUtf8",
          "p": 262145
        }
      ],
      "n": "Split",
      "d": 2716511,
      "h": 42952389471,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42952389471),
//--TRIMMABLE-BOUNDARY-START(47247356767),
    {
      "r": $.$$.SCG.List$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment)).$h,
      "p": [
        {
          "n": "segments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "version",
          "p": 655361
        },
        {
          "n": "dataCapacity",
          "p": 655361
        },
        {
          "n": "isUtf8",
          "p": 262145
        }
      ],
      "n": "Split",
      "o": "@$1",
      "d": 2716511,
      "h": 47247356767,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47247356767),
//--TRIMMABLE-BOUNDARY-START(51542324063),
    {
      "r": $.$$.S.Tuple$$$($.$wZnq.NCQ.DataSegment, $.$wZnq.NCQ.DataSegment).$h,
      "p": [
        {
          "n": "segment",
          "p": 422751
        },
        {
          "n": "numBytes",
          "p": 655361
        }
      ],
      "n": "SplitSegment",
      "d": 2716511,
      "h": 51542324063,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51542324063),
//--TRIMMABLE-BOUNDARY-START(25772520287),
    {
      "r": 393217,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "CalculateParity",
      "d": 2716511,
      "h": 25772520287,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25772520287)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067487583),
    {
      "t": 655361,
      "n": "CompactionVersion",
      "d": 2716511,
      "h": 30067487583,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30067487583)
  ],
  "h": 2716511
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.StructuredAppend`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}StructuredAppend`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2716511)
        
        

        //--TRIMMABLE-BOUNDARY-START(1667935)
        $asm.$cls(`$wZnq.NCQ.Penalty`, ($self) => class Penalty
        {
            //--TRIMMABLE-BOUNDARY-START(85901013855)
            static /*int */ Calculate(/*ScoringMatrix*/ matrix, /*int*/ lowestPenaltySoFar)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901013855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sum = $.$wZnq.NCQ.Penalty.Calc2By2Blocks(matrix.Rows);
                if (sum >= lowestPenaltySoFar)
                {
                    return sum;
                }
                sum += $.$wZnq.NCQ.Penalty.CalcSameColor(matrix.Columns);
                if (sum >= lowestPenaltySoFar)
                {
                    return sum;
                }
                sum += $.$wZnq.NCQ.Penalty.CalcSameColor(matrix.Rows);
                if (sum >= lowestPenaltySoFar)
                {
                    return sum;
                }
                sum += $.$wZnq.NCQ.Penalty.CalcFinderPattern(matrix.Rows);
                if (sum >= lowestPenaltySoFar)
                {
                    return sum;
                }
                sum += $.$wZnq.NCQ.Penalty.CalcFinderPattern(matrix.Columns);
                if (sum >= lowestPenaltySoFar)
                {
                    return sum;
                }
                return ((sum + $.$wZnq.NCQ.Penalty.CalcColorBalance(matrix.Rows)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(85901013855)
            
            //--TRIMMABLE-BOUNDARY-START(90195981151)
            static /*int */ CalculateFully(/*ScoringMatrix*/ matrix, /*ref PenaltyScore*/ penaltyInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195981151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                penaltyInfo.$v.Blocks = $.$wZnq.NCQ.Penalty.Calc2By2Blocks(matrix.Rows);
                penaltyInfo.$v.VerticalStreaks = $.$wZnq.NCQ.Penalty.CalcSameColor(matrix.Columns);
                penaltyInfo.$v.HorizontalStreaks = $.$wZnq.NCQ.Penalty.CalcSameColor(matrix.Rows);
                penaltyInfo.$v.HorizontalFinderPatterns = $.$wZnq.NCQ.Penalty.CalcFinderPattern(matrix.Rows);
                penaltyInfo.$v.VerticalFinderPatterns = $.$wZnq.NCQ.Penalty.CalcFinderPattern(matrix.Columns);
                penaltyInfo.$v.ColorBalance = $.$wZnq.NCQ.Penalty.CalcColorBalance(matrix.Rows);
                penaltyInfo.$v.Total = ((((((((((penaltyInfo.$v.Blocks + penaltyInfo.$v.VerticalStreaks) | 0) + penaltyInfo.$v.HorizontalStreaks) | 0) + penaltyInfo.$v.HorizontalFinderPatterns) | 0) + penaltyInfo.$v.VerticalFinderPatterns) | 0) + penaltyInfo.$v.ColorBalance) | 0);
                return penaltyInfo.$v.Total;
            }
            //--TRIMMABLE-BOUNDARY-END(90195981151)
            
            //--TRIMMABLE-BOUNDARY-START(68721144671)
            static /*int */ CalcSameColor(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721144671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = modules.UsedWordsPerRow;
                switch($switch1)
                {
                    case 1:
                    return $.$wZnq.NCQ.Penalty.CalcSameColorOneWord(modules);
                    case 2:
                    return $.$wZnq.NCQ.Penalty.CalcSameColorTwoWords(modules);
                    default:
                    return $.$wZnq.NCQ.Penalty.CalcSameColorThreeWords(modules);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721144671)
            
            //--TRIMMABLE-BOUNDARY-START(17181537119)
            /*int*/ static BaseSameColor = 66;
            //--TRIMMABLE-BOUNDARY-END(17181537119)
            
            //--TRIMMABLE-BOUNDARY-START(73016111967)
            static /*int */ CalcSameColorOneWord(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016111967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                if (size < 5)
                {
                    return 0;
                }
                /*var*/ let edgeMask = BigInt.asUintN(64, (BigInt.asUintN(64, 1n << BigInt((((size - 4) | 0))))) - 1n);
                /*var*/ let fiveWindowCount = 0;
                /*var*/ let run5StartCount = 0;
                for(/*var*/ let y = 0; y < size; y += 1)
                {
                    /*var*/ let w = $.$$.System.Array.$ReadT1.call(raw, y);
                    /*var*/ let t = w ^ (w >> 1n);
                    /*var*/ let tz = (~(t | (t >> 1n)) & 0xFFFFFFFFFFFFFFFFn);
                    /*var*/ let fw = tz & (tz >> 2n) & edgeMask;
                    /*var*/ let rs = fw & ((BigInt.asUintN(64, t << 1n)) | 1n);
                    fiveWindowCount += $.$wZnq.NCQ.BitMatrix.PopCount$1(fw);
                    run5StartCount += $.$wZnq.NCQ.BitMatrix.PopCount$1(rs);
                }
                return ((((fiveWindowCount + ((2 * run5StartCount) | 0)) | 0) - 66/*BaseSameColor*/) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(73016111967)
            
            //--TRIMMABLE-BOUNDARY-START(81606046559)
            static /*int */ CalcSameColorTwoWords(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606046559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                if (size < 5)
                {
                    return 0;
                }
                /*var*/ let edgeMask = $.$wZnq.NCQ.Penalty.GetEdgeMask(((size - 4) | 0));
                /*var*/ let fiveWindowCount = 0;
                /*var*/ let run5StartCount = 0;
                for(/*var*/ let y = 0; y < size; y += 1)
                {
                    /*var*/ let rowOffset = ((2 * y) | 0);
                    /*var*/ let w0 = $.$$.System.Array.$ReadT1.call(raw, rowOffset);
                    /*var*/ let w1 = $.$$.System.Array.$ReadT1.call(raw, ((rowOffset + 1) | 0));
                    /*var*/ let t0 = w0 ^ ((w0 >> 1n) | (BigInt.asUintN(64, w1 << 63n)));
                    /*var*/ let t1 = w1 ^ (w1 >> 1n);
                    /*var*/ let tz0 = (~(t0 | ((t0 >> 1n) | (BigInt.asUintN(64, t1 << 63n)))) & 0xFFFFFFFFFFFFFFFFn);
                    /*var*/ let tz1 = (~(t1 | (t1 >> 1n)) & 0xFFFFFFFFFFFFFFFFn);
                    /*var*/ let fw0 = tz0 & ((tz0 >> 2n) | (BigInt.asUintN(64, tz1 << 62n))) & $.$$.System.Array.$ReadT1.call(edgeMask, 0);
                    /*var*/ let fw1 = tz1 & (tz1 >> 2n) & $.$$.System.Array.$ReadT1.call(edgeMask, 1);
                    /*var*/ let rs0 = fw0 & ((BigInt.asUintN(64, t0 << 1n)) | 1n);
                    /*var*/ let rs1 = fw1 & ((BigInt.asUintN(64, t1 << 1n)) | (t0 >> 63n));
                    fiveWindowCount += (($.$wZnq.NCQ.BitMatrix.PopCount$1(fw0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(fw1)) | 0);
                    run5StartCount += (($.$wZnq.NCQ.BitMatrix.PopCount$1(rs0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(rs1)) | 0);
                }
                return ((((fiveWindowCount + ((2 * run5StartCount) | 0)) | 0) - 66/*BaseSameColor*/) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(81606046559)
            
            //--TRIMMABLE-BOUNDARY-START(77311079263)
            static /*int */ CalcSameColorThreeWords(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311079263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                if (size < 5)
                {
                    return 0;
                }
                /*var*/ let edgeMask = $.$wZnq.NCQ.Penalty.GetEdgeMask(((size - 4) | 0));
                /*var*/ let fiveWindowCount = 0;
                /*var*/ let run5StartCount = 0;
                for(/*var*/ let y = 0; y < size; y += 1)
                {
                    /*var*/ let rowOffset = ((4/*BitMatrix.MaxWordsPerRow*/ * y) | 0);
                    /*var*/ let w0 = $.$$.System.Array.$ReadT1.call(raw, rowOffset);
                    /*var*/ let w1 = $.$$.System.Array.$ReadT1.call(raw, ((rowOffset + 1) | 0));
                    /*var*/ let w2 = $.$$.System.Array.$ReadT1.call(raw, ((rowOffset + 2) | 0));
                    /*var*/ let t0 = w0 ^ ((w0 >> 1n) | (BigInt.asUintN(64, w1 << 63n)));
                    /*var*/ let t1 = w1 ^ ((w1 >> 1n) | (BigInt.asUintN(64, w2 << 63n)));
                    /*var*/ let t2 = w2 ^ (w2 >> 1n);
                    /*var*/ let tz0 = (~(t0 | ((t0 >> 1n) | (BigInt.asUintN(64, t1 << 63n)))) & 0xFFFFFFFFFFFFFFFFn);
                    /*var*/ let tz1 = (~(t1 | ((t1 >> 1n) | (BigInt.asUintN(64, t2 << 63n)))) & 0xFFFFFFFFFFFFFFFFn);
                    /*var*/ let tz2 = (~(t2 | (t2 >> 1n)) & 0xFFFFFFFFFFFFFFFFn);
                    /*var*/ let fw0 = tz0 & ((tz0 >> 2n) | (BigInt.asUintN(64, tz1 << 62n))) & $.$$.System.Array.$ReadT1.call(edgeMask, 0);
                    /*var*/ let fw1 = tz1 & ((tz1 >> 2n) | (BigInt.asUintN(64, tz2 << 62n))) & $.$$.System.Array.$ReadT1.call(edgeMask, 1);
                    /*var*/ let fw2 = tz2 & (tz2 >> 2n) & $.$$.System.Array.$ReadT1.call(edgeMask, 2);
                    /*var*/ let rs0 = fw0 & ((BigInt.asUintN(64, t0 << 1n)) | 1n);
                    /*var*/ let rs1 = fw1 & ((BigInt.asUintN(64, t1 << 1n)) | (t0 >> 63n));
                    /*var*/ let rs2 = fw2 & ((BigInt.asUintN(64, t2 << 1n)) | (t1 >> 63n));
                    fiveWindowCount += (((($.$wZnq.NCQ.BitMatrix.PopCount$1(fw0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(fw1)) | 0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(fw2)) | 0);
                    run5StartCount += (((($.$wZnq.NCQ.BitMatrix.PopCount$1(rs0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(rs1)) | 0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(rs2)) | 0);
                }
                return ((((fiveWindowCount + ((2 * run5StartCount) | 0)) | 0) - 66/*BaseSameColor*/) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(77311079263)
            
            //--TRIMMABLE-BOUNDARY-START(30066439007)
            static /*int */ Calc2By2Blocks(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066439007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = modules.UsedWordsPerRow;
                switch($switch1)
                {
                    case 1:
                    return $.$wZnq.NCQ.Penalty.Calc2By2BlocksOneWord(modules);
                    case 2:
                    return $.$wZnq.NCQ.Penalty.Calc2By2BlocksTwoWords(modules);
                    default:
                    return $.$wZnq.NCQ.Penalty.Calc2By2BlocksThreeWords(modules);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066439007)
            
            //--TRIMMABLE-BOUNDARY-START(8591602527)
            /*int*/ static Base2By2Blocks = 12;
            //--TRIMMABLE-BOUNDARY-END(8591602527)
            
            //--TRIMMABLE-BOUNDARY-START(34361406303)
            static /*int */ Calc2By2BlocksOneWord(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361406303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                if (size < 2)
                {
                    return 0;
                }
                /*var*/ let edgeMask = BigInt.asUintN(64, (BigInt.asUintN(64, 1n << BigInt((((size - 1) | 0))))) - 1n);
                /*var*/ let count = 0;
                /*var*/ let b = $.$$.System.Array.$ReadT1.call(raw, 0);
                for(/*var*/ let y = 0; y < ((size - 1) | 0); y += 1)
                {
                    /*var*/ let a = b;
                    b = $.$$.System.Array.$ReadT1.call(raw, ((y + 1) | 0));
                    /*var*/ let monochrome = (~((a ^ (a >> 1n)) | (b ^ (b >> 1n)) | (a ^ b)) & 0xFFFFFFFFFFFFFFFFn) & edgeMask;
                    count += $.$wZnq.NCQ.BitMatrix.PopCount$1(monochrome);
                }
                return (((((count - 12/*Base2By2Blocks*/) | 0)) * 3) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(34361406303)
            
            //--TRIMMABLE-BOUNDARY-START(42951340895)
            static /*int */ Calc2By2BlocksTwoWords(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951340895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                if (size < 2)
                {
                    return 0;
                }
                /*var*/ let edgeMask = $.$wZnq.NCQ.Penalty.GetEdgeMask(((size - 1) | 0));
                /*var*/ let count = 0;
                for(/*var*/ let y = 0; y < ((size - 1) | 0); y += 1)
                {
                    /*var*/ let aOffset = ((2 * y) | 0);
                    /*var*/ let bOffset = ((aOffset + 2) | 0);
                    /*var*/ let a0 = $.$$.System.Array.$ReadT1.call(raw, aOffset);
                    /*var*/ let a1 = $.$$.System.Array.$ReadT1.call(raw, ((aOffset + 1) | 0));
                    /*var*/ let b0 = $.$$.System.Array.$ReadT1.call(raw, bOffset);
                    /*var*/ let b1 = $.$$.System.Array.$ReadT1.call(raw, ((bOffset + 1) | 0));
                    /*var*/ let mono0 = (~((a0 ^ ((a0 >> 1n) | (BigInt.asUintN(64, a1 << 63n)))) | (b0 ^ ((b0 >> 1n) | (BigInt.asUintN(64, b1 << 63n)))) | (a0 ^ b0)) & 0xFFFFFFFFFFFFFFFFn) & $.$$.System.Array.$ReadT1.call(edgeMask, 0);
                    /*var*/ let mono1 = (~((a1 ^ (a1 >> 1n)) | (b1 ^ (b1 >> 1n)) | (a1 ^ b1)) & 0xFFFFFFFFFFFFFFFFn) & $.$$.System.Array.$ReadT1.call(edgeMask, 1);
                    count += (($.$wZnq.NCQ.BitMatrix.PopCount$1(mono0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(mono1)) | 0);
                }
                return (((((count - 12/*Base2By2Blocks*/) | 0)) * 3) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42951340895)
            
            //--TRIMMABLE-BOUNDARY-START(38656373599)
            static /*int */ Calc2By2BlocksThreeWords(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656373599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                if (size < 2)
                {
                    return 0;
                }
                /*var*/ let edgeMask = $.$wZnq.NCQ.Penalty.GetEdgeMask(((size - 1) | 0));
                /*var*/ let count = 0;
                for(/*var*/ let y = 0; y < ((size - 1) | 0); y += 1)
                {
                    /*var*/ let aOffset = ((4/*BitMatrix.MaxWordsPerRow*/ * y) | 0);
                    /*var*/ let bOffset = ((aOffset + 4/*BitMatrix.MaxWordsPerRow*/) | 0);
                    /*var*/ let a0 = $.$$.System.Array.$ReadT1.call(raw, aOffset);
                    /*var*/ let a1 = $.$$.System.Array.$ReadT1.call(raw, ((aOffset + 1) | 0));
                    /*var*/ let a2 = $.$$.System.Array.$ReadT1.call(raw, ((aOffset + 2) | 0));
                    /*var*/ let b0 = $.$$.System.Array.$ReadT1.call(raw, bOffset);
                    /*var*/ let b1 = $.$$.System.Array.$ReadT1.call(raw, ((bOffset + 1) | 0));
                    /*var*/ let b2 = $.$$.System.Array.$ReadT1.call(raw, ((bOffset + 2) | 0));
                    /*var*/ let mono0 = (~((a0 ^ ((a0 >> 1n) | (BigInt.asUintN(64, a1 << 63n)))) | (b0 ^ ((b0 >> 1n) | (BigInt.asUintN(64, b1 << 63n)))) | (a0 ^ b0)) & 0xFFFFFFFFFFFFFFFFn) & $.$$.System.Array.$ReadT1.call(edgeMask, 0);
                    /*var*/ let mono1 = (~((a1 ^ ((a1 >> 1n) | (BigInt.asUintN(64, a2 << 63n)))) | (b1 ^ ((b1 >> 1n) | (BigInt.asUintN(64, b2 << 63n)))) | (a1 ^ b1)) & 0xFFFFFFFFFFFFFFFFn) & $.$$.System.Array.$ReadT1.call(edgeMask, 1);
                    /*var*/ let mono2 = (~((a2 ^ (a2 >> 1n)) | (b2 ^ (b2 >> 1n)) | (a2 ^ b2)) & 0xFFFFFFFFFFFFFFFFn) & $.$$.System.Array.$ReadT1.call(edgeMask, 2);
                    count += (((($.$wZnq.NCQ.BitMatrix.PopCount$1(mono0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(mono1)) | 0) + $.$wZnq.NCQ.BitMatrix.PopCount$1(mono2)) | 0);
                }
                return (((((count - 12/*Base2By2Blocks*/) | 0)) * 3) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(38656373599)
            
            //--TRIMMABLE-BOUNDARY-START(51541275487)
            static /*int */ CalcFinderPattern(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541275487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = modules.UsedWordsPerRow;
                switch($switch1)
                {
                    case 1:
                    return $.$wZnq.NCQ.Penalty.CalcFinderPatternOneWord(modules);
                    case 2:
                    return $.$wZnq.NCQ.Penalty.CalcFinderPatternTwoWords(modules);
                    default:
                    return $.$wZnq.NCQ.Penalty.CalcFinderPatternThreeWords(modules);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541275487)
            
            //--TRIMMABLE-BOUNDARY-START(12886569823)
            /*int*/ static BaseFinderPattern = 9;
            //--TRIMMABLE-BOUNDARY-END(12886569823)
            
            //--TRIMMABLE-BOUNDARY-START(55836242783)
            static /*int */ CalcFinderPatternOneWord(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836242783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                /*var*/ let count = 0;
                for(/*var*/ let y = 0; y < size; y += 1)
                {
                    count += $.$wZnq.NCQ.Penalty.MatchesInWord(0n, $.$$.System.Array.$ReadT1.call(raw, y), 0n);
                }
                return (((((count - 9/*BaseFinderPattern*/) | 0)) * 40) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(55836242783)
            
            //--TRIMMABLE-BOUNDARY-START(64426177375)
            static /*int */ CalcFinderPatternTwoWords(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426177375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                /*var*/ let count = 0;
                for(/*var*/ let y = 0; y < size; y += 1)
                {
                    /*var*/ let rowOffset = ((2 * y) | 0);
                    /*var*/ let w0 = $.$$.System.Array.$ReadT1.call(raw, rowOffset);
                    /*var*/ let w1 = $.$$.System.Array.$ReadT1.call(raw, ((rowOffset + 1) | 0));
                    count += (($.$wZnq.NCQ.Penalty.MatchesInWord(0n, w0, w1) + $.$wZnq.NCQ.Penalty.MatchesInWord(w0, w1, 0n)) | 0);
                }
                return (((((count - 9/*BaseFinderPattern*/) | 0)) * 40) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(64426177375)
            
            //--TRIMMABLE-BOUNDARY-START(60131210079)
            static /*int */ CalcFinderPatternThreeWords(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131210079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let raw = modules.Raw;
                /*var*/ let size = modules.Size;
                /*var*/ let count = 0;
                for(/*var*/ let y = 0; y < size; y += 1)
                {
                    /*var*/ let rowOffset = ((4/*BitMatrix.MaxWordsPerRow*/ * y) | 0);
                    /*var*/ let w0 = $.$$.System.Array.$ReadT1.call(raw, rowOffset);
                    /*var*/ let w1 = $.$$.System.Array.$ReadT1.call(raw, ((rowOffset + 1) | 0));
                    /*var*/ let w2 = $.$$.System.Array.$ReadT1.call(raw, ((rowOffset + 2) | 0));
                    count += (((($.$wZnq.NCQ.Penalty.MatchesInWord(0n, w0, w1) + $.$wZnq.NCQ.Penalty.MatchesInWord(w0, w1, w2)) | 0) + $.$wZnq.NCQ.Penalty.MatchesInWord(w1, w2, 0n)) | 0);
                }
                return (((((count - 9/*BaseFinderPattern*/) | 0)) * 40) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(60131210079)
            
            //--TRIMMABLE-BOUNDARY-START(103080883039)
            static /*int */ MatchesInWord(/*ulong*/ previous, /*ulong*/ w, /*ulong*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080883039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let r1 = (w >> 1n) | (BigInt.asUintN(64, next << 63n));
                /*var*/ let r2 = (w >> 2n) | (BigInt.asUintN(64, next << 62n));
                /*var*/ let r3 = (w >> 3n) | (BigInt.asUintN(64, next << 61n));
                /*var*/ let r4 = (w >> 4n) | (BigInt.asUintN(64, next << 60n));
                /*var*/ let r5 = (w >> 5n) | (BigInt.asUintN(64, next << 59n));
                /*var*/ let r6 = (w >> 6n) | (BigInt.asUintN(64, next << 58n));
                /*var*/ let r7 = (w >> 7n) | (BigInt.asUintN(64, next << 57n));
                /*var*/ let r8 = (w >> 8n) | (BigInt.asUintN(64, next << 56n));
                /*var*/ let r9 = (w >> 9n) | (BigInt.asUintN(64, next << 55n));
                /*var*/ let r10 = (w >> 10n) | (BigInt.asUintN(64, next << 54n));
                /*var*/ let l1 = (BigInt.asUintN(64, w << 1n)) | (previous >> 63n);
                /*var*/ let l2 = (BigInt.asUintN(64, w << 2n)) | (previous >> 62n);
                /*var*/ let l3 = (BigInt.asUintN(64, w << 3n)) | (previous >> 61n);
                /*var*/ let l4 = (BigInt.asUintN(64, w << 4n)) | (previous >> 60n);
                /*var*/ let pattern = w & r2 & r3 & r4 & r6 & (~(r1 | r5) & 0xFFFFFFFFFFFFFFFFn);
                /*var*/ let enclosed = pattern & (~(l1 | r7) & 0xFFFFFFFFFFFFFFFFn);
                return $.$wZnq.NCQ.BitMatrix.PopCount$1(enclosed & (~((l2 | l3 | l4) & (r8 | r9 | r10)) & 0xFFFFFFFFFFFFFFFFn));
            }
            //--TRIMMABLE-BOUNDARY-END(103080883039)
            
            //--TRIMMABLE-BOUNDARY-START(47246308191)
            static /*int */ CalcColorBalance(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246308191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let darkModules = modules.PopCount();
                /*var*/ let size = modules.Size;
                /*var*/ let totalNumber = ((size * size) | 0);
                /*var*/ let deviationSteps = $.trunc((($.$$.S.Math.Abs$3(((((2 * darkModules) | 0) - totalNumber) | 0)) * 10) | 0) / totalNumber);
                return ((10 * deviationSteps) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(47246308191)
            
            //--TRIMMABLE-BOUNDARY-START(94490948447)
            /*ConcurrentDictionary<int, ulong[]>*/ static EdgeMaskCache = null;
            //--TRIMMABLE-BOUNDARY-END(94490948447)
            
            //--TRIMMABLE-BOUNDARY-START(25771471711)
            /*Func<int, ulong[]>*/ static BuildEdgeMaskFunc = null;
            //--TRIMMABLE-BOUNDARY-END(25771471711)
            
            //--TRIMMABLE-BOUNDARY-START(98785915743)
            static /*ulong[] */ GetEdgeMask(/*int*/ validBits)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785915743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.Penalty.EdgeMaskCache.GetOrAdd(validBits, $.$wZnq.NCQ.Penalty.BuildEdgeMaskFunc);
            }
            //--TRIMMABLE-BOUNDARY-END(98785915743)
            
            //--TRIMMABLE-BOUNDARY-START(21476504415)
            static /*ulong[] */ BuildEdgeMask(/*int*/ validBits)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476504415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let validWord = validBits >> 6;
                /*var*/ let validBit = validBits & 63;
                /*var*/ let partialMask = BigInt.asUintN(64, (BigInt.asUintN(64, 1n << BigInt(validBit))) - 1n);
                /*var*/ let mask = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.UInt64), null, [3/*BitMatrix.MaxUsedWordsPerRow*/], null);
                for(/*var*/ let w = 0; w < mask.length; w += 1)
                {
                    if (w < validWord)
                    {
                        $.$$.System.Array.$WriteT1.call(mask, 18446744073709551615n, w);
                    }
                    else if (w === validWord)
                    {
                        $.$$.System.Array.$WriteT1.call(mask, partialMask, w);
                    }
                }
                return mask;
            }
            //--TRIMMABLE-BOUNDARY-END(21476504415)
            
            //--TRIMMABLE-BOUNDARY-START(4296635231)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296635231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(94490948447)
                    this.EdgeMaskCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$typeArray($.$$.S.UInt64)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(94490948447)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771471711)
                    this.BuildEdgeMaskFunc = new ($.$$.S.Func$$$($.$$.S.Int32, $.$typeArray($.$$.S.UInt64)))().$ctor($.$wZnq.NCQ.Penalty, $.$wZnq.NCQ.Penalty.BuildEdgeMask);
                    //--TRIMMABLE-BOUNDARY-END(25771471711)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296635231)
            
            static $h = 1667935;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901013855),
    {
      "r": 655361,
      "p": [
        {
          "n": "matrix",
          "p": 2454367
        },
        {
          "n": "lowestPenaltySoFar",
          "p": 655361
        }
      ],
      "n": "Calculate",
      "d": 1667935,
      "h": 85901013855,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(85901013855),
//--TRIMMABLE-BOUNDARY-START(90195981151),
    {
      "r": 655361,
      "p": [
        {
          "n": "matrix",
          "p": 2454367
        },
        {
          "n": "penaltyInfo",
          "p": 1733471,
          "f": 4
        }
      ],
      "n": "CalculateFully",
      "d": 1667935,
      "h": 90195981151,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90195981151),
//--TRIMMABLE-BOUNDARY-START(68721144671),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcSameColor",
      "d": 1667935,
      "h": 68721144671,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(68721144671),
//--TRIMMABLE-BOUNDARY-START(73016111967),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcSameColorOneWord",
      "d": 1667935,
      "h": 73016111967,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73016111967),
//--TRIMMABLE-BOUNDARY-START(81606046559),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcSameColorTwoWords",
      "d": 1667935,
      "h": 81606046559,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81606046559),
//--TRIMMABLE-BOUNDARY-START(77311079263),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcSameColorThreeWords",
      "d": 1667935,
      "h": 77311079263,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77311079263),
//--TRIMMABLE-BOUNDARY-START(30066439007),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "Calc2By2Blocks",
      "d": 1667935,
      "h": 30066439007,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30066439007),
//--TRIMMABLE-BOUNDARY-START(34361406303),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "Calc2By2BlocksOneWord",
      "d": 1667935,
      "h": 34361406303,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361406303),
//--TRIMMABLE-BOUNDARY-START(42951340895),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "Calc2By2BlocksTwoWords",
      "d": 1667935,
      "h": 42951340895,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42951340895),
//--TRIMMABLE-BOUNDARY-START(38656373599),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "Calc2By2BlocksThreeWords",
      "d": 1667935,
      "h": 38656373599,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656373599),
//--TRIMMABLE-BOUNDARY-START(51541275487),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcFinderPattern",
      "d": 1667935,
      "h": 51541275487,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51541275487),
//--TRIMMABLE-BOUNDARY-START(55836242783),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcFinderPatternOneWord",
      "d": 1667935,
      "h": 55836242783,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55836242783),
//--TRIMMABLE-BOUNDARY-START(64426177375),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcFinderPatternTwoWords",
      "d": 1667935,
      "h": 64426177375,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64426177375),
//--TRIMMABLE-BOUNDARY-START(60131210079),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcFinderPatternThreeWords",
      "d": 1667935,
      "h": 60131210079,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60131210079),
//--TRIMMABLE-BOUNDARY-START(103080883039),
    {
      "r": 655361,
      "p": [
        {
          "n": "previous",
          "p": 983041
        },
        {
          "n": "w",
          "p": 983041
        },
        {
          "n": "next",
          "p": 983041
        }
      ],
      "n": "MatchesInWord",
      "d": 1667935,
      "h": 103080883039,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103080883039),
//--TRIMMABLE-BOUNDARY-START(47246308191),
    {
      "r": 655361,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "CalcColorBalance",
      "d": 1667935,
      "h": 47246308191,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246308191),
//--TRIMMABLE-BOUNDARY-START(98785915743),
    {
      "r": $.$typeArray($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "validBits",
          "p": 655361
        }
      ],
      "n": "GetEdgeMask",
      "d": 1667935,
      "h": 98785915743,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98785915743),
//--TRIMMABLE-BOUNDARY-START(21476504415),
    {
      "r": $.$typeArray($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "validBits",
          "p": 655361
        }
      ],
      "n": "BuildEdgeMask",
      "d": 1667935,
      "h": 21476504415,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476504415)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181537119),
    {
      "t": 655361,
      "n": "BaseSameColor",
      "d": 1667935,
      "h": 17181537119,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181537119),
//--TRIMMABLE-BOUNDARY-START(8591602527),
    {
      "t": 655361,
      "n": "Base2By2Blocks",
      "d": 1667935,
      "h": 8591602527,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591602527),
//--TRIMMABLE-BOUNDARY-START(12886569823),
    {
      "t": 655361,
      "n": "BaseFinderPattern",
      "d": 1667935,
      "h": 12886569823,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886569823),
//--TRIMMABLE-BOUNDARY-START(94490948447),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$typeArray($.$$.S.UInt64)).$h,
      "n": "EdgeMaskCache",
      "d": 1667935,
      "h": 94490948447,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(94490948447),
//--TRIMMABLE-BOUNDARY-START(25771471711),
    {
      "t": $.$$.S.Func$$$($.$$.S.Int32, $.$typeArray($.$$.S.UInt64)).$h,
      "n": "BuildEdgeMaskFunc",
      "d": 1667935,
      "h": 25771471711,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771471711)
  ],
  "h": 1667935
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.Penalty`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}Penalty`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1667935)
        
        

        //--TRIMMABLE-BOUNDARY-START(2519903)
        $asm.$cls(`$wZnq.NCQ.SegmentCompaction`, ($self) => class SegmentCompaction
        {
            //--TRIMMABLE-BOUNDARY-START(21477356383)
            static /*List<DataSegment> */ BuildSegments$1(/*ArraySegment<byte>*/ bytes, /*int*/ version, /*bool*/ considerKanjiMode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477356383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.SegmentCompaction.BuildSegments(bytes, $.$wZnq.NCQ.SegmentCompaction.BuildBlocks(bytes, considerKanjiMode), version);
            }
            //--TRIMMABLE-BOUNDARY-END(21477356383)
            
            //--TRIMMABLE-BOUNDARY-START(17182389087)
            static /*List<DataSegment> */ BuildSegments(/*ArraySegment<byte>*/ bytes, /*Block[]*/ blocks, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182389087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (blocks.length === 0)
                {
                    return new ($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment))().$ctor$1();
                }
                $.$wZnq.NCQ.SegmentCompaction.AssignModes(blocks, version);
                /*var*/ let segments = new ($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment))().$ctor$1();
                /*var*/ let offset = 0;
                /*var*/ let length = 0;
                for(/*var*/ let i = 0; i < blocks.length; i += 1)
                {
                    length += $.$$.System.Array.$ReadT1.call(blocks, i).Length;
                    if (((i + 1) | 0) === blocks.length || $.$$.System.Array.$ReadT1.call(blocks, ((i + 1) | 0)).Mode !== $.$$.System.Array.$ReadT1.call(blocks, i).Mode)
                    {
                        segments.Add($.$wZnq.NCQ.DataSegment.MakeSegment($.$$.System.Array.$ReadT1.call(blocks, i).Mode, $.$wZnq.NCQ.ArraySegmentExtensions.MakeSlice($.$$.S.Byte, bytes, offset, length)));
                        offset += length;
                        length = 0;
                    }
                }
                return segments;
            }
            //--TRIMMABLE-BOUNDARY-END(17182389087)
            
            //--TRIMMABLE-BOUNDARY-START(64427029343)
            /*int*/ static NumModes = 4;
            //--TRIMMABLE-BOUNDARY-END(64427029343)
            
            //--TRIMMABLE-BOUNDARY-START(25772323679)
            /*int[]*/ static ByteCosts = null;
            //--TRIMMABLE-BOUNDARY-END(25772323679)
            
            //--TRIMMABLE-BOUNDARY-START(60132062047)
            static /*int */ ModeIndex(/*DataSegmentMode*/ mode)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60132062047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ((mode - 1) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132062047)
            
            //--TRIMMABLE-BOUNDARY-START(55837094751)
            static /*DataSegmentMode */ ModeAt(/*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55837094751);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$cast((((index + 1) | 0)), $.$wZnq.NCQ.DataSegmentMode);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55837094751)
            
            //--TRIMMABLE-BOUNDARY-START(51542127455)
            static /*int */ MinBitLength(/*Block[]*/ blocks)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542127455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let cost = 0;
                let $i1 = 0;
                let $arr1 = blocks;
                while ($i1 < $arr1.length)
                {
                    let block = $arr1[$i1++];
                    cost += ((block.Length * $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.SegmentCompaction.ByteCosts, $.$wZnq.NCQ.SegmentCompaction.ModeIndex(block.Mode))) | 0);
                }
                return $.trunc(cost / 6);
            }
            //--TRIMMABLE-BOUNDARY-END(51542127455)
            
            //--TRIMMABLE-BOUNDARY-START(47247160159)
            /*int*/ static Infinity = 1073741823;
            //--TRIMMABLE-BOUNDARY-END(47247160159)
            
            //--TRIMMABLE-BOUNDARY-START(8592454495)
            static /*void */ AssignModes(/*Block[]*/ blocks, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592454495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let headerCosts = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [4/*NumModes*/], null);
                for(/*var*/ let m = 0; m < 4/*NumModes*/; m += 1)
                {
                    $.$$.System.Array.$WriteT1.call(headerCosts, ((6 * $.$wZnq.NCQ.SegmentCompaction.GetSegmentHeaderLength($.$wZnq.NCQ.SegmentCompaction.ModeAt(m), version)) | 0), m);
                }
                /*var*/ let blockCount = blocks.length;
                /*var*/ let previousCosts = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [4/*NumModes*/], null);
                /*var*/ let costs = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [4/*NumModes*/], null);
                /*var*/ let previousModes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((blockCount * 4/*NumModes*/) | 0)], null);
                for(/*var*/ let i = 0; i < blockCount; i += 1)
                {
                    $.$tupleUnpack(($tp) =>
                    {
                        previousCosts = $tp.Item1;
                        costs = $tp.Item2;
                    }).$v = { Item1: costs, Item2: previousCosts };
                    /*var*/ let block = $.$$.System.Array.$ReadT1.call(blocks, i);
                    for(/*var*/ let m = 0; m < 4/*NumModes*/; m += 1)
                    {
                        if (!$.$wZnq.NCQ.SegmentCompaction.CanEncode($.$wZnq.NCQ.SegmentCompaction.ModeAt(m), block.Mode))
                        {
                            $.$$.System.Array.$WriteT1.call(costs, 1073741823/*Infinity*/, m);
                            continue;
                        }
                        /*var*/ let dataCost = ((block.Length * $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.SegmentCompaction.ByteCosts, m)) | 0);
                        if (i === 0)
                        {
                            $.$$.System.Array.$WriteT1.call(costs, (($.$$.System.Array.$ReadT1.call(headerCosts, m) + dataCost) | 0), m);
                            continue;
                        }
                        /*var*/ let best = (($.$$.System.Array.$ReadT1.call(previousCosts, m) + dataCost) | 0);
                        /*var*/ let bestPrevious = m;
                        for(/*var*/ let p = 0; p < 4/*NumModes*/; p += 1)
                        {
                            /*var*/ let previousCost = $.$$.System.Array.$ReadT1.call(previousCosts, p);
                            if (p === m || previousCost >= 1073741823/*Infinity*/)
                            {
                                continue;
                            }
                            /*var*/ let cost = (((($.$wZnq.NCQ.SegmentCompaction.RoundUpToBits(previousCost) + $.$$.System.Array.$ReadT1.call(headerCosts, m)) | 0) + dataCost) | 0);
                            if (cost < best)
                            {
                                best = cost;
                                bestPrevious = p;
                            }
                        }
                        $.$$.System.Array.$WriteT1.call(costs, best, m);
                        $.$$.System.Array.$WriteT1.call(previousModes, $.$cast(bestPrevious, $.$$.S.Byte), ((((i * 4/*NumModes*/) | 0) + m) | 0));
                    }
                }
                /*var*/ let mode = 0;
                for(/*var*/ let m = 1; m < 4/*NumModes*/; m += 1)
                {
                    if ($.$wZnq.NCQ.SegmentCompaction.RoundUpToBits($.$$.System.Array.$ReadT1.call(costs, m)) < $.$wZnq.NCQ.SegmentCompaction.RoundUpToBits($.$$.System.Array.$ReadT1.call(costs, mode)))
                    {
                        mode = m;
                    }
                }
                for(/*var*/ let i = ((blockCount - 1) | 0); i >= 0; i -= 1)
                {
                    $.$$.System.Array.$ReadT1.call(blocks, i).Mode = $.$wZnq.NCQ.SegmentCompaction.ModeAt(mode);
                    mode = $.$$.System.Array.$ReadT1.call(previousModes, ((((i * 4/*NumModes*/) | 0) + mode) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592454495)
            
            //--TRIMMABLE-BOUNDARY-START(68721996639)
            static /*int */ RoundUpToBits(/*int*/ cost)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721996639);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (($.trunc((((cost + 5) | 0)) / 6) * 6) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721996639)
            
            //--TRIMMABLE-BOUNDARY-START(34362258271)
            static /*bool */ CanEncode(/*DataSegmentMode*/ segmentMode, /*DataSegmentMode*/ blockMode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362258271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return segmentMode === 4/*DataSegmentMode.Binary*/ || segmentMode === blockMode || (segmentMode === 2/*DataSegmentMode.Alphanumeric*/ && blockMode === 1/*DataSegmentMode.Numeric*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34362258271)
            
            //--TRIMMABLE-BOUNDARY-START(12887421791)
            static /*Block[] */ BuildBlocks(/*ArraySegment<byte>*/ bytes, /*bool*/ useKanji)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887421791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bytes.Count === 0)
                {
                    return $.$$.S.Array.Empty($.$wZnq.NCQ.SegmentCompaction.Block);
                }
                /*var*/ let modes = $.$wZnq.NCQ.SegmentCompaction.CalcCompactionMode(bytes, useKanji);
                /*var*/ let modeChanges = $.$wZnq.NCQ.SegmentCompaction.CountModeChanges(modes);
                /*var*/ let blocks = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$wZnq.NCQ.SegmentCompaction.Block), null, [modeChanges], null);
                /*var*/ let blockCount = 0;
                /*var*/ let blockStartIndex = 0;
                /*var*/ let previousMode = $.$$.System.Array.$ReadT1.call(modes, 0);
                for(/*var*/ let i = 0; i < modes.length; i += 1)
                {
                    /*var*/ let currentMode = $.$$.System.Array.$ReadT1.call(modes, i);
                    if (currentMode === previousMode)
                    {
                        continue;
                    }
                    $.$$.System.Array.$WriteT1.call(blocks, (() =>
                    {
                        //new $.$wZnq.NCQ.SegmentCompaction.Block()
                        const $t1 = $.$wZnq.NCQ.SegmentCompaction.Block;
                        const $i1 = new $t1();
                        $i1.Mode = $.$cast(previousMode, $.$wZnq.NCQ.DataSegmentMode);
                        $i1.Length = ((i - blockStartIndex) | 0);
                        return $i1;
                    })(), blockCount);
                    blockCount += 1;
                    previousMode = currentMode;
                    blockStartIndex = i;
                }
                $.$$.System.Array.$WriteT1.call(blocks, (() =>
                {
                    //new $.$wZnq.NCQ.SegmentCompaction.Block()
                    const $t1 = $.$wZnq.NCQ.SegmentCompaction.Block;
                    const $i1 = new $t1();
                    $i1.Mode = $.$cast(previousMode, $.$wZnq.NCQ.DataSegmentMode);
                    $i1.Length = ((modes.length - blockStartIndex) | 0);
                    return $i1;
                })(), blockCount);
                return blocks;
            }
            //--TRIMMABLE-BOUNDARY-END(12887421791)
            
            //--TRIMMABLE-BOUNDARY-START(38657225567)
            static /*int */ CountModeChanges(/*byte[]*/ modes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657225567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let count = 1;
                /*var*/ let previousMode = $.$$.System.Array.$ReadT1.call(modes, 0);
                for(/*var*/ let i = 0; i < modes.length; i += 1)
                {
                    /*var*/ let currentMode = $.$$.System.Array.$ReadT1.call(modes, i);
                    if (currentMode !== previousMode)
                    {
                        count += 1;
                        previousMode = currentMode;
                    }
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(38657225567)
            
            //--TRIMMABLE-BOUNDARY-START(30067290975)
            static /*byte[] */ CalcCompactionMode(/*ArraySegment<byte>*/ bytes, /*bool*/ useKanji)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067290975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let len = bytes.Count;
                /*var*/ let modes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [len], null);
                /*var*/ let index = 0;
                while(index < len)
                {
                    /*var*/ let b1 = $.$wZnq.NCQ.ArraySegmentExtensions.At($.$$.S.Byte, bytes, index);
                    if ($.$wZnq.NCQ.DataSegmentNumeric.IsNumeric(b1))
                    {
                        $.$$.System.Array.$WriteT1.call(modes, $.$cast(1/*DataSegmentMode.Numeric*/, $.$$.S.Byte), index);
                    }
                    else if ($.$wZnq.NCQ.DataSegmentAlphanumeric.IsAlphanumeric(b1))
                    {
                        $.$$.System.Array.$WriteT1.call(modes, $.$cast(2/*DataSegmentMode.Alphanumeric*/, $.$$.S.Byte), index);
                    }
                    else if (useKanji && index < ((len - 1) | 0) && $.$wZnq.NCQ.DataSegmentKanji.IsShiftJisDoubleByte(b1, $.$wZnq.NCQ.ArraySegmentExtensions.At($.$$.S.Byte, bytes, ((index + 1) | 0))))
                    {
                        $.$$.System.Array.$WriteT1.call(modes, $.$cast(3/*DataSegmentMode.Kanji*/, $.$$.S.Byte), index);
                        index += 1;
                        $.$$.System.Array.$WriteT1.call(modes, $.$cast(3/*DataSegmentMode.Kanji*/, $.$$.S.Byte), index);
                    }
                    else 
                    {
                        $.$$.System.Array.$WriteT1.call(modes, $.$cast(4/*DataSegmentMode.Binary*/, $.$$.S.Byte), index);
                    }
                    index += 1;
                }
                return modes;
            }
            //--TRIMMABLE-BOUNDARY-END(30067290975)
            
            //--TRIMMABLE-BOUNDARY-START(42952192863)
            static /*int */ GetSegmentHeaderLength(/*DataSegmentMode*/ mode, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952192863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(mode)
                {
                    case 4/*DataSegmentMode.Binary*/:
                    return ((12 + (version <= 9 ? 0 : 8)) | 0);
                    case 1/*DataSegmentMode.Numeric*/:
                    return ((14 + (($.trunc((((version + 7) | 0)) / 17) * 2) | 0)) | 0);
                    case 2/*DataSegmentMode.Alphanumeric*/:
                    return ((13 + (($.trunc((((version + 7) | 0)) / 17) * 2) | 0)) | 0);
                    case 3/*DataSegmentMode.Kanji*/:
                    return ((12 + $.trunc((((version + 7) | 0)) / 17)) | 0);
                    default:
                    $.$$.SD.Debug.Assert$4(false, "data segment mode not supported by this function");
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952192863)
            
            //--TRIMMABLE-BOUNDARY-START(2585439)
            static $_Block;
            static get Block()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2585439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$wZnq.NCQ.SegmentCompaction;
                return $cls.$_Block ??= $asm.$nstr(`$wZnq.NCQ.SegmentCompaction.Block`, ($self) => class Block extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17182454623)
                    /*DataSegmentMode*/  get Mode() { return this.$getField(0, $.$wZnq.NCQ.DataSegmentMode); }
                    /*DataSegmentMode*/  set Mode(value) { this.$setField(0, $.$wZnq.NCQ.DataSegmentMode, value); }
                    //--TRIMMABLE-BOUNDARY-END(17182454623)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887487327)
                    /*int*/  get Length() { return this.$getField(4, $.$$.S.Int32); }
                    /*int*/  set Length(value) { this.$setField(4, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(12887487327)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592520031)
                    /*int */ GetSegmentLength(/*int*/ version)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592520031);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        switch(this.Mode)
                        {
                            case 4/*DataSegmentMode.Binary*/:
                            return ((((12 + (version <= 9 ? 0 : 8)) | 0) + ((this.Length * 8) | 0)) | 0);
                            case 1/*DataSegmentMode.Numeric*/:
                            return ((((14 + (($.trunc((((version + 7) | 0)) / 17) * 2) | 0)) | 0) + $.trunc((((((this.Length * 10) | 0) + 2) | 0)) / 3)) | 0);
                            case 2/*DataSegmentMode.Alphanumeric*/:
                            return ((((13 + (($.trunc((((version + 7) | 0)) / 17) * 2) | 0)) | 0) + $.trunc((((((this.Length * 11) | 0) + 1) | 0)) / 2)) | 0);
                            case 3/*DataSegmentMode.Kanji*/:
                            return ((((12 + (($.trunc((((version + 7) | 0)) / 17) * 2) | 0)) | 0) + $.trunc(((this.Length * 13) | 0) / 2)) | 0);
                            default:
                            $.$$.SD.Debug.Assert$4(false, "data segment mode not supported by this function");
                            return 0;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592520031)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477421919)
                    /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477421919);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return `${$.$$.S.Enum.ToStringT($.$wZnq.NCQ.DataSegmentMode, $.$$.S.UInt32, this.Mode)}: ${this.Length} bytes`;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477421919)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297552735)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297552735);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297552735)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297552735)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297552735)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Mode = this.Mode;
                        copy.Length = this.Length;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(17182454623)
                        this.Mode = 0;
                        //--TRIMMABLE-BOUNDARY-END(17182454623)
                        
                        //--TRIMMABLE-BOUNDARY-START(12887487327)
                        this.Length = 0;
                        //--TRIMMABLE-BOUNDARY-END(12887487327)
                        
                    }
                    static $h = 2585439;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592520031),
    {
      "r": 655361,
      "p": [
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetSegmentLength",
      "d": 2585439,
      "h": 8592520031,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592520031),
//--TRIMMABLE-BOUNDARY-START(21477421919),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2585439,
      "h": 21477421919,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21477421919)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182454623),
    {
      "t": 750431,
      "n": "Mode",
      "d": 2585439,
      "h": 17182454623,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17182454623),
//--TRIMMABLE-BOUNDARY-START(12887487327),
    {
      "t": 655361,
      "n": "Length",
      "d": 2585439,
      "h": 12887487327,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12887487327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297552735),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2585439,
      "h": 4297552735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297552735)
  ],
  "d": 2519903,
  "h": 2585439
}; }
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.SegmentCompaction+Block`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}SegmentCompaction${separator}Block`; }
                }, $cls, ($v) => $cls.$_Block = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2585439)
            
            //--TRIMMABLE-BOUNDARY-START(4297487199)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297487199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25772323679)
                    this.ByteCosts = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [20, 33, 39, 48], null, null);
                    //--TRIMMABLE-BOUNDARY-END(25772323679)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297487199)
            
            static $h = 2519903;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477356383),
    {
      "r": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "version",
          "p": 655361,
          "f": 65,
          "v": 20
        },
        {
          "n": "considerKanjiMode",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "BuildSegments",
      "o": "@$1",
      "d": 2519903,
      "h": 21477356383,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21477356383),
//--TRIMMABLE-BOUNDARY-START(17182389087),
    {
      "r": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "blocks",
          "p": $.$typeArray($.$wZnq.NCQ.SegmentCompaction.Block).$h
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "BuildSegments",
      "d": 2519903,
      "h": 17182389087,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17182389087),
//--TRIMMABLE-BOUNDARY-START(60132062047),
    {
      "r": 655361,
      "p": [
        {
          "n": "mode",
          "p": 750431
        }
      ],
      "n": "ModeIndex",
      "d": 2519903,
      "h": 60132062047,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60132062047),
//--TRIMMABLE-BOUNDARY-START(55837094751),
    {
      "r": 750431,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "ModeAt",
      "d": 2519903,
      "h": 55837094751,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55837094751),
//--TRIMMABLE-BOUNDARY-START(51542127455),
    {
      "r": 655361,
      "p": [
        {
          "n": "blocks",
          "p": $.$typeArray($.$wZnq.NCQ.SegmentCompaction.Block).$h
        }
      ],
      "n": "MinBitLength",
      "d": 2519903,
      "h": 51542127455,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51542127455),
//--TRIMMABLE-BOUNDARY-START(8592454495),
    {
      "r": 65537,
      "p": [
        {
          "n": "blocks",
          "p": $.$typeArray($.$wZnq.NCQ.SegmentCompaction.Block).$h
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "AssignModes",
      "d": 2519903,
      "h": 8592454495,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8592454495),
//--TRIMMABLE-BOUNDARY-START(68721996639),
    {
      "r": 655361,
      "p": [
        {
          "n": "cost",
          "p": 655361
        }
      ],
      "n": "RoundUpToBits",
      "d": 2519903,
      "h": 68721996639,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68721996639),
//--TRIMMABLE-BOUNDARY-START(34362258271),
    {
      "r": 262145,
      "p": [
        {
          "n": "segmentMode",
          "p": 750431
        },
        {
          "n": "blockMode",
          "p": 750431
        }
      ],
      "n": "CanEncode",
      "d": 2519903,
      "h": 34362258271,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34362258271),
//--TRIMMABLE-BOUNDARY-START(12887421791),
    {
      "r": $.$typeArray($.$wZnq.NCQ.SegmentCompaction.Block).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "useKanji",
          "p": 262145
        }
      ],
      "n": "BuildBlocks",
      "d": 2519903,
      "h": 12887421791,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12887421791),
//--TRIMMABLE-BOUNDARY-START(38657225567),
    {
      "r": 655361,
      "p": [
        {
          "n": "modes",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "CountModeChanges",
      "d": 2519903,
      "h": 38657225567,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38657225567),
//--TRIMMABLE-BOUNDARY-START(30067290975),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "useKanji",
          "p": 262145
        }
      ],
      "n": "CalcCompactionMode",
      "d": 2519903,
      "h": 30067290975,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30067290975),
//--TRIMMABLE-BOUNDARY-START(42952192863),
    {
      "r": 655361,
      "p": [
        {
          "n": "mode",
          "p": 750431
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetSegmentHeaderLength",
      "d": 2519903,
      "h": 42952192863,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42952192863)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64427029343),
    {
      "t": 655361,
      "n": "NumModes",
      "d": 2519903,
      "h": 64427029343,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64427029343),
//--TRIMMABLE-BOUNDARY-START(25772323679),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "ByteCosts",
      "d": 2519903,
      "h": 25772323679,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25772323679),
//--TRIMMABLE-BOUNDARY-START(47247160159),
    {
      "t": 655361,
      "n": "Infinity",
      "d": 2519903,
      "h": 47247160159,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47247160159)
  ],
  "j": [2585439
  ],
  "h": 2519903
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.SegmentCompaction`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}SegmentCompaction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2519903)
        
        

        //--TRIMMABLE-BOUNDARY-START(1864543)
        $asm.$cls(`$wZnq.NCQ.QrCode`, ($self) => class QrCode extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38656570207)
            static /*QrCode */ EncodeText(/*string*/ text, /*Ecc*/ ecl)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656570207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.QrCode.EncodeTextAdvanced(text, ecl, true, 1, 40, null, null, 0, null);
            }
            //--TRIMMABLE-BOUNDARY-END(38656570207)
            
            //--TRIMMABLE-BOUNDARY-START(42951537503)
            static /*QrCode */ EncodeTextAdvanced(/*string*/ text, /*Ecc*/ minimumEcl, /*bool*/ boostEcl, /*int*/ minVersion, /*int*/ maxVersion, /*ECI*/ eci, /*Encoding*/ encoding, /*KanjiStrategy*/ kanjiStrategy, /*EncodingInfo*/ encodingInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951537503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$$.S.String, text, "text");
                $.$wZnq.NCQ.QrCode.ValidateVersion(minVersion, maxVersion);
                /*var*/ let source = $.$wZnq.NCQ.DataSegment.PrepareText(text, eci, encoding, kanjiStrategy);
                return $.$wZnq.NCQ.QrCode.BuildInVersionGroups(source, minimumEcl, minVersion, maxVersion, boostEcl, encodingInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(42951537503)
            
            //--TRIMMABLE-BOUNDARY-START(154620687199)
            /*(int Min, int Max)[]*/ static VersionGroups = null;
            //--TRIMMABLE-BOUNDARY-END(154620687199)
            
            //--TRIMMABLE-BOUNDARY-START(25771668319)
            static /*QrCode */ BuildInVersionGroups(/*SegmentSource*/ source, /*int*/ ecc, /*int*/ minVersion, /*int*/ maxVersion, /*bool*/ boostEcl, /*EncodingInfo*/ encodingInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771668319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let minBitLength = source.MinBitLength;
                var $en2 = $.$wZnq.NCQ.QrCode.VersionGroups.GetEnumerator$1();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let [ groupMin, groupMax ] = $.$destructure($en2.SCG$IEnumerator$$$Current);
                    {
                        /*var*/ let lowest = $.$$.S.Math.Max$4(minVersion, groupMin);
                        /*var*/ let highest = $.$$.S.Math.Min$4(maxVersion, groupMax);
                        if (lowest > highest)
                        {
                            continue;
                        }
                        /*var*/ let isLastGroup = highest === maxVersion;
                        if (!isLastGroup && !$.$wZnq.NCQ.VersionPlanner.Fits$1(minBitLength, highest, ecc))
                        {
                            continue;
                        }
                        /*var*/ let segments = source.ToSegments(highest);
                        if (isLastGroup || $.$wZnq.NCQ.VersionPlanner.Fits(segments, ecc, highest))
                        {
                            return $.$wZnq.NCQ.QrCodeBuilder.Build(segments, ecc, lowest, highest, boostEcl, encodingInfo);
                        }
                    }
                }
                throw new $.$$.S.InvalidOperationException().$ctor$12("Version range does not overlap any version group");
            }
            //--TRIMMABLE-BOUNDARY-END(25771668319)
            
            //--TRIMMABLE-BOUNDARY-START(51541472095)
            static /*List<QrCode> */ EncodeTextInMultipleCodes(/*string*/ text, /*Ecc*/ ecl, /*int*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541472095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$$.S.String, text, "text");
                if (version < 1 || version > 40)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("version", "'version' must be between 1 and 40.");
                }
                /*var*/ let qrCodes = $.$wZnq.NCQ.StructuredAppend.BuildFromText(text, version, ecl);
                if (qrCodes.Count <= 2)
                {
                    try
                    {
                        /*var*/ let segments = $.$wZnq.NCQ.DataSegment.FromText(text, null, null, version, 0);
                        return (() =>
                        {
                            //new $.$$.SCG.List$$($.$wZnq.NCQ.QrCode)()
                            const $t1 = $.$$.SCG.List$$($.$wZnq.NCQ.QrCode);
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.Add($.$wZnq.NCQ.QrCodeBuilder.Build(segments, ecl, version, version, true, null));
                            return $i1;
                        })();
                    }
                    catch($e)
                    {
                    }
                }
                return qrCodes.ConvertAll($.$wZnq.NCQ.QrCode, new ($.$$.S.Converter$$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment), $.$wZnq.NCQ.QrCode))().$ctor(this,  (/*segments*/ segments) =>
                {
                    return $.$wZnq.NCQ.QrCodeBuilder.Build(segments, ecl, version, version, true, null);
                }, _12da453a_5db2_4716_a58a_1ed64227ffea ??= {"r":1864543,"p":[{"n":"segments","p":$.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h}],"n":"","d":1864543,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(51541472095)
            
            //--TRIMMABLE-BOUNDARY-START(47246504799)
            static /*List<QrCode> */ EncodeTextInMultipleBalancedCodes(/*string*/ text, /*Ecc*/ ecl, /*int*/ minVersion, /*int*/ maxVersion)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246504799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$$.S.String, text, "text");
                $.$wZnq.NCQ.QrCode.ValidateVersion(minVersion, maxVersion);
                /*var*/ let  [ qrCodes, version ] = $.$destructure($.$wZnq.NCQ.StructuredAppend.BuildBalancedFromText(text, minVersion, maxVersion, ecl));
                if (qrCodes.Count === 1)
                {
                    /*var*/ let segments = $.$wZnq.NCQ.DataSegment.FromText(text, null, null, maxVersion, 0);
                    return (() =>
                    {
                        //new $.$$.SCG.List$$($.$wZnq.NCQ.QrCode)()
                        const $t1 = $.$$.SCG.List$$($.$wZnq.NCQ.QrCode);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add($.$wZnq.NCQ.QrCodeBuilder.Build(segments, ecl, minVersion, maxVersion, true, null));
                        return $i1;
                    })();
                }
                return qrCodes.ConvertAll($.$wZnq.NCQ.QrCode, new ($.$$.S.Converter$$$($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment), $.$wZnq.NCQ.QrCode))().$ctor(this,  (/*segments*/ segments) =>
                {
                    return $.$wZnq.NCQ.QrCodeBuilder.Build(segments, ecl, version, version, true, null);
                }, _7951e441_828f_4841_a3e8_bbb5ac31c045 ??= {"r":1864543,"p":[{"n":"segments","p":$.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h}],"n":"","d":1864543,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(47246504799)
            
            //--TRIMMABLE-BOUNDARY-START(30066635615)
            static /*QrCode */ EncodeBinary(/*byte[]*/ data, /*Ecc*/ ecl, /*bool*/ omitEci)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066635615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$typeArray($.$$.S.Byte), data, "data");
                /*var*/ let source = $.$wZnq.NCQ.DataSegment.PrepareBinaryData(data, omitEci ? $.$wZnq.NCQ.ECI.None : $.$wZnq.NCQ.ECI.BinaryData, false);
                return $.$wZnq.NCQ.QrCode.BuildInVersionGroups(source, ecl, 1/*MinVersion*/, 40/*MaxVersion*/, true, null);
            }
            //--TRIMMABLE-BOUNDARY-END(30066635615)
            
            //--TRIMMABLE-BOUNDARY-START(34361602911)
            static /*QrCode */ EncodeSegments(/*List<DataSegment>*/ segments, /*Ecc*/ ecl, /*int*/ minVersion, /*int*/ maxVersion, /*bool*/ boostEcl)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361602911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.Objects.RequireNonNull($.$$.SCG.List$$($.$wZnq.NCQ.DataSegment), segments, "segments");
                $.$wZnq.NCQ.QrCode.ValidateVersion(minVersion, maxVersion);
                return $.$wZnq.NCQ.QrCodeBuilder.Build(segments, ecl, minVersion, maxVersion, boostEcl, null);
            }
            //--TRIMMABLE-BOUNDARY-END(34361602911)
            
            //--TRIMMABLE-BOUNDARY-START(146030752607)
            static /*void */ ValidateVersion(/*int*/ minVersion, /*int*/ maxVersion)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030752607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (minVersion < 1 || minVersion > 40)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("minVersion", "'minVersion' must be between 1 and 40.");
                }
                if (maxVersion < 1 || maxVersion > 40)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("maxVersion", "'maxVersion' must be between 1 and 40.");
                }
                if (minVersion > maxVersion)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("minVersion", "'minVersion' must be equal or less than 'maxVersion'.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030752607)
            
            //--TRIMMABLE-BOUNDARY-START(150325719903)
            /*int */ get Version()
            {
                return $.trunc((((this._modules.Size - 17) | 0)) / 4);
            }
            //--TRIMMABLE-BOUNDARY-END(150325719903)
            
            //--TRIMMABLE-BOUNDARY-START(115965981535)
            /*int */ get Size()
            {
                return this._modules.Size;
            }
            //--TRIMMABLE-BOUNDARY-END(115965981535)
            
            //--TRIMMABLE-BOUNDARY-START(55836439391)
            /*Ecc*/ ErrorCorrectionLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(55836439391)
            
            //--TRIMMABLE-BOUNDARY-START(98786112351)
            /*int*/ Mask = 0;
            //--TRIMMABLE-BOUNDARY-END(98786112351)
            
            //--TRIMMABLE-BOUNDARY-START(4296831839)
            /*BitMatrix*/ _modules;
            //--TRIMMABLE-BOUNDARY-END(4296831839)
            
            //--TRIMMABLE-BOUNDARY-START(21476701023)
            $ctor$1(/*BitMatrix*/ modules, /*Ecc*/ ecl, /*int*/ mask)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476701023);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._modules = modules;
                    this.ErrorCorrectionLevel = ecl;
                    this.Mask = mask;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476701023)
            
            //--TRIMMABLE-BOUNDARY-START(94491145055)
            /*bool */ GetModule(/*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491145055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 0 <= x && x < this.Size && 0 <= y && y < this.Size && this._modules.Get(x, y);
            }
            //--TRIMMABLE-BOUNDARY-END(94491145055)
            
            //--TRIMMABLE-BOUNDARY-START(141735785311)
            /*string */ ToSvgString(/*int*/ border, /*string*/ foreground, /*string*/ background)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735785311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.SvgBuilder.ToSvgString(this, border, foreground, background);
            }
            //--TRIMMABLE-BOUNDARY-END(141735785311)
            
            //--TRIMMABLE-BOUNDARY-START(124555916127)
            /*string */ ToGraphicsPath(/*int*/ border)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555916127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.SvgBuilder.ToGraphicsPath(this, border);
            }
            //--TRIMMABLE-BOUNDARY-END(124555916127)
            
            //--TRIMMABLE-BOUNDARY-START(137440818015)
            /*IReadOnlyList<QrRectangle> */ ToRectangles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440818015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.RectangleBuilder.Build(this._modules);
            }
            //--TRIMMABLE-BOUNDARY-END(137440818015)
            
            //--TRIMMABLE-BOUNDARY-START(128850883423)
            /*IReadOnlyList<QrPolygon> */ ToOutlines()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850883423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.OutlineBuilder.Build(this._modules);
            }
            //--TRIMMABLE-BOUNDARY-END(128850883423)
            
            //--TRIMMABLE-BOUNDARY-START(120260948831)
            /*byte[] */ ToBmpBitmap(/*int*/ border, /*int*/ scale, /*int*/ foreground, /*int*/ background)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260948831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.BmpBuilder.ToImage(this, border, scale, foreground, background);
            }
            //--TRIMMABLE-BOUNDARY-END(120260948831)
            
            //--TRIMMABLE-BOUNDARY-START(133145850719)
            /*byte[] */ ToPngBitmap(/*int*/ border, /*int*/ scale, /*int*/ foreground, /*int*/ background)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145850719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wZnq.NCQ.PngBuilder.ToImage(this, scale, border, foreground, background);
            }
            //--TRIMMABLE-BOUNDARY-END(133145850719)
            
            //--TRIMMABLE-BOUNDARY-START(111671014239)
            static /*int */ RgbColor(/*byte*/ red, /*byte*/ green, /*byte*/ blue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671014239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((red << 16) >>> 0) | ((green << 8) >>> 0) | blue;
            }
            //--TRIMMABLE-BOUNDARY-END(111671014239)
            
            //--TRIMMABLE-BOUNDARY-START(107376046943)
            /*int*/ static MinVersion = 1;
            //--TRIMMABLE-BOUNDARY-END(107376046943)
            
            //--TRIMMABLE-BOUNDARY-START(103081079647)
            /*int*/ static MaxVersion = 40;
            //--TRIMMABLE-BOUNDARY-END(103081079647)
            
            //--TRIMMABLE-BOUNDARY-START(1930079)
            static $_Ecc;
            static get Ecc()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1930079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$wZnq.NCQ.QrCode;
                return $cls.$_Ecc ??= $asm.$nstr(`$wZnq.NCQ.QrCode.Ecc`, ($self) => class Ecc extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static Low = 0;
                    static Medium = 1;
                    static Quartile = 2;
                    static High = 3;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1930079);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Low": 0n,
                            "Medium": 1n,
                            "Quartile": 2n,
                            "High": 3n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4296897375)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296897375);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296897375)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296897375)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296897375)
                    
                    static $h = 1930079;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886831967),
    {
      "t": 1930079,
      "n": "Low",
      "d": 1930079,
      "h": 12886831967,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886831967),
//--TRIMMABLE-BOUNDARY-START(17181799263),
    {
      "t": 1930079,
      "n": "Medium",
      "d": 1930079,
      "h": 17181799263,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181799263),
//--TRIMMABLE-BOUNDARY-START(21476766559),
    {
      "t": 1930079,
      "n": "Quartile",
      "d": 1930079,
      "h": 21476766559,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476766559),
//--TRIMMABLE-BOUNDARY-START(8591864671),
    {
      "t": 1930079,
      "n": "High",
      "d": 1930079,
      "h": 8591864671,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591864671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296897375),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1930079,
      "h": 4296897375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296897375)
  ],
  "i": [90308609,96862209,90767361,90439681
  ],
  "d": 1864543,
  "h": 1930079
}; }
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.QrCode+Ecc`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}QrCode${separator}Ecc`; }
                }, $cls, ($v) => $cls.$_Ecc = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1930079)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296831839)
                this._modules = $.$default($.$wZnq.NCQ.BitMatrix);
                //--TRIMMABLE-BOUNDARY-END(4296831839)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17181733727)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181733727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(154620687199)
                    this.VersionGroups = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32)), [new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(1, 9), new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(10, 26), new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(27, 40)], null, null);
                    //--TRIMMABLE-BOUNDARY-END(154620687199)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181733727)
            
            static $h = 1864543;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(150325719903),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196177759,
        "f": 50331649
      },
      "n": "Version",
      "d": 1864543,
      "h": 150325719903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150325719903),
//--TRIMMABLE-BOUNDARY-START(115965981535),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606243167,
        "f": 50331649
      },
      "n": "Size",
      "d": 1864543,
      "h": 115965981535,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965981535),
//--TRIMMABLE-BOUNDARY-START(55836439391),
    {
      "p": 1930079,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426373983,
        "f": 50331649
      },
      "n": "ErrorCorrectionLevel",
      "d": 1864543,
      "h": 55836439391,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836439391),
//--TRIMMABLE-BOUNDARY-START(98786112351),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016308575,
        "f": 50331649
      },
      "n": "Mask",
      "d": 1864543,
      "h": 98786112351,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786112351)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656570207),
    {
      "r": 1864543,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "ecl",
          "p": 1930079
        }
      ],
      "n": "EncodeText",
      "d": 1864543,
      "h": 38656570207,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656570207),
//--TRIMMABLE-BOUNDARY-START(42951537503),
    {
      "r": 1864543,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "minimumEcl",
          "p": 1930079
        },
        {
          "n": "boostEcl",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "minVersion",
          "p": 655361,
          "f": 65,
          "v": 1
        },
        {
          "n": "maxVersion",
          "p": 655361,
          "f": 65,
          "v": 40
        },
        {
          "n": "eci",
          "p": 1078111,
          "f": 65
        },
        {
          "n": "encoding",
          "p": 166199297,
          "f": 65
        },
        {
          "n": "kanjiStrategy",
          "p": 1340255,
          "f": 65,
          "v": 0
        },
        {
          "n": "encodingInfo",
          "p": 1209183,
          "f": 65
        }
      ],
      "n": "EncodeTextAdvanced",
      "d": 1864543,
      "h": 42951537503,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951537503),
//--TRIMMABLE-BOUNDARY-START(25771668319),
    {
      "r": 1864543,
      "p": [
        {
          "n": "source",
          "p": 2650975
        },
        {
          "n": "ecc",
          "p": 655361
        },
        {
          "n": "minVersion",
          "p": 655361
        },
        {
          "n": "maxVersion",
          "p": 655361
        },
        {
          "n": "boostEcl",
          "p": 262145
        },
        {
          "n": "encodingInfo",
          "p": 1209183
        }
      ],
      "n": "BuildInVersionGroups",
      "d": 1864543,
      "h": 25771668319,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771668319),
//--TRIMMABLE-BOUNDARY-START(51541472095),
    {
      "r": $.$$.SCG.List$$($.$wZnq.NCQ.QrCode).$h,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "version",
          "p": 655361,
          "f": 65,
          "v": 29
        }
      ],
      "n": "EncodeTextInMultipleCodes",
      "d": 1864543,
      "h": 51541472095,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541472095),
//--TRIMMABLE-BOUNDARY-START(47246504799),
    {
      "r": $.$$.SCG.List$$($.$wZnq.NCQ.QrCode).$h,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "minVersion",
          "p": 655361,
          "f": 65,
          "v": 10
        },
        {
          "n": "maxVersion",
          "p": 655361,
          "f": 65,
          "v": 29
        }
      ],
      "n": "EncodeTextInMultipleBalancedCodes",
      "d": 1864543,
      "h": 47246504799,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246504799),
//--TRIMMABLE-BOUNDARY-START(30066635615),
    {
      "r": 1864543,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "omitEci",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "EncodeBinary",
      "d": 1864543,
      "h": 30066635615,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066635615),
//--TRIMMABLE-BOUNDARY-START(34361602911),
    {
      "r": 1864543,
      "p": [
        {
          "n": "segments",
          "p": $.$$.SCG.List$$($.$wZnq.NCQ.DataSegment).$h
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "minVersion",
          "p": 655361,
          "f": 65,
          "v": 1
        },
        {
          "n": "maxVersion",
          "p": 655361,
          "f": 65,
          "v": 40
        },
        {
          "n": "boostEcl",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "EncodeSegments",
      "d": 1864543,
      "h": 34361602911,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361602911),
//--TRIMMABLE-BOUNDARY-START(146030752607),
    {
      "r": 65537,
      "p": [
        {
          "n": "minVersion",
          "p": 655361
        },
        {
          "n": "maxVersion",
          "p": 655361
        }
      ],
      "n": "ValidateVersion",
      "d": 1864543,
      "h": 146030752607,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146030752607),
//--TRIMMABLE-BOUNDARY-START(94491145055),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "GetModule",
      "d": 1864543,
      "h": 94491145055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94491145055),
//--TRIMMABLE-BOUNDARY-START(141735785311),
    {
      "r": 1310721,
      "p": [
        {
          "n": "border",
          "p": 655361
        },
        {
          "n": "foreground",
          "p": 1310721,
          "f": 65,
          "v": "#000000"
        },
        {
          "n": "background",
          "p": 1310721,
          "f": 65,
          "v": "#ffffff"
        }
      ],
      "n": "ToSvgString",
      "d": 1864543,
      "h": 141735785311,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735785311),
//--TRIMMABLE-BOUNDARY-START(124555916127),
    {
      "r": 1310721,
      "p": [
        {
          "n": "border",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToGraphicsPath",
      "d": 1864543,
      "h": 124555916127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555916127),
//--TRIMMABLE-BOUNDARY-START(137440818015),
    {
      "r": $.$$.SCG.IReadOnlyList$$($.$wZnq.NCQ.QrRectangle).$h,
      "n": "ToRectangles",
      "d": 1864543,
      "h": 137440818015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440818015),
//--TRIMMABLE-BOUNDARY-START(128850883423),
    {
      "r": $.$$.SCG.IReadOnlyList$$($.$wZnq.NCQ.QrPolygon).$h,
      "n": "ToOutlines",
      "d": 1864543,
      "h": 128850883423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850883423),
//--TRIMMABLE-BOUNDARY-START(120260948831),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "border",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "scale",
          "p": 655361,
          "f": 65,
          "v": 1
        },
        {
          "n": "foreground",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "background",
          "p": 655361,
          "f": 65,
          "v": 16777215
        }
      ],
      "n": "ToBmpBitmap",
      "d": 1864543,
      "h": 120260948831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120260948831),
//--TRIMMABLE-BOUNDARY-START(133145850719),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "border",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "scale",
          "p": 655361,
          "f": 65,
          "v": 1
        },
        {
          "n": "foreground",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "background",
          "p": 655361,
          "f": 65,
          "v": 16777215
        }
      ],
      "n": "ToPngBitmap",
      "d": 1864543,
      "h": 133145850719,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133145850719),
//--TRIMMABLE-BOUNDARY-START(111671014239),
    {
      "r": 655361,
      "p": [
        {
          "n": "red",
          "p": 393217
        },
        {
          "n": "green",
          "p": 393217
        },
        {
          "n": "blue",
          "p": 393217
        }
      ],
      "n": "RgbColor",
      "d": 1864543,
      "h": 111671014239,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111671014239)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(154620687199),
    {
      "t": $.$typeArray($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32)).$h,
      "n": "VersionGroups",
      "d": 1864543,
      "h": 154620687199,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(154620687199),
//--TRIMMABLE-BOUNDARY-START(4296831839),
    {
      "t": 160607,
      "n": "_modules",
      "d": 1864543,
      "h": 4296831839,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296831839),
//--TRIMMABLE-BOUNDARY-START(107376046943),
    {
      "t": 655361,
      "n": "MinVersion",
      "d": 1864543,
      "h": 107376046943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107376046943),
//--TRIMMABLE-BOUNDARY-START(103081079647),
    {
      "t": 655361,
      "n": "MaxVersion",
      "d": 1864543,
      "h": 103081079647,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103081079647)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476701023),
    {
      "p": [
        {
          "n": "modules",
          "p": 160607
        },
        {
          "n": "ecl",
          "p": 1930079
        },
        {
          "n": "mask",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1864543,
      "h": 21476701023,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476701023)
  ],
  "j": [1930079
  ],
  "h": 1864543
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.QrCode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}QrCode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1864543)
        
        

        //--TRIMMABLE-BOUNDARY-START(2192223)
        $asm.$cls(`$wZnq.NCQ.QrPolygon`, ($self) => class QrPolygon extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297159519)
            /*QrPoint[]*/ _vertices = null;
            //--TRIMMABLE-BOUNDARY-END(4297159519)
            
            //--TRIMMABLE-BOUNDARY-START(8592126815)
            $ctor$1(/*IReadOnlyList<QrPoint>*/ vertices)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592126815);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$wZnq.NCQ.Objects.RequireNonNull($.$$.SCG.IReadOnlyList$$($.$wZnq.NCQ.QrPoint), vertices, "vertices");
                    this._vertices = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$wZnq.NCQ.QrPoint), null, [vertices.SCG$IReadOnlyCollection$$$Count], null);
                    for(/*var*/ let i = 0; i < vertices.SCG$IReadOnlyCollection$$$Count; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(this._vertices, vertices.SCG$IReadOnlyList$$$get_Item(i), i);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592126815)
            
            //--TRIMMABLE-BOUNDARY-START(47246832479)
            /*IReadOnlyList<QrPoint> */ get Vertices()
            {
                return this._vertices;
            }
            //--TRIMMABLE-BOUNDARY-END(47246832479)
            
            //--TRIMMABLE-BOUNDARY-START(17182061407)
            /*bool */ Equals$2(/*QrPolygon*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182061407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$wZnq.NCQ.QrPolygon.op_Equality(other, null))
                {
                    return false;
                }
                if ($.$$.S.Object.ReferenceEquals(this, other))
                {
                    return true;
                }
                if (this._vertices.length !== other._vertices.length)
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < this._vertices.length; i++)
                {
                    if ($.$wZnq.NCQ.QrPoint.op_Inequality($.$$.System.Array.$ReadT1.call(this._vertices, i), $.$$.System.Array.$ReadT1.call(other._vertices, i)))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182061407)
            
            //--TRIMMABLE-BOUNDARY-START(12887094111)
            /*bool */ Equals$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887094111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2($.$as(obj, $.$wZnq.NCQ.QrPolygon));
            }
            //--TRIMMABLE-BOUNDARY-END(12887094111)
            
            //--TRIMMABLE-BOUNDARY-START(30066963295)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066963295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    /*var*/ let hash = 17;
                    let $i1 = 0;
                    let $arr1 = this._vertices;
                    while ($i1 < $arr1.length)
                    {
                        let vertex = $arr1[$i1++];
                        hash = ((((hash * 31) | 0) + vertex.GetHashCode()) | 0);
                    }
                    return hash;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066963295)
            
            //--TRIMMABLE-BOUNDARY-START(42951865183)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951865183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$8("QrPolygon(");
                for(/*var*/ let i = 0; i < this._vertices.length; i++)
                {
                    if (i !== 0)
                    {
                        sb.Append$21(", ");
                    }
                    sb.Append$5(/*(*/ 40).Append$13($.$$.System.Array.$ReadT1.call(this._vertices, i).X).Append$5(/*,*/ 44).Append$13($.$$.System.Array.$ReadT1.call(this._vertices, i).Y).Append$5(/*)*/ 41);
                }
                return sb.Append$5(/*)*/ 41).ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(42951865183)
            
            //--TRIMMABLE-BOUNDARY-START(34361930591)
            static /*bool */ op_Equality(/*QrPolygon*/ left, /*QrPolygon*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361930591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Object.ReferenceEquals(left, null) ? $.$$.S.Object.ReferenceEquals(right, null) : left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(34361930591)
            
            //--TRIMMABLE-BOUNDARY-START(38656897887)
            static /*bool */ op_Inequality(/*QrPolygon*/ left, /*QrPolygon*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656897887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !($.$wZnq.NCQ.QrPolygon.op_Equality(left, right));
            }
            //--TRIMMABLE-BOUNDARY-END(38656897887)
            
            //--TRIMMABLE-BOUNDARY-START(4385603585)
            //Generated interface implemetation for System.IEquatable<Net.Codecrete.QrCodeGenerator.QrPolygon>.Equals(Net.Codecrete.QrCodeGenerator.QrPolygon?)
            S$IEquatable$Net$Codecrete$QrCodeGenerator$QrPolygon$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385603585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385603585)
            
            static $h = 2192223;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246832479),
    {
      "p": $.$$.SCG.IReadOnlyList$$($.$wZnq.NCQ.QrPoint).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771995999,
        "f": 50331649
      },
      "n": "Vertices",
      "d": 2192223,
      "h": 47246832479,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246832479)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182061407),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 2192223
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2192223,
      "h": 17182061407,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182061407),
//--TRIMMABLE-BOUNDARY-START(12887094111),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2192223,
      "h": 12887094111,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887094111),
//--TRIMMABLE-BOUNDARY-START(30066963295),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2192223,
      "h": 30066963295,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066963295),
//--TRIMMABLE-BOUNDARY-START(42951865183),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2192223,
      "h": 42951865183,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951865183)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297159519),
    {
      "t": $.$typeArray($.$wZnq.NCQ.QrPoint).$h,
      "n": "_vertices",
      "d": 2192223,
      "h": 4297159519,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297159519)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592126815),
    {
      "p": [
        {
          "n": "vertices",
          "p": $.$$.SCG.IReadOnlyList$$($.$wZnq.NCQ.QrPoint).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2192223,
      "h": 8592126815,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592126815)
  ],
  "i": [$.$$.S.IEquatable$$($.$wZnq.NCQ.QrPolygon).$h
  ],
  "h": 2192223
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$wZnq.NCQ.QrPolygon) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.QrPolygon`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}QrPolygon`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2192223)
        
        

        //--TRIMMABLE-BOUNDARY-START(1078111)
        $asm.$cls(`$wZnq.NCQ.ECI`, ($self) => class ECI extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(240519246687)
            /*int*/ static NoneValue = -2;
            //--TRIMMABLE-BOUNDARY-END(240519246687)
            
            //--TRIMMABLE-BOUNDARY-START(21475914591)
            /*int*/ static AutomaticValue = -1;
            //--TRIMMABLE-BOUNDARY-END(21475914591)
            
            //--TRIMMABLE-BOUNDARY-START(236224279391)
            /*ECI*/ static None = null;
            //--TRIMMABLE-BOUNDARY-END(236224279391)
            
            //--TRIMMABLE-BOUNDARY-START(17180947295)
            /*ECI*/ static Automatic = null;
            //--TRIMMABLE-BOUNDARY-END(17180947295)
            
            //--TRIMMABLE-BOUNDARY-START(34360816479)
            /*ECI*/ static CodePage437 = null;
            //--TRIMMABLE-BOUNDARY-END(34360816479)
            
            //--TRIMMABLE-BOUNDARY-START(171799769951)
            /*ECI*/ static Latin1 = null;
            //--TRIMMABLE-BOUNDARY-END(171799769951)
            
            //--TRIMMABLE-BOUNDARY-START(103080293215)
            /*ECI*/ static Iso8859_1 = null;
            //--TRIMMABLE-BOUNDARY-END(103080293215)
            
            //--TRIMMABLE-BOUNDARY-START(180389704543)
            /*ECI*/ static Latin2 = null;
            //--TRIMMABLE-BOUNDARY-END(180389704543)
            
            //--TRIMMABLE-BOUNDARY-START(133145064287)
            /*ECI*/ static Iso8859_2 = null;
            //--TRIMMABLE-BOUNDARY-END(133145064287)
            
            //--TRIMMABLE-BOUNDARY-START(184684671839)
            /*ECI*/ static Latin3 = null;
            //--TRIMMABLE-BOUNDARY-END(184684671839)
            
            //--TRIMMABLE-BOUNDARY-START(137440031583)
            /*ECI*/ static Iso8859_3 = null;
            //--TRIMMABLE-BOUNDARY-END(137440031583)
            
            //--TRIMMABLE-BOUNDARY-START(188979639135)
            /*ECI*/ static Latin4 = null;
            //--TRIMMABLE-BOUNDARY-END(188979639135)
            
            //--TRIMMABLE-BOUNDARY-START(141734998879)
            /*ECI*/ static Iso8859_4 = null;
            //--TRIMMABLE-BOUNDARY-END(141734998879)
            
            //--TRIMMABLE-BOUNDARY-START(219044410207)
            /*ECI*/ static LatinCyrillic = null;
            //--TRIMMABLE-BOUNDARY-END(219044410207)
            
            //--TRIMMABLE-BOUNDARY-START(146029966175)
            /*ECI*/ static Iso8859_5 = null;
            //--TRIMMABLE-BOUNDARY-END(146029966175)
            
            //--TRIMMABLE-BOUNDARY-START(214749442911)
            /*ECI*/ static LatinArabic = null;
            //--TRIMMABLE-BOUNDARY-END(214749442911)
            
            //--TRIMMABLE-BOUNDARY-START(150324933471)
            /*ECI*/ static Iso8859_6 = null;
            //--TRIMMABLE-BOUNDARY-END(150324933471)
            
            //--TRIMMABLE-BOUNDARY-START(223339377503)
            /*ECI*/ static LatinGreek = null;
            //--TRIMMABLE-BOUNDARY-END(223339377503)
            
            //--TRIMMABLE-BOUNDARY-START(154619900767)
            /*ECI*/ static Iso8859_7 = null;
            //--TRIMMABLE-BOUNDARY-END(154619900767)
            
            //--TRIMMABLE-BOUNDARY-START(227634344799)
            /*ECI*/ static LatinHebrew = null;
            //--TRIMMABLE-BOUNDARY-END(227634344799)
            
            //--TRIMMABLE-BOUNDARY-START(158914868063)
            /*ECI*/ static Iso8859_8 = null;
            //--TRIMMABLE-BOUNDARY-END(158914868063)
            
            //--TRIMMABLE-BOUNDARY-START(193274606431)
            /*ECI*/ static Latin5 = null;
            //--TRIMMABLE-BOUNDARY-END(193274606431)
            
            //--TRIMMABLE-BOUNDARY-START(163209835359)
            /*ECI*/ static Iso8859_9 = null;
            //--TRIMMABLE-BOUNDARY-END(163209835359)
            
            //--TRIMMABLE-BOUNDARY-START(197569573727)
            /*ECI*/ static Latin6 = null;
            //--TRIMMABLE-BOUNDARY-END(197569573727)
            
            //--TRIMMABLE-BOUNDARY-START(107375260511)
            /*ECI*/ static Iso8859_10 = null;
            //--TRIMMABLE-BOUNDARY-END(107375260511)
            
            //--TRIMMABLE-BOUNDARY-START(231929312095)
            /*ECI*/ static LatinThai = null;
            //--TRIMMABLE-BOUNDARY-END(231929312095)
            
            //--TRIMMABLE-BOUNDARY-START(111670227807)
            /*ECI*/ static Iso8859_11 = null;
            //--TRIMMABLE-BOUNDARY-END(111670227807)
            
            //--TRIMMABLE-BOUNDARY-START(201864541023)
            /*ECI*/ static Latin7 = null;
            //--TRIMMABLE-BOUNDARY-END(201864541023)
            
            //--TRIMMABLE-BOUNDARY-START(115965195103)
            /*ECI*/ static Iso8859_13 = null;
            //--TRIMMABLE-BOUNDARY-END(115965195103)
            
            //--TRIMMABLE-BOUNDARY-START(206159508319)
            /*ECI*/ static Latin8 = null;
            //--TRIMMABLE-BOUNDARY-END(206159508319)
            
            //--TRIMMABLE-BOUNDARY-START(120260162399)
            /*ECI*/ static Iso8859_14 = null;
            //--TRIMMABLE-BOUNDARY-END(120260162399)
            
            //--TRIMMABLE-BOUNDARY-START(210454475615)
            /*ECI*/ static Latin9 = null;
            //--TRIMMABLE-BOUNDARY-END(210454475615)
            
            //--TRIMMABLE-BOUNDARY-START(124555129695)
            /*ECI*/ static Iso8859_15 = null;
            //--TRIMMABLE-BOUNDARY-END(124555129695)
            
            //--TRIMMABLE-BOUNDARY-START(176094737247)
            /*ECI*/ static Latin10 = null;
            //--TRIMMABLE-BOUNDARY-END(176094737247)
            
            //--TRIMMABLE-BOUNDARY-START(128850096991)
            /*ECI*/ static Iso8859_16 = null;
            //--TRIMMABLE-BOUNDARY-END(128850096991)
            
            //--TRIMMABLE-BOUNDARY-START(244814213983)
            /*ECI*/ static ShiftJIS = null;
            //--TRIMMABLE-BOUNDARY-END(244814213983)
            
            //--TRIMMABLE-BOUNDARY-START(279173952351)
            /*ECI*/ static Windows1250 = null;
            //--TRIMMABLE-BOUNDARY-END(279173952351)
            
            //--TRIMMABLE-BOUNDARY-START(283468919647)
            /*ECI*/ static Windows1251 = null;
            //--TRIMMABLE-BOUNDARY-END(283468919647)
            
            //--TRIMMABLE-BOUNDARY-START(287763886943)
            /*ECI*/ static Windows1252 = null;
            //--TRIMMABLE-BOUNDARY-END(287763886943)
            
            //--TRIMMABLE-BOUNDARY-START(292058854239)
            /*ECI*/ static Windows1256 = null;
            //--TRIMMABLE-BOUNDARY-END(292058854239)
            
            //--TRIMMABLE-BOUNDARY-START(253404148575)
            /*ECI*/ static UTF16BE = null;
            //--TRIMMABLE-BOUNDARY-END(253404148575)
            
            //--TRIMMABLE-BOUNDARY-START(270584017759)
            /*ECI*/ static UTF8 = null;
            //--TRIMMABLE-BOUNDARY-END(270584017759)
            
            //--TRIMMABLE-BOUNDARY-START(249109181279)
            /*ECI*/ static US_ASCII = null;
            //--TRIMMABLE-BOUNDARY-END(249109181279)
            
            //--TRIMMABLE-BOUNDARY-START(25770881887)
            /*ECI*/ static Big5 = null;
            //--TRIMMABLE-BOUNDARY-END(25770881887)
            
            //--TRIMMABLE-BOUNDARY-START(73015522143)
            /*ECI*/ static GB2312 = null;
            //--TRIMMABLE-BOUNDARY-END(73015522143)
            
            //--TRIMMABLE-BOUNDARY-START(167504802655)
            /*ECI*/ static KS_X1001 = null;
            //--TRIMMABLE-BOUNDARY-END(167504802655)
            
            //--TRIMMABLE-BOUNDARY-START(77310489439)
            /*ECI*/ static GBK = null;
            //--TRIMMABLE-BOUNDARY-END(77310489439)
            
            //--TRIMMABLE-BOUNDARY-START(68720554847)
            /*ECI*/ static GB18030 = null;
            //--TRIMMABLE-BOUNDARY-END(68720554847)
            
            //--TRIMMABLE-BOUNDARY-START(257699115871)
            /*ECI*/ static UTF16LE = null;
            //--TRIMMABLE-BOUNDARY-END(257699115871)
            
            //--TRIMMABLE-BOUNDARY-START(261994083167)
            /*ECI*/ static UTF32BE = null;
            //--TRIMMABLE-BOUNDARY-END(261994083167)
            
            //--TRIMMABLE-BOUNDARY-START(266289050463)
            /*ECI*/ static UTF32LE = null;
            //--TRIMMABLE-BOUNDARY-END(266289050463)
            
            //--TRIMMABLE-BOUNDARY-START(98785325919)
            /*ECI*/ static Iso646Inv = null;
            //--TRIMMABLE-BOUNDARY-END(98785325919)
            
            //--TRIMMABLE-BOUNDARY-START(30065849183)
            /*ECI*/ static BinaryData = null;
            //--TRIMMABLE-BOUNDARY-END(30065849183)
            
            //--TRIMMABLE-BOUNDARY-START(64425587551)
            static /*ECI */ FromValue(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425587551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$wZnq.NCQ.ECI().$ctor$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425587551)
            
            //--TRIMMABLE-BOUNDARY-START(12885979999)
            $ctor$1(/*int*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885979999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885979999)
            
            //--TRIMMABLE-BOUNDARY-START(274878985055)
            /*int*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(274878985055)
            
            //--TRIMMABLE-BOUNDARY-START(90195391327)
            /*Encoding */ GetEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195391327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let codePage;
                if (this.Value >= 0 && this.Value < $.$wZnq.NCQ.ECI.CodePages.length)
                {
                    codePage = $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.ECI.CodePages, this.Value);
                }
                else 
                {
                    throw new $.$wZnq.NCQ.ECIException().$ctor$15(`Unsupported ECI value ${this.Value}: it is not associated with a character set encoding.`);
                }
                if (codePage !== -1)
                {
                    try
                    {
                        return $.$wZnq.NCQ.ECI.EncodingCache.GetOrAdd(codePage, $.$wZnq.NCQ.ECI.CreateEncodingFunc);
                    }
                    catch($e)
                    {
                    }
                }
                throw new $.$wZnq.NCQ.ECIException().$ctor$15(`Unsupported ECI value: ${this.Value}. Character set encoding is required but not available on this platform.`);
            }
            //--TRIMMABLE-BOUNDARY-END(90195391327)
            
            //--TRIMMABLE-BOUNDARY-START(51540685663)
            /*ConcurrentDictionary<int, Encoding>*/ static EncodingCache = null;
            //--TRIMMABLE-BOUNDARY-END(51540685663)
            
            //--TRIMMABLE-BOUNDARY-START(47245718367)
            /*Func<int, Encoding>*/ static CreateEncodingFunc = null;
            //--TRIMMABLE-BOUNDARY-END(47245718367)
            
            //--TRIMMABLE-BOUNDARY-START(42950751071)
            static /*Encoding */ CreateEncoding(/*int*/ codePage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950751071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.ST.Encoding.GetEncoding(codePage, new $.$$.ST.EncoderExceptionFallback().$ctor$2(), new $.$$.ST.DecoderExceptionFallback().$ctor$2());
            }
            //--TRIMMABLE-BOUNDARY-END(42950751071)
            
            //--TRIMMABLE-BOUNDARY-START(38655783775)
            /*int[]*/ static CodePages = null;
            //--TRIMMABLE-BOUNDARY-END(38655783775)
            
            //--TRIMMABLE-BOUNDARY-START(60130620255)
            /*bool */ Equals$2(/*ECI*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130620255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return other !== null && this.Value === other.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(60130620255)
            
            //--TRIMMABLE-BOUNDARY-START(55835652959)
            /*bool */ Equals$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835652959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return false;
                }
                if ($.$$.S.Object.ReferenceEquals(this, obj))
                {
                    return true;
                }
                if ($.$$.S.Type.op_Inequality$1($.$$.S.Object.GetType.call(obj), $.$$.S.Object.GetType.call(this)))
                {
                    return false;
                }
                return this.Equals$2($.$cast(obj, $.$wZnq.NCQ.ECI));
            }
            //--TRIMMABLE-BOUNDARY-END(55835652959)
            
            //--TRIMMABLE-BOUNDARY-START(94490358623)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490358623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(94490358623)
            
            //--TRIMMABLE-BOUNDARY-START(4385603585)
            //Generated interface implemetation for System.IEquatable<Net.Codecrete.QrCodeGenerator.ECI>.Equals(Net.Codecrete.QrCodeGenerator.ECI?)
            S$IEquatable$Net$Codecrete$QrCodeGenerator$ECI$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385603585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385603585)
            
            //--TRIMMABLE-BOUNDARY-START(8591012703)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591012703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(236224279391)
                    this.None = new $.$wZnq.NCQ.ECI().$ctor$1(-2/*NoneValue*/);
                    //--TRIMMABLE-BOUNDARY-END(236224279391)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180947295)
                    this.Automatic = new $.$wZnq.NCQ.ECI().$ctor$1(-1/*AutomaticValue*/);
                    //--TRIMMABLE-BOUNDARY-END(17180947295)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360816479)
                    this.CodePage437 = new $.$wZnq.NCQ.ECI().$ctor$1(2);
                    //--TRIMMABLE-BOUNDARY-END(34360816479)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799769951)
                    this.Latin1 = new $.$wZnq.NCQ.ECI().$ctor$1(3);
                    //--TRIMMABLE-BOUNDARY-END(171799769951)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080293215)
                    this.Iso8859_1 = $.$wZnq.NCQ.ECI.Latin1;
                    //--TRIMMABLE-BOUNDARY-END(103080293215)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389704543)
                    this.Latin2 = new $.$wZnq.NCQ.ECI().$ctor$1(4);
                    //--TRIMMABLE-BOUNDARY-END(180389704543)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133145064287)
                    this.Iso8859_2 = $.$wZnq.NCQ.ECI.Latin2;
                    //--TRIMMABLE-BOUNDARY-END(133145064287)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184684671839)
                    this.Latin3 = new $.$wZnq.NCQ.ECI().$ctor$1(5);
                    //--TRIMMABLE-BOUNDARY-END(184684671839)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137440031583)
                    this.Iso8859_3 = $.$wZnq.NCQ.ECI.Latin3;
                    //--TRIMMABLE-BOUNDARY-END(137440031583)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979639135)
                    this.Latin4 = new $.$wZnq.NCQ.ECI().$ctor$1(6);
                    //--TRIMMABLE-BOUNDARY-END(188979639135)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734998879)
                    this.Iso8859_4 = $.$wZnq.NCQ.ECI.Latin4;
                    //--TRIMMABLE-BOUNDARY-END(141734998879)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219044410207)
                    this.LatinCyrillic = new $.$wZnq.NCQ.ECI().$ctor$1(7);
                    //--TRIMMABLE-BOUNDARY-END(219044410207)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029966175)
                    this.Iso8859_5 = $.$wZnq.NCQ.ECI.LatinCyrillic;
                    //--TRIMMABLE-BOUNDARY-END(146029966175)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749442911)
                    this.LatinArabic = new $.$wZnq.NCQ.ECI().$ctor$1(8);
                    //--TRIMMABLE-BOUNDARY-END(214749442911)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324933471)
                    this.Iso8859_6 = $.$wZnq.NCQ.ECI.LatinArabic;
                    //--TRIMMABLE-BOUNDARY-END(150324933471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223339377503)
                    this.LatinGreek = new $.$wZnq.NCQ.ECI().$ctor$1(9);
                    //--TRIMMABLE-BOUNDARY-END(223339377503)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619900767)
                    this.Iso8859_7 = $.$wZnq.NCQ.ECI.LatinGreek;
                    //--TRIMMABLE-BOUNDARY-END(154619900767)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227634344799)
                    this.LatinHebrew = new $.$wZnq.NCQ.ECI().$ctor$1(10);
                    //--TRIMMABLE-BOUNDARY-END(227634344799)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914868063)
                    this.Iso8859_8 = $.$wZnq.NCQ.ECI.LatinHebrew;
                    //--TRIMMABLE-BOUNDARY-END(158914868063)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274606431)
                    this.Latin5 = new $.$wZnq.NCQ.ECI().$ctor$1(11);
                    //--TRIMMABLE-BOUNDARY-END(193274606431)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209835359)
                    this.Iso8859_9 = $.$wZnq.NCQ.ECI.Latin5;
                    //--TRIMMABLE-BOUNDARY-END(163209835359)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569573727)
                    this.Latin6 = new $.$wZnq.NCQ.ECI().$ctor$1(12);
                    //--TRIMMABLE-BOUNDARY-END(197569573727)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375260511)
                    this.Iso8859_10 = $.$wZnq.NCQ.ECI.Latin6;
                    //--TRIMMABLE-BOUNDARY-END(107375260511)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929312095)
                    this.LatinThai = new $.$wZnq.NCQ.ECI().$ctor$1(13);
                    //--TRIMMABLE-BOUNDARY-END(231929312095)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670227807)
                    this.Iso8859_11 = $.$wZnq.NCQ.ECI.LatinThai;
                    //--TRIMMABLE-BOUNDARY-END(111670227807)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201864541023)
                    this.Latin7 = new $.$wZnq.NCQ.ECI().$ctor$1(15);
                    //--TRIMMABLE-BOUNDARY-END(201864541023)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115965195103)
                    this.Iso8859_13 = $.$wZnq.NCQ.ECI.Latin7;
                    //--TRIMMABLE-BOUNDARY-END(115965195103)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206159508319)
                    this.Latin8 = new $.$wZnq.NCQ.ECI().$ctor$1(16);
                    //--TRIMMABLE-BOUNDARY-END(206159508319)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120260162399)
                    this.Iso8859_14 = $.$wZnq.NCQ.ECI.Latin8;
                    //--TRIMMABLE-BOUNDARY-END(120260162399)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210454475615)
                    this.Latin9 = new $.$wZnq.NCQ.ECI().$ctor$1(17);
                    //--TRIMMABLE-BOUNDARY-END(210454475615)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124555129695)
                    this.Iso8859_15 = $.$wZnq.NCQ.ECI.Latin9;
                    //--TRIMMABLE-BOUNDARY-END(124555129695)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094737247)
                    this.Latin10 = new $.$wZnq.NCQ.ECI().$ctor$1(18);
                    //--TRIMMABLE-BOUNDARY-END(176094737247)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128850096991)
                    this.Iso8859_16 = $.$wZnq.NCQ.ECI.Latin10;
                    //--TRIMMABLE-BOUNDARY-END(128850096991)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244814213983)
                    this.ShiftJIS = new $.$wZnq.NCQ.ECI().$ctor$1(20);
                    //--TRIMMABLE-BOUNDARY-END(244814213983)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173952351)
                    this.Windows1250 = new $.$wZnq.NCQ.ECI().$ctor$1(21);
                    //--TRIMMABLE-BOUNDARY-END(279173952351)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468919647)
                    this.Windows1251 = new $.$wZnq.NCQ.ECI().$ctor$1(22);
                    //--TRIMMABLE-BOUNDARY-END(283468919647)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763886943)
                    this.Windows1252 = new $.$wZnq.NCQ.ECI().$ctor$1(23);
                    //--TRIMMABLE-BOUNDARY-END(287763886943)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292058854239)
                    this.Windows1256 = new $.$wZnq.NCQ.ECI().$ctor$1(24);
                    //--TRIMMABLE-BOUNDARY-END(292058854239)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253404148575)
                    this.UTF16BE = new $.$wZnq.NCQ.ECI().$ctor$1(25);
                    //--TRIMMABLE-BOUNDARY-END(253404148575)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270584017759)
                    this.UTF8 = new $.$wZnq.NCQ.ECI().$ctor$1(26);
                    //--TRIMMABLE-BOUNDARY-END(270584017759)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249109181279)
                    this.US_ASCII = new $.$wZnq.NCQ.ECI().$ctor$1(27);
                    //--TRIMMABLE-BOUNDARY-END(249109181279)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770881887)
                    this.Big5 = new $.$wZnq.NCQ.ECI().$ctor$1(28);
                    //--TRIMMABLE-BOUNDARY-END(25770881887)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015522143)
                    this.GB2312 = new $.$wZnq.NCQ.ECI().$ctor$1(29);
                    //--TRIMMABLE-BOUNDARY-END(73015522143)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504802655)
                    this.KS_X1001 = new $.$wZnq.NCQ.ECI().$ctor$1(30);
                    //--TRIMMABLE-BOUNDARY-END(167504802655)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310489439)
                    this.GBK = new $.$wZnq.NCQ.ECI().$ctor$1(31);
                    //--TRIMMABLE-BOUNDARY-END(77310489439)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720554847)
                    this.GB18030 = new $.$wZnq.NCQ.ECI().$ctor$1(32);
                    //--TRIMMABLE-BOUNDARY-END(68720554847)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257699115871)
                    this.UTF16LE = new $.$wZnq.NCQ.ECI().$ctor$1(33);
                    //--TRIMMABLE-BOUNDARY-END(257699115871)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261994083167)
                    this.UTF32BE = new $.$wZnq.NCQ.ECI().$ctor$1(34);
                    //--TRIMMABLE-BOUNDARY-END(261994083167)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266289050463)
                    this.UTF32LE = new $.$wZnq.NCQ.ECI().$ctor$1(35);
                    //--TRIMMABLE-BOUNDARY-END(266289050463)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98785325919)
                    this.Iso646Inv = new $.$wZnq.NCQ.ECI().$ctor$1(170);
                    //--TRIMMABLE-BOUNDARY-END(98785325919)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065849183)
                    this.BinaryData = new $.$wZnq.NCQ.ECI().$ctor$1(899);
                    //--TRIMMABLE-BOUNDARY-END(30065849183)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540685663)
                    this.EncodingCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$$.ST.Encoding))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(51540685663)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245718367)
                    this.CreateEncodingFunc = new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.ST.Encoding))().$ctor($.$wZnq.NCQ.ECI, $.$wZnq.NCQ.ECI.CreateEncoding);
                    //--TRIMMABLE-BOUNDARY-END(47245718367)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655783775)
                    this.CodePages = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [437, 28591, 437, 28591, 28592, 28593, 28594, 28595, 28596, 28597, 28598, 28599, 28600, 28601, -1, 28603, 28604, 28605, 28606, -1, 932, 1250, 1251, 1252, 1256, 1201, 65001, 20127, 950, 936, 949, -1, 54936, 1200, 12001, 12000], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(38655783775)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591012703)
            
            static $h = 1078111;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(274878985055),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900424031,
        "f": 50331649
      },
      "n": "Value",
      "d": 1078111,
      "h": 274878985055,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878985055)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425587551),
    {
      "r": 1078111,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "FromValue",
      "d": 1078111,
      "h": 64425587551,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425587551),
//--TRIMMABLE-BOUNDARY-START(90195391327),
    {
      "r": 166199297,
      "n": "GetEncoding",
      "d": 1078111,
      "h": 90195391327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195391327),
//--TRIMMABLE-BOUNDARY-START(42950751071),
    {
      "r": 166199297,
      "p": [
        {
          "n": "codePage",
          "p": 655361
        }
      ],
      "n": "CreateEncoding",
      "d": 1078111,
      "h": 42950751071,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950751071),
//--TRIMMABLE-BOUNDARY-START(60130620255),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1078111
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1078111,
      "h": 60130620255,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130620255),
//--TRIMMABLE-BOUNDARY-START(55835652959),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1078111,
      "h": 55835652959,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835652959),
//--TRIMMABLE-BOUNDARY-START(94490358623),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1078111,
      "h": 94490358623,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490358623)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(240519246687),
    {
      "t": 655361,
      "n": "NoneValue",
      "d": 1078111,
      "h": 240519246687,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240519246687),
//--TRIMMABLE-BOUNDARY-START(21475914591),
    {
      "t": 655361,
      "n": "AutomaticValue",
      "d": 1078111,
      "h": 21475914591,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475914591),
//--TRIMMABLE-BOUNDARY-START(236224279391),
    {
      "t": 1078111,
      "n": "None",
      "d": 1078111,
      "h": 236224279391,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236224279391),
//--TRIMMABLE-BOUNDARY-START(17180947295),
    {
      "t": 1078111,
      "n": "Automatic",
      "d": 1078111,
      "h": 17180947295,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180947295),
//--TRIMMABLE-BOUNDARY-START(34360816479),
    {
      "t": 1078111,
      "n": "CodePage437",
      "d": 1078111,
      "h": 34360816479,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360816479),
//--TRIMMABLE-BOUNDARY-START(171799769951),
    {
      "t": 1078111,
      "n": "Latin1",
      "d": 1078111,
      "h": 171799769951,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799769951),
//--TRIMMABLE-BOUNDARY-START(103080293215),
    {
      "t": 1078111,
      "n": "Iso8859_1",
      "d": 1078111,
      "h": 103080293215,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080293215),
//--TRIMMABLE-BOUNDARY-START(180389704543),
    {
      "t": 1078111,
      "n": "Latin2",
      "d": 1078111,
      "h": 180389704543,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389704543),
//--TRIMMABLE-BOUNDARY-START(133145064287),
    {
      "t": 1078111,
      "n": "Iso8859_2",
      "d": 1078111,
      "h": 133145064287,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133145064287),
//--TRIMMABLE-BOUNDARY-START(184684671839),
    {
      "t": 1078111,
      "n": "Latin3",
      "d": 1078111,
      "h": 184684671839,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684671839),
//--TRIMMABLE-BOUNDARY-START(137440031583),
    {
      "t": 1078111,
      "n": "Iso8859_3",
      "d": 1078111,
      "h": 137440031583,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137440031583),
//--TRIMMABLE-BOUNDARY-START(188979639135),
    {
      "t": 1078111,
      "n": "Latin4",
      "d": 1078111,
      "h": 188979639135,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188979639135),
//--TRIMMABLE-BOUNDARY-START(141734998879),
    {
      "t": 1078111,
      "n": "Iso8859_4",
      "d": 1078111,
      "h": 141734998879,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734998879),
//--TRIMMABLE-BOUNDARY-START(219044410207),
    {
      "t": 1078111,
      "n": "LatinCyrillic",
      "d": 1078111,
      "h": 219044410207,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219044410207),
//--TRIMMABLE-BOUNDARY-START(146029966175),
    {
      "t": 1078111,
      "n": "Iso8859_5",
      "d": 1078111,
      "h": 146029966175,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029966175),
//--TRIMMABLE-BOUNDARY-START(214749442911),
    {
      "t": 1078111,
      "n": "LatinArabic",
      "d": 1078111,
      "h": 214749442911,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214749442911),
//--TRIMMABLE-BOUNDARY-START(150324933471),
    {
      "t": 1078111,
      "n": "Iso8859_6",
      "d": 1078111,
      "h": 150324933471,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324933471),
//--TRIMMABLE-BOUNDARY-START(223339377503),
    {
      "t": 1078111,
      "n": "LatinGreek",
      "d": 1078111,
      "h": 223339377503,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223339377503),
//--TRIMMABLE-BOUNDARY-START(154619900767),
    {
      "t": 1078111,
      "n": "Iso8859_7",
      "d": 1078111,
      "h": 154619900767,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619900767),
//--TRIMMABLE-BOUNDARY-START(227634344799),
    {
      "t": 1078111,
      "n": "LatinHebrew",
      "d": 1078111,
      "h": 227634344799,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227634344799),
//--TRIMMABLE-BOUNDARY-START(158914868063),
    {
      "t": 1078111,
      "n": "Iso8859_8",
      "d": 1078111,
      "h": 158914868063,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914868063),
//--TRIMMABLE-BOUNDARY-START(193274606431),
    {
      "t": 1078111,
      "n": "Latin5",
      "d": 1078111,
      "h": 193274606431,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193274606431),
//--TRIMMABLE-BOUNDARY-START(163209835359),
    {
      "t": 1078111,
      "n": "Iso8859_9",
      "d": 1078111,
      "h": 163209835359,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209835359),
//--TRIMMABLE-BOUNDARY-START(197569573727),
    {
      "t": 1078111,
      "n": "Latin6",
      "d": 1078111,
      "h": 197569573727,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197569573727),
//--TRIMMABLE-BOUNDARY-START(107375260511),
    {
      "t": 1078111,
      "n": "Iso8859_10",
      "d": 1078111,
      "h": 107375260511,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375260511),
//--TRIMMABLE-BOUNDARY-START(231929312095),
    {
      "t": 1078111,
      "n": "LatinThai",
      "d": 1078111,
      "h": 231929312095,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231929312095),
//--TRIMMABLE-BOUNDARY-START(111670227807),
    {
      "t": 1078111,
      "n": "Iso8859_11",
      "d": 1078111,
      "h": 111670227807,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670227807),
//--TRIMMABLE-BOUNDARY-START(201864541023),
    {
      "t": 1078111,
      "n": "Latin7",
      "d": 1078111,
      "h": 201864541023,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201864541023),
//--TRIMMABLE-BOUNDARY-START(115965195103),
    {
      "t": 1078111,
      "n": "Iso8859_13",
      "d": 1078111,
      "h": 115965195103,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115965195103),
//--TRIMMABLE-BOUNDARY-START(206159508319),
    {
      "t": 1078111,
      "n": "Latin8",
      "d": 1078111,
      "h": 206159508319,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206159508319),
//--TRIMMABLE-BOUNDARY-START(120260162399),
    {
      "t": 1078111,
      "n": "Iso8859_14",
      "d": 1078111,
      "h": 120260162399,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120260162399),
//--TRIMMABLE-BOUNDARY-START(210454475615),
    {
      "t": 1078111,
      "n": "Latin9",
      "d": 1078111,
      "h": 210454475615,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210454475615),
//--TRIMMABLE-BOUNDARY-START(124555129695),
    {
      "t": 1078111,
      "n": "Iso8859_15",
      "d": 1078111,
      "h": 124555129695,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555129695),
//--TRIMMABLE-BOUNDARY-START(176094737247),
    {
      "t": 1078111,
      "n": "Latin10",
      "d": 1078111,
      "h": 176094737247,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094737247),
//--TRIMMABLE-BOUNDARY-START(128850096991),
    {
      "t": 1078111,
      "n": "Iso8859_16",
      "d": 1078111,
      "h": 128850096991,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128850096991),
//--TRIMMABLE-BOUNDARY-START(244814213983),
    {
      "t": 1078111,
      "n": "ShiftJIS",
      "d": 1078111,
      "h": 244814213983,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244814213983),
//--TRIMMABLE-BOUNDARY-START(279173952351),
    {
      "t": 1078111,
      "n": "Windows1250",
      "d": 1078111,
      "h": 279173952351,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173952351),
//--TRIMMABLE-BOUNDARY-START(283468919647),
    {
      "t": 1078111,
      "n": "Windows1251",
      "d": 1078111,
      "h": 283468919647,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283468919647),
//--TRIMMABLE-BOUNDARY-START(287763886943),
    {
      "t": 1078111,
      "n": "Windows1252",
      "d": 1078111,
      "h": 287763886943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287763886943),
//--TRIMMABLE-BOUNDARY-START(292058854239),
    {
      "t": 1078111,
      "n": "Windows1256",
      "d": 1078111,
      "h": 292058854239,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292058854239),
//--TRIMMABLE-BOUNDARY-START(253404148575),
    {
      "t": 1078111,
      "n": "UTF16BE",
      "d": 1078111,
      "h": 253404148575,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(253404148575),
//--TRIMMABLE-BOUNDARY-START(270584017759),
    {
      "t": 1078111,
      "n": "UTF8",
      "d": 1078111,
      "h": 270584017759,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270584017759),
//--TRIMMABLE-BOUNDARY-START(249109181279),
    {
      "t": 1078111,
      "n": "US_ASCII",
      "d": 1078111,
      "h": 249109181279,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249109181279),
//--TRIMMABLE-BOUNDARY-START(25770881887),
    {
      "t": 1078111,
      "n": "Big5",
      "d": 1078111,
      "h": 25770881887,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770881887),
//--TRIMMABLE-BOUNDARY-START(73015522143),
    {
      "t": 1078111,
      "n": "GB2312",
      "d": 1078111,
      "h": 73015522143,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015522143),
//--TRIMMABLE-BOUNDARY-START(167504802655),
    {
      "t": 1078111,
      "n": "KS_X1001",
      "d": 1078111,
      "h": 167504802655,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504802655),
//--TRIMMABLE-BOUNDARY-START(77310489439),
    {
      "t": 1078111,
      "n": "GBK",
      "d": 1078111,
      "h": 77310489439,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310489439),
//--TRIMMABLE-BOUNDARY-START(68720554847),
    {
      "t": 1078111,
      "n": "GB18030",
      "d": 1078111,
      "h": 68720554847,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720554847),
//--TRIMMABLE-BOUNDARY-START(257699115871),
    {
      "t": 1078111,
      "n": "UTF16LE",
      "d": 1078111,
      "h": 257699115871,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257699115871),
//--TRIMMABLE-BOUNDARY-START(261994083167),
    {
      "t": 1078111,
      "n": "UTF32BE",
      "d": 1078111,
      "h": 261994083167,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261994083167),
//--TRIMMABLE-BOUNDARY-START(266289050463),
    {
      "t": 1078111,
      "n": "UTF32LE",
      "d": 1078111,
      "h": 266289050463,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266289050463),
//--TRIMMABLE-BOUNDARY-START(98785325919),
    {
      "t": 1078111,
      "n": "Iso646Inv",
      "d": 1078111,
      "h": 98785325919,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785325919),
//--TRIMMABLE-BOUNDARY-START(30065849183),
    {
      "t": 1078111,
      "n": "BinaryData",
      "d": 1078111,
      "h": 30065849183,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065849183),
//--TRIMMABLE-BOUNDARY-START(51540685663),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$$.ST.Encoding).$h,
      "n": "EncodingCache",
      "d": 1078111,
      "h": 51540685663,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51540685663),
//--TRIMMABLE-BOUNDARY-START(47245718367),
    {
      "t": $.$$.S.Func$$$($.$$.S.Int32, $.$$.ST.Encoding).$h,
      "n": "CreateEncodingFunc",
      "d": 1078111,
      "h": 47245718367,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245718367),
//--TRIMMABLE-BOUNDARY-START(38655783775),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "CodePages",
      "d": 1078111,
      "h": 38655783775,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655783775)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885979999),
    {
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1078111,
      "h": 12885979999,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885979999)
  ],
  "i": [$.$$.S.IEquatable$$($.$wZnq.NCQ.ECI).$h
  ],
  "h": 1078111,
  "a": [
    {
      "t": 162594817,
      "c": 4457562113
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$wZnq.NCQ.ECI) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.ECI`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}ECI`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1078111)
        
        

        //--TRIMMABLE-BOUNDARY-START(553823)
        $asm.$cls(`$wZnq.NCQ.DataSegmentByte`, ($self) => class DataSegmentByte extends $.$wZnq.NCQ.DataSegment
        {
            //--TRIMMABLE-BOUNDARY-START(4295521119)
            $ctor$2(/*ArraySegment<byte>*/ bytes)
            {
                super.$ctor$1(4/*DataSegmentMode.Binary*/, $.$wZnq.NCQ.DataSegmentByte.GetByteBitLength(bytes.Count));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295521119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ;
                    this.DataBytes = bytes;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295521119)
            
            //--TRIMMABLE-BOUNDARY-START(8590488415)
            static /*int */ GetByteBitLength(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590488415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((length * 8) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8590488415)
            
            //--TRIMMABLE-BOUNDARY-START(12885455711)
            static /*int */ GetByteByteCount(/*int*/ bitLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885455711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.trunc(bitLength / 8);
            }
            //--TRIMMABLE-BOUNDARY-END(12885455711)
            
            //--TRIMMABLE-BOUNDARY-START(17180423007)
            /*void */ WriteToBitStream(/*BitStream*/ bitStream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180423007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this.DataBytes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current;
                    {
                        bitStream.AppendBits(b, 8);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180423007)
            
            static $h = 553823;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 422751,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590488415),
    {
      "r": 655361,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "GetByteBitLength",
      "d": 553823,
      "h": 8590488415,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590488415),
//--TRIMMABLE-BOUNDARY-START(12885455711),
    {
      "r": 655361,
      "p": [
        {
          "n": "bitLength",
          "p": 655361
        }
      ],
      "n": "GetByteByteCount",
      "d": 553823,
      "h": 12885455711,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885455711),
//--TRIMMABLE-BOUNDARY-START(17180423007),
    {
      "r": 65537,
      "p": [
        {
          "n": "bitStream",
          "p": 226143
        }
      ],
      "n": "WriteToBitStream",
      "d": 553823,
      "h": 17180423007,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17180423007)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295521119),
    {
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 553823,
      "h": 4295521119,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295521119)
  ],
  "h": 553823
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$wZnq.NCQ.DataSegment; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegmentByte`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegmentByte`; }
        });
        //--TRIMMABLE-BOUNDARY-END(553823)
        
        

        //--TRIMMABLE-BOUNDARY-START(1405791)
        $asm.$str(`$wZnq.NCQ.MaskPair`, ($self) => class MaskPair extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17181274975)
            $ctor$3(/*BitMatrix*/ rows, /*BitMatrix*/ columns)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181274975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Rows = rows;
                    this.Columns = columns;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181274975)
            
            //--TRIMMABLE-BOUNDARY-START(42951078751)
            /*BitMatrix*/ Rows;
            //--TRIMMABLE-BOUNDARY-END(42951078751)
            
            //--TRIMMABLE-BOUNDARY-START(21476242271)
            /*BitMatrix*/ Columns;
            //--TRIMMABLE-BOUNDARY-END(21476242271)
            
            //--TRIMMABLE-BOUNDARY-START(12886307679)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886307679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886307679)
            
            //--TRIMMABLE-BOUNDARY-START(12886307679)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886307679)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Rows = this.Rows.Clone();
                copy.Columns = this.Columns.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42951078751)
                this.Rows = $.$default($.$wZnq.NCQ.BitMatrix);
                //--TRIMMABLE-BOUNDARY-END(42951078751)
                
                //--TRIMMABLE-BOUNDARY-START(21476242271)
                this.Columns = $.$default($.$wZnq.NCQ.BitMatrix);
                //--TRIMMABLE-BOUNDARY-END(21476242271)
                
            }
            static $h = 1405791;
            static $z = 32;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951078751),
    {
      "p": 160607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656111455,
        "f": 50331656
      },
      "n": "Rows",
      "d": 1405791,
      "h": 42951078751,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42951078751),
//--TRIMMABLE-BOUNDARY-START(21476242271),
    {
      "p": 160607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066176863,
        "f": 50331656
      },
      "n": "Columns",
      "d": 1405791,
      "h": 21476242271,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21476242271)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181274975),
    {
      "p": [
        {
          "n": "rows",
          "p": 160607
        },
        {
          "n": "columns",
          "p": 160607
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1405791,
      "h": 17181274975,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181274975),
//--TRIMMABLE-BOUNDARY-START(12886307679),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1405791,
      "h": 12886307679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886307679)
  ],
  "h": 1405791
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.MaskPair`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}MaskPair`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1405791)
        
        

        //--TRIMMABLE-BOUNDARY-START(1733471)
        $asm.$str(`$wZnq.NCQ.PenaltyScore`, ($self) => class PenaltyScore extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(111670883167)
            /*int*/ HorizontalStreaks = 0;
            //--TRIMMABLE-BOUNDARY-END(111670883167)
            
            //--TRIMMABLE-BOUNDARY-START(184685327199)
            /*int*/ VerticalStreaks = 0;
            //--TRIMMABLE-BOUNDARY-END(184685327199)
            
            //--TRIMMABLE-BOUNDARY-START(38656439135)
            /*int*/ Blocks = 0;
            //--TRIMMABLE-BOUNDARY-END(38656439135)
            
            //--TRIMMABLE-BOUNDARY-START(107375915871)
            /*int*/ HorizontalFinderPatterns = 0;
            //--TRIMMABLE-BOUNDARY-END(107375915871)
            
            //--TRIMMABLE-BOUNDARY-START(180390359903)
            /*int*/ VerticalFinderPatterns = 0;
            //--TRIMMABLE-BOUNDARY-END(180390359903)
            
            //--TRIMMABLE-BOUNDARY-START(42951406431)
            /*int*/ ColorBalance = 0;
            //--TRIMMABLE-BOUNDARY-END(42951406431)
            
            //--TRIMMABLE-BOUNDARY-START(176095392607)
            /*int*/ Total = 0;
            //--TRIMMABLE-BOUNDARY-END(176095392607)
            
            //--TRIMMABLE-BOUNDARY-START(34361471839)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361471839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361471839)
            
            //--TRIMMABLE-BOUNDARY-START(34361471839)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(34361471839)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.HorizontalStreaks = this.HorizontalStreaks;
                copy.VerticalStreaks = this.VerticalStreaks;
                copy.Blocks = this.Blocks;
                copy.HorizontalFinderPatterns = this.HorizontalFinderPatterns;
                copy.VerticalFinderPatterns = this.VerticalFinderPatterns;
                copy.ColorBalance = this.ColorBalance;
                copy.Total = this.Total;
                return copy;
            }
            static $h = 1733471;
            static $z = 28;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670883167),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311144799,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030621535,
        "f": 83886081
      },
      "n": "HorizontalStreaks",
      "d": 1733471,
      "h": 111670883167,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670883167),
//--TRIMMABLE-BOUNDARY-START(184685327199),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080948575,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800425311,
        "f": 83886081
      },
      "n": "VerticalStreaks",
      "d": 1733471,
      "h": 184685327199,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184685327199),
//--TRIMMABLE-BOUNDARY-START(38656439135),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541341023,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260817759,
        "f": 83886081
      },
      "n": "Blocks",
      "d": 1733471,
      "h": 38656439135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656439135),
//--TRIMMABLE-BOUNDARY-START(107375915871),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721210207,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440686943,
        "f": 83886081
      },
      "n": "HorizontalFinderPatterns",
      "d": 1733471,
      "h": 107375915871,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375915871),
//--TRIMMABLE-BOUNDARY-START(180390359903),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491013983,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210490719,
        "f": 83886081
      },
      "n": "VerticalFinderPatterns",
      "d": 1733471,
      "h": 180390359903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390359903),
//--TRIMMABLE-BOUNDARY-START(42951406431),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131275615,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850752351,
        "f": 83886081
      },
      "n": "ColorBalance",
      "d": 1733471,
      "h": 42951406431,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951406431),
//--TRIMMABLE-BOUNDARY-START(176095392607),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901079391,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620556127,
        "f": 83886081
      },
      "n": "Total",
      "d": 1733471,
      "h": 176095392607,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176095392607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361471839),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1733471,
      "h": 34361471839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361471839)
  ],
  "h": 1733471
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.PenaltyScore`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}PenaltyScore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1733471)
        
        

        //--TRIMMABLE-BOUNDARY-START(881503)
        $asm.$cls(`$wZnq.NCQ.DataSegmentNumeric`, ($self) => class DataSegmentNumeric extends $.$wZnq.NCQ.DataSegment
        {
            //--TRIMMABLE-BOUNDARY-START(4295848799)
            $ctor$2(/*ArraySegment<byte>*/ bytes)
            {
                super.$ctor$1(1/*DataSegmentMode.Numeric*/, $.$wZnq.NCQ.DataSegmentNumeric.GetNumericBitLength(bytes.Count));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295848799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ;
                    this.DataBytes = bytes;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295848799)
            
            //--TRIMMABLE-BOUNDARY-START(17180750687)
            static /*bool */ IsNumeric(/*byte*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180750687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return b >= /*0*/ 48 && b <= /*9*/ 57;
            }
            //--TRIMMABLE-BOUNDARY-END(17180750687)
            
            //--TRIMMABLE-BOUNDARY-START(8590816095)
            static /*int */ GetNumericBitLength(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590816095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.trunc((((((length * 10) | 0) + 2) | 0)) / 3);
            }
            //--TRIMMABLE-BOUNDARY-END(8590816095)
            
            //--TRIMMABLE-BOUNDARY-START(12885783391)
            static /*int */ GetNumericByteCount(/*int*/ bitLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885783391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.trunc(((bitLength * 3) | 0) / 10);
            }
            //--TRIMMABLE-BOUNDARY-END(12885783391)
            
            //--TRIMMABLE-BOUNDARY-START(21475717983)
            /*void */ WriteToBitStream(/*BitStream*/ bitStream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475717983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bytes = this.DataBytes;
                ;
                /*var*/ let i = 0;
                while(i < bytes.Count)
                {
                    /*var*/ let n = $.$$.S.Math.Min$4(((bytes.Count - i) | 0), 3);
                    /*var*/ let value = 0;
                    for(/*var*/ let j = i; j < ((i + n) | 0); j += 1)
                    {
                        /*var*/ let digitByte = $.$$.System.Array.$ReadT1.call(bytes.Array, ((bytes.Offset + j) | 0));
                        $.$$.SD.Debug.Assert$4($.$wZnq.NCQ.DataSegmentNumeric.IsNumeric(digitByte), "IsNumeric(digitByte)");
                        value = ((((((value * 10) >>> 0) + digitByte) >>> 0) - 48) >>> 0);
                    }
                    bitStream.AppendBits(value, ((((n * 3) | 0) + 1) | 0));
                    i += n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475717983)
            
            static $h = 881503;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 422751,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180750687),
    {
      "r": 262145,
      "p": [
        {
          "n": "b",
          "p": 393217
        }
      ],
      "n": "IsNumeric",
      "d": 881503,
      "h": 17180750687,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180750687),
//--TRIMMABLE-BOUNDARY-START(8590816095),
    {
      "r": 655361,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "GetNumericBitLength",
      "d": 881503,
      "h": 8590816095,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590816095),
//--TRIMMABLE-BOUNDARY-START(12885783391),
    {
      "r": 655361,
      "p": [
        {
          "n": "bitLength",
          "p": 655361
        }
      ],
      "n": "GetNumericByteCount",
      "d": 881503,
      "h": 12885783391,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885783391),
//--TRIMMABLE-BOUNDARY-START(21475717983),
    {
      "r": 65537,
      "p": [
        {
          "n": "bitStream",
          "p": 226143
        }
      ],
      "n": "WriteToBitStream",
      "d": 881503,
      "h": 21475717983,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(21475717983)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295848799),
    {
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 881503,
      "h": 4295848799,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295848799)
  ],
  "h": 881503
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$wZnq.NCQ.DataSegment; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegmentNumeric`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegmentNumeric`; }
        });
        //--TRIMMABLE-BOUNDARY-END(881503)
        
        

        //--TRIMMABLE-BOUNDARY-START(619359)
        $asm.$cls(`$wZnq.NCQ.DataSegmentEci`, ($self) => class DataSegmentEci extends $.$wZnq.NCQ.DataSegment
        {
            //--TRIMMABLE-BOUNDARY-START(12885521247)
            /*ECI*/ EciDesignator = null;
            //--TRIMMABLE-BOUNDARY-END(12885521247)
            
            //--TRIMMABLE-BOUNDARY-START(8590553951)
            $ctor$2(/*ECI*/ eci)
            {
                super.$ctor$1(5/*DataSegmentMode.ECI*/, $.$wZnq.NCQ.DataSegmentEci.GetEciBitLength(eci.Value));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590553951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (eci.Value < 0 || eci.Value > 999999)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("eci", eci, "ECI value must be between 0 and 999999");
                    }
                    this.EciDesignator = eci;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590553951)
            
            //--TRIMMABLE-BOUNDARY-START(25770423135)
            static /*int */ GetEciBitLength(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770423135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value <= 127)
                {
                    return 8;
                }
                if (value <= 16383)
                {
                    return 16;
                }
                return 24;
            }
            //--TRIMMABLE-BOUNDARY-END(25770423135)
            
            //--TRIMMABLE-BOUNDARY-START(30065390431)
            /*void */ WriteToBitStream(/*BitStream*/ bitStream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065390431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let eciValue = (this.EciDesignator.Value >>> 0);
                if (eciValue <= 127)
                {
                    bitStream.AppendBits(eciValue, 8);
                }
                else if (eciValue <= 16383)
                {
                    bitStream.AppendBits(32768 | eciValue, 16);
                }
                else if (eciValue <= 999999)
                {
                    bitStream.AppendBits(12582912 | eciValue, 24);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065390431)
            
            static $h = 619359;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 422751,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885521247),
    {
      "p": 1078111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475455839,
        "f": 50364417
      },
      "n": "EciDesignator",
      "d": 619359,
      "h": 12885521247,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885521247)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770423135),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "GetEciBitLength",
      "d": 619359,
      "h": 25770423135,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770423135),
//--TRIMMABLE-BOUNDARY-START(30065390431),
    {
      "r": 65537,
      "p": [
        {
          "n": "bitStream",
          "p": 226143
        }
      ],
      "n": "WriteToBitStream",
      "d": 619359,
      "h": 30065390431,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(30065390431)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590553951),
    {
      "p": [
        {
          "n": "eci",
          "p": 1078111
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 619359,
      "h": 8590553951,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590553951)
  ],
  "h": 619359
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$wZnq.NCQ.DataSegment; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegmentEci`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegmentEci`; }
        });
        //--TRIMMABLE-BOUNDARY-END(619359)
        
        

        //--TRIMMABLE-BOUNDARY-START(488287)
        $asm.$cls(`$wZnq.NCQ.DataSegmentAlphanumeric`, ($self) => class DataSegmentAlphanumeric extends $.$wZnq.NCQ.DataSegment
        {
            //--TRIMMABLE-BOUNDARY-START(8590422879)
            $ctor$2(/*ArraySegment<byte>*/ bytes)
            {
                super.$ctor$1(2/*DataSegmentMode.Alphanumeric*/, $.$wZnq.NCQ.DataSegmentAlphanumeric.GetAlphanumericBitLength(bytes.Count));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590422879);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ;
                    this.DataBytes = bytes;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590422879)
            
            //--TRIMMABLE-BOUNDARY-START(34360226655)
            static /*bool */ IsAlphanumeric(/*byte*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360226655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (b >= /*A*/ 65 && b <= /*Z*/ 90) || (b >= /*-*/ 45 && b <= /*:*/ 58) || b === /* */ 32 || b === /*$*/ 36 || b === /*%*/ 37 || b === /***/ 42 || b === /*+*/ 43;
            }
            //--TRIMMABLE-BOUNDARY-END(34360226655)
            
            //--TRIMMABLE-BOUNDARY-START(25770292063)
            static /*int */ GetAlphanumericBitLength(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770292063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.trunc((((((length * 11) | 0) + 1) | 0)) / 2);
            }
            //--TRIMMABLE-BOUNDARY-END(25770292063)
            
            //--TRIMMABLE-BOUNDARY-START(30065259359)
            static /*int */ GetAlphanumericByteCount(/*int*/ bitLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065259359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.trunc(((bitLength * 2) | 0) / 11);
            }
            //--TRIMMABLE-BOUNDARY-END(30065259359)
            
            //--TRIMMABLE-BOUNDARY-START(38655193951)
            /*void */ WriteToBitStream(/*BitStream*/ bitStream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655193951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
                for(/*var*/ let i = 0; ((i + 1) | 0) < this.DataBytes.Count; i += 2)
                {
                    /*var*/ let letter1Byte = $.$$.System.Array.$ReadT1.call(this.DataBytes.Array, ((this.DataBytes.Offset + i) | 0));
                    /*var*/ let letter2Byte = $.$$.System.Array.$ReadT1.call(this.DataBytes.Array, ((((this.DataBytes.Offset + i) | 0) + 1) | 0));
                    $.$$.SD.Debug.Assert$4($.$wZnq.NCQ.DataSegmentAlphanumeric.IsAlphanumeric(letter1Byte), "IsAlphanumeric(letter1Byte)");
                    $.$$.SD.Debug.Assert$4($.$wZnq.NCQ.DataSegmentAlphanumeric.IsAlphanumeric(letter2Byte), "IsAlphanumeric(letter2Byte)");
                    bitStream.AppendBits((((($.$wZnq.NCQ.DataSegmentAlphanumeric.EncodeAlphanumericByte(letter1Byte) * 45) >>> 0) + $.$wZnq.NCQ.DataSegmentAlphanumeric.EncodeAlphanumericByte(letter2Byte)) >>> 0), 11);
                }
                if (this.DataBytes.Count % 2 === 1)
                {
                    /*var*/ let letterByte = $.$$.System.Array.$ReadT1.call(this.DataBytes.Array, ((((this.DataBytes.Offset + this.DataBytes.Count) | 0) - 1) | 0));
                    $.$$.SD.Debug.Assert$4($.$wZnq.NCQ.DataSegmentAlphanumeric.IsAlphanumeric(letterByte), "IsAlphanumeric(letterByte)");
                    bitStream.AppendBits($.$wZnq.NCQ.DataSegmentAlphanumeric.EncodeAlphanumericByte(letterByte), 6);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655193951)
            
            //--TRIMMABLE-BOUNDARY-START(21475324767)
            static /*uint */ EncodeAlphanumericByte(/*byte*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475324767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (b < 32 || b > 90)
                {
                    return 255;
                }
                return $.$$.System.Array.$ReadT1.call($.$wZnq.NCQ.DataSegmentAlphanumeric.AlphanumericEncoding, ((b - 32) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(21475324767)
            
            //--TRIMMABLE-BOUNDARY-START(17180357471)
            static /*byte */ DecodeAlphanumericByte(/*uint*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180357471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = $.$$.S.Array.IndexOf$4($.$$.S.Byte, $.$wZnq.NCQ.DataSegmentAlphanumeric.AlphanumericEncoding, ((value & 0xFF) >>> 0), 0);
                return $.$cast((((index + 32) | 0)), $.$$.S.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(17180357471)
            
            //--TRIMMABLE-BOUNDARY-START(12885390175)
            /*byte[]*/ static AlphanumericEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(12885390175)
            
            //--TRIMMABLE-BOUNDARY-START(4295455583)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295455583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885390175)
                    this.AlphanumericEncoding = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [36, 255, 255, 255, 37, 38, 255, 255, 255, 255, 39, 40, 255, 41, 42, 43, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 44, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12885390175)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295455583)
            
            static $h = 488287;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 422751,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360226655),
    {
      "r": 262145,
      "p": [
        {
          "n": "b",
          "p": 393217
        }
      ],
      "n": "IsAlphanumeric",
      "d": 488287,
      "h": 34360226655,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360226655),
//--TRIMMABLE-BOUNDARY-START(25770292063),
    {
      "r": 655361,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "GetAlphanumericBitLength",
      "d": 488287,
      "h": 25770292063,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770292063),
//--TRIMMABLE-BOUNDARY-START(30065259359),
    {
      "r": 655361,
      "p": [
        {
          "n": "bitLength",
          "p": 655361
        }
      ],
      "n": "GetAlphanumericByteCount",
      "d": 488287,
      "h": 30065259359,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065259359),
//--TRIMMABLE-BOUNDARY-START(38655193951),
    {
      "r": 65537,
      "p": [
        {
          "n": "bitStream",
          "p": 226143
        }
      ],
      "n": "WriteToBitStream",
      "d": 488287,
      "h": 38655193951,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(38655193951),
//--TRIMMABLE-BOUNDARY-START(21475324767),
    {
      "r": 720897,
      "p": [
        {
          "n": "b",
          "p": 393217
        }
      ],
      "n": "EncodeAlphanumericByte",
      "d": 488287,
      "h": 21475324767,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475324767),
//--TRIMMABLE-BOUNDARY-START(17180357471),
    {
      "r": 393217,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "DecodeAlphanumericByte",
      "d": 488287,
      "h": 17180357471,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180357471)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885390175),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "AlphanumericEncoding",
      "d": 488287,
      "h": 12885390175,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885390175)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590422879),
    {
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 488287,
      "h": 8590422879,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590422879)
  ],
  "h": 488287
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$wZnq.NCQ.DataSegment; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegmentAlphanumeric`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegmentAlphanumeric`; }
        });
        //--TRIMMABLE-BOUNDARY-END(488287)
        
        

        //--TRIMMABLE-BOUNDARY-START(947039)
        $asm.$cls(`$wZnq.NCQ.DataSegmentStructuredAppend`, ($self) => class DataSegmentStructuredAppend extends $.$wZnq.NCQ.DataSegment
        {
            //--TRIMMABLE-BOUNDARY-START(47245587295)
            /*int*/ static StructuredAppendBitLength = 16;
            //--TRIMMABLE-BOUNDARY-END(47245587295)
            
            //--TRIMMABLE-BOUNDARY-START(55835521887)
            /*int*/ StructuredAppendPosition = 0;
            //--TRIMMABLE-BOUNDARY-END(55835521887)
            
            //--TRIMMABLE-BOUNDARY-START(60130489183)
            /*int*/ StructuredAppendTotal = 0;
            //--TRIMMABLE-BOUNDARY-END(60130489183)
            
            //--TRIMMABLE-BOUNDARY-START(51540554591)
            /*byte*/ StructuredAppendParity = 0;
            //--TRIMMABLE-BOUNDARY-END(51540554591)
            
            //--TRIMMABLE-BOUNDARY-START(17180816223)
            $ctor$2(/*int*/ position, /*int*/ total, /*byte*/ parity)
            {
                super.$ctor$1(6/*DataSegmentMode.StructuredAppend*/, 16/*StructuredAppendBitLength*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180816223);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (total < 1 || total > 16)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("total", $.$$.S.Int32.ToString.call(total), "total must be between 1 and 16");
                    }
                    if (position < 1 || position > 16)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("position", $.$$.S.Int32.ToString.call(position), "position must be between 1 and 16");
                    }
                    if (position > total)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("position", $.$$.S.Int32.ToString.call(position), "position must be less or equal to total");
                    }
                    this.StructuredAppendPosition = position;
                    this.StructuredAppendTotal = total;
                    this.StructuredAppendParity = parity;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180816223)
            
            //--TRIMMABLE-BOUNDARY-START(64425456479)
            /*void */ WriteToBitStream(/*BitStream*/ bitStream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425456479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bitStream.AppendBits((((this.StructuredAppendPosition >>> 0) - 1) >>> 0), 4);
                bitStream.AppendBits((((this.StructuredAppendTotal >>> 0) - 1) >>> 0), 4);
                bitStream.AppendBits(this.StructuredAppendParity, 8);
            }
            //--TRIMMABLE-BOUNDARY-END(64425456479)
            
            static $h = 947039;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 422751,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835521887),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360685407,
        "f": 50364417
      },
      "n": "StructuredAppendPosition",
      "d": 947039,
      "h": 55835521887,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835521887),
//--TRIMMABLE-BOUNDARY-START(60130489183),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950619999,
        "f": 50364417
      },
      "n": "StructuredAppendTotal",
      "d": 947039,
      "h": 60130489183,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130489183),
//--TRIMMABLE-BOUNDARY-START(51540554591),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770750815,
        "f": 50364417
      },
      "n": "StructuredAppendParity",
      "d": 947039,
      "h": 51540554591,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540554591)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425456479),
    {
      "r": 65537,
      "p": [
        {
          "n": "bitStream",
          "p": 226143
        }
      ],
      "n": "WriteToBitStream",
      "d": 947039,
      "h": 64425456479,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(64425456479)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245587295),
    {
      "t": 655361,
      "n": "StructuredAppendBitLength",
      "d": 947039,
      "h": 47245587295,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245587295)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180816223),
    {
      "p": [
        {
          "n": "position",
          "p": 655361
        },
        {
          "n": "total",
          "p": 655361
        },
        {
          "n": "parity",
          "p": 393217
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 947039,
      "h": 17180816223,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180816223)
  ],
  "h": 947039
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$wZnq.NCQ.DataSegment; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegmentStructuredAppend`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegmentStructuredAppend`; }
        });
        //--TRIMMABLE-BOUNDARY-END(947039)
        
        

        //--TRIMMABLE-BOUNDARY-START(2454367)
        $asm.$str(`$wZnq.NCQ.ScoringMatrix`, ($self) => class ScoringMatrix extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17182323551)
            $ctor$3(/*BitMatrix*/ rows, /*BitMatrix*/ columns)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182323551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Rows = rows;
                    this.Columns = columns;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182323551)
            
            //--TRIMMABLE-BOUNDARY-START(30067225439)
            static /*ScoringMatrix */ From(/*BitMatrix*/ modules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067225439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let columns = modules.Copy();
                columns.Transpose();
                return new $.$wZnq.NCQ.ScoringMatrix().$ctor$3(modules, columns);
            }
            //--TRIMMABLE-BOUNDARY-END(30067225439)
            
            //--TRIMMABLE-BOUNDARY-START(60131996511)
            /*BitMatrix*/ Rows;
            //--TRIMMABLE-BOUNDARY-END(60131996511)
            
            //--TRIMMABLE-BOUNDARY-START(21477290847)
            /*BitMatrix*/ Columns;
            //--TRIMMABLE-BOUNDARY-END(21477290847)
            
            //--TRIMMABLE-BOUNDARY-START(68721931103)
            /*int */ get Size()
            {
                return this.Rows.Size;
            }
            //--TRIMMABLE-BOUNDARY-END(68721931103)
            
            //--TRIMMABLE-BOUNDARY-START(73016898399)
            /*void */ Xor(/*MaskPair*/ mask)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016898399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Rows.Xor(mask.Rows);
                this.Columns.Xor(mask.Columns);
            }
            //--TRIMMABLE-BOUNDARY-END(73016898399)
            
            //--TRIMMABLE-BOUNDARY-START(64426963807)
            /*void */ SetFormatBit(/*int*/ x, /*int*/ y, /*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426963807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Rows.Set(x, y, value);
                this.Columns.Set(y, x, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64426963807)
            
            //--TRIMMABLE-BOUNDARY-START(25772258143)
            /*BitMatrix */ Finish(/*MaskPair*/ mask)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772258143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Rows.Xor(mask.Rows);
                return this.Rows;
            }
            //--TRIMMABLE-BOUNDARY-END(25772258143)
            
            //--TRIMMABLE-BOUNDARY-START(12887356255)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887356255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887356255)
            
            //--TRIMMABLE-BOUNDARY-START(12887356255)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887356255)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Rows = this.Rows.Clone();
                copy.Columns = this.Columns.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60131996511)
                this.Rows = $.$default($.$wZnq.NCQ.BitMatrix);
                //--TRIMMABLE-BOUNDARY-END(60131996511)
                
                //--TRIMMABLE-BOUNDARY-START(21477290847)
                this.Columns = $.$default($.$wZnq.NCQ.BitMatrix);
                //--TRIMMABLE-BOUNDARY-END(21477290847)
                
            }
            static $h = 2454367;
            static $z = 32;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131996511),
    {
      "p": 160607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247094623,
        "f": 50331656
      },
      "n": "Rows",
      "d": 2454367,
      "h": 60131996511,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60131996511),
//--TRIMMABLE-BOUNDARY-START(21477290847),
    {
      "p": 160607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657160031,
        "f": 50331656
      },
      "n": "Columns",
      "d": 2454367,
      "h": 21477290847,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21477290847),
//--TRIMMABLE-BOUNDARY-START(68721931103),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837029215,
        "f": 50331656
      },
      "n": "Size",
      "d": 2454367,
      "h": 68721931103,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68721931103)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067225439),
    {
      "r": 2454367,
      "p": [
        {
          "n": "modules",
          "p": 160607
        }
      ],
      "n": "From",
      "d": 2454367,
      "h": 30067225439,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30067225439),
//--TRIMMABLE-BOUNDARY-START(73016898399),
    {
      "r": 65537,
      "p": [
        {
          "n": "mask",
          "p": 1405791
        }
      ],
      "n": "Xor",
      "d": 2454367,
      "h": 73016898399,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73016898399),
//--TRIMMABLE-BOUNDARY-START(64426963807),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "SetFormatBit",
      "d": 2454367,
      "h": 64426963807,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64426963807),
//--TRIMMABLE-BOUNDARY-START(25772258143),
    {
      "r": 160607,
      "p": [
        {
          "n": "mask",
          "p": 1405791
        }
      ],
      "n": "Finish",
      "d": 2454367,
      "h": 25772258143,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25772258143)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182323551),
    {
      "p": [
        {
          "n": "rows",
          "p": 160607
        },
        {
          "n": "columns",
          "p": 160607
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2454367,
      "h": 17182323551,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17182323551),
//--TRIMMABLE-BOUNDARY-START(12887356255),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2454367,
      "h": 12887356255,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887356255)
  ],
  "h": 2454367
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.ScoringMatrix`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}ScoringMatrix`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2454367)
        
        

        //--TRIMMABLE-BOUNDARY-START(684895)
        $asm.$cls(`$wZnq.NCQ.DataSegmentKanji`, ($self) => class DataSegmentKanji extends $.$wZnq.NCQ.DataSegment
        {
            //--TRIMMABLE-BOUNDARY-START(4295652191)
            $ctor$2(/*ArraySegment<byte>*/ bytes)
            {
                super.$ctor$1(3/*DataSegmentMode.Kanji*/, $.$wZnq.NCQ.DataSegmentKanji.GetKanjiBitLength(bytes.Count));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295652191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ;
                    ;
                    this.DataBytes = bytes;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295652191)
            
            //--TRIMMABLE-BOUNDARY-START(34360423263)
            static /*bool */ IsShiftJisDoubleByte(/*byte*/ b1, /*byte*/ b2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360423263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (b1 < 129 || (b1 > 159 && b1 < 224) || b1 > 235)
                {
                    return false;
                }
                return b2 >= 64 && b2 <= 252;
            }
            //--TRIMMABLE-BOUNDARY-END(34360423263)
            
            //--TRIMMABLE-BOUNDARY-START(8590619487)
            /*int */ get CharacterCount()
            {
                return $.trunc(this.DataBytes.Count / 2);
            }
            //--TRIMMABLE-BOUNDARY-END(8590619487)
            
            //--TRIMMABLE-BOUNDARY-START(25770488671)
            static /*int */ GetKanjiBitLength(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770488671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.trunc(((length * 13) | 0) / 2);
            }
            //--TRIMMABLE-BOUNDARY-END(25770488671)
            
            //--TRIMMABLE-BOUNDARY-START(30065455967)
            static /*int */ GetKanjiByteCount(/*int*/ bitLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065455967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (($.trunc(bitLength / 13) * 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(30065455967)
            
            //--TRIMMABLE-BOUNDARY-START(38655390559)
            /*void */ WriteToBitStream(/*BitStream*/ bitStream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655390559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bytes = this.DataBytes;
                ;
                for(/*var*/ let i = 0; i < bytes.Count; i += 2)
                {
                    /*var*/ let kanjiByte1 = $.$$.System.Array.$ReadT1.call(bytes.Array, ((bytes.Offset + i) | 0));
                    /*var*/ let kanjiByte2 = $.$$.System.Array.$ReadT1.call(bytes.Array, ((((bytes.Offset + i) | 0) + 1) | 0));
                    $.$$.SD.Debug.Assert$4($.$wZnq.NCQ.DataSegmentKanji.IsShiftJisDoubleByte(kanjiByte1, kanjiByte2), "IsShiftJisDoubleByte(kanjiByte1, kanjiByte2)");
                    bitStream.AppendBits($.$wZnq.NCQ.DataSegmentKanji.EncodeShiftJisCode(((((kanjiByte1 * 256) | 0) + kanjiByte2) | 0)), 13);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655390559)
            
            //--TRIMMABLE-BOUNDARY-START(12885586783)
            static /*uint */ EncodeShiftJisCode(/*int*/ shiftJisCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885586783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let code;
                if (shiftJisCode >= 33088 && shiftJisCode <= 40956)
                {
                    code = ((shiftJisCode - 33088) | 0);
                }
                else if (shiftJisCode >= 57408 && shiftJisCode <= 60351)
                {
                    code = ((shiftJisCode - 49472) | 0);
                }
                else 
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("shiftJisCode", $.$box(shiftJisCode, $.$$.S.Int32), "Invalid Shift JIS code: only two-byte codes can be encoded in Kanji mode.");
                }
                return (((((((code >> 8) * 192) | 0) + (code & 255)) | 0)) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(12885586783)
            
            static $h = 684895;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 422751,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590619487),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475521375,
        "f": 50364424
      },
      "n": "CharacterCount",
      "d": 684895,
      "h": 8590619487,
      "f": 2129928
    },
//--TRIMMABLE-BOUNDARY-END(8590619487)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360423263),
    {
      "r": 262145,
      "p": [
        {
          "n": "b1",
          "p": 393217
        },
        {
          "n": "b2",
          "p": 393217
        }
      ],
      "n": "IsShiftJisDoubleByte",
      "d": 684895,
      "h": 34360423263,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360423263),
//--TRIMMABLE-BOUNDARY-START(25770488671),
    {
      "r": 655361,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "GetKanjiBitLength",
      "d": 684895,
      "h": 25770488671,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770488671),
//--TRIMMABLE-BOUNDARY-START(30065455967),
    {
      "r": 655361,
      "p": [
        {
          "n": "bitLength",
          "p": 655361
        }
      ],
      "n": "GetKanjiByteCount",
      "d": 684895,
      "h": 30065455967,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065455967),
//--TRIMMABLE-BOUNDARY-START(38655390559),
    {
      "r": 65537,
      "p": [
        {
          "n": "bitStream",
          "p": 226143
        }
      ],
      "n": "WriteToBitStream",
      "d": 684895,
      "h": 38655390559,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(38655390559),
//--TRIMMABLE-BOUNDARY-START(12885586783),
    {
      "r": 720897,
      "p": [
        {
          "n": "shiftJisCode",
          "p": 655361
        }
      ],
      "n": "EncodeShiftJisCode",
      "d": 684895,
      "h": 12885586783,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885586783)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295652191),
    {
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 684895,
      "h": 4295652191,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295652191)
  ],
  "h": 684895
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$wZnq.NCQ.DataSegment; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegmentKanji`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegmentKanji`; }
        });
        //--TRIMMABLE-BOUNDARY-END(684895)
        
        

        //--TRIMMABLE-BOUNDARY-START(160607)
        $asm.$str(`$wZnq.NCQ.BitMatrix`, ($self) => class BitMatrix extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(124554212191)
            /*int*/ static MaxUsedWordsPerRow = 3;
            //--TRIMMABLE-BOUNDARY-END(124554212191)
            
            //--TRIMMABLE-BOUNDARY-START(128849179487)
            /*int*/ static MaxWordsPerRow = 4;
            //--TRIMMABLE-BOUNDARY-END(128849179487)
            
            //--TRIMMABLE-BOUNDARY-START(120259244895)
            /*int*/ static MaxSize = 192;
            //--TRIMMABLE-BOUNDARY-END(120259244895)
            
            //--TRIMMABLE-BOUNDARY-START(163208917855)
            /*int*/ Size = 0;
            //--TRIMMABLE-BOUNDARY-END(163208917855)
            
            //--TRIMMABLE-BOUNDARY-START(150324015967)
            /*int*/ RowShift = 0;
            //--TRIMMABLE-BOUNDARY-END(150324015967)
            
            //--TRIMMABLE-BOUNDARY-START(180388787039)
            /*int*/ UsedWordsPerRow = 0;
            //--TRIMMABLE-BOUNDARY-END(180388787039)
            
            //--TRIMMABLE-BOUNDARY-START(184683754335)
            /*int */ get WordsPerRow()
            {
                return 1 << this.RowShift;
            }
            //--TRIMMABLE-BOUNDARY-END(184683754335)
            
            //--TRIMMABLE-BOUNDARY-START(25769964383)
            $ctor$3(/*int*/ size)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769964383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (size < 0 || size > 192/*MaxSize*/)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13(`The size must be between 0 and ${192/*MaxSize*/}`, "size");
                    }
                    /*var*/ let shift = size <= 64 ? 0 : (size <= 128 ? 1 : 2);
                    this.RowShift = shift;
                    this.UsedWordsPerRow = size <= 64 ? 1 : (size <= 128 ? 2 : 3);
                    this.Size = size;
                    this.Raw = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.UInt64), null, [size << shift], null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769964383)
            
            //--TRIMMABLE-BOUNDARY-START(30064931679)
            $ctor$4(/*ulong[]*/ bits, /*int*/ size, /*int*/ rowShift, /*int*/ usedWordsPerRow)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064931679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Raw = bits;
                    this.Size = size;
                    this.RowShift = rowShift;
                    this.UsedWordsPerRow = usedWordsPerRow;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064931679)
            
            //--TRIMMABLE-BOUNDARY-START(111669310303)
            /*bool */ Get(/*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669310303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bitMask = BigInt.asUintN(64, 1n << BigInt((x & 63)));
                /*var*/ let index = (((y << this.RowShift) + (x >> 6)) | 0);
                return ($.$$.System.Array.$ReadT1.call(this.Raw, index) & bitMask) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(111669310303)
            
            //--TRIMMABLE-BOUNDARY-START(158913950559)
            /*void */ Set(/*int*/ x, /*int*/ y, /*bool*/ bit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913950559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bitMask = BigInt.asUintN(64, 1n << BigInt((x & 63)));
                /*var*/ let index = (((y << this.RowShift) + (x >> 6)) | 0);
                if (bit)
                {
                    $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(this.Raw, index) | bitMask, index);
                }
                else 
                {
                    $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(this.Raw, index) & (~bitMask & 0xFFFFFFFFFFFFFFFFn), index);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158913950559)
            
            //--TRIMMABLE-BOUNDARY-START(34359898975)
            /*ushort */ Address(/*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359898975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(((((((y << this.RowShift) + (x >> 6)) | 0)) << 6) | (x & 63)), $.$$.S.UInt16);
            }
            //--TRIMMABLE-BOUNDARY-END(34359898975)
            
            //--TRIMMABLE-BOUNDARY-START(133144146783)
            /*void */ OrBit(/*ushort*/ address, /*int*/ bit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144146783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(this.Raw, address >>> 6) | BigInt.asUintN(64, $.$cast(bit, $.$$.S.UInt64) << BigInt(address)), address >>> 6);
            }
            //--TRIMMABLE-BOUNDARY-END(133144146783)
            
            //--TRIMMABLE-BOUNDARY-START(60129702751)
            /*void */ FillRect(/*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129702751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (width <= 0 || height <= 0)
                {
                    return;
                }
                /*var*/ let startWord = x >> 6;
                /*var*/ let endX = ((((x + width) | 0) - 1) | 0);
                /*var*/ let endWord = endX >> 6;
                /*var*/ let startBit = x & 63;
                /*var*/ let endBit = endX & 63;
                /*var*/ let startMask = BigInt.asUintN(64, 18446744073709551615n << BigInt(startBit));
                /*var*/ let endMask = 18446744073709551615n >> BigInt((((63 - endBit) | 0)));
                /*var*/ let wordsPerRow = this.WordsPerRow;
                /*var*/ let rowBase = y << this.RowShift;
                /*var*/ let rowEnd = ((rowBase + ((wordsPerRow * height) | 0)) | 0);
                if (startWord === endWord)
                {
                    /*var*/ let mask = startMask & endMask;
                    for(/*var*/ let idx = ((rowBase + startWord) | 0); idx < rowEnd; idx += wordsPerRow)
                    {
                        $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(this.Raw, idx) | mask, idx);
                    }
                }
                else 
                {
                    for(/*var*/ let row = rowBase; row < rowEnd; row += wordsPerRow)
                    {
                        $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(this.Raw, ((row + startWord) | 0)) | startMask, ((row + startWord) | 0));
                        for(/*var*/ let w = ((startWord + 1) | 0); w < endWord; w += 1)
                        {
                            $.$$.System.Array.$WriteT1.call(this.Raw, 18446744073709551615n, ((row + w) | 0));
                        }
                        $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(this.Raw, ((row + endWord) | 0)) | endMask, ((row + endWord) | 0));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129702751)
            
            //--TRIMMABLE-BOUNDARY-START(115964277599)
            /*void */ Invert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964277599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = this.Size;
                /*var*/ let lastBit = ((size - 1) | 0);
                /*var*/ let lastWord = lastBit >> 6;
                /*var*/ let lastMask = 18446744073709551615n >> BigInt((((63 - (lastBit & 63)) | 0)));
                /*var*/ let wordsPerRow = this.WordsPerRow;
                for(/*var*/ let y = 0; y < size; y += 1)
                {
                    /*var*/ let rowBase = y << this.RowShift;
                    for(/*var*/ let w = 0; w < lastWord; w += 1)
                    {
                        $.$$.System.Array.$WriteT1.call(this.Raw, (~$.$$.System.Array.$ReadT1.call(this.Raw, ((rowBase + w) | 0)) & 0xFFFFFFFFFFFFFFFFn), ((rowBase + w) | 0));
                    }
                    $.$$.System.Array.$WriteT1.call(this.Raw, (~$.$$.System.Array.$ReadT1.call(this.Raw, ((rowBase + lastWord) | 0)) & 0xFFFFFFFFFFFFFFFFn) & lastMask, ((rowBase + lastWord) | 0));
                    for(/*var*/ let w = ((lastWord + 1) | 0); w < wordsPerRow; w += 1)
                    {
                        $.$$.System.Array.$WriteT1.call(this.Raw, 0n, ((rowBase + w) | 0));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964277599)
            
            //--TRIMMABLE-BOUNDARY-START(171798852447)
            /*void */ Transpose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798852447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let size = this.Size;
                if (size <= 1)
                {
                    return;
                }
                /*var*/ let nBlocks = (((size + 63) | 0)) >> 6;
                /*var*/ let blockA = $.$wZnq.NCQ.BitMatrix.BlockA ?? ($.$wZnq.NCQ.BitMatrix.BlockA = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.UInt64), null, [64], null));
                /*var*/ let blockB = $.$wZnq.NCQ.BitMatrix.BlockB ?? ($.$wZnq.NCQ.BitMatrix.BlockB = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.UInt64), null, [64], null));
                for(/*var*/ let br = 0; br < nBlocks; br += 1)
                {
                    this.GatherBlock(blockA, br, br);
                    $.$wZnq.NCQ.BitMatrix.Transpose64X64(blockA);
                    this.ScatterBlock(blockA, br, br);
                    for(/*var*/ let bc = ((br + 1) | 0); bc < nBlocks; bc += 1)
                    {
                        this.GatherBlock(blockA, br, bc);
                        this.GatherBlock(blockB, bc, br);
                        $.$wZnq.NCQ.BitMatrix.Transpose64X64(blockA);
                        $.$wZnq.NCQ.BitMatrix.Transpose64X64(blockB);
                        this.ScatterBlock(blockA, bc, br);
                        this.ScatterBlock(blockB, br, bc);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171798852447)
            
            //--TRIMMABLE-BOUNDARY-START(42949833567)
            /*ulong[]*/ static BlockA = null;
            //--TRIMMABLE-BOUNDARY-END(42949833567)
            
            //--TRIMMABLE-BOUNDARY-START(47244800863)
            /*ulong[]*/ static BlockB = null;
            //--TRIMMABLE-BOUNDARY-END(47244800863)
            
            //--TRIMMABLE-BOUNDARY-START(64424670047)
            /*void */ GatherBlock(/*ulong[]*/ dest, /*int*/ br, /*int*/ bc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424670047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rowStart = br << 6;
                /*var*/ let rows = $.$$.S.Math.Min$4(((this.Size - rowStart) | 0), 64);
                for(/*var*/ let i = 0; i < rows; i += 1)
                {
                    $.$$.System.Array.$WriteT1.call(dest, $.$$.System.Array.$ReadT1.call(this.Raw, ((((((rowStart + i) | 0)) << this.RowShift) + bc) | 0)), i);
                }
                for(/*var*/ let i = rows; i < 64; i += 1)
                {
                    $.$$.System.Array.$WriteT1.call(dest, 0n, i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424670047)
            
            //--TRIMMABLE-BOUNDARY-START(154618983263)
            /*void */ ScatterBlock(/*ulong[]*/ src, /*int*/ br, /*int*/ bc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154618983263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rowStart = br << 6;
                /*var*/ let rows = $.$$.S.Math.Min$4(((this.Size - rowStart) | 0), 64);
                for(/*var*/ let i = 0; i < rows; i += 1)
                {
                    $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(src, i), ((((((rowStart + i) | 0)) << this.RowShift) + bc) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154618983263)
            
            //--TRIMMABLE-BOUNDARY-START(176093819743)
            static /*void */ Transpose64X64(/*ulong[]*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093819743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wZnq.NCQ.BitMatrix.DeltaSwap(a, 32, 4294967295n);
                $.$wZnq.NCQ.BitMatrix.DeltaSwap(a, 16, 281470681808895n);
                $.$wZnq.NCQ.BitMatrix.DeltaSwap(a, 8, 71777214294589695n);
                $.$wZnq.NCQ.BitMatrix.DeltaSwap(a, 4, 1085102592571150095n);
                $.$wZnq.NCQ.BitMatrix.DeltaSwap(a, 2, 3689348814741910323n);
                $.$wZnq.NCQ.BitMatrix.DeltaSwap(a, 1, 6148914691236517205n);
            }
            //--TRIMMABLE-BOUNDARY-END(176093819743)
            
            //--TRIMMABLE-BOUNDARY-START(55834735455)
            static /*void */ DeltaSwap(/*ulong[]*/ a, /*int*/ j, /*ulong*/ m)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834735455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let k = 0; k < 64; k = (((((k + j) | 0) + 1) | 0)) & ~j)
                {
                    /*var*/ let t = (($.$$.System.Array.$ReadT1.call(a, k) >> BigInt(j)) ^ $.$$.System.Array.$ReadT1.call(a, ((k + j) | 0))) & m;
                    $.$$.System.Array.$WriteT1.call(a, $.$$.System.Array.$ReadT1.call(a, ((k + j) | 0)) ^ t, ((k + j) | 0));
                    $.$$.System.Array.$WriteT1.call(a, $.$$.System.Array.$ReadT1.call(a, k) ^ BigInt.asUintN(64, t << BigInt(j)), k);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834735455)
            
            //--TRIMMABLE-BOUNDARY-START(38654866271)
            /*void */ And(/*BitMatrix*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654866271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (other.Size !== this.Size)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("The matrices must have the same size", "other");
                }
                for(/*var*/ let i = 0; i < this.Raw.length; i += 1)
                {
                    $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(this.Raw, i) & $.$$.System.Array.$ReadT1.call(other.Raw, i), i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654866271)
            
            //--TRIMMABLE-BOUNDARY-START(188978721631)
            /*void */ Xor(/*BitMatrix*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978721631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (other.Size !== this.Size)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("The matrices must have the same size", "other");
                }
                for(/*var*/ let i = 0; i < this.Raw.length; i += 1)
                {
                    $.$$.System.Array.$WriteT1.call(this.Raw, $.$$.System.Array.$ReadT1.call(this.Raw, i) ^ $.$$.System.Array.$ReadT1.call(other.Raw, i), i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188978721631)
            
            //--TRIMMABLE-BOUNDARY-START(51539768159)
            /*BitMatrix */ Copy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539768159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$wZnq.NCQ.BitMatrix().$ctor$4($.$cast(this.Raw.Clone(), $.$typeArray($.$$.S.UInt64)), this.Size, this.RowShift, this.UsedWordsPerRow);
            }
            //--TRIMMABLE-BOUNDARY-END(51539768159)
            
            //--TRIMMABLE-BOUNDARY-START(146029048671)
            /*ulong[]*/ Raw = null;
            //--TRIMMABLE-BOUNDARY-END(146029048671)
            
            //--TRIMMABLE-BOUNDARY-START(167503885151)
            /*bool[,] */ ToBoolArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503885151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Boolean), null, [this.Size, this.Size], null);
                for(/*var*/ let y = 0; y < this.Size; y += 1)
                {
                    for(/*var*/ let x = 0; x < this.Size; x += 1)
                    {
                        array.$WriteT(this.Get(x, y), [y, x]);
                    }
                }
                return array;
            }
            //--TRIMMABLE-BOUNDARY-END(167503885151)
            
            //--TRIMMABLE-BOUNDARY-START(137439114079)
            /*int */ PopCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439114079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sum = 0;
                let $i1 = 0;
                let $arr1 = this.Raw;
                while ($i1 < $arr1.length)
                {
                    let v = $arr1[$i1++];
                    sum += $.$wZnq.NCQ.BitMatrix.PopCount$1(v);
                }
                return sum;
            }
            //--TRIMMABLE-BOUNDARY-END(137439114079)
            
            //--TRIMMABLE-BOUNDARY-START(141734081375)
            static /*int */ PopCount$1(/*ulong*/ i)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734081375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (System.Runtime.Intrinsics.X86.Popcnt.X64.IsSupported) { ... }
                i = BigInt.asUintN(64, i - ((i >> 1n) & 0x5555555555555555n));
                i = BigInt.asUintN(64, (i & 0x3333333333333333n) + ((i >> 2n) & 0x3333333333333333n));
                return $.$cast((BigInt.asUintN(64, ((BigInt.asUintN(64, i + (i >> 4n))) & 0xF0F0F0F0F0F0F0Fn) * 0x101010101010101n) >> 56n), $.$$.S.Int32);
            }
            //--TRIMMABLE-BOUNDARY-END(141734081375)
            
            //--TRIMMABLE-BOUNDARY-START(21474997087)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474997087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474997087)
            
            //--TRIMMABLE-BOUNDARY-START(21474997087)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21474997087)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Size = this.Size;
                copy.RowShift = this.RowShift;
                copy.UsedWordsPerRow = this.UsedWordsPerRow;
                copy.Raw = this.Raw;
                return copy;
            }
            static $h = 160607;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(163208917855),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194473823,
        "f": 50331656
      },
      "n": "Size",
      "d": 160607,
      "h": 163208917855,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(163208917855),
//--TRIMMABLE-BOUNDARY-START(150324015967),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604539231,
        "f": 50331656
      },
      "n": "RowShift",
      "d": 160607,
      "h": 150324015967,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(150324015967),
//--TRIMMABLE-BOUNDARY-START(180388787039),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784408415,
        "f": 50331656
      },
      "n": "UsedWordsPerRow",
      "d": 160607,
      "h": 180388787039,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(180388787039),
//--TRIMMABLE-BOUNDARY-START(184683754335),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374343007,
        "f": 50331656
      },
      "n": "WordsPerRow",
      "d": 160607,
      "h": 184683754335,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(184683754335),
//--TRIMMABLE-BOUNDARY-START(146029048671),
    {
      "p": $.$typeArray($.$$.S.UInt64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014604639,
        "f": 50331656
      },
      "n": "Raw",
      "d": 160607,
      "h": 146029048671,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(146029048671)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669310303),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "Get",
      "d": 160607,
      "h": 111669310303,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(111669310303),
//--TRIMMABLE-BOUNDARY-START(158913950559),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        },
        {
          "n": "bit",
          "p": 262145
        }
      ],
      "n": "Set",
      "d": 160607,
      "h": 158913950559,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158913950559),
//--TRIMMABLE-BOUNDARY-START(34359898975),
    {
      "r": 589825,
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "Address",
      "d": 160607,
      "h": 34359898975,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34359898975),
//--TRIMMABLE-BOUNDARY-START(133144146783),
    {
      "r": 65537,
      "p": [
        {
          "n": "address",
          "p": 589825
        },
        {
          "n": "bit",
          "p": 655361
        }
      ],
      "n": "OrBit",
      "d": 160607,
      "h": 133144146783,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(133144146783),
//--TRIMMABLE-BOUNDARY-START(60129702751),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        },
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": "FillRect",
      "d": 160607,
      "h": 60129702751,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60129702751),
//--TRIMMABLE-BOUNDARY-START(115964277599),
    {
      "r": 65537,
      "n": "Invert",
      "d": 160607,
      "h": 115964277599,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115964277599),
//--TRIMMABLE-BOUNDARY-START(171798852447),
    {
      "r": 65537,
      "n": "Transpose",
      "d": 160607,
      "h": 171798852447,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(171798852447),
//--TRIMMABLE-BOUNDARY-START(64424670047),
    {
      "r": 65537,
      "p": [
        {
          "n": "dest",
          "p": $.$typeArray($.$$.S.UInt64).$h
        },
        {
          "n": "br",
          "p": 655361
        },
        {
          "n": "bc",
          "p": 655361
        }
      ],
      "n": "GatherBlock",
      "d": 160607,
      "h": 64424670047,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64424670047),
//--TRIMMABLE-BOUNDARY-START(154618983263),
    {
      "r": 65537,
      "p": [
        {
          "n": "src",
          "p": $.$typeArray($.$$.S.UInt64).$h
        },
        {
          "n": "br",
          "p": 655361
        },
        {
          "n": "bc",
          "p": 655361
        }
      ],
      "n": "ScatterBlock",
      "d": 160607,
      "h": 154618983263,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154618983263),
//--TRIMMABLE-BOUNDARY-START(176093819743),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": $.$typeArray($.$$.S.UInt64).$h
        }
      ],
      "n": "Transpose64X64",
      "d": 160607,
      "h": 176093819743,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176093819743),
//--TRIMMABLE-BOUNDARY-START(55834735455),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": $.$typeArray($.$$.S.UInt64).$h
        },
        {
          "n": "j",
          "p": 655361
        },
        {
          "n": "m",
          "p": 983041
        }
      ],
      "n": "DeltaSwap",
      "d": 160607,
      "h": 55834735455,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834735455),
//--TRIMMABLE-BOUNDARY-START(38654866271),
    {
      "r": 65537,
      "p": [
        {
          "n": "other",
          "p": 160607
        }
      ],
      "n": "And",
      "d": 160607,
      "h": 38654866271,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38654866271),
//--TRIMMABLE-BOUNDARY-START(188978721631),
    {
      "r": 65537,
      "p": [
        {
          "n": "other",
          "p": 160607
        }
      ],
      "n": "Xor",
      "d": 160607,
      "h": 188978721631,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(188978721631),
//--TRIMMABLE-BOUNDARY-START(51539768159),
    {
      "r": 160607,
      "n": "Copy",
      "d": 160607,
      "h": 51539768159,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51539768159),
//--TRIMMABLE-BOUNDARY-START(167503885151),
    {
      "r": $.$typeArray($.$$.S.Boolean).$h,
      "n": "ToBoolArray",
      "d": 160607,
      "h": 167503885151,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(167503885151),
//--TRIMMABLE-BOUNDARY-START(137439114079),
    {
      "r": 655361,
      "n": "PopCount",
      "d": 160607,
      "h": 137439114079,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(137439114079),
//--TRIMMABLE-BOUNDARY-START(141734081375),
    {
      "r": 655361,
      "p": [
        {
          "n": "i",
          "p": 983041
        }
      ],
      "n": "PopCount",
      "o": "@$1",
      "d": 160607,
      "h": 141734081375,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(141734081375)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124554212191),
    {
      "t": 655361,
      "n": "MaxUsedWordsPerRow",
      "d": 160607,
      "h": 124554212191,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554212191),
//--TRIMMABLE-BOUNDARY-START(128849179487),
    {
      "t": 655361,
      "n": "MaxWordsPerRow",
      "d": 160607,
      "h": 128849179487,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849179487),
//--TRIMMABLE-BOUNDARY-START(120259244895),
    {
      "t": 655361,
      "n": "MaxSize",
      "d": 160607,
      "h": 120259244895,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259244895),
//--TRIMMABLE-BOUNDARY-START(42949833567),
    {
      "t": $.$typeArray($.$$.S.UInt64).$h,
      "n": "BlockA",
      "d": 160607,
      "h": 42949833567,
      "f": 4194338,
      "a": [
        {
          "t": 185597953,
          "c": 4480565249
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949833567),
//--TRIMMABLE-BOUNDARY-START(47244800863),
    {
      "t": $.$typeArray($.$$.S.UInt64).$h,
      "n": "BlockB",
      "d": 160607,
      "h": 47244800863,
      "f": 4194338,
      "a": [
        {
          "t": 185597953,
          "c": 4480565249
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47244800863)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769964383),
    {
      "p": [
        {
          "n": "size",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 160607,
      "h": 25769964383,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25769964383),
//--TRIMMABLE-BOUNDARY-START(30064931679),
    {
      "p": [
        {
          "n": "bits",
          "p": $.$typeArray($.$$.S.UInt64).$h
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "rowShift",
          "p": 655361
        },
        {
          "n": "usedWordsPerRow",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 160607,
      "h": 30064931679,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30064931679),
//--TRIMMABLE-BOUNDARY-START(21474997087),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 160607,
      "h": 21474997087,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474997087)
  ],
  "h": 160607
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.BitMatrix`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}BitMatrix`; }
        });
        //--TRIMMABLE-BOUNDARY-END(160607)
        
        

        //--TRIMMABLE-BOUNDARY-START(2126687)
        $asm.$str(`$wZnq.NCQ.QrPoint`, ($self) => class QrPoint extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17181995871)
            $ctor$3(/*int*/ x, /*int*/ y)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181995871);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.X = x;
                    this.Y = y;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181995871)
            
            //--TRIMMABLE-BOUNDARY-START(68721603423)
            /*int*/ X = 0;
            //--TRIMMABLE-BOUNDARY-END(68721603423)
            
            //--TRIMMABLE-BOUNDARY-START(73016570719)
            /*int*/ Y = 0;
            //--TRIMMABLE-BOUNDARY-END(73016570719)
            
            //--TRIMMABLE-BOUNDARY-START(21476963167)
            /*void */ Deconstruct(/*out int*/ x, /*out int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476963167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                x.$v = this.X;
                y.$v = this.Y;
            }
            //--TRIMMABLE-BOUNDARY-END(21476963167)
            
            //--TRIMMABLE-BOUNDARY-START(30066897759)
            /*bool */ Equals$2(/*QrPoint*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066897759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.X === other.X && this.Y === other.Y;
            }
            //--TRIMMABLE-BOUNDARY-END(30066897759)
            
            //--TRIMMABLE-BOUNDARY-START(25771930463)
            /*bool */ Equals$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771930463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$wZnq.NCQ.QrPoint, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //--TRIMMABLE-BOUNDARY-END(25771930463)
            
            //--TRIMMABLE-BOUNDARY-START(51541734239)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541734239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    /*var*/ let hash = 17;
                    hash = ((((hash * 31) | 0) + this.X) | 0);
                    hash = ((((hash * 31) | 0) + this.Y) | 0);
                    return hash;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541734239)
            
            //--TRIMMABLE-BOUNDARY-START(64426636127)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426636127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `QrPoint(X=${this.X}, Y=${this.Y})`;
            }
            //--TRIMMABLE-BOUNDARY-END(64426636127)
            
            //--TRIMMABLE-BOUNDARY-START(55836701535)
            static /*bool */ op_Equality(/*QrPoint*/ left, /*QrPoint*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836701535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(55836701535)
            
            //--TRIMMABLE-BOUNDARY-START(60131668831)
            static /*bool */ op_Inequality(/*QrPoint*/ left, /*QrPoint*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131668831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(60131668831)
            
            //--TRIMMABLE-BOUNDARY-START(4385603585)
            //Generated interface implemetation for System.IEquatable<Net.Codecrete.QrCodeGenerator.QrPoint>.Equals(Net.Codecrete.QrCodeGenerator.QrPoint)
            S$IEquatable$Net$Codecrete$QrCodeGenerator$QrPoint$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385603585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385603585)
            
            //--TRIMMABLE-BOUNDARY-START(12887028575)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887028575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887028575)
            
            //--TRIMMABLE-BOUNDARY-START(12887028575)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887028575)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.X = this.X;
                copy.Y = this.Y;
                return copy;
            }
            static $h = 2126687;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721603423),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656832351,
        "f": 50331649
      },
      "n": "X",
      "d": 2126687,
      "h": 68721603423,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721603423),
//--TRIMMABLE-BOUNDARY-START(73016570719),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246766943,
        "f": 50331649
      },
      "n": "Y",
      "d": 2126687,
      "h": 73016570719,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016570719)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476963167),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 655361,
          "f": 2
        },
        {
          "n": "y",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": 2126687,
      "h": 21476963167,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476963167),
//--TRIMMABLE-BOUNDARY-START(30066897759),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 2126687
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2126687,
      "h": 30066897759,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066897759),
//--TRIMMABLE-BOUNDARY-START(25771930463),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2126687,
      "h": 25771930463,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771930463),
//--TRIMMABLE-BOUNDARY-START(51541734239),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2126687,
      "h": 51541734239,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541734239),
//--TRIMMABLE-BOUNDARY-START(64426636127),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2126687,
      "h": 64426636127,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426636127)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181995871),
    {
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2126687,
      "h": 17181995871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181995871),
//--TRIMMABLE-BOUNDARY-START(12887028575),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2126687,
      "h": 12887028575,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887028575)
  ],
  "i": [$.$$.S.IEquatable$$($.$wZnq.NCQ.QrPoint).$h
  ],
  "h": 2126687
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$wZnq.NCQ.QrPoint) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.QrPoint`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}QrPoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2126687)
        
        

        //--TRIMMABLE-BOUNDARY-START(2257759)
        $asm.$str(`$wZnq.NCQ.QrRectangle`, ($self) => class QrRectangle extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25772061535)
            $ctor$3(/*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772061535);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.X = x;
                    this.Y = y;
                    this.Width = width;
                    this.Height = height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772061535)
            
            //--TRIMMABLE-BOUNDARY-START(103081472863)
            /*int*/ X = 0;
            //--TRIMMABLE-BOUNDARY-END(103081472863)
            
            //--TRIMMABLE-BOUNDARY-START(107376440159)
            /*int*/ Y = 0;
            //--TRIMMABLE-BOUNDARY-END(107376440159)
            
            //--TRIMMABLE-BOUNDARY-START(98786505567)
            /*int*/ Width = 0;
            //--TRIMMABLE-BOUNDARY-END(98786505567)
            
            //--TRIMMABLE-BOUNDARY-START(81606636383)
            /*int*/ Height = 0;
            //--TRIMMABLE-BOUNDARY-END(81606636383)
            
            //--TRIMMABLE-BOUNDARY-START(30067028831)
            /*void */ Deconstruct(/*out int*/ x, /*out int*/ y, /*out int*/ width, /*out int*/ height)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067028831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                x.$v = this.X;
                y.$v = this.Y;
                width.$v = this.Width;
                height.$v = this.Height;
            }
            //--TRIMMABLE-BOUNDARY-END(30067028831)
            
            //--TRIMMABLE-BOUNDARY-START(38656963423)
            /*bool */ Equals$2(/*QrRectangle*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656963423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.X === other.X && this.Y === other.Y && this.Width === other.Width && this.Height === other.Height;
            }
            //--TRIMMABLE-BOUNDARY-END(38656963423)
            
            //--TRIMMABLE-BOUNDARY-START(34361996127)
            /*bool */ Equals$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361996127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$wZnq.NCQ.QrRectangle, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //--TRIMMABLE-BOUNDARY-END(34361996127)
            
            //--TRIMMABLE-BOUNDARY-START(77311669087)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311669087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    /*var*/ let hash = 17;
                    hash = ((((hash * 31) | 0) + this.X) | 0);
                    hash = ((((hash * 31) | 0) + this.Y) | 0);
                    hash = ((((hash * 31) | 0) + this.Width) | 0);
                    hash = ((((hash * 31) | 0) + this.Height) | 0);
                    return hash;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311669087)
            
            //--TRIMMABLE-BOUNDARY-START(94491538271)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491538271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `QrRectangle(X=${this.X}, Y=${this.Y}, Width=${this.Width}, Height=${this.Height})`;
            }
            //--TRIMMABLE-BOUNDARY-END(94491538271)
            
            //--TRIMMABLE-BOUNDARY-START(85901603679)
            static /*bool */ op_Equality(/*QrRectangle*/ left, /*QrRectangle*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901603679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(85901603679)
            
            //--TRIMMABLE-BOUNDARY-START(90196570975)
            static /*bool */ op_Inequality(/*QrRectangle*/ left, /*QrRectangle*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196570975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(90196570975)
            
            //--TRIMMABLE-BOUNDARY-START(4385603585)
            //Generated interface implemetation for System.IEquatable<Net.Codecrete.QrCodeGenerator.QrRectangle>.Equals(Net.Codecrete.QrCodeGenerator.QrRectangle)
            S$IEquatable$Net$Codecrete$QrCodeGenerator$QrRectangle$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385603585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385603585)
            
            //--TRIMMABLE-BOUNDARY-START(21477094239)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477094239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477094239)
            
            //--TRIMMABLE-BOUNDARY-START(21477094239)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21477094239)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.X = this.X;
                copy.Y = this.Y;
                copy.Width = this.Width;
                copy.Height = this.Height;
                return copy;
            }
            static $h = 2257759;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103081472863),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426767199,
        "f": 50331649
      },
      "n": "X",
      "d": 2257759,
      "h": 103081472863,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103081472863),
//--TRIMMABLE-BOUNDARY-START(107376440159),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016701791,
        "f": 50331649
      },
      "n": "Y",
      "d": 2257759,
      "h": 107376440159,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376440159),
//--TRIMMABLE-BOUNDARY-START(98786505567),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836832607,
        "f": 50331649
      },
      "n": "Width",
      "d": 2257759,
      "h": 98786505567,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786505567),
//--TRIMMABLE-BOUNDARY-START(81606636383),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246898015,
        "f": 50331649
      },
      "n": "Height",
      "d": 2257759,
      "h": 81606636383,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606636383)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067028831),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 655361,
          "f": 2
        },
        {
          "n": "y",
          "p": 655361,
          "f": 2
        },
        {
          "n": "width",
          "p": 655361,
          "f": 2
        },
        {
          "n": "height",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": 2257759,
      "h": 30067028831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067028831),
//--TRIMMABLE-BOUNDARY-START(38656963423),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 2257759
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2257759,
      "h": 38656963423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656963423),
//--TRIMMABLE-BOUNDARY-START(34361996127),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2257759,
      "h": 34361996127,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361996127),
//--TRIMMABLE-BOUNDARY-START(77311669087),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2257759,
      "h": 77311669087,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77311669087),
//--TRIMMABLE-BOUNDARY-START(94491538271),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2257759,
      "h": 94491538271,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491538271)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772061535),
    {
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        },
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2257759,
      "h": 25772061535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772061535),
//--TRIMMABLE-BOUNDARY-START(21477094239),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2257759,
      "h": 21477094239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477094239)
  ],
  "i": [$.$$.S.IEquatable$$($.$wZnq.NCQ.QrRectangle).$h
  ],
  "h": 2257759
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$wZnq.NCQ.QrRectangle) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.QrRectangle`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}QrRectangle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2257759)
        
        

        //--TRIMMABLE-BOUNDARY-START(1340255)
        $asm.$str(`$wZnq.NCQ.KanjiStrategy`, ($self) => class KanjiStrategy extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Automatic = 0;
            static Enabled = 1;
            static Disabled = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1340255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Automatic": 0n,
                    "Enabled": 1n,
                    "Disabled": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296307551)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296307551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296307551)
            
            //--TRIMMABLE-BOUNDARY-START(4296307551)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296307551)
            
            static $h = 1340255;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591274847),
    {
      "t": 1340255,
      "n": "Automatic",
      "d": 1340255,
      "h": 8591274847,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591274847),
//--TRIMMABLE-BOUNDARY-START(17181209439),
    {
      "t": 1340255,
      "n": "Enabled",
      "d": 1340255,
      "h": 17181209439,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181209439),
//--TRIMMABLE-BOUNDARY-START(12886242143),
    {
      "t": 1340255,
      "n": "Disabled",
      "d": 1340255,
      "h": 12886242143,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886242143)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296307551),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1340255,
      "h": 4296307551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296307551)
  ],
  "i": [90308609,96862209,90767361,90439681
  ],
  "h": 1340255
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.KanjiStrategy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}KanjiStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1340255)
        
        

        //--TRIMMABLE-BOUNDARY-START(750431)
        $asm.$str(`$wZnq.NCQ.DataSegmentMode`, ($self) => class DataSegmentMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Numeric = 1;
            static Alphanumeric = 2;
            static Kanji = 3;
            static Binary = 4;
            static ECI = 5;
            static StructuredAppend = 6;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(750431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Numeric": 1n,
                    "Alphanumeric": 2n,
                    "Kanji": 3n,
                    "Binary": 4n,
                    "ECI": 5n,
                    "StructuredAppend": 6n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295717727)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295717727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295717727)
            
            //--TRIMMABLE-BOUNDARY-START(4295717727)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295717727)
            
            static $h = 750431;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770554207),
    {
      "t": 750431,
      "n": "Numeric",
      "d": 750431,
      "h": 25770554207,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770554207),
//--TRIMMABLE-BOUNDARY-START(8590685023),
    {
      "t": 750431,
      "n": "Alphanumeric",
      "d": 750431,
      "h": 8590685023,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590685023),
//--TRIMMABLE-BOUNDARY-START(21475586911),
    {
      "t": 750431,
      "n": "Kanji",
      "d": 750431,
      "h": 21475586911,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475586911),
//--TRIMMABLE-BOUNDARY-START(12885652319),
    {
      "t": 750431,
      "n": "Binary",
      "d": 750431,
      "h": 12885652319,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885652319),
//--TRIMMABLE-BOUNDARY-START(17180619615),
    {
      "t": 750431,
      "n": "ECI",
      "d": 750431,
      "h": 17180619615,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180619615),
//--TRIMMABLE-BOUNDARY-START(30065521503),
    {
      "t": 750431,
      "n": "StructuredAppend",
      "d": 750431,
      "h": 30065521503,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065521503)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295717727),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 750431,
      "h": 4295717727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295717727)
  ],
  "i": [90308609,96862209,90767361,90439681
  ],
  "h": 750431
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataSegmentMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataSegmentMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(750431)
        
        

        //--TRIMMABLE-BOUNDARY-START(1012575)
        $asm.$cls(`$wZnq.NCQ.DataTooLongException`, ($self) => class DataTooLongException extends $.$$.S.ArgumentException
        {
            //--TRIMMABLE-BOUNDARY-START(4295979871)
            $ctor$15(/*string*/ message)
            {
                super.$ctor$14(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295979871);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295979871)
            
            static $h = 1012575;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 44433409,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295979871),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": 1012575,
      "h": 4295979871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295979871)
  ],
  "i": [157745153
  ],
  "h": 1012575
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ArgumentException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.DataTooLongException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}DataTooLongException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1012575)
        
        

        //--TRIMMABLE-BOUNDARY-START(1143647)
        $asm.$cls(`$wZnq.NCQ.ECIException`, ($self) => class ECIException extends $.$$.S.ArgumentException
        {
            //--TRIMMABLE-BOUNDARY-START(4296110943)
            $ctor$15(/*string*/ message)
            {
                super.$ctor$14(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296110943);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296110943)
            
            static $h = 1143647;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 44433409,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296110943),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": 1143647,
      "h": 4296110943,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296110943)
  ],
  "i": [157745153
  ],
  "h": 1143647
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ArgumentException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Net.Codecrete.QrCodeGenerator.ECIException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Net${separator}Codecrete${separator}QrCodeGenerator${separator}ECIException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1143647)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.IO.Hashing", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"));
})();
//--TRIMMABLE-BOUNDARY-END(29535)
