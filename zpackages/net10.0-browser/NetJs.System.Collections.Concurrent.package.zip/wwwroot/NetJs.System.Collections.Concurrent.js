
//--TRIMMABLE-BOUNDARY-START(14)
(function ($global, $, $$, $sc, $sdt, $st) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Collections.Concurrent", 
    {
  "h": 14,
  "f": "System.Collections.Concurrent",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Collections.Concurrent",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Collections.Concurrent",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2949134)
        $asm.$cls("$scc.System.Collections.Concurrent.Partitioner<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner<>", [TSource], ($self) => class Partitioner$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25772752910)
            /*bool */ get SupportsDynamicPartitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887851022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25772752910)
            
            //--TRIMMABLE-BOUNDARY-START(17182818318)
            /*IEnumerable<TSource> */ GetDynamicPartitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182818318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.Partitioner_DynamicPartitionsNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(17182818318)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2949134;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772752910),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331777
      },
      "n": "SupportsDynamicPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25772752910)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477785614),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$(TSource)).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21477785614),
//--TRIMMABLE-BOUNDARY-START(17182818318),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h,
      "n": "GetDynamicPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17182818318)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297916430),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297916430)
  ],
  "g": [TSource?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.Partitioner<${TSource?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2949134)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310734)
        $asm.$cls("$scc.System.Collections.Concurrent.OrderablePartitioner<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.OrderablePartitioner<>", [TSource], ($self) => class OrderablePartitioner$$ extends $.$scc.System.Collections.Concurrent.Partitioner$$(TSource)
        {
            //--TRIMMABLE-BOUNDARY-START(4296278030)
            $ctor$2(/*bool*/ keysOrderedInEachPartition, /*bool*/ keysOrderedAcrossPartitions, /*bool*/ keysNormalized)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278030);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.KeysOrderedInEachPartition = keysOrderedInEachPartition;
                    this.KeysOrderedAcrossPartitions = keysOrderedAcrossPartitions;
                    this.KeysNormalized = keysNormalized;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278030)
            
            //--TRIMMABLE-BOUNDARY-START(60130852878)
            /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130852878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.Partitioner_DynamicPartitionsNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(60130852878)
            
            //--TRIMMABLE-BOUNDARY-START(81605689358)
            /*bool*/ KeysOrderedInEachPartition = false;
            //--TRIMMABLE-BOUNDARY-END(81605689358)
            
            //--TRIMMABLE-BOUNDARY-START(77310722062)
            /*bool*/ KeysOrderedAcrossPartitions = false;
            //--TRIMMABLE-BOUNDARY-END(77310722062)
            
            //--TRIMMABLE-BOUNDARY-START(73015754766)
            /*bool*/ KeysNormalized = false;
            //--TRIMMABLE-BOUNDARY-END(73015754766)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 68720787470, 21477785614)
            /*IList<IEnumerator<TSource>> */ GetPartitions(/*int*/ partitionCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IList<IEnumerator<KeyValuePair<long, TSource>>>*/ let orderablePartitions = this.GetOrderablePartitions(partitionCount);
                if (orderablePartitions.System$Collections$Generic$ICollection$$$Count !== partitionCount)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("OrderablePartitioner_GetPartitions_WrongNumberOfPartitions");
                }
                /*IEnumerator<TSource>[]*/ let partitions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.IEnumerator$$(TSource)), null, [partitionCount], null);
                for(/*int*/ let i = 0; i < partitionCount; i++)
                {
                    $.$$.System.Array.$WriteT1.call(partitions, new ($.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).EnumeratorDropIndices)().$ctor$1(orderablePartitions.System$Collections$Generic$IList$$$get_Item(i, [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))])), i);
                }
                return partitions;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 68720787470, 21477785614)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55835885582, 17182818318)
            /*IEnumerable<TSource> */ GetDynamicPartitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835885582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<KeyValuePair<long, TSource>>*/ let orderablePartitions = this.GetOrderableDynamicPartitions();
                return new ($.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).EnumerableDropIndices)().$ctor$1(orderablePartitions);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55835885582, 17182818318)
            
            //--TRIMMABLE-BOUNDARY-START(1376270)
            static $_EnumerableDropIndices;
            static get EnumerableDropIndices()
            {
                let $cls = $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource);
                return $cls.$_EnumerableDropIndices ??= $asm.$ncls("$scc.System.Collections.Concurrent.OrderablePartitioner$$.EnumerableDropIndices", ($self) => class EnumerableDropIndices extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296343566)
                    /*IEnumerable<KeyValuePair<long, TSource>>*/ _source = null;
                    //--TRIMMABLE-BOUNDARY-END(4296343566)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591310862)
                    $ctor$1(/*IEnumerable<KeyValuePair<long, TSource>>*/ source)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591310862);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._source = source;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591310862)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181245454)
                    /*IEnumerator<TSource> */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181245454);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).EnumeratorDropIndices)().$ctor$1(this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)]));
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181245454)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 21476212750, 4357488641)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476212750);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 21476212750, 4357488641)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886278158)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886278158);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        ($.$as(this._source, $.$$.System.IDisposable))?.System$IDisposable$Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886278158)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354473985)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<TSource>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354473985);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354473985)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    static $h = 1376270;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181245454),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(TSource).$h,
      "n": "GetEnumerator",
      "d": 1376270,
      "h": Number(BigInt(1376270)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181245454),
//--TRIMMABLE-BOUNDARY-START(12886278158),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1376270,
      "h": Number(BigInt(1376270)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886278158)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296343566),
    {
      "t": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "_source",
      "d": 1376270,
      "h": Number(BigInt(1376270)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343566)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591310862),
    {
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376270,
      "h": Number(BigInt(1376270)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591310862)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerable$$(TSource).$h,62521345,90177537
  ],
  "d": $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,
  "h": 1376270
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.IEnumerable, $.$$.System.IDisposable ]; }
                    static get $fullName() { return `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>.EnumerableDropIndices`; }
                }, $cls, ($v) => $cls.$_EnumerableDropIndices = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376270)
            
            //--TRIMMABLE-BOUNDARY-START(1441806)
            static $_EnumeratorDropIndices;
            static get EnumeratorDropIndices()
            {
                let $cls = $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource);
                return $cls.$_EnumeratorDropIndices ??= $asm.$ncls("$scc.System.Collections.Concurrent.OrderablePartitioner$$.EnumeratorDropIndices", ($self) => class EnumeratorDropIndices extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296409102)
                    /*IEnumerator<KeyValuePair<long, TSource>>*/ _source = null;
                    //--TRIMMABLE-BOUNDARY-END(4296409102)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591376398)
                    $ctor$1(/*IEnumerator<KeyValuePair<long, TSource>>*/ source)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591376398);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._source = source;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591376398)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066212878)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066212878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._source.System$Collections$IEnumerator$MoveNext();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066212878)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886343694)
                    /*TSource */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771245582);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._source.System$Collections$Generic$IEnumerator$$$Current.Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886343694)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 38656147470, 4357619713)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246082062);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$box((this).Current, TSource);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 38656147470, 4357619713)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181310990)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181310990);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._source.System$IDisposable$Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181310990)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361180174)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34361180174);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._source.System$Collections$IEnumerator$Reset();
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361180174)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944474113)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<TSource>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354539521);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944474113)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242521601)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242521601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242521601)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537488897)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537488897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537488897)
                    
                    static $h = 1441806;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886343694),
    {
      "p": TSource?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1441806)|0x600000000n),
        "f": 50331649
      },
      "n": "Current",
      "d": 1441806,
      "h": Number(BigInt(1441806)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886343694),
//--TRIMMABLE-BOUNDARY-START(ALL, 38656147470, 4357619713),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1441806)|0xB00000000n),
        "f": 50331650
      },
      "n": "{62652417}.Current",
      "o": "System$Collections$IEnumerator$Current",
      "d": 1441806,
      "h": Number(BigInt(1441806)|0x900000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38656147470, 4357619713)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066212878),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1441806,
      "h": Number(BigInt(1441806)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066212878),
//--TRIMMABLE-BOUNDARY-START(17181310990),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1441806,
      "h": Number(BigInt(1441806)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181310990),
//--TRIMMABLE-BOUNDARY-START(34361180174),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1441806,
      "h": Number(BigInt(1441806)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361180174)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296409102),
    {
      "t": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "_source",
      "d": 1441806,
      "h": Number(BigInt(1441806)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409102)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591376398),
    {
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441806,
      "h": Number(BigInt(1441806)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591376398)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$(TSource).$h,90177537,62652417
  ],
  "d": $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,
  "h": 1441806
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TSource), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>.EnumeratorDropIndices`; }
                }, $cls, ($v) => $cls.$_EnumeratorDropIndices = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1441806)
            
            static $h = 1310734;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605689358),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "KeysOrderedInEachPartition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605689358),
//--TRIMMABLE-BOUNDARY-START(77310722062),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "KeysOrderedAcrossPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310722062),
//--TRIMMABLE-BOUNDARY-START(73015754766),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "KeysNormalized",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015754766)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425820174),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetOrderablePartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64425820174),
//--TRIMMABLE-BOUNDARY-START(60130852878),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "GetOrderableDynamicPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60130852878),
//--TRIMMABLE-BOUNDARY-START(ALL, 68720787470, 21477785614),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$(TSource)).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 68720787470, 21477785614),
//--TRIMMABLE-BOUNDARY-START(ALL, 55835885582, 17182818318),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h,
      "n": "GetDynamicPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55835885582, 17182818318)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278030),
    {
      "p": [
        {
          "n": "keysOrderedInEachPartition",
          "p": 262145
        },
        {
          "n": "keysOrderedAcrossPartitions",
          "p": 262145
        },
        {
          "n": "keysNormalized",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296278030)
  ],
  "g": [TSource?.$h??1507328
  ],
  "j": [1376270,1441806
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner$$(TSource); }
            static get $fullName() { return `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1310734)
        
        
        //--TRIMMABLE-BOUNDARY-START(3211278)
        $asm.$cls("$scc.System.ThrowHelper", ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(17183080462)
            static /*void */ ThrowKeyNullException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183080462);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("key");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183080462)
            
            //--TRIMMABLE-BOUNDARY-START(4298178574)
            static /*void */ ThrowArgumentNullException$1(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298178574);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.ArgumentNullException().$ctor$19(name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298178574)
            
            //--TRIMMABLE-BOUNDARY-START(8593145870)
            static /*void */ ThrowArgumentNullException(/*string*/ name, /*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593145870);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.ArgumentNullException().$ctor$18(name, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593145870)
            
            //--TRIMMABLE-BOUNDARY-START(25773015054)
            static /*void */ ThrowValueNullException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773015054);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_TypeOfValueIncorrect);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773015054)
            
            //--TRIMMABLE-BOUNDARY-START(21478047758)
            static /*void */ ThrowOutOfMemoryException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478047758);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.OutOfMemoryException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478047758)
            
            //--TRIMMABLE-BOUNDARY-START(12888113166)
            static /*void */ ThrowIncompatibleComparer()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888113166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.InvalidOperation_IncompatibleComparer);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888113166)
            
            static $h = 3211278;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183080462),
    {
      "r": 65537,
      "n": "ThrowKeyNullException",
      "d": 3211278,
      "h": 17183080462,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17183080462),
//--TRIMMABLE-BOUNDARY-START(4298178574),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "ThrowArgumentNullException",
      "o": "@$1",
      "d": 3211278,
      "h": 4298178574,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298178574),
//--TRIMMABLE-BOUNDARY-START(8593145870),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ThrowArgumentNullException",
      "d": 3211278,
      "h": 8593145870,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8593145870),
//--TRIMMABLE-BOUNDARY-START(25773015054),
    {
      "r": 65537,
      "n": "ThrowValueNullException",
      "d": 3211278,
      "h": 25773015054,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25773015054),
//--TRIMMABLE-BOUNDARY-START(21478047758),
    {
      "r": 65537,
      "n": "ThrowOutOfMemoryException",
      "d": 3211278,
      "h": 21478047758,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21478047758),
//--TRIMMABLE-BOUNDARY-START(12888113166),
    {
      "r": 65537,
      "n": "ThrowIncompatibleComparer",
      "d": 3211278,
      "h": 12888113166,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12888113166)
  ],
  "h": 3211278
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211278)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245198)
        $asm.$cls("$scc.System.Collections.Concurrent.IProducerConsumerCollectionDebugView<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.IProducerConsumerCollectionDebugView<>", [T], ($self) => class IProducerConsumerCollectionDebugView$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296212494)
            /*IProducerConsumerCollection<T>*/ _collection = null;
            //--TRIMMABLE-BOUNDARY-END(4296212494)
            
            //--TRIMMABLE-BOUNDARY-START(8591179790)
            $ctor$1(/*IProducerConsumerCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179790);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179790)
            
            //--TRIMMABLE-BOUNDARY-START(21476081678)
            /*T[] */ get Items()
            {
                return this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray([T]);
            }
            //--TRIMMABLE-BOUNDARY-END(21476081678)
            
            static $h = 1245198;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476081678),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70057985,
          "c": 4365025281,
          "a": [
            {
              "v": 3,
              "t": 70123521
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476081678)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212494),
    {
      "t": $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,
      "n": "_collection",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212494)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179790),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179790)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.IProducerConsumerCollectionDebugView<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1245198)
        
        
        //--TRIMMABLE-BOUNDARY-START(3145742)
        $asm.$cls("$scc.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(523989155854)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(523989155854)
            
            //--TRIMMABLE-BOUNDARY-START(493924384782)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(493924384782);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(493924384782)
            
            //--TRIMMABLE-BOUNDARY-START(536874057742)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(536874057742);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scc.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(536874057742)
            
            //--TRIMMABLE-BOUNDARY-START(485334450190)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485334450190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(485334450190)
            
            //--TRIMMABLE-BOUNDARY-START(489629417486)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489629417486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$scc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(489629417486)
            
            //--TRIMMABLE-BOUNDARY-START(141737066510)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737066510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(141737066510)
            
            //--TRIMMABLE-BOUNDARY-START(146032033806)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032033806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(146032033806)
            
            //--TRIMMABLE-BOUNDARY-START(150327001102)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150327001102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(150327001102)
            
            //--TRIMMABLE-BOUNDARY-START(154621968398)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621968398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(154621968398)
            
            //--TRIMMABLE-BOUNDARY-START(158916935694)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916935694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(158916935694)
            
            //--TRIMMABLE-BOUNDARY-START(163211902990)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211902990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(163211902990)
            
            //--TRIMMABLE-BOUNDARY-START(167506870286)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506870286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(167506870286)
            
            //--TRIMMABLE-BOUNDARY-START(171801837582)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801837582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(171801837582)
            
            //--TRIMMABLE-BOUNDARY-START(519694188558)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(519694188558)
            
            //--TRIMMABLE-BOUNDARY-START(511104253966)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(511104253966)
            
            //--TRIMMABLE-BOUNDARY-START(515399221262)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481039482894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$scc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Collections.Concurrent", $.$scc.System.SR.$type.Assembly);
                    $.$scc.System.SR.s_resourceManager = temp;
                }
                return $.$scc.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(515399221262)
            
            //--TRIMMABLE-BOUNDARY-START(137442099214)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446679744526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532579090446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(137442099214)
            
            //--TRIMMABLE-BOUNDARY-START(17183014926)
            static /*string */ get BlockingCollection_Add_ConcurrentCompleteAdd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206161575950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "CompleteAdding may not be used concurrently with additions to the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183014926)
            
            //--TRIMMABLE-BOUNDARY-START(21477982222)
            static /*string */ get BlockingCollection_Add_Failed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751510542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The underlying collection didn't accept the item.";
            }
            //--TRIMMABLE-BOUNDARY-END(21477982222)
            
            //--TRIMMABLE-BOUNDARY-START(25772949518)
            static /*string */ get BlockingCollection_CantAddAnyWhenCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223341445134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "At least one of the specified collections is marked as complete with regards to additions.";
            }
            //--TRIMMABLE-BOUNDARY-END(25772949518)
            
            //--TRIMMABLE-BOUNDARY-START(30067916814)
            static /*string */ get BlockingCollection_CantTakeAnyWhenAllDone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231931379726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "All collections are marked as complete with regards to additions.";
            }
            //--TRIMMABLE-BOUNDARY-END(30067916814)
            
            //--TRIMMABLE-BOUNDARY-START(34362884110)
            static /*string */ get BlockingCollection_CantTakeWhenDone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240521314318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collection argument is empty and has been marked as complete with regards to additions.";
            }
            //--TRIMMABLE-BOUNDARY-END(34362884110)
            
            //--TRIMMABLE-BOUNDARY-START(38657851406)
            static /*string */ get BlockingCollection_Completed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249111248910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collection has been marked as complete with regards to additions.";
            }
            //--TRIMMABLE-BOUNDARY-END(38657851406)
            
            //--TRIMMABLE-BOUNDARY-START(42952818702)
            static /*string */ get BlockingCollection_CopyTo_IncorrectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257701183502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The array argument is of the incorrect type.";
            }
            //--TRIMMABLE-BOUNDARY-END(42952818702)
            
            //--TRIMMABLE-BOUNDARY-START(47247785998)
            static /*string */ get BlockingCollection_CopyTo_MultiDim()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266291118094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The array argument is multidimensional.";
            }
            //--TRIMMABLE-BOUNDARY-END(47247785998)
            
            //--TRIMMABLE-BOUNDARY-START(51542753294)
            static /*string */ get BlockingCollection_CopyTo_NonNegative()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274881052686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The index argument must be greater than or equal zero.";
            }
            //--TRIMMABLE-BOUNDARY-END(51542753294)
            
            //--TRIMMABLE-BOUNDARY-START(85902491662)
            static /*string */ get Collection_CopyTo_TooManyElems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343600529422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The number of elements in the collection is greater than the available space from index to the end of the destination array.";
            }
            //--TRIMMABLE-BOUNDARY-END(85902491662)
            
            //--TRIMMABLE-BOUNDARY-START(55837720590)
            static /*string */ get BlockingCollection_ctor_CountMoreThanCapacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283470987278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collection argument contains more items than are allowed by the boundedCapacity.";
            }
            //--TRIMMABLE-BOUNDARY-END(55837720590)
            
            //--TRIMMABLE-BOUNDARY-START(60132687886)
            static /*string */ get BlockingCollection_Take_CollectionModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292060921870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The underlying collection was modified from outside of the BlockingCollection<T>.";
            }
            //--TRIMMABLE-BOUNDARY-END(60132687886)
            
            //--TRIMMABLE-BOUNDARY-START(64427655182)
            static /*string */ get BlockingCollection_TimeoutInvalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300650856462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified timeout must represent a value between -1 and {0}, inclusive.";
            }
            //--TRIMMABLE-BOUNDARY-END(64427655182)
            
            //--TRIMMABLE-BOUNDARY-START(180391772174)
            static /*string */ FormatBlockingCollection_TimeoutInvalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391772174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The specified timeout must represent a value between -1 and {0}, inclusive.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(180391772174)
            
            //--TRIMMABLE-BOUNDARY-START(68722622478)
            static /*string */ get BlockingCollection_ValidateCollectionsArray_DispElems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309240791054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collections argument contains at least one disposed element.";
            }
            //--TRIMMABLE-BOUNDARY-END(68722622478)
            
            //--TRIMMABLE-BOUNDARY-START(73017589774)
            static /*string */ get BlockingCollection_ValidateCollectionsArray_LargeSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317830725646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collections length is greater than the supported range.";
            }
            //--TRIMMABLE-BOUNDARY-END(73017589774)
            
            //--TRIMMABLE-BOUNDARY-START(77312557070)
            static /*string */ get BlockingCollection_ValidateCollectionsArray_NullElems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326420660238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collections argument contains at least one null element.";
            }
            //--TRIMMABLE-BOUNDARY-END(77312557070)
            
            //--TRIMMABLE-BOUNDARY-START(81607524366)
            static /*string */ get BlockingCollection_ValidateCollectionsArray_ZeroSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335010594830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collections argument is a zero-length array.";
            }
            //--TRIMMABLE-BOUNDARY-END(81607524366)
            
            //--TRIMMABLE-BOUNDARY-START(94492426254)
            static /*string */ get ConcurrentCollection_SyncRoot_NotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360780398606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The SyncRoot property may not be used for the synchronization of concurrent collections.";
            }
            //--TRIMMABLE-BOUNDARY-END(94492426254)
            
            //--TRIMMABLE-BOUNDARY-START(98787393550)
            static /*string */ get ConcurrentDictionary_ArrayIncorrectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369370333198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The array is multidimensional, or the type parameter for the set cannot be cast automatically to the type of the destination array.";
            }
            //--TRIMMABLE-BOUNDARY-END(98787393550)
            
            //--TRIMMABLE-BOUNDARY-START(120262230030)
            static /*string */ get ConcurrentDictionary_SourceContainsDuplicateKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412320006158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The source argument contains duplicate keys.";
            }
            //--TRIMMABLE-BOUNDARY-END(120262230030)
            
            //--TRIMMABLE-BOUNDARY-START(107377328142)
            static /*string */ get ConcurrentDictionary_ConcurrencyLevelMustBePositiveOrNegativeOne()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386550202382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The concurrencyLevel argument must be positive, or -1 to indicate a default level.";
            }
            //--TRIMMABLE-BOUNDARY-END(107377328142)
            
            //--TRIMMABLE-BOUNDARY-START(103082360846)
            static /*string */ get ConcurrentDictionary_ArrayNotLargeEnough()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377960267790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The index is equal to or greater than the length of the array, or the number of elements in the dictionary is greater than the available space from index to the end of the destination array.";
            }
            //--TRIMMABLE-BOUNDARY-END(103082360846)
            
            //--TRIMMABLE-BOUNDARY-START(115967262734)
            static /*string */ get ConcurrentDictionary_KeyAlreadyExisted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403730071566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The key already existed in the dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(115967262734)
            
            //--TRIMMABLE-BOUNDARY-START(111672295438)
            static /*string */ get ConcurrentDictionary_ItemKeyIsNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395140136974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "TKey is a reference type and item.Key is null.";
            }
            //--TRIMMABLE-BOUNDARY-END(111672295438)
            
            //--TRIMMABLE-BOUNDARY-START(124557197326)
            static /*string */ get ConcurrentDictionary_TypeOfKeyIncorrect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420909940750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The key was of an incorrect type for this dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(124557197326)
            
            //--TRIMMABLE-BOUNDARY-START(128852164622)
            static /*string */ get ConcurrentDictionary_TypeOfValueIncorrect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429499875342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value was of an incorrect type for this dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(128852164622)
            
            //--TRIMMABLE-BOUNDARY-START(133147131918)
            static /*string */ get ConcurrentStack_PushPopRange_InvalidCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438089809934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The sum of the startIndex and count arguments must be less than or equal to the collection's Count.";
            }
            //--TRIMMABLE-BOUNDARY-END(133147131918)
            
            //--TRIMMABLE-BOUNDARY-START(502514319374)
            static /*string */ get Partitioner_DynamicPartitionsNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463859613710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Dynamic partitions are not supported by this partitioner.";
            }
            //--TRIMMABLE-BOUNDARY-END(502514319374)
            
            //--TRIMMABLE-BOUNDARY-START(506809286670)
            static /*string */ get PartitionerStatic_CurrentCalledBeforeMoveNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472449548302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MoveNext must be called at least once before calling Current.";
            }
            //--TRIMMABLE-BOUNDARY-END(506809286670)
            
            //--TRIMMABLE-BOUNDARY-START(90197458958)
            static /*string */ get ConcurrentBag_Enumerator_EnumerationNotStartedOrAlreadyFinished()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352190464014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration has either not started or has already finished.";
            }
            //--TRIMMABLE-BOUNDARY-END(90197458958)
            
            //--TRIMMABLE-BOUNDARY-START(12888047630)
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571641358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The given key '{0}' was not present in the dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888047630)
            
            //--TRIMMABLE-BOUNDARY-START(176096804878)
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096804878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(176096804878)
            
            //--TRIMMABLE-BOUNDARY-START(8593080334)
            static /*string */ get Arg_HTCapacityOverflow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981706766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            //--TRIMMABLE-BOUNDARY-END(8593080334)
            
            //--TRIMMABLE-BOUNDARY-START(498219352078)
            static /*string */ get InvalidOperation_IncompatibleComparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455269679118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collection's comparer does not support the requested operation.";
            }
            //--TRIMMABLE-BOUNDARY-END(498219352078)
            
            //--TRIMMABLE-BOUNDARY-START(4298113038)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(523989155854)
                    this.s_usingResourceKeys = $.$scc.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(523989155854)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298113038)
            
            static $h = 3145742;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3145742
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3145742)
        
        
        //--TRIMMABLE-BOUNDARY-START(3080206)
        $asm.$cls("$scc.System.Collections.HashHelpers", ($self) => class HashHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(30067851278)
            /*uint*/ static HashCollisionThreshold = 100;
            //--TRIMMABLE-BOUNDARY-END(30067851278)
            
            //--TRIMMABLE-BOUNDARY-START(42952753166)
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            //--TRIMMABLE-BOUNDARY-END(42952753166)
            
            //--TRIMMABLE-BOUNDARY-START(34362818574)
            /*int*/ static HashPrime = 101;
            //--TRIMMABLE-BOUNDARY-END(34362818574)
            
            //--TRIMMABLE-BOUNDARY-START(47247720462)
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Int32))().$ctor$4([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(47247720462)
            
            //--TRIMMABLE-BOUNDARY-START(38657785870)
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657785870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$$.System.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            //--TRIMMABLE-BOUNDARY-END(38657785870)
            
            //--TRIMMABLE-BOUNDARY-START(25772883982)
            static /*int */ GetPrime(/*int*/ min)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772883982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (min < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.Arg_HTCapacityOverflow);
                }
                var $en2 = $.$scc.System.Collections.HashHelpers.Primes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prime = $en2.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$scc.System.Collections.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            //--TRIMMABLE-BOUNDARY-END(25772883982)
            
            //--TRIMMABLE-BOUNDARY-START(4298047502)
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298047502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(2147483587/*MaxPrimeArrayLength*/ === $.$scc.System.Collections.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$scc.System.Collections.HashHelpers.GetPrime(newSize);
            }
            //--TRIMMABLE-BOUNDARY-END(4298047502)
            
            //--TRIMMABLE-BOUNDARY-START(21477916686)
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477916686);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return 18446744073709551615n / BigInt(divisor) + 1n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477916686)
            
            //--TRIMMABLE-BOUNDARY-START(8593014798)
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593014798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast((((((multiplier * BigInt(value)) >> 32n) + 1n) * BigInt(divisor)) >> 32n), $.$$.System.UInt32);
                $.$$.System.Diagnostics.Debug.Assert$2(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            //--TRIMMABLE-BOUNDARY-END(8593014798)
            
            static $h = 3080206;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247720462),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182949390,
        "f": 50331688
      },
      "n": "Primes",
      "d": 3080206,
      "h": 47247720462,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(47247720462)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38657785870),
    {
      "r": 262145,
      "p": [
        {
          "n": "candidate",
          "p": 655361
        }
      ],
      "n": "IsPrime",
      "d": 3080206,
      "h": 38657785870,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657785870),
//--TRIMMABLE-BOUNDARY-START(25772883982),
    {
      "r": 655361,
      "p": [
        {
          "n": "min",
          "p": 655361
        }
      ],
      "n": "GetPrime",
      "d": 3080206,
      "h": 25772883982,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772883982),
//--TRIMMABLE-BOUNDARY-START(4298047502),
    {
      "r": 655361,
      "p": [
        {
          "n": "oldSize",
          "p": 655361
        }
      ],
      "n": "ExpandPrime",
      "d": 3080206,
      "h": 4298047502,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298047502),
//--TRIMMABLE-BOUNDARY-START(21477916686),
    {
      "r": 983041,
      "p": [
        {
          "n": "divisor",
          "p": 720897
        }
      ],
      "n": "GetFastModMultiplier",
      "d": 3080206,
      "h": 21477916686,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477916686),
//--TRIMMABLE-BOUNDARY-START(8593014798),
    {
      "r": 720897,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "divisor",
          "p": 720897
        },
        {
          "n": "multiplier",
          "p": 983041
        }
      ],
      "n": "FastMod",
      "d": 3080206,
      "h": 8593014798,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593014798)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067851278),
    {
      "t": 720897,
      "n": "HashCollisionThreshold",
      "d": 3080206,
      "h": 30067851278,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067851278),
//--TRIMMABLE-BOUNDARY-START(42952753166),
    {
      "t": 655361,
      "n": "MaxPrimeArrayLength",
      "d": 3080206,
      "h": 42952753166,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42952753166),
//--TRIMMABLE-BOUNDARY-START(34362818574),
    {
      "t": 655361,
      "n": "HashPrime",
      "d": 3080206,
      "h": 34362818574,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362818574)
  ],
  "h": 3080206
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.HashHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3080206)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507342)
        $asm.$cls("$scc.System.Collections.Concurrent.Partitioner", ($self) => class Partitioner
        {
            //--TRIMMABLE-BOUNDARY-START(4296474638)
            /*int*/ static CoreOversubscriptionRate = 3;
            //--TRIMMABLE-BOUNDARY-END(4296474638)
            
            //--TRIMMABLE-BOUNDARY-START(8591441934)
            static /*OrderablePartitioner<TSource> */ Create$6(TSource, /*IList<TSource>*/ list, /*bool*/ loadBalance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591441934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(list, "list");
                if (loadBalance)
                {
                    return (new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource))().$ctor$4(list));
                }
                else 
                {
                    return (new ($.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForIList$$(TSource))().$ctor$4(list));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591441934)
            
            //--TRIMMABLE-BOUNDARY-START(12886409230)
            static /*OrderablePartitioner<TSource> */ Create$7(TSource, /*TSource[]*/ array, /*bool*/ loadBalance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886409230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if (loadBalance)
                {
                    return (new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource))().$ctor$4(array));
                }
                else 
                {
                    return (new ($.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForArray$$(TSource))().$ctor$4(array));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886409230)
            
            //--TRIMMABLE-BOUNDARY-START(17181376526)
            static /*OrderablePartitioner<TSource> */ Create$5(TSource, /*IEnumerable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4(TSource, source, 0/*EnumerablePartitionerOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17181376526)
            
            //--TRIMMABLE-BOUNDARY-START(21476343822)
            static /*OrderablePartitioner<TSource> */ Create$4(TSource, /*IEnumerable<TSource>*/ source, /*EnumerablePartitionerOptions*/ partitionerOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                if ((partitionerOptions & (~1/*EnumerablePartitionerOptions.NoBuffering*/)) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("partitionerOptions");
                }
                return (new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource))().$ctor$3(source, partitionerOptions));
            }
            //--TRIMMABLE-BOUNDARY-END(21476343822)
            
            //--TRIMMABLE-BOUNDARY-START(25771311118)
            static /*OrderablePartitioner<Tuple<long, long>> */ Create$3(/*long*/ fromInclusive, /*long*/ toExclusive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.System.Int64, toExclusive, fromInclusive, "toExclusive");
                /*decimal*/ let range = $.$$.System.Decimal.op_Subtraction($.$$.System.Decimal.op_Implicit$4(toExclusive), $.$$.System.Decimal.op_Implicit$4(fromInclusive));
                /*long*/ let rangeSize = $.$$.System.Decimal.op_Explicit$7(($.$$.System.Decimal.op_Division(range, ($.$$.System.Decimal.op_Implicit$3((($.$$.System.Environment.ProcessorCount * 3/*CoreOversubscriptionRate*/) | 0))))));
                if (rangeSize === 0n)
                {
                    rangeSize = 1n;
                }
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64), $.$scc.System.Collections.Concurrent.Partitioner.CreateRanges$1(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25771311118)
            
            //--TRIMMABLE-BOUNDARY-START(30066278414)
            static /*OrderablePartitioner<Tuple<long, long>> */ Create$2(/*long*/ fromInclusive, /*long*/ toExclusive, /*long*/ rangeSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.System.Int64, toExclusive, fromInclusive, "toExclusive");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int64, rangeSize, "rangeSize");
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64), $.$scc.System.Collections.Concurrent.Partitioner.CreateRanges$1(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            //--TRIMMABLE-BOUNDARY-END(30066278414)
            
            //--TRIMMABLE-BOUNDARY-START(42951180302)
            static /*IEnumerable<Tuple<long, long>> */ CreateRanges$1(/*long*/ fromInclusive, /*long*/ toExclusive, /*long*/ rangeSize)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*long*/ let $from, to;
                    /*bool*/ let shouldQuit = false;
                    for(/*long*/ let i = fromInclusive; (i < toExclusive) && !shouldQuit; i = i + rangeSize)
                    {
                        $from = i;
                        try
                        {
                            //checked
                            {
                                to = i + rangeSize;
                            }
                        }
                        catch($e)
                        {
                            to = toExclusive;
                            shouldQuit = true;
                        }
                        if (to > toExclusive)
                        {
                            to = toExclusive;
                        }
                        yield new ($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64))().$ctor$1($from, to);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(42951180302)
            
            //--TRIMMABLE-BOUNDARY-START(34361245710)
            static /*OrderablePartitioner<Tuple<int, int>> */ Create$1(/*int*/ fromInclusive, /*int*/ toExclusive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.System.Int32, toExclusive, fromInclusive, "toExclusive");
                /*long*/ let range = $.$cast(toExclusive, $.$$.System.Int64) - BigInt(fromInclusive);
                /*int*/ let rangeSize = $.$cast((range / (BigInt($.$$.System.Environment.ProcessorCount * 3/*CoreOversubscriptionRate*/))), $.$$.System.Int32);
                if (rangeSize === 0)
                {
                    rangeSize = 1;
                }
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32), $.$scc.System.Collections.Concurrent.Partitioner.CreateRanges(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34361245710)
            
            //--TRIMMABLE-BOUNDARY-START(38656213006)
            static /*OrderablePartitioner<Tuple<int, int>> */ Create(/*int*/ fromInclusive, /*int*/ toExclusive, /*int*/ rangeSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.System.Int32, toExclusive, fromInclusive, "toExclusive");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, rangeSize, "rangeSize");
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32), $.$scc.System.Collections.Concurrent.Partitioner.CreateRanges(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            //--TRIMMABLE-BOUNDARY-END(38656213006)
            
            //--TRIMMABLE-BOUNDARY-START(47246147598)
            static /*IEnumerable<Tuple<int, int>> */ CreateRanges(/*int*/ fromInclusive, /*int*/ toExclusive, /*int*/ rangeSize)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let $from, to;
                    /*bool*/ let shouldQuit = false;
                    for(/*int*/ let i = fromInclusive; (i < toExclusive) && !shouldQuit; i = ((i + rangeSize) | 0))
                    {
                        $from = i;
                        try
                        {
                            //checked
                            {
                                to = $.$checked(i + rangeSize, 1);
                            }
                        }
                        catch($e)
                        {
                            to = toExclusive;
                            shouldQuit = true;
                        }
                        if (to > toExclusive)
                        {
                            to = toExclusive;
                        }
                        yield new ($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$1($from, to);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(47246147598)
            
            //--TRIMMABLE-BOUNDARY-START(1572878)
            static $_DynamicPartitionEnumerator_Abstract$$$;
            static DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionEnumerator_Abstract$$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract<,>", (TSource, TSourceReader) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract<,>", [TSource, TSourceReader], ($self) => class DynamicPartitionEnumerator_Abstract$$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(25771376654)
                    /*TSourceReader*/ _sharedReader = $.$default(TSourceReader);
                    //--TRIMMABLE-BOUNDARY-END(25771376654)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195886094)
                    /*int*/ static s_defaultMaxChunkSize = 0;
                    //--TRIMMABLE-BOUNDARY-END(90195886094)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296540174)
                    /*StrongBox<int>?*/ _currentChunkSize = null;
                    //--TRIMMABLE-BOUNDARY-END(4296540174)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886474766)
                    /*StrongBox<int>?*/ _localOffset = null;
                    //--TRIMMABLE-BOUNDARY-END(12886474766)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951245838)
                    /*int*/ static CHUNK_DOUBLING_RATE = 3;
                    //--TRIMMABLE-BOUNDARY-END(42951245838)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591507470)
                    /*int*/ _doublingCountdown = 0;
                    //--TRIMMABLE-BOUNDARY-END(8591507470)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181442062)
                    /*int*/ _maxChunkSize = 0;
                    //--TRIMMABLE-BOUNDARY-END(17181442062)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476409358)
                    /*SharedLong*/ _sharedIndex = null;
                    //--TRIMMABLE-BOUNDARY-END(21476409358)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361311246)
                    $ctor$2(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex)
                    {
                        this.$ctor$1(sharedReader, sharedIndex, false);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361311246);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361311246)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656278542)
                    $ctor$1(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex, /*bool*/ useSingleChunking)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38656278542);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._sharedReader = sharedReader;
                            this._sharedIndex = sharedIndex;
                            this._maxChunkSize = useSingleChunking ? 1 : $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader).s_defaultMaxChunkSize;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656278542)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900918798)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900918798);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(85900918798)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 94490853390, 4357619713)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103080787982);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this).Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 94490853390, 4357619713)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605951502)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81605951502);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._localOffset === null)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._currentChunkSize === null, "_currentChunkSize == null");
                            this._localOffset = new ($.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Int32))().$ctor$2(-1);
                            this._currentChunkSize = new ($.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Int32))().$ctor$2(0);
                            this._doublingCountdown = 3/*CHUNK_DOUBLING_RATE*/;
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._currentChunkSize !== null, "_currentChunkSize != null");
                        if (this._localOffset.Value < ((this._currentChunkSize.Value - 1) | 0))
                        {
                            this._localOffset.Value++;
                            return true;
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._localOffset.Value === ((this._currentChunkSize.Value - 1) | 0) || this._currentChunkSize.Value === 0, "_localOffset.Value == _currentChunkSize.Value - 1 || _currentChunkSize.Value == 0");
                            /*int*/ let requestedChunkSize;
                            if (this._currentChunkSize.Value === 0)
                            {
                                requestedChunkSize = 1;
                            }
                            else if (this._doublingCountdown > 0)
                            {
                                requestedChunkSize = this._currentChunkSize.Value;
                            }
                            else 
                            {
                                requestedChunkSize = $.$$.System.Math.Min$4(((this._currentChunkSize.Value * 2) | 0), this._maxChunkSize);
                                this._doublingCountdown = 3/*CHUNK_DOUBLING_RATE*/;
                            }
                            this._doublingCountdown--;
                            $.$$.System.Diagnostics.Debug.Assert$2(requestedChunkSize > 0 && requestedChunkSize <= this._maxChunkSize, "requestedChunkSize > 0 && requestedChunkSize <= _maxChunkSize");
                            if (this.GrabNextChunk(requestedChunkSize))
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(this._currentChunkSize.Value <= requestedChunkSize && this._currentChunkSize.Value > 0, "_currentChunkSize.Value <= requestedChunkSize && _currentChunkSize.Value > 0");
                                this._localOffset.Value = 0;
                                return true;
                            }
                            else 
                            {
                                return false;
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605951502)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944474113)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<long, TSource>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354539521);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944474113)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242521601)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242521601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242521601)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537488897)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537488897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537488897)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066343950)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(90195886094)
                            this.s_defaultMaxChunkSize = $.$scc.System.Collections.Concurrent.Partitioner.GetDefaultChunkSize(TSource);
                            //--TRIMMABLE-BOUNDARY-END(90195886094)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066343950)
                    
                    static $h = 1572878;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310984206),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331908
      },
      "n": "HasNoElementsLeft",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(77310984206),
//--TRIMMABLE-BOUNDARY-START(47246213134),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331905
      },
      "n": "Current",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47246213134),
//--TRIMMABLE-BOUNDARY-START(ALL, 94490853390, 4357619713),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331650
      },
      "n": "{62652417}.Current",
      "o": "System$Collections$IEnumerator$Current",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 94490853390, 4357619713)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73016016910),
    {
      "r": 262145,
      "p": [
        {
          "n": "requestedChunkSize",
          "p": 655361
        }
      ],
      "n": "GrabNextChunk",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(73016016910),
//--TRIMMABLE-BOUNDARY-START(51541180430),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51541180430),
//--TRIMMABLE-BOUNDARY-START(85900918798),
    {
      "r": 65537,
      "n": "Reset",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900918798),
//--TRIMMABLE-BOUNDARY-START(81605951502),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605951502)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771376654),
    {
      "t": TSourceReader?.$h??1572864,
      "n": "_sharedReader",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(25771376654),
//--TRIMMABLE-BOUNDARY-START(90195886094),
    {
      "t": 655361,
      "n": "s_defaultMaxChunkSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 4194340
    },
//--TRIMMABLE-BOUNDARY-END(90195886094),
//--TRIMMABLE-BOUNDARY-START(4296540174),
    {
      "t": $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Int32).$h,
      "n": "_currentChunkSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(4296540174),
//--TRIMMABLE-BOUNDARY-START(12886474766),
    {
      "t": $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Int32).$h,
      "n": "_localOffset",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(12886474766),
//--TRIMMABLE-BOUNDARY-START(42951245838),
    {
      "t": 655361,
      "n": "CHUNK_DOUBLING_RATE",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951245838),
//--TRIMMABLE-BOUNDARY-START(8591507470),
    {
      "t": 655361,
      "n": "_doublingCountdown",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507470),
//--TRIMMABLE-BOUNDARY-START(17181442062),
    {
      "t": 655361,
      "n": "_maxChunkSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(17181442062),
//--TRIMMABLE-BOUNDARY-START(21476409358),
    {
      "t": 2490382,
      "n": "_sharedIndex",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(21476409358)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361311246),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": TSourceReader?.$h??1572864
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(34361311246),
//--TRIMMABLE-BOUNDARY-START(38656278542),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": TSourceReader?.$h??1572864
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        },
        {
          "n": "useSingleChunking",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38656278542)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,90177537,62652417
  ],
  "g": [TSource?.$h??1507328,TSourceReader?.$h??1572864
  ],
  "r": 2,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract<${TSource?.$fullName},${TSourceReader?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionEnumerator_Abstract$$$ = $v))(TSource, TSourceReader);
            }
            //--TRIMMABLE-BOUNDARY-END(1572878)
            
            //--TRIMMABLE-BOUNDARY-START(1900558)
            static $_DynamicPartitionerForIEnumerable$$;
            static DynamicPartitionerForIEnumerable$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionerForIEnumerable$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<>", [TSource], ($self) => class DynamicPartitionerForIEnumerable$$ extends $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4296867854)
                    /*IEnumerable<TSource>*/ _source = null;
                    //--TRIMMABLE-BOUNDARY-END(4296867854)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591835150)
                    /*bool*/ _useSingleChunking = false;
                    //--TRIMMABLE-BOUNDARY-END(8591835150)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802446)
                    $ctor$3(/*IEnumerable<TSource>*/ source, /*EnumerablePartitionerOptions*/ partitionerOptions)
                    {
                        super.$ctor$2(true, false, true);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886802446);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._source = source;
                            this._useSingleChunking = ((partitionerOptions & 1/*EnumerablePartitionerOptions.NoBuffering*/) !== 0);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886802446)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 30066671630, 64425820174)
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066671630);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, partitionCount, "partitionCount");
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))), null, [partitionCount], null);
                        /*var*/ let partitionEnumerable = new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable)().$ctor$1(this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]), this._useSingleChunking, true);
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(partitions, partitionEnumerable.GetEnumerator(), i);
                        }
                        return partitions;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 30066671630, 64425820174)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 25771704334, 60130852878)
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771704334);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable)().$ctor$1(this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]), this._useSingleChunking, false);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 25771704334, 60130852878)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 42951573518, 25772752910)
                    /*bool */ get SupportsDynamicPartitions()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476737038);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 42951573518, 25772752910)
                    
                    //--TRIMMABLE-BOUNDARY-START(1966094)
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$.InternalPartitionEnumerable", ($self) => class InternalPartitionEnumerable extends $.$$.System.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(42951639054)
                            /*IEnumerator<TSource>*/ _sharedReader = null;
                            //--TRIMMABLE-BOUNDARY-END(42951639054)
                            
                            //--TRIMMABLE-BOUNDARY-START(34361704462)
                            /*SharedLong*/ _sharedIndex = null;
                            //--TRIMMABLE-BOUNDARY-END(34361704462)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181835278)
                            /*KeyValuePair<long, TSource>[]?*/ _fillBuffer = null;
                            //--TRIMMABLE-BOUNDARY-END(17181835278)
                            
                            //--TRIMMABLE-BOUNDARY-START(25771769870)
                            /*int*/ _fillBufferSize = 0;
                            //--TRIMMABLE-BOUNDARY-END(25771769870)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476802574)
                            /*int*/ _fillBufferCurrentPosition = 0;
                            //--TRIMMABLE-BOUNDARY-END(21476802574)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296933390)
                            /*int*/ _activeCopiers = 0;
                            //--TRIMMABLE-BOUNDARY-END(4296933390)
                            
                            //--TRIMMABLE-BOUNDARY-START(30066737166)
                            /*SharedBool*/ _hasNoElementsLeft = null;
                            //--TRIMMABLE-BOUNDARY-END(30066737166)
                            
                            //--TRIMMABLE-BOUNDARY-START(47246606350)
                            /*SharedBool*/ _sourceDepleted = null;
                            //--TRIMMABLE-BOUNDARY-END(47246606350)
                            
                            //--TRIMMABLE-BOUNDARY-START(38656671758)
                            /*object*/ _sharedLock = null;
                            //--TRIMMABLE-BOUNDARY-END(38656671758)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886867982)
                            /*bool*/ _disposed = false;
                            //--TRIMMABLE-BOUNDARY-END(12886867982)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591900686)
                            /*SharedInt?*/ _activePartitionCount = null;
                            //--TRIMMABLE-BOUNDARY-END(8591900686)
                            
                            //--TRIMMABLE-BOUNDARY-START(51541573646)
                            /*bool*/ _useSingleChunking = false;
                            //--TRIMMABLE-BOUNDARY-END(51541573646)
                            
                            //--TRIMMABLE-BOUNDARY-START(55836540942)
                            $ctor$1(/*IEnumerator<TSource>*/ sharedReader, /*bool*/ useSingleChunking, /*bool*/ isStaticPartitioning)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(55836540942);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.System.Collections.Concurrent.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                    this._hasNoElementsLeft = new $.$scc.System.Collections.Concurrent.Partitioner.SharedBool().$ctor$1(false);
                                    this._sourceDepleted = new $.$scc.System.Collections.Concurrent.Partitioner.SharedBool().$ctor$1(false);
                                    this._sharedLock = new $.$$.System.Object().$ctor();
                                    this._useSingleChunking = useSingleChunking;
                                    if (!this._useSingleChunking)
                                    {
                                        /*int*/ let fillBufferMultiplier = /*(Environment.ProcessorCount > 4) ? 4 : */ 1;
                                        this._fillBuffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), null, [((fillBufferMultiplier * $.$scc.System.Collections.Concurrent.Partitioner.GetDefaultChunkSize(TSource)) | 0)], null);
                                    }
                                    if (isStaticPartitioning)
                                    {
                                        this._activePartitionCount = new $.$scc.System.Collections.Concurrent.Partitioner.SharedInt().$ctor$1(0);
                                    }
                                    else 
                                    {
                                        this._activePartitionCount = null;
                                    }
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(55836540942)
                            
                            //--TRIMMABLE-BOUNDARY-START(64426475534)
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(64426475534);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                                return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerator)().$ctor$3(this._sharedReader, this._sharedIndex, this._hasNoElementsLeft, this._activePartitionCount, this, this._useSingleChunking);
                            }
                            //--TRIMMABLE-BOUNDARY-END(64426475534)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 81606344718, 4357488641)
                            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(81606344718);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return (this).GetEnumerator();
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 81606344718, 4357488641)
                            
                            //--TRIMMABLE-BOUNDARY-START(85901312014)
                            /*void */ TryCopyFromFillBuffer(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(85901312014);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                actualNumElementsGrabbed.$v = 0;
                                /*KeyValuePair<long, TSource>[]?*/ let fillBufferLocalRef = this._fillBuffer;
                                if (fillBufferLocalRef === null)
                                {
                                    return;
                                }
                                if (this._fillBufferCurrentPosition >= this._fillBufferSize)
                                {
                                    return;
                                }
                                $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._activeCopiers, ($v) => this._activeCopiers = $v, $.$$.System.Int32));
                                /*int*/ let endPos = $.$$.System.Threading.Interlocked.Add($.$ref(() => this._fillBufferCurrentPosition, ($v) => this._fillBufferCurrentPosition = $v, $.$$.System.Int32), requestedChunkSize);
                                /*int*/ let beginPos = ((endPos - requestedChunkSize) | 0);
                                if (beginPos < this._fillBufferSize)
                                {
                                    actualNumElementsGrabbed.$v = (endPos < this._fillBufferSize) ? endPos : ((this._fillBufferSize - beginPos) | 0);
                                    $.$$.System.Array.Copy$2(fillBufferLocalRef, beginPos, destArray, 0, actualNumElementsGrabbed.$v);
                                }
                                $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._activeCopiers, ($v) => this._activeCopiers = $v, $.$$.System.Int32));
                            }
                            //--TRIMMABLE-BOUNDARY-END(85901312014)
                            
                            //--TRIMMABLE-BOUNDARY-START(68721442830)
                            /*bool */ GrabChunk(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(68721442830);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                actualNumElementsGrabbed.$v = 0;
                                if (this._hasNoElementsLeft.Value)
                                {
                                    return false;
                                }
                                if (this._useSingleChunking)
                                {
                                    return this.GrabChunk_Single(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                }
                                else 
                                {
                                    return this.GrabChunk_Buffered(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(68721442830)
                            
                            //--TRIMMABLE-BOUNDARY-START(77311377422)
                            /*bool */ GrabChunk_Single(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(77311377422);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                $.$$.System.Diagnostics.Debug.Assert$2(this._useSingleChunking, "Expected _useSingleChecking to be true");
                                $.$$.System.Diagnostics.Debug.Assert$4(requestedChunkSize === 1, `Got requested chunk size of ${requestedChunkSize} when single-chunking was on`);
                                $.$$.System.Diagnostics.Debug.Assert$4(actualNumElementsGrabbed.$v === 0, `Expected actualNumElementsGrabbed == 0, instead it is ${actualNumElementsGrabbed.$v}`);
                                $.$$.System.Diagnostics.Debug.Assert$4(destArray.length === 1, `Expected destArray to be of length 1, instead its length is ${destArray.length}`);
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(this._sharedLock)
                                    {
                                        if (this._hasNoElementsLeft.Value)
                                        {
                                            return false;
                                        }
                                        try
                                        {
                                            if (this._sharedReader.System$Collections$IEnumerator$MoveNext())
                                            {
                                                this._sharedIndex.Value = this._sharedIndex.Value + 1n;
                                                $.$$.System.Array.$WriteT1.call(destArray, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.System$Collections$Generic$IEnumerator$$$Current), 0);
                                                actualNumElementsGrabbed.$v = 1;
                                                return true;
                                            }
                                            else 
                                            {
                                                this._sourceDepleted.Value = true;
                                                this._hasNoElementsLeft.Value = true;
                                                return false;
                                            }
                                        }
                                        catch($e)
                                        {
                                            this._sourceDepleted.Value = true;
                                            this._hasNoElementsLeft.Value = true;
                                            throw $e;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(this._sharedLock)
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(77311377422)
                            
                            //--TRIMMABLE-BOUNDARY-START(73016410126)
                            /*bool */ GrabChunk_Buffered(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(73016410126);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                $.$$.System.Diagnostics.Debug.Assert$2(requestedChunkSize > 0, "requestedChunkSize > 0");
                                $.$$.System.Diagnostics.Debug.Assert$2(!this._useSingleChunking, "Did not expect to be in single-chunking mode");
                                this.TryCopyFromFillBuffer(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                if (actualNumElementsGrabbed.$v === requestedChunkSize)
                                {
                                    return true;
                                }
                                else if (this._sourceDepleted.Value)
                                {
                                    this._hasNoElementsLeft.Value = true;
                                    this._fillBuffer = null;
                                    return (actualNumElementsGrabbed.$v > 0);
                                }
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(this._sharedLock)
                                    {
                                        if (this._sourceDepleted.Value)
                                        {
                                            return (actualNumElementsGrabbed.$v > 0);
                                        }
                                        try
                                        {
                                            if (this._activeCopiers > 0)
                                            {
                                                /*SpinWait*/ let sw = new $.$$.System.Threading.SpinWait();
                                                while(this._activeCopiers > 0)
                                                {
                                                    sw.SpinOnce();
                                                }
                                            }
                                            $.$$.System.Diagnostics.Debug.Assert$2(this._sharedIndex !== null, "_sharedIndex != null");
                                            for(; actualNumElementsGrabbed.$v < requestedChunkSize; actualNumElementsGrabbed.$v++)
                                            {
                                                if (this._sharedReader.System$Collections$IEnumerator$MoveNext())
                                                {
                                                    this._sharedIndex.Value = this._sharedIndex.Value + 1n;
                                                    $.$$.System.Array.$WriteT1.call(destArray, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.System$Collections$Generic$IEnumerator$$$Current), actualNumElementsGrabbed.$v);
                                                }
                                                else 
                                                {
                                                    this._sourceDepleted.Value = true;
                                                    break;
                                                }
                                            }
                                            /*var*/ let localFillBufferRef = this._fillBuffer;
                                            if (this._sourceDepleted.Value === false && localFillBufferRef !== null && this._fillBufferCurrentPosition >= localFillBufferRef.length)
                                            {
                                                for(/*int*/ let i = 0; i < localFillBufferRef.length; i++)
                                                {
                                                    if (this._sharedReader.System$Collections$IEnumerator$MoveNext())
                                                    {
                                                        this._sharedIndex.Value = this._sharedIndex.Value + 1n;
                                                        $.$$.System.Array.$WriteT1.call(localFillBufferRef, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.System$Collections$Generic$IEnumerator$$$Current), i);
                                                    }
                                                    else 
                                                    {
                                                        this._sourceDepleted.Value = true;
                                                        this._fillBufferSize = i;
                                                        break;
                                                    }
                                                }
                                                this._fillBufferCurrentPosition = 0;
                                            }
                                        }
                                        catch($e)
                                        {
                                            this._sourceDepleted.Value = true;
                                            this._hasNoElementsLeft.Value = true;
                                            throw $e;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(this._sharedLock)
                                }
                                return (actualNumElementsGrabbed.$v > 0);
                            }
                            //--TRIMMABLE-BOUNDARY-END(73016410126)
                            
                            //--TRIMMABLE-BOUNDARY-START(60131508238)
                            /*void */ Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(60131508238);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (!this._disposed)
                                {
                                    this._disposed = true;
                                    this._sharedReader.System$IDisposable$Dispose();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(60131508238)
                            
                            //--TRIMMABLE-BOUNDARY-START(4354473985)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            System$Collections$Generic$IEnumerable$$$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354473985);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.GetEnumerator(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4354473985)
                            
                            //--TRIMMABLE-BOUNDARY-START(4385144833)
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4385144833);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Dispose(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4385144833)
                            
                            static $h = 1966094;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426475534),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "GetEnumerator",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426475534),
//--TRIMMABLE-BOUNDARY-START(85901312014),
    {
      "r": 65537,
      "p": [
        {
          "n": "destArray",
          "p": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h
        },
        {
          "n": "requestedChunkSize",
          "p": 655361
        },
        {
          "n": "actualNumElementsGrabbed",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "TryCopyFromFillBuffer",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901312014),
//--TRIMMABLE-BOUNDARY-START(68721442830),
    {
      "r": 262145,
      "p": [
        {
          "n": "destArray",
          "p": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h
        },
        {
          "n": "requestedChunkSize",
          "p": 655361
        },
        {
          "n": "actualNumElementsGrabbed",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "GrabChunk",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x1000000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68721442830),
//--TRIMMABLE-BOUNDARY-START(77311377422),
    {
      "r": 262145,
      "p": [
        {
          "n": "destArray",
          "p": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h
        },
        {
          "n": "requestedChunkSize",
          "p": 655361
        },
        {
          "n": "actualNumElementsGrabbed",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "GrabChunk_Single",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x1200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77311377422),
//--TRIMMABLE-BOUNDARY-START(73016410126),
    {
      "r": 262145,
      "p": [
        {
          "n": "destArray",
          "p": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h
        },
        {
          "n": "requestedChunkSize",
          "p": 655361
        },
        {
          "n": "actualNumElementsGrabbed",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "GrabChunk_Buffered",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x1100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73016410126),
//--TRIMMABLE-BOUNDARY-START(60131508238),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131508238)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951639054),
    {
      "t": $.$$.System.Collections.Generic.IEnumerator$$(TSource).$h,
      "n": "_sharedReader",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951639054),
//--TRIMMABLE-BOUNDARY-START(34361704462),
    {
      "t": 2490382,
      "n": "_sharedIndex",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361704462),
//--TRIMMABLE-BOUNDARY-START(17181835278),
    {
      "t": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "_fillBuffer",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181835278),
//--TRIMMABLE-BOUNDARY-START(25771769870),
    {
      "t": 655361,
      "n": "_fillBufferSize",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771769870),
//--TRIMMABLE-BOUNDARY-START(21476802574),
    {
      "t": 655361,
      "n": "_fillBufferCurrentPosition",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476802574),
//--TRIMMABLE-BOUNDARY-START(4296933390),
    {
      "t": 655361,
      "n": "_activeCopiers",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933390),
//--TRIMMABLE-BOUNDARY-START(30066737166),
    {
      "t": 2359310,
      "n": "_hasNoElementsLeft",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066737166),
//--TRIMMABLE-BOUNDARY-START(47246606350),
    {
      "t": 2359310,
      "n": "_sourceDepleted",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0xB00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47246606350),
//--TRIMMABLE-BOUNDARY-START(38656671758),
    {
      "t": 131073,
      "n": "_sharedLock",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656671758),
//--TRIMMABLE-BOUNDARY-START(12886867982),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886867982),
//--TRIMMABLE-BOUNDARY-START(8591900686),
    {
      "t": 2424846,
      "n": "_activePartitionCount",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591900686),
//--TRIMMABLE-BOUNDARY-START(51541573646),
    {
      "t": 262145,
      "n": "_useSingleChunking",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0xC00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51541573646)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55836540942),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$$.System.Collections.Generic.IEnumerator$$(TSource).$h
        },
        {
          "n": "useSingleChunking",
          "p": 262145
        },
        {
          "n": "isStaticPartitioning",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1966094,
      "h": Number(BigInt(1966094)|0xD00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55836540942)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,62521345,90177537
  ],
  "d": $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).$h,
  "h": 1966094
}; }
                            static get $b() { return $.$$.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.Collections.IEnumerable, $.$$.System.IDisposable ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<${TSource?.$fullName}>.InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1966094)
                    
                    //--TRIMMABLE-BOUNDARY-START(2031630)
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$.InternalPartitionEnumerator", ($self) => class InternalPartitionEnumerator extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, $.$$.System.Collections.Generic.IEnumerator$$(TSource))
                        {
                            //--TRIMMABLE-BOUNDARY-START(17181900814)
                            /*KeyValuePair<long, TSource>[]?*/ _localList = null;
                            //--TRIMMABLE-BOUNDARY-END(17181900814)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886933518)
                            /*SharedBool*/ _hasNoElementsLeft = null;
                            //--TRIMMABLE-BOUNDARY-END(12886933518)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296998926)
                            /*SharedInt?*/ _activePartitionCount = null;
                            //--TRIMMABLE-BOUNDARY-END(4296998926)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591966222)
                            /*InternalPartitionEnumerable*/ _enumerable = null;
                            //--TRIMMABLE-BOUNDARY-END(8591966222)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476868110)
                            $ctor$3(/*IEnumerator<TSource>*/ sharedReader, /*SharedLong*/ sharedIndex, /*SharedBool*/ hasNoElementsLeft, /*SharedInt?*/ activePartitionCount, /*InternalPartitionEnumerable*/ enumerable, /*bool*/ useSingleChunking)
                            {
                                super.$ctor$1(sharedReader, sharedIndex, useSingleChunking);
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(21476868110);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._hasNoElementsLeft = hasNoElementsLeft;
                                    this._enumerable = enumerable;
                                    this._activePartitionCount = activePartitionCount;
                                    if (this._activePartitionCount !== null)
                                    {
                                        $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._activePartitionCount.Value, ($v) => this._activePartitionCount.Value = $v, $.$$.System.Int32));
                                    }
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476868110)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 51541639182, 73016016910)
                            /*bool */ GrabNextChunk(/*int*/ requestedChunkSize)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(51541639182);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                $.$$.System.Diagnostics.Debug.Assert$2(requestedChunkSize > 0, "requestedChunkSize > 0");
                                if (this.HasNoElementsLeft)
                                {
                                    return false;
                                }
                                this._localList ??= $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), null, [this._maxChunkSize], null);
                                return this._enumerable.GrabChunk(this._localList, requestedChunkSize, $.$ref(() => this._currentChunkSize.Value, ($v) => this._currentChunkSize.Value = $v, $.$$.System.Int32));
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 51541639182, 73016016910)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 55836606478, 77310984206)
                            /*bool */ get HasNoElementsLeft()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(47246671886);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._hasNoElementsLeft.Value;
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 55836606478, 77310984206)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 25771835406, 47246213134)
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(38656737294);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.System.Diagnostics.Debug.Assert$2(this._localList !== null, "_localList != null");
                                $.$$.System.Diagnostics.Debug.Assert$2(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return ($.$$.System.Array.$ReadT1.call(this._localList, this._localOffset.Value));
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 25771835406, 47246213134)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 30066802702, 51541180430)
                            /*void */ Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(30066802702);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._activePartitionCount !== null && $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._activePartitionCount.Value, ($v) => this._activePartitionCount.Value = $v, $.$$.System.Int32)) === 0)
                                {
                                    this._enumerable.Dispose();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 30066802702, 51541180430)
                            
                            static $h = 2031630;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1572878,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 55836606478, 77310984206),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2031630)|0xB00000000n),
        "f": 50364420
      },
      "n": "HasNoElementsLeft",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0xD00000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55836606478, 77310984206),
//--TRIMMABLE-BOUNDARY-START(ALL, 25771835406, 47246213134),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2031630)|0x900000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771835406, 47246213134)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 51541639182, 73016016910),
    {
      "r": 262145,
      "p": [
        {
          "n": "requestedChunkSize",
          "p": 655361
        }
      ],
      "n": "GrabNextChunk",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51541639182, 73016016910),
//--TRIMMABLE-BOUNDARY-START(ALL, 30066802702, 51541180430),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066802702, 51541180430)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181900814),
    {
      "t": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "_localList",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181900814),
//--TRIMMABLE-BOUNDARY-START(12886933518),
    {
      "t": 2359310,
      "n": "_hasNoElementsLeft",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886933518),
//--TRIMMABLE-BOUNDARY-START(4296998926),
    {
      "t": 2424846,
      "n": "_activePartitionCount",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296998926),
//--TRIMMABLE-BOUNDARY-START(8591966222),
    {
      "t": 1966094,
      "n": "_enumerable",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591966222)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476868110),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$$.System.Collections.Generic.IEnumerator$$(TSource).$h
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        },
        {
          "n": "hasNoElementsLeft",
          "p": 2359310
        },
        {
          "n": "activePartitionCount",
          "p": 2424846
        },
        {
          "n": "enumerable",
          "p": 1966094
        },
        {
          "n": "useSingleChunking",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2031630,
      "h": Number(BigInt(2031630)|0x500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476868110)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,90177537,62652417
  ],
  "d": $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).$h,
  "h": 2031630
}; }
                            static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, $.$$.System.Collections.Generic.IEnumerator$$(TSource)); }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<${TSource?.$fullName}>.InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(2031630)
                    
                    static $h = 1900558;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 42951573518, 25772752910),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364417
      },
      "n": "SupportsDynamicPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42951573518, 25772752910)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 30066671630, 64425820174),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetOrderablePartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066671630, 64425820174),
//--TRIMMABLE-BOUNDARY-START(ALL, 25771704334, 60130852878),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "GetOrderableDynamicPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771704334, 60130852878)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867854),
    {
      "t": $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h,
      "n": "_source",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867854),
//--TRIMMABLE-BOUNDARY-START(8591835150),
    {
      "t": 262145,
      "n": "_useSingleChunking",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835150)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886802446),
    {
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        },
        {
          "n": "partitionerOptions",
          "p": 1114126
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886802446)
  ],
  "g": [TSource?.$h??1507328
  ],
  "j": [1966094,2031630
  ],
  "r": 1,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIEnumerable$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(1900558)
            
            //--TRIMMABLE-BOUNDARY-START(2293774)
            static $_DynamicPartitionerForIndexRange_Abstract$$$;
            static DynamicPartitionerForIndexRange_Abstract$$$(TSource, TCollection)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionerForIndexRange_Abstract$$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract<,>", (TSource, TCollection) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract<,>", [TSource, TCollection], ($self) => class DynamicPartitionerForIndexRange_Abstract$$$ extends $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297261070)
                    /*TCollection*/ _data = $.$default(TCollection);
                    //--TRIMMABLE-BOUNDARY-END(4297261070)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592228366)
                    $ctor$3(/*TCollection*/ data)
                    {
                        super.$ctor$2(true, false, true);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592228366);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._data = data;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592228366)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 30067064846, 64425820174)
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067064846);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, partitionCount, "partitionCount");
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))), null, [partitionCount], null);
                        /*IEnumerable<KeyValuePair<long, TSource>>*/ let partitionEnumerable = this.GetOrderableDynamicPartitions_Factory(this._data);
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(partitions, partitionEnumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)]), i);
                        }
                        return partitions;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 30067064846, 64425820174)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 21477130254, 60130852878)
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477130254);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetOrderableDynamicPartitions_Factory(this._data);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 21477130254, 60130852878)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 34362032142, 25772752910)
                    /*bool */ get SupportsDynamicPartitions()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17182162958);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 34362032142, 25772752910)
                    
                    static $h = 2293774;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 34362032142, 25772752910),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50364417
      },
      "n": "SupportsDynamicPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34362032142, 25772752910)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772097550),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "p": [
        {
          "n": "data",
          "p": TCollection?.$h??1572864
        }
      ],
      "n": "GetOrderableDynamicPartitions_Factory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(25772097550),
//--TRIMMABLE-BOUNDARY-START(ALL, 30067064846, 64425820174),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetOrderablePartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30067064846, 64425820174),
//--TRIMMABLE-BOUNDARY-START(ALL, 21477130254, 60130852878),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "GetOrderableDynamicPartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21477130254, 60130852878)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297261070),
    {
      "t": TCollection?.$h??1572864,
      "n": "_data",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297261070)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592228366),
    {
      "p": [
        {
          "n": "data",
          "p": TCollection?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8592228366)
  ],
  "g": [TSource?.$h??1507328,TCollection?.$h??1572864
  ],
  "r": 2,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract<${TSource?.$fullName},${TCollection?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIndexRange_Abstract$$$ = $v))(TSource, TCollection);
            }
            //--TRIMMABLE-BOUNDARY-END(2293774)
            
            //--TRIMMABLE-BOUNDARY-START(1638414)
            static $_DynamicPartitionEnumeratorForIndexRange_Abstract$$$;
            static DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, TSourceReader)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionEnumeratorForIndexRange_Abstract$$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract<,>", (TSource, TSourceReader) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract<,>", [TSource, TSourceReader], ($self) => class DynamicPartitionEnumeratorForIndexRange_Abstract$$$ extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader)
                {
                    //--TRIMMABLE-BOUNDARY-START(4296605710)
                    /*int*/ _startIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(4296605710)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591573006)
                    $ctor$3(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex)
                    {
                        super.$ctor$2(sharedReader, sharedIndex);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591573006);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591573006)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 34361376782, 73016016910)
                    /*bool */ GrabNextChunk(/*int*/ requestedChunkSize)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34361376782);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(requestedChunkSize > 0, "requestedChunkSize > 0");
                        while(!this.HasNoElementsLeft)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._sharedIndex !== null, "_sharedIndex != null");
                            /*long*/ let oldSharedIndex = $.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.System.Int64).$v;
                            if (this.HasNoElementsLeft)
                            {
                                return false;
                            }
                            /*long*/ let newSharedIndex = $.$$.System.Math.Min$5(BigInt(this.SourceCount - 1), oldSharedIndex + BigInt(requestedChunkSize));
                            if ($.$$.System.Threading.Interlocked.CompareExchange$4($.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.System.Int64), newSharedIndex, oldSharedIndex) === oldSharedIndex)
                            {
                                this._currentChunkSize.Value = $.$cast((newSharedIndex - oldSharedIndex), $.$$.System.Int32);
                                this._localOffset.Value = -1;
                                this._startIndex = $.$cast((oldSharedIndex + 1n), $.$$.System.Int32);
                                return true;
                            }
                        }
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 34361376782, 73016016910)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 38656344078, 77310984206)
                    /*bool */ get HasNoElementsLeft()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476474894);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this._sharedIndex !== null, "_sharedIndex != null");
                        return $.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.System.Int64).$v >= BigInt(this.SourceCount - 1);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 38656344078, 77310984206)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 12886540302, 51541180430)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886540302);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 12886540302, 51541180430)
                    
                    static $h = 1638414;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951311374),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331908
      },
      "n": "SourceCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(42951311374),
//--TRIMMABLE-BOUNDARY-START(ALL, 38656344078, 77310984206),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364420
      },
      "n": "HasNoElementsLeft",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38656344078, 77310984206)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 34361376782, 73016016910),
    {
      "r": 262145,
      "p": [
        {
          "n": "requestedChunkSize",
          "p": 655361
        }
      ],
      "n": "GrabNextChunk",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34361376782, 73016016910),
//--TRIMMABLE-BOUNDARY-START(ALL, 12886540302, 51541180430),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886540302, 51541180430)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296605710),
    {
      "t": 655361,
      "n": "_startIndex",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(4296605710)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591573006),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": TSourceReader?.$h??1572864
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591573006)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,90177537,62652417
  ],
  "g": [TSource?.$h??1507328,TSourceReader?.$h??1572864
  ],
  "r": 2,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract<${TSource?.$fullName},${TSourceReader?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionEnumeratorForIndexRange_Abstract$$$ = $v))(TSource, TSourceReader);
            }
            //--TRIMMABLE-BOUNDARY-END(1638414)
            
            //--TRIMMABLE-BOUNDARY-START(2097166)
            static $_DynamicPartitionerForIList$$;
            static DynamicPartitionerForIList$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionerForIList$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<>", [TSource], ($self) => class DynamicPartitionerForIList$$ extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource))
                {
                    //--TRIMMABLE-BOUNDARY-START(4297064462)
                    $ctor$4(/*IList<TSource>*/ source)
                    {
                        super.$ctor$3(source);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297064462);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297064462)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 8592031758, 25772097550)
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions_Factory(/*IList<TSource>*/ _data)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592031758);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerable)().$ctor$1(_data);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 8592031758, 25772097550)
                    
                    //--TRIMMABLE-BOUNDARY-START(2162702)
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$.InternalPartitionEnumerable", ($self) => class InternalPartitionEnumerable extends $.$$.System.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(8592097294)
                            /*IList<TSource>*/ _sharedReader = null;
                            //--TRIMMABLE-BOUNDARY-END(8592097294)
                            
                            //--TRIMMABLE-BOUNDARY-START(4297129998)
                            /*SharedLong*/ _sharedIndex = null;
                            //--TRIMMABLE-BOUNDARY-END(4297129998)
                            
                            //--TRIMMABLE-BOUNDARY-START(12887064590)
                            $ctor$1(/*IList<TSource>*/ sharedReader)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12887064590);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.System.Collections.Concurrent.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12887064590)
                            
                            //--TRIMMABLE-BOUNDARY-START(17182031886)
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17182031886);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerator)().$ctor$4(this._sharedReader, this._sharedIndex);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17182031886)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 21476999182, 4357488641)
                            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21476999182);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return (this).GetEnumerator();
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 21476999182, 4357488641)
                            
                            //--TRIMMABLE-BOUNDARY-START(4354473985)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            System$Collections$Generic$IEnumerable$$$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354473985);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.GetEnumerator(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4354473985)
                            
                            static $h = 2162702;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182031886),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "GetEnumerator",
      "d": 2162702,
      "h": Number(BigInt(2162702)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182031886)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592097294),
    {
      "t": $.$$.System.Collections.Generic.IList$$(TSource).$h,
      "n": "_sharedReader",
      "d": 2162702,
      "h": Number(BigInt(2162702)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097294),
//--TRIMMABLE-BOUNDARY-START(4297129998),
    {
      "t": 2490382,
      "n": "_sharedIndex",
      "d": 2162702,
      "h": Number(BigInt(2162702)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297129998)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887064590),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$$.System.Collections.Generic.IList$$(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162702,
      "h": Number(BigInt(2162702)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12887064590)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,62521345
  ],
  "d": $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).$h,
  "h": 2162702
}; }
                            static get $b() { return $.$$.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.Collections.IEnumerable ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<${TSource?.$fullName}>.InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(2162702)
                    
                    //--TRIMMABLE-BOUNDARY-START(2228238)
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$.InternalPartitionEnumerator", ($self) => class InternalPartitionEnumerator extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource))
                        {
                            //--TRIMMABLE-BOUNDARY-START(4297195534)
                            $ctor$4(/*IList<TSource>*/ sharedReader, /*SharedLong*/ sharedIndex)
                            {
                                super.$ctor$3(sharedReader, sharedIndex);
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(4297195534);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4297195534)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 30066999310, 42951311374)
                            /*int */ get SourceCount()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(25772032014);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._sharedReader.System$Collections$Generic$ICollection$$$Count;
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 30066999310, 42951311374)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 8592162830, 47246213134)
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17182097422);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.System.Diagnostics.Debug.Assert$2(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(BigInt(this._startIndex + this._localOffset.Value), this._sharedReader.System$Collections$Generic$IList$$$get_Item(((this._startIndex + this._localOffset.Value) | 0), [TSource]));
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 8592162830, 47246213134)
                            
                            static $h = 2228238;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1638414,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 30066999310, 42951311374),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2228238)|0x600000000n),
        "f": 50364420
      },
      "n": "SourceCount",
      "d": 2228238,
      "h": Number(BigInt(2228238)|0x700000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066999310, 42951311374),
//--TRIMMABLE-BOUNDARY-START(ALL, 8592162830, 47246213134),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2228238)|0x400000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": 2228238,
      "h": Number(BigInt(2228238)|0x200000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8592162830, 47246213134)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195534),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$$.System.Collections.Generic.IList$$(TSource).$h
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2228238,
      "h": Number(BigInt(2228238)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297195534)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,90177537,62652417
  ],
  "d": $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).$h,
  "h": 2228238
}; }
                            static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource)); }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<${TSource?.$fullName}>.InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(2228238)
                    
                    static $h = 2097166;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2293774,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8592031758, 25772097550),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "p": [
        {
          "n": "_data",
          "p": $.$$.System.Collections.Generic.IList$$(TSource).$h
        }
      ],
      "n": "GetOrderableDynamicPartitions_Factory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8592031758, 25772097550)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064462),
    {
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IList$$(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297064462)
  ],
  "g": [TSource?.$h??1507328
  ],
  "j": [2162702,2228238
  ],
  "r": 1,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource)); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIList$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2097166)
            
            //--TRIMMABLE-BOUNDARY-START(1703950)
            static $_DynamicPartitionerForArray$$;
            static DynamicPartitionerForArray$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionerForArray$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<>", [TSource], ($self) => class DynamicPartitionerForArray$$ extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource))
                {
                    //--TRIMMABLE-BOUNDARY-START(4296671246)
                    $ctor$4(/*TSource[]*/ source)
                    {
                        super.$ctor$3(source);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296671246);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296671246)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 8591638542, 25772097550)
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions_Factory(/*TSource[]*/ _data)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591638542);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerable)().$ctor$1(_data);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 8591638542, 25772097550)
                    
                    //--TRIMMABLE-BOUNDARY-START(1769486)
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$.InternalPartitionEnumerable", ($self) => class InternalPartitionEnumerable extends $.$$.System.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591704078)
                            /*TSource[]*/ _sharedReader = null;
                            //--TRIMMABLE-BOUNDARY-END(8591704078)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296736782)
                            /*SharedLong*/ _sharedIndex = null;
                            //--TRIMMABLE-BOUNDARY-END(4296736782)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886671374)
                            $ctor$1(/*TSource[]*/ sharedReader)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12886671374);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.System.Collections.Concurrent.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886671374)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 21476605966, 4357488641)
                            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21476605966);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return (this).GetEnumerator();
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 21476605966, 4357488641)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181638670)
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17181638670);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerator)().$ctor$4(this._sharedReader, this._sharedIndex);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181638670)
                            
                            //--TRIMMABLE-BOUNDARY-START(4354473985)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            System$Collections$Generic$IEnumerable$$$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354473985);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.GetEnumerator(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4354473985)
                            
                            static $h = 1769486;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181638670),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "n": "GetEnumerator",
      "d": 1769486,
      "h": Number(BigInt(1769486)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181638670)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591704078),
    {
      "t": $.$typeArray(TSource).$h,
      "n": "_sharedReader",
      "d": 1769486,
      "h": Number(BigInt(1769486)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704078),
//--TRIMMABLE-BOUNDARY-START(4296736782),
    {
      "t": 2490382,
      "n": "_sharedIndex",
      "d": 1769486,
      "h": Number(BigInt(1769486)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736782)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886671374),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$typeArray(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769486,
      "h": Number(BigInt(1769486)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886671374)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,62521345
  ],
  "d": $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).$h,
  "h": 1769486
}; }
                            static get $b() { return $.$$.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.Collections.IEnumerable ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<${TSource?.$fullName}>.InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1769486)
                    
                    //--TRIMMABLE-BOUNDARY-START(1835022)
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$.InternalPartitionEnumerator", ($self) => class InternalPartitionEnumerator extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource))
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296802318)
                            $ctor$4(/*TSource[]*/ sharedReader, /*SharedLong*/ sharedIndex)
                            {
                                super.$ctor$3(sharedReader, sharedIndex);
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(4296802318);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296802318)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 30066606094, 42951311374)
                            /*int */ get SourceCount()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(25771638798);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._sharedReader.length;
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 30066606094, 42951311374)
                            
                            //--TRIMMABLE-BOUNDARY-START(ALL, 8591769614, 47246213134)
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17181704206);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.System.Diagnostics.Debug.Assert$2(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(BigInt(this._startIndex + this._localOffset.Value), $.$$.System.Array.$ReadT1.call(this._sharedReader, ((this._startIndex + this._localOffset.Value) | 0)));
                            }
                            //--TRIMMABLE-BOUNDARY-END(ALL, 8591769614, 47246213134)
                            
                            static $h = 1835022;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1638414,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 30066606094, 42951311374),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1835022)|0x600000000n),
        "f": 50364420
      },
      "n": "SourceCount",
      "d": 1835022,
      "h": Number(BigInt(1835022)|0x700000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066606094, 42951311374),
//--TRIMMABLE-BOUNDARY-START(ALL, 8591769614, 47246213134),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1835022)|0x400000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": 1835022,
      "h": Number(BigInt(1835022)|0x200000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8591769614, 47246213134)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802318),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$typeArray(TSource).$h
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1835022,
      "h": Number(BigInt(1835022)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296802318)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,90177537,62652417
  ],
  "d": $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).$h,
  "h": 1835022
}; }
                            static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource)); }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<${TSource?.$fullName}>.InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1835022)
                    
                    static $h = 1703950;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2293774,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8591638542, 25772097550),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "p": [
        {
          "n": "_data",
          "p": $.$typeArray(TSource).$h
        }
      ],
      "n": "GetOrderableDynamicPartitions_Factory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8591638542, 25772097550)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671246),
    {
      "p": [
        {
          "n": "source",
          "p": $.$typeArray(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296671246)
  ],
  "g": [TSource?.$h??1507328
  ],
  "j": [1769486,1835022
  ],
  "r": 1,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource)); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForArray$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(1703950)
            
            //--TRIMMABLE-BOUNDARY-START(2621454)
            static $_StaticIndexRangePartitioner$$$;
            static StaticIndexRangePartitioner$$$(TSource, TCollection)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitioner$$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner<,>", (TSource, TCollection) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner<,>", [TSource, TCollection], ($self) => class StaticIndexRangePartitioner$$$ extends $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297588750)
                    $ctor$3()
                    {
                        super.$ctor$2(true, true, true);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297588750);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297588750)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 21477457934, 64425820174)
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477457934);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, partitionCount, "partitionCount");
                        const { Item1: quotient, Item2: remainder } = $.$$.System.Math.DivRem$3(this.SourceCount, partitionCount);
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))), null, [partitionCount], null);
                        /*int*/ let lastEndIndex = -1;
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            /*int*/ let startIndex = ((lastEndIndex + 1) | 0);
                            if (i < remainder)
                            {
                                lastEndIndex = ((startIndex + quotient) | 0);
                            }
                            else 
                            {
                                lastEndIndex = ((((startIndex + quotient) | 0) - 1) | 0);
                            }
                            $.$$.System.Array.$WriteT1.call(partitions, this.CreatePartition(startIndex, lastEndIndex), i);
                        }
                        return partitions;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 21477457934, 64425820174)
                    
                    static $h = 2621454;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772425230),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331908
      },
      "n": "SourceCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(25772425230)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592556046),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "CreatePartition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8592556046),
//--TRIMMABLE-BOUNDARY-START(ALL, 21477457934, 64425820174),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetOrderablePartitions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21477457934, 64425820174)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297588750),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297588750)
  ],
  "g": [TSource?.$h??1507328,TCollection?.$h??1572864
  ],
  "r": 2,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner<${TSource?.$fullName},${TCollection?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitioner$$$ = $v))(TSource, TCollection);
            }
            //--TRIMMABLE-BOUNDARY-END(2621454)
            
            //--TRIMMABLE-BOUNDARY-START(2555918)
            static $_StaticIndexRangePartition$$;
            static StaticIndexRangePartition$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartition$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition<>", [TSource], ($self) => class StaticIndexRangePartition$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12887457806)
                    /*int*/ _startIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(12887457806)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297523214)
                    /*int*/ _endIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(4297523214)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592490510)
                    /*int*/ _offset = 0;
                    //--TRIMMABLE-BOUNDARY-END(8592490510)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182425102)
                    $ctor$1(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182425102);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._startIndex = startIndex;
                            this._endIndex = endIndex;
                            this._offset = ((startIndex - 1) | 0);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182425102)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772359694)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772359694);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772359694)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952228878)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42952228878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952228878)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657261582)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657261582);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._offset < this._endIndex)
                        {
                            this._offset++;
                            return true;
                        }
                        else 
                        {
                            this._offset = ((this._endIndex + 1) | 0);
                            return false;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657261582)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 47247196174, 4357619713)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55837130766);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this).Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 47247196174, 4357619713)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944474113)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<long, TSource>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354539521);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944474113)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242521601)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242521601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242521601)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537488897)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537488897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537488897)
                    
                    static $h = 2555918;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477392398),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331905
      },
      "n": "Current",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21477392398),
//--TRIMMABLE-BOUNDARY-START(ALL, 47247196174, 4357619713),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331650
      },
      "n": "{62652417}.Current",
      "o": "System$Collections$IEnumerator$Current",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47247196174, 4357619713)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772359694),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772359694),
//--TRIMMABLE-BOUNDARY-START(42952228878),
    {
      "r": 65537,
      "n": "Reset",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952228878),
//--TRIMMABLE-BOUNDARY-START(38657261582),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657261582)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887457806),
    {
      "t": 655361,
      "n": "_startIndex",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(12887457806),
//--TRIMMABLE-BOUNDARY-START(4297523214),
    {
      "t": 655361,
      "n": "_endIndex",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(4297523214),
//--TRIMMABLE-BOUNDARY-START(8592490510),
    {
      "t": 655361,
      "n": "_offset",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(8592490510)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182425102),
    {
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17182425102)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,90177537,62652417
  ],
  "g": [TSource?.$h??1507328
  ],
  "r": 1,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartition<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartition$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2555918)
            
            //--TRIMMABLE-BOUNDARY-START(2752526)
            static $_StaticIndexRangePartitionerForIList$$;
            static StaticIndexRangePartitionerForIList$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitionerForIList$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForIList<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForIList<>", [TSource], ($self) => class StaticIndexRangePartitionerForIList$$ extends $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource))
                {
                    //--TRIMMABLE-BOUNDARY-START(4297719822)
                    /*IList<TSource>*/ _list = null;
                    //--TRIMMABLE-BOUNDARY-END(4297719822)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592687118)
                    $ctor$4(/*IList<TSource>*/ list)
                    {
                        super.$ctor$3();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592687118);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2(list !== null, "list != null");
                            this._list = list;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592687118)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 25772556302, 25772425230)
                    /*int */ get SourceCount()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477589006);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._list.System$Collections$Generic$ICollection$$$Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 25772556302, 25772425230)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 12887654414, 8592556046)
                    /*IEnumerator<KeyValuePair<long, TSource>> */ CreatePartition(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887654414);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForIList$$(TSource))().$ctor$2(this._list, startIndex, endIndex);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 12887654414, 8592556046)
                    
                    static $h = 2752526;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2621454,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 25772556302, 25772425230),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364420
      },
      "n": "SourceCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25772556302, 25772425230)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12887654414, 8592556046),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "CreatePartition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12887654414, 8592556046)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297719822),
    {
      "t": $.$$.System.Collections.Generic.IList$$(TSource).$h,
      "n": "_list",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297719822)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592687118),
    {
      "p": [
        {
          "n": "list",
          "p": $.$$.System.Collections.Generic.IList$$(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592687118)
  ],
  "g": [TSource?.$h??1507328
  ],
  "r": 1,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource)); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForIList<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionerForIList$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2752526)
            
            //--TRIMMABLE-BOUNDARY-START(2883598)
            static $_StaticIndexRangePartitionForIList$$;
            static StaticIndexRangePartitionForIList$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitionForIList$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForIList<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForIList<>", [TSource], ($self) => class StaticIndexRangePartitionForIList$$ extends $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297850894)
                    /*IList<TSource>*/ _list = null;
                    //--TRIMMABLE-BOUNDARY-END(4297850894)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592818190)
                    $ctor$2(/*IList<TSource>*/ list, /*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor$1(startIndex, endIndex);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592818190);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2(startIndex >= 0 && endIndex <= ((list.System$Collections$Generic$ICollection$$$Count - 1) | 0), "startIndex >= 0 && endIndex <= list.Count - 1");
                            this._list = list;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592818190)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 12887785486, 21477392398)
                    /*KeyValuePair<long, TSource> */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477720078);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._offset < this._startIndex)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._offset >= this._startIndex && this._offset <= this._endIndex, "_offset >= _startIndex && _offset <= _endIndex");
                        return (new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(BigInt(this._offset), this._list.System$Collections$Generic$IList$$$get_Item(this._offset, [TSource])));
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 12887785486, 21477392398)
                    
                    static $h = 2883598;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12887785486, 21477392398),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12887785486, 21477392398)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297850894),
    {
      "t": $.$$.System.Collections.Generic.IList$$(TSource).$h,
      "n": "_list",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297850894)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592818190),
    {
      "p": [
        {
          "n": "list",
          "p": $.$$.System.Collections.Generic.IList$$(TSource).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592818190)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,90177537,62652417
  ],
  "g": [TSource?.$h??1507328
  ],
  "r": 1,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForIList<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionForIList$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2883598)
            
            //--TRIMMABLE-BOUNDARY-START(2686990)
            static $_StaticIndexRangePartitionerForArray$$;
            static StaticIndexRangePartitionerForArray$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitionerForArray$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForArray<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForArray<>", [TSource], ($self) => class StaticIndexRangePartitionerForArray$$ extends $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$typeArray(TSource))
                {
                    //--TRIMMABLE-BOUNDARY-START(4297654286)
                    /*TSource[]*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(4297654286)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592621582)
                    $ctor$4(/*TSource[]*/ array)
                    {
                        super.$ctor$3();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592621582);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2(array !== null, "array != null");
                            this._array = array;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592621582)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 25772490766, 25772425230)
                    /*int */ get SourceCount()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477523470);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._array.length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 25772490766, 25772425230)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 12887588878, 8592556046)
                    /*IEnumerator<KeyValuePair<long, TSource>> */ CreatePartition(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887588878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForArray$$(TSource))().$ctor$2(this._array, startIndex, endIndex);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 12887588878, 8592556046)
                    
                    static $h = 2686990;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2621454,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 25772490766, 25772425230),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364420
      },
      "n": "SourceCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25772490766, 25772425230)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12887588878, 8592556046),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "CreatePartition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12887588878, 8592556046)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297654286),
    {
      "t": $.$typeArray(TSource).$h,
      "n": "_array",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297654286)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592621582),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592621582)
  ],
  "g": [TSource?.$h??1507328
  ],
  "r": 1,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$typeArray(TSource)); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForArray<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionerForArray$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2686990)
            
            //--TRIMMABLE-BOUNDARY-START(2818062)
            static $_StaticIndexRangePartitionForArray$$;
            static StaticIndexRangePartitionForArray$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitionForArray$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForArray<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForArray<>", [TSource], ($self) => class StaticIndexRangePartitionForArray$$ extends $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297785358)
                    /*TSource[]*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(4297785358)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592752654)
                    $ctor$2(/*TSource[]*/ array, /*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor$1(startIndex, endIndex);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592752654);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2(startIndex >= 0 && endIndex <= ((array.length - 1) | 0), "startIndex >= 0 && endIndex <= array.Length - 1");
                            this._array = array;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592752654)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 12887719950, 21477392398)
                    /*KeyValuePair<long, TSource> */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477654542);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._offset < this._startIndex)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._offset >= this._startIndex && this._offset <= this._endIndex, "_offset >= _startIndex && _offset <= _endIndex");
                        return (new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(BigInt(this._offset), $.$$.System.Array.$ReadT1.call(this._array, this._offset)));
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 12887719950, 21477392398)
                    
                    static $h = 2818062;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12887719950, 21477392398),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12887719950, 21477392398)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297785358),
    {
      "t": $.$typeArray(TSource).$h,
      "n": "_array",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297785358)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592752654),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(TSource).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592752654)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,90177537,62652417
  ],
  "g": [TSource?.$h??1507328
  ],
  "r": 1,
  "d": 1507342,
  "h": this.$h
}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForArray<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionForArray$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2818062)
            
            //--TRIMMABLE-BOUNDARY-START(2424846)
            static $_SharedInt;
            static get SharedInt()
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return $cls.$_SharedInt ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.SharedInt", ($self) => class SharedInt extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592359438)
                    /*int*/ Value = 0;
                    //--TRIMMABLE-BOUNDARY-END(8592359438)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297392142)
                    $ctor$1(/*int*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297392142);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297392142)
                    
                    static $h = 2424846;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592359438),
    {
      "t": 655361,
      "n": "Value",
      "d": 2424846,
      "h": 8592359438,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592359438)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297392142),
    {
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2424846,
      "h": 4297392142,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297392142)
  ],
  "d": 1507342,
  "h": 2424846
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.SharedInt`; }
                }, $cls, ($v) => $cls.$_SharedInt = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2424846)
            
            //--TRIMMABLE-BOUNDARY-START(2359310)
            static $_SharedBool;
            static get SharedBool()
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return $cls.$_SharedBool ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.SharedBool", ($self) => class SharedBool extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592293902)
                    /*bool*/ Value = false;
                    //--TRIMMABLE-BOUNDARY-END(8592293902)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297326606)
                    $ctor$1(/*bool*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297326606);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297326606)
                    
                    static $h = 2359310;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592293902),
    {
      "t": 262145,
      "n": "Value",
      "d": 2359310,
      "h": 8592293902,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592293902)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326606),
    {
      "p": [
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359310,
      "h": 4297326606,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297326606)
  ],
  "d": 1507342,
  "h": 2359310
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.SharedBool`; }
                }, $cls, ($v) => $cls.$_SharedBool = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2359310)
            
            //--TRIMMABLE-BOUNDARY-START(2490382)
            static $_SharedLong;
            static get SharedLong()
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return $cls.$_SharedLong ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.SharedLong", ($self) => class SharedLong extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592424974)
                    /*long*/ Value = 0n;
                    //--TRIMMABLE-BOUNDARY-END(8592424974)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297457678)
                    $ctor$1(/*long*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297457678);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297457678)
                    
                    static $h = 2490382;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592424974),
    {
      "t": 917505,
      "n": "Value",
      "d": 2490382,
      "h": 8592424974,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592424974)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457678),
    {
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2490382,
      "h": 4297457678,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297457678)
  ],
  "d": 1507342,
  "h": 2490382
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.SharedLong`; }
                }, $cls, ($v) => $cls.$_SharedLong = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2490382)
            
            //--TRIMMABLE-BOUNDARY-START(55836082190)
            /*int*/ static DEFAULT_BYTES_PER_UNIT = 128;
            //--TRIMMABLE-BOUNDARY-END(55836082190)
            
            //--TRIMMABLE-BOUNDARY-START(51541114894)
            /*int*/ static DEFAULT_BYTES_PER_CHUNK = 512;
            //--TRIMMABLE-BOUNDARY-END(51541114894)
            
            //--TRIMMABLE-BOUNDARY-START(85900853262)
            static /*int */ GetDefaultChunkSize(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900853262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let chunkSize;
                if (TSource.$type.IsValueType)
                {
                    {
                        chunkSize = 128/*DEFAULT_BYTES_PER_UNIT*/;
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((512/*DEFAULT_BYTES_PER_CHUNK*/ % $.$$.System.IntPtr.Size) === 0, "bytes per chunk should be a multiple of pointer size");
                    chunkSize = ($.trunc(512/*DEFAULT_BYTES_PER_CHUNK*/ / $.$$.System.IntPtr.Size));
                }
                return chunkSize;
            }
            //--TRIMMABLE-BOUNDARY-END(85900853262)
            
            static $h = 1507342;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591441934),
    {
      "r": (TSource) => $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,
      "p": [
        {
          "n": "list",
          "p": (TSource) => $.$$.System.Collections.Generic.IList$$(TSource).$h
        },
        {
          "n": "loadBalance",
          "p": 262145
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Create",
      "o": "@$6",
      "d": 1507342,
      "h": 8591441934,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591441934),
//--TRIMMABLE-BOUNDARY-START(12886409230),
    {
      "r": (TSource) => $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,
      "p": [
        {
          "n": "array",
          "p": (TSource) => $.$typeArray(TSource).$h
        },
        {
          "n": "loadBalance",
          "p": 262145
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Create",
      "o": "@$7",
      "d": 1507342,
      "h": 12886409230,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886409230),
//--TRIMMABLE-BOUNDARY-START(17181376526),
    {
      "r": (TSource) => $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Create",
      "o": "@$5",
      "d": 1507342,
      "h": 17181376526,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181376526),
//--TRIMMABLE-BOUNDARY-START(21476343822),
    {
      "r": (TSource) => $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        },
        {
          "n": "partitionerOptions",
          "p": 1114126
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Create",
      "o": "@$4",
      "d": 1507342,
      "h": 21476343822,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21476343822),
//--TRIMMABLE-BOUNDARY-START(25771311118),
    {
      "r": $.$scc.System.Collections.Concurrent.OrderablePartitioner$$($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 917505
        },
        {
          "n": "toExclusive",
          "p": 917505
        }
      ],
      "n": "Create",
      "o": "@$3",
      "d": 1507342,
      "h": 25771311118,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771311118),
//--TRIMMABLE-BOUNDARY-START(30066278414),
    {
      "r": $.$scc.System.Collections.Concurrent.OrderablePartitioner$$($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 917505
        },
        {
          "n": "toExclusive",
          "p": 917505
        },
        {
          "n": "rangeSize",
          "p": 917505
        }
      ],
      "n": "Create",
      "o": "@$2",
      "d": 1507342,
      "h": 30066278414,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066278414),
//--TRIMMABLE-BOUNDARY-START(42951180302),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 917505
        },
        {
          "n": "toExclusive",
          "p": 917505
        },
        {
          "n": "rangeSize",
          "p": 917505
        }
      ],
      "n": "CreateRanges",
      "o": "@$1",
      "d": 1507342,
      "h": 42951180302,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42951180302),
//--TRIMMABLE-BOUNDARY-START(34361245710),
    {
      "r": $.$scc.System.Collections.Concurrent.OrderablePartitioner$$($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 655361
        },
        {
          "n": "toExclusive",
          "p": 655361
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 1507342,
      "h": 34361245710,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361245710),
//--TRIMMABLE-BOUNDARY-START(38656213006),
    {
      "r": $.$scc.System.Collections.Concurrent.OrderablePartitioner$$($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 655361
        },
        {
          "n": "toExclusive",
          "p": 655361
        },
        {
          "n": "rangeSize",
          "p": 655361
        }
      ],
      "n": "Create",
      "d": 1507342,
      "h": 38656213006,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656213006),
//--TRIMMABLE-BOUNDARY-START(47246147598),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 655361
        },
        {
          "n": "toExclusive",
          "p": 655361
        },
        {
          "n": "rangeSize",
          "p": 655361
        }
      ],
      "n": "CreateRanges",
      "d": 1507342,
      "h": 47246147598,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47246147598),
//--TRIMMABLE-BOUNDARY-START(85900853262),
    {
      "r": 655361,
      "g": [
        "TSource"
      ],
      "n": "GetDefaultChunkSize",
      "d": 1507342,
      "h": 85900853262,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(85900853262)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474638),
    {
      "t": 655361,
      "n": "CoreOversubscriptionRate",
      "d": 1507342,
      "h": 4296474638,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296474638),
//--TRIMMABLE-BOUNDARY-START(55836082190),
    {
      "t": 655361,
      "n": "DEFAULT_BYTES_PER_UNIT",
      "d": 1507342,
      "h": 55836082190,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836082190),
//--TRIMMABLE-BOUNDARY-START(51541114894),
    {
      "t": 655361,
      "n": "DEFAULT_BYTES_PER_CHUNK",
      "d": 1507342,
      "h": 51541114894,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541114894)
  ],
  "j": [1572878,1900558,2293774,1638414,2097166,1703950,2621454,2555918,2752526,2883598,2686990,2818062,2424846,2359310,2490382
  ],
  "h": 1507342
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.Partitioner`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507342)
        
        
        //--TRIMMABLE-BOUNDARY-START(131086)
        $asm.$cls("$scc.System.Collections.Concurrent.BlockingCollectionDebugView<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.BlockingCollectionDebugView<>", [T], ($self) => class BlockingCollectionDebugView$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098382)
            /*BlockingCollection<T>*/ _blockingCollection = null;
            //--TRIMMABLE-BOUNDARY-END(4295098382)
            
            //--TRIMMABLE-BOUNDARY-START(8590065678)
            $ctor$1(/*BlockingCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065678);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._blockingCollection = collection;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065678)
            
            //--TRIMMABLE-BOUNDARY-START(21474967566)
            /*T[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._blockingCollection.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(21474967566)
            
            static $h = 131086;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967566),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70057985,
          "c": 4365025281,
          "a": [
            {
              "v": 3,
              "t": 70123521
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21474967566)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098382),
    {
      "t": $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).$h,
      "n": "_blockingCollection",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098382)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065678),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065678)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.BlockingCollectionDebugView<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(131086)
        
        
        //--TRIMMABLE-BOUNDARY-START(917518)
        $asm.$cls("$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps<>", [T], ($self) => class ConcurrentDictionaryTypeProps$$
        {
            //--TRIMMABLE-BOUNDARY-START(8590852110)
            /*bool*/ static IsWriteAtomic = false;
            //--TRIMMABLE-BOUNDARY-END(8590852110)
            
            //--TRIMMABLE-BOUNDARY-START(12885819406)
            static /*bool */ IsWriteAtomicPrivate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!T.$type.IsValueType || $.$$.System.Type.op_Equality$1(T.$type, $.$$.System.IntPtr.$type) || $.$$.System.Type.op_Equality$1(T.$type, $.$$.System.UIntPtr.$type))
                {
                    return true;
                }
                let $switch1 = $.$$.System.Type.GetTypeCode(T.$type);
                switch($switch1)
                {
                    case 3/*TypeCode.Boolean*/:
                    case 6/*TypeCode.Byte*/:
                    case 4/*TypeCode.Char*/:
                    case 7/*TypeCode.Int16*/:
                    case 9/*TypeCode.Int32*/:
                    case 5/*TypeCode.SByte*/:
                    case 13/*TypeCode.Single*/:
                    case 8/*TypeCode.UInt16*/:
                    case 10/*TypeCode.UInt32*/:
                    return true;
                    case 14/*TypeCode.Double*/:
                    case 11/*TypeCode.Int64*/:
                    case 12/*TypeCode.UInt64*/:
                    return $.$$.System.IntPtr.Size === 8;
                    default:
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885819406)
            
            //--TRIMMABLE-BOUNDARY-START(4295884814)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852110)
                    this.IsWriteAtomic = $.$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps$$(T).IsWriteAtomicPrivate();
                    //--TRIMMABLE-BOUNDARY-END(8590852110)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295884814)
            
            static $h = 917518;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885819406),
    {
      "r": 262145,
      "n": "IsWriteAtomicPrivate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885819406)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852110),
    {
      "t": 262145,
      "n": "IsWriteAtomic",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590852110)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionaryTypeProps<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917518)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179662)
        $asm.$cls("$scc.System.Collections.Concurrent.IDictionaryDebugView<,>", (TKey, TValue) => $asm.$gt("$scc.System.Collections.Concurrent.IDictionaryDebugView<,>", [TKey, TValue], ($self) => class IDictionaryDebugView$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296146958)
            /*IDictionary<TKey, TValue>*/ _dictionary = null;
            //--TRIMMABLE-BOUNDARY-END(4296146958)
            
            //--TRIMMABLE-BOUNDARY-START(8591114254)
            $ctor$1(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114254);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (dictionary === null)
                    {
                        $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("dictionary");
                    }
                    this._dictionary = dictionary;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114254)
            
            //--TRIMMABLE-BOUNDARY-START(21476016142)
            /*DebugViewDictionaryItem<TKey, TValue>[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let keyValuePairs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), null, [this._dictionary.System$Collections$Generic$ICollection$$$Count], null);
                this._dictionary.System$Collections$Generic$ICollection$$$CopyTo(keyValuePairs, 0, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                /*var*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue)), null, [keyValuePairs.length], null);
                for(/*int*/ let i = 0; i < items.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(items, new ($.$scc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(keyValuePairs, i)), i);
                }
                return items;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016142)
            
            static $h = 1179662;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476016142),
    {
      "p": $.$typeArray($.$scc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70057985,
          "c": 4365025281,
          "a": [
            {
              "v": 3,
              "t": 70123521
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476016142)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296146958),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue).$h,
      "n": "_dictionary",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296146958)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114254),
    {
      "p": [
        {
          "n": "dictionary",
          "p": $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591114254)
  ],
  "g": [TKey?.$h??1507328,TValue?.$h??1572864
  ],
  "s": [
    {
      "n": "TKey",
      "f": 64
    },
    null
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.IDictionaryDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1179662)
        
        
        //--TRIMMABLE-BOUNDARY-START(983054)
        $asm.$cls("$scc.System.Collections.Concurrent.ConcurrentStack<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentStack<>", [T], ($self) => class ConcurrentStack$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1048590)
            static $_Node;
            static get Node()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T);
                return $cls.$_Node ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentStack$$.Node", ($self) => class Node extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590983182)
                    /*T*/ _value = $.$default(T);
                    //--TRIMMABLE-BOUNDARY-END(8590983182)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015886)
                    /*Node?*/ _next = null;
                    //--TRIMMABLE-BOUNDARY-END(4296015886)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885950478)
                    $ctor$1(/*T*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885950478);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._value = value;
                            this._next = null;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885950478)
                    
                    static $h = 1048590;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590983182),
    {
      "t": T?.$h??1507328,
      "n": "_value",
      "d": 1048590,
      "h": Number(BigInt(1048590)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590983182),
//--TRIMMABLE-BOUNDARY-START(4296015886),
    {
      "t": 1048590,
      "n": "_next",
      "d": 1048590,
      "h": Number(BigInt(1048590)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296015886)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885950478),
    {
      "p": [
        {
          "n": "value",
          "p": T?.$h??1507328
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048590,
      "h": Number(BigInt(1048590)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885950478)
  ],
  "d": $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).$h,
  "h": 1048590
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentStack<${T?.$fullName}>.Node`; }
                }, $cls, ($v) => $cls.$_Node = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048590)
            
            //--TRIMMABLE-BOUNDARY-START(4295950350)
            /*Node?*/ _head = null;
            //--TRIMMABLE-BOUNDARY-END(4295950350)
            
            //--TRIMMABLE-BOUNDARY-START(17180852238)
            /*int*/ static BACKOFF_MAX_YIELDS = 8;
            //--TRIMMABLE-BOUNDARY-END(17180852238)
            
            //--TRIMMABLE-BOUNDARY-START(8590917646)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917646);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917646)
            
            //--TRIMMABLE-BOUNDARY-START(12885884942)
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885884942);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885884942)
            
            //--TRIMMABLE-BOUNDARY-START(64425492494)
            /*void */ InitializeFromCollection(/*IEnumerable<T>*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let lastNode = null;
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var element = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*Node*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)().$ctor$1(element);
                        newNode._next = lastNode;
                        lastNode = newNode;
                    }
                }
                this._head = lastNode;
            }
            //--TRIMMABLE-BOUNDARY-END(64425492494)
            
            //--TRIMMABLE-BOUNDARY-START(68720459790)
            /*bool */ get IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540590606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._head === null;
            }
            //--TRIMMABLE-BOUNDARY-END(68720459790)
            
            //--TRIMMABLE-BOUNDARY-START(34360721422)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = 0;
                for(/*Node?*/ let curr = this._head; curr !== null; curr = curr._next)
                {
                    count++;
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(34360721422)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 124555034638, 38716964865)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670132750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 124555034638, 38716964865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 128850001934, 43011932161)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260067342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 128850001934, 43011932161)
            
            //--TRIMMABLE-BOUNDARY-START(21475819534)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._head = null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475819534)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 103080198158, 4357226497)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080198158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                (this.ToList()).System$Collections$ICollection$CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 103080198158, 4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(30065754126)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                this.ToList().CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(30065754126)
            
            //--TRIMMABLE-BOUNDARY-START(77310394382)
            /*void */ Push(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310394382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)().$ctor$1(item);
                newNode._next = this._head;
                if ($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), newNode, newNode._next) === newNode._next)
                {
                    return;
                }
                this.PushCore(newNode, newNode);
            }
            //--TRIMMABLE-BOUNDARY-END(77310394382)
            
            //--TRIMMABLE-BOUNDARY-START(85900328974)
            /*void */ PushRange$1(/*T[]*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900328974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                this.PushRange(items, 0, items.length);
            }
            //--TRIMMABLE-BOUNDARY-END(85900328974)
            
            //--TRIMMABLE-BOUNDARY-START(90195296270)
            /*void */ PushRange(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195296270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).ValidatePushPopRangeInput(items, startIndex, count);
                if (count === 0)
                {
                    return;
                }
                /*Node*/ let head, tail;
                head = tail = new ($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(items, startIndex));
                for(/*int*/ let i = ((startIndex + 1) | 0); i < ((startIndex + count) | 0); i++)
                {
                    /*Node*/ let node = new ($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(items, i));
                    node._next = head;
                    head = node;
                }
                tail._next = this._head;
                if ($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), head, tail._next) === tail._next)
                {
                    return;
                }
                this.PushCore(head, tail);
            }
            //--TRIMMABLE-BOUNDARY-END(90195296270)
            
            //--TRIMMABLE-BOUNDARY-START(81605361678)
            /*void */ PushCore(/*Node*/ head, /*Node*/ tail)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SpinWait*/ let spin = new $.$$.System.Threading.SpinWait();
                do
                {
                    spin.SpinOnce$1(-1);
                    tail._next = this._head;
                }
                while($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), head, tail._next) !== tail._next);
                if ($.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPushFailed(spin.Count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605361678)
            
            //--TRIMMABLE-BOUNDARY-START(176094642190)
            static /*void */ ValidatePushPopRangeInput(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094642190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                /*int*/ let length = items.length;
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, startIndex, length, "startIndex");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, startIndex, "startIndex");
                if (((length - count) | 0) < startIndex)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentStack_PushPopRange_InvalidCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094642190)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 94490263566, 12940869633)
            /*bool */ System$Collections$Concurrent$IProducerConsumerCollection$$$TryAdd(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490263566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Push(item);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 94490263566, 12940869633)
            
            //--TRIMMABLE-BOUNDARY-START(150324838414)
            /*bool */ TryPeek(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324838414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let head = this._head;
                if (head === null)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                else 
                {
                    result.$v = head._value;
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324838414)
            
            //--TRIMMABLE-BOUNDARY-START(154619805710)
            /*bool */ TryPop(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619805710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let head = this._head;
                if (head === null)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                if ($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), head._next, head) === head)
                {
                    result.$v = head._value;
                    return true;
                }
                return this.TryPopCore$1(result);
            }
            //--TRIMMABLE-BOUNDARY-END(154619805710)
            
            //--TRIMMABLE-BOUNDARY-START(167504707598)
            /*int */ TryPopRange$1(/*T[]*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504707598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                return this.TryPopRange(items, 0, items.length);
            }
            //--TRIMMABLE-BOUNDARY-END(167504707598)
            
            //--TRIMMABLE-BOUNDARY-START(171799674894)
            /*int */ TryPopRange(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799674894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).ValidatePushPopRangeInput(items, startIndex, count);
                if (count === 0)
                {
                    return 0;
                }
                /*Node?*/ let poppedHead;
                /*int*/ let nodesCount = this.TryPopCore(count, $.$ref(() => poppedHead, ($v) => poppedHead = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node));
                if (nodesCount > 0)
                {
                    $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).CopyRemovedItems(poppedHead, items, startIndex, nodesCount);
                }
                return nodesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(171799674894)
            
            //--TRIMMABLE-BOUNDARY-START(158914773006)
            /*bool */ TryPopCore$1(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914773006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let poppedNode;
                if (this.TryPopCore(1, $.$ref(() => poppedNode, ($v) => poppedNode = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)) === 1)
                {
                    result.$v = poppedNode._value;
                    return true;
                }
                result.$v = $.$default(T);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(158914773006)
            
            //--TRIMMABLE-BOUNDARY-START(163209740302)
            /*int */ TryPopCore(/*int*/ count, /*out Node?*/ poppedHead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209740302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SpinWait*/ let spin = new $.$$.System.Threading.SpinWait();
                /*Node?*/ let head;
                /*Node*/ let next;
                /*int*/ let backoff = 1;
                while(true)
                {
                    head = this._head;
                    if (head === null)
                    {
                        if (count === 1 && $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                        {
                            $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPopFailed(spin.Count);
                        }
                        poppedHead.$v = null;
                        return 0;
                    }
                    next = head;
                    /*int*/ let nodesCount = 1;
                    for(; nodesCount < count && next._next !== null; nodesCount++)
                    {
                        next = next._next;
                    }
                    if ($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), next._next, head) === head)
                    {
                        if (count === 1 && $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                        {
                            $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPopFailed(spin.Count);
                        }
                        poppedHead.$v = head;
                        return nodesCount;
                    }
                    for(/*int*/ let i = 0; i < backoff; i++)
                    {
                        spin.SpinOnce$1(-1);
                    }
                    if (spin.NextSpinWillYield)
                    {
                        backoff = $.$$.System.Random.Shared.Next$1(1, 8/*BACKOFF_MAX_YIELDS*/);
                    }
                    else 
                    {
                        backoff *= 2;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209740302)
            
            //--TRIMMABLE-BOUNDARY-START(25770786830)
            static /*void */ CopyRemovedItems(/*Node*/ head, /*T[]*/ collection, /*int*/ startIndex, /*int*/ nodesCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let current = head;
                for(/*int*/ let i = startIndex; i < ((startIndex + nodesCount) | 0); i++)
                {
                    $.$$.System.Array.$WriteT1.call(collection, current._value, i);
                    current = current._next;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770786830)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 98785230862, 17235836929)
            /*bool */ System$Collections$Concurrent$IProducerConsumerCollection$$$TryTake(/*out T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryPop(item);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 98785230862, 17235836929)
            
            //--TRIMMABLE-BOUNDARY-START(137439936526)
            /*T[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439936526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let curr = this._head;
                return curr === null ? $.$$.System.Array.Empty(T) : $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).ToList$1(curr).ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(137439936526)
            
            //--TRIMMABLE-BOUNDARY-START(141734903822)
            /*List<T> */ ToList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734903822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).ToList$1(this._head);
            }
            //--TRIMMABLE-BOUNDARY-END(141734903822)
            
            //--TRIMMABLE-BOUNDARY-START(146029871118)
            static /*List<T> */ ToList$1(/*Node?*/ curr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029871118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<T>*/ let list = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                while(curr !== null)
                {
                    list.Add(curr._value);
                    curr = curr._next;
                }
                return list;
            }
            //--TRIMMABLE-BOUNDARY-END(146029871118)
            
            //--TRIMMABLE-BOUNDARY-START(55835557902)
            /*IEnumerator<T> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).GetEnumerator$1(this._head);
            }
            //--TRIMMABLE-BOUNDARY-END(55835557902)
            
            //--TRIMMABLE-BOUNDARY-START(60130525198)
            static /*IEnumerator<T> */ GetEnumerator$1(/*Node?*/ head)
            {
                return new ($.$$.NetJs.YieldToIterator$$(T))().$ctor$1(function*()
                {
                    /*Node?*/ let current = head;
                    while(current !== null)
                    {
                        yield current._value;
                        current = current._next;
                    }
                }.bind(this)).GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(60130525198)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 133144969230, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 133144969230, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(4350935041)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.CopyTo(T[], int)
            System$Collections$Concurrent$IProducerConsumerCollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4350935041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4350935041)
            
            //--TRIMMABLE-BOUNDARY-START(8645902337)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.ToArray()
            System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8645902337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToArray(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8645902337)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(12944801793)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354867201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944801793)
            
            //--TRIMMABLE-BOUNDARY-START(4354473985)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<T>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354473985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354473985)
            
            static $h = 983054;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720459790),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720459790),
//--TRIMMABLE-BOUNDARY-START(34360721422),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360721422),
//--TRIMMABLE-BOUNDARY-START(ALL, 124555034638, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 124555034638, 38716964865),
//--TRIMMABLE-BOUNDARY-START(ALL, 128850001934, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 128850001934, 43011932161)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425492494),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "n": "InitializeFromCollection",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425492494),
//--TRIMMABLE-BOUNDARY-START(21475819534),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475819534),
//--TRIMMABLE-BOUNDARY-START(30065754126),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065754126),
//--TRIMMABLE-BOUNDARY-START(77310394382),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "Push",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310394382),
//--TRIMMABLE-BOUNDARY-START(85900328974),
    {
      "r": 65537,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        }
      ],
      "n": "PushRange",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900328974),
//--TRIMMABLE-BOUNDARY-START(90195296270),
    {
      "r": 65537,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "PushRange",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195296270),
//--TRIMMABLE-BOUNDARY-START(81605361678),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": 1048590
        },
        {
          "n": "tail",
          "p": 1048590
        }
      ],
      "n": "PushCore",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605361678),
//--TRIMMABLE-BOUNDARY-START(176094642190),
    {
      "r": 65537,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidatePushPopRangeInput",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176094642190),
//--TRIMMABLE-BOUNDARY-START(150324838414),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324838414),
//--TRIMMABLE-BOUNDARY-START(154619805710),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPop",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619805710),
//--TRIMMABLE-BOUNDARY-START(167504707598),
    {
      "r": 655361,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        }
      ],
      "n": "TryPopRange",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504707598),
//--TRIMMABLE-BOUNDARY-START(171799674894),
    {
      "r": 655361,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "TryPopRange",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799674894),
//--TRIMMABLE-BOUNDARY-START(158914773006),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPopCore",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914773006),
//--TRIMMABLE-BOUNDARY-START(163209740302),
    {
      "r": 655361,
      "p": [
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "poppedHead",
          "p": 1048590,
          "f": 2
        }
      ],
      "n": "TryPopCore",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209740302),
//--TRIMMABLE-BOUNDARY-START(25770786830),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": 1048590
        },
        {
          "n": "collection",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "nodesCount",
          "p": 655361
        }
      ],
      "n": "CopyRemovedItems",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770786830),
//--TRIMMABLE-BOUNDARY-START(137439936526),
    {
      "r": $.$typeArray(T).$h,
      "n": "ToArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439936526),
//--TRIMMABLE-BOUNDARY-START(141734903822),
    {
      "r": $.$$.System.Collections.Generic.List$$(T).$h,
      "n": "ToList",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734903822),
//--TRIMMABLE-BOUNDARY-START(146029871118),
    {
      "r": $.$$.System.Collections.Generic.List$$(T).$h,
      "p": [
        {
          "n": "curr",
          "p": 1048590
        }
      ],
      "n": "ToList",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146029871118),
//--TRIMMABLE-BOUNDARY-START(55835557902),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835557902),
//--TRIMMABLE-BOUNDARY-START(60130525198),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "p": [
        {
          "n": "head",
          "p": 1048590
        }
      ],
      "n": "GetEnumerator",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60130525198)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950350),
    {
      "t": 1048590,
      "n": "_head",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950350),
//--TRIMMABLE-BOUNDARY-START(17180852238),
    {
      "t": 655361,
      "n": "BACKOFF_MAX_YIELDS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180852238)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917646),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917646),
//--TRIMMABLE-BOUNDARY-START(12885884942),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885884942)
  ],
  "i": [$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,62259201,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,62521345
  ],
  "g": [T?.$h??1507328
  ],
  "j": [1048590
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70582273,
      "c": 8660516865,
      "a": [
        {
          "v": $.$scc.System.Collections.Concurrent.IProducerConsumerCollectionDebugView$$().$h,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.ConcurrentStack<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(983054)
        
        
        //--TRIMMABLE-BOUNDARY-START(262158)
        $asm.$cls("$scc.System.Collections.Concurrent.ConcurrentBag<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentBag<>", [T], ($self) => class ConcurrentBag$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590196750)
            /*ThreadLocal<WorkStealingQueue>*/ _locals = null;
            //--TRIMMABLE-BOUNDARY-END(8590196750)
            
            //--TRIMMABLE-BOUNDARY-START(12885164046)
            /*WorkStealingQueue?*/ _workStealingQueues = null;
            //--TRIMMABLE-BOUNDARY-END(12885164046)
            
            //--TRIMMABLE-BOUNDARY-START(4295229454)
            /*long*/ _emptyToNonEmptyListTransitionCount = 0n;
            //--TRIMMABLE-BOUNDARY-END(4295229454)
            
            //--TRIMMABLE-BOUNDARY-START(17180131342)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131342);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._locals = new ($.$$.System.Threading.ThreadLocal$$($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131342)
            
            //--TRIMMABLE-BOUNDARY-START(21475098638)
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475098638);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._locals = new ($.$$.System.Threading.ThreadLocal$$($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue))().$ctor$1();
                    /*WorkStealingQueue*/ let queue = this.GetCurrentThreadWorkStealingQueue(true);
                    var $en3 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            queue.LocalPush(item, $.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.System.Int64));
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098638)
            
            //--TRIMMABLE-BOUNDARY-START(25770065934)
            /*void */ Add(/*T*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770065934);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetCurrentThreadWorkStealingQueue(true).LocalPush(item, $.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.System.Int64));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770065934)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 120259346446, 12940869633)
            /*bool */ System$Collections$Concurrent$IProducerConsumerCollection$$$TryAdd(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259346446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Add(item);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 120259346446, 12940869633)
            
            //--TRIMMABLE-BOUNDARY-START(176093921294)
            /*bool */ TryTake(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WorkStealingQueue?*/ let queue = this.GetCurrentThreadWorkStealingQueue(false);
                return (queue !== null && queue.TryLocalPop(result)) || this.TrySteal(result, true);
            }
            //--TRIMMABLE-BOUNDARY-END(176093921294)
            
            //--TRIMMABLE-BOUNDARY-START(163209019406)
            /*bool */ TryPeek(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WorkStealingQueue?*/ let queue = this.GetCurrentThreadWorkStealingQueue(false);
                return (queue !== null && queue.TryLocalPeek(result)) || this.TrySteal(result, false);
            }
            //--TRIMMABLE-BOUNDARY-END(163209019406)
            
            //--TRIMMABLE-BOUNDARY-START(94489542670)
            /*WorkStealingQueue? */ GetCurrentThreadWorkStealingQueue(/*bool*/ forceCreate)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489542670);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._locals.Value ?? (forceCreate ? this.CreateWorkStealingQueueForCurrentThread() : null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489542670)
            
            //--TRIMMABLE-BOUNDARY-START(47244902414)
            /*WorkStealingQueue */ CreateWorkStealingQueueForCurrentThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.GlobalQueuesLock)
                    {
                        /*WorkStealingQueue?*/ let head = this._workStealingQueues;
                        /*WorkStealingQueue?*/ let queue = head !== null ? this.GetUnownedWorkStealingQueue() : null;
                        if (queue === null)
                        {
                            this._workStealingQueues = queue = new ($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue)().$ctor$1(head);
                        }
                        this._locals.Value = queue;
                        return queue;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.GlobalQueuesLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244902414)
            
            //--TRIMMABLE-BOUNDARY-START(103079477262)
            /*WorkStealingQueue? */ GetUnownedWorkStealingQueue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.GlobalQueuesLock), "Monitor.IsEntered(GlobalQueuesLock)");
                /*int*/ let currentThreadId = $.$$.System.Environment.CurrentManagedThreadId;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    if (queue._ownerThreadId === currentThreadId)
                    {
                        return queue;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(103079477262)
            
            //--TRIMMABLE-BOUNDARY-START(167503986702)
            /*bool */ TrySteal(/*out T*/ result, /*bool*/ take)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    if (take)
                    {
                        $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentBag_TryTakeSteals();
                    }
                    else 
                    {
                        $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentBag_TryPeekSteals();
                    }
                }
                while(true)
                {
                    /*long*/ let initialEmptyToNonEmptyCounts = $.$$.System.Threading.Interlocked.Read($.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.System.Int64));
                    /*WorkStealingQueue?*/ let localQueue = this.GetCurrentThreadWorkStealingQueue(false);
                    /*bool*/ let gotItem = localQueue === null ? $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).TryStealFromTo(this._workStealingQueues, null, result, take) : ($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).TryStealFromTo(localQueue._nextQueue, null, result, take) || $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).TryStealFromTo(this._workStealingQueues, localQueue, result, take));
                    if (gotItem)
                    {
                        return true;
                    }
                    if ($.$$.System.Threading.Interlocked.Read($.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.System.Int64)) === initialEmptyToNonEmptyCounts)
                    {
                        return false;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167503986702)
            
            //--TRIMMABLE-BOUNDARY-START(171798953998)
            static /*bool */ TryStealFromTo(/*WorkStealingQueue?*/ startInclusive, /*WorkStealingQueue?*/ endExclusive, /*out T*/ result, /*bool*/ take)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798953998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*WorkStealingQueue?*/ let queue = startInclusive; queue !== endExclusive; queue = queue._nextQueue)
                {
                    if (queue.TrySteal(result, take))
                    {
                        return true;
                    }
                }
                result.$v = $.$default(T);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(171798953998)
            
            //--TRIMMABLE-BOUNDARY-START(38654967822)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (this._workStealingQueues === null)
                {
                    return;
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                    /*int*/ let count = this.DangerousCount;
                    if (index > ((array.length - count) | 0))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.Collection_CopyTo_TooManyElems, "index");
                    }
                    try
                    {
                        /*int*/ let copied = this.CopyFromEachQueueToArray(array, index);
                        $.$$.System.Diagnostics.Debug.Assert$2(copied === count, "copied == count");
                    }
                    catch(e)
                    {
                        throw new $.$$.System.InvalidCastException().$ctor$11(e.Message, e);
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654967822)
            
            //--TRIMMABLE-BOUNDARY-START(34360000526)
            /*int */ CopyFromEachQueueToArray(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.GlobalQueuesLock), "Monitor.IsEntered(GlobalQueuesLock)");
                /*int*/ let i = index;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    i += queue.DangerousCopyTo(array, i);
                }
                return ((i - index) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(34360000526)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 124554313742, 4357226497)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T[]?*/ let szArray = $.$as(array, $.$typeArray(T));
                if (szArray !== null)
                {
                    this.CopyTo(szArray, index);
                    return;
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                this.ToArray().CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 124554313742, 4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(158914052110)
            /*T[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._workStealingQueues !== null)
                {
                    /*bool*/ let lockTaken = false;
                    try
                    {
                        this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                        /*int*/ let count = this.DangerousCount;
                        if (count > 0)
                        {
                            /*var*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                            /*int*/ let copied = this.CopyFromEachQueueToArray(arr, 0);
                            $.$$.System.Diagnostics.Debug.Assert$2(copied === count, "copied == count");
                            return arr;
                        }
                    }
                    finally
                    {
                        {
                            this.UnfreezeBag(lockTaken);
                        }
                    }
                }
                return $.$$.System.Array.Empty(T);
            }
            //--TRIMMABLE-BOUNDARY-END(158914052110)
            
            //--TRIMMABLE-BOUNDARY-START(30065033230)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._workStealingQueues === null)
                {
                    return;
                }
                /*WorkStealingQueue?*/ let local = this.GetCurrentThreadWorkStealingQueue(false);
                if (local !== null)
                {
                    local.LocalClear();
                    if (local._nextQueue === null && local === this._workStealingQueues)
                    {
                        return;
                    }
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        /*T?*/ let ignored;
                        while(queue.TrySteal($.$ref(() => ignored, ($v) => ignored = $v, T), true))
                        {
                        }
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065033230)
            
            //--TRIMMABLE-BOUNDARY-START(98784509966)
            /*IEnumerator<T> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784509966);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.ToArray()).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784509966)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 154619084814, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619084814);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 154619084814, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(42949935118)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._workStealingQueues === null)
                {
                    return 0;
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                    return this.DangerousCount;
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949935118)
            
            //--TRIMMABLE-BOUNDARY-START(51539869710)
            /*int */ get DangerousCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = 0;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    //checked
                    {
                        count += queue.DangerousCount;
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0, "count >= 0");
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(51539869710)
            
            //--TRIMMABLE-BOUNDARY-START(111669411854)
            /*bool */ get IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WorkStealingQueue?*/ let local = this.GetCurrentThreadWorkStealingQueue(false);
                if (local !== null)
                {
                    if (!local.IsEmpty)
                    {
                        return false;
                    }
                    if (local._nextQueue === null && local === this._workStealingQueues)
                    {
                        return true;
                    }
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        if (!queue.IsEmpty)
                        {
                            return false;
                        }
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(111669411854)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 146029150222, 38716964865)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 146029150222, 38716964865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 150324117518, 43011932161)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734182926);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 150324117518, 43011932161)
            
            //--TRIMMABLE-BOUNDARY-START(107374444558)
            /*object */ get GlobalQueuesLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._locals !== null, "_locals != null");
                return this._locals;
            }
            //--TRIMMABLE-BOUNDARY-END(107374444558)
            
            //--TRIMMABLE-BOUNDARY-START(55834837006)
            /*void */ FreezeBag(/*ref bool*/ lockTaken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.Threading.Monitor.IsEntered(this.GlobalQueuesLock), "!Monitor.IsEntered(GlobalQueuesLock)");
                $.$$.System.Threading.Monitor.Enter(this.GlobalQueuesLock, lockTaken);
                /*WorkStealingQueue?*/ let head = this._workStealingQueues;
                for(/*WorkStealingQueue?*/ let queue = head; queue !== null; queue = queue._nextQueue)
                {
                    $.$$.System.Threading.Monitor.Enter(queue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => queue._frozen, ($v) => queue._frozen = $v, null));
                }
                $.$$.System.Threading.Interlocked.MemoryBarrier();
                for(/*WorkStealingQueue?*/ let queue = head; queue !== null; queue = queue._nextQueue)
                {
                    if (queue._currentOp !== 0/*Operation.None*/)
                    {
                        /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                        do
                        {
                            spinner.SpinOnce();
                        }
                        while(queue._currentOp !== 0/*Operation.None*/);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834837006)
            
            //--TRIMMABLE-BOUNDARY-START(180388888590)
            /*void */ UnfreezeBag(/*bool*/ lockTaken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388888590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.GlobalQueuesLock) === lockTaken, "Monitor.IsEntered(GlobalQueuesLock) == lockTaken");
                if (lockTaken)
                {
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        if (queue._frozen)
                        {
                            queue._frozen = false;
                            $.$$.System.Threading.Monitor.Exit(queue);
                        }
                    }
                    $.$$.System.Threading.Monitor.Exit(this.GlobalQueuesLock);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180388888590)
            
            //--TRIMMABLE-BOUNDARY-START(393230)
            static $_WorkStealingQueue;
            static get WorkStealingQueue()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T);
                return $cls.$_WorkStealingQueue ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentBag$$.WorkStealingQueue", ($self) => class WorkStealingQueue extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(77309804558)
                    /*int*/ static InitialSize = 32;
                    //--TRIMMABLE-BOUNDARY-END(77309804558)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489673742)
                    /*int*/ static StartIndex = 2147483647;
                    //--TRIMMABLE-BOUNDARY-END(94489673742)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475229710)
                    /*int*/ _headIndex = 2147483647;
                    //--TRIMMABLE-BOUNDARY-END(21475229710)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950066190)
                    /*int*/ _tailIndex = 2147483647;
                    //--TRIMMABLE-BOUNDARY-END(42950066190)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590327822)
                    /*T[]*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(8590327822)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770197006)
                    /*int*/ _mask = 31;
                    //--TRIMMABLE-BOUNDARY-END(25770197006)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360526)
                    /*int*/ _addTakeCount = 0;
                    //--TRIMMABLE-BOUNDARY-END(4295360526)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655098894)
                    /*int*/ _stealCount = 0;
                    //--TRIMMABLE-BOUNDARY-END(38655098894)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885295118)
                    /*Operation*/ _currentOp = 0;
                    //--TRIMMABLE-BOUNDARY-END(12885295118)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180262414)
                    /*bool*/ _frozen = false;
                    //--TRIMMABLE-BOUNDARY-END(17180262414)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065164302)
                    /*WorkStealingQueue?*/ _nextQueue = null;
                    //--TRIMMABLE-BOUNDARY-END(30065164302)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360131598)
                    /*int*/ _ownerThreadId = 0;
                    //--TRIMMABLE-BOUNDARY-END(34360131598)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245033486)
                    $ctor$1(/*WorkStealingQueue?*/ nextQueue)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47245033486);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._ownerThreadId = $.$$.System.Environment.CurrentManagedThreadId;
                            this._nextQueue = nextQueue;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245033486)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604771854)
                    /*bool */ get IsEmpty()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014837262);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return ((this._headIndex - this._tailIndex) | 0) >= 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(81604771854)
                    
                    //--TRIMMABLE-BOUNDARY-START(90194706446)
                    /*void */ LocalPush(/*T*/ item, /*ref long*/ emptyToNonEmptyListTransitionCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90194706446);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*bool*/ let lockTaken = false;
                        try
                        {
                            $.$$.System.Threading.Interlocked.Exchange$14($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation, () => this._currentOp, ($v) => this._currentOp = $v, null), 1/*Operation.Add*/);
                            /*int*/ let tail = this._tailIndex;
                            if (tail === 2147483647/*int.MaxValue*/)
                            {
                                this._currentOp = 0/*Operation.None*/;
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(this)
                                    {
                                        $.$$.System.Diagnostics.Debug.Assert$2(this._tailIndex === tail, "No other thread should be changing _tailIndex");
                                        this._headIndex &= this._mask;
                                        this._tailIndex = tail &= this._mask;
                                        $.$$.System.Diagnostics.Debug.Assert$2(((this._headIndex - this._tailIndex) | 0) <= 0, "_headIndex - _tailIndex <= 0");
                                        $.$$.System.Threading.Interlocked.Exchange$14($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation, () => this._currentOp, ($v) => this._currentOp = $v, null), 1/*Operation.Add*/);
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(this)
                                }
                            }
                            /*int*/ let head = this._headIndex;
                            if (!this._frozen && (((head - (((tail - 1) | 0))) | 0) < 0) && (((tail - (((head + this._mask) | 0))) | 0) < 0))
                            {
                                $.$$.System.Array.$WriteT1.call(this._array, item, tail & this._mask);
                                this._tailIndex = ((tail + 1) | 0);
                            }
                            else 
                            {
                                this._currentOp = 0/*Operation.None*/;
                                $.$$.System.Threading.Monitor.Enter(this, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                                head = this._headIndex;
                                /*int*/ let count = ((tail - head) | 0);
                                if (count >= this._mask)
                                {
                                    /*var*/ let newArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._array.length << 1], null);
                                    /*int*/ let headIdx = head & this._mask;
                                    if (headIdx === 0)
                                    {
                                        $.$$.System.Array.Copy(this._array, newArray, this._array.length);
                                    }
                                    else 
                                    {
                                        $.$$.System.Array.Copy$2(this._array, headIdx, newArray, 0, ((this._array.length - headIdx) | 0));
                                        $.$$.System.Array.Copy$2(this._array, 0, newArray, ((this._array.length - headIdx) | 0), headIdx);
                                    }
                                    this._array = newArray;
                                    this._headIndex = 0;
                                    this._tailIndex = tail = count;
                                    this._mask = (this._mask << 1) | 1;
                                }
                                $.$$.System.Array.$WriteT1.call(this._array, item, tail & this._mask);
                                this._tailIndex = ((tail + 1) | 0);
                                if (count === 0)
                                {
                                    $.$$.System.Threading.Interlocked.Increment$1(emptyToNonEmptyListTransitionCount);
                                }
                                this._addTakeCount -= this._stealCount;
                                this._stealCount = 0;
                            }
                            //checked
                            {
                                this._addTakeCount++;
                            }
                        }
                        finally
                        {
                            {
                                this._currentOp = 0/*Operation.None*/;
                                if (lockTaken)
                                {
                                    $.$$.System.Threading.Monitor.Exit(this);
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90194706446)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899739150)
                    /*void */ LocalClear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85899739150);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this)
                            {
                                if (((this._headIndex - this._tailIndex) | 0) < 0)
                                {
                                    this._headIndex = this._tailIndex = 2147483647/*StartIndex*/;
                                    this._addTakeCount = this._stealCount = 0;
                                    $.$$.System.Array.Clear$1(this._array);
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(85899739150)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079608334)
                    /*bool */ TryLocalPop(/*out T*/ result)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103079608334);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*int*/ let tail = this._tailIndex;
                        if (((this._headIndex - tail) | 0) >= 0)
                        {
                            result.$v = $.$default(T);
                            return false;
                        }
                        /*bool*/ let lockTaken = false;
                        try
                        {
                            this._currentOp = 2/*Operation.Take*/;
                            $.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._tailIndex, ($v) => this._tailIndex = $v, $.$$.System.Int32), --tail);
                            if (!this._frozen && (((this._headIndex - tail) | 0) < 0))
                            {
                                /*int*/ let idx = tail & this._mask;
                                result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                this._addTakeCount--;
                                return true;
                            }
                            else 
                            {
                                this._currentOp = 0/*Operation.None*/;
                                $.$$.System.Threading.Monitor.Enter(this, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                                if (((this._headIndex - tail) | 0) <= 0)
                                {
                                    /*int*/ let idx = tail & this._mask;
                                    result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                    //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                    this._addTakeCount--;
                                    return true;
                                }
                                else 
                                {
                                    this._tailIndex = ((tail + 1) | 0);
                                    result.$v = $.$default(T);
                                    return false;
                                }
                            }
                        }
                        finally
                        {
                            {
                                this._currentOp = 0/*Operation.None*/;
                                if (lockTaken)
                                {
                                    $.$$.System.Threading.Monitor.Exit(this);
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(103079608334)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784641038)
                    /*bool */ TryLocalPeek(/*out T*/ result)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98784641038);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*int*/ let tail = this._tailIndex;
                        if (((this._headIndex - tail) | 0) < 0)
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(this)
                                {
                                    if (((this._headIndex - tail) | 0) < 0)
                                    {
                                        result.$v = $.$$.System.Array.$ReadT1.call(this._array, (((tail - 1) | 0)) & this._mask);
                                        return true;
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(this)
                            }
                        }
                        result.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98784641038)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374575630)
                    /*bool */ TrySteal(/*out T*/ result, /*bool*/ take)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107374575630);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this)
                            {
                                /*int*/ let head = this._headIndex;
                                if (take)
                                {
                                    if ((((head - (((this._tailIndex - 2) | 0))) | 0) >= 0) && this._currentOp === 1/*Operation.Add*/)
                                    {
                                        /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                                        do
                                        {
                                            spinner.SpinOnce();
                                        }
                                        while(this._currentOp === 1/*Operation.Add*/);
                                    }
                                    $.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._headIndex, ($v) => this._headIndex = $v, $.$$.System.Int32), ((head + 1) | 0));
                                    if (head < this._tailIndex)
                                    {
                                        /*int*/ let idx = head & this._mask;
                                        result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                        //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                        this._stealCount++;
                                        return true;
                                    }
                                    else 
                                    {
                                        this._headIndex = head;
                                    }
                                }
                                else if (head < this._tailIndex)
                                {
                                    result.$v = $.$$.System.Array.$ReadT1.call(this._array, head & this._mask);
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this)
                        }
                        result.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107374575630)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540000782)
                    /*int */ DangerousCopyTo(/*T[]*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540000782);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this), "Monitor.IsEntered(this)");
                        $.$$.System.Diagnostics.Debug.Assert$2(this._frozen, "_frozen");
                        $.$$.System.Diagnostics.Debug.Assert$2(array !== null, "array != null");
                        $.$$.System.Diagnostics.Debug.Assert$2(arrayIndex >= 0 && arrayIndex <= array.length, "arrayIndex >= 0 && arrayIndex <= array.Length");
                        /*int*/ let headIndex = this._headIndex;
                        /*int*/ let count = this.DangerousCount;
                        $.$$.System.Diagnostics.Debug.Assert$2(count === (((this._tailIndex - this._headIndex) | 0)) || count === (((((this._tailIndex + 1) | 0) - this._headIndex) | 0)), "Count should be the same as tail - head, but allowing for the possibility that " + "a peek decremented _tailIndex before seeing that a freeze was happening.");
                        $.$$.System.Diagnostics.Debug.Assert$2(arrayIndex <= ((array.length - count) | 0), "arrayIndex <= array.Length - count");
                        for(/*int*/ let i = ((((arrayIndex + count) | 0) - 1) | 0); i >= arrayIndex; i--)
                        {
                            $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(this._array, headIndex++ & this._mask), i);
                        }
                        return count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540000782)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834968078)
                    /*int */ get DangerousCount()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424902670);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this), "Monitor.IsEntered(this)");
                        /*int*/ let stealCount = this._stealCount;
                        /*int*/ let addTakeCount = this._addTakeCount;
                        /*int*/ let count = ((addTakeCount - stealCount) | 0);
                        $.$$.System.Diagnostics.Debug.Assert$4(count >= 0, `Expected _addTakeCount (${addTakeCount}) >= _stealCount (${stealCount}).`);
                        return count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834968078)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590327822)
                        this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [32/*InitialSize*/], null);
                        //--TRIMMABLE-BOUNDARY-END(8590327822)
                        
                    }
                    static $h = 393230;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604771854),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(393230)|0x1100000000n),
        "f": 50331656
      },
      "n": "IsEmpty",
      "d": 393230,
      "h": Number(BigInt(393230)|0x1300000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(81604771854),
//--TRIMMABLE-BOUNDARY-START(55834968078),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(393230)|0xF00000000n),
        "f": 50331656
      },
      "n": "DangerousCount",
      "d": 393230,
      "h": Number(BigInt(393230)|0xD00000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55834968078)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90194706446),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "emptyToNonEmptyListTransitionCount",
          "p": 917505,
          "f": 4
        }
      ],
      "n": "LocalPush",
      "d": 393230,
      "h": Number(BigInt(393230)|0x1500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90194706446),
//--TRIMMABLE-BOUNDARY-START(85899739150),
    {
      "r": 65537,
      "n": "LocalClear",
      "d": 393230,
      "h": Number(BigInt(393230)|0x1400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(85899739150),
//--TRIMMABLE-BOUNDARY-START(103079608334),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryLocalPop",
      "d": 393230,
      "h": Number(BigInt(393230)|0x1800000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(103079608334),
//--TRIMMABLE-BOUNDARY-START(98784641038),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryLocalPeek",
      "d": 393230,
      "h": Number(BigInt(393230)|0x1700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98784641038),
//--TRIMMABLE-BOUNDARY-START(107374575630),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "take",
          "p": 262145
        }
      ],
      "n": "TrySteal",
      "d": 393230,
      "h": Number(BigInt(393230)|0x1900000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(107374575630),
//--TRIMMABLE-BOUNDARY-START(51540000782),
    {
      "r": 655361,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "DangerousCopyTo",
      "d": 393230,
      "h": Number(BigInt(393230)|0xC00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540000782)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77309804558),
    {
      "t": 655361,
      "n": "InitialSize",
      "d": 393230,
      "h": Number(BigInt(393230)|0x1200000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77309804558),
//--TRIMMABLE-BOUNDARY-START(94489673742),
    {
      "t": 655361,
      "n": "StartIndex",
      "d": 393230,
      "h": Number(BigInt(393230)|0x1600000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(94489673742),
//--TRIMMABLE-BOUNDARY-START(21475229710),
    {
      "t": 655361,
      "n": "_headIndex",
      "d": 393230,
      "h": Number(BigInt(393230)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475229710),
//--TRIMMABLE-BOUNDARY-START(42950066190),
    {
      "t": 655361,
      "n": "_tailIndex",
      "d": 393230,
      "h": Number(BigInt(393230)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950066190),
//--TRIMMABLE-BOUNDARY-START(8590327822),
    {
      "t": $.$typeArray(T).$h,
      "n": "_array",
      "d": 393230,
      "h": Number(BigInt(393230)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590327822),
//--TRIMMABLE-BOUNDARY-START(25770197006),
    {
      "t": 655361,
      "n": "_mask",
      "d": 393230,
      "h": Number(BigInt(393230)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770197006),
//--TRIMMABLE-BOUNDARY-START(4295360526),
    {
      "t": 655361,
      "n": "_addTakeCount",
      "d": 393230,
      "h": Number(BigInt(393230)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360526),
//--TRIMMABLE-BOUNDARY-START(38655098894),
    {
      "t": 655361,
      "n": "_stealCount",
      "d": 393230,
      "h": Number(BigInt(393230)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655098894),
//--TRIMMABLE-BOUNDARY-START(12885295118),
    {
      "t": 327694,
      "n": "_currentOp",
      "d": 393230,
      "h": Number(BigInt(393230)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885295118),
//--TRIMMABLE-BOUNDARY-START(17180262414),
    {
      "t": 262145,
      "n": "_frozen",
      "d": 393230,
      "h": Number(BigInt(393230)|0x400000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180262414),
//--TRIMMABLE-BOUNDARY-START(30065164302),
    {
      "t": 393230,
      "n": "_nextQueue",
      "d": 393230,
      "h": Number(BigInt(393230)|0x700000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065164302),
//--TRIMMABLE-BOUNDARY-START(34360131598),
    {
      "t": 655361,
      "n": "_ownerThreadId",
      "d": 393230,
      "h": Number(BigInt(393230)|0x800000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360131598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245033486),
    {
      "p": [
        {
          "n": "nextQueue",
          "p": 393230
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393230,
      "h": Number(BigInt(393230)|0xB00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47245033486)
  ],
  "d": $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).$h,
  "h": 393230
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>.WorkStealingQueue`; }
                }, $cls, ($v) => $cls.$_WorkStealingQueue = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393230)
            
            //--TRIMMABLE-BOUNDARY-START(327694)
            static $_Operation;
            static get Operation()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T);
                return $cls.$_Operation ??= $asm.$nstr("$scc.System.Collections.Concurrent.ConcurrentBag$$.Operation", ($self) => class Operation extends $.$$.System.Enum
                {
                    static None = 0;
                    static Add = 1;
                    static Take = 2;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(327694);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Add": 1n,
                            "Take": 2n
                        };
                    }
                    static $h = 327694;
                    static $z = 4;
                    static $f = 0b110000011011001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885229582),
    {
      "t": 327694,
      "n": "None",
      "d": 327694,
      "h": Number(BigInt(327694)|0x300000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229582),
//--TRIMMABLE-BOUNDARY-START(8590262286),
    {
      "t": 327694,
      "n": "Add",
      "d": 327694,
      "h": Number(BigInt(327694)|0x200000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262286),
//--TRIMMABLE-BOUNDARY-START(17180196878),
    {
      "t": 327694,
      "n": "Take",
      "d": 327694,
      "h": Number(BigInt(327694)|0x400000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196878)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295294990),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327694,
      "h": Number(BigInt(327694)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295294990)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).$h,
  "h": 327694
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>.Operation`; }
                }, $cls, ($v) => $cls.$_Operation = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327694)
            
            //--TRIMMABLE-BOUNDARY-START(4350935041)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.CopyTo(T[], int)
            System$Collections$Concurrent$IProducerConsumerCollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4350935041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4350935041)
            
            //--TRIMMABLE-BOUNDARY-START(17235836929)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.TryTake(out T)
            System$Collections$Concurrent$IProducerConsumerCollection$$$TryTake()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17235836929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryTake(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17235836929)
            
            //--TRIMMABLE-BOUNDARY-START(8645902337)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.ToArray()
            System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8645902337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToArray(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8645902337)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(12944801793)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354867201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944801793)
            
            //--TRIMMABLE-BOUNDARY-START(4354473985)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<T>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354473985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354473985)
            
            static $h = 262158;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949935118),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949935118),
//--TRIMMABLE-BOUNDARY-START(51539869710),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331650
      },
      "n": "DangerousCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51539869710),
//--TRIMMABLE-BOUNDARY-START(111669411854),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669411854),
//--TRIMMABLE-BOUNDARY-START(ALL, 146029150222, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 146029150222, 38716964865),
//--TRIMMABLE-BOUNDARY-START(ALL, 150324117518, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 150324117518, 43011932161),
//--TRIMMABLE-BOUNDARY-START(107374444558),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331650
      },
      "n": "GlobalQueuesLock",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(107374444558)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770065934),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "Add",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770065934),
//--TRIMMABLE-BOUNDARY-START(176093921294),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryTake",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176093921294),
//--TRIMMABLE-BOUNDARY-START(163209019406),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209019406),
//--TRIMMABLE-BOUNDARY-START(94489542670),
    {
      "r": 393230,
      "p": [
        {
          "n": "forceCreate",
          "p": 262145
        }
      ],
      "n": "GetCurrentThreadWorkStealingQueue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489542670),
//--TRIMMABLE-BOUNDARY-START(47244902414),
    {
      "r": 393230,
      "n": "CreateWorkStealingQueueForCurrentThread",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244902414),
//--TRIMMABLE-BOUNDARY-START(103079477262),
    {
      "r": 393230,
      "n": "GetUnownedWorkStealingQueue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079477262),
//--TRIMMABLE-BOUNDARY-START(167503986702),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "take",
          "p": 262145
        }
      ],
      "n": "TrySteal",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167503986702),
//--TRIMMABLE-BOUNDARY-START(171798953998),
    {
      "r": 262145,
      "p": [
        {
          "n": "startInclusive",
          "p": 393230
        },
        {
          "n": "endExclusive",
          "p": 393230
        },
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "take",
          "p": 262145
        }
      ],
      "n": "TryStealFromTo",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(171798953998),
//--TRIMMABLE-BOUNDARY-START(38654967822),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967822),
//--TRIMMABLE-BOUNDARY-START(34360000526),
    {
      "r": 655361,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyFromEachQueueToArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360000526),
//--TRIMMABLE-BOUNDARY-START(158914052110),
    {
      "r": $.$typeArray(T).$h,
      "n": "ToArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914052110),
//--TRIMMABLE-BOUNDARY-START(30065033230),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033230),
//--TRIMMABLE-BOUNDARY-START(98784509966),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784509966),
//--TRIMMABLE-BOUNDARY-START(55834837006),
    {
      "r": 65537,
      "p": [
        {
          "n": "lockTaken",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "FreezeBag",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55834837006),
//--TRIMMABLE-BOUNDARY-START(180388888590),
    {
      "r": 65537,
      "p": [
        {
          "n": "lockTaken",
          "p": 262145
        }
      ],
      "n": "UnfreezeBag",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180388888590)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196750),
    {
      "t": $.$$.System.Threading.ThreadLocal$$($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue).$h,
      "n": "_locals",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196750),
//--TRIMMABLE-BOUNDARY-START(12885164046),
    {
      "t": 393230,
      "n": "_workStealingQueues",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164046),
//--TRIMMABLE-BOUNDARY-START(4295229454),
    {
      "t": 917505,
      "n": "_emptyToNonEmptyListTransitionCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229454)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131342),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131342),
//--TRIMMABLE-BOUNDARY-START(21475098638),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098638)
  ],
  "i": [$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,62259201,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,62521345
  ],
  "g": [T?.$h??1507328
  ],
  "j": [393230,327694
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70582273,
      "c": 8660516865,
      "a": [
        {
          "v": $.$scc.System.Collections.Concurrent.IProducerConsumerCollectionDebugView$$().$h,
          "t": 187629569
        }
      ]
    },
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262158)
        
        
        //--TRIMMABLE-BOUNDARY-START(65550)
        $asm.$cls("$scc.System.Collections.Concurrent.BlockingCollection<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.BlockingCollection<>", [T], ($self) => class BlockingCollection$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590000142)
            /*IProducerConsumerCollection<T>*/ _collection = null;
            //--TRIMMABLE-BOUNDARY-END(8590000142)
            
            //--TRIMMABLE-BOUNDARY-START(4295032846)
            /*int*/ _boundedCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(4295032846)
            
            //--TRIMMABLE-BOUNDARY-START(176093724686)
            /*int*/ static NON_BOUNDED = -1;
            //--TRIMMABLE-BOUNDARY-END(176093724686)
            
            //--TRIMMABLE-BOUNDARY-START(21474902030)
            /*SemaphoreSlim?*/ _freeNodes = null;
            //--TRIMMABLE-BOUNDARY-END(21474902030)
            
            //--TRIMMABLE-BOUNDARY-START(30064836622)
            /*SemaphoreSlim*/ _occupiedNodes = null;
            //--TRIMMABLE-BOUNDARY-END(30064836622)
            
            //--TRIMMABLE-BOUNDARY-START(25769869326)
            /*bool*/ _isDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(25769869326)
            
            //--TRIMMABLE-BOUNDARY-START(12884967438)
            /*CancellationTokenSource*/ _consumersCancellationTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(12884967438)
            
            //--TRIMMABLE-BOUNDARY-START(34359803918)
            /*CancellationTokenSource*/ _producersCancellationTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(34359803918)
            
            //--TRIMMABLE-BOUNDARY-START(17179934734)
            /*int*/ _currentAdders = 0;
            //--TRIMMABLE-BOUNDARY-END(17179934734)
            
            //--TRIMMABLE-BOUNDARY-START(90194378766)
            /*int*/ static COMPLETE_ADDING_ON_MASK = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(90194378766)
            
            //--TRIMMABLE-BOUNDARY-START(73014509582)
            /*int */ get BoundedCapacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259149838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return this._boundedCapacity;
            }
            //--TRIMMABLE-BOUNDARY-END(73014509582)
            
            //--TRIMMABLE-BOUNDARY-START(167503790094)
            /*bool */ get IsAddingCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439019022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return (this._currentAdders === -2147483648/*COMPLETE_ADDING_ON_MASK*/);
            }
            //--TRIMMABLE-BOUNDARY-END(167503790094)
            
            //--TRIMMABLE-BOUNDARY-START(171798757390)
            /*bool */ get IsCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028953614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return (this.IsAddingCompleted && (this._occupiedNodes.CurrentCount === 0));
            }
            //--TRIMMABLE-BOUNDARY-END(171798757390)
            
            //--TRIMMABLE-BOUNDARY-START(103079280654)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849084430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return this._occupiedNodes.CurrentCount;
            }
            //--TRIMMABLE-BOUNDARY-END(103079280654)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 206158495758, 38716964865)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273593870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 206158495758, 38716964865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 210453463054, 43011932161)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863528462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 210453463054, 43011932161)
            
            //--TRIMMABLE-BOUNDARY-START(38654771214)
            $ctor$1()
            {
                this.$ctor$3(new ($.$$.System.Collections.Concurrent.ConcurrentQueue$$(T))().$ctor$1());
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654771214);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771214)
            
            //--TRIMMABLE-BOUNDARY-START(42949738510)
            $ctor$4(/*int*/ boundedCapacity)
            {
                this.$ctor$2(new ($.$$.System.Collections.Concurrent.ConcurrentQueue$$(T))().$ctor$1(), boundedCapacity);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949738510);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738510)
            
            //--TRIMMABLE-BOUNDARY-START(47244705806)
            $ctor$2(/*IProducerConsumerCollection<T>*/ collection, /*int*/ boundedCapacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244705806);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, boundedCapacity, "boundedCapacity");
                    /*int*/ let count = collection.System$Collections$ICollection$Count;
                    if (count > boundedCapacity)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.BlockingCollection_ctor_CountMoreThanCapacity);
                    }
                    this.Initialize(collection, boundedCapacity, count);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244705806)
            
            //--TRIMMABLE-BOUNDARY-START(51539673102)
            $ctor$3(/*IProducerConsumerCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539673102);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.Initialize(collection, -1/*NON_BOUNDED*/, collection.System$Collections$ICollection$Count);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539673102)
            
            //--TRIMMABLE-BOUNDARY-START(163208822798)
            /*void */ Initialize(/*IProducerConsumerCollection<T>*/ collection, /*int*/ boundedCapacity, /*int*/ collectionCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208822798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(boundedCapacity > 0 || boundedCapacity === -1/*NON_BOUNDED*/, "boundedCapacity > 0 || boundedCapacity == NON_BOUNDED");
                this._collection = collection;
                this._boundedCapacity = boundedCapacity;
                this._isDisposed = false;
                this._consumersCancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                this._producersCancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                if (boundedCapacity === -1/*NON_BOUNDED*/)
                {
                    this._freeNodes = null;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(boundedCapacity > 0, "boundedCapacity > 0");
                    this._freeNodes = new $.$$.System.Threading.SemaphoreSlim().$ctor$2(((boundedCapacity - collectionCount) | 0));
                }
                this._occupiedNodes = new $.$$.System.Threading.SemaphoreSlim().$ctor$2(collectionCount);
            }
            //--TRIMMABLE-BOUNDARY-END(163208822798)
            
            //--TRIMMABLE-BOUNDARY-START(55834640398)
            /*void */ Add$1(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let tryAddReturnValue = this.TryAddWithNoTimeValidation(item, -1/*Timeout.Infinite*/, $.$$.System.Threading.CancellationToken.None);
                $.$$.System.Diagnostics.Debug.Assert$2(tryAddReturnValue, "TryAdd() was expected to return true.");
            }
            //--TRIMMABLE-BOUNDARY-END(55834640398)
            
            //--TRIMMABLE-BOUNDARY-START(60129607694)
            /*void */ Add(/*T*/ item, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let tryAddReturnValue = this.TryAddWithNoTimeValidation(item, -1/*Timeout.Infinite*/, cancellationToken);
                $.$$.System.Diagnostics.Debug.Assert$2(tryAddReturnValue, "TryAdd() was expected to return true.");
            }
            //--TRIMMABLE-BOUNDARY-END(60129607694)
            
            //--TRIMMABLE-BOUNDARY-START(240518234126)
            /*bool */ TryAdd$3(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518234126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryAddWithNoTimeValidation(item, 0, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(240518234126)
            
            //--TRIMMABLE-BOUNDARY-START(244813201422)
            /*bool */ TryAdd$2(/*T*/ item, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813201422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateTimeout(timeout);
                return this.TryAddWithNoTimeValidation(item, $.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(244813201422)
            
            //--TRIMMABLE-BOUNDARY-START(249108168718)
            /*bool */ TryAdd$1(/*T*/ item, /*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108168718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryAddWithNoTimeValidation(item, millisecondsTimeout, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(249108168718)
            
            //--TRIMMABLE-BOUNDARY-START(253403136014)
            /*bool */ TryAdd(/*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403136014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryAddWithNoTimeValidation(item, millisecondsTimeout, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(253403136014)
            
            //--TRIMMABLE-BOUNDARY-START(283467907086)
            /*bool */ TryAddWithNoTimeValidation(/*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283467907086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                cancellationToken.ThrowIfCancellationRequested();
                if (this.IsAddingCompleted)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Completed);
                }
                /*bool*/ let waitForSemaphoreWasSuccessful = true;
                if (this._freeNodes !== null)
                {
                    /*CancellationTokenSource?*/ let linkedTokenSource = null;
                    try
                    {
                        waitForSemaphoreWasSuccessful = this._freeNodes.Wait$1(0, new $.$$.System.Threading.CancellationToken());
                        if (waitForSemaphoreWasSuccessful === false && millisecondsTimeout !== 0)
                        {
                            linkedTokenSource = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._producersCancellationTokenSource.Token);
                            waitForSemaphoreWasSuccessful = this._freeNodes.Wait$1(millisecondsTimeout, linkedTokenSource.Token);
                        }
                    }
                    catch($e)
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Add_ConcurrentCompleteAdd);
                    }
                    finally
                    {
                        {
                            linkedTokenSource?.Dispose();
                        }
                    }
                }
                if (waitForSemaphoreWasSuccessful)
                {
                    /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                    while(true)
                    {
                        /*int*/ let observedAdders = this._currentAdders;
                        if ((observedAdders & -2147483648/*COMPLETE_ADDING_ON_MASK*/) !== 0)
                        {
                            spinner.Reset();
                            while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                            {
                                spinner.SpinOnce();
                            }
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Completed);
                        }
                        if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.System.Int32), ((observedAdders + 1) | 0), observedAdders) === observedAdders)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2((((observedAdders + 1) | 0)) <= (~-2147483648/*COMPLETE_ADDING_ON_MASK*/), "The number of concurrent adders thread exceeded the maximum limit.");
                            break;
                        }
                        spinner.SpinOnce$1(-1);
                    }
                    /*bool*/ let addingSucceeded = false;
                    try
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        addingSucceeded = this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$TryAdd(item, [T]);
                        if (!addingSucceeded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Add_Failed);
                        }
                    }
                    finally
                    {
                        {
                            if (addingSucceeded)
                            {
                                this._occupiedNodes.Release();
                            }
                            else 
                            {
                                this._freeNodes?.Release();
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2((this._currentAdders & ~-2147483648/*COMPLETE_ADDING_ON_MASK*/) > 0, "(_currentAdders & ~COMPLETE_ADDING_ON_MASK) > 0");
                            $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.System.Int32));
                        }
                    }
                }
                return waitForSemaphoreWasSuccessful;
            }
            //--TRIMMABLE-BOUNDARY-END(283467907086)
            
            //--TRIMMABLE-BOUNDARY-START(219043397646)
            /*T */ Take()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043397646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T?*/ let item;
                if (!this.TryTake($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, $.$$.System.Threading.CancellationToken.None))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_CantTakeWhenDone);
                }
                return item;
            }
            //--TRIMMABLE-BOUNDARY-END(219043397646)
            
            //--TRIMMABLE-BOUNDARY-START(223338364942)
            /*T */ Take$1(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338364942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T?*/ let item;
                if (!this.TryTake($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, cancellationToken))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_CantTakeWhenDone);
                }
                return item;
            }
            //--TRIMMABLE-BOUNDARY-END(223338364942)
            
            //--TRIMMABLE-BOUNDARY-START(287762874382)
            /*bool */ TryTake$3(/*out T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287762874382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryTake(item, 0, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(287762874382)
            
            //--TRIMMABLE-BOUNDARY-START(292057841678)
            /*bool */ TryTake$2(/*out T*/ item, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292057841678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateTimeout(timeout);
                return this.TryTakeWithNoTimeValidation(item, $.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), $.$$.System.Threading.CancellationToken.None, null);
            }
            //--TRIMMABLE-BOUNDARY-END(292057841678)
            
            //--TRIMMABLE-BOUNDARY-START(296352808974)
            /*bool */ TryTake$1(/*out T*/ item, /*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296352808974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryTakeWithNoTimeValidation(item, millisecondsTimeout, $.$$.System.Threading.CancellationToken.None, null);
            }
            //--TRIMMABLE-BOUNDARY-END(296352808974)
            
            //--TRIMMABLE-BOUNDARY-START(300647776270)
            /*bool */ TryTake(/*out T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647776270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryTakeWithNoTimeValidation(item, millisecondsTimeout, cancellationToken, null);
            }
            //--TRIMMABLE-BOUNDARY-END(300647776270)
            
            //--TRIMMABLE-BOUNDARY-START(330712547342)
            /*bool */ TryTakeWithNoTimeValidation(/*out T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken, /*CancellationTokenSource?*/ combinedTokenSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712547342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                item.$v = $.$default(T);
                cancellationToken.ThrowIfCancellationRequested();
                if (this.IsCompleted)
                {
                    return false;
                }
                /*bool*/ let waitForSemaphoreWasSuccessful = false;
                /*CancellationTokenSource?*/ let linkedTokenSource = combinedTokenSource;
                try
                {
                    waitForSemaphoreWasSuccessful = this._occupiedNodes.Wait$2(0);
                    if (waitForSemaphoreWasSuccessful === false && millisecondsTimeout !== 0)
                    {
                        linkedTokenSource ??= $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._consumersCancellationTokenSource.Token);
                        waitForSemaphoreWasSuccessful = this._occupiedNodes.Wait$1(millisecondsTimeout, linkedTokenSource.Token);
                    }
                }
                catch($e)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    return false;
                }
                finally
                {
                    {
                        if (linkedTokenSource !== null && combinedTokenSource === null)
                        {
                            linkedTokenSource.Dispose();
                        }
                    }
                }
                if (waitForSemaphoreWasSuccessful)
                {
                    /*bool*/ let removeSucceeded = false;
                    try
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        removeSucceeded = this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$TryTake(item, [T]);
                        if (!removeSucceeded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Take_CollectionModified);
                        }
                    }
                    finally
                    {
                        {
                            if (removeSucceeded)
                            {
                                if (this._freeNodes !== null)
                                {
                                    $.$$.System.Diagnostics.Debug.Assert$2(this._boundedCapacity !== -1/*NON_BOUNDED*/, "_boundedCapacity != NON_BOUNDED");
                                    this._freeNodes.Release();
                                }
                            }
                            else 
                            {
                                this._occupiedNodes.Release();
                            }
                            if (this.IsCompleted)
                            {
                                this.CancelWaitingConsumers();
                            }
                        }
                    }
                }
                return waitForSemaphoreWasSuccessful;
            }
            //--TRIMMABLE-BOUNDARY-END(330712547342)
            
            //--TRIMMABLE-BOUNDARY-START(64424574990)
            static /*int */ AddToAny$1(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424574990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tryAddAnyReturnValue = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAny(collections, item, -1/*Timeout.Infinite*/, $.$$.System.Threading.CancellationToken.None);
                $.$$.System.Diagnostics.Debug.Assert$2(tryAddAnyReturnValue >= 0 && tryAddAnyReturnValue < collections.length, "TryAddToAny() was expected to return an index within the bounds of the collections array.");
                return tryAddAnyReturnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(64424574990)
            
            //--TRIMMABLE-BOUNDARY-START(68719542286)
            static /*int */ AddToAny(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719542286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tryAddAnyReturnValue = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAny(collections, item, -1/*Timeout.Infinite*/, cancellationToken);
                $.$$.System.Diagnostics.Debug.Assert$2(tryAddAnyReturnValue >= 0 && tryAddAnyReturnValue < collections.length, "TryAddToAny() was expected to return an index within the bounds of the collections array.");
                return tryAddAnyReturnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(68719542286)
            
            //--TRIMMABLE-BOUNDARY-START(257698103310)
            static /*int */ TryAddToAny$3(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698103310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAny(collections, item, 0, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(257698103310)
            
            //--TRIMMABLE-BOUNDARY-START(261993070606)
            static /*int */ TryAddToAny$2(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993070606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateTimeout(timeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAnyCore(collections, item, $.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(261993070606)
            
            //--TRIMMABLE-BOUNDARY-START(266288037902)
            static /*int */ TryAddToAny$1(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288037902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAnyCore(collections, item, millisecondsTimeout, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(266288037902)
            
            //--TRIMMABLE-BOUNDARY-START(270583005198)
            static /*int */ TryAddToAny(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583005198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAnyCore(collections, item, millisecondsTimeout, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(270583005198)
            
            //--TRIMMABLE-BOUNDARY-START(274877972494)
            static /*int */ TryAddToAnyCore(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ externalCancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274877972494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateCollectionsArray(collections, true);
                /*int*/ let OPERATION_FAILED = -1;
                /*int*/ let timeout = millisecondsTimeout;
                /*uint*/ let startTime = 0;
                if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                {
                    startTime = ($.$$.System.Environment.TickCount >>> 0);
                }
                /*int*/ let index = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAnyFast(collections, item);
                if (index > -1)
                {
                    return index;
                }
                /*CancellationToken[]*/ let collatedCancellationTokens;
                /*List<WaitHandle>*/ let handles = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).GetHandles(collections, externalCancellationToken, true, $.$ref(() => collatedCancellationTokens, ($v) => collatedCancellationTokens = $v, $.$typeArray($.$$.System.Threading.CancellationToken)));
                while(millisecondsTimeout === -1/*Timeout.Infinite*/ || timeout >= 0)
                {
                    index = -1;
                    let linkedTokenSource = null;
                    try
                    {
                        linkedTokenSource = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$3(collatedCancellationTokens);
                        handles.Add(linkedTokenSource.Token.WaitHandle);
                        index = $.$$.System.Threading.WaitHandle.WaitAny$3(handles.ToArray(), timeout);
                        handles.RemoveAt(((handles.Count - 1) | 0));
                        if (linkedTokenSource.IsCancellationRequested)
                        {
                            externalCancellationToken.ThrowIfCancellationRequested();
                            throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CantAddAnyWhenCompleted, "collections");
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.System$IDisposable$Dispose();
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((index === 258/*WaitHandle.WaitTimeout*/) || (index >= 0 && index < handles.Count), "(index == WaitHandle.WaitTimeout) || (index >= 0 && index < handles.Count)");
                    if (index === 258/*WaitHandle.WaitTimeout*/)
                    {
                        return OPERATION_FAILED;
                    }
                    if ($.$$.System.Array.$ReadT1.call(collections, index).TryAdd$3(item))
                    {
                        return index;
                    }
                    if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                    {
                        timeout = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).UpdateTimeOut(startTime, millisecondsTimeout);
                    }
                }
                return OPERATION_FAILED;
            }
            //--TRIMMABLE-BOUNDARY-END(274877972494)
            
            //--TRIMMABLE-BOUNDARY-START(279172939790)
            static /*int */ TryAddToAnyFast(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279172939790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < collections.length; i++)
                {
                    if ($.$$.System.Array.$ReadT1.call(collections, i)._freeNodes === null)
                    {
                        /*bool*/ let result = $.$$.System.Array.$ReadT1.call(collections, i).TryAdd$3(item);
                        $.$$.System.Diagnostics.Debug.Assert$2(result, "result");
                        return i;
                    }
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(279172939790)
            
            //--TRIMMABLE-BOUNDARY-START(158913855502)
            static /*List<WaitHandle> */ GetHandles(/*BlockingCollection<T>[]*/ collections, /*CancellationToken*/ externalCancellationToken, /*bool*/ isAddOperation, /*out CancellationToken[]*/ cancellationTokens)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913855502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(collections !== null, "collections != null");
                /*List<WaitHandle>*/ let handlesList = new ($.$$.System.Collections.Generic.List$$($.$$.System.Threading.WaitHandle))().$ctor$3(((collections.length + 1) | 0));
                /*List<CancellationToken>*/ let tokensList = new ($.$$.System.Collections.Generic.List$$($.$$.System.Threading.CancellationToken))().$ctor$3(((collections.length + 1) | 0));
                tokensList.Add(externalCancellationToken);
                if (isAddOperation)
                {
                    for(/*int*/ let i = 0; i < collections.length; i++)
                    {
                        /*BlockingCollection<T>*/ let c = $.$$.System.Array.$ReadT1.call(collections, i);
                        if (c._freeNodes !== null)
                        {
                            handlesList.Add(c._freeNodes.AvailableWaitHandle);
                            tokensList.Add(c._producersCancellationTokenSource.Token);
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < collections.length; i++)
                    {
                        if ($.$$.System.Array.$ReadT1.call(collections, i).IsCompleted)
                        {
                            continue;
                        }
                        handlesList.Add($.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.AvailableWaitHandle);
                        tokensList.Add($.$$.System.Array.$ReadT1.call(collections, i)._consumersCancellationTokenSource.Token);
                    }
                }
                cancellationTokens.$v = tokensList.ToArray();
                return handlesList;
            }
            //--TRIMMABLE-BOUNDARY-END(158913855502)
            
            //--TRIMMABLE-BOUNDARY-START(335007514638)
            static /*int */ UpdateTimeOut(/*uint*/ startTime, /*int*/ originalWaitMillisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007514638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (originalWaitMillisecondsTimeout === 0)
                {
                    return 0;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(originalWaitMillisecondsTimeout !== -1/*Timeout.Infinite*/, "originalWaitMillisecondsTimeout != Timeout.Infinite");
                /*uint*/ let elapsedMilliseconds = ((($.$$.System.Environment.TickCount >>> 0) - startTime) >>> 0);
                if (elapsedMilliseconds > 2147483647/*int.MaxValue*/)
                {
                    return 0;
                }
                /*int*/ let currentWaitTimeout = ((originalWaitMillisecondsTimeout - (elapsedMilliseconds | 0)) | 0);
                if (currentWaitTimeout <= 0)
                {
                    return 0;
                }
                return currentWaitTimeout;
            }
            //--TRIMMABLE-BOUNDARY-END(335007514638)
            
            //--TRIMMABLE-BOUNDARY-START(227633332238)
            static /*int */ TakeFromAny$1(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633332238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TakeFromAny(collections, item, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(227633332238)
            
            //--TRIMMABLE-BOUNDARY-START(231928299534)
            static /*int */ TakeFromAny(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928299534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let returnValue = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, -1/*Timeout.Infinite*/, true, cancellationToken);
                $.$$.System.Diagnostics.Debug.Assert$2(returnValue >= 0 && returnValue < collections.length, "TryTakeFromAny() was expected to return an index within the bounds of the collections array.");
                return returnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(231928299534)
            
            //--TRIMMABLE-BOUNDARY-START(304942743566)
            static /*int */ TryTakeFromAny$3(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942743566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAny$1(collections, item, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(304942743566)
            
            //--TRIMMABLE-BOUNDARY-START(309237710862)
            static /*int */ TryTakeFromAny$2(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237710862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateTimeout(timeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, $.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), false, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(309237710862)
            
            //--TRIMMABLE-BOUNDARY-START(313532678158)
            static /*int */ TryTakeFromAny$1(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532678158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, millisecondsTimeout, false, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(313532678158)
            
            //--TRIMMABLE-BOUNDARY-START(317827645454)
            static /*int */ TryTakeFromAny(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827645454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, millisecondsTimeout, false, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(317827645454)
            
            //--TRIMMABLE-BOUNDARY-START(322122612750)
            static /*int */ TryTakeFromAnyCore(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*bool*/ isTakeOperation, /*CancellationToken*/ externalCancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122612750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateCollectionsArray(collections, false);
                for(/*int*/ let i = 0; i < collections.length; i++)
                {
                    if (!$.$$.System.Array.$ReadT1.call(collections, i).IsCompleted && $.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.CurrentCount > 0 && $.$$.System.Array.$ReadT1.call(collections, i).TryTake$3(item))
                    {
                        return i;
                    }
                }
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCoreSlow(collections, item, millisecondsTimeout, isTakeOperation, externalCancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(322122612750)
            
            //--TRIMMABLE-BOUNDARY-START(326417580046)
            static /*int */ TryTakeFromAnyCoreSlow(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*bool*/ isTakeOperation, /*CancellationToken*/ externalCancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417580046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let OPERATION_FAILED = -1;
                /*int*/ let timeout = millisecondsTimeout;
                /*uint*/ let startTime = 0;
                if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                {
                    startTime = ($.$$.System.Environment.TickCount >>> 0);
                }
                while(millisecondsTimeout === -1/*Timeout.Infinite*/ || timeout >= 0)
                {
                    /*CancellationToken[]*/ let collatedCancellationTokens;
                    /*List<WaitHandle>*/ let handles = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).GetHandles(collections, externalCancellationToken, false, $.$ref(() => collatedCancellationTokens, ($v) => collatedCancellationTokens = $v, $.$typeArray($.$$.System.Threading.CancellationToken)));
                    if (handles.Count === 0 && isTakeOperation)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CantTakeAnyWhenAllDone, "collections");
                    }
                    if (handles.Count === 0)
                    {
                        break;
                    }
                    let linkedTokenSource = null;
                    try
                    {
                        linkedTokenSource = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$3(collatedCancellationTokens);
                        handles.Add(linkedTokenSource.Token.WaitHandle);
                        /*int*/ let index = $.$$.System.Threading.WaitHandle.WaitAny$3(handles.ToArray(), timeout);
                        if (linkedTokenSource.IsCancellationRequested)
                        {
                            externalCancellationToken.ThrowIfCancellationRequested();
                        }
                        if (!linkedTokenSource.IsCancellationRequested)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2((index === 258/*WaitHandle.WaitTimeout*/) || (index >= 0 && index < handles.Count), "(index == WaitHandle.WaitTimeout) || (index >= 0 && index < handles.Count)");
                            if (index === 258/*WaitHandle.WaitTimeout*/)
                            {
                                break;
                            }
                            if (collections.length !== ((handles.Count - 1) | 0))
                            {
                                for(/*int*/ let i = 0; i < collections.length; i++)
                                {
                                    if ($.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.AvailableWaitHandle === handles.get_Item(index))
                                    {
                                        index = i;
                                        break;
                                    }
                                }
                            }
                            if ($.$$.System.Array.$ReadT1.call(collections, index).TryTake$3(item))
                            {
                                return index;
                            }
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.System$IDisposable$Dispose();
                    }
                    if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                    {
                        timeout = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).UpdateTimeOut(startTime, millisecondsTimeout);
                    }
                }
                item.$v = $.$default(T);
                return OPERATION_FAILED;
            }
            //--TRIMMABLE-BOUNDARY-END(326417580046)
            
            //--TRIMMABLE-BOUNDARY-START(94489346062)
            /*void */ CompleteAdding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                if (this.IsAddingCompleted)
                {
                    return;
                }
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    /*int*/ let observedAdders = this._currentAdders;
                    if ((observedAdders & -2147483648/*COMPLETE_ADDING_ON_MASK*/) !== 0)
                    {
                        spinner.Reset();
                        while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                        {
                            spinner.SpinOnce();
                        }
                        return;
                    }
                    if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.System.Int32), observedAdders | -2147483648/*COMPLETE_ADDING_ON_MASK*/, observedAdders) === observedAdders)
                    {
                        spinner.Reset();
                        while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                        {
                            spinner.SpinOnce();
                        }
                        if (this.Count === 0)
                        {
                            this.CancelWaitingConsumers();
                        }
                        this.CancelWaitingProducers();
                        return;
                    }
                    spinner.SpinOnce$1(-1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489346062)
            
            //--TRIMMABLE-BOUNDARY-START(77309476878)
            /*void */ CancelWaitingConsumers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._consumersCancellationTokenSource.Cancel();
            }
            //--TRIMMABLE-BOUNDARY-END(77309476878)
            
            //--TRIMMABLE-BOUNDARY-START(81604444174)
            /*void */ CancelWaitingProducers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._producersCancellationTokenSource.Cancel();
            }
            //--TRIMMABLE-BOUNDARY-END(81604444174)
            
            //--TRIMMABLE-BOUNDARY-START(107374247950)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374247950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(107374247950)
            
            //--TRIMMABLE-BOUNDARY-START(111669215246)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._isDisposed)
                {
                    this._freeNodes?.Dispose();
                    this._occupiedNodes.Dispose();
                    this._isDisposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669215246)
            
            //--TRIMMABLE-BOUNDARY-START(236223266830)
            /*T[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223266830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray([T]);
            }
            //--TRIMMABLE-BOUNDARY-END(236223266830)
            
            //--TRIMMABLE-BOUNDARY-START(98784313358)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                (this).System$Collections$ICollection$CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(98784313358)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 184683659278, 4357226497)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683659278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                /*T[]*/ let collectionSnapShot = this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray([T]);
                try
                {
                    $.$$.System.Array.Copy$2(collectionSnapShot, 0, array, index, collectionSnapShot.length);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.ArgumentNullException)
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("array");
                    }
                    else if ($e instanceof $.$$.System.ArgumentOutOfRangeException)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$scc.System.SR.BlockingCollection_CopyTo_NonNegative);
                    }
                    else if ($e instanceof $.$$.System.ArgumentException)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.Collection_CopyTo_TooManyElems, "index");
                    }
                    else if ($e instanceof $.$$.System.RankException)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CopyTo_MultiDim, "array");
                    }
                    else if ($e instanceof $.$$.System.InvalidCastException)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CopyTo_IncorrectType, "array");
                    }
                    else if ($e instanceof $.$$.System.ArrayTypeMismatchException)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CopyTo_IncorrectType, "array");
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 184683659278, 4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(150323920910)
            /*IEnumerable<T> */ GetConsumingEnumerable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323920910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetConsumingEnumerable$1($.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(150323920910)
            
            //--TRIMMABLE-BOUNDARY-START(154618888206)
            /*IEnumerable<T> */ GetConsumingEnumerable$1(/*CancellationToken*/ cancellationToken)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.IsCompleted)
                    {
                        return;
                    }
                    /*CancellationTokenSource*/ let linkedTokenSource = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._consumersCancellationTokenSource.Token);
                    try
                    {
                        /*T?*/ let item;
                        while(this.TryTakeWithNoTimeValidation($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, cancellationToken, linkedTokenSource))
                        {
                            yield item;
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(154618888206)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 180388691982, 4354473985)
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388691982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return this._collection.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 180388691982, 4354473985)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 214748430350, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748430350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 214748430350, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(339302481934)
            static /*void */ ValidateCollectionsArray(/*BlockingCollection<T>[]*/ collections, /*bool*/ isAddOperation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302481934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collections, "collections");
                if (collections.length < 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_ValidateCollectionsArray_ZeroSize, "collections");
                }
                if ((collections.length > 63) || ((collections.length === 63) && ($.$$.System.Threading.Thread.CurrentThread.GetApartmentState() === 0/*ApartmentState.STA*/)))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("collections", $.$scc.System.SR.BlockingCollection_ValidateCollectionsArray_LargeSize);
                }
                for(/*int*/ let i = 0; i < collections.length; ++i)
                {
                    if ($.$$.System.Array.$ReadT1.call(collections, i) === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_ValidateCollectionsArray_NullElems, "collections");
                    }
                    if ($.$$.System.Array.$ReadT1.call(collections, i)._isDisposed)
                    {
                        throw new $.$$.System.ObjectDisposedException().$ctor$16("collections", $.$scc.System.SR.BlockingCollection_ValidateCollectionsArray_DispElems);
                    }
                    if (isAddOperation && $.$$.System.Array.$ReadT1.call(collections, i).IsAddingCompleted)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CantAddAnyWhenCompleted, "collections");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339302481934)
            
            //--TRIMMABLE-BOUNDARY-START(347892416526)
            static /*void */ ValidateTimeout(/*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892416526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                if ((totalMilliseconds < 0n || totalMilliseconds > BigInt(2147483647/*int.MaxValue*/)) && (totalMilliseconds !== BigInt(-1/*Timeout.Infinite*/)))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("timeout", timeout, $.$scc.System.SR.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$scc.System.SR.BlockingCollection_TimeoutInvalid, $.$box(2147483647/*int.MaxValue*/, $.$$.System.Int32)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(347892416526)
            
            //--TRIMMABLE-BOUNDARY-START(343597449230)
            static /*void */ ValidateMillisecondsTimeout(/*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597449230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((millisecondsTimeout < 0) && (millisecondsTimeout !== -1/*Timeout.Infinite*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("millisecondsTimeout", $.$box(millisecondsTimeout, $.$$.System.Int32), $.$scc.System.SR.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$scc.System.SR.BlockingCollection_TimeoutInvalid, $.$box(2147483647/*int.MaxValue*/, $.$$.System.Int32)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343597449230)
            
            //--TRIMMABLE-BOUNDARY-START(85899411470)
            /*void */ CheckDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(85899411470)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //--TRIMMABLE-BOUNDARY-START(12944801793)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354867201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944801793)
            
            static $h = 65550;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014509582),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "n": "BoundedCapacity",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014509582),
//--TRIMMABLE-BOUNDARY-START(167503790094),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331649
      },
      "n": "IsAddingCompleted",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167503790094),
//--TRIMMABLE-BOUNDARY-START(171798757390),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 50331649
      },
      "n": "IsCompleted",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171798757390),
//--TRIMMABLE-BOUNDARY-START(103079280654),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079280654),
//--TRIMMABLE-BOUNDARY-START(ALL, 206158495758, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2D00000000n),
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 206158495758, 38716964865),
//--TRIMMABLE-BOUNDARY-START(ALL, 210453463054, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2F00000000n),
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 210453463054, 43011932161)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(163208822798),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h
        },
        {
          "n": "boundedCapacity",
          "p": 655361
        },
        {
          "n": "collectionCount",
          "p": 655361
        }
      ],
      "n": "Initialize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163208822798),
//--TRIMMABLE-BOUNDARY-START(55834640398),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834640398),
//--TRIMMABLE-BOUNDARY-START(60129607694),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "Add",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129607694),
//--TRIMMABLE-BOUNDARY-START(240518234126),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryAdd",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240518234126),
//--TRIMMABLE-BOUNDARY-START(244813201422),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "TryAdd",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813201422),
//--TRIMMABLE-BOUNDARY-START(249108168718),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "TryAdd",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249108168718),
//--TRIMMABLE-BOUNDARY-START(253403136014),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "TryAdd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253403136014),
//--TRIMMABLE-BOUNDARY-START(283467907086),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "TryAddWithNoTimeValidation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283467907086),
//--TRIMMABLE-BOUNDARY-START(219043397646),
    {
      "r": T?.$h??1507328,
      "n": "Take",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219043397646),
//--TRIMMABLE-BOUNDARY-START(223338364942),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "Take",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223338364942),
//--TRIMMABLE-BOUNDARY-START(287762874382),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryTake",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(287762874382),
//--TRIMMABLE-BOUNDARY-START(292057841678),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "TryTake",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292057841678),
//--TRIMMABLE-BOUNDARY-START(296352808974),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "TryTake",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296352808974),
//--TRIMMABLE-BOUNDARY-START(300647776270),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "TryTake",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300647776270),
//--TRIMMABLE-BOUNDARY-START(330712547342),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "combinedTokenSource",
          "p": 170065921
        }
      ],
      "n": "TryTakeWithNoTimeValidation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(330712547342),
//--TRIMMABLE-BOUNDARY-START(64424574990),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "AddToAny",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424574990),
//--TRIMMABLE-BOUNDARY-START(68719542286),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "AddToAny",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719542286),
//--TRIMMABLE-BOUNDARY-START(257698103310),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryAddToAny",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257698103310),
//--TRIMMABLE-BOUNDARY-START(261993070606),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "TryAddToAny",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(261993070606),
//--TRIMMABLE-BOUNDARY-START(266288037902),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "TryAddToAny",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(266288037902),
//--TRIMMABLE-BOUNDARY-START(270583005198),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "TryAddToAny",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(270583005198),
//--TRIMMABLE-BOUNDARY-START(274877972494),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "externalCancellationToken",
          "p": 169934849
        }
      ],
      "n": "TryAddToAnyCore",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(274877972494),
//--TRIMMABLE-BOUNDARY-START(279172939790),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryAddToAnyFast",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(279172939790),
//--TRIMMABLE-BOUNDARY-START(158913855502),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$$.System.Threading.WaitHandle).$h,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "externalCancellationToken",
          "p": 169934849
        },
        {
          "n": "isAddOperation",
          "p": 262145
        },
        {
          "n": "cancellationTokens",
          "p": $.$typeArray($.$$.System.Threading.CancellationToken).$h,
          "f": 2
        }
      ],
      "n": "GetHandles",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(158913855502),
//--TRIMMABLE-BOUNDARY-START(335007514638),
    {
      "r": 655361,
      "p": [
        {
          "n": "startTime",
          "p": 720897
        },
        {
          "n": "originalWaitMillisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "UpdateTimeOut",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(335007514638),
//--TRIMMABLE-BOUNDARY-START(227633332238),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TakeFromAny",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(227633332238),
//--TRIMMABLE-BOUNDARY-START(231928299534),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "TakeFromAny",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(231928299534),
//--TRIMMABLE-BOUNDARY-START(304942743566),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryTakeFromAny",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4700000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(304942743566),
//--TRIMMABLE-BOUNDARY-START(309237710862),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "TryTakeFromAny",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(309237710862),
//--TRIMMABLE-BOUNDARY-START(313532678158),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "TryTakeFromAny",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4900000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313532678158),
//--TRIMMABLE-BOUNDARY-START(317827645454),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "TryTakeFromAny",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4A00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(317827645454),
//--TRIMMABLE-BOUNDARY-START(322122612750),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "isTakeOperation",
          "p": 262145
        },
        {
          "n": "externalCancellationToken",
          "p": 169934849
        }
      ],
      "n": "TryTakeFromAnyCore",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4B00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(322122612750),
//--TRIMMABLE-BOUNDARY-START(326417580046),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "isTakeOperation",
          "p": 262145
        },
        {
          "n": "externalCancellationToken",
          "p": 169934849
        }
      ],
      "n": "TryTakeFromAnyCoreSlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4C00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(326417580046),
//--TRIMMABLE-BOUNDARY-START(94489346062),
    {
      "r": 65537,
      "n": "CompleteAdding",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489346062),
//--TRIMMABLE-BOUNDARY-START(77309476878),
    {
      "r": 65537,
      "n": "CancelWaitingConsumers",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77309476878),
//--TRIMMABLE-BOUNDARY-START(81604444174),
    {
      "r": 65537,
      "n": "CancelWaitingProducers",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604444174),
//--TRIMMABLE-BOUNDARY-START(107374247950),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374247950),
//--TRIMMABLE-BOUNDARY-START(111669215246),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(111669215246),
//--TRIMMABLE-BOUNDARY-START(236223266830),
    {
      "r": $.$typeArray(T).$h,
      "n": "ToArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236223266830),
//--TRIMMABLE-BOUNDARY-START(98784313358),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784313358),
//--TRIMMABLE-BOUNDARY-START(150323920910),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "n": "GetConsumingEnumerable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150323920910),
//--TRIMMABLE-BOUNDARY-START(154618888206),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "GetConsumingEnumerable",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154618888206),
//--TRIMMABLE-BOUNDARY-START(339302481934),
    {
      "r": 65537,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h
        },
        {
          "n": "isAddOperation",
          "p": 262145
        }
      ],
      "n": "ValidateCollectionsArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(339302481934),
//--TRIMMABLE-BOUNDARY-START(347892416526),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "ValidateTimeout",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5100000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(347892416526),
//--TRIMMABLE-BOUNDARY-START(343597449230),
    {
      "r": 65537,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "ValidateMillisecondsTimeout",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(343597449230),
//--TRIMMABLE-BOUNDARY-START(85899411470),
    {
      "r": 65537,
      "n": "CheckDisposed",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899411470)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590000142),
    {
      "t": $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,
      "n": "_collection",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000142),
//--TRIMMABLE-BOUNDARY-START(4295032846),
    {
      "t": 655361,
      "n": "_boundedCapacity",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032846),
//--TRIMMABLE-BOUNDARY-START(176093724686),
    {
      "t": 655361,
      "n": "NON_BOUNDED",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(176093724686),
//--TRIMMABLE-BOUNDARY-START(21474902030),
    {
      "t": 174718977,
      "n": "_freeNodes",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474902030),
//--TRIMMABLE-BOUNDARY-START(30064836622),
    {
      "t": 174718977,
      "n": "_occupiedNodes",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064836622),
//--TRIMMABLE-BOUNDARY-START(25769869326),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769869326),
//--TRIMMABLE-BOUNDARY-START(12884967438),
    {
      "t": 170065921,
      "n": "_consumersCancellationTokenSource",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12884967438),
//--TRIMMABLE-BOUNDARY-START(34359803918),
    {
      "t": 170065921,
      "n": "_producersCancellationTokenSource",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359803918),
//--TRIMMABLE-BOUNDARY-START(17179934734),
    {
      "t": 655361,
      "n": "_currentAdders",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17179934734),
//--TRIMMABLE-BOUNDARY-START(90194378766),
    {
      "t": 655361,
      "n": "COMPLETE_ADDING_ON_MASK",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(90194378766)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38654771214),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654771214),
//--TRIMMABLE-BOUNDARY-START(42949738510),
    {
      "p": [
        {
          "n": "boundedCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949738510),
//--TRIMMABLE-BOUNDARY-START(47244705806),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h
        },
        {
          "n": "boundedCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244705806),
//--TRIMMABLE-BOUNDARY-START(51539673102),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539673102)
  ],
  "i": [62259201,90177537,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,62521345
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70582273,
      "c": 8660516865,
      "a": [
        {
          "v": $.$scc.System.Collections.Concurrent.BlockingCollectionDebugView$$().$h,
          "t": 187629569
        }
      ]
    },
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "Count = {Count}, Type = {_collection}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.IDisposable, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.BlockingCollection<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(65550)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014670)
        $asm.$str("$scc.System.Collections.Generic.DebugViewDictionaryItem<,>", (TKey, TValue) => $asm.$gt("$scc.System.Collections.Generic.DebugViewDictionaryItem<,>", [TKey, TValue], ($self) => class DebugViewDictionaryItem$$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4297981966)
            $ctor$4(/*TKey*/ key, /*TValue*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297981966);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = key;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297981966)
            
            //--TRIMMABLE-BOUNDARY-START(8592949262)
            $ctor$3(/*KeyValuePair<TKey, TValue>*/ keyValue)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592949262);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = keyValue.Key;
                    this.Value = keyValue.Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592949262)
            
            //--TRIMMABLE-BOUNDARY-START(42952687630)
            /*TKey*/ Key = $.$default(TKey);
            //--TRIMMABLE-BOUNDARY-END(42952687630)
            
            //--TRIMMABLE-BOUNDARY-START(47247654926)
            /*TValue*/ Value = $.$default(TValue);
            //--TRIMMABLE-BOUNDARY-END(47247654926)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Key = this.Key;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 3014670;
            static $g = 2;
            static $z = 8;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952687630),
    {
      "p": TKey?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "Key",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70057985,
          "c": 4365025281,
          "a": [
            {
              "v": 2,
              "t": 70123521
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42952687630),
//--TRIMMABLE-BOUNDARY-START(47247654926),
    {
      "p": TValue?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70057985,
          "c": 4365025281,
          "a": [
            {
              "v": 2,
              "t": 70123521
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247654926)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297981966),
    {
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297981966),
//--TRIMMABLE-BOUNDARY-START(8592949262),
    {
      "p": [
        {
          "n": "keyValue",
          "p": $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592949262),
//--TRIMMABLE-BOUNDARY-START(12887916558),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887916558)
  ],
  "g": [TKey?.$h??1507328,TValue?.$h??1572864
  ],
  "r": 2,
  "h": this.$h,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{Value}",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "Name",
          "v": "[{Key}]",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.DebugViewDictionaryItem<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3014670)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114126)
        $asm.$str("$scc.System.Collections.Concurrent.EnumerablePartitionerOptions", ($self) => class EnumerablePartitionerOptions extends $.$$.System.Enum
        {
            static None = 0;
            static NoBuffering = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoBuffering": 1n
                };
            }
            static $h = 1114126;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886016014),
    {
      "t": 1114126,
      "n": "None",
      "d": 1114126,
      "h": 12886016014,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886016014),
//--TRIMMABLE-BOUNDARY-START(8591048718),
    {
      "t": 1114126,
      "n": "NoBuffering",
      "d": 1114126,
      "h": 8591048718,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591048718)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081422),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114126,
      "h": 4296081422,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081422)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1114126,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Concurrent.EnumerablePartitionerOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114126)
        
        
        //--TRIMMABLE-BOUNDARY-START(458766)
        $asm.$cls("$scc.System.Collections.Concurrent.ConcurrentDictionary<,>", (TKey, TValue) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentDictionary<,>", [TKey, TValue], ($self) => class ConcurrentDictionary$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475295246)
            /*Tables*/ _tables = null;
            //--TRIMMABLE-BOUNDARY-END(21475295246)
            
            //--TRIMMABLE-BOUNDARY-START(4295426062)
            /*int*/ _budget = 0;
            //--TRIMMABLE-BOUNDARY-END(4295426062)
            
            //--TRIMMABLE-BOUNDARY-START(12885360654)
            /*bool*/ _growLockArray = false;
            //--TRIMMABLE-BOUNDARY-END(12885360654)
            
            //--TRIMMABLE-BOUNDARY-START(8590393358)
            /*bool*/ _comparerIsDefaultForClasses = false;
            //--TRIMMABLE-BOUNDARY-END(8590393358)
            
            //--TRIMMABLE-BOUNDARY-START(17180327950)
            /*int*/ _initialCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(17180327950)
            
            //--TRIMMABLE-BOUNDARY-START(124554510350)
            /*int*/ static DefaultCapacity = 31;
            //--TRIMMABLE-BOUNDARY-END(124554510350)
            
            //--TRIMMABLE-BOUNDARY-START(279173333006)
            /*int*/ static MaxLockNumber = 1024;
            //--TRIMMABLE-BOUNDARY-END(279173333006)
            
            //--TRIMMABLE-BOUNDARY-START(25770262542)
            $ctor$1()
            {
                this.$ctor$6($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, 31/*DefaultCapacity*/, true, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770262542);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262542)
            
            //--TRIMMABLE-BOUNDARY-START(30065229838)
            $ctor$8(/*int*/ concurrencyLevel, /*int*/ capacity)
            {
                this.$ctor$6(concurrencyLevel, capacity, false, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065229838);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065229838)
            
            //--TRIMMABLE-BOUNDARY-START(34360197134)
            $ctor$3(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                this.$ctor$5($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, collection, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360197134);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197134)
            
            //--TRIMMABLE-BOUNDARY-START(38655164430)
            $ctor$4(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, 31/*DefaultCapacity*/, true, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655164430);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655164430)
            
            //--TRIMMABLE-BOUNDARY-START(42950131726)
            $ctor$2(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetCapacityFromCollection(collection), comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950131726);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950131726)
            
            //--TRIMMABLE-BOUNDARY-START(47245099022)
            $ctor$5(/*int*/ concurrencyLevel, /*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6(concurrencyLevel, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetCapacityFromCollection(collection), false, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245099022);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099022)
            
            //--TRIMMABLE-BOUNDARY-START(51540066318)
            $ctor$7(/*int*/ concurrencyLevel, /*int*/ capacity, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6(concurrencyLevel, capacity, false, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540066318);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540066318)
            
            //--TRIMMABLE-BOUNDARY-START(55835033614)
            $ctor$6(/*int*/ concurrencyLevel, /*int*/ capacity, /*bool*/ growLockArray, /*IEqualityComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835033614);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (concurrencyLevel <= 0)
                    {
                        if (concurrencyLevel !== -1)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("concurrencyLevel", $.$scc.System.SR.ConcurrentDictionary_ConcurrencyLevelMustBePositiveOrNegativeOne);
                        }
                        concurrencyLevel = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel;
                    }
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    if (capacity < concurrencyLevel)
                    {
                        capacity = concurrencyLevel;
                    }
                    capacity = $.$scc.System.Collections.HashHelpers.GetPrime(capacity);
                    /*var*/ let locks = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [concurrencyLevel], null);
                    $.$$.System.Array.$WriteT1.call(locks, locks, 0);
                    for(/*int*/ let i = 1; i < locks.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(locks, new $.$$.System.Object().$ctor(), i);
                    }
                    /*var*/ let countPerLock = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [locks.length], null);
                    /*var*/ let buckets = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [capacity], null);
                    if (TKey.$type.IsValueType)
                    {
                        if (!(comparer === null) && $.$$.System.Object.ReferenceEquals(comparer, $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default))
                        {
                            comparer = null;
                        }
                    }
                    else 
                    {
                        comparer ??= $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
                        let stringComparer;
                        if ($.$$.System.Type.op_Equality$1(TKey.$type, $.$$.System.String.$type) && $.$is($.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer.GetStringComparer(comparer), $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String), { set $v(v){ stringComparer = v; } }))
                        {
                            comparer = $.$cast(stringComparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                        }
                        else if ($.$$.System.Object.ReferenceEquals(comparer, $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default))
                        {
                            this._comparerIsDefaultForClasses = true;
                        }
                    }
                    this._tables = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1(buckets, locks, countPerLock, comparer);
                    this._growLockArray = growLockArray;
                    this._initialCapacity = capacity;
                    this._budget = $.trunc(buckets.length / locks.length);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835033614)
            
            //--TRIMMABLE-BOUNDARY-START(206158888974)
            /*AlternateLookup<TAlternateKey> */ GetAlternateLookup(TAlternateKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158888974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, this._tables))
                {
                    $.$scc.System.ThrowHelper.ThrowIncompatibleComparer();
                }
                return new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(206158888974)
            
            //--TRIMMABLE-BOUNDARY-START(523986468878)
            /*bool */ TryGetAlternateLookup(TAlternateKey, /*out AlternateLookup<TAlternateKey>*/ lookup)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523986468878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, this._tables))
                {
                    lookup.$v = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))().$ctor$3(this);
                    return true;
                }
                lookup.$v = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(523986468878)
            
            //--TRIMMABLE-BOUNDARY-START(219043790862)
            static /*int */ GetCapacityFromCollection(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219043790862);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        {
                            let c;
                            if ((c = collection, $.$is(c, $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))))
                            {
                                return $.$$.System.Math.Max$4(31/*DefaultCapacity*/, c.System$Collections$Generic$ICollection$$$Count);
                            }
                        }
                        {
                            let rc;
                            if ((rc = collection, $.$is(rc, $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))))
                            {
                                return $.$$.System.Math.Max$4(31/*DefaultCapacity*/, rc.System$Collections$Generic$IReadOnlyCollection$$$Count);
                            }
                        }
                        return 31/*DefaultCapacity*/;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043790862)
            
            //--TRIMMABLE-BOUNDARY-START(231928692750)
            /*int */ GetHashCode$1(/*IEqualityComparer<TKey>?*/ comparer, /*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928692750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (TKey.$type.IsValueType)
                {
                    return comparer === null ? $.$$.System.Object.GetHashCodeT(TKey, key) : comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                return this._comparerIsDefaultForClasses ? $.$$.System.Object.GetHashCodeT(TKey, key) : comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]);
            }
            //--TRIMMABLE-BOUNDARY-END(231928692750)
            
            //--TRIMMABLE-BOUNDARY-START(287763267598)
            static /*bool */ NodeEqualsKey(/*IEqualityComparer<TKey>?*/ comparer, /*Node*/ node, /*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763267598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (TKey.$type.IsValueType)
                {
                    return comparer === null ? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(node._key, key) : comparer.System$Collections$Generic$IEqualityComparer$$$Equals(node._key, key, [TKey]);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                return comparer.System$Collections$Generic$IEqualityComparer$$$Equals(node._key, key, [TKey]);
            }
            //--TRIMMABLE-BOUNDARY-END(287763267598)
            
            //--TRIMMABLE-BOUNDARY-START(261993463822)
            /*void */ InitializeFromCollection(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993463822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var pair = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (pair.Key === null)
                        {
                            $.$scc.System.ThrowHelper.ThrowKeyNullException();
                        }
                        if (!this.TryAddInternal(this._tables, pair.Key, null, pair.Value, false, false, $.$discardRef()))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_SourceContainsDuplicateKeys);
                        }
                    }
                }
                if (this._budget === 0)
                {
                    /*Tables*/ let tables = this._tables;
                    this._budget = $.trunc(tables._buckets.length / tables._locks.length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261993463822)
            
            //--TRIMMABLE-BOUNDARY-START(515396534286)
            /*bool */ TryAdd(/*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396534286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryAddInternal(this._tables, key, null, value, false, true, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(515396534286)
            
            //--TRIMMABLE-BOUNDARY-START(103079673870)
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079673870);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryGetValue(key, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079673870)
            
            //--TRIMMABLE-BOUNDARY-START(536871370766)
            /*bool */ TryRemove$1(/*TKey*/ key, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871370766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryRemoveInternal(key, value, false, $.$default(TValue));
            }
            //--TRIMMABLE-BOUNDARY-END(536871370766)
            
            //--TRIMMABLE-BOUNDARY-START(541166338062)
            /*bool */ TryRemove(/*KeyValuePair<TKey, TValue>*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541166338062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (item.Key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException("item", $.$scc.System.SR.ConcurrentDictionary_ItemKeyIsNull);
                }
                return this.TryRemoveInternal(item.Key, $.$discardRef(), true, item.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(541166338062)
            
            //--TRIMMABLE-BOUNDARY-START(545461305358)
            /*bool */ TryRemoveInternal(/*TKey*/ key, /*out TValue*/ value, /*bool*/ matchValue, /*TValue?*/ oldValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461305358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*object[]*/ let locks = tables._locks;
                    /*uint*/ let lockNo;
                    /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                        {
                            if (tables !== this._tables)
                            {
                                tables = this._tables;
                                if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                                {
                                    comparer = tables._comparer;
                                    hashcode = this.GetHashCode$1(comparer, key);
                                }
                                continue;
                            }
                            /*Node?*/ let prev = null;
                            for(/*Node?*/ let curr = bucket.$v; !(curr === null); curr = curr._next)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2((prev === null && curr === bucket.$v) || prev._next === curr, "(prev is null && curr == bucket) || prev!._next == curr");
                                if (hashcode === curr._hashcode && $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, curr, key))
                                {
                                    if (matchValue)
                                    {
                                        /*bool*/ let valuesMatch = $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(oldValue, curr._value);
                                        if (!valuesMatch)
                                        {
                                            value.$v = $.$default(TValue);
                                            return false;
                                        }
                                    }
                                    if (prev === null)
                                    {
                                        bucket.$v = curr._next;
                                    }
                                    else 
                                    {
                                        prev._next = curr._next;
                                    }
                                    value.$v = curr._value;
                                    (() =>
                                    {
                                        let $old = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                        $.$$.System.Array.$WriteT1.call(tables._countPerLock, $old - 1, lockNo);
                                        return $old;
                                    })();
                                    return true;
                                }
                                prev = curr;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                    }
                    value.$v = $.$default(TValue);
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(545461305358)
            
            //--TRIMMABLE-BOUNDARY-START(528281436174)
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281436174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                if (TKey.$type.IsValueType && comparer === null)
                {
                    /*int*/ let hashcode = $.$$.System.Object.GetHashCodeT(TKey, key);
                    for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(n._key, key))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                    /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                    for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(n._key, key, [TKey]))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                value.$v = $.$default(TValue);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(528281436174)
            
            //--TRIMMABLE-BOUNDARY-START(532576403470)
            static /*bool */ TryGetValueInternal(/*Tables*/ tables, /*TKey*/ key, /*int*/ hashcode, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532576403470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                if (TKey.$type.IsValueType && comparer === null)
                {
                    for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(n._key, key))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                    for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(n._key, key, [TKey]))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                value.$v = $.$default(TValue);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(532576403470)
            
            //--TRIMMABLE-BOUNDARY-START(549756272654)
            /*bool */ TryUpdate(/*TKey*/ key, /*TValue*/ newValue, /*TValue*/ comparisonValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549756272654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryUpdateInternal(this._tables, key, null, newValue, comparisonValue);
            }
            //--TRIMMABLE-BOUNDARY-END(549756272654)
            
            //--TRIMMABLE-BOUNDARY-START(554051239950)
            /*bool */ TryUpdateInternal(/*Tables*/ tables, /*TKey*/ key, /*int?*/ nullableHashcode, /*TValue*/ newValue, /*TValue*/ comparisonValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051239950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = nullableHashcode ?? this.GetHashCode$1(comparer, key);
                $.$$.System.Diagnostics.Debug.Assert$2(nullableHashcode === null || nullableHashcode === hashcode, "nullableHashcode is null || nullableHashcode == hashcode");
                /*EqualityComparer<TValue>*/ let valueComparer = $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default;
                while(true)
                {
                    /*object[]*/ let locks = tables._locks;
                    /*uint*/ let lockNo;
                    /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                        {
                            if (tables !== this._tables)
                            {
                                tables = this._tables;
                                if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                                {
                                    comparer = tables._comparer;
                                    hashcode = this.GetHashCode$1(comparer, key);
                                }
                                continue;
                            }
                            /*Node?*/ let prev = null;
                            for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                                if (hashcode === node._hashcode && $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, node, key))
                                {
                                    if (valueComparer.Equals$2(node._value, comparisonValue))
                                    {
                                        if (!TValue.$type.IsValueType || $.$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                        {
                                            node._value = newValue;
                                        }
                                        else 
                                        {
                                            /*var*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, newValue, hashcode, node._next);
                                            if (prev === null)
                                            {
                                                bucket.$v = newNode;
                                            }
                                            else 
                                            {
                                                prev._next = newNode;
                                            }
                                        }
                                        return true;
                                    }
                                    return false;
                                }
                                prev = node;
                            }
                            return false;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(554051239950)
            
            //--TRIMMABLE-BOUNDARY-START(94489739278)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    if (this.AreAllBucketsEmpty())
                    {
                        return;
                    }
                    /*Tables*/ let tables = this._tables;
                    /*var*/ let newTables = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [$.$scc.System.Collections.HashHelpers.GetPrime(this._initialCapacity)], null), tables._locks, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [tables._countPerLock.length], null), tables._comparer);
                    this._tables = newTables;
                    this._budget = $.$$.System.Math.Max$4(1, $.trunc(newTables._buckets.length / newTables._locks.length));
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489739278)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 313533071374, 17239048193)
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533071374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (((array.length - count) | 0) < index)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_ArrayNotLargeEnough);
                    }
                    this.CopyToPairs(array, index);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 313533071374, 17239048193)
            
            //--TRIMMABLE-BOUNDARY-START(511101566990)
            /*KeyValuePair<TKey, TValue>[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101566990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.System.Array.Empty($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue));
                    }
                    /*var*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), null, [count], null);
                    this.CopyToPairs(array, 0);
                    return array;
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(511101566990)
            
            //--TRIMMABLE-BOUNDARY-START(115964575758)
            /*void */ CopyToPairs(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._tables._buckets;
                while ($i1 < $arr1.length)
                {
                    let bucket = $arr1[$i1++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(current._key, current._value), index);
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964575758)
            
            //--TRIMMABLE-BOUNDARY-START(107374641166)
            /*void */ CopyToEntries(/*DictionaryEntry[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._tables._buckets;
                while ($i1 < $arr1.length)
                {
                    let bucket = $arr1[$i1++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(current._key, TKey), $.$box(current._value, TValue)), index);
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374641166)
            
            //--TRIMMABLE-BOUNDARY-START(111669608462)
            /*void */ CopyToObjects(/*object[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._tables._buckets;
                while ($i1 < $arr1.length)
                {
                    let bucket = $arr1[$i1++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(current._key, current._value), index);
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669608462)
            
            //--TRIMMABLE-BOUNDARY-START(227633725454)
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633725454);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Enumerator)().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633725454)
            
            //--TRIMMABLE-BOUNDARY-START(655374)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.Enumerator", ($self) => class Enumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590589966)
                    /*ConcurrentDictionary<TKey, TValue>*/ _dictionary = null;
                    //--TRIMMABLE-BOUNDARY-END(8590589966)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622670)
                    /*ConcurrentDictionary<TKey, TValue>.VolatileNode[]?*/ _buckets = null;
                    //--TRIMMABLE-BOUNDARY-END(4295622670)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524558)
                    /*Node?*/ _node = null;
                    //--TRIMMABLE-BOUNDARY-END(17180524558)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557262)
                    /*int*/ _i = -1;
                    //--TRIMMABLE-BOUNDARY-END(12885557262)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426446)
                    /*KeyValuePair<TKey, TValue>*/ Current;
                    //--TRIMMABLE-BOUNDARY-END(30065426446)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 64425164814, 4357619713)
                    /*object */ get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 64425164814, 4357619713)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540262926)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540262926);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._buckets = null;
                        this._node = null;
                        this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))();
                        this._i = -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540262926)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360393742)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360393742);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360393742)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245295630)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245295630);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        while(true)
                        {
                            let node;
                            if ($.$is(this._node, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node, { set $v(v){ node = v; } }))
                            {
                                this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(node._key, node._value);
                                this._node = node._next;
                                return true;
                            }
                            /*ConcurrentDictionary<TKey, TValue>.VolatileNode[]?*/ let buckets = this._buckets ??= this._dictionary._tables._buckets;
                            $.$$.System.Diagnostics.Debug.Assert$2(!(buckets === null), "buckets is not null");
                            /*int*/ let i = ((this._i + 1) | 0);
                            if ((i >>> 0) >= (buckets.length >>> 0))
                            {
                                return false;
                            }
                            this._node = $.$$.System.Array.$ReadT1.call(buckets, i)._node;
                            this._i = i;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245295630)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944474113)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354539521);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944474113)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242521601)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242521601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242521601)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537488897)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537488897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537488897)
                    
                    //Begin primary constructor
                    /*ConcurrentDictionary<TKey, TValue>*/ dictionary = null;
                    $ctor$1(/*ConcurrentDictionary<TKey, TValue>*/dictionary)
                    {
                        this.dictionary = dictionary;
                        //--TRIMMABLE-BOUNDARY-START(8590589966)
                        //depends on primary constructor parameter
                        this._dictionary = this.dictionary;
                        //--TRIMMABLE-BOUNDARY-END(8590589966)
                        
                        return this
                    }
                    //End primary constructor
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Current = $.$default($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue));
                    }
                    static $h = 655374;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065426446),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(655374)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(655374)|0xE00000000n),
        "f": 83886082
      },
      "n": "Current",
      "d": 655374,
      "h": Number(BigInt(655374)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065426446),
//--TRIMMABLE-BOUNDARY-START(ALL, 64425164814, 4357619713),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(655374)|0x1100000000n),
        "f": 50331650
      },
      "n": "{62652417}.Current",
      "o": "System$Collections$IEnumerator$Current",
      "d": 655374,
      "h": Number(BigInt(655374)|0xF00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 64425164814, 4357619713)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540262926),
    {
      "r": 65537,
      "n": "Reset",
      "d": 655374,
      "h": Number(BigInt(655374)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540262926),
//--TRIMMABLE-BOUNDARY-START(34360393742),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 655374,
      "h": Number(BigInt(655374)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360393742),
//--TRIMMABLE-BOUNDARY-START(47245295630),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 655374,
      "h": Number(BigInt(655374)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245295630)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590589966),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,
      "n": "_dictionary",
      "d": 655374,
      "h": Number(BigInt(655374)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590589966),
//--TRIMMABLE-BOUNDARY-START(4295622670),
    {
      "t": $.$typeArray($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h,
      "n": "_buckets",
      "d": 655374,
      "h": Number(BigInt(655374)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622670),
//--TRIMMABLE-BOUNDARY-START(17180524558),
    {
      "t": 720910,
      "n": "_node",
      "d": 655374,
      "h": Number(BigInt(655374)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180524558),
//--TRIMMABLE-BOUNDARY-START(12885557262),
    {
      "t": 655361,
      "n": "_i",
      "d": 655374,
      "h": Number(BigInt(655374)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885557262)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475491854),
    {
      "p": [
        {
          "n": "dictionary",
          "p": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655374,
      "h": Number(BigInt(655374)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491854)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,90177537,62652417
  ],
  "d": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,
  "h": 655374
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655374)
            
            //--TRIMMABLE-BOUNDARY-START(519691501582)
            /*bool */ TryAddInternal(/*Tables*/ tables, /*TKey*/ key, /*int?*/ nullableHashcode, /*TValue*/ value, /*bool*/ updateIfExists, /*bool*/ acquireLock, /*out TValue*/ resultingValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519691501582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = nullableHashcode ?? this.GetHashCode$1(comparer, key);
                $.$$.System.Diagnostics.Debug.Assert$2(nullableHashcode === null || nullableHashcode === hashcode, "nullableHashcode is null || nullableHashcode == hashcode");
                while(true)
                {
                    /*object[]*/ let locks = tables._locks;
                    /*uint*/ let lockNo;
                    /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                    /*bool*/ let resizeDesired = false;
                    /*bool*/ let forceRehash = false;
                    /*bool*/ let lockTaken = false;
                    try
                    {
                        if (acquireLock)
                        {
                            $.$$.System.Threading.Monitor.Enter($.$$.System.Array.$ReadT1.call(locks, lockNo), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                        }
                        if (tables !== this._tables)
                        {
                            tables = this._tables;
                            if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                            {
                                comparer = tables._comparer;
                                hashcode = this.GetHashCode$1(comparer, key);
                            }
                            continue;
                        }
                        /*uint*/ let collisionCount = 0;
                        /*Node?*/ let prev = null;
                        for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                            if (hashcode === node._hashcode && $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, node, key))
                            {
                                if (updateIfExists)
                                {
                                    if (!TValue.$type.IsValueType || $.$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                    {
                                        node._value = value;
                                    }
                                    else 
                                    {
                                        /*var*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, value, hashcode, node._next);
                                        if (prev === null)
                                        {
                                            bucket.$v = newNode;
                                        }
                                        else 
                                        {
                                            prev._next = newNode;
                                        }
                                    }
                                    resultingValue.$v = value;
                                }
                                else 
                                {
                                    resultingValue.$v = node._value;
                                }
                                return false;
                            }
                            prev = node;
                            if (!TKey.$type.IsValueType)
                            {
                                collisionCount++;
                            }
                        }
                        /*var*/ let resultNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(key, value, hashcode, bucket.$v);
                        bucket.$v = resultNode;
                        //checked
                        {
                            (() =>
                            {
                                let $old = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                $.$$.System.Array.$WriteT1.call(tables._countPerLock, $old + 1, lockNo);
                                return $old;
                            })();
                        }
                        if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) > this._budget)
                        {
                            resizeDesired = true;
                        }
                        if (!TKey.$type.IsValueType && collisionCount > 100/*HashHelpers.HashCollisionThreshold*/ && $.$is(comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))
                        {
                            forceRehash = true;
                        }
                    }
                    finally
                    {
                        {
                            if (lockTaken)
                            {
                                $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo));
                            }
                        }
                    }
                    if ($.$$.System.Boolean.op_BitwiseOr(resizeDesired, forceRehash))
                    {
                        this.GrowTable(tables, resizeDesired, forceRehash);
                    }
                    resultingValue.$v = value;
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(519691501582)
            
            //--TRIMMABLE-BOUNDARY-START(498216665102)
            /*TValue*/ get_Item(/*TKey*/ key)
            {
                /*TValue?*/ let value;
                if (!this.TryGetValue(key, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).ThrowKeyNotFoundException(key);
                }
                return value;
            }
            /*void*/ set_Item(/*TKey*/ key, /*TValue*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                this.TryAddInternal(this._tables, key, null, value, true, true, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(498216665102)
            
            //--TRIMMABLE-BOUNDARY-START(506806599694)
            static /*void */ ThrowKeyNotFoundException(/*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(506806599694);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$scc.System.SR.Format$6($.$scc.System.SR.Arg_KeyNotFoundWithKey, $.$$.System.Object.ToString.call(key)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(506806599694)
            
            //--TRIMMABLE-BOUNDARY-START(98784706574)
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = this._tables._comparer;
                if ($.$$.System.Type.op_Equality$1(TKey.$type, $.$$.System.String.$type))
                {
                    let ec;
                    if ($.$is((($.$as(comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))?.GetUnderlyingEqualityComparer() ?? null), $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String), { set $v(v){ ec = v; } }))
                    {
                        return $.$cast(ec, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                    }
                }
                return comparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
            }
            //--TRIMMABLE-BOUNDARY-END(98784706574)
            
            //--TRIMMABLE-BOUNDARY-START(120259543054)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619281422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    return this.GetCountNoLocks();
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259543054)
            
            //--TRIMMABLE-BOUNDARY-START(223338758158)
            /*int */ GetCountNoLocks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338758158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = 0;
                let $i1 = 0;
                let $arr1 = this._tables._countPerLock;
                while ($i1 < $arr1.length)
                {
                    let value = $arr1[$i1++];
                    //checked
                    {
                        count += value;
                    }
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(223338758158)
            
            //--TRIMMABLE-BOUNDARY-START(240518627342)
            /*TValue */ GetOrAdd(/*TKey*/ key, /*Func<TKey, TValue>*/ valueFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518627342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (valueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("valueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                /*TValue?*/ let resultingValue;
                if (!$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, valueFactory.Invoke(key), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            //--TRIMMABLE-BOUNDARY-END(240518627342)
            
            //--TRIMMABLE-BOUNDARY-START(244813594638)
            /*TValue */ GetOrAdd$2(TArg, /*TKey*/ key, /*Func<TKey, TArg, TValue>*/ valueFactory, /*TArg*/ factoryArgument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813594638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (valueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("valueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                /*TValue?*/ let resultingValue;
                if (!$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, valueFactory.Invoke(key, factoryArgument), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            //--TRIMMABLE-BOUNDARY-END(244813594638)
            
            //--TRIMMABLE-BOUNDARY-START(249108561934)
            /*TValue */ GetOrAdd$1(/*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108561934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                /*TValue?*/ let resultingValue;
                if (!$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, value, false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            //--TRIMMABLE-BOUNDARY-END(249108561934)
            
            //--TRIMMABLE-BOUNDARY-START(73014902798)
            /*TValue */ AddOrUpdate$2(TArg, /*TKey*/ key, /*Func<TKey, TArg, TValue>*/ addValueFactory, /*Func<TKey, TValue, TArg, TValue>*/ updateValueFactory, /*TArg*/ factoryArgument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (addValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("addValueFactory");
                }
                if (updateValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue, factoryArgument);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValueFactory.Invoke(key, factoryArgument), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014902798)
            
            //--TRIMMABLE-BOUNDARY-START(77309870094)
            /*TValue */ AddOrUpdate(/*TKey*/ key, /*Func<TKey, TValue>*/ addValueFactory, /*Func<TKey, TValue, TValue>*/ updateValueFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (addValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("addValueFactory");
                }
                if (updateValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValueFactory.Invoke(key), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309870094)
            
            //--TRIMMABLE-BOUNDARY-START(81604837390)
            /*TValue */ AddOrUpdate$1(/*TKey*/ key, /*TValue*/ addValue, /*Func<TKey, TValue, TValue>*/ updateValueFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (updateValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValue, false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604837390)
            
            //--TRIMMABLE-BOUNDARY-START(270583398414)
            /*bool */ get IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799150606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.AreAllBucketsEmpty())
                {
                    return false;
                }
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    return this.AreAllBucketsEmpty();
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270583398414)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 335007907854, 4354342913)
            /*void */ System$Collections$Generic$IDictionary$$$$Add(/*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007907854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryAdd(key, value))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_KeyAlreadyExisted);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 335007907854, 4354342913)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 339302875150, 43009048577)
            /*bool */ System$Collections$Generic$IDictionary$$$$Remove(/*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(339302875150);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryRemove$1(key, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 339302875150, 43009048577)
            
            //--TRIMMABLE-BOUNDARY-START(274878365710)
            /*ICollection<TKey> */ get Keys$1()
            {
                return this.GetKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(274878365710)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 360777711630, 34419703809)
            /*IEnumerable<TKey> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Keys()
            {
                return this.GetKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 360777711630, 34419703809)
            
            //--TRIMMABLE-BOUNDARY-START(558346207246)
            /*ICollection<TValue> */ get Values()
            {
                return this.GetValues();
            }
            //--TRIMMABLE-BOUNDARY-END(558346207246)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 365072678926, 47304605697)
            /*IEnumerable<TValue> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Values()
            {
                return this.GetValues();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 365072678926, 47304605697)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 304943136782, 4354146305)
            /*void */ System$Collections$Generic$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(304943136782);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).System$Collections$Generic$IDictionary$$$$Add(keyValuePair.Key, keyValuePair.Value, [TKey, TValue]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 304943136782, 4354146305)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 309238104078, 12944080897)
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(309238104078);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*TValue?*/ let value;
                    return this.TryGetValue(keyValuePair.Key, $.$ref(() => value, ($v) => value = $v, TValue)) && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, keyValuePair.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 309238104078, 12944080897)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 326417973262, 43008851969)
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 326417973262, 43008851969)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 330712940558, 47303819265)
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(330712940558);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryRemove(keyValuePair);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 330712940558, 47303819265)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 489626730510, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(489626730510);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 489626730510, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 399432417294, 4357357569)
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432417294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (!($.$is(key, TKey)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_TypeOfKeyIncorrect);
                }
                $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).ThrowIfInvalidObjectValue(value);
                (this).System$Collections$Generic$IDictionary$$$$Add($.$cast(key, TKey), $.$cast(value, TValue), [TKey, TValue]);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 399432417294, 4357357569)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 403727384590, 12947292161)
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727384590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                return $.$is(key, TKey, { set $v(v){ tkey = v; } }) && this.ContainsKey(tkey);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 403727384590, 12947292161)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 450972024846, 60191932417)
            /*IDictionaryEnumerator */ System$Collections$IDictionary$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(450972024846);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DictionaryEnumerator)().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 450972024846, 60191932417)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 455266992142, 64486899713)
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 455266992142, 64486899713)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 459561959438, 68781867009)
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 459561959438, 68781867009)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 463856926734, 73076834305)
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                return this.GetKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 463856926734, 73076834305)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 468151894030, 77371801601)
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468151894030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                if ($.$is(key, TKey, { set $v(v){ tkey = v; } }))
                {
                    this.TryRemove$1(tkey, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 468151894030, 77371801601)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 485331763214, 94551670785)
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                return this.GetValues();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 485331763214, 94551670785)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 481036795918, 90256703489)
            //--TRIMMABLE-BOUNDARY-START(90256703489)
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                /*TValue?*/ let value;
                if ($.$is(key, TKey, { set $v(v){ tkey = v; } }) && this.TryGetValue(tkey, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    return $.$box(value, TValue);
                }
                return null;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (!($.$is(key, TKey)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_TypeOfKeyIncorrect);
                }
                $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).ThrowIfInvalidObjectValue(value);
                (this).set_Item($.$cast(key, TKey), $.$cast(value, TValue));
            }
            //--TRIMMABLE-BOUNDARY-END(90256703489)
            
            //--TRIMMABLE-BOUNDARY-END(ALL, 481036795918, 90256703489)
            
            //--TRIMMABLE-BOUNDARY-START(502511632398)
            static /*void */ ThrowIfInvalidObjectValue(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511632398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(value === null))
                {
                    if (!($.$is(value, TValue)))
                    {
                        $.$scc.System.ThrowHelper.ThrowValueNullException();
                    }
                }
                else if (!($.$default(TValue) === null))
                {
                    $.$scc.System.ThrowHelper.ThrowValueNullException();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(502511632398)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 369367646222, 4357226497)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367646222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (((array.length - count) | 0) < index)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_ArrayNotLargeEnough);
                    }
                    let pairs;
                    if ($.$is(array, $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), { set $v(v){ pairs = v; } }))
                    {
                        this.CopyToPairs(pairs, index);
                        return;
                    }
                    let entries;
                    if ($.$is(array, $.$typeArray($.$$.System.Collections.DictionaryEntry), { set $v(v){ entries = v; } }))
                    {
                        this.CopyToEntries(entries, index);
                        return;
                    }
                    let objects;
                    if ($.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                    {
                        this.CopyToObjects(objects, index);
                        return;
                    }
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.ConcurrentDictionary_ArrayIncorrectType, "array");
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 369367646222, 4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 390842482702, 38716964865)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 390842482702, 38716964865)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 395137449998, 43011932161)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 395137449998, 43011932161)
            
            //--TRIMMABLE-BOUNDARY-START(90194771982)
            /*bool */ AreAllBucketsEmpty()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194771982);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$$.System.MemoryExtensions.ContainsAnyExcept$8($.$$.System.Int32, $.$$.System.Span$$($.$$.System.Int32).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Int32, this._tables._countPerLock)), 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194771982)
            
            //--TRIMMABLE-BOUNDARY-START(257698496526)
            /*void */ GrowTable(/*Tables*/ tables, /*bool*/ resizeDesired, /*bool*/ forceRehashIfNonRandomized)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698496526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireFirstLock($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    if (tables !== this._tables)
                    {
                        return;
                    }
                    /*int*/ let newLength = tables._buckets.length;
                    /*IEqualityComparer<TKey>?*/ let upgradeComparer = null;
                    let nrsec;
                    if (forceRehashIfNonRandomized && $.$is(tables._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer, { set $v(v){ nrsec = v; } }))
                    {
                        upgradeComparer = $.$cast(nrsec.GetUnderlyingEqualityComparer(), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                    }
                    if (resizeDesired)
                    {
                        if (upgradeComparer === null && this.GetCountNoLocks() < $.trunc(tables._buckets.length / 4))
                        {
                            this._budget = ((2 * this._budget) | 0);
                            if (this._budget < 0)
                            {
                                this._budget = 2147483647/*int.MaxValue*/;
                            }
                            return;
                        }
                        if ((newLength = ((tables._buckets.length * 2) | 0)) < 0 || (newLength = $.$scc.System.Collections.HashHelpers.GetPrime(newLength)) > $.$$.System.Array.MaxLength)
                        {
                            newLength = $.$$.System.Array.MaxLength;
                            this._budget = 2147483647/*int.MaxValue*/;
                        }
                    }
                    /*object[]*/ let newLocks = tables._locks;
                    if (this._growLockArray && tables._locks.length < 1024/*MaxLockNumber*/)
                    {
                        newLocks = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [((tables._locks.length * 2) | 0)], null);
                        $.$$.System.Array.Copy(tables._locks, newLocks, tables._locks.length);
                        for(/*int*/ let i = tables._locks.length; i < newLocks.length; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(newLocks, new $.$$.System.Object().$ctor(), i);
                        }
                    }
                    /*var*/ let newBuckets = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [newLength], null);
                    /*var*/ let newCountPerLock = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [newLocks.length], null);
                    /*var*/ let newTables = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1(newBuckets, newLocks, newCountPerLock, upgradeComparer ?? tables._comparer);
                    $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AcquirePostFirstLock(tables, $.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    let $i3 = 0;
                    let $arr3 = tables._buckets;
                    while ($i3 < $arr3.length)
                    {
                        let bucket = $arr3[$i3++];
                        /*Node?*/ let current = bucket._node;
                        while(!(current === null))
                        {
                            /*int*/ let hashCode = upgradeComparer === null ? current._hashcode : upgradeComparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(current._key, [TKey]);
                            /*Node?*/ let next = current._next;
                            /*uint*/ let newLockNo;
                            /*ref Node?*/ let newBucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(newTables, hashCode, $.$ref(() => newLockNo, ($v) => newLockNo = $v, $.$$.System.UInt32));
                            newBucket.$v = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(current._key, current._value, hashCode, newBucket.$v);
                            //checked
                            {
                                (() =>
                                {
                                    let $old = $.$$.System.Array.$ReadT1.call(newCountPerLock, newLockNo);
                                    $.$$.System.Array.$WriteT1.call(newCountPerLock, $old + 1, newLockNo);
                                    return $old;
                                })();
                            }
                            current = next;
                        }
                    }
                    this._budget = $.$$.System.Math.Max$4(1, $.trunc(newBuckets.length / newLocks.length));
                    this._tables = newTables;
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698496526)
            
            //--TRIMMABLE-BOUNDARY-START(128849477646)
            static /*int */ get DefaultConcurrencyLevel()
            {
                return $.$$.System.Environment.ProcessorCount;
            }
            //--TRIMMABLE-BOUNDARY-END(128849477646)
            
            //--TRIMMABLE-BOUNDARY-START(60130000910)
            /*void */ AcquireAllLocks(/*ref int*/ locksAcquired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentDictionary_AcquiringAllLocks(this._tables._buckets.length);
                }
                this.AcquireFirstLock(locksAcquired);
                $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AcquirePostFirstLock(this._tables, locksAcquired);
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired.$v === this._tables._locks.length, "locksAcquired == _tables._locks.Length");
            }
            //--TRIMMABLE-BOUNDARY-END(60130000910)
            
            //--TRIMMABLE-BOUNDARY-START(64424968206)
            /*void */ AcquireFirstLock(/*ref int*/ locksAcquired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object[]*/ let locks = this._tables._locks;
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired.$v === 0, "locksAcquired == 0");
                $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.Threading.Monitor.IsEntered($.$$.System.Array.$ReadT1.call(locks, 0)), "!Monitor.IsEntered(locks[0])");
                $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, 0));
                locksAcquired.$v = 1;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968206)
            
            //--TRIMMABLE-BOUNDARY-START(68719935502)
            static /*void */ AcquirePostFirstLock(/*Tables*/ tables, /*ref int*/ locksAcquired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object[]*/ let locks = tables._locks;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered($.$$.System.Array.$ReadT1.call(locks, 0)), "Monitor.IsEntered(locks[0])");
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired.$v === 1, "locksAcquired == 1");
                for(/*int*/ let i = 1; i < locks.length; i++)
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, i));
                    locksAcquired.$v++;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired.$v === locks.length, "locksAcquired == locks.Length");
            }
            //--TRIMMABLE-BOUNDARY-END(68719935502)
            
            //--TRIMMABLE-BOUNDARY-START(292058234894)
            /*void */ ReleaseLocks(/*int*/ locksAcquired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058234894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired >= 0, "locksAcquired >= 0");
                /*object[]*/ let locks = this._tables._locks;
                for(/*int*/ let i = 0; i < locksAcquired; i++)
                {
                    $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, i));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(292058234894)
            
            //--TRIMMABLE-BOUNDARY-START(236223660046)
            /*ReadOnlyCollection<TKey> */ GetKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223660046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TKey).Empty;
                    }
                    /*var*/ let keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [count], null);
                    /*int*/ let i = 0;
                    let $i2 = 0;
                    let $arr2 = this._tables._buckets;
                    while ($i2 < $arr2.length)
                    {
                        let bucket = $arr2[$i2++];
                        for(/*Node?*/ let node = bucket._node; !(node === null); node = node._next)
                        {
                            $.$$.System.Array.$WriteT1.call(keys, node._key, i);
                            i++;
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(i === count, "i == count");
                    return new ($.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TKey))().$ctor$1(keys);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236223660046)
            
            //--TRIMMABLE-BOUNDARY-START(253403529230)
            /*ReadOnlyCollection<TValue> */ GetValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403529230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TValue).Empty;
                    }
                    /*var*/ let keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [count], null);
                    /*int*/ let i = 0;
                    let $i2 = 0;
                    let $arr2 = this._tables._buckets;
                    while ($i2 < $arr2.length)
                    {
                        let bucket = $arr2[$i2++];
                        for(/*Node?*/ let node = bucket._node; !(node === null); node = node._next)
                        {
                            $.$$.System.Array.$WriteT1.call(keys, node._value, i);
                            i++;
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(i === count, "i == count");
                    return new ($.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TValue))().$ctor$1(keys);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253403529230)
            
            //--TRIMMABLE-BOUNDARY-START(851982)
            static $_VolatileNode;
            static get VolatileNode()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_VolatileNode ??= $asm.$nstr("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.VolatileNode", ($self) => class VolatileNode extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295819278)
                    /*Node?*/  get _node() { return this.$getField(0, 4); }
                    /*Node?*/  set _node(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295819278)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._node = this._node;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4295819278)
                        this._node = null;
                        //--TRIMMABLE-BOUNDARY-END(4295819278)
                        
                    }
                    static $h = 851982;
                    static $z = 4;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819278),
    {
      "t": 720910,
      "n": "_node",
      "d": 851982,
      "h": Number(BigInt(851982)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295819278)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786574),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 851982,
      "h": Number(BigInt(851982)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786574)
  ],
  "d": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,
  "h": 851982
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.VolatileNode`; }
                }, $cls, ($v) => $cls.$_VolatileNode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851982)
            
            //--TRIMMABLE-BOUNDARY-START(720910)
            static $_Node;
            static get Node()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Node ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.Node", ($self) => class Node extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590655502)
                    /*TKey*/ _key = $.$default(TKey);
                    //--TRIMMABLE-BOUNDARY-END(8590655502)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180590094)
                    /*TValue*/ _value = $.$default(TValue);
                    //--TRIMMABLE-BOUNDARY-END(17180590094)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885622798)
                    /*Node?*/ _next = null;
                    //--TRIMMABLE-BOUNDARY-END(12885622798)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295688206)
                    /*int*/ _hashcode = 0;
                    //--TRIMMABLE-BOUNDARY-END(4295688206)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475557390)
                    $ctor$1(/*TKey*/ key, /*TValue*/ value, /*int*/ hashcode, /*Node?*/ next)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475557390);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._key = key;
                            this._value = value;
                            this._next = next;
                            this._hashcode = hashcode;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475557390)
                    
                    static $h = 720910;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590655502),
    {
      "t": TKey?.$h??1507328,
      "n": "_key",
      "d": 720910,
      "h": Number(BigInt(720910)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590655502),
//--TRIMMABLE-BOUNDARY-START(17180590094),
    {
      "t": TValue?.$h??1572864,
      "n": "_value",
      "d": 720910,
      "h": Number(BigInt(720910)|0x400000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180590094),
//--TRIMMABLE-BOUNDARY-START(12885622798),
    {
      "t": 720910,
      "n": "_next",
      "d": 720910,
      "h": Number(BigInt(720910)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885622798),
//--TRIMMABLE-BOUNDARY-START(4295688206),
    {
      "t": 655361,
      "n": "_hashcode",
      "d": 720910,
      "h": Number(BigInt(720910)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295688206)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557390),
    {
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864
        },
        {
          "n": "hashcode",
          "p": 655361
        },
        {
          "n": "next",
          "p": 720910
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720910,
      "h": Number(BigInt(720910)|0x500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475557390)
  ],
  "d": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,
  "h": 720910
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Node`; }
                }, $cls, ($v) => $cls.$_Node = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(720910)
            
            //--TRIMMABLE-BOUNDARY-START(210453856270)
            static /*Node? */ GetBucket(/*Tables*/ tables, /*int*/ hashcode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453856270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*VolatileNode[]*/ let buckets = tables._buckets;
                //if (IntPtr.Size == 8) { ... }
                //else 
                {
                    return $.$$.System.Array.$ReadT1.call(buckets, (hashcode >>> 0) % (buckets.length >>> 0))._node;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210453856270)
            
            //--TRIMMABLE-BOUNDARY-START(214748823566)
            static /*ref Node? */ GetBucketAndLock(/*Tables*/ tables, /*int*/ hashcode, /*out uint*/ lockNo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748823566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*VolatileNode[]*/ let buckets = tables._buckets;
                /*uint*/ let bucketNo;
                //if (IntPtr.Size == 8) { ... }
                //else 
                {
                    bucketNo = (hashcode >>> 0) % (buckets.length >>> 0);
                }
                lockNo.$v = bucketNo % (tables._locks.length >>> 0);
                return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node, () => $.$$.System.Array.$ReadT1.call(buckets, bucketNo)._node, ($v) => $.$$.System.Array.$ReadT1.call(buckets, bucketNo)._node = $v, null);
            }
            //--TRIMMABLE-BOUNDARY-END(214748823566)
            
            //--TRIMMABLE-BOUNDARY-START(786446)
            static $_Tables;
            static get Tables()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Tables ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.Tables", ($self) => class Tables extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590721038)
                    /*IEqualityComparer<TKey>?*/ _comparer = null;
                    //--TRIMMABLE-BOUNDARY-END(8590721038)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295753742)
                    /*VolatileNode[]*/ _buckets = null;
                    //--TRIMMABLE-BOUNDARY-END(4295753742)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655630)
                    /*ulong*/ _fastModBucketsMultiplier = 0n;
                    //--TRIMMABLE-BOUNDARY-END(17180655630)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475622926)
                    /*object[]*/ _locks = null;
                    //--TRIMMABLE-BOUNDARY-END(21475622926)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688334)
                    /*int[]*/ _countPerLock = null;
                    //--TRIMMABLE-BOUNDARY-END(12885688334)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770590222)
                    $ctor$1(/*VolatileNode[]*/ buckets, /*object[]*/ locks, /*int[]*/ countPerLock, /*IEqualityComparer<TKey>?*/ comparer)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770590222);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2(TKey.$type.IsValueType || !(comparer === null), "typeof(TKey).IsValueType || comparer is not null");
                            this._buckets = buckets;
                            this._locks = locks;
                            this._countPerLock = countPerLock;
                            this._comparer = comparer;
                            //if (IntPtr.Size == 8) { ... }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770590222)
                    
                    static $h = 786446;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721038),
    {
      "t": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,
      "n": "_comparer",
      "d": 786446,
      "h": Number(BigInt(786446)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590721038),
//--TRIMMABLE-BOUNDARY-START(4295753742),
    {
      "t": $.$typeArray($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h,
      "n": "_buckets",
      "d": 786446,
      "h": Number(BigInt(786446)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295753742),
//--TRIMMABLE-BOUNDARY-START(17180655630),
    {
      "t": 983041,
      "n": "_fastModBucketsMultiplier",
      "d": 786446,
      "h": Number(BigInt(786446)|0x400000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180655630),
//--TRIMMABLE-BOUNDARY-START(21475622926),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "_locks",
      "d": 786446,
      "h": Number(BigInt(786446)|0x500000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475622926),
//--TRIMMABLE-BOUNDARY-START(12885688334),
    {
      "t": $.$typeArray($.$$.System.Int32).$h,
      "n": "_countPerLock",
      "d": 786446,
      "h": Number(BigInt(786446)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885688334)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590222),
    {
      "p": [
        {
          "n": "buckets",
          "p": $.$typeArray($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h
        },
        {
          "n": "locks",
          "p": $.$typeArray($.$$.System.Object).$h
        },
        {
          "n": "countPerLock",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786446,
      "h": Number(BigInt(786446)|0x600000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25770590222)
  ],
  "d": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,
  "h": 786446
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Tables`; }
                }, $cls, ($v) => $cls.$_Tables = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786446)
            
            //--TRIMMABLE-BOUNDARY-START(589838)
            static $_DictionaryEnumerator;
            static get DictionaryEnumerator()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_DictionaryEnumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.DictionaryEnumerator", ($self) => class DictionaryEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557134)
                    /*IEnumerator<KeyValuePair<TKey, TValue>>*/ _enumerator = null;
                    //--TRIMMABLE-BOUNDARY-END(4295557134)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590524430)
                    $ctor$1(/*ConcurrentDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590524430);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._enumerator = dictionary.GetEnumerator();
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590524430)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459022)
                    /*DictionaryEntry */ get Entry()
                    {
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Key, TKey), $.$box(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Value, TValue));
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180459022)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835164686)
                    /*object */ get Key()
                    {
                        return $.$box(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Key, TKey);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835164686)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720066574)
                    /*object? */ get Value()
                    {
                        return $.$box(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Value, TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720066574)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885491726)
                    /*object */ get Current()
                    {
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885491726)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130131982)
                    /*bool */ MoveNext()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(60130131982);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._enumerator.System$Collections$IEnumerator$MoveNext();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130131982)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425099278)
                    /*void */ Reset()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64425099278);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._enumerator.System$Collections$IEnumerator$Reset();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425099278)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537292289)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get System$Collections$IDictionaryEnumerator$Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34422194177);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Key;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537292289)
                    
                    //--TRIMMABLE-BOUNDARY-START(30127226881)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get System$Collections$IDictionaryEnumerator$Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38717161473);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30127226881)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947357697)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357423105);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947357697)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242521601)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242521601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242521601)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947554305)
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357619713);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947554305)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537488897)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537488897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537488897)
                    
                    static $h = 589838;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180459022),
    {
      "p": 56557569,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(589838)|0x800000000n),
        "f": 50331649
      },
      "n": "Entry",
      "d": 589838,
      "h": Number(BigInt(589838)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180459022),
//--TRIMMABLE-BOUNDARY-START(55835164686),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(589838)|0xA00000000n),
        "f": 50331649
      },
      "n": "Key",
      "d": 589838,
      "h": Number(BigInt(589838)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835164686),
//--TRIMMABLE-BOUNDARY-START(68720066574),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(589838)|0xC00000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": 589838,
      "h": Number(BigInt(589838)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720066574),
//--TRIMMABLE-BOUNDARY-START(12885491726),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(589838)|0x600000000n),
        "f": 50331649
      },
      "n": "Current",
      "d": 589838,
      "h": Number(BigInt(589838)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885491726)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130131982),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 589838,
      "h": Number(BigInt(589838)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130131982),
//--TRIMMABLE-BOUNDARY-START(64425099278),
    {
      "r": 65537,
      "n": "Reset",
      "d": 589838,
      "h": Number(BigInt(589838)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425099278)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557134),
    {
      "t": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,
      "n": "_enumerator",
      "d": 589838,
      "h": Number(BigInt(589838)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557134)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590524430),
    {
      "p": [
        {
          "n": "dictionary",
          "p": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589838,
      "h": Number(BigInt(589838)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590524430)
  ],
  "i": [62455809,62652417
  ],
  "d": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,
  "h": 589838
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.DictionaryEnumerator`; }
                }, $cls, ($v) => $cls.$_DictionaryEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589838)
            
            //--TRIMMABLE-BOUNDARY-START(266288431118)
            static /*bool */ IsCompatibleKey(TAlternateKey, /*ConcurrentDictionary<TKey, TValue>.Tables*/ tables)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288431118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(tables === null), "tables is not null");
                return $.$is(tables._comparer, $.$$.System.Collections.Generic.IAlternateEqualityComparer$$$(TAlternateKey, TKey));
            }
            //--TRIMMABLE-BOUNDARY-END(266288431118)
            
            //--TRIMMABLE-BOUNDARY-START(201863921678)
            static /*IAlternateEqualityComparer<TAlternateKey, TKey> */ GetAlternateComparer(TAlternateKey, /*ConcurrentDictionary<TKey, TValue>.Tables*/ tables)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863921678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, tables), "IsCompatibleKey<TAlternateKey>(tables)");
                return tables._comparer;
            }
            //--TRIMMABLE-BOUNDARY-END(201863921678)
            
            //--TRIMMABLE-BOUNDARY-START(524302)
            static $_AlternateLookup$$;
            static AlternateLookup$$(TAlternateKey)
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return ($cls.$_AlternateLookup$$ ??= $asm.$nstr("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.AlternateLookup<>", (TAlternateKey) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.AlternateLookup<>", [TAlternateKey], ($self) => class AlternateLookup$$ extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295491598)
                    $ctor$3(/*ConcurrentDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295491598);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2(!(dictionary === null), "dictionary is not null");
                            $.$$.System.Diagnostics.Debug.Assert$2($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, dictionary._tables), "IsCompatibleKey<TAlternateKey>(dictionary._tables)");
                            this.Dictionary = dictionary;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295491598)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475360782)
                    /*ConcurrentDictionary<TKey, TValue>*/ Dictionary = null;
                    //--TRIMMABLE-BOUNDARY-END(21475360782)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540131854)
                    /*TValue*/ get_Item(/*TAlternateKey*/ key)
                    {
                        /*TValue?*/ let value;
                        return this.TryGetValue$1(key, $.$ref(() => value, ($v) => value = $v, TValue)) ? value : (() =>
                        {
        throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$9()                })();
                    }
                    /*void*/ set_Item(/*TAlternateKey*/ key, /*TValue*/ value)
                    {
                        this.TryAdd(key, value, true, $.$discardRef());
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540131854)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180393486)
                    /*bool */ ContainsKey(/*TAlternateKey*/ key)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180393486);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.TryGetValue$1(key, $.$discardRef());
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180393486)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835099150)
                    /*bool */ TryAdd$1(/*TAlternateKey*/ key, /*TValue*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(55835099150);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.TryAdd(key, value, false, $.$discardRef());
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835099150)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130066446)
                    /*bool */ TryAdd(/*TAlternateKey*/ key, /*TValue*/ value, /*bool*/ updateIfExists, /*out TValue*/ resultingValue)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130066446);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (key === null)
                        {
                            $.$scc.System.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                        while(true)
                        {
                            /*object[]*/ let locks = tables._locks;
                            /*uint*/ let lockNo;
                            /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                            /*bool*/ let resizeDesired = false;
                            /*bool*/ let forceRehash = false;
                            /*bool*/ let lockTaken = false;
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter($.$$.System.Array.$ReadT1.call(locks, lockNo), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                                if (tables !== this.Dictionary._tables)
                                {
                                    tables = this.Dictionary._tables;
                                    if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                                    {
                                        comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                                        hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                                    }
                                    continue;
                                }
                                /*uint*/ let collisionCount = 0;
                                /*Node?*/ let prev = null;
                                for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                                {
                                    $.$$.System.Diagnostics.Debug.Assert$2((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                                    if (hashcode === node._hashcode && comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$Equals(key, node._key, [TAlternateKey, TKey]))
                                    {
                                        if (updateIfExists)
                                        {
                                            if (!TValue.$type.IsValueType || $.$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                            {
                                                node._value = value;
                                            }
                                            else 
                                            {
                                                /*var*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, value, hashcode, node._next);
                                                if (prev === null)
                                                {
                                                    bucket.$v = newNode;
                                                }
                                                else 
                                                {
                                                    prev._next = newNode;
                                                }
                                            }
                                            resultingValue.$v = value;
                                        }
                                        else 
                                        {
                                            resultingValue.$v = node._value;
                                        }
                                        return false;
                                    }
                                    prev = node;
                                    if (!TKey.$type.IsValueType)
                                    {
                                        collisionCount++;
                                    }
                                }
                                /*TKey*/ let actualKey = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$Create(key, [TAlternateKey, TKey]);
                                if (actualKey === null)
                                {
                                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                                }
                                /*var*/ let resultNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(actualKey, value, hashcode, bucket.$v);
                                bucket.$v = resultNode;
                                //checked
                                {
                                    (() =>
                                    {
                                        let $old = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                        $.$$.System.Array.$WriteT1.call(tables._countPerLock, $old + 1, lockNo);
                                        return $old;
                                    })();
                                }
                                if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) > this.Dictionary._budget)
                                {
                                    resizeDesired = true;
                                }
                                if (!TKey.$type.IsValueType && collisionCount > 100/*HashHelpers.HashCollisionThreshold*/ && $.$is(comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))
                                {
                                    forceRehash = true;
                                }
                            }
                            finally
                            {
                                {
                                    if (lockTaken)
                                    {
                                        $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo));
                                    }
                                }
                            }
                            if ($.$$.System.Boolean.op_BitwiseOr(resizeDesired, forceRehash))
                            {
                                this.Dictionary.GrowTable(tables, resizeDesired, forceRehash);
                            }
                            resultingValue.$v = value;
                            return true;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130066446)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425033742)
                    /*bool */ TryGetValue$1(/*TAlternateKey*/ key, /*out TValue*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64425033742);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.TryGetValue(key, $.$discardRef(), value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425033742)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720001038)
                    /*bool */ TryGetValue(/*TAlternateKey*/ key, /*out TKey*/ actualKey, /*out TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68720001038);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (key === null)
                        {
                            $.$scc.System.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                        for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                        {
                            if (hashcode === n._hashcode && comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$Equals(key, n._key, [TAlternateKey, TKey]))
                            {
                                actualKey.$v = n._key;
                                value.$v = n._value;
                                return true;
                            }
                        }
                        actualKey.$v = $.$default(TKey);
                        value.$v = $.$default(TValue);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720001038)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014968334)
                    /*bool */ TryRemove$1(/*TAlternateKey*/ key, /*out TValue*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(73014968334);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.TryRemove(key, $.$discardRef(), value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014968334)
                    
                    //--TRIMMABLE-BOUNDARY-START(77309935630)
                    /*bool */ TryRemove(/*TAlternateKey*/ key, /*out TKey*/ actualKey, /*out TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77309935630);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (key === null)
                        {
                            $.$scc.System.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                        while(true)
                        {
                            /*object[]*/ let locks = tables._locks;
                            /*uint*/ let lockNo;
                            /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                            if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) !== 0)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                                    {
                                        if (tables !== this.Dictionary._tables)
                                        {
                                            tables = this.Dictionary._tables;
                                            if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                                            {
                                                comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                                                hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                                            }
                                            continue;
                                        }
                                        /*Node?*/ let prev = null;
                                        for(/*Node?*/ let curr = bucket.$v; !(curr === null); curr = curr._next)
                                        {
                                            $.$$.System.Diagnostics.Debug.Assert$2((prev === null && curr === bucket.$v) || prev._next === curr, "(prev is null && curr == bucket) || prev!._next == curr");
                                            if (hashcode === curr._hashcode && comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$Equals(key, curr._key, [TAlternateKey, TKey]))
                                            {
                                                if (prev === null)
                                                {
                                                    bucket.$v = curr._next;
                                                }
                                                else 
                                                {
                                                    prev._next = curr._next;
                                                }
                                                actualKey.$v = curr._key;
                                                value.$v = curr._value;
                                                (() =>
                                                {
                                                    let $old = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                                    $.$$.System.Array.$WriteT1.call(tables._countPerLock, $old - 1, lockNo);
                                                    return $old;
                                                })();
                                                return true;
                                            }
                                            prev = curr;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                                }
                            }
                            actualKey.$v = $.$default(TKey);
                            value.$v = $.$default(TValue);
                            return false;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77309935630)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Dictionary = this.Dictionary;
                        return copy;
                    }
                    static $h = 524302;
                    static $g = 1;
                    static $z = 4;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360782),
    {
      "p": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "Dictionary",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475360782),
//--TRIMMABLE-BOUNDARY-START(51540131854),
    {
      "p": TValue?.$h??1572864,
      "i": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1507328
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540131854)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393486),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1507328
        }
      ],
      "n": "ContainsKey",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393486),
//--TRIMMABLE-BOUNDARY-START(55835099150),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864
        }
      ],
      "n": "TryAdd",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835099150),
//--TRIMMABLE-BOUNDARY-START(60130066446),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864
        },
        {
          "n": "updateIfExists",
          "p": 262145
        },
        {
          "n": "resultingValue",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryAdd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130066446),
//--TRIMMABLE-BOUNDARY-START(64425033742),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425033742),
//--TRIMMABLE-BOUNDARY-START(68720001038),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1507328
        },
        {
          "n": "actualKey",
          "p": TKey?.$h??1507328,
          "f": 2
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720001038),
//--TRIMMABLE-BOUNDARY-START(73014968334),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryRemove",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014968334),
//--TRIMMABLE-BOUNDARY-START(77309935630),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1507328
        },
        {
          "n": "actualKey",
          "p": TKey?.$h??1507328,
          "f": 2
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryRemove",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309935630)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491598),
    {
      "p": [
        {
          "n": "dictionary",
          "p": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295491598),
//--TRIMMABLE-BOUNDARY-START(8590458894),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458894)
  ],
  "g": [TAlternateKey?.$h??1507328
  ],
  "s": [
    {
      "n": "TAlternateKey",
      "f": 64
    }
  ],
  "r": 1,
  "d": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.AlternateLookup<${TAlternateKey?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_AlternateLookup$$ = $v))(TAlternateKey);
            }
            //--TRIMMABLE-BOUNDARY-END(524302)
            
            //--TRIMMABLE-BOUNDARY-START(17239244801)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239244801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239244801)
            
            //--TRIMMABLE-BOUNDARY-START(51598983169)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51598983169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51598983169)
            
            //--TRIMMABLE-BOUNDARY-START(25829179393)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Keys.get
            get System$Collections$Generic$IDictionary$$$$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38714081281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(25829179393)
            
            //--TRIMMABLE-BOUNDARY-START(34419113985)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Values.get
            get System$Collections$Generic$IDictionary$$$$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64483885057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(34419113985)
            
            //--TRIMMABLE-BOUNDARY-START(8649310209)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649310209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649310209)
            
            //--TRIMMABLE-BOUNDARY-START(60188917761)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60188917761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60188917761)
            
            //--TRIMMABLE-BOUNDARY-START(30123950081)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534015489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30123950081)
            
            //--TRIMMABLE-BOUNDARY-START(8649113601)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649113601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649113601)
            
            //--TRIMMABLE-BOUNDARY-START(8652324865)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652324865)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(4354932737)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354932737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354932737)
            
            //--TRIMMABLE-BOUNDARY-START(43009638401)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009638401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43009638401)
            
            //--TRIMMABLE-BOUNDARY-START(12944867329)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IReadOnlyDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944867329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944867329)
            
            //--TRIMMABLE-BOUNDARY-START(12944801793)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354867201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944801793)
            
            //--TRIMMABLE-BOUNDARY-START(4354473985)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey, TValue>>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354473985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354473985)
            
            static $h = 458766;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(498216665102),
    {
      "p": TValue?.$h??1572864,
      "i": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4600000000n),
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(498216665102),
//--TRIMMABLE-BOUNDARY-START(98784706574),
    {
      "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 50331649
      },
      "n": "Comparer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784706574),
//--TRIMMABLE-BOUNDARY-START(120259543054),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259543054),
//--TRIMMABLE-BOUNDARY-START(270583398414),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583398414),
//--TRIMMABLE-BOUNDARY-START(274878365710),
    {
      "p": $.$$.System.Collections.Generic.ICollection$$(TKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2C00000000n),
        "f": 50331649
      },
      "n": "Keys",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878365710),
//--TRIMMABLE-BOUNDARY-START(ALL, 360777711630, 34419703809),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x5100000000n),
        "f": 50331650
      },
      "n": "{$.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue).$h}.Keys",
      "o": "System$Collections$Generic$IReadOnlyDictionary$$$$Keys",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5400000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 360777711630, 34419703809),
//--TRIMMABLE-BOUNDARY-START(558346207246),
    {
      "p": $.$$.System.Collections.Generic.ICollection$$(TValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2E00000000n),
        "f": 50331649
      },
      "n": "Values",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x8200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(558346207246),
//--TRIMMABLE-BOUNDARY-START(ALL, 365072678926, 47304605697),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$(TValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x5300000000n),
        "f": 50331650
      },
      "n": "{$.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue).$h}.Values",
      "o": "System$Collections$Generic$IReadOnlyDictionary$$$$Values",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5500000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 365072678926, 47304605697),
//--TRIMMABLE-BOUNDARY-START(ALL, 326417973262, 43008851969),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4B00000000n),
        "f": 50331650
      },
      "n": "{$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h}.IsReadOnly",
      "o": "System$Collections$Generic$ICollection$$$IsReadOnly",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4C00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 326417973262, 43008851969),
//--TRIMMABLE-BOUNDARY-START(ALL, 455266992142, 64486899713),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6000000000n),
        "f": 50331650
      },
      "n": "{62390273}.IsFixedSize",
      "o": "System$Collections$IDictionary$IsFixedSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x6A00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 455266992142, 64486899713),
//--TRIMMABLE-BOUNDARY-START(ALL, 459561959438, 68781867009),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6200000000n),
        "f": 50331650
      },
      "n": "{62390273}.IsReadOnly",
      "o": "System$Collections$IDictionary$IsReadOnly",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x6B00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 459561959438, 68781867009),
//--TRIMMABLE-BOUNDARY-START(ALL, 463856926734, 73076834305),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6600000000n),
        "f": 50331650
      },
      "n": "{62390273}.Keys",
      "o": "System$Collections$IDictionary$Keys",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x6C00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 463856926734, 73076834305),
//--TRIMMABLE-BOUNDARY-START(ALL, 485331763214, 94551670785),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6800000000n),
        "f": 50331650
      },
      "n": "{62390273}.Values",
      "o": "System$Collections$IDictionary$Values",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7100000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 485331763214, 94551670785),
//--TRIMMABLE-BOUNDARY-START(ALL, 481036795918, 90256703489),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6400000000n),
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6F00000000n),
        "f": 83886082
      },
      "n": "{62390273}.this[]",
      "o": "System$Collections$IDictionary$Item",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7000000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 481036795918, 90256703489),
//--TRIMMABLE-BOUNDARY-START(ALL, 390842482702, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x5800000000n),
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5B00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 390842482702, 38716964865),
//--TRIMMABLE-BOUNDARY-START(ALL, 395137449998, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x5A00000000n),
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5C00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 395137449998, 43011932161),
//--TRIMMABLE-BOUNDARY-START(128849477646),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 50331682
      },
      "n": "DefaultConcurrencyLevel",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(128849477646)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(206158888974),
    {
      "r": (TAlternateKey) => $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey).$h,
      "g": [
        "TAlternateKey"
      ],
      "n": "GetAlternateLookup",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(206158888974),
//--TRIMMABLE-BOUNDARY-START(523986468878),
    {
      "r": 262145,
      "p": [
        {
          "n": "lookup",
          "p": (TAlternateKey) => $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey).$h,
          "f": 2
        }
      ],
      "g": [
        "TAlternateKey"
      ],
      "n": "TryGetAlternateLookup",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7A00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(523986468878),
//--TRIMMABLE-BOUNDARY-START(219043790862),
    {
      "r": 655361,
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h
        }
      ],
      "n": "GetCapacityFromCollection",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(219043790862),
//--TRIMMABLE-BOUNDARY-START(231928692750),
    {
      "r": 655361,
      "p": [
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        },
        {
          "n": "key",
          "p": TKey?.$h??1507328
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(231928692750),
//--TRIMMABLE-BOUNDARY-START(287763267598),
    {
      "r": 262145,
      "p": [
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        },
        {
          "n": "node",
          "p": 720910
        },
        {
          "n": "key",
          "p": TKey?.$h??1507328
        }
      ],
      "n": "NodeEqualsKey",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(287763267598),
//--TRIMMABLE-BOUNDARY-START(261993463822),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h
        }
      ],
      "n": "InitializeFromCollection",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261993463822),
//--TRIMMABLE-BOUNDARY-START(515396534286),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864
        }
      ],
      "n": "TryAdd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(515396534286),
//--TRIMMABLE-BOUNDARY-START(103079673870),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        }
      ],
      "n": "ContainsKey",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079673870),
//--TRIMMABLE-BOUNDARY-START(536871370766),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryRemove",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(536871370766),
//--TRIMMABLE-BOUNDARY-START(541166338062),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$h
        }
      ],
      "n": "TryRemove",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(541166338062),
//--TRIMMABLE-BOUNDARY-START(545461305358),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864,
          "f": 2
        },
        {
          "n": "matchValue",
          "p": 262145
        },
        {
          "n": "oldValue",
          "p": TValue?.$h??1572864
        }
      ],
      "n": "TryRemoveInternal",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7F00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(545461305358),
//--TRIMMABLE-BOUNDARY-START(528281436174),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(528281436174),
//--TRIMMABLE-BOUNDARY-START(532576403470),
    {
      "r": 262145,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "hashcode",
          "p": 655361
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryGetValueInternal",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7C00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(532576403470),
//--TRIMMABLE-BOUNDARY-START(549756272654),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "newValue",
          "p": TValue?.$h??1572864
        },
        {
          "n": "comparisonValue",
          "p": TValue?.$h??1572864
        }
      ],
      "n": "TryUpdate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x8000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(549756272654),
//--TRIMMABLE-BOUNDARY-START(554051239950),
    {
      "r": 262145,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "nullableHashcode",
          "p": $.$typeNullable($.$$.System.Int32).$h
        },
        {
          "n": "newValue",
          "p": TValue?.$h??1572864
        },
        {
          "n": "comparisonValue",
          "p": TValue?.$h??1572864
        }
      ],
      "n": "TryUpdateInternal",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x8100000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(554051239950),
//--TRIMMABLE-BOUNDARY-START(94489739278),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489739278),
//--TRIMMABLE-BOUNDARY-START(511101566990),
    {
      "r": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,
      "n": "ToArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(511101566990),
//--TRIMMABLE-BOUNDARY-START(115964575758),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyToPairs",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964575758),
//--TRIMMABLE-BOUNDARY-START(107374641166),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.System.Collections.DictionaryEntry).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyToEntries",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107374641166),
//--TRIMMABLE-BOUNDARY-START(111669608462),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.System.Object).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyToObjects",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111669608462),
//--TRIMMABLE-BOUNDARY-START(227633725454),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227633725454),
//--TRIMMABLE-BOUNDARY-START(519691501582),
    {
      "r": 262145,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "nullableHashcode",
          "p": $.$typeNullable($.$$.System.Int32).$h
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864
        },
        {
          "n": "updateIfExists",
          "p": 262145
        },
        {
          "n": "acquireLock",
          "p": 262145
        },
        {
          "n": "resultingValue",
          "p": TValue?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryAddInternal",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(519691501582),
//--TRIMMABLE-BOUNDARY-START(506806599694),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        }
      ],
      "n": "ThrowKeyNotFoundException",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7600000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(506806599694),
//--TRIMMABLE-BOUNDARY-START(223338758158),
    {
      "r": 655361,
      "n": "GetCountNoLocks",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223338758158),
//--TRIMMABLE-BOUNDARY-START(240518627342),
    {
      "r": TValue?.$h??1572864,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "valueFactory",
          "p": $.$$.System.Func$$$(TKey, TValue).$h
        }
      ],
      "n": "GetOrAdd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240518627342),
//--TRIMMABLE-BOUNDARY-START(244813594638),
    {
      "r": TValue?.$h??1572864,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "valueFactory",
          "p": (TArg) => $.$$.System.Func$$$$(TKey, TArg, TValue).$h
        },
        {
          "n": "factoryArgument",
          "p": (TArg) => TArg.$h
        }
      ],
      "g": [
        "TArg"
      ],
      "n": "GetOrAdd",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(244813594638),
//--TRIMMABLE-BOUNDARY-START(249108561934),
    {
      "r": TValue?.$h??1572864,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864
        }
      ],
      "n": "GetOrAdd",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249108561934),
//--TRIMMABLE-BOUNDARY-START(73014902798),
    {
      "r": TValue?.$h??1572864,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "addValueFactory",
          "p": (TArg) => $.$$.System.Func$$$$(TKey, TArg, TValue).$h
        },
        {
          "n": "updateValueFactory",
          "p": (TArg) => $.$$.System.Func$$$$$(TKey, TValue, TArg, TValue).$h
        },
        {
          "n": "factoryArgument",
          "p": (TArg) => TArg.$h
        }
      ],
      "g": [
        "TArg"
      ],
      "n": "AddOrUpdate",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(73014902798),
//--TRIMMABLE-BOUNDARY-START(77309870094),
    {
      "r": TValue?.$h??1572864,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "addValueFactory",
          "p": $.$$.System.Func$$$(TKey, TValue).$h
        },
        {
          "n": "updateValueFactory",
          "p": $.$$.System.Func$$$$(TKey, TValue, TValue).$h
        }
      ],
      "n": "AddOrUpdate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309870094),
//--TRIMMABLE-BOUNDARY-START(81604837390),
    {
      "r": TValue?.$h??1572864,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "addValue",
          "p": TValue?.$h??1572864
        },
        {
          "n": "updateValueFactory",
          "p": $.$$.System.Func$$$$(TKey, TValue, TValue).$h
        }
      ],
      "n": "AddOrUpdate",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604837390),
//--TRIMMABLE-BOUNDARY-START(502511632398),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ThrowIfInvalidObjectValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7500000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(502511632398),
//--TRIMMABLE-BOUNDARY-START(90194771982),
    {
      "r": 262145,
      "n": "AreAllBucketsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90194771982),
//--TRIMMABLE-BOUNDARY-START(257698496526),
    {
      "r": 65537,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "resizeDesired",
          "p": 262145
        },
        {
          "n": "forceRehashIfNonRandomized",
          "p": 262145
        }
      ],
      "n": "GrowTable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(257698496526),
//--TRIMMABLE-BOUNDARY-START(60130000910),
    {
      "r": 65537,
      "p": [
        {
          "n": "locksAcquired",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "AcquireAllLocks",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130000910),
//--TRIMMABLE-BOUNDARY-START(64424968206),
    {
      "r": 65537,
      "p": [
        {
          "n": "locksAcquired",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "AcquireFirstLock",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64424968206),
//--TRIMMABLE-BOUNDARY-START(68719935502),
    {
      "r": 65537,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "locksAcquired",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "AcquirePostFirstLock",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719935502),
//--TRIMMABLE-BOUNDARY-START(292058234894),
    {
      "r": 65537,
      "p": [
        {
          "n": "locksAcquired",
          "p": 655361
        }
      ],
      "n": "ReleaseLocks",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(292058234894),
//--TRIMMABLE-BOUNDARY-START(236223660046),
    {
      "r": $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TKey).$h,
      "n": "GetKeys",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(236223660046),
//--TRIMMABLE-BOUNDARY-START(253403529230),
    {
      "r": $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TValue).$h,
      "n": "GetValues",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253403529230),
//--TRIMMABLE-BOUNDARY-START(210453856270),
    {
      "r": 720910,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "hashcode",
          "p": 655361
        }
      ],
      "n": "GetBucket",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(210453856270),
//--TRIMMABLE-BOUNDARY-START(214748823566),
    {
      "r": 720910,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "hashcode",
          "p": 655361
        },
        {
          "n": "lockNo",
          "p": 720897,
          "f": 2
        }
      ],
      "n": "GetBucketAndLock",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(214748823566),
//--TRIMMABLE-BOUNDARY-START(266288431118),
    {
      "r": 262145,
      "p": [
        {
          "n": "tables",
          "p": 786446
        }
      ],
      "g": [
        "TAlternateKey"
      ],
      "n": "IsCompatibleKey",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(266288431118),
//--TRIMMABLE-BOUNDARY-START(201863921678),
    {
      "r": (TAlternateKey) => $.$$.System.Collections.Generic.IAlternateEqualityComparer$$$(TAlternateKey, TKey).$h,
      "p": [
        {
          "n": "tables",
          "p": 786446
        }
      ],
      "g": [
        "TAlternateKey"
      ],
      "n": "GetAlternateComparer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(201863921678)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475295246),
    {
      "t": 786446,
      "n": "_tables",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475295246),
//--TRIMMABLE-BOUNDARY-START(4295426062),
    {
      "t": 655361,
      "n": "_budget",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426062),
//--TRIMMABLE-BOUNDARY-START(12885360654),
    {
      "t": 262145,
      "n": "_growLockArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360654),
//--TRIMMABLE-BOUNDARY-START(8590393358),
    {
      "t": 262145,
      "n": "_comparerIsDefaultForClasses",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393358),
//--TRIMMABLE-BOUNDARY-START(17180327950),
    {
      "t": 655361,
      "n": "_initialCapacity",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180327950),
//--TRIMMABLE-BOUNDARY-START(124554510350),
    {
      "t": 655361,
      "n": "DefaultCapacity",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124554510350),
//--TRIMMABLE-BOUNDARY-START(279173333006),
    {
      "t": 655361,
      "n": "MaxLockNumber",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(279173333006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770262542),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770262542),
//--TRIMMABLE-BOUNDARY-START(30065229838),
    {
      "p": [
        {
          "n": "concurrencyLevel",
          "p": 655361
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229838),
//--TRIMMABLE-BOUNDARY-START(34360197134),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197134),
//--TRIMMABLE-BOUNDARY-START(38655164430),
    {
      "p": [
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655164430),
//--TRIMMABLE-BOUNDARY-START(42950131726),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h
        },
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950131726),
//--TRIMMABLE-BOUNDARY-START(47245099022),
    {
      "p": [
        {
          "n": "concurrencyLevel",
          "p": 655361
        },
        {
          "n": "collection",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h
        },
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245099022),
//--TRIMMABLE-BOUNDARY-START(51540066318),
    {
      "p": [
        {
          "n": "concurrencyLevel",
          "p": 655361
        },
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540066318),
//--TRIMMABLE-BOUNDARY-START(55835033614),
    {
      "p": [
        {
          "n": "concurrencyLevel",
          "p": 655361
        },
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "growLockArray",
          "p": 262145
        },
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55835033614)
  ],
  "i": [$.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue).$h,$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,62390273,62259201,$.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,62521345
  ],
  "g": [TKey?.$h??1507328,TValue?.$h??1572864
  ],
  "s": [
    {
      "n": "TKey",
      "f": 64
    },
    null
  ],
  "j": [655374,851982,720910,786446,589838,524302
  ],
  "r": 2,
  "h": this.$h,
  "a": [
    {
      "t": 70582273,
      "c": 8660516865,
      "a": [
        {
          "v": $.$scc.System.Collections.Concurrent.IDictionaryDebugView$$$().$h,
          "t": 187629569
        }
      ]
    },
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458766)
        
        
        //--TRIMMABLE-BOUNDARY-START(196622)
        $asm.$cls("$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider", ($self) => class CDSCollectionETWBCLProvider extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            //--TRIMMABLE-BOUNDARY-START(60129738766)
            /*CDSCollectionETWBCLProvider*/ static Log = null;
            //--TRIMMABLE-BOUNDARY-END(60129738766)
            
            //--TRIMMABLE-BOUNDARY-START(8590131214)
            $ctor$10()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131214);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131214)
            
            //--TRIMMABLE-BOUNDARY-START(12885098510)
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            //--TRIMMABLE-BOUNDARY-END(12885098510)
            
            //--TRIMMABLE-BOUNDARY-START(55834771470)
            /*int*/ static CONCURRENTSTACK_FASTPUSHFAILED_ID = 1;
            //--TRIMMABLE-BOUNDARY-END(55834771470)
            
            //--TRIMMABLE-BOUNDARY-START(47244836878)
            /*int*/ static CONCURRENTSTACK_FASTPOPFAILED_ID = 2;
            //--TRIMMABLE-BOUNDARY-END(47244836878)
            
            //--TRIMMABLE-BOUNDARY-START(38654902286)
            /*int*/ static CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID = 3;
            //--TRIMMABLE-BOUNDARY-END(38654902286)
            
            //--TRIMMABLE-BOUNDARY-START(30064967694)
            /*int*/ static CONCURRENTBAG_TRYTAKESTEALS_ID = 4;
            //--TRIMMABLE-BOUNDARY-END(30064967694)
            
            //--TRIMMABLE-BOUNDARY-START(21475033102)
            /*int*/ static CONCURRENTBAG_TRYPEEKSTEALS_ID = 5;
            //--TRIMMABLE-BOUNDARY-END(21475033102)
            
            //--TRIMMABLE-BOUNDARY-START(51539804174)
            /*void */ ConcurrentStack_FastPushFailed(/*int*/ spinCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(1/*CONCURRENTSTACK_FASTPUSHFAILED_ID*/, spinCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539804174)
            
            //--TRIMMABLE-BOUNDARY-START(42949869582)
            /*void */ ConcurrentStack_FastPopFailed(/*int*/ spinCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(2/*CONCURRENTSTACK_FASTPOPFAILED_ID*/, spinCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949869582)
            
            //--TRIMMABLE-BOUNDARY-START(34359934990)
            /*void */ ConcurrentDictionary_AcquiringAllLocks(/*int*/ numOfBuckets)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359934990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(3/*CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID*/, numOfBuckets);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359934990)
            
            //--TRIMMABLE-BOUNDARY-START(25770000398)
            /*void */ ConcurrentBag_TryTakeSteals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.WriteEvent$18(4/*CONCURRENTBAG_TRYTAKESTEALS_ID*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770000398)
            
            //--TRIMMABLE-BOUNDARY-START(17180065806)
            /*void */ ConcurrentBag_TryPeekSteals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.WriteEvent$18(5/*CONCURRENTBAG_TRYPEEKSTEALS_ID*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180065806)
            
            //--TRIMMABLE-BOUNDARY-START(4295163918)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(60129738766)
                    this.Log = new $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider().$ctor$10();
                    //--TRIMMABLE-BOUNDARY-END(60129738766)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295163918)
            
            static $h = 196622;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 74383361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539804174),
    {
      "r": 65537,
      "p": [
        {
          "n": "spinCount",
          "p": 655361
        }
      ],
      "n": "ConcurrentStack_FastPushFailed",
      "d": 196622,
      "h": 51539804174,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 1,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 3,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539804174),
//--TRIMMABLE-BOUNDARY-START(42949869582),
    {
      "r": 65537,
      "p": [
        {
          "n": "spinCount",
          "p": 655361
        }
      ],
      "n": "ConcurrentStack_FastPopFailed",
      "d": 196622,
      "h": 42949869582,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 2,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 3,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949869582),
//--TRIMMABLE-BOUNDARY-START(34359934990),
    {
      "r": 65537,
      "p": [
        {
          "n": "numOfBuckets",
          "p": 655361
        }
      ],
      "n": "ConcurrentDictionary_AcquiringAllLocks",
      "d": 196622,
      "h": 34359934990,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 3,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 3,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34359934990),
//--TRIMMABLE-BOUNDARY-START(25770000398),
    {
      "r": 65537,
      "n": "ConcurrentBag_TryTakeSteals",
      "d": 196622,
      "h": 25770000398,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770000398),
//--TRIMMABLE-BOUNDARY-START(17180065806),
    {
      "r": 65537,
      "n": "ConcurrentBag_TryPeekSteals",
      "d": 196622,
      "h": 17180065806,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 5,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73596929
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180065806)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60129738766),
    {
      "t": 196622,
      "n": "Log",
      "d": 196622,
      "h": 60129738766,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129738766),
//--TRIMMABLE-BOUNDARY-START(12885098510),
    {
      "t": 73531393,
      "n": "ALL_KEYWORDS",
      "d": 196622,
      "h": 12885098510,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885098510),
//--TRIMMABLE-BOUNDARY-START(55834771470),
    {
      "t": 655361,
      "n": "CONCURRENTSTACK_FASTPUSHFAILED_ID",
      "d": 196622,
      "h": 55834771470,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834771470),
//--TRIMMABLE-BOUNDARY-START(47244836878),
    {
      "t": 655361,
      "n": "CONCURRENTSTACK_FASTPOPFAILED_ID",
      "d": 196622,
      "h": 47244836878,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244836878),
//--TRIMMABLE-BOUNDARY-START(38654902286),
    {
      "t": 655361,
      "n": "CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID",
      "d": 196622,
      "h": 38654902286,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38654902286),
//--TRIMMABLE-BOUNDARY-START(30064967694),
    {
      "t": 655361,
      "n": "CONCURRENTBAG_TRYTAKESTEALS_ID",
      "d": 196622,
      "h": 30064967694,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30064967694),
//--TRIMMABLE-BOUNDARY-START(21475033102),
    {
      "t": 655361,
      "n": "CONCURRENTBAG_TRYPEEKSTEALS_ID",
      "d": 196622,
      "h": 21475033102,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21475033102)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131214),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 196622,
      "h": 8590131214,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590131214)
  ],
  "i": [90177537
  ],
  "h": 196622,
  "a": [
    {
      "t": 74711041,
      "c": 4369678337,
      "n": [
        {
          "n": "Name",
          "v": "System.Collections.Concurrent.ConcurrentCollectionsEventSource",
          "t": 1310721
        },
        {
          "n": "Guid",
          "v": "35167F8E-49B2-4b96-AB86-435B59336B5E",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Collections.Concurrent.CDSCollectionETWBCLProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196622)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading"))
//--TRIMMABLE-BOUNDARY-END(14)
